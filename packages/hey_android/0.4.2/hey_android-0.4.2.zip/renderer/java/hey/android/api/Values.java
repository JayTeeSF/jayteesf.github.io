package hey.android.api;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The value language of a hey_mobile description (hey_mobile docs/RENDERERS.md,
 * "Values"): paths, templates and modifiers, lines, literal text, conditions,
 * truth, request body values, parameters, path variables, and which kinds a
 * level knows. Pure Java: specs/api_renderer_host_spec.sh runs every vector in
 * hey_mobile's conformance/values.json against this class on the Mac.
 */
public final class Values {
  private Values() {}

  /** The one level this renderer declares (renderer/api-renderer.json). */
  public static final int RENDERER_LEVEL = 1;
  public static final String RENDERER_PLATFORM = "android";

  /** value(): the key is left out of a request body. */
  public static final Object OMIT = new Object() {
    @Override public String toString() { return "(omitted)"; }
  };

  static boolean isNull(Object v) { return v == null || v == Json.NULL; }

  public static String string(Object v) {
    if (v instanceof String) return (String) v;
    if (v instanceof Boolean) return ((Boolean) v) ? "true" : "false";
    if (v instanceof Number) return Json.numberText((Number) v);
    return "";
  }

  private static boolean digits(String s) {
    if (s.isEmpty()) return false;
    int i = s.startsWith("-") ? 1 : 0;
    if (i == s.length()) return false;
    for (; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c < '0' || c > '9') return false;
    }
    return true;
  }

  public static long integer(Object v) {
    if (v instanceof Boolean) return 0;
    if (v instanceof Number) return ((Number) v).longValue();
    if (v instanceof String && digits((String) v)) {
      try {
        return Long.parseLong((String) v);
      } catch (NumberFormatException e) {
        return 0;
      }
    }
    return 0;
  }

  /** A dotted path through objects only; never into a list. null when absent or JSON null. */
  public static Object at(Object json, String path) {
    if (path == null || path.isEmpty()) return null;
    Object cur = json;
    for (String part : path.split("\\.", -1)) {
      if (!(cur instanceof Map)) return null;
      cur = ((Map<?, ?>) cur).get(part);
      if (isNull(cur)) return null;
    }
    return cur;
  }

  /**
   * The whole scale, always five, then the number: "★★★⯪☆ 3.5".
   *
   * <p>THE HALF-STAR GLYPH IS THE CONTRACT'S, not a choice this renderer gets
   * to make: hey_mobile's conformance vectors name U+2BEA exactly, and iOS
   * draws the same string. It is worth knowing that it draws as a tofu box on a
   * device whose font lacks it (a Nexus 5X), which is why the rating FIELD
   * shows a half by drawing a whole star faintly instead of by spelling it.
   */
  public static String stars(long halves) {
    if (halves <= 0) return "";
    if (halves > 10) halves = 10;
    StringBuilder s = new StringBuilder();
    for (long i = 1; i <= 5; i++) {
      if (i * 2 <= halves) s.append('★');
      else if (i * 2 == halves + 1) s.append('⯪');
      else s.append('☆');
    }
    s.append(' ').append(Json.numberText(halves / 2.0));
    return s.toString();
  }

  /** Seconds as "42 min", "1 h" or "1 h 5 min"; nothing when unknown. */
  public static String duration(long seconds) {
    if (seconds <= 0) return "";
    long minutes = Math.max(1, (seconds + 30) / 60);
    if (minutes < 60) return minutes + " min";
    long rest = minutes % 60;
    return rest == 0 ? (minutes / 60) + " h" : (minutes / 60) + " h " + rest + " min";
  }

  static String format(String inner, Object obj, Map<String, Object> labels) {
    int colon = inner.indexOf(':');
    String mod = colon < 0 ? "" : inner.substring(0, colon);
    String path = colon < 0 ? inner : inner.substring(colon + 1);
    Object raw = at(obj, path);
    String text = string(raw);
    if (mod.isEmpty()) return text;
    switch (mod) {
      case "label": {
        String label = string(Json.dict(labels).get(text));
        return label.isEmpty() ? text : label;
      }
      case "date": return text.length() >= 10 ? text.substring(0, 10) : text;
      case "duration": return duration(integer(raw));
      case "stars": return stars(integer(raw));
      default: return ""; // an unknown modifier empties its placeholder, so the template is hidden
    }
  }

  /** 'title' is a path; 'From {sharer}' is a template, "" when any placeholder is empty. */
  public static String render(Object spec, Object obj, Map<String, Object> labels) {
    if (!(spec instanceof String)) return "";
    String s = (String) spec;
    if (s.isEmpty()) return "";
    if (s.indexOf('{') < 0) return string(at(obj, s));
    StringBuilder out = new StringBuilder();
    int from = 0;
    while (from < s.length()) {
      int open = s.indexOf('{', from);
      if (open < 0) {
        out.append(s, from, s.length());
        break;
      }
      out.append(s, from, open);
      int close = s.indexOf('}', open);
      if (close < 0) break;
      String value = format(s.substring(open + 1, close), obj, labels);
      if (value.isEmpty()) return "";
      out.append(value);
      from = close + 1;
    }
    return out.toString();
  }

  /** A line: a render, or a list of parts with the empty ones dropped, joined by " · ". */
  public static String line(Object spec, Object obj, Map<String, Object> labels) {
    if (spec instanceof String) return render(spec, obj, labels);
    if (!(spec instanceof List)) return "";
    StringBuilder out = new StringBuilder();
    for (Object piece : (List<?>) spec) {
      String text = render(string(piece), obj, labels);
      if (text.isEmpty()) continue;
      if (out.length() > 0) out.append(" · ");
      out.append(text);
    }
    return out.toString();
  }

  /** Literal text unless it has a {placeholder}. */
  public static String text(Object spec, Object obj, Map<String, Object> labels) {
    String s = string(spec);
    if (s.indexOf('{') < 0) return s;
    return render(s, obj, labels);
  }

  public static boolean truthy(Object v) {
    if (isNull(v)) return false;
    if (v instanceof String) return !((String) v).isEmpty();
    if (v instanceof Boolean) return (Boolean) v;
    if (v instanceof Number) return ((Number) v).doubleValue() != 0;
    if (v instanceof List) return !((List<?>) v).isEmpty();
    return true;
  }

  private static boolean present(Map<?, ?> d, String key) {
    return !isNull(d.get(key));
  }

  /** nil, 'field', '!field', [all of these], or {field, equals | not | in}; values compare as text. */
  public static boolean when(Object spec, Object obj) {
    if (spec instanceof String) {
      String s = (String) spec;
      boolean negate = s.startsWith("!");
      if (negate) s = s.substring(1);
      boolean truth = truthy(at(obj, s));
      return negate != truth;
    }
    if (spec instanceof List) {
      for (Object part : (List<?>) spec) if (!when(part, obj)) return false;
      return true;
    }
    if (!(spec instanceof Map)) return true;
    Map<?, ?> d = (Map<?, ?>) spec;
    String value = string(at(obj, string(d.get("field"))));
    if (present(d, "equals")) return value.equals(string(d.get("equals")));
    if (present(d, "not")) return !value.equals(string(d.get("not")));
    if (present(d, "in")) {
      for (Object option : Json.list(d.get("in"))) if (string(option).equals(value)) return true;
      return false;
    }
    return true;
  }

  /** A request body value: '$name' a variable, '@path' a row field, '?' at the end leaves an empty one out. */
  public static Object value(Object spec, Map<String, Object> vars, Object row) {
    if (!(spec instanceof String)) return spec;
    String s = (String) spec;
    if (!s.startsWith("$") && !s.startsWith("@")) return s;
    boolean optional = s.endsWith("?") && s.length() > 1;
    String name = s.substring(1, s.length() - (optional ? 1 : 0));
    Object v = s.startsWith("$") ? Json.dict(vars).get(name) : at(row, name);
    if (v == Json.NULL) v = null;
    boolean empty = v == null || (v instanceof String && ((String) v).isEmpty()) || (v instanceof List && ((List<?>) v).isEmpty());
    if (empty) return optional ? OMIT : "";
    return v;
  }

  /** A parameter: '$name' a variable, '=word' the word, else a path read from the row, then the screen's answer. */
  public static String param(Object spec, Map<String, Object> vars, Object row, Object json) {
    String p = string(spec);
    if (p.startsWith("$")) return string(Json.dict(vars).get(p.substring(1)));
    if (p.startsWith("=")) return p.substring(1);
    String fromRow = string(at(row, p));
    return !fromRow.isEmpty() ? fromRow : string(at(json, p));
  }

  private static final String PATH_ALLOWED = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!$&'()*+,-.:;=@_~";

  static String percentEncode(String value) {
    StringBuilder out = new StringBuilder();
    for (byte b : value.getBytes(StandardCharsets.UTF_8)) {
      int c = b & 0xff;
      if (c < 0x80 && PATH_ALLOWED.indexOf(c) >= 0) out.append((char) c);
      else out.append('%').append(String.format("%02X", c));
    }
    return out.toString();
  }

  /** '/things/{id}' with each {name} replaced by its variable, percent-encoded; an unknown {name} stays. */
  public static String fillPath(String path, Map<String, Object> vars) {
    String out = path == null ? "" : path;
    for (Map.Entry<String, Object> e : Json.dict(vars).entrySet()) {
      out = out.replace("{" + e.getKey() + "}", percentEncode(string(e.getValue())));
    }
    return out;
  }

  // ---- kinds -------------------------------------------------------------------------------

  static List<String> screenTypes(int level) {
    return level <= 1 ? Arrays.asList("list", "form", "search", "audio", "detail") : Arrays.asList("list", "form", "search", "audio");
  }

  static final List<String> SECTION_KINDS = Arrays.asList("fields", "actions", "rows", "from", "route");
  static final List<String> ACTION_KINDS = Arrays.asList("request", "open_url", "open_screen", "video", "share", "copy", "rating", "web_sign_in", "document", "set_var", "choose");
  static final List<String> FIELD_KINDS = Arrays.asList("text", "secure", "new_secure", "url", "prose", "multiline", "choice", "rating", "code", "number");
  static final List<String> ROW_KINDS = Arrays.asList("screen", "action", "text");

  public static String actionKind(Object action) {
    String kind = string(Json.dict(action).get("kind"));
    return kind.isEmpty() ? "request" : kind;
  }

  /** An explicit kind, else the key the section is shaped by: fields, actions, rows, from, or a route. */
  public static String sectionKind(Object section) {
    Map<String, Object> spec = Json.dict(section);
    if (present(spec, "kind")) return string(spec.get("kind"));
    if (spec.get("fields") instanceof List) return "fields";
    if (spec.get("actions") instanceof List) return "actions";
    if (spec.get("rows") instanceof List) return "rows";
    if (present(spec, "from")) return "from";
    return "route";
  }

  public static String rowKind(Object row) {
    Map<String, Object> d = Json.dict(row);
    if (present(d, "kind")) return string(d.get("kind"));
    if (present(d, "action")) return "action";
    if (present(d, "screen")) return "screen";
    return "text";
  }

  private static boolean knownAction(Object action, int level) {
    if (!(action instanceof Map)) return false;
    if (!ACTION_KINDS.contains(actionKind(action))) return false;
    Map<String, Object> d = Json.dict(action);
    if (present(d, "then_action")) return knownAction(d.get("then_action"), level);
    return true;
  }

  /** Whether a renderer at `level` knows this screen, section, action, field or row. */
  public static boolean known(String category, Object element, int level) {
    Map<String, Object> d = Json.dict(element);
    switch (category) {
      case "screen": return screenTypes(level).contains(string(d.get("type")));
      case "section": return SECTION_KINDS.contains(sectionKind(d));
      case "action": return knownAction(element, level);
      case "field": return FIELD_KINDS.contains(string(d.get("kind")));
      case "row": {
        String kind = rowKind(d);
        if (!ROW_KINDS.contains(kind)) return false;
        if (kind.equals("action")) return knownAction(d.get("action"), level);
        return true;
      }
      default: return false;
    }
  }

  public static Map<String, Object> mapOf(Object... pairs) {
    Map<String, Object> m = new LinkedHashMap<>();
    for (int i = 0; i + 1 < pairs.length; i += 2) m.put((String) pairs[i], pairs[i + 1]);
    return m;
  }
}
