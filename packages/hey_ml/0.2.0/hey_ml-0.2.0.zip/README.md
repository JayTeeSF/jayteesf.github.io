# hey_ml

CPU-first machine learning and learned decision policies for Hey.

`hey_ml` is a normal third-party Hey package. It is designed for small, fast,
local models that can learn from engineering outcomes without an LLM, GPU, token
budget, or model server.

The first implementation focuses on online learning:

- numeric feature vectors;
- online linear reward prediction;
- deterministic contextual action ranking;
- a per-person ranker (`personal`) that orders and thins candidates from one
  person's own labelled examples;
- a non-contextual bandit baseline;
- immutable, serialization-friendly model state; and
- an optional actor-owned HTTP service.

The package deliberately starts with the cheapest model that can work. Small
neural networks belong here too, but they should earn their CPU and memory cost
against the linear/bandit baselines.

## Embedded example

```hey
import './policy.hey'

let policy = Policy.new(
  ['rerun_test', 'inspect_diff', 'run_type_checker'],
  4,
  0.05,
  0.0001,
  1.0
)

let features = [4.0, 2.0, 1.0, 0.0]
let decision = Policy.choose(policy, features)
let learned = Policy.learn_choice(policy, decision, features, 1.0)
```

The returned model is an ordinary immutable Hey value.

## Per-person ranking

`PersonalModel` (`pkg:hey_ml@0.2.0/personal`) is the generic half of a
recommender that learns each person's taste from their own answers: kept is
1.0, passed is 0.0. It is pure -- the caller stores the examples and any cached
model, and runs its hard rules (an avoid list, a service filter) first.

```hey
import 'pkg:hey_ml@0.2.0/personal'

let spec = PersonalModel.spec({feature_count: 49})
let trained = PersonalModel.train(spec, examples)        # [{features, reward}], oldest first
let ranked = PersonalModel.rank(spec, trained.model, candidates, {
  mode: PersonalModel.mode(setting),                     # off | shadow | rank; a typo is shadow
  warm: PersonalModel.warm?(spec, len(examples)),        # 20 answers before it changes anything
  floor: PersonalModel.floor(spec, floor_setting)        # 0.5 unless set; 'none' is no floor
})
# ranked.order: best first, ties in the given order, below the floor dropped
# ranked.held: how many the floor dropped
# ranked.fallback: '', or why the input came back untouched (mode, empty, cold, no_model, unscorable)
```

The examples are the authority and the model is a cache: `train` starts from
nothing every time, so undoing an answer is "drop the label, train again" and
gives back exactly the model from before. my_queue's Scout uses it; see
`examples/personal_ranker.hey`.

## Service mode

`PolicyService` owns a policy inside one actor and exposes:

- `POST /v1/choose`
- `POST /v1/observe`
- `GET /v1/snapshot`

The HTTP layer is only an adapter; the ML library remains fully embeddable.

See `docs/DESIGN.md`, `examples/compiler_policy.hey`, and
`examples/policy_service.hey`.
