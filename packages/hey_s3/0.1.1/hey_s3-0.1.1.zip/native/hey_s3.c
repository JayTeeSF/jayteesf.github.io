#define _POSIX_C_SOURCE 200809L
#define _DARWIN_C_SOURCE
#include "hey_s3.h"
#include <curl/curl.h>
#include <openssl/evp.h>
#include <openssl/crypto.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <inttypes.h>
#include <time.h>
typedef struct {CURL *curl;char *endpoint,*signing,*bucket,*access,*secret,*token;char etag[256],checksum[128],length[32];FILE *file;EVP_MD_CTX *digest;uint64_t bytes,limit;int method,local;time_t credentials_at;} Client;
static pthread_once_t init_once=PTHREAD_ONCE_INIT;
static void init_curl(void){(void)curl_global_init(CURL_GLOBAL_DEFAULT);}
static char *copy(HeyNativeUtf8View v,size_t max){if(v.length>max||memchr(v.data,0,v.length)||memchr(v.data,'\r',v.length)||memchr(v.data,'\n',v.length))return NULL;char *s=malloc(v.length+1);if(s){memcpy(s,v.data,v.length);s[v.length]=0;}return s;}
static void secret_free(char *s){if(s){OPENSSL_cleanse(s,strlen(s));free(s);}}
static int safe_name(const char *s){if(!*s)return 0;for(;*s;s++)if(!((*s>='a'&&*s<='z')||(*s>='0'&&*s<='9')||*s=='-'||*s=='.'))return 0;return 1;}
int32_t s3_close(HeyNativeHandle h){Client *c=(Client *)(uintptr_t)h;if(!c)return 1;if(c->curl)curl_easy_cleanup(c->curl);free(c->endpoint);free(c->bucket);free(c->signing);secret_free(c->access);secret_free(c->secret);secret_free(c->token);free(c);return 0;}
int32_t s3_credentials(HeyNativeHandle h,HeyNativeUtf8View a,HeyNativeUtf8View s,HeyNativeUtf8View t){Client *c=(Client *)(uintptr_t)h;if(!c)return 1;char *aa=copy(a,256),*ss=copy(s,512),*tt=copy(t,16384);if(!aa||!ss||!tt||!*aa||!*ss){secret_free(aa);secret_free(ss);secret_free(tt);return 1;}secret_free(c->access);secret_free(c->secret);secret_free(c->token);c->access=aa;c->secret=ss;c->token=tt;c->credentials_at=time(NULL);return 0;}
HeyNativeHandle s3_open(HeyNativeUtf8View ep,HeyNativeUtf8View region,HeyNativeUtf8View bucket,HeyNativeUtf8View access,HeyNativeUtf8View secret,HeyNativeUtf8View token,uint32_t local){
 pthread_once(&init_once,init_curl);Client *c=calloc(1,sizeof(*c));if(!c)return 0;
 c->endpoint=copy(ep,2048);c->bucket=copy(bucket,63);char *r=copy(region,64);c->local=local==1;
 if(!c->endpoint||!c->bucket||!r||!safe_name(c->bucket)||!safe_name(r))goto bad;
 if(c->local){if(strncmp(c->endpoint,"http://127.0.0.1:",17)!=0)goto bad;}else if(strncmp(c->endpoint,"https://",8)!=0)goto bad;
 CURLU *url=curl_url();char *host=NULL,*user=NULL,*query=NULL,*fragment=NULL;int valid=0;
 if(url&&curl_url_set(url,CURLUPART_URL,c->endpoint,0)==CURLUE_OK&&curl_url_get(url,CURLUPART_HOST,&host,0)==CURLUE_OK&&curl_url_get(url,CURLUPART_USER,&user,0)==CURLUE_NO_USER&&curl_url_get(url,CURLUPART_QUERY,&query,0)==CURLUE_NO_QUERY&&curl_url_get(url,CURLUPART_FRAGMENT,&fragment,0)==CURLUE_NO_FRAGMENT)valid=1;
 curl_free(host);curl_free(user);curl_free(query);curl_free(fragment);if(url)curl_url_cleanup(url);if(!valid)goto bad;
 c->signing=malloc(strlen(r)+16);if(!c->signing)goto bad;sprintf(c->signing,"aws:amz:%s:s3",r);free(r);r=NULL;
 c->curl=curl_easy_init();if(!c->curl||s3_credentials((HeyNativeHandle)(uintptr_t)c,access,secret,token))goto bad;
 return (HeyNativeHandle)(uintptr_t)c;
 bad:free(r);s3_close((HeyNativeHandle)(uintptr_t)c);return 0;
}
static size_t header(char *data,size_t size,size_t count,void *ctx){Client *c=ctx;size_t n=size*count;char *to=NULL;size_t cap=0,skip=0;
 if(n>=5&&!strncasecmp(data,"HTTP/",5)){c->etag[0]=c->checksum[0]=c->length[0]=0;return n;}
 if(n>5&&!strncasecmp(data,"etag:",5)){to=c->etag;cap=sizeof(c->etag);skip=5;}
 if(n>22&&!strncasecmp(data,"x-amz-checksum-sha256:",22)){to=c->checksum;cap=sizeof(c->checksum);skip=22;}
 if(n>15&&!strncasecmp(data,"content-length:",15)){to=c->length;cap=sizeof(c->length);skip=15;}
 if(to){while(skip<n&&(data[skip]==' '||data[skip]=='\t'))skip++;size_t end=n;while(end>skip&&(data[end-1]=='\r'||data[end-1]=='\n'||data[end-1]==' '))end--;if(end-skip>=cap)return 0;memcpy(to,data+skip,end-skip);to[end-skip]=0;}
 return n;
}
static size_t body(char *data,size_t size,size_t count,void *ctx){Client *c=ctx;size_t n=size*count;if(c->method!=1)return n;if((uint64_t)n>c->limit-c->bytes)return 0;if(fwrite(data,1,n,c->file)!=n||EVP_DigestUpdate(c->digest,data,n)!=1)return 0;c->bytes+=n;return n;}
static int hash_file(FILE *f,char hex[65],char b64[45]){unsigned char b[65536],d[32];unsigned int len=0;EVP_MD_CTX *md=EVP_MD_CTX_new();if(!md)return 0;int ok=EVP_DigestInit_ex(md,EVP_sha256(),NULL)==1;size_t n;while(ok&&(n=fread(b,1,sizeof(b),f))>0)ok=EVP_DigestUpdate(md,b,n)==1;if(ferror(f))ok=0;if(ok)ok=EVP_DigestFinal_ex(md,d,&len)==1&&len==32;EVP_MD_CTX_free(md);if(!ok||fseek(f,0,SEEK_SET))return 0;for(unsigned i=0;i<32;i++)sprintf(hex+i*2,"%02x",d[i]);EVP_EncodeBlock((unsigned char *)b64,d,32);return 1;}
static int add(struct curl_slist **list,const char *name,const char *value){size_t n=strlen(name)+strlen(value)+3;char *line=malloc(n);if(!line)return 0;snprintf(line,n,"%s: %s",name,value);struct curl_slist *next=curl_slist_append(*list,line);free(line);if(!next)return 0;*list=next;return 1;}
int32_t s3_request(HeyNativeHandle h,uint32_t method,HeyNativeUtf8View keyv,HeyNativeUtf8View pathv,HeyNativeUtf8View shav,HeyNativeUtf8View condv,uint64_t limit){
 Client *c=(Client *)(uintptr_t)h;if(!c||method>2||!limit||limit>UINT64_C(5368709120))return -1;
 char *key=copy(keyv,1024),*path=copy(pathv,4096),*sha=copy(shav,64),*cond=copy(condv,255);char *url=NULL,*escaped=NULL;struct curl_slist *headers=NULL;int result=-1,created=0;long status=0;char hex[65],b64[45];struct stat st;
 if(!key||!path||!sha||!cond||!*key||*key=='/'||strstr(key,"..")||strchr(key,'\\'))goto done;
 if(*sha){if(strlen(sha)!=64)goto done;for(size_t i=0;i<64;i++)if(!((sha[i]>='0'&&sha[i]<='9')||(sha[i]>='a'&&sha[i]<='f')))goto done;}
 c->method=(int)method;c->bytes=0;c->limit=limit;c->etag[0]=c->checksum[0]=c->length[0]=0;
 if(method==1){int fd=open(path,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW,0600);if(fd<0)goto done;created=1;c->file=fdopen(fd,"wb");if(!c->file){close(fd);unlink(path);goto done;}c->digest=EVP_MD_CTX_new();if(!c->digest||EVP_DigestInit_ex(c->digest,EVP_sha256(),NULL)!=1)goto done;}
 if(method==2){int fd=open(path,O_RDONLY|O_NOFOLLOW);if(fd<0)goto done;if(fstat(fd,&st)||!S_ISREG(st.st_mode)||st.st_size<0||(uint64_t)st.st_size>limit){close(fd);goto done;}c->file=fdopen(fd,"rb");if(!c->file){close(fd);goto done;}if(!hash_file(c->file,hex,b64)||strcmp(sha,hex))goto done;if(!add(&headers,"x-amz-content-sha256",hex)||!add(&headers,"x-amz-checksum-sha256",b64))goto done;}
 if(*c->token&&!add(&headers,"x-amz-security-token",c->token))goto done;
 if(method==0&&!add(&headers,"x-amz-checksum-mode","ENABLED"))goto done;
 if(*cond&&!add(&headers,strcmp(cond,"*")==0?"If-None-Match":"If-Match",cond))goto done;
 if(!add(&headers,"Expect", ""))goto done;
 escaped=curl_easy_escape(c->curl,key,0);if(!escaped)goto done;
 // Keep '/' as an S3 path separator, while all other unsafe bytes remain encoded.
 for(char *p=escaped;(p=strstr(p,"%2F"));){*p='/';memmove(p+1,p+3,strlen(p+3)+1);p++;}
 size_t urln=strlen(c->endpoint)+strlen(c->bucket)+strlen(escaped)+3;url=malloc(urln);if(!url)goto done;snprintf(url,urln,"%s/%s/%s",c->endpoint,c->bucket,escaped);
 curl_easy_reset(c->curl);
 #define OPT(k,v) do{if(curl_easy_setopt(c->curl,k,v)!=CURLE_OK)goto done;}while(0)
 OPT(CURLOPT_URL,url);OPT(CURLOPT_PATH_AS_IS,1L);OPT(CURLOPT_AWS_SIGV4,c->signing);OPT(CURLOPT_USERNAME,c->access);OPT(CURLOPT_PASSWORD,c->secret);OPT(CURLOPT_HTTPHEADER,headers);OPT(CURLOPT_HEADERFUNCTION,header);OPT(CURLOPT_HEADERDATA,c);OPT(CURLOPT_WRITEFUNCTION,body);OPT(CURLOPT_WRITEDATA,c);OPT(CURLOPT_NOSIGNAL,1L);OPT(CURLOPT_CONNECTTIMEOUT,10L);OPT(CURLOPT_TIMEOUT,300L);OPT(CURLOPT_LOW_SPEED_LIMIT,1024L);OPT(CURLOPT_LOW_SPEED_TIME,30L);OPT(CURLOPT_FOLLOWLOCATION,0L);OPT(CURLOPT_SSL_VERIFYPEER,1L);OPT(CURLOPT_SSL_VERIFYHOST,2L);OPT(CURLOPT_PROTOCOLS_STR,c->local?"http":"https");
 if(c->local){OPT(CURLOPT_PROXY,"");}
 if(method==0){OPT(CURLOPT_NOBODY,1L);}else if(method==2){OPT(CURLOPT_UPLOAD,1L);OPT(CURLOPT_READDATA,c->file);OPT(CURLOPT_INFILESIZE_LARGE,(curl_off_t)st.st_size);}
 CURLcode code=curl_easy_perform(c->curl);curl_easy_getinfo(c->curl,CURLINFO_RESPONSE_CODE,&status);
 if(code!=CURLE_OK){result=-2;goto done;}result=(int)status;
 if(method==1&&status==200){unsigned char d[32];unsigned int len=0;if(EVP_DigestFinal_ex(c->digest,d,&len)!=1||len!=32){result=-3;goto done;}for(unsigned i=0;i<32;i++)sprintf(hex+i*2,"%02x",d[i]);if(*sha&&strcmp(hex,sha)){result=-3;goto done;}if(fflush(c->file)||fsync(fileno(c->file))){result=-4;goto done;}}
 if(method==2&&status==200&&strcmp(c->checksum,b64)){result=-3;}
 done:
 if(c&&c->file){if(fclose(c->file)!=0&&result==200)result=-4;c->file=NULL;}
 if(c&&c->digest){EVP_MD_CTX_free(c->digest);c->digest=NULL;}
 if(method==1&&created&&result!=200&&path)unlink(path);
 free(key);free(path);free(sha);free(cond);free(url);curl_free(escaped);curl_slist_free_all(headers);return result;
}
static void release(void *ctx,uint8_t *data,size_t length){(void)ctx;(void)length;free(data);}
HeyNativeOwnedBytes s3_header(HeyNativeHandle h,HeyNativeUtf8View name){Client *c=(Client *)(uintptr_t)h;char *n=copy(name,32);const char *v="";if(c&&n){if(!strcmp(n,"etag"))v=c->etag;else if(!strcmp(n,"checksum"))v=c->checksum;else if(!strcmp(n,"length"))v=c->length;}free(n);size_t len=strlen(v);uint8_t *data=malloc(len?len:1);if(!data)return (HeyNativeOwnedBytes){0};memcpy(data,v,len);return (HeyNativeOwnedBytes){data,len,release,NULL};}

uint64_t s3_credential_age(HeyNativeHandle h){Client *c=(Client *)(uintptr_t)h;time_t now=time(NULL);return c&&now>=c->credentials_at ? (uint64_t)(now-c->credentials_at) : UINT64_MAX;}
