# In progress

- Verify one complete mixed-device room using package-locked dependencies.
