#!/usr/bin/env bash
set -euo pipefail

ANDROID_API="${HEY_ANDROID_API:-34}"
ANDROID_BUILD_TOOLS="${HEY_ANDROID_BUILD_TOOLS:-34.0.0}"
ANDROID_NDK_VERSION="${HEY_ANDROID_NDK_VERSION:-26.1.10909125}"
ANDROID_CMAKE_VERSION="${HEY_ANDROID_CMAKE_VERSION:-3.22.1}"
GRADLE_VERSION="${HEY_ANDROID_GRADLE_VERSION:-8.7}"
ANDROID_AVD_NAME="${HEY_ANDROID_AVD_NAME:-Hey_API_34}"
ENV_FILE="${HEY_ANDROID_ENV_FILE:-$HOME/.config/hey/android.env}"
GRADLE_HOME="$HOME/.cache/hey/gradle-$GRADLE_VERSION"

fail() { printf 'error: %s\n' "$*" >&2; exit 1; }
step() { printf '\n== %s ==\n' "$*"; }

[ "$(uname -s)" = Darwin ] || fail "this installer currently supports macOS"
command -v brew >/dev/null 2>&1 || fail "Homebrew is required: https://brew.sh"
command -v ditto >/dev/null 2>&1 || fail "macOS ditto is required"

if [ -n "${ANDROID_HOME:-}" ] && [ -n "${ANDROID_SDK_ROOT:-}" ] && [ "$ANDROID_HOME" != "$ANDROID_SDK_ROOT" ]; then
  fail "ANDROID_HOME and ANDROID_SDK_ROOT disagree: $ANDROID_HOME != $ANDROID_SDK_ROOT"
fi

# ANDROID_HOME is the current SDK-location variable. Keep ANDROID_SDK_ROOT equal
# for older Android tooling that still checks it.
ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"
ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_HOME ANDROID_SDK_ROOT

step "Install Android Studio, JDK 17, and Android command-line tools"
brew list --cask android-studio >/dev/null 2>&1 || brew install --cask android-studio
brew list --cask temurin@17 >/dev/null 2>&1 || brew install --cask temurin@17
brew list --cask android-commandlinetools >/dev/null 2>&1 || brew install --cask android-commandlinetools

JAVA_HOME="$(/usr/libexec/java_home -v 17 2>/dev/null || true)"
[ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/java" ] || fail "JDK 17 was not found after installation"
export JAVA_HOME

# Homebrew installs avdmanager beneath its own SDK root. avdmanager derives the
# package repository from the SDK containing the executable, so merely exporting
# ANDROID_HOME is not enough. Copy the command-line tools into the canonical SDK
# and invoke only the SDK-local binaries from this point forward.
BREW_PREFIX="$(brew --prefix)"
BREW_CMDLINE_TOOLS="$BREW_PREFIX/share/android-commandlinetools/cmdline-tools/latest"
SDK_CMDLINE_TOOLS="$ANDROID_HOME/cmdline-tools/latest"

[ -x "$BREW_CMDLINE_TOOLS/bin/sdkmanager" ] \
  || fail "Homebrew sdkmanager was not found: $BREW_CMDLINE_TOOLS/bin/sdkmanager"
[ -x "$BREW_CMDLINE_TOOLS/bin/avdmanager" ] \
  || fail "Homebrew avdmanager was not found: $BREW_CMDLINE_TOOLS/bin/avdmanager"

mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -x "$SDK_CMDLINE_TOOLS/bin/sdkmanager" ] \
  || [ ! -x "$SDK_CMDLINE_TOOLS/bin/avdmanager" ] \
  || ! cmp -s "$BREW_CMDLINE_TOOLS/source.properties" "$SDK_CMDLINE_TOOLS/source.properties"; then
  step "Install command-line tools inside the selected Android SDK"
  cmdline_stage="$ANDROID_HOME/cmdline-tools/.latest.$$"
  rm -rf "$cmdline_stage"
  mkdir -p "$cmdline_stage"
  ditto "$BREW_CMDLINE_TOOLS" "$cmdline_stage"
  rm -rf "$SDK_CMDLINE_TOOLS"
  mv "$cmdline_stage" "$SDK_CMDLINE_TOOLS"
fi

SDKMANAGER="$SDK_CMDLINE_TOOLS/bin/sdkmanager"
AVDMANAGER="$SDK_CMDLINE_TOOLS/bin/avdmanager"
ANDROID_CMDLINE_TOOLS_BIN="$SDK_CMDLINE_TOOLS/bin"

[ -x "$SDKMANAGER" ] || fail "SDK-local sdkmanager is missing: $SDKMANAGER"
[ -x "$AVDMANAGER" ] || fail "SDK-local avdmanager is missing: $AVDMANAGER"

case "$(uname -m)" in
  arm64) SYSTEM_IMAGE_ABI=arm64-v8a ;;
  x86_64) SYSTEM_IMAGE_ABI=x86_64 ;;
  *) fail "unsupported Mac architecture: $(uname -m)" ;;
esac

SYSTEM_IMAGE="system-images;android-$ANDROID_API;google_apis;$SYSTEM_IMAGE_ABI"
SYSTEM_IMAGE_DIR="$ANDROID_HOME/system-images/android-$ANDROID_API/google_apis/$SYSTEM_IMAGE_ABI"

step "Accept Android SDK licenses"
yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null || true

step "Install the pinned Android SDK, NDK, CMake, emulator, and system image"
"$SDKMANAGER" --sdk_root="$ANDROID_HOME" \
  "platform-tools" \
  "platforms;android-$ANDROID_API" \
  "build-tools;$ANDROID_BUILD_TOOLS" \
  "emulator" \
  "ndk;$ANDROID_NDK_VERSION" \
  "cmake;$ANDROID_CMAKE_VERSION" \
  "$SYSTEM_IMAGE"

yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null || true

if [ ! -d "$SYSTEM_IMAGE_DIR" ]; then
  printf '\nInstalled SDK packages matching system-images:\n' >&2
  "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --list_installed 2>/dev/null \
    | grep 'system-images;' >&2 || true
  fail "system image was not installed under the selected SDK root: $SYSTEM_IMAGE_DIR"
fi

if ! "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --list_installed 2>/dev/null \
  | grep -F "$SYSTEM_IMAGE" >/dev/null; then
  fail "SDK-local sdkmanager cannot see the installed system image: $SYSTEM_IMAGE"
fi

step "Install the pinned Gradle runner"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  tmp_dir="$(mktemp -d)"
  cleanup() { rm -rf "$tmp_dir"; }
  trap cleanup EXIT HUP INT TERM
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$tmp_dir/gradle.zip"
  unzip -q "$tmp_dir/gradle.zip" -d "$tmp_dir"
  mkdir -p "$(dirname "$GRADLE_HOME")"
  rm -rf "$GRADLE_HOME"
  mv "$tmp_dir/gradle-$GRADLE_VERSION" "$GRADLE_HOME"
  trap - EXIT HUP INT TERM
  cleanup
fi

step "Create the Android virtual device"
EMULATOR="$ANDROID_HOME/emulator/emulator"
if [ ! -x "$EMULATOR" ]; then
  fail "Android emulator missing after installation: $EMULATOR"
fi

if ! "$EMULATOR" -list-avds | grep -Fx "$ANDROID_AVD_NAME" >/dev/null 2>&1; then
  if ! printf 'no\n' | "$AVDMANAGER" create avd \
    --force \
    --name "$ANDROID_AVD_NAME" \
    --package "$SYSTEM_IMAGE"; then
    printf '\nAVD creation diagnostics:\n' >&2
    printf 'ANDROID_HOME=%s\n' "$ANDROID_HOME" >&2
    printf 'sdkmanager=%s\n' "$SDKMANAGER" >&2
    printf 'avdmanager=%s\n' "$AVDMANAGER" >&2
    printf 'system_image=%s\n' "$SYSTEM_IMAGE" >&2
    printf 'system_image_dir=%s\n' "$SYSTEM_IMAGE_DIR" >&2
    "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --list_installed 2>/dev/null \
      | grep -F "$SYSTEM_IMAGE" >&2 || true
    fail "SDK-local avdmanager could not create $ANDROID_AVD_NAME"
  fi
fi

"$EMULATOR" -list-avds | grep -Fx "$ANDROID_AVD_NAME" >/dev/null \
  || fail "AVD was not visible after creation: $ANDROID_AVD_NAME"

step "Write reusable Hey Android environment"
mkdir -p "$(dirname "$ENV_FILE")"
cat > "$ENV_FILE" <<EOF_ENV
export ANDROID_HOME="$ANDROID_HOME"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/$ANDROID_NDK_VERSION"
export JAVA_HOME="$JAVA_HOME"
export HEY_ANDROID_API="$ANDROID_API"
export HEY_ANDROID_BUILD_TOOLS="$ANDROID_BUILD_TOOLS"
export HEY_ANDROID_NDK_VERSION="$ANDROID_NDK_VERSION"
export HEY_ANDROID_CMAKE_VERSION="$ANDROID_CMAKE_VERSION"
export HEY_ANDROID_GRADLE_VERSION="$GRADLE_VERSION"
export HEY_ANDROID_AVD_NAME="$ANDROID_AVD_NAME"
export PATH="$GRADLE_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/emulator:$ANDROID_CMDLINE_TOOLS_BIN:\$PATH"
EOF_ENV
chmod 600 "$ENV_FILE"

printf '\nAndroid toolchain installed.\n'
printf 'sdk_root=%s\n' "$ANDROID_HOME"
printf 'sdkmanager=%s\n' "$SDKMANAGER"
printf 'avdmanager=%s\n' "$AVDMANAGER"
printf 'system_image=%s\n' "$SYSTEM_IMAGE"
printf 'environment=%s\n' "$ENV_FILE"
printf 'avd=%s\n' "$ANDROID_AVD_NAME"
printf 'next: ./02-build-and-launch-hey-android.sh\n'
