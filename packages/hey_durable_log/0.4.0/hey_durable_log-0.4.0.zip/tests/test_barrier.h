#ifndef HDL_TEST_BARRIER_H
#define HDL_TEST_BARRIER_H

/* Reusable thread barrier for the concurrency gates.
 *
 * pthread_barrier_t is an OPTIONAL POSIX feature. glibc has it; Darwin does
 * not, so the broker group-commit gate -- the one that proves fewer durable
 * batches than records -- failed to COMPILE on macOS and therefore never ran
 * there at all. A gate that cannot build on a developer's host is not a gate.
 *
 * Where the platform provides barriers this is a direct alias. Where it does
 * not, the mutex/condition-variable fallback below has the same contract that
 * the gate depends on: it is CYCLING, because the writers wait on it once per
 * operation, not once per run.
 */

#include <pthread.h>
#include <unistd.h>

#if defined(_POSIX_BARRIERS) && _POSIX_BARRIERS > 0

typedef pthread_barrier_t hdl_test_barrier;

static inline int hdl_test_barrier_init(hdl_test_barrier *barrier, unsigned count) {
  return pthread_barrier_init(barrier, NULL, count);
}

static inline int hdl_test_barrier_wait(hdl_test_barrier *barrier) {
  int result = pthread_barrier_wait(barrier);
  return result == PTHREAD_BARRIER_SERIAL_THREAD ? 0 : result;
}

static inline int hdl_test_barrier_destroy(hdl_test_barrier *barrier) {
  return pthread_barrier_destroy(barrier);
}

#else

typedef struct {
  pthread_mutex_t mutex;
  pthread_cond_t cond;
  unsigned count;
  unsigned waiting;
  unsigned generation;
} hdl_test_barrier;

static inline int hdl_test_barrier_init(hdl_test_barrier *barrier, unsigned count) {
  if (count == 0) return -1;
  int status = pthread_mutex_init(&barrier->mutex, NULL);
  if (status != 0) return status;
  status = pthread_cond_init(&barrier->cond, NULL);
  if (status != 0) {
    pthread_mutex_destroy(&barrier->mutex);
    return status;
  }
  barrier->count = count;
  barrier->waiting = 0;
  barrier->generation = 0;
  return 0;
}

static inline int hdl_test_barrier_wait(hdl_test_barrier *barrier) {
  int status = pthread_mutex_lock(&barrier->mutex);
  if (status != 0) return status;
  unsigned generation = barrier->generation;
  barrier->waiting++;
  if (barrier->waiting == barrier->count) {
    /* Release the cycle and immediately arm the next one, so a fast thread
     * re-entering the barrier cannot be counted into the cycle it just left. */
    barrier->waiting = 0;
    barrier->generation++;
    status = pthread_cond_broadcast(&barrier->cond);
  } else {
    while (generation == barrier->generation) {
      status = pthread_cond_wait(&barrier->cond, &barrier->mutex);
      if (status != 0) break;
    }
  }
  int unlocked = pthread_mutex_unlock(&barrier->mutex);
  return status != 0 ? status : unlocked;
}

static inline int hdl_test_barrier_destroy(hdl_test_barrier *barrier) {
  int cond_status = pthread_cond_destroy(&barrier->cond);
  int mutex_status = pthread_mutex_destroy(&barrier->mutex);
  return cond_status != 0 ? cond_status : mutex_status;
}

#endif

#endif
