#import "HeyIOSKeychain.h"
#import <Security/Security.h>

static NSMutableDictionary *HeyIOSKeychainQuery(NSString *service, NSString *account) {
  return [@{
    (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
    (__bridge id)kSecAttrService: service,
    (__bridge id)kSecAttrAccount: account
  } mutableCopy];
}

NSString *HeyIOSKeychainRead(NSString *service, NSString *account) {
  NSMutableDictionary *query = HeyIOSKeychainQuery(service, account);
  query[(__bridge id)kSecReturnData] = @YES;
  query[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitOne;
  CFTypeRef found = NULL;
  OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &found);
  if (status != errSecSuccess || found == NULL) return nil;
  NSData *data = (__bridge_transfer NSData *)found;
  NSString *value = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
  return value.length > 0 ? value : nil;
}

BOOL HeyIOSKeychainWrite(NSString *service, NSString *account, NSString *value) {
  NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
  if (data == nil) return NO;
  NSMutableDictionary *query = HeyIOSKeychainQuery(service, account);
  NSDictionary *update = @{
    (__bridge id)kSecValueData: data,
    (__bridge id)kSecAttrAccessible: (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
  };
  OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)query, (__bridge CFDictionaryRef)update);
  if (status == errSecItemNotFound) {
    [query addEntriesFromDictionary:update];
    status = SecItemAdd((__bridge CFDictionaryRef)query, NULL);
  }
  return status == errSecSuccess;
}

BOOL HeyIOSKeychainDelete(NSString *service, NSString *account) {
  OSStatus status = SecItemDelete((__bridge CFDictionaryRef)HeyIOSKeychainQuery(service, account));
  return status == errSecSuccess || status == errSecItemNotFound;
}
