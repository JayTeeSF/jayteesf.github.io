require 'json'
require_relative 'fixture_http'
port, log = ARGV
nodes = [
  {path:'work',parent:'',label:'work',slug:'work-slug',selectable:true},
  {path:'work/science',parent:'work',label:'science',slug:'science-slug',selectable:true},
  {path:'private',parent:'',label:'private',slug:'private-slug',selectable:false},
  {path:'private/visible',parent:'private',label:'visible',slug:'visible-slug',selectable:true}
]
lock = Mutex.new
requests=0
defaults=0
retries=Hash.new(0)
reply = lambda do |r, status, value|
  body=JSON.generate(value)
  r.respond(status,body,[['Content-Type','application/json'],['Content-Length',body.bytesize.to_s],['Connection','close']])
end
FixtureHttp.serve(Integer(port), 'choice fixture ready', lambda do |r|
  # The spec's reachability probe from the emulator; not part of the fixture's log.
  if r.path == '/ready'
    r.respond(200,'ready',[['Content-Type','text/plain'],['Content-Length','5'],['Connection','close']])
    next
  end
  lock.synchronize { File.open(log,'a'){|f|f.puts JSON.generate(method:r.method,path:r.path,authorization:r.header('authorization'),body:r.body)} }
  # The form reads its choices at launch, before the fixture has an account.
  if r.path.start_with?('/choices') && r.header('authorization').nil?
    reply.(r, 401, {error:'Synthetic sign-in required'})
    next
  end
  if r.path == '/choices'
    # The first signed-in read is the form's own; later ones are pickers. From
    # the fourth on they are slow, so a static choice can be picked while loading.
    count = lock.synchronize { requests += 1 }
    sleep 0.9 if count >= 4
  end
  # A picker's retries, counted per path so each run names a fresh one: the
  # first read fails, the second fails late (a double-tapped Retry's second
  # read would answer first and draw the tree), the third succeeds.
  if r.path.start_with?('/choices-retry/')
    count = lock.synchronize { retries[r.path] += 1 }
    if count <= 2
      sleep 0.6 if count == 2
      reply.(r, 500, {error:'Synthetic retry'})
      next
    end
  end
  # Answered after the page has left: every label differs, so a reply that
  # slipped past the renderer's guard would show.
  sleep 0.9 if r.path == '/choices-late'
  if r.path == '/defaults-fail'
    reply.(r, 500, {error:'Synthetic source retry'})
    next
  end
  if r.path == '/defaults'
    lock.synchronize { defaults += 1 }
    sleep 0.8
  end
  late = nodes.map { |n| n.merge(label: "#{n[:label]} (late)") }
  value = if r.path == '/choices' || r.path.start_with?('/choices-retry/') then {nodes:nodes}
          elsif r.path == '/choices-late' then {nodes:late}
          else {request_key:"synthetic-request-#{defaults}",default_folder:'science-slug'} end
  reply.(r, 200, value)
end)
