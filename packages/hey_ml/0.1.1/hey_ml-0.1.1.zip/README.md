# hey_ml

CPU-first machine learning and learned decision policies for Hey.

`hey_ml` is a normal third-party Hey package. It is designed for small, fast,
local models that can learn from engineering outcomes without an LLM, GPU, token
budget, or model server.

The first implementation focuses on online learning:

- numeric feature vectors;
- online linear reward prediction;
- deterministic contextual action ranking;
- a non-contextual bandit baseline;
- immutable, serialization-friendly model state; and
- an optional actor-owned HTTP service.

The package deliberately starts with the cheapest model that can work. Small
neural networks belong here too, but they should earn their CPU and memory cost
against the linear/bandit baselines.

## Embedded example

```hey
import './policy.hey'

let policy = Policy.new(
  ['rerun_test', 'inspect_diff', 'run_type_checker'],
  4,
  0.05,
  0.0001,
  1.0
)

let features = [4.0, 2.0, 1.0, 0.0]
let decision = Policy.choose(policy, features)
let learned = Policy.learn_choice(policy, decision, features, 1.0)
```

The returned model is an ordinary immutable Hey value.

## Service mode

`PolicyService` owns a policy inside one actor and exposes:

- `POST /v1/choose`
- `POST /v1/observe`
- `GET /v1/snapshot`

The HTTP layer is only an adapter; the ML library remains fully embeddable.

See `docs/DESIGN.md`, `examples/compiler_policy.hey`, and
`examples/policy_service.hey`.
