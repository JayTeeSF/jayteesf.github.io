# hey_jose Builder Start Here

## Goal

Turn this repository into the verified immutable `hey_jose` package described by `PACKAGE_SPEC.md` using the current Hey toolchain and canonical `hey_packager` workflow.

## Non-negotiable package rule

Every package created for MMeoww must depend on `hey_packager` and use it for standard package structure/check/release/publish/source-handoff behavior. Do not copy packaging policy into this repository and allow it to drift.

At the time this handoff was written the accessible canonical `hey_packager` manifest is version `0.1.6`. When the package is initialized, declare an **exact immutable `hey_packager` dependency** to the current approved release; do not use a moving branch or `latest`.

## First implementation actions

1. Use the exact Hey checkout/toolchain intended for release.
2. Run the current `hey package init hey_jose --path <this-repo>` workflow, or generate the scaffold in a temporary directory and merge it if the command refuses a non-empty repository. Preserve `README.md`, `PACKAGE_SPEC.md`, this handoff, and Git history.
3. Generate native package metadata/build wrappers with the current Hey native-package generator. Do **not** author `hey.native.json` from an old example.
4. Make the package manifest depend exactly on the approved immutable `hey_packager` release.
5. Use standard package surfaces expected by `hey_packager`: package-specific `bin/package-check`, shared `bin/check`, `bin/release`, `bin/publish`, `bin/source-zip`, `bin/bump`, required docs, and at least one executable docs example.
6. Implement `Jose.JWT`, `Jose.JWKS`, and `Jose.OIDC` exactly to `PACKAGE_SPEC.md`. Use vetted native cryptography; do not implement cryptographic primitives in ordinary Hey.
7. Add known-good algorithm vectors plus malformed/adversarial/rotation/cache/oversize/fuzz coverage. Fail closed.
8. Run package-specific checks, `hey_packager check`, target builds, sanitizer/resource tests and the full security test set.
9. Bump through the canonical packager workflow and publish an immutable release through `hey_packager`; record archive/release/manifest/content hashes.

## MMeoww gate

MMeoww must consume only the verified immutable registry release. The Hey API must trust Auth0/OIDC claims only after successful `hey_jose` verification. After release, add the exact version to MMeoww `hey-package.json` and regenerate/commit `hey.lock.json` with Hey tooling.

## Stop conditions

Do not claim completion without generated native metadata, successful target builds, complete security tests, fuzz/malformed-input coverage, required docs, immutable release metadata/hashes, and exact registry version.
