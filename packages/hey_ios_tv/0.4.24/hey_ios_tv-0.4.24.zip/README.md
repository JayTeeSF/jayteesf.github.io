# hey_ios_tv

Native Apple TV/tvOS adapter for target-neutral Hey television applications.

This is an independently versioned third-party Hey package. It is not part
of Hey core or the standard library.

## Built against hey_ios 0.4.2 (0.4.24)

The lock named hey_ios 0.4.0, which had neither the now playing bar's
running time and skip controls (released as 0.3.4/0.3.5 from a branch
main never took) nor a resolution of the two lines. hey_ios 0.4.2 is the
first release with both, and hey_mobile 0.3.3 comes with it: its
`routes()` now lists the action on a data-driven row template, so a host
asking which addresses an app reaches gets a true answer.

## hey_ios 0.4.0 (0.4.23)

Takes `hey_ios` 0.3.x or 0.4.x. Nothing tvOS draws depends on what 0.4.0 changed (the phone renderer's level 3, its audio player, its App Store and universal-link signing).

## Package boundary

See `docs/DESIGN.md`. The package consumes current published dependencies
from `https://www.jayteesf.com/packages/` and delegates release/source ZIP/
publication controls to `hey_packager`.

## What 0.4.18 adds to the tool

```sh
hey ios-tv-app --out build/tvos --source app.hey --icon icons \
  --query-schemes youtube,music        # the apps the app may ask canOpenURL about
HEY_IOS_TV_SHORT_VERSION=1.2 HEY_IOS_TV_BUILD=202609131200 hey ios-tv-app ... --device --distribution
```

- `--query-schemes LIST` (or `HEY_IOS_TV_QUERY_SCHEMES`) writes `LSApplicationQueriesSchemes`. The renderer reports the installed ones in `X-Hey-TV-Apps` on every poll. Which services exist is the app's knowledge, so there is no default list.
- `HEY_IOS_TV_SHORT_VERSION` / `HEY_IOS_TV_BUILD` set the bundle version; App Store Connect refuses a reused build number.
- A distribution pack that must not carry a device id bakes `__HEY_TV_DEVICE__` where the id goes; the renderer mints one per installation.
- `HEY_IOS_ROOT` defaults to the `hey_ios` installed beside this package, then `~/dev/hey_ios`.

The scene fields (`grid`, `chips`, `rail`, `open_url`, `audio`, the keyboard, `forget_device`, ...) are in `docs/SCENE_CONTRACT.md`; `done.md` says why each exists.

## App icon and top shelf (`--icon`, 0.4.12)

Without `--icon` the app carries the **default blank tvOS tile**, and an App
Store build is rejected outright. Before 0.4.12 there was no way to give it one
short of hand-editing the bundle: the packager wrote an `Info.plist` with no
icon keys and shipped no asset catalog.

```sh
hey ios-tv-app --out build/tvos --source app.hey --icon path/to/icons
```

`--icon` takes a DIRECTORY holding these eleven files, all required:

| file | size | what it is |
|---|---|---|
| `appicon-1x-{back,middle,front}.png` | 400x240 | app icon layers, @1x |
| `appicon-2x-{back,middle,front}.png` | 800x480 | app icon layers, @2x |
| `appstore-{back,middle,front}.png` | 1280x768 | App Store icon layers |
| `topshelf.png` | 1920x720 | top shelf, flat (not layered) |
| `topshelf-wide.png` | 2320x720 | top shelf wide, flat |

**The three layers are what parallax IS.** tvOS slides them against each other
as the icon takes focus, so they are real, separate images: background, middle,
foreground. Front is listed first in the image stack -- topmost to backmost --
and inverting that order silently inverts the effect.

**The back layer must be a full rectangle with SQUARE corners.** tvOS applies
its own rounded mask; baking corners in gets a double-rounded icon.

**`topshelf-wide.png` is a different CROP, not a stretch.** It is wider at the
same height, so it wants re-rendering (or re-cropping) from the source art
rather than resampling the 1920 one.

### Why this is not a `cp`

tvOS will not take loose PNGs. The icon has to be a compiled asset catalog: a
brand-assets group whose app icon is an *image stack* of layers. This packager
generates that catalog, compiles it with `actool`, and merges the partial
`Info.plist` actool emits (`CFBundleIcons`, `TVTopShelfImage`) into the bundle
plist -- the key names are actool contract, not ours, and they have moved
between Xcode versions.

The static **top shelf images ride along for free**, since they live in the same
brand-assets group. A top shelf that plays **video** is a different feature: it
needs a Top Shelf *extension* target supplying `TVTopShelfCarouselItem`s with a
`previewVideoURL`, and this packager cannot express a second bundle yet.

### The trap, if you ever touch the actool call

`--target-device tv` is **not optional and fails silently**. Without it actool
filters every asset out as applying to no requested device, exits 0, writes an
empty partial plist and no `Assets.car`. It is indistinguishable from a
successful run that had nothing to do.

## Development

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
```

## Release and publish

```sh
bin/release
bin/source-zip
bin/publish --no-commit
```

Existing immutable versions must never be replaced.

## Build and release tooling

`hey_packager` is declared in `dependencies` as `">=0.1.1 <0.2.0"`, so it appears
in an application's lock; no module imports it. It provides `bin/check`,
`bin/bump`, `bin/release` (builds the release, does not publish) and
`bin/publish` (commits `packages/NAME/VERSION` to
`~/dev/jayteesf.github.io/packages`; never overwrites, never pushes).
`bin/package-zip` and `bin/source-zip` also run through it.
