// HeyIOSKeychain: one generic-password item per (service, account).
//
// Stored kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly: readable while the
// phone is locked in a pocket (a CarPlay session starts that way), never
// restored to another device from a backup. No SecItem reference escapes.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

NSString *_Nullable HeyIOSKeychainRead(NSString *service, NSString *account);
BOOL HeyIOSKeychainWrite(NSString *service, NSString *account, NSString *value);
BOOL HeyIOSKeychainDelete(NSString *service, NSString *account);

NS_ASSUME_NONNULL_END
