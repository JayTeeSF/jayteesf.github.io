# Continue hey_durable_log

Read `README.md`, `docs/DESIGN.md`, `docs/FORMAT.md`, `docs/ROADMAP.md`,
`docs/TESTING.md`, the manifests, the implementation files, and the specs before
editing. The active branch is `main_v2`; `main` is the landing branch only.

This is the crash-safe mutation journal for the cagents v2 server. Hey owns the
generic FFI, native loader and package plumbing; this package owns the journal
format, its durability behaviour, and its releases.

Every change starts with a test that fails for the stated reason, observed
failing before the implementation exists. Never weaken a gate to make it pass —
in particular `bin/check-hey`'s interpreter and stage0-compiled receipts.

Non-negotiable invariants: never acknowledge RAM alone; never skip a complete
corrupt frame; truncate only a partial or uncommitted tail; preserve ambiguous
post-COMMIT responses through application idempotency; keep queues bounded; never
make SQLite or Git the hidden acknowledgement boundary.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

Published versions are immutable. Change the package version whenever released
bytes change.

## Files the next LLM needs

For focused work, upload:

1. the latest full Hey source ZIP (the current `hey-lang-bootstrap-plan` source
   ZIP or newer);
2. this package's latest source/release ZIP (`hey_durable_log-0.2.0.zip`).
