#!/usr/bin/env bash
# The vendored SHA-256 (native/vendor/sha256) against the NIST vectors in
# specs/sha256_vectors.txt, on the host. The same vectors run through the Hey
# runtime on the emulator in specs/android_emulator_spec.sh.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-sha256.XXXXXX")
trap 'rm -rf "$work"' EXIT

env -u CPATH -u C_INCLUDE_PATH -u LIBRARY_PATH -u CPPFLAGS -u CFLAGS -u LDFLAGS \
  /usr/bin/cc -std=c11 -O2 -w -I"$ROOT/native/vendor/sha256" \
  "$ROOT/native/vendor/sha256/sha256.c" "$ROOT/specs/support/sha256_stdin.c" -o "$work/sha256_stdin" ||
  { echo 'FAIL: the vendored SHA-256 does not build on the host'; exit 1; }

vector_input() {
  case "$1" in
    empty) printf '' ;;
    abc) printf 'abc' ;;
    nist448) printf '%s' 'abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq' ;;
    nist896) printf '%s' 'abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu' ;;
    million_a) head -c 1000000 /dev/zero | tr '\0' a ;;
    *) return 1 ;;
  esac
}

compare() { # VECTORS_FILE HASHER...
  vectors=$1
  shift
  count=0
  bad=0
  while read -r name digest; do
    case "$name" in ''|\#*) continue ;; esac
    count=$((count + 1))
    got=$(vector_input "$name" | "$@" | cut -c1-64)
    if [ "$got" != "$digest" ]; then
      echo "  $name: got $got, want $digest"
      bad=$((bad + 1))
    fi
  done < "$vectors"
  [ "$count" -gt 0 ] && [ "$bad" = 0 ]
}

vectors=$ROOT/specs/sha256_vectors.txt
total=$(grep -cvE '^(#|$)' "$vectors")
if compare "$vectors" "$work/sha256_stdin"; then
  echo "PASS: the vendored SHA-256 matches all $total NIST vectors on the host"
else
  echo 'FAIL: the vendored SHA-256 does not match the NIST vectors'
  failed=1
fi

if compare "$vectors" shasum -a 256; then
  echo "PASS: the host's own shasum agrees with specs/sha256_vectors.txt ($total vectors)"
else
  echo 'FAIL: specs/sha256_vectors.txt disagrees with shasum -a 256'
  failed=1
fi

sed 's/^abc ba7816bf/abc ba7816bE/' "$vectors" > "$work/wrong.txt"
if compare "$work/wrong.txt" "$work/sha256_stdin" > "$work/control.txt"; then
  echo 'FAIL (control): a wrong digest was accepted'
  failed=1
else
  echo "PASS (control): a wrong digest fails ($(sed -n 1p "$work/control.txt" | sed 's/^ *//'))"
fi
exit $failed
