# hey_carplay

The CarPlay audio scene for Hey iOS apps built on `hey_ios`'s api_screens host. When a car connects it lists what the phone's Listen tab lists, plays a chosen row through `hey_ios`'s audio module and shows Now Playing. It decides nothing about what may play: the app's server filters the feed, and a row survives only if it has something the audio module can play.

This is an independently versioned third-party Hey package, extracted from `hey_ios` at 0.2.0 so that an app without a car screen carries no CarPlay code and the scene can be released on its own.

## hey_ios 0.4.0 (0.1.4)

Takes `hey_ios` 0.3.x or 0.4.x. The scene plays rows through `HeyIOSAudio playRow`; since `hey_ios` 0.4.0 an audio fetch carries no request header, and an address on the app's own server is exchanged for a short-lived signed one by the host (the description's `audio.sign`) before it plays, in the car as on the phone. Nothing in the scene changed.

## Use it

`hey_ios`'s build tool links the scene as an extension:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
  "$HEY_IOS/tools/hey-ios-api-app.sh" --source ios/app.hey --out build/ios \
  --bundle-id com.example.app --display-name 'Example' \
  --extension "$HEY_CARPLAY"
```

`$HEY_IOS` and `$HEY_CARPLAY` are the installed packages (`.hey/packages/hey_ios/0.3.1`, `.hey/packages/hey_carplay/0.1.4` after `hey package ensure`). The tool reads `ios-extension.json`: it compiles `native/HeyIOSCarPlay.m` beside the host, links CarPlay, declares the scene in Info.plist and adds `com.apple.developer.carplay-audio` (linked into a simulator build; on a device, carried only when the provisioning profile grants it).

The app's description needs an `audio` block (`hey_mobile` api_screens): the scene reads it through `HeyIOSApiHostLoadAudioFeed` and `HeyIOSApiHostAudioTitle`, and re-reads when the host posts `HeyIOSApiHostAudioFeedDidChange`.

`carplay.hey` (`HeyIOSCarPlayCapability`) states the same contract in Hey: the entitlement key, the scene configuration, the frameworks, the templates, `row_playable?` (the shape check the native module applies, so an app can test its feed on the host) and `request_steps(bundle_id)`, what to ask Apple for before a device build carries the entitlement.

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_carplay`.
