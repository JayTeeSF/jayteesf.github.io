# Todos

- Add a live temporary-file integration spec where sqlite3 is installed.
- Add typed values and prepared statements.
- Add persistent connections, busy timeout, WAL configuration, backup, and native extension support.
