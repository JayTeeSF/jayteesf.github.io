# hey_mobile

Cross-platform application primitives for ordinary Hey mobile apps. It owns lifecycle state transitions, platform-neutral screen/action/accessibility descriptions, QR/server enrollment payload validation, and development-vs-release transport policy. It does not own UIKit, Android Views/Compose, cryptographic keys, product screens, business data, signing, installation, or deployment.

`hey_mobile` is the interface layer above independently versioned `hey_ios` and future `hey_android` adapters. The CLI porcelain remains in the Hey language repository (`hey mobile ios ...`, `hey mobile android ...`).

## Check and release

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
bin/release
```

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_mobile`.
