package hey.android.fixture;

/** Test-only HTTP(S) intent sink: displays the received action and URI, never fetches it. */
public final class IntentReceiver extends android.app.Activity {
  @Override public void onCreate(android.os.Bundle saved) {
    super.onCreate(saved);
    android.widget.LinearLayout box = new android.widget.LinearLayout(this);
    box.setOrientation(android.widget.LinearLayout.VERTICAL);
    box.setPadding(24, 80, 24, 24);
    for (String value : new String[] {getIntent().getAction(), getIntent().getDataString()}) {
      android.widget.TextView text = new android.widget.TextView(this);
      text.setText(value);
      text.setTextSize(20);
      box.addView(text);
    }
    setContentView(box);
  }
}
