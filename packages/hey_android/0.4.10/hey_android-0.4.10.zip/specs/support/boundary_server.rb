# Synthetic audio/account fixture. Logs only synthetic account letters and request scope.
require 'json'
require_relative 'fixture_http'
port, logfile = ARGV
port = Integer(port)
lock = Mutex.new
pcm = "\0".b * (8000 * 2 * 12)
wave = 'RIFF'.b + [pcm.bytesize + 36].pack('V') + 'WAVEfmt '.b + [16, 1, 1, 8000, 16000, 2, 16].pack('VvvVVvv') + 'data'.b + [pcm.bytesize].pack('V') + pcm
handler = lambda do |req|
  token = req.header('authorization').to_s
  account = {'Bearer synthetic-A' => 'A', 'Bearer synthetic-B' => 'B', 'Bearer synthetic-C' => 'C'}[token]
  lock.synchronize { File.open(logfile, 'a') { |f| f.puts JSON.generate(path: req.path, account: account, bearer: !token.empty?) } }
  headers = []
  status = 200
  body = ''
  case req.path
  when '/health'
    body = 'ready'
  when '/audio.wav'
    if (range = /\Abytes=(\d+)-(\d+)\z/.match(req.header('range').to_s))
      first = Integer(range[1]); last = [Integer(range[2]), wave.bytesize - 1].min
      body = wave.byteslice(first..last) || ''
      status = 206
      headers << ['content-range', "bytes #{first}-#{last}/#{wave.bytesize}"]
    else body = wave
    end
    headers << ['content-type', 'audio/wav']
  when '/feed', '/feed/slow'
    sleep 2 if req.path.end_with?('/slow')
    body = JSON.generate(tracks: [{id: "#{account.to_s.downcase}-track", title: "Account #{account}", url: "http://10.0.2.2:#{port}/audio.wav"}])
  when %r{\A/redirect/}
    status = 302
    target = case req.path.split('/').last
             when 'port' then "http://10.0.2.2:#{port + 1}/sink"
             when 'scheme' then "https://10.0.2.2:#{port}/sink"
             else "http://localhost:#{port}/sink"
             end
    headers << ['location', target]
  when '/position/a-track', '/position/b-track', '/position/c-track'
    body = '{}'
  else
    status = 404
  end
  headers << ['content-length', body.bytesize.to_s]
  req.respond(status, body, headers)
end
threads = [port, port + 1].map { |p| Thread.new { FixtureHttp.serve(p, "boundary fixture #{p}", handler) } }
threads.each(&:join)
