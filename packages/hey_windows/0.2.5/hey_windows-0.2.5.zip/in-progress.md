# In progress

- Nothing. Next: docs/ROADMAP.md item 2 (user agent, icon, URL scheme).
