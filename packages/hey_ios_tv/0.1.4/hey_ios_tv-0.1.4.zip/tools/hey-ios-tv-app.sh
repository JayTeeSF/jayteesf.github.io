#!/usr/bin/env sh
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
HEY_IOS_ROOT=${HEY_IOS_ROOT:-$HOME/dev/hey_ios}
out=''
source="$PACKAGE_ROOT/examples/native_tvos_app.hey"
entry='tvos_app_manifest'
bundle_id='com.hey-lang.party-tv'
display_name='Hey Party TV'
minimum='17.0'
launch=false
plan_only=false
device='booted'

usage() {
  cat <<'HELP'
usage: hey ios-tv-app --out DIRECTORY [--source FILE.hey] [--entry FUNCTION] [--bundle-id ID] [--display-name NAME] [--minimum-tvos VERSION] [--launch] [--device booted|UDID] [--plan-only]
HELP
}
while [ "$#" -gt 0 ]; do
  case "$1" in
    --out) shift; out=${1:?missing --out value} ;;
    --source) shift; source=${1:?missing --source value} ;;
    --entry) shift; entry=${1:?missing --entry value} ;;
    --bundle-id) shift; bundle_id=${1:?missing --bundle-id value} ;;
    --display-name) shift; display_name=${1:?missing --display-name value} ;;
    --minimum-tvos) shift; minimum=${1:?missing --minimum-tvos value} ;;
    --device) shift; device=${1:?missing --device value} ;;
    --launch) launch=true ;;
    --plan-only) plan_only=true ;;
    --help|-h) usage; exit 0 ;;
    *) echo "unknown tvOS native-app option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
[ -n "$out" ] || { echo '--out is required' >&2; exit 2; }
[ -f "$HEY_IOS_ROOT/hey-package.json" ] || {
  echo "hey_ios package is required: $HEY_IOS_ROOT" >&2
  echo "Install and lock hey_ios 0.1.3 before using hey_ios_tv." >&2
  exit 69
}
grep -F '"name": "hey_ios"' "$HEY_IOS_ROOT/hey-package.json" >/dev/null
grep -F '0.1.3' "$HEY_IOS_ROOT/VERSION" >/dev/null || {
  echo "hey_ios 0.1.3 is required: $HEY_IOS_ROOT" >&2
  exit 69
}
[ -f "$source" ] || { echo "Hey source not found: $source" >&2; exit 66; }
case "$entry" in *[!A-Za-z0-9_]*|'') echo "invalid Hey entry function: $entry" >&2; exit 2 ;; esac

clang=''
if [ -n "${HEY_TVOS_CLANG:-}" ] && [ -x "$HEY_TVOS_CLANG" ]; then
  clang=$HEY_TVOS_CLANG
elif command -v xcrun >/dev/null 2>&1; then
  clang=$(xcrun --sdk appletvsimulator --find clang 2>/dev/null || true)
fi
[ -n "$clang" ] || clang=$(command -v clang 2>/dev/null || true)
[ -n "$clang" ] || { echo 'clang is required for tvOS Mach-O object generation' >&2; exit 69; }

rm -rf "$out"
mkdir -p "$out/src" "$out/objects" "$out/HeyPartyTV.app"
cp "$source" "$out/src/app.hey"
"$HEY_ROOT/bin/heyc" build --emit-llvm-ir "$source" -o "$out/src/app.ll" >/dev/null
symbol="hey_fn_${entry}"
grep -F "define ptr @$symbol()" "$out/src/app.ll" >/dev/null || { echo "Hey source must export fn $entry()" >&2; exit 65; }
grep -F 'define i64 @hey_fn_tvos_action_code(i64 ' "$out/src/app.ll" >/dev/null || { echo 'Hey source must export fn tvos_action_code(action_id)' >&2; exit 65; }
sed 's/define i32 @main(/define i32 @hey_tvos_source_program_main(/' "$out/src/app.ll" > "$out/src/app-tvos.ll"
sed "s/HEY_ENTRY_SYMBOL/$symbol/g" "$PACKAGE_ROOT/tools/hey_native_tv_runtime.m" > "$out/src/main.m"

host_arch=$(uname -m 2>/dev/null || echo x86_64)
case "$host_arch" in arm64|aarch64) sim_arch=arm64 ;; *) sim_arch=x86_64 ;; esac
triple="${sim_arch}-apple-tvos${minimum}-simulator"
if command -v xcrun >/dev/null 2>&1; then sdk=$(xcrun --sdk appletvsimulator --show-sdk-path 2>/dev/null || true); else sdk=''; fi
if [ -n "$sdk" ]; then
  "$clang" --target="$triple" -isysroot "$sdk" -Wno-override-module -c "$out/src/app-tvos.ll" -o "$out/objects/app-simulator.o"
else
  env -u SDKROOT "$clang" --target="$triple" -Wno-override-module -c "$out/src/app-tvos.ll" -o "$out/objects/app-simulator.o"
fi
file "$out/objects/app-simulator.o" > "$out/objects/app-simulator.file.txt"
grep -F 'Mach-O 64-bit' "$out/objects/app-simulator.file.txt" >/dev/null

cat > "$out/HeyPartyTV.app/Info.plist" <<EOF_PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDisplayName</key><string>$display_name</string>
<key>CFBundleExecutable</key><string>HeyPartyTV</string>
<key>CFBundleIdentifier</key><string>$bundle_id</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleName</key><string>$display_name</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>CFBundleVersion</key><string>1</string>
<key>MinimumOSVersion</key><string>$minimum</string>
<key>UIDeviceFamily</key><array><integer>3</integer></array>
<key>UILaunchScreen</key><dict/>
</dict></plist>
EOF_PLIST
source_sha=$(shasum -a 256 "$source" 2>/dev/null | awk '{print $1}')
object_sha=$(shasum -a 256 "$out/objects/app-simulator.o" 2>/dev/null | awk '{print $1}')

write_receipt() {
  native_link=$1; installed=$2; launched=$3; udid=$4
  cat > "$out/receipt.json" <<EOF_RECEIPT
{"kind":"hey-tvos-native-app-v1","hey_source":"$source","hey_source_sha256":"$source_sha","hey_entry":"$entry","native_hey_codegen":true,"native_object":"objects/app-simulator.o","native_object_sha256":"$object_sha","target_triple":"$triple","public_display":true,"focus_engine":true,"remote_primary_action":true,"native_link":"$native_link","simulator_install":"$installed","simulator_launch":"$launched","simulator_udid":"$udid","physical_device_signing":"pending","app_store_submission_ready":false}
EOF_RECEIPT
}

if [ "$plan_only" = true ]; then
  write_receipt pending false false ''
  printf 'tvOS native app plan ok output=%s ordinary_hey_source=true direct_llvm=true mach_o=true focus=true remote=true native_link=pending\n' "$out"
  exit 0
fi
[ "$(uname -s)" = Darwin ] || { echo 'native tvOS linking requires macOS/Xcode; use --plan-only elsewhere' >&2; exit 69; }
[ -n "$sdk" ] || { echo 'Apple TV simulator SDK missing' >&2; exit 69; }
clang=$(xcrun --sdk appletvsimulator --find clang)
"$clang" --target="$triple" -isysroot "$sdk" -fobjc-arc -fmodules \
  "$out/src/main.m" "$out/objects/app-simulator.o" -framework UIKit -framework Foundation -framework CoreImage \
  -o "$out/HeyPartyTV.app/HeyPartyTV"
chmod +x "$out/HeyPartyTV.app/HeyPartyTV"
codesign --force --sign - "$out/HeyPartyTV.app"
codesign --verify --strict "$out/HeyPartyTV.app"
installed=false; launched=false; udid=''
if [ "$launch" = true ]; then
  if [ "$device" = booted ]; then
    udid=$(xcrun simctl list devices booted | sed -n 's/.*(\([0-9A-Fa-f-][0-9A-Fa-f-]*\)) (Booted).*/\1/p' | head -1)
    [ -n "$udid" ] || { echo 'no booted Apple TV simulator found' >&2; exit 70; }
  else
    udid=$device
    xcrun simctl boot "$udid" >/dev/null 2>&1 || true
    xcrun simctl bootstatus "$udid" -b
  fi
  xcrun simctl install "$udid" "$out/HeyPartyTV.app"; installed=true
  xcrun simctl launch --terminate-running-process "$udid" "$bundle_id" > "$out/simctl-launch.txt"; launched=true
fi
write_receipt passed "$installed" "$launched" "$udid"
printf 'tvOS native app ok output=%s ordinary_hey_source=true direct_llvm=true mach_o=true focus=true remote=true native_link=passed installed=%s launched=%s\n' "$out" "$installed" "$launched"
