# hey_duckdb

Reusable Hey package for embedded DuckDB through the DuckDB C API.

## Status

**AUTHORITATIVE PACKAGE CONTRACT.** This repository is the permanent home for `hey_duckdb`. Generate the canonical package/native manifests with the current Hey toolchain at release time; do not invent native-manifest syntax, release hashes, or lock data.

## Purpose

Provide an embedded analytical SQL engine for Parquet/object-store and calibration/analytics workflows without a Python service.

## Required public surface

### `DuckDB`

- `open(path_or_memory, config: {})` -> database
- `connect(database)` -> connection
- `query(connection, sql, params: [])` -> result
- `query_one(...)`
- `execute(...)`
- `prepare(connection, sql)`
- `execute_prepared(statement, params: [])`
- `transaction(connection, fn)`
- `close(handle)`
- `interrupt(connection)`
- `health(database_or_connection)`

### Result/row decoding

Support NULL-aware decoders for booleans, signed/unsigned integers, float/double, decimal/string representation, varchar, blob, UUID, date/time/timestamp, list/struct/map through explicit typed/value APIs, and JSON text when returned as such.

### Analytics helpers

Helpers may generate safe SQL for:

- reading local Parquet
- reading bounded approved S3-compatible URLs/configurations
- writing partitioned Parquet
- attaching/detaching databases where explicitly allowed
- schema introspection

Helpers must not hide SQL semantics or introduce an ORM.

## Native DuckDB API

Wrap stable DuckDB C API functions for:

- database open/config/open_ext/close
- connect/disconnect
- query/result destroy
- prepare/bind/execute/destroy prepare
- result metadata, row count, column count/name/type
- modern value/vector/chunk access APIs preferred over deprecated accessors
- appender API for efficient bulk ingestion
- interrupt
- pending/streaming APIs where required to keep memory bounded

Opaque native handles only; no raw host pointers exposed to ordinary Hey code.

## Safety and performance

- Query strings authored by application code; user values bind as parameters.
- Bounded result materialization; large result sets stream/chunk.
- Explicit memory/thread configuration for calibration workers.
- Object-store credentials are injected at runtime and never logged.
- Parquet is authoritative analytics interchange; DuckDB databases are rebuildable analytical working state unless a specific app contract says otherwise.

## Tests required

- in-memory and file database lifecycle
- prepared parameters/injection resistance
- scalar/NULL/blob/UUID/date/timestamp decoding
- nested/list/struct values
- transaction commit/rollback
- appender bulk ingestion
- large Parquet scan with bounded memory
- Parquet write/read round trip
- concurrent independent connections from Hey workers
- interrupt/cancellation
- malformed SQL/native errors
- resource/leak checks

## MMeoww use

Use for Parquet analytics, calibration datasets, validation and exploratory/rebuildable projections. PostgreSQL remains operational truth.
