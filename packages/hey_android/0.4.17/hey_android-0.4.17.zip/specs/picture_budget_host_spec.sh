#!/usr/bin/env bash
# Host proof of the image memory budgets (HeyAndroidPictureBudget): source-pixel refusal,
# sampling to the drawn size, a decoded-byte LRU, one fetch per picture and a waiting cap.
# No device and no android.jar: the class is plain Java on purpose.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
java_home=$(hey_android_java_home)
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-picture-budget.XXXXXX")
trap 'rm -rf -- "$work"' EXIT
"$java_home/bin/javac" --release 17 -d "$work" \
  "$ROOT/renderer/android/hey/android/api/HeyAndroidPictureBudget.java" \
  "$ROOT/renderer/instrumentation/picture-budget/hey/android/api/PictureBudgetCheck.java"
"$java_home/bin/java" -cp "$work" hey.android.api.PictureBudgetCheck
