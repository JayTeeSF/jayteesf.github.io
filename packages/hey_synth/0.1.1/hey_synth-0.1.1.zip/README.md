# hey_synth

Deterministic synthetic first names, last names and email addresses from caller-supplied namespaces and stable keys. Useful for fixtures, demonstrations and filtered data exports. Password hashing and application masking policy belong to their own layers.

```hey
let first = Synth.name('Lorem', 42)
let last = Synth.name('Ipsum', 42)
let email = Synth.email('demo', 42, 'users.example.invalid')
```

Results contain `Lorem 42`, `Ipsum 42`, and `demo-42@users.example.invalid`. All operations return a Result. Failures contain a fixed code/message without input values.

[API and limits](docs/README.md) · [Getting started](docs/GETTING_STARTED.md) · [Tests](docs/TESTING.md)
