# hey_stripe

Thin Stripe primitives for Hey applications.

`hey_stripe` deliberately does **not** own application subscription truth. It describes Stripe requests and Stripe lifecycle events; the host application owns users, organizations/workspaces, plans, entitlements, authorization, idempotency and persistence.

## 0.2.0 scope

- subscription Checkout Session request shape
- one-time payment Checkout Session request shape (`mode: 'payment'`), the only mode in which Stripe offers buy-now-pay-later methods such as Affirm, Klarna and Afterpay
- Billing Portal Session request shape
- Stripe HTTP transport through `stdlib:Http`
- subscription status -> entitlement-state helper
- supported billing webhook event classification, including refunds (`charge.refunded`) and chargebacks (`charge.dispute.created`)
- fail-closed webhook signature policy

0.2.0 adds `HeyStripeCheckout.payment_session_params` and `HeyStripeCheckout.create_payment_session`, and recognises refund and dispute events. No 0.1.0 function changed signature.

HTTP transport is implemented in Hey and uses `stdlib:Http`. Cryptographic Stripe webhook verification remains behind a host crypto adapter because the current production `stdlib:Crypto` exposes SHA-256 and constant-time equality but does not yet expose HMAC-SHA256. No code should treat an unverified webhook body as a Stripe event.

## Intended Cagents Cloud flow

1. Cagents creates its user and workspace records first.
2. The server creates a Stripe Checkout Session carrying a Cagents workspace reference.
3. Stripe redirects the user through hosted Checkout.
4. Cagents changes paid entitlement only from verified Stripe lifecycle state, primarily signed webhooks.
5. Cagents stores Stripe customer/subscription IDs as external references, not as its primary identity.
6. Billing management redirects to Stripe's Customer Portal.

## Security rules

- Restricted/secret keys stay server-side.
- Raw webhook request bodies are preserved for signature verification.
- `Stripe-Signature` verification is mandatory before event parsing/dispatch.
- Webhook processing must be idempotent by Stripe event ID.
- Clients never receive a Stripe restricted/secret key or webhook secret.
- Never replace HMAC-SHA256 with an ordinary SHA-256 construction such as `sha256(secret + payload)`.

## Compiler acceptance

Do not hardcode a Hey checkout path. `bin/check` resolves the compiler from `HEY_HEYC`, then `HEY_ROOT/bin/heyc`, then `PATH`.

```sh
cd ~/dev/hey_stripe
git pull --ff-only
sh bin/check
```

`bin/check` runs the shared hey_packager checks (VERSION/manifest agreement, the docs set, `hey package verify`), then `bin/package-check`, then `docs/examples/basic.hey`. `bin/package-check` holds this package's own acceptance:

```text
heyc --version
heyc client.hey --check
form_spec.hey --test
client_spec.hey --test
webhooks_spec.hey --test
checkout_spec.hey --test
```

The client spec deliberately does not execute live HTTP through the interpreter. It checks the pure fail-closed API-key policy, while `client.hey --check` proves the HTTP-bearing module resolves through the compiler.

## Opt-in Stripe sandbox HTTP probe

Use a Stripe sandbox restricted key when practical, or a sandbox secret key while bringing the integration up. Never paste the key into source or chat.

```sh
cd ~/dev/hey_stripe
export STRIPE_API_KEY='your Stripe sandbox key'
sh bin/live-http-probe
unset STRIPE_API_KEY
```

`STRIPE_SECRET_KEY` remains a compatibility fallback. `bin/live-http-probe` resolves `hey` from `HEY_BIN`, then `HEY_ROOT/bin/hey`, then `PATH`; builds `specs/live_http_probe.hey` as a native executable with `hey build`; and only then executes it. This avoids treating `heyc --run`/the interpreter lane as evidence for the production HTTP client.

The probe performs an authenticated `GET /v1/balance` through `HeyStripeClient`. A successful transport/API call prints:

```text
stripe_http_probe_result
true
```

If neither API-key environment variable is present it prints a skip result and performs no network request.

## Webhook acceptance

The package currently stops at the cryptographic boundary on purpose. The production Hey crypto facade must first gain a real HMAC-SHA256 primitive (or the host must provide an equivalent narrowly scoped verifier). Until then, `HeyStripeWebhooks.signature_policy()` requires:

```text
raw request body
Stripe-Signature header
host_crypto_adapter
```

Once Cagents Cloud has that verifier wired, Stripe CLI can forward signed test events to the local webhook endpoint. The webhook secret printed by `stripe listen` is specific to that CLI listener and must be used for those forwarded events.
