#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreImage/CoreImage.h>
#include <stdint.h>

// hey_ios_tv native tvOS app template.
//
// The real Hey runtime (claude_01 runtime/hey_runtime.c, compiled for the
// Apple TV target) is linked into every app, so the v1 no-runtime string
// shim is GONE -- the runtime provides hey_runtime_init/shutdown, the
// hey_llvm_* string helpers, and the boxed-value ABI. The build script
// (hey-ios-tv-app.sh) calls hey_runtime_init() before the first scene is
// built and hey_runtime_shutdown() on termination.
//
// One template, two contracts, selected at build time by -DHEY_SCENE_V2:
//   * HEY_SCENE_V2 defined  -> scene-contract-v2 JSON renderer (below).
//   * otherwise             -> the v1 opaque-i64 game contract (unchanged).
// The build script nm-checks the compiled app object for
// _hey_fn_tv_scene_init and defines HEY_SCENE_V2 when it is present.

// ---- runtime (provided by hey_runtime.c, linked in) ---------------------
extern void hey_runtime_init(void);
extern void hey_runtime_shutdown(void);
extern void hey_runtime_set_argv(int argc, char **argv);
// Extract a C string from a Hey str return. Hey str-returning entries come
// back either as a raw NUL-terminated C string (single-expression returns)
// or as a boxed HeyValue* (control-flow returns). A boxed value's first
// word is its kind enum (0..13); scene JSON always starts with '{' (123) or
// '[' (91), so the first word disambiguates the two representations safely.
extern char *hey_llvm_value_to_raw_string_cstr(void *value);

static NSString *HeyStringFromReturn(const void *ret) {
  if (!ret) { return @""; }
  uint32_t tag = *(const uint32_t *)ret;         // HeyKind for a boxed value
  if (tag <= 13) {                               // HEY_ACTOR_DEFINITION == 13
    char *owned = hey_llvm_value_to_raw_string_cstr((void *)ret);
    NSString *s = owned ? [NSString stringWithUTF8String:owned] : @"";
    if (owned) { free(owned); }                  // owned copy from the runtime
    return s;                                     // boxed HeyValue* leaks (bounded, per-step)
  }
  return [NSString stringWithUTF8String:(const char *)ret];  // raw runtime cstr; do not free
}

#if defined(HEY_SCENE_V2)
// =========================================================================
// scene-contract-v2 renderer (hey-tv-scene-v2)
// =========================================================================
extern const char *hey_fn_tv_scene_init(void);
extern const char *hey_fn_tv_scene_step(const char *scene_json, const char *event_json);

static UIColor *HeyColorFromHex(NSString *hex, UIColor *fallback) {
  if (![hex isKindOfClass:NSString.class]) { return fallback; }
  NSString *s = [[hex stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet]
                    stringByReplacingOccurrencesOfString:@"#" withString:@""];
  if (s.length != 6 && s.length != 8) { return fallback; }
  unsigned int rgb = 0;
  NSScanner *scan = [NSScanner scannerWithString:s.length == 8 ? [s substringFromIndex:2] : s];
  if (![scan scanHexInt:&rgb]) { return fallback; }
  return [UIColor colorWithRed:((rgb >> 16) & 0xFF) / 255.0
                         green:((rgb >> 8) & 0xFF) / 255.0
                          blue:(rgb & 0xFF) / 255.0
                         alpha:1.0];
}

static UIColor *HeyScaleColor(UIColor *base, CGFloat factor) {
  CGFloat r = 0, g = 0, b = 0, a = 1;
  [base getRed:&r green:&g blue:&b alpha:&a];
  return [UIColor colorWithRed:MIN(1, r * factor) green:MIN(1, g * factor) blue:MIN(1, b * factor) alpha:a];
}

// ---- a single playing card (renderer-owned geometry + style) ------------
// 2.5:3.5 proportions, white face with corner rank+suit indices and a large
// center pip, hearts/diamonds red and spades/clubs near-black, soft drop
// shadow; a face-down card is a deep-blue patterned back with a border.
@interface HeyCardView : UIView
@property(copy, nonatomic) NSString *rank;
@property(copy, nonatomic) NSString *suit;
@property(nonatomic) BOOL faceUp;
@end

@implementation HeyCardView

+ (CGFloat)widthForHeight:(CGFloat)h { return h / 1.4; }   // 2.5 : 3.5

- (instancetype)initWithHeight:(CGFloat)h {
  CGFloat w = [HeyCardView widthForHeight:h];
  self = [super initWithFrame:CGRectMake(0, 0, w, h)];
  if (self) {
    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.layer.shadowColor = UIColor.blackColor.CGColor;
    self.layer.shadowOpacity = 0.35;
    self.layer.shadowRadius = 10.0;
    self.layer.shadowOffset = CGSizeMake(0, 7);
    [NSLayoutConstraint activateConstraints:@[
      [self.widthAnchor constraintEqualToConstant:w],
      [self.heightAnchor constraintEqualToConstant:h],
    ]];
    self.translatesAutoresizingMaskIntoConstraints = NO;
  }
  return self;
}

- (NSString *)pipGlyph {
  NSString *s = self.suit.lowercaseString;
  if ([s hasPrefix:@"spade"]) { return @"♠"; }
  if ([s hasPrefix:@"heart"]) { return @"♥"; }
  if ([s hasPrefix:@"diamond"]) { return @"♦"; }
  if ([s hasPrefix:@"club"]) { return @"♣"; }
  return @"?";
}

- (UIColor *)suitColor {
  NSString *s = self.suit.lowercaseString;
  if ([s hasPrefix:@"heart"] || [s hasPrefix:@"diamond"]) {
    return [UIColor colorWithRed:0xC0 / 255.0 green:0x39 / 255.0 blue:0x2B / 255.0 alpha:1.0]; // #C0392B
  }
  return [UIColor colorWithWhite:0.10 alpha:1.0]; // near-black
}

- (void)layoutSubviews {
  [super layoutSubviews];
  CGFloat radius = self.bounds.size.width * 0.09;
  self.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:radius].CGPath;
}

- (void)drawRect:(CGRect)rect {
  CGRect b = self.bounds;
  CGFloat w = b.size.width, h = b.size.height;
  CGFloat radius = w * 0.09;
  UIBezierPath *card = [UIBezierPath bezierPathWithRoundedRect:b cornerRadius:radius];

  if (!self.faceUp) {
    // deep-blue patterned back with border
    UIColor *back = [UIColor colorWithRed:0x16 / 255.0 green:0x30 / 255.0 blue:0x5C / 255.0 alpha:1.0]; // #16305C
    [back setFill];
    [card fill];
    CGRect inner = CGRectInset(b, w * 0.07, w * 0.07);
    UIBezierPath *innerPath = [UIBezierPath bezierPathWithRoundedRect:inner cornerRadius:radius * 0.7];
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSaveGState(ctx);
    [innerPath addClip];
    UIColor *hatch = [UIColor colorWithRed:0x3A / 255.0 green:0x5B / 255.0 blue:0x9C / 255.0 alpha:0.9];
    [hatch setStroke];
    UIBezierPath *lines = [UIBezierPath bezierPath];
    lines.lineWidth = 2.0;
    CGFloat step = w * 0.17;
    for (CGFloat x = -h; x < w + h; x += step) {
      [lines moveToPoint:CGPointMake(x, 0)];
      [lines addLineToPoint:CGPointMake(x + h, h)];
      [lines moveToPoint:CGPointMake(x + h, 0)];
      [lines addLineToPoint:CGPointMake(x, h)];
    }
    [lines stroke];
    CGContextRestoreGState(ctx);
    [[UIColor colorWithRed:0x8F / 255.0 green:0xAB / 255.0 blue:0xE0 / 255.0 alpha:1.0] setStroke];
    innerPath.lineWidth = 3.0;
    [innerPath stroke];
    return;
  }

  // white face
  [[UIColor colorWithRed:0.99 green:0.99 blue:0.97 alpha:1.0] setFill];
  [card fill];
  [[UIColor colorWithWhite:0.86 alpha:1.0] setStroke];
  card.lineWidth = 1.5;
  [card stroke];

  UIColor *color = [self suitColor];
  NSString *pip = [self pipGlyph];
  NSString *rk = self.rank.length ? self.rank.uppercaseString : @"?";

  // large center pip
  UIFont *centerFont = [UIFont systemFontOfSize:h * 0.42 weight:UIFontWeightMedium];
  NSDictionary *centerAttrs = @{ NSFontAttributeName: centerFont, NSForegroundColorAttributeName: color };
  CGSize cs = [pip sizeWithAttributes:centerAttrs];
  [pip drawAtPoint:CGPointMake((w - cs.width) / 2.0, (h - cs.height) / 2.0) withAttributes:centerAttrs];

  // corner index: rank over suit pip, top-left and (rotated) bottom-right
  UIFont *rankFont = [UIFont systemFontOfSize:h * 0.15 weight:UIFontWeightSemibold];
  UIFont *smallPipFont = [UIFont systemFontOfSize:h * 0.13 weight:UIFontWeightRegular];
  NSDictionary *rankAttrs = @{ NSFontAttributeName: rankFont, NSForegroundColorAttributeName: color };
  NSDictionary *smallPipAttrs = @{ NSFontAttributeName: smallPipFont, NSForegroundColorAttributeName: color };
  CGFloat inset = w * 0.09;

  [rk drawAtPoint:CGPointMake(inset, inset * 0.7) withAttributes:rankAttrs];
  [pip drawAtPoint:CGPointMake(inset, inset * 0.7 + rankFont.lineHeight * 0.85) withAttributes:smallPipAttrs];

  CGContextRef ctx = UIGraphicsGetCurrentContext();
  CGContextSaveGState(ctx);
  CGContextTranslateCTM(ctx, w, h);
  CGContextRotateCTM(ctx, M_PI);
  [rk drawAtPoint:CGPointMake(inset, inset * 0.7) withAttributes:rankAttrs];
  [pip drawAtPoint:CGPointMake(inset, inset * 0.7 + rankFont.lineHeight * 0.85) withAttributes:smallPipAttrs];
  CGContextRestoreGState(ctx);
}
@end

// ---- an empty stack slot: a dashed rounded outline ----------------------
@interface HeyCardSlotView : UIView
@end
@implementation HeyCardSlotView
- (instancetype)initWithHeight:(CGFloat)h {
  CGFloat w = [HeyCardView widthForHeight:h];
  self = [super initWithFrame:CGRectMake(0, 0, w, h)];
  if (self) {
    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
      [self.widthAnchor constraintEqualToConstant:w],
      [self.heightAnchor constraintEqualToConstant:h],
    ]];
  }
  return self;
}
- (void)drawRect:(CGRect)rect {
  CGRect b = CGRectInset(self.bounds, 3, 3);
  UIBezierPath *p = [UIBezierPath bezierPathWithRoundedRect:b cornerRadius:b.size.width * 0.09];
  CGFloat dashes[] = {12, 9};
  [p setLineDash:dashes count:2 phase:0];
  p.lineWidth = 3.0;
  [[UIColor colorWithWhite:1.0 alpha:0.35] setStroke];
  [p stroke];
}
@end

@interface HeySceneViewController : UIViewController
@property(copy, nonatomic) NSString *sceneJson;
@property(strong, nonatomic) UIView *contentView;
@property(strong, nonatomic) CAGradientLayer *feltLayer;
@property(nonatomic) BOOL seeded;
// Live-data support (0.4.0). A scene may declare "tick" and/or "fetch"; the
// renderer owns the clock and the socket so the Hey app stays pure.
@property(strong, nonatomic) NSTimer *pollTimer;
@property(copy, nonatomic) NSString *pollSignature;
@property(nonatomic) BOOL fetchInFlight;
// Bootstrap fallback: the fetch url baked into the app's OWN first scene
// (tv_scene_init), kept separately from whatever url the poll has since been
// re-armed onto, plus a count of consecutive failed scene-mode polls.
@property(copy, nonatomic) NSString *bootstrapFetchUrl;
@property(nonatomic) NSInteger consecutiveFetchFailures;
// Back-button support (0.4.6). YES only while the CURRENTLY INSTALLED scene
// declares top-level "handles_back": true; re-evaluated on every scene
// install (renderScene), because scenes change every poll.
@property(nonatomic) BOOL handlesBack;
// Whether WE consumed the in-flight Menu press at press-down. The decision
// is captured once in -pressesBegan: and reused for the matching
// ended/cancelled, so a poll that swaps the scene mid-press can never split
// one physical press between the funnel and the system.
@property(nonatomic) BOOL menuPressOwned;
@end

// ---- bootstrap fallback threshold ---------------------------------------
// A scene-mode poll may re-arm the renderer onto a NEW url: that is how the
// Jackbox-style room handoff works -- a pack bakes ONE generic bootstrap url,
// the server answers with a scene whose own fetch.url is room-specific, and
// the renderer follows it. If that room later disappears (expiry, restart,
// deploy) every poll fails, nothing is ever installed, and the screen is stuck
// on its last frame forever. The server cannot fix it, because the TV is no
// longer asking the server anything it can answer. So the renderer counts
// CONSECUTIVE failed scene polls and, at the limit, re-points the poll at the
// baked url, which re-bootstraps the display with nobody touching the TV.
//
// 5 is chosen against the documented 2000ms default cadence: ~10s of a dead
// screen before recovery is attempted. Fewer (1-2) would throw away a healthy
// room over one Wi-Fi hiccup or a single slow response; many more would leave
// a visibly frozen TV long enough for someone to get up and restart the app,
// which is exactly the failure this removes. It is a COUNT, not a duration, so
// a pack that polls more slowly waits proportionally longer before giving up
// on its room -- the right trade, since a slow cadence implies a slow game.
//
// There is deliberately NO back-off: the cadence is already the app's declared
// fetch.ms, requests never stack (fetchInFlight), and a bounded retry against
// one bootstrap url every few seconds is cheaper than the alternative of a
// screen that stays dead until a human intervenes.
static const NSInteger kHeySceneFetchFailureLimit = 5;

@implementation HeySceneViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = [UIColor colorWithRed:0x10 / 255.0 green:0x18 / 255.0 blue:0x20 / 255.0 alpha:1.0];

  self.contentView = [[UIView alloc] init];
  self.contentView.translatesAutoresizingMaskIntoConstraints = NO;
  [self.view addSubview:self.contentView];
  [NSLayoutConstraint activateConstraints:@[
    [self.contentView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [self.contentView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [self.contentView.topAnchor constraintEqualToAnchor:self.view.topAnchor],
    [self.contentView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
  ]];

  const char *initBytes = hey_fn_tv_scene_init();
  self.sceneJson = HeyStringFromReturn(initBytes);
  // Capture the BAKED fetch url before any server document can replace it.
  // This is the address the pack was built with and the only one still
  // guaranteed to exist after a room-specific url goes away.
  self.bootstrapFetchUrl = [self fetchUrlInScene:[self parsedScene]];
  [self renderScene];

  // ---- input: ONE mechanism per input class, no double-fires ------------
  // Directional + Select + Play/Pause arrive as UIPress events and are
  // handled in -pressesBegan: below (simulator arrow keys and hardware
  // edge-clicks both deliver these as presses). The Siri Remote clickpad
  // ALSO reports directional gestures as touch swipes, which never surface
  // as presses -- those are covered by the swipe recognizers here. A given
  // physical input reaches exactly one path, so nothing double-fires. The
  // per-pressType UITapGestureRecognizers are intentionally GONE: they were
  // unreliable for arrow presses on real hardware.
  NSArray<NSNumber *> *swipeDirs = @[
    @(UISwipeGestureRecognizerDirectionUp), @(UISwipeGestureRecognizerDirectionDown),
    @(UISwipeGestureRecognizerDirectionLeft), @(UISwipeGestureRecognizerDirectionRight)
  ];
  for (NSNumber *dir in swipeDirs) {
    UISwipeGestureRecognizer *swipe =
        [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(remoteSwipe:)];
    swipe.direction = (UISwipeGestureRecognizerDirection)dir.unsignedIntegerValue;
    [self.view addGestureRecognizer:swipe];
  }
}

- (BOOL)canBecomeFocused { return YES; }

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
  if (self.seeded) { return; }
  self.seeded = YES;
  long long ms = (long long)([NSDate date].timeIntervalSince1970 * 1000.0);
  NSString *event = [NSString stringWithFormat:@"{\"kind\":\"seed\",\"value\":%lld}", ms];
  [self stepWithEvent:event];
}

- (NSDictionary *)parsedScene {
  NSData *data = [self.sceneJson dataUsingEncoding:NSUTF8StringEncoding];
  if (!data) { return @{}; }
  id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
  return [parsed isKindOfClass:NSDictionary.class] ? parsed : @{};
}

- (void)stepWithEvent:(NSString *)eventJson {
  const char *next = hey_fn_tv_scene_step(self.sceneJson.UTF8String, eventJson.UTF8String);
  NSString *nextScene = HeyStringFromReturn(next);
  if ([nextScene isEqualToString:self.sceneJson]) { return; } // unchanged: skip re-render
  self.sceneJson = nextScene;
  [self renderScene];
}

// ---- live data: tick + fetch (0.4.0) -----------------------------------
//
// A scene opts in by carrying either of:
//   "tick":  {"ms": 1000}
//   "fetch": {"url": "http://host/path", "ms": 2000, "mode": "scene", "id": "room"}
//
// The timer period comes from tick.ms, else fetch.ms, else 2000, floored at
// 250ms. With mode "scene" the fetched document IS the next scene and the
// renderer installs it directly -- that is what lets a display app project
// server-rendered state without asking the Hey app to parse JSON (the tvOS
// LLVM subset builds documents by string concatenation and cannot decode
// them). Any other mode delivers {"kind":"data",...} through the normal
// event funnel instead.
//
// Networking is NSURLSession on purpose: hey_tvos_link_stubs.c replaces the
// whole OpenSSL surface with abort() traps, so an HTTPS request issued from
// Hey's own stdlib would kill the app.
//
// Because a fetched scene carries its own fetch declaration, a scene-mode poll
// can move the renderer onto a different url. -noteFailedScenePoll below is the
// way back: see kHeySceneFetchFailureLimit.
- (void)syncLiveDataWithScene:(NSDictionary *)scene {
  NSDictionary *tick = [scene[@"tick"] isKindOfClass:NSDictionary.class] ? scene[@"tick"] : nil;
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;

  double ms = 0.0;
  if ([tick[@"ms"] isKindOfClass:NSNumber.class]) { ms = [tick[@"ms"] doubleValue]; }
  if (ms <= 0.0 && [fetch[@"ms"] isKindOfClass:NSNumber.class]) { ms = [fetch[@"ms"] doubleValue]; }
  if (ms <= 0.0) { ms = 2000.0; }
  if (ms < 250.0) { ms = 250.0; }

  NSString *url = [fetch[@"url"] isKindOfClass:NSString.class] ? fetch[@"url"] : @"";
  NSString *signature = [NSString stringWithFormat:@"%.0f|%@|%@|%@",
                         ms, tick ? @"t" : @"-", url,
                         [fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @""];
  if ([signature isEqualToString:self.pollSignature]) { return; }  // nothing changed
  self.pollSignature = signature;

  [self.pollTimer invalidate];
  self.pollTimer = nil;
  if (!tick && !fetch) { return; }

  __weak __typeof__(self) weakSelf = self;
  self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:(ms / 1000.0)
                                                   repeats:YES
                                                     block:^(NSTimer *timer) {
    (void)timer;
    [weakSelf onLiveDataTimer];
  }];
}

- (void)onLiveDataTimer {
  NSDictionary *scene = [self parsedScene];
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  if ([fetch[@"url"] isKindOfClass:NSString.class]) { [self startFetch:fetch]; }
  if ([scene[@"tick"] isKindOfClass:NSDictionary.class]) {
    long long ms = (long long)([NSDate date].timeIntervalSince1970 * 1000.0);
    [self stepWithEvent:[NSString stringWithFormat:@"{\"kind\":\"tick\",\"ms\":%lld}", ms]];
  }
}

- (void)startFetch:(NSDictionary *)fetch {
  if (self.fetchInFlight) { return; }              // never stack requests
  NSURL *url = [NSURL URLWithString:fetch[@"url"]];
  if (!url) { return; }
  BOOL sceneMode = [[fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @""
                    isEqualToString:@"scene"];
  NSString *fetchId = [fetch[@"id"] isKindOfClass:NSString.class] ? fetch[@"id"] : @"";
  self.fetchInFlight = YES;

  __weak __typeof__(self) weakSelf = self;
  NSURLSessionDataTask *task =
      [NSURLSession.sharedSession dataTaskWithURL:url
                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    (void)error;
    long long status = [response isKindOfClass:NSHTTPURLResponse.class]
                           ? (long long)((NSHTTPURLResponse *)response).statusCode : 0;
    NSString *body = data.length ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
    dispatch_async(dispatch_get_main_queue(), ^{
      __typeof__(self) strongSelf = weakSelf;
      if (!strongSelf) { return; }
      strongSelf.fetchInFlight = NO;
      if (sceneMode) {
        // Only a successful, non-empty document may replace the scene; a
        // failed poll must leave whatever is on screen untouched.
        if (status == 200 && body.length) {
          strongSelf.consecutiveFetchFailures = 0;   // the streak is broken
          if (![body isEqualToString:strongSelf.sceneJson]) {
            strongSelf.sceneJson = body;
            [strongSelf renderScene];
          }
        } else {
          // Transport error, timeout, non-2xx, or an empty body: everything
          // that did NOT yield an installable document counts against the
          // bootstrap-fallback streak. `error` is folded in here rather than
          // inspected -- a failed transport reports status 0 and no body.
          [strongSelf noteFailedScenePoll];
        }
        return;
      }
      NSDictionary *event = @{ @"kind": @"data", @"id": fetchId,
                               @"status": @(status), @"body": body ?: @"" };
      NSData *json = [NSJSONSerialization dataWithJSONObject:event options:0 error:NULL];
      if (!json) { return; }
      [strongSelf stepWithEvent:[[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding]];
    });
  }];
  [task resume];
}

// The fetch url a scene document declares, or nil when it declares none.
- (NSString *)fetchUrlInScene:(NSDictionary *)scene {
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  NSString *url = [fetch[@"url"] isKindOfClass:NSString.class] ? fetch[@"url"] : nil;
  return url.length ? url : nil;
}

// One failed scene-mode poll. At kHeySceneFetchFailureLimit consecutive
// failures, re-point the poll at the baked bootstrap url so the screen can
// re-bootstrap itself onto a fresh room with no human involved.
//
// Recovery rewrites ONLY fetch.url in the scene currently on screen; the
// widgets are left exactly as they are, so the display keeps showing its last
// good frame until the bootstrap url answers with a real document. Re-render
// is what re-arms the timer, via the usual syncLiveDataWithScene signature.
//
// This applies to scene mode only. In any other mode the Hey app owns the
// scene and already sees the failure as a {"kind":"data","status":...} event,
// so the renderer must not overrule it.
- (void)noteFailedScenePoll {
  NSString *bootstrap = self.bootstrapFetchUrl;
  if (!bootstrap.length) { return; }   // nothing was baked in: nowhere to go

  if (self.consecutiveFetchFailures < kHeySceneFetchFailureLimit) {
    self.consecutiveFetchFailures++;   // clamped: a long outage cannot overflow
  }
  if (self.consecutiveFetchFailures < kHeySceneFetchFailureLimit) { return; }

  NSDictionary *scene = [self parsedScene];
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  NSString *mode = [fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @"";
  if (![mode isEqualToString:@"scene"]) { return; }  // scene swapped out under us
  NSString *current = [self fetchUrlInScene:scene];
  // Already home: keep hammering the bootstrap url on its normal cadence
  // rather than re-installing the same document over and over.
  if (current && [current isEqualToString:bootstrap]) { return; }

  NSMutableDictionary *nextScene = [scene mutableCopy];
  NSMutableDictionary *nextFetch = [fetch mutableCopy];
  nextFetch[@"url"] = bootstrap;
  nextScene[@"fetch"] = nextFetch;
  NSData *json = [NSJSONSerialization dataWithJSONObject:nextScene options:0 error:NULL];
  if (!json) { return; }
  NSString *doc = [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding];
  if (!doc.length) { return; }

  NSLog(@"[hey_ios_tv] %ld consecutive failed scene polls of %@; returning to bootstrap url %@",
        (long)self.consecutiveFetchFailures, current ?: @"(none)", bootstrap);
  self.consecutiveFetchFailures = 0;   // give the bootstrap url a full budget
  self.sceneJson = doc;
  [self renderScene];
}

- (void)viewWillDisappear:(BOOL)animated {
  [super viewWillDisappear:animated];
  [self.pollTimer invalidate];
  self.pollTimer = nil;
  self.pollSignature = nil;   // so returning to the view reschedules
  self.consecutiveFetchFailures = 0;   // and starts its failure budget fresh
}

- (void)dealloc {
  [_pollTimer invalidate];
}

// Maps a UIPress type to the scene "button" name, or nil for types we do
// NOT own unconditionally. Menu is deliberately ABSENT from this table: it
// is owned per-scene (see -ownsMenuPress:), because a renderer that always
// swallows Menu makes the app inescapable at its root -- Menu-at-root must
// keep suspending the app (tvOS convention and an App Store requirement).
static NSString *HeyButtonForPressType(UIPressType type) {
  switch (type) {
    case UIPressTypeSelect: return @"select";
    case UIPressTypeUpArrow: return @"up";
    case UIPressTypeDownArrow: return @"down";
    case UIPressTypeLeftArrow: return @"left";
    case UIPressTypeRightArrow: return @"right";
    case UIPressTypePlayPause: return @"playpause";
    default: return nil;   // anything else: never swallowed
  }
}

// ---- the back button: Menu, per-scene (0.4.6) ---------------------------
//
// The 'back' event existed only in specs before 0.4.6: HeyButtonForPressType
// had no Menu case, so on hardware a Menu press never reached the scene
// funnel and a multi-screen app was inescapable without remapping back onto
// other buttons (field defect, RecallCoach demo, 2026-07-30).
//
// A scene now claims the press by declaring, at the top level of the scene
// document, "handles_back": true. While the installed scene declares it,
// press-down delivers {"kind":"remote","button":"back"} through the normal
// event funnel. When the field is absent or false the press is forwarded to
// super exactly as before, so tvOS still suspends the app -- absent means
// false, and every pre-0.4.6 scene behaves byte-identically.
//
// The flag is cached at install time (syncBackHandlingWithScene, called from
// renderScene like keep_awake) rather than parsed per press, and re-evaluated
// on EVERY install because scene-mode polls replace the document every few
// seconds: a server can hand out "handles_back": true on a question screen
// and drop it on the lobby screen, restoring Menu-suspends at the root.
- (void)syncBackHandlingWithScene:(NSDictionary *)scene {
  BOOL wanted = NO;
  id declared = scene[@"handles_back"];
  if ([declared isKindOfClass:NSNumber.class]) { wanted = [declared boolValue]; }
  if (self.handlesBack == wanted) { return; }
  self.handlesBack = wanted;
  NSLog(@"[hey_ios_tv] handles_back=%@ (Menu %@)",
        wanted ? @"true" : @"false",
        wanted ? @"delivered to the scene as 'back'" : @"bubbles to tvOS");
}

- (void)fireRemoteButton:(NSString *)button {
  NSString *event = [NSString stringWithFormat:@"{\"kind\":\"remote\",\"button\":\"%@\"}", button];
  [self stepWithEvent:event];
}

// The action fires exactly once, on press-down. Any press we do not own --
// including Menu whenever the installed scene does not declare
// "handles_back": true -- is forwarded to super so the system default
// (suspend/exit) still runs.
- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      self.menuPressOwned = self.handlesBack;   // decide once, at press-down
      if (self.menuPressOwned) {
        [self fireRemoteButton:@"back"];
        [unhandled removeObject:press];
      }
      continue;
    }
    NSString *button = HeyButtonForPressType(press.type);
    if (button) {
      [self fireRemoteButton:button];
      [unhandled removeObject:press];
    }
  }
  if (unhandled.count) { [super pressesBegan:unhandled withEvent:event]; }
}

// We already acted on press-down; on end/cancel just swallow the presses we
// own (so they do not fire twice) and forward the rest up the chain. Menu is
// swallowed here iff WE consumed its press-down (menuPressOwned), never by
// re-reading handlesBack -- the scene may have changed mid-press.
- (void)pressesEnded:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      if (self.menuPressOwned) { [unhandled removeObject:press]; }
      self.menuPressOwned = NO;
      continue;
    }
    if (HeyButtonForPressType(press.type)) { [unhandled removeObject:press]; }
  }
  if (unhandled.count) { [super pressesEnded:unhandled withEvent:event]; }
}

- (void)pressesCancelled:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      if (self.menuPressOwned) { [unhandled removeObject:press]; }
      self.menuPressOwned = NO;
      continue;
    }
    if (HeyButtonForPressType(press.type)) { [unhandled removeObject:press]; }
  }
  if (unhandled.count) { [super pressesCancelled:unhandled withEvent:event]; }
}

// Clickpad touch swipes -> the same directional actions. These fire only for
// touch gestures, which never arrive as presses, so there is no double-fire.
- (void)remoteSwipe:(UISwipeGestureRecognizer *)recognizer {
  NSString *button = @"up";
  switch (recognizer.direction) {
    case UISwipeGestureRecognizerDirectionUp: button = @"up"; break;
    case UISwipeGestureRecognizerDirectionDown: button = @"down"; break;
    case UISwipeGestureRecognizerDirectionLeft: button = @"left"; break;
    case UISwipeGestureRecognizerDirectionRight: button = @"right"; break;
    default: return;
  }
  [self fireRemoteButton:button];
}

// ---- rendering (diff-lite: rebuild the widget tree each step) ------------
// The tvOS screensaver is a BUG during a live quiz: the whole room is looking
// at the screen, nobody is touching a remote, and tvOS has no idea the display
// is doing anything. A scene asks to stay awake with "keep_awake": true.
//
// Scene-DECLARED rather than always-on, deliberately. A display parked on an
// unclaimed code could sit for hours, and holding the screen awake forever
// wastes power and risks burn-in for no one's benefit. The server knows which
// it is -- a claimed room keeps the TV awake, an unclaimed one lets it sleep.
//
// Absent means false, so every pack built before this behaves exactly as it
// did. idleTimerDisabled must be touched on the main thread; renderScene is
// already there.
- (void)syncIdleTimerWithScene:(NSDictionary *)scene {
  BOOL wanted = NO;
  id declared = scene[@"keep_awake"];
  if ([declared isKindOfClass:NSNumber.class]) { wanted = [declared boolValue]; }

  UIApplication *app = UIApplication.sharedApplication;
  if (app.idleTimerDisabled == wanted) { return; }
  app.idleTimerDisabled = wanted;
  NSLog(@"[hey_ios_tv] keep_awake=%@ (tvOS screensaver %@)",
        wanted ? @"true" : @"false", wanted ? @"suppressed" : @"allowed");
}

- (void)renderScene {
  NSDictionary *scene = [self parsedScene];
  // Re-arm the clock/socket whenever the scene's tick/fetch declaration
  // changes. renderScene only runs when the scene actually changed, so an
  // idle app never reschedules.
  [self syncLiveDataWithScene:scene];
  [self syncIdleTimerWithScene:scene];
  [self syncBackHandlingWithScene:scene];

  // background: top-level background_color, felt gradient, or flat color.
  //
  // "background_color" (0.4.7) is a top-level hex string: one flat fill for
  // the whole scene background, added so a SERVER-rendered scene can dim the
  // screen (maintainer report 2026-07-31: the white quiz screen is too bright
  // at night) with a single field. When present and parseable it wins over
  // the background object's felt/color; when ABSENT -- or not a string, or
  // not a parseable hex value (HeyColorFromHex returns the nil fallback) --
  // the branches below run exactly as they did in 0.4.6, so every existing
  // scene renders pixel-identically. Same additive rule as handles_back and
  // keep_awake: absent means today's behavior; same guard pattern as
  // caption_color: isKindOfClass check + HeyColorFromHex with a fallback.
  [self.feltLayer removeFromSuperlayer];
  self.feltLayer = nil;
  UIColor *flat = [scene[@"background_color"] isKindOfClass:NSString.class]
                      ? HeyColorFromHex(scene[@"background_color"], nil) : nil;
  NSDictionary *bg = [scene[@"background"] isKindOfClass:NSDictionary.class] ? scene[@"background"] : @{};
  if (flat) {
    self.view.backgroundColor = flat;
  } else if ([bg[@"felt"] isKindOfClass:NSString.class]) {
    UIColor *base = HeyColorFromHex(bg[@"felt"], [UIColor colorWithRed:0x1E / 255.0 green:0x4D / 255.0 blue:0x3B / 255.0 alpha:1.0]);
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = self.view.bounds;
    g.colors = @[ (id)HeyScaleColor(base, 1.35).CGColor, (id)HeyScaleColor(base, 0.6).CGColor ];
    g.startPoint = CGPointMake(0.5, 0.0);
    g.endPoint = CGPointMake(0.5, 1.0);
    [self.view.layer insertSublayer:g atIndex:0];
    self.feltLayer = g;
    self.view.backgroundColor = base;
  } else if ([bg[@"color"] isKindOfClass:NSString.class]) {
    self.view.backgroundColor = HeyColorFromHex(bg[@"color"], UIColor.blackColor);
  }

  for (UIView *sub in self.contentView.subviews.copy) { [sub removeFromSuperview]; }

  // three slot columns: top / center / bottom, each a vertical stack
  UIStackView *(^makeColumn)(void) = ^UIStackView *(void) {
    UIStackView *s = [[UIStackView alloc] init];
    s.axis = UILayoutConstraintAxisVertical;
    s.alignment = UIStackViewAlignmentCenter;
    s.spacing = 28;
    s.translatesAutoresizingMaskIntoConstraints = NO;
    return s;
  };
  UIStackView *top = makeColumn(), *center = makeColumn(), *bottom = makeColumn();

  NSArray *widgets = [scene[@"widgets"] isKindOfClass:NSArray.class] ? scene[@"widgets"] : @[];
  for (id item in widgets) {
    if (![item isKindOfClass:NSDictionary.class]) { continue; }
    NSDictionary *w = item;
    UIView *view = [self viewForWidget:w];
    if (!view) { continue; }
    NSString *slot = [w[@"slot"] isKindOfClass:NSString.class] ? w[@"slot"] : @"center";
    if ([slot isEqualToString:@"top"]) { [top addArrangedSubview:view]; }
    else if ([slot isEqualToString:@"bottom"]) { [bottom addArrangedSubview:view]; }
    else { [center addArrangedSubview:view]; }
  }

  // Assemble the three slot columns into ONE top-to-bottom flow that can never
  // overlap: a vertical stack view never lays its arranged subviews on top of
  // one another. Two flexible spacers keep `top` pinned to the top, `bottom`
  // pinned to the bottom, and `center` in the middle when there is slack; when
  // a scene is tall (two dealt hands, or a wide card fan above a status line
  // and a QR) the spacers simply shrink, so text never overprints text.
  UIView *(^makeSpacer)(void) = ^UIView *(void) {
    UIView *v = [[UIView alloc] init];
    v.translatesAutoresizingMaskIntoConstraints = NO;
    [v setContentHuggingPriority:1 forAxis:UILayoutConstraintAxisVertical];  // stretch me first
    [v.widthAnchor constraintEqualToConstant:0].active = YES;
    return v;
  };
  UIView *spacerTop = makeSpacer(), *spacerBottom = makeSpacer();

  UIStackView *flow = [[UIStackView alloc] init];
  flow.axis = UILayoutConstraintAxisVertical;
  flow.alignment = UIStackViewAlignmentCenter;
  flow.distribution = UIStackViewDistributionFill;
  flow.translatesAutoresizingMaskIntoConstraints = NO;
  [flow addArrangedSubview:top];
  [flow addArrangedSubview:spacerTop];
  [flow addArrangedSubview:center];
  [flow addArrangedSubview:spacerBottom];
  [flow addArrangedSubview:bottom];
  [self.contentView addSubview:flow];

  UILayoutGuide *safe = self.contentView.safeAreaLayoutGuide;
  // The bottom pin yields (only) if a scene is too tall to fit, letting the
  // flow overflow downward rather than forcing an unsatisfiable layout.
  NSLayoutConstraint *bottomPin =
      [flow.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor constant:-40];
  bottomPin.priority = UILayoutPriorityRequired - 1;
  // Equal spacers keep the center column visually centered when there is slack.
  NSLayoutConstraint *equalSpacers =
      [spacerTop.heightAnchor constraintEqualToAnchor:spacerBottom.heightAnchor];
  equalSpacers.priority = UILayoutPriorityDefaultHigh;
  [NSLayoutConstraint activateConstraints:@[
    [flow.centerXAnchor constraintEqualToAnchor:self.contentView.centerXAnchor],
    [flow.topAnchor constraintEqualToAnchor:safe.topAnchor constant:40],
    bottomPin,
    [spacerTop.heightAnchor constraintGreaterThanOrEqualToConstant:16],
    [spacerBottom.heightAnchor constraintGreaterThanOrEqualToConstant:16],
    equalSpacers,
  ]];
}

- (UIView *)viewForWidget:(NSDictionary *)w {
  NSString *kind = [w[@"kind"] isKindOfClass:NSString.class] ? w[@"kind"] : @"";
  if ([kind isEqualToString:@"text"]) { return [self textViewForWidget:w]; }
  if ([kind isEqualToString:@"image"]) { return [self imageViewForWidget:w]; }
  if ([kind isEqualToString:@"qr"]) { return [self qrViewForWidget:w]; }
  if ([kind isEqualToString:@"rect"]) { return [self rectViewForWidget:w]; }
  if ([kind isEqualToString:@"card"]) { return [self cardViewForWidget:w height:230]; }
  if ([kind isEqualToString:@"stack"]) { return [self stackViewForWidget:w]; }
  if ([kind isEqualToString:@"hand"]) { return [self handViewForWidget:w]; }
  return [self placeholderForKind:kind];   // unknown kind: visible, never a crash
}

- (UILabel *)textViewForWidget:(NSDictionary *)w {
  UILabel *label = [[UILabel alloc] init];
  label.translatesAutoresizingMaskIntoConstraints = NO;
  label.text = [w[@"text"] isKindOfClass:NSString.class] ? w[@"text"] : @"";
  label.numberOfLines = 0;
  // numberOfLines=0 alone never wraps here: the widget columns are centered
  // with no width constraint, so a long single label's INTRINSIC width wins
  // and the line runs off both screen edges (seen on-device with a long
  // question stem). tvOS UIKit is logically 1920x1080, so cap every label at
  // 1760pt (80pt margins) and tell the intrinsic-size machinery to wrap at
  // the same width.
  label.preferredMaxLayoutWidth = 1760;
  [label.widthAnchor constraintLessThanOrEqualToConstant:1760].active = YES;
  NSString *style = [w[@"style"] isKindOfClass:NSString.class] ? w[@"style"] : @"body";
  if ([style isEqualToString:@"title"]) { label.font = [UIFont systemFontOfSize:76 weight:UIFontWeightBold]; }
  else if ([style isEqualToString:@"headline"]) { label.font = [UIFont systemFontOfSize:48 weight:UIFontWeightSemibold]; }
  else if ([style isEqualToString:@"caption"]) { label.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular]; }
  else { label.font = [UIFont systemFontOfSize:36 weight:UIFontWeightRegular]; }
  label.textColor = HeyColorFromHex(w[@"color"], UIColor.whiteColor);
  NSString *align = [w[@"align"] isKindOfClass:NSString.class] ? w[@"align"] : @"center";
  label.textAlignment = [align isEqualToString:@"left"] ? NSTextAlignmentLeft
      : [align isEqualToString:@"right"] ? NSTextAlignmentRight : NSTextAlignmentCenter;
  return label;
}

- (UIImageView *)imageViewForWidget:(NSDictionary *)w {
  UIImageView *iv = [[UIImageView alloc] init];
  iv.translatesAutoresizingMaskIntoConstraints = NO;
  iv.contentMode = UIViewContentModeScaleAspectFit;
  NSString *symbol = [w[@"symbol"] isKindOfClass:NSString.class] ? w[@"symbol"] : @"";
  UIImage *img = symbol.length ? [UIImage systemImageNamed:symbol] : nil;
  UIColor *tint = HeyColorFromHex(w[@"tint"], nil);
  if (img && tint) { img = [img imageWithTintColor:tint renderingMode:UIImageRenderingModeAlwaysOriginal]; }
  iv.image = img;
  [NSLayoutConstraint activateConstraints:@[
    [iv.widthAnchor constraintEqualToConstant:140],
    [iv.heightAnchor constraintEqualToConstant:140],
  ]];
  return iv;
}

- (UIImage *)qrImageForString:(NSString *)text size:(CGFloat)side {
  CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
  [filter setValue:[text dataUsingEncoding:NSUTF8StringEncoding] forKey:@"inputMessage"];
  [filter setValue:@"M" forKey:@"inputCorrectionLevel"];
  CIImage *output = filter.outputImage;
  if (!output) { return nil; }
  CGFloat scale = side / output.extent.size.width;
  CIImage *scaled = [output imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
  CIContext *context = [CIContext context];
  CGImageRef cg = [context createCGImage:scaled fromRect:scaled.extent];
  if (!cg) { return nil; }
  UIImage *image = [UIImage imageWithCGImage:cg];
  CGImageRelease(cg);
  return image;
}

- (UIView *)qrViewForWidget:(NSDictionary *)w {
  UIStackView *col = [[UIStackView alloc] init];
  col.axis = UILayoutConstraintAxisVertical;
  col.alignment = UIStackViewAlignmentCenter;
  col.spacing = 14;
  col.translatesAutoresizingMaskIntoConstraints = NO;

  NSString *payload = [w[@"payload"] isKindOfClass:NSString.class] ? w[@"payload"] : @"";
  UIImageView *qr = [[UIImageView alloc] init];
  qr.translatesAutoresizingMaskIntoConstraints = NO;
  qr.accessibilityIdentifier = @"scene-qr";
  qr.layer.magnificationFilter = kCAFilterNearest;
  if (payload.length) { qr.image = [self qrImageForString:payload size:260]; }
  [NSLayoutConstraint activateConstraints:@[
    [qr.widthAnchor constraintEqualToConstant:260],
    [qr.heightAnchor constraintEqualToConstant:260],
  ]];
  [col addArrangedSubview:qr];

  if ([w[@"caption"] isKindOfClass:NSString.class]) {
    UILabel *cap = [[UILabel alloc] init];
    cap.text = w[@"caption"];
    cap.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular];
    // caption_color lets a light-background scene use a readable caption;
    // the near-white default predates light scenes and stays for backward
    // compatibility (dark scenes rely on it).
    cap.textColor = HeyColorFromHex(w[@"caption_color"], [UIColor colorWithWhite:0.9 alpha:1.0]);
    cap.textAlignment = NSTextAlignmentCenter;
    cap.numberOfLines = 0;
    cap.preferredMaxLayoutWidth = 1760;
    [cap.widthAnchor constraintLessThanOrEqualToConstant:1760].active = YES;
    [col addArrangedSubview:cap];
  }
  return col;
}

- (UIView *)rectViewForWidget:(NSDictionary *)w {
  UIView *v = [[UIView alloc] init];
  v.translatesAutoresizingMaskIntoConstraints = NO;
  v.backgroundColor = HeyColorFromHex(w[@"color"], UIColor.grayColor);
  v.layer.cornerRadius = 12;
  CGFloat width = [w[@"width"] respondsToSelector:@selector(doubleValue)] ? [w[@"width"] doubleValue] : 240;
  CGFloat height = [w[@"height"] respondsToSelector:@selector(doubleValue)] ? [w[@"height"] doubleValue] : 140;
  [NSLayoutConstraint activateConstraints:@[
    [v.widthAnchor constraintEqualToConstant:width],
    [v.heightAnchor constraintEqualToConstant:height],
  ]];
  return v;
}

- (HeyCardView *)cardFromDict:(NSDictionary *)c height:(CGFloat)h {
  HeyCardView *card = [[HeyCardView alloc] initWithHeight:h];
  card.rank = [c[@"rank"] isKindOfClass:NSString.class] ? c[@"rank"] : @"";
  card.suit = [c[@"suit"] isKindOfClass:NSString.class] ? c[@"suit"] : @"";
  NSString *face = [c[@"face"] isKindOfClass:NSString.class] ? c[@"face"] : @"up";
  card.faceUp = ![face isEqualToString:@"down"];
  [card setNeedsDisplay];
  return card;
}

- (UIView *)cardViewForWidget:(NSDictionary *)w height:(CGFloat)h {
  return [self cardFromDict:w height:h];
}

// A hand: a row of cards with an optional caption beneath it. Built as an
// explicit-constraint container (not a bare UIStackView) so its height ALWAYS
// includes the caption -- the caption is pinned inside the container and the
// container's bottom is pinned to it. That guarantees the hand contributes its
// full height to the enclosing slot column, so the next widget in the flow is
// laid out below the caption instead of overprinting it.
- (UIView *)handViewForWidget:(NSDictionary *)w {
  CGFloat cardH = 210;
  UIView *container = [[UIView alloc] init];
  container.translatesAutoresizingMaskIntoConstraints = NO;

  UIStackView *row = [[UIStackView alloc] init];
  row.axis = UILayoutConstraintAxisHorizontal;
  row.alignment = UIStackViewAlignmentCenter;
  row.spacing = 22;
  row.translatesAutoresizingMaskIntoConstraints = NO;
  NSArray *cards = [w[@"cards"] isKindOfClass:NSArray.class] ? w[@"cards"] : @[];
  for (id c in cards) {
    if (![c isKindOfClass:NSDictionary.class]) { continue; }
    [row addArrangedSubview:[self cardFromDict:c height:cardH]];
  }
  [container addSubview:row];

  NSMutableArray<NSLayoutConstraint *> *cons = [@[
    [row.topAnchor constraintEqualToAnchor:container.topAnchor],
    [row.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
    [row.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor],
    [row.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor],
    [row.heightAnchor constraintEqualToConstant:cardH],
    [container.widthAnchor constraintGreaterThanOrEqualToAnchor:row.widthAnchor],
  ] mutableCopy];

  UIView *lastView = row;   // the view whose bottom defines the container height
  if ([w[@"label"] isKindOfClass:NSString.class]) {
    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = w[@"label"];
    label.font = [UIFont systemFontOfSize:40 weight:UIFontWeightSemibold];
    label.textColor = UIColor.whiteColor;
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 1;
    [container addSubview:label];
    [cons addObjectsFromArray:@[
      [label.topAnchor constraintEqualToAnchor:row.bottomAnchor constant:16],
      [label.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
      [label.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor],
      [label.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor],
      [container.widthAnchor constraintGreaterThanOrEqualToAnchor:label.widthAnchor],
    ]];
    lastView = label;
  }
  // Pin the container bottom to the caption (or the card row when captionless):
  // this is what makes the caption count toward the container's height.
  [cons addObject:[container.bottomAnchor constraintEqualToAnchor:lastView.bottomAnchor]];
  // Hug content horizontally: minimise width subject to the >= guards above,
  // so the container settles at max(rowWidth, labelWidth).
  NSLayoutConstraint *hug = [container.widthAnchor constraintEqualToConstant:0];
  hug.priority = UILayoutPriorityDefaultLow;
  [cons addObject:hug];
  [NSLayoutConstraint activateConstraints:cons];
  return container;
}

- (UIView *)stackViewForWidget:(NSDictionary *)w {
  CGFloat h = 210;
  CGFloat cardW = [HeyCardView widthForHeight:h];
  NSArray *cards = [w[@"cards"] isKindOfClass:NSArray.class] ? w[@"cards"] : @[];
  NSString *fan = [w[@"fan"] isKindOfClass:NSString.class] ? w[@"fan"] : @"none";
  double overlap = [w[@"overlap"] respondsToSelector:@selector(doubleValue)] ? [w[@"overlap"] doubleValue] : 0.22;

  UIView *container = [[UIView alloc] init];
  container.translatesAutoresizingMaskIntoConstraints = NO;

  if (cards.count == 0) {
    HeyCardSlotView *slot = [[HeyCardSlotView alloc] initWithHeight:h];
    [container addSubview:slot];
    [NSLayoutConstraint activateConstraints:@[
      [container.widthAnchor constraintEqualToConstant:cardW],
      [container.heightAnchor constraintEqualToConstant:h],
      [slot.leadingAnchor constraintEqualToAnchor:container.leadingAnchor],
      [slot.topAnchor constraintEqualToAnchor:container.topAnchor],
    ]];
    return container;
  }

  CGFloat dx = [fan isEqualToString:@"right"] ? cardW * (1.0 - overlap) : 0;
  CGFloat dy = [fan isEqualToString:@"down"] ? h * (1.0 - overlap) : 0;
  NSUInteger i = 0;
  CGFloat maxX = 0, maxY = 0;
  for (id c in cards) {
    if (![c isKindOfClass:NSDictionary.class]) { continue; }
    HeyCardView *card = [self cardFromDict:c height:h];
    card.translatesAutoresizingMaskIntoConstraints = YES;
    card.frame = CGRectMake(dx * i, dy * i, cardW, h);
    [container addSubview:card];
    maxX = MAX(maxX, dx * i + cardW);
    maxY = MAX(maxY, dy * i + h);
    i++;
  }
  [NSLayoutConstraint activateConstraints:@[
    [container.widthAnchor constraintEqualToConstant:maxX],
    [container.heightAnchor constraintEqualToConstant:maxY],
  ]];
  return container;
}

- (UIView *)placeholderForKind:(NSString *)kind {
  UILabel *label = [[UILabel alloc] init];
  label.text = [NSString stringWithFormat:@"[%@?]", kind.length ? kind : @"widget"];
  label.font = [UIFont monospacedSystemFontOfSize:30 weight:UIFontWeightRegular];
  label.textColor = [UIColor colorWithRed:1.0 green:0.6 blue:0.2 alpha:1.0];
  label.textAlignment = NSTextAlignmentCenter;
  label.layer.borderColor = [UIColor colorWithRed:1.0 green:0.6 blue:0.2 alpha:1.0].CGColor;
  label.layer.borderWidth = 2;
  return label;
}

- (void)viewDidLayoutSubviews {
  [super viewDidLayoutSubviews];
  self.feltLayer.frame = self.view.bounds;
}
@end

#define HEY_ROOT_VIEW_CONTROLLER HeySceneViewController

#else
// =========================================================================
// v1 game contract (opaque i64 + manifest); unchanged behavior.
// =========================================================================
extern const char *HEY_ENTRY_SYMBOL(void);
extern long long hey_fn_tvos_action_code(long long action_id);
extern long long hey_fn_tvos_game_init(void);
extern long long hey_fn_tvos_game_step(long long state, long long action_id);
extern const char *hey_fn_tvos_game_text(long long state);

@interface HeyTVViewController : UIViewController
@property(nonatomic) long long gameState;
@property(strong, nonatomic) UILabel *gameLabel;
@end

@implementation HeyTVViewController

- (UIImage *)qrImageForString:(NSString *)text size:(CGFloat)side {
  CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
  [filter setValue:[text dataUsingEncoding:NSUTF8StringEncoding] forKey:@"inputMessage"];
  [filter setValue:@"M" forKey:@"inputCorrectionLevel"];
  CIImage *output = filter.outputImage;
  if (!output) { return nil; }
  CGFloat scale = side / output.extent.size.width;
  CIImage *scaled = [output imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
  CIContext *context = [CIContext context];
  CGImageRef cg = [context createCGImage:scaled fromRect:scaled.extent];
  if (!cg) { return nil; }
  UIImage *image = [UIImage imageWithCGImage:cg];
  CGImageRelease(cg);
  return image;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = UIColor.blackColor;
  const char *manifestBytes = HEY_ENTRY_SYMBOL();
  NSString *manifest = manifestBytes ? [NSString stringWithUTF8String:manifestBytes] : @"{}";
  NSDictionary *fields = @{};
  NSData *manifestData = [manifest dataUsingEncoding:NSUTF8StringEncoding];
  if (manifestData) {
    id parsed = [NSJSONSerialization JSONObjectWithData:manifestData options:0 error:NULL];
    if ([parsed isKindOfClass:NSDictionary.class]) { fields = parsed; }
  }
  NSString *titleText = [fields[@"title"] isKindOfClass:NSString.class] ? fields[@"title"] : @"Hey TV";
  NSString *joinUrl = [fields[@"join_url"] isKindOfClass:NSString.class] ? fields[@"join_url"] : @"";

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  title.text = titleText;
  title.textColor = UIColor.whiteColor;
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1];
  [self.view addSubview:title];

  UIImageView *qrView = [[UIImageView alloc] init];
  qrView.translatesAutoresizingMaskIntoConstraints = NO;
  qrView.accessibilityIdentifier = @"join-qr";
  if (joinUrl.length > 0) { qrView.image = [self qrImageForString:joinUrl size:360]; }
  [self.view addSubview:qrView];

  UILabel *joinLabel = [[UILabel alloc] init];
  joinLabel.translatesAutoresizingMaskIntoConstraints = NO;
  joinLabel.text = joinUrl;
  joinLabel.textColor = UIColor.lightGrayColor;
  joinLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
  [self.view addSubview:joinLabel];

  self.gameState = hey_fn_tvos_game_init();
  UILabel *game = [[UILabel alloc] init];
  game.translatesAutoresizingMaskIntoConstraints = NO;
  game.textColor = UIColor.whiteColor;
  game.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  game.numberOfLines = 3;
  game.textAlignment = NSTextAlignmentCenter;
  game.accessibilityIdentifier = @"game-state";
  self.gameLabel = game;
  [self refreshGameLabel];
  [self.view addSubview:game];

  [NSLayoutConstraint activateConstraints:@[
    [title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:60],
    [qrView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [qrView.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:40],
    [qrView.widthAnchor constraintEqualToConstant:360],
    [qrView.heightAnchor constraintEqualToConstant:360],
    [joinLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [joinLabel.topAnchor constraintEqualToAnchor:qrView.bottomAnchor constant:16],
    [game.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:120],
    [game.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-120],
    [game.topAnchor constraintEqualToAnchor:joinLabel.bottomAnchor constant:60]
  ]];

  NSArray<NSNumber *> *pressTypes = @[
    @(UIPressTypeSelect), @(UIPressTypeUpArrow), @(UIPressTypeDownArrow),
    @(UIPressTypeLeftArrow), @(UIPressTypeRightArrow), @(UIPressTypePlayPause)
  ];
  for (NSNumber *pressType in pressTypes) {
    UITapGestureRecognizer *tap =
        [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(remotePress:)];
    tap.allowedPressTypes = @[ pressType ];
    [self.view addGestureRecognizer:tap];
  }
}

- (void)refreshGameLabel {
  const char *text = hey_fn_tvos_game_text(self.gameState);
  self.gameLabel.text = text ? [NSString stringWithUTF8String:text] : @"";
}

- (void)remotePress:(UITapGestureRecognizer *)recognizer {
  NSNumber *pressType = recognizer.allowedPressTypes.firstObject;
  long long action = 1;
  switch ((UIPressType)pressType.integerValue) {
    case UIPressTypeSelect: action = 1; break;
    case UIPressTypeUpArrow: action = 2; break;
    case UIPressTypeDownArrow: action = 3; break;
    case UIPressTypeLeftArrow: action = 4; break;
    case UIPressTypeRightArrow: action = 5; break;
    case UIPressTypePlayPause: action = 6; break;
    default: action = 1; break;
  }
  self.gameState = hey_fn_tvos_game_step(self.gameState, action);
  self.gameLabel.accessibilityValue =
      [NSString stringWithFormat:@"%lld", hey_fn_tvos_action_code(action)];
  [self refreshGameLabel];
}
@end

#define HEY_ROOT_VIEW_CONTROLLER HeyTVViewController

#endif

// ---- shared app delegate + entry point ----------------------------------
@interface HeyTVAppDelegate : UIResponder <UIApplicationDelegate>
@property(strong, nonatomic) UIWindow *window;
@end

@implementation HeyTVAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
  self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  self.window.rootViewController = [[HEY_ROOT_VIEW_CONTROLLER alloc] init];
  [self.window makeKeyAndVisible];
  return YES;
}
- (void)applicationWillTerminate:(UIApplication *)application {
  hey_runtime_shutdown();
}
@end

int main(int argc, char **argv) {
  @autoreleasepool {
    hey_runtime_init();
    hey_runtime_set_argv(argc, argv);
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(HeyTVAppDelegate.class));
  }
}
