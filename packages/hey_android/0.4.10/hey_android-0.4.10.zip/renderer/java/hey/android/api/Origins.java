package hey.android.api;

import java.net.URI;

/** Credential scope is a parsed HTTP origin: scheme, hostname and effective port. */
public final class Origins {
  private Origins() {}

  public static boolean same(String origin, String address) {
    try {
      URI base = new URI(origin), target = new URI(address);
      return valid(base) && valid(target)
          && (base.getRawPath() == null || base.getRawPath().isEmpty() || base.getRawPath().equals("/"))
          && base.getRawQuery() == null && base.getRawFragment() == null
          && base.getScheme().equalsIgnoreCase(target.getScheme())
          && base.getHost().equalsIgnoreCase(target.getHost())
          && port(base) == port(target);
    } catch (Exception e) {
      return false;
    }
  }

  private static boolean valid(URI uri) {
    String scheme = uri.getScheme();
    return ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))
        && uri.getHost() != null && uri.getRawUserInfo() == null
        && uri.getPort() != 0 && uri.getPort() <= 65535;
  }

  private static int port(URI uri) {
    return uri.getPort() >= 0 ? uri.getPort() : "https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80;
  }
}
