# hey_roaring

Compressed 32-bit integer sets (Roaring bitmaps) for Hey, over a pinned, unmodified CRoaring 5.2.3 amalgamation. The portable serialization format interoperates with CRoaring, Java and Go Roaring.

Version 0.1.0. Hey module over a native ABI kernel; no compiler or runtime source modifications. Build with `bin/build-native`; test with `bin/check`. Supported build targets are Linux x86-64 and Darwin arm64. See `docs/` for design, testing and licensing of the vendored code.

Commits use short subjects without coauthor trailers.
