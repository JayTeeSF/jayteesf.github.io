# Done

- v0.1.0 package boundary, modules, tests, toolchain installer, emulator/device launcher, docs, packaging, and LLM handoff.
- Fixed the macOS installer so `sdkmanager` and `avdmanager` share the same exported Android SDK root before AVD creation.
- Fixed AVD creation by installing Android command-line tools inside the selected SDK and invoking those SDK-local binaries; Homebrew's avdmanager no longer resolves packages from its separate root.

## 0.4.3 (2026-10-07): a list that has not loaded yet no longer says it is empty

Seen on a Nexus 5X just after a restart: Library said "Nothing in this Library
view. Change Filter / Sort, or use Add." for several seconds while 582 rows were
on their way. A `fields` or `from` section read the screen's answer before it
arrived, found nothing, and said its `empty` text. Route sections already said
nothing until answered; now these do too (`Screens.list`). Answered with nothing,
they still say it. Gated by ModelMain 8 and its mutation control
`unanswered-says-empty`.

## 0.4.2 (2026-10-07): a search screen's keyboard, and where a search stands

Not a version: VERSION stays 0.4.1 until the Maintainer releases it.

- Measured on the API 36 emulator against a local My Queue server, before the
  fix: after the search key the keyboard stayed up attached to no field (typing
  went nowhere), because every answer rebuilt the box; emptying the box left it
  up; a tap on the empty screen did nothing; opening Account with it up kept it
  up, and Back there navigated instead of hiding it. System Back on a tab root
  did hide it (the platform's own IME callback).
- The search box is pinned above the scrolling body and made once per page, so
  a redraw keeps its focus and text. Cancel beside it whenever it has focus or
  text (it clears and hides the keyboard); the search key hides it; a touch
  below the box (a tap or the start of a drag) hides it; the keyboard going away
  on its own takes the focus with it; and any change of screen hides it and
  clears focus, so returning to a search screen never raises it.
- Tab stacks were measured and are NOT the iOS bug here: `selectTab` empties
  the stack, so a tab shows its root and Account is never kept on it.
- Where a search stands, from `Screens.searchState`: a spinner and "Searching
  for “q”…" while any section is unanswered or still pending; "No results for
  “q”." (or the screen's own `empty`) when every section answered with nothing;
  "The search did not finish." with Try again when one failed and nothing was
  found, and a failed section's error drawn in red. A pending section out of
  polls now shows its `gave_up_note` (as hey_ios does) instead of looking busy
  for ever. Clearing the box starts a new generation, so late answers and polls
  for the old query are dropped.
- `specs/api_renderer_emulator_spec.sh` section 7 drives the fixture's Later tab
  (now with a search section, an Account button and a `POST /v1/search` in the
  fake server); `ModelMain` section 7 checks the search states, with three new
  mutation controls in `specs/api_renderer_host_spec.sh`. Run against the
  unfixed renderer the new emulator checks fail on Cancel, the search key, tap
  outside, drag and all four search states.

## 0.4.1 (2026-09-30): complete immutable renderer archive

- `hey-package.json` now carries all 19 renderer files used by source-root
  builds. Published 0.4.0 omitted `HeyAndroidAudioService`,
  `HeyAndroidPictures`, `HeyAndroidPlayback`, and `HeyAndroidPlayer`, so an
  installed package could not compile `HeyAndroidApiActivity` even though the
  source checkout passed its renderer gate.
- `specs/package_manifest_spec.sh` compares the real renderer tree with the
  package manifest. It failed on those four omissions before the fix and now
  prevents source-root-only files from escaping future immutable releases.

## 0.3.0 (2026-09-13): Views drawn by a Hey program, and a tap, with no Java in any form

- Measured first: on NativeActivity, Views set with `setContentView` are laid
  out but never drawn while NativeActivity holds the window's surface. After
  `getWindow().takeSurface(null)` through JNI they draw.
- Measured: `Native.open` of the app's own `libhey_app.so` works on the device,
  by soname and by the `dladdr` path.
- `native/ui`: five C shims declared in `hey.native.json` and wrapped by
  `hey native`: `begin`, `text_row`, `commit`, `next_event` (`thread_safe`)
  and `errors`. Every JNI call runs on the UI thread through an `ALooper` pipe;
  the UI thread never waits on Hey.
- Taps with no dex: NativeActivity's input queue, hit-tested against the rows'
  View bounds, queued as `{"kind":"tap","id":"row-3"}`.
- `src/android_ui.hey` (`HeyAndroidUi`) and `examples/rows.hey`: a `program`
  that loops on `next_event`, draws rows and shows "Row N was tapped".
  `examples/rows_error.hey` fails in the loop on purpose.
- The glue attaches the shims, forwards the input queue, and ends the process
  once the program and the activity are both gone, in either order. The
  manifest uses a light theme with no action bar.
- `tools/hey-android-app.sh --ui` waits for the first commit instead of the
  program's end; the receipt records commits and views on screen.
  `HEY_ANDROID_NEGATIVE_CONTROL=surface-taken` builds the drawing control.
- New specs, each check with a negative control:
  `specs/android_ui_host_spec.sh` (the Hey side on the Mac against
  `specs/support/fake_ui.c`) and `specs/android_ui_emulator_spec.sh` (pixels
  drawn, a tap changes the text, rotation, a second launch, an error in the
  loop, no dex).
- Docs: `docs/ROADMAP.md` corrects phase 2 (no library entry point or function
  pointer needed; the Proxy idea was wrong; no attach rule while JNI stays on
  the UI thread). It records the Maintainer's rule of no Java in any form, and
  what that rule costs on Android. It also lists the LLVM-lane miscompiles found
  while building the slice. `docs/PHASE2_FEASIBILITY.md` is committed with the
  withdrawn in-memory dex plan marked.

## 0.2.0 (2026-09-13): a Hey program with the runtime, on Android 16, with no Java or Kotlin

- `tools/hey-android-app.sh` builds a Hey program into a signed APK:
  - heyc's LLVM IR, compiled by NDK r28 clang for `aarch64-linux-android35`;
  - the unmodified Hey runtime from HEY_ROOT with the package's Android profile;
  - one 16 KB-aligned library;
  - aapt2, zipalign `-P 16` and apksigner.
  - The manifest has `hasCode="false"` and uses `android.app.NativeActivity`.
  - It installs and launches with adb, then writes a receipt.
- `native/glue`, the entry point:
  - the program runs on an 8 MiB thread, and so do the runtime's own threads;
  - stdout and stderr go to logcat;
  - `exit()` finishes the activity;
  - one program per process.
- `native/runtime_profile` gives the runtime real secure random, constant-time
  compare and SHA-256 (vendored from Brad Conte, public domain) through its
  platform-crypto seam. TLS, AEAD, scrypt and Argon2id report named
  unavailable errors.
- Build isolation:
  - every compiler-search variable is cleared, and `PATH` is reduced;
  - the include search path goes into the receipt, and any host directory
    fails the build.
- `bin/android-doctor` checks and prints the new pins and the Hey checkout's
  identity: platform 36, build-tools 36.0.0, NDK 28.2.13676358, the API 36
  Play image, JDK 17. It fails with the exact sdkmanager line for anything
  missing.
- `tools/hey-android-emulator.sh` owns the dedicated AVD `hey_android_API_36`:
  - it boots headless;
  - it shuts down and waits until no emulator process remains.
- `bin/check` runs the Hey specs and five shell specs: pins, SHA-256 on the
  host, the doctor, the build lane and the emulator. Every check has a
  negative control:
  - a Mac target triple is refused;
  - a Homebrew-contaminated runtime is caught;
  - a 4 KB library is refused;
  - a dex in the APK is refused;
  - `hasCode="true"` is refused;
  - a wrong digest fails;
  - an API 34 SDK is refused;
  - a build linked without `--wrap=exit` fails.
- On the emulator:
  - `hello_runtime`'s logcat output equals the Mac run byte for byte;
  - the NIST vectors pass through the runtime;
  - a runtime error ends the activity with no crash.
- Removed the Gradle lane: `tooling/01-*`, `tooling/02-*` and their spec, with
  the API 34, AGP 8.5.2 and NDK 26.1 pins.

## 0.4.0 (2026-09-14): a native renderer for served screens, level 1

- The Maintainer withdrew the no-Java rule; `docs/ROADMAP.md` records it and
  keeps the no-Java cost table as the record of the JNI-only route.
- `renderer/`: a Java renderer for hey_mobile api_screens descriptions at level
  1, platform android, mirroring hey_ios's HeyIOSApiHost and HeyIOSValues.
  Pure layer (`Json`, `Values`, `Descriptions`, `Names`, `Screens`, `Actions`)
  with no Android import; Android layer (`HeyAndroidApiActivity`,
  `HeyAndroidHttp`, `HeyAndroidSecureStore`, `HeyAndroidDescription`).
- Served, stored, baked with ETag and If-None-Match; baked-only origin and
  session keys; unknown and undrawn kinds hidden and never sent; the token
  sealed with an Android Keystore key in the no-backup directory.
- `tools/hey-android-api-app.sh`: javac, d8, aapt2, zipalign, apksigner, no
  Gradle; refuses a baked description the renderer refuses.
- hey_mobile 0.3.1's conformance vectors vendored and passing (117 values,
  names, 21 descriptions), with eleven mutation controls.
- New specs: `specs/api_renderer_host_spec.sh` and
  `specs/api_renderer_emulator_spec.sh` (fake server, sign-in, list, detail,
  back, kept session, sign-out, served/stored/baked).
- Measured by hand against a local My Queue server on the API 36 emulator:
  sign in, the seeded library, an item, back, sign out.
