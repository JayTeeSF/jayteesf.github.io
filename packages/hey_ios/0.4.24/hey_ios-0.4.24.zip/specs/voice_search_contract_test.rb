# frozen_string_literal: true
require 'minitest/autorun'
class VoiceSearchContractTest < Minitest::Test
  HOST = File.read(File.expand_path('../native/HeyIOSApiHost.m', __dir__))
  def test_search_uses_standard_keyboard
    assert_includes HOST, 'self.tableView.tableHeaderView = self.searchBar;'
    assert_includes HOST, 'self.searchBar.delegate = self;'
    refute_includes HOST, 'search_microphone'
    refute_match(/SFSpeech|requestRecordPermission|UIKeyboardImpl|startDictation/, HOST)
  end
  def test_navigation_retains_keyboard_dismissal
    assert_match(/viewWillDisappear:.*?\[self.view endEditing:YES\]/m, HOST)
    assert_includes HOST, 'UIScrollViewKeyboardDismissModeInteractive'
  end
end
