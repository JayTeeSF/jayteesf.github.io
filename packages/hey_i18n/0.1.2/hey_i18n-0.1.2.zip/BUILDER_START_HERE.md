# hey_i18n Builder Start Here

## Goal

Evolve the existing verified `hey_i18n` package to the expanded `PACKAGE_SPEC.md` contract without discarding its v0.1.x implementation, tests, compiled-lane receipt, or history.

## Non-negotiable package rule

Every package created or evolved for MMeoww must depend on `hey_packager` and use it for the standard package structure/check/release/publish/source-handoff workflow. Do not fork or duplicate packager policy inside this repository.

At the time this handoff was written the accessible canonical `hey_packager` manifest is version `0.1.6`. The Maintainer has since decided the dependency is the range `">=0.1.1 <0.2.0"`, not an exact version: an application lock holds one version of each package, and every package that declares `hey_packager` must accept the same one. Do not use a moving branch or `latest`.

## Existing lineage

- Existing package version in this repository: `0.1.1`.
- Existing behavior, specs and compiled-lane parity are regression requirements.
- `PACKAGE_SPEC.md` expands the package beyond its current catalog/interpolation surface into the complete MMeoww localization contract.
- Do not publish over the immutable 0.1.1 registry release. Once implementation is complete, bump through the canonical `hey_packager` workflow to the next appropriate version.

## Implementation actions

1. Preserve existing public behavior and tests.
2. Update the package manifest/scaffold to the current standard and declare the `hey_packager` dependency (`">=0.1.1 <0.2.0"`).
3. Keep package-specific tests in `bin/package-check`; make shared check/release/publish/source-zip/bump behavior use `hey_packager` rather than independent copies of policy.
4. Implement the missing `I18n.Locale`, `I18n.Messages`, `I18n.Format`, `I18n.Direction`, and `I18n.Resources` capabilities required by `PACKAGE_SPEC.md`, reusing the current code where it already satisfies the contract.
5. If platform ICU/CLDR/native adapters require a native package boundary, generate it using the current Hey native-package generator. Do not invent native manifest fields.
6. Add BCP 47, CLDR plural/select, date/number/currency/timezone/list, RTL/bidi, pseudolocalization, catalog-completeness and accessibility-string coverage.
7. Run existing specs and compiled-lane receipt, package-specific checks, `hey_packager check`, and claimed target builds.
8. Bump via the packager and publish a new immutable release; record archive/release/manifest/content hashes.

## MMeoww gate

MMeoww must pin the new verified release, not the mutable repository branch. After release, add the exact version to MMeoww `hey-package.json` and regenerate/commit `hey.lock.json` with Hey tooling.
