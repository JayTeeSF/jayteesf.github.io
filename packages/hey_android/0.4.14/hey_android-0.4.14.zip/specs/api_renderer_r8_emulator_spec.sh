#!/usr/bin/env bash
# Black-box regression of the actual R8 --release APK. No backend, credentials,
# production instrumentation, extra keep rules, or recompiled renderer classes.
# Logs, receipt and real device screenshots survive under HEY_ANDROID_R8_EVIDENCE.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-r8-device.XXXXXX")
evidence=${HEY_ANDROID_R8_EVIDENCE:-/private/tmp/hey-android-r8-device}
mkdir -p "$evidence"
serial=''
package=com.jayteesf.hey.r8.fixture
activity=hey.android.api.HeyAndroidApiActivity
export ADB=$HEY_ANDROID_ADB
fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }
adbs() { "$HEY_ANDROID_ADB" -s "$serial" "$@"; }
drive() { "$HEY_ANDROID_RUBY" "$ROOT/specs/support/drive.rb" "$serial" "$@"; }
cleanup() {
  status=$?
  trap - EXIT
  if [ -n "$serial" ]; then
    adbs logcat -d > "$evidence/logcat.txt" 2>&1 || true
    adbs uninstall "$package" > "$evidence/uninstall.log" 2>&1 || true
    "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" > "$evidence/shutdown.log" 2>&1 || status=1
  fi
  cp "$work"/*.log "$evidence/" 2>/dev/null || true
  rm -rf "$work"
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
java_home=$(hey_android_java_home)
[ -n "$java_home" ] || fail 'JDK 17 unavailable'
export HEY_ANDROID_R8_FIXTURE_PASS=throwaway-fixture-only
"$java_home/bin/keytool" -genkeypair -keystore "$work/fixture.jks" -alias upload \
  -storepass:env HEY_ANDROID_R8_FIXTURE_PASS -keypass:env HEY_ANDROID_R8_FIXTURE_PASS \
  -dname 'CN=R8 offline regression' -keyalg RSA -validity 2 > "$work/keytool.log" 2>&1
"$ROOT/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/r8/description.json" \
  --origin https://example.invalid --package-id "$package" --label 'R8 offline fixture' --out "$work/release" \
  --release --keystore "$work/fixture.jks" --keystore-password-env HEY_ANDROID_R8_FIXTURE_PASS > "$work/build.log" 2>&1 \
  || { tail -20 "$work/build.log"; fail 'release fixture build'; }
[ -s "$work/release/mapping.txt" ] || fail 'release has no R8 mapping.txt; refusing to test an unoptimized APK'
"$HEY_ANDROID_RUBY" -rjson -rdigest -e '
  dir = ARGV.fetch(0); r = JSON.parse(File.read(File.join(dir, "receipt.json")))
  raise "not a non-debug release" unless r.dig("apk", "signing") == "release" && r.dig("apk", "debuggable") == false
  raise "APK receipt mismatch" unless r.dig("apk", "sha256") == Digest::SHA256.file(File.join(dir, "app.apk")).hexdigest
  optimizer = r.fetch("optimizer")
  raise "receipt is not R8 release" unless optimizer.fetch("name") == "R8" && optimizer.fetch("mode") == "release"
  raise "mapping receipt mismatch" unless optimizer.fetch("mapping").fetch("file") == "mapping.txt" && optimizer.fetch("mapping").fetch("sha256") == Digest::SHA256.file(File.join(dir, "mapping.txt")).hexdigest
  mapping = File.read(File.join(dir, "mapping.txt"))
  raise "no obfuscation evidence" unless mapping.lines.any? { |line| m = /\A(hey\.android\.api\.[^ ]+) -> ([^:]+):\s*$/.match(line); m && m[1] != m[2] }
' "$work/release" || fail 'release identity or R8 obfuscation evidence'
cp "$work/release/receipt.json" "$work/release/mapping.txt" "$evidence/"
hey_android_sha256 "$work/release/app.apk" > "$evidence/optimized-apk.sha256"
pass 'release APK is non-debuggable, receipt matches bytes, mapping proves renderer obfuscation'
"$ROOT/tools/hey-android-emulator.sh" create-avd > "$work/avd.log" 2>&1
boot_line=$("$ROOT/tools/hey-android-emulator.sh" boot 2> "$work/boot.log")
serial=$(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^serial=//p')
[ -n "$serial" ] || fail 'emulator boot returned no serial'
adbs install -r "$work/release/app.apk" > "$work/install.log" 2>&1
adbs logcat -c
adbs shell am start -W -n "$package/$activity" > "$work/launch.log" 2>&1
drive wait 'R8 local form' 30
drive wait 'Dictate Note' 10
drive tap Validate
drive wait 'Name is needed.' 10
drive type Name 'R8-sentinel'
drive type Note 'optimized-prose'
adbs shell input keyevent 111
drive wait 'optimized-prose' 10
drive shot "$evidence/01-optimized-form.png"
pass 'optimized Activity boots, draws form/dictation affordance, validates and accepts native field edits'
adbs shell dumpsys activity providers > "$evidence/providers.txt"
grep -q "$package/hey.android.api.HeyAndroidShareProvider" "$evidence/providers.txt" || fail 'framework did not instantiate the private share provider'
pass 'framework instantiated preserved share ContentProvider in release process'
drive tap 'Open local search'
drive wait 'R8 local search' 10
drive wait 'Search by voice' 10
drive type 'R8 local search' 'sentinel'
drive wait Cancel 10
drive tap Cancel
drive wait 'Local search is ready.' 10
drive shot "$evidence/02-optimized-search.png"
adbs shell input keyevent 4
drive wait 'R8 local form' 10
drive tap 'Open local list'
drive wait 'Return to form' 10
drive shot "$evidence/03-optimized-list.png"
drive tap 'Return to form'
drive wait 'R8 local form' 10
pass 'optimized search/voice affordance, cancel listener, local list and navigation work offline'
adbs shell am startservice -n "$package/hey.android.api.HeyAndroidAudioService" > "$work/service.log" 2>&1
drive logwait 'audio service: ready' 15
adbs shell dumpsys media_session > "$evidence/media-session.txt"
grep -q "$package" "$evidence/media-session.txt" || fail 'release media service published no framework media session'
pass 'framework creates preserved AudioService and its active MediaSession'
adbs logcat -d -b crash > "$evidence/positive-crash.txt"
if grep -q "$package" "$evidence/positive-crash.txt"; then fail 'optimized release crashed before negative control'; fi
# Mutate a COPY of the R8 dex; production classes are never recompiled/re-dexed.
mkdir -p "$work/negative"
unzip -p "$work/release/app.apk" classes.dex > "$work/negative/original.dex"
"$HEY_ANDROID_RUBY" "$ROOT/specs/support/r8/drop_activity.rb" "$work/negative/original.dex" "$work/negative/classes.dex" > "$evidence/negative-mutation.txt"
cp "$work/release/app.apk" "$work/negative/base.apk"
(cd "$work/negative" && zip -q -X base.apk classes.dex)
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
"$bt/zipalign" -P 16 -f 4 "$work/negative/base.apk" "$work/negative/aligned.apk"
env JAVA_HOME="$java_home" "$bt/apksigner" sign --ks "$work/fixture.jks" --ks-key-alias upload \
  --ks-pass env:HEY_ANDROID_R8_FIXTURE_PASS --key-pass env:HEY_ANDROID_R8_FIXTURE_PASS \
  --v4-signing-enabled false --out "$work/negative/app.apk" "$work/negative/aligned.apk"
env JAVA_HOME="$java_home" "$bt/apksigner" verify "$work/negative/app.apk"
adbs shell am force-stop "$package"
adbs install -r "$work/negative/app.apk" > "$work/negative-install.log" 2>&1
adbs logcat -c
adbs shell am start -W -n "$package/$activity" > "$work/negative-launch.log" 2>&1 || true
for _ in $(seq 1 15); do
  adbs logcat -d -b crash > "$evidence/negative-crash.txt"
  grep -q 'ClassNotFoundException.*hey.android.api.HeyAndroidApiActivity' "$evidence/negative-crash.txt" && break
  sleep 1
done
grep -q 'ClassNotFoundException.*hey.android.api.HeyAndroidApiActivity' "$evidence/negative-crash.txt" || fail 'negative control did not detect the missing Activity'
pass 'negative control: renaming the manifest Activity in optimized dex makes framework launch fail'
echo "Evidence: $evidence"
