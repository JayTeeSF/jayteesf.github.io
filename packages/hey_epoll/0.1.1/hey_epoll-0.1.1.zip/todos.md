# Todo

1. An io_uring backend (multishot accept/recv, provided buffers) behind the same API, selected at open.
2. IPv6 listeners.
3. A per-connection idle deadline option (today idle keep-alive connections stay open until the peer closes).
