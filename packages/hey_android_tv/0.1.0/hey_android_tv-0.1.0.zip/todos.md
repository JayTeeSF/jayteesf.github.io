# Todo

1. Emulator receipt.
2. Physical TV receipt.
3. Play publication structure.
