# Todo

1. The x86 decision: hey_fast_web `single` and hey_web's readiness lane, epoll
   vs io_uring, on real x86 Linux (asked of the linux seat 2026-10-14). If
   io_uring wins there, hey_poller selects it on Linux (epoll stays the
   fallback).
2. Zero-copy send (`IORING_OP_SEND_ZC`) for large replies, measured first: it
   pays only above a few KiB per send.
3. Receive bundles (6.10) to take several buffers in one completion.
4. IPv6 listeners (with hey_epoll, hey_kqueue and hey_iocp, so the API stays equal).
5. An idle deadline per connection (a linked timeout), with the other backends.
