// HeyIOSAudio: the audio playback capability.
//
// Plays ONE row at a time:
//   {title, subtitle, image_url, kind,
//    audio_url | audio_urls: [page 0, page 1, ...],
//    position_page, position_seconds}          through AVQueuePlayer, or
//   {apple_music_id}                             through MPMusicPlayerController's
//                                                application queue player, for a
//                                                subscriber.
// A row with several audio_urls (an article read aloud a page at a time) plays
// them in order and resumes at position_page / position_seconds.
//
// Owns the AVAudioSession playback category (the app's Info.plist must carry
// UIBackgroundModes=audio), the lock screen and car Now Playing information,
// and the remote commands (play, pause, toggle, stop). Reports where the
// listener is through positionReporter: every reportInterval seconds while
// playing, on pause, when another row replaces this one, and once with
// finished=YES after the last page ends.
//
// It decides nothing about WHAT may be played: the caller hands it rows a
// server already filtered. HeyIOSAudioRowPlayable is a shape check only.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSNotificationName const HeyIOSAudioStateDidChange;

typedef NS_ENUM(NSInteger, HeyIOSAudioState) {
  HeyIOSAudioStateIdle = 0,
  HeyIOSAudioStateLoading,
  HeyIOSAudioStatePlaying,
  HeyIOSAudioStatePaused,
  HeyIOSAudioStateFailed
};

typedef void (^HeyIOSAudioPositionReporter)(NSDictionary *row, NSInteger seconds, NSInteger page, BOOL finished);
// The address to play for an audio address: the same one, another (a
// short-lived signed address from the app's own server), or nil and why not.
// `done` may be called on any queue.
typedef void (^HeyIOSAudioAddressResolver)(NSURL *url, void (^done)(NSURL *_Nullable playable, NSString *_Nullable failure));

@interface HeyIOSAudio : NSObject
+ (instancetype)shared;
@property(nonatomic, readonly) HeyIOSAudioState state;
@property(nonatomic, readonly, copy, nullable) NSDictionary *currentRow;
@property(nonatomic, readonly) NSInteger currentPage;
@property(nonatomic, readonly, copy, nullable) NSString *lastError;
@property(nonatomic, copy, nullable) HeyIOSAudioPositionReporter positionReporter;
// NO CREDENTIAL RIDES ON AN AUDIO FETCH (hey_ios 0.4.0). Every page is played
// from a plain AVURLAsset with no options. An address that needs authorising
// is handed to resolveAddress just before its page plays, and once more when a
// playing page fails (a signed address may have run out during a pause). nil
// plays every address as it is.
@property(nonatomic, copy, nullable) HeyIOSAudioAddressResolver resolveAddress;
@property(nonatomic, assign) NSTimeInterval reportInterval;
- (void)playRow:(NSDictionary *)row;
- (void)togglePlayPause;
- (void)stop;
@end

// A row carries something this module can play: an http(s) audio_url, or an
// apple_music_id when appleMusicAvailable.
BOOL HeyIOSAudioRowPlayable(NSDictionary *row, BOOL appleMusicAvailable);

// Apple Music catalogue playback is available: the user authorised media
// library access earlier AND the account can play catalogue tracks. Never
// prompts; the completion runs on the main queue.
void HeyIOSAudioCheckAppleMusic(void (^completion)(BOOL available));

NS_ASSUME_NONNULL_END
