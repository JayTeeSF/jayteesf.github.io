# In progress

v0.2.2 updates the package for the stable `hey native` command and the shared `hey_packager` controls. The API, C wrapper, prepared query/execute paths, blobs, transactions, interpreter receipt, and native-C receipt are implemented. Darwin is verified by the package maintainer through `bin/check`; native Windows loading remains gated by Hey's Windows extension-loader milestone.
