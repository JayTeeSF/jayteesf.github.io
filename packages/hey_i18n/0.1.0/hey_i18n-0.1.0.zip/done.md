# Done

- 0.1.0: extracted the pure catalog/chain i18n kernel from the
  RecallCoach prototype; folded catalog-aware Accept-Language negotiation
  into locale_for_request.
