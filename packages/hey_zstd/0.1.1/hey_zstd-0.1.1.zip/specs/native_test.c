#include "hey_native_abi.h"
#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include "hey_zstd.h"
static HeyNativeUtf8View text(const char *s){return (HeyNativeUtf8View){s,strlen(s)};}
int main(int argc,char **argv){
 assert(argc==2);const char *path=argv[1];const uint8_t data[]="tabs\tlines\n日本語\0end";size_t size=sizeof(data)-1;
 HeyNativeHandle w=zstd_writer_open(text(path),3);assert(w);assert(!zstd_writer_open(text(path),3));
 assert(zstd_writer_write(w,(HeyNativeBytesView){data,size})==0);assert(zstd_writer_close(w)==0);
 HeyNativeHandle r=zstd_reader_open(text(path),4096);assert(r);size_t seen=0;
 for(;;){HeyNativeOwnedBytes out=zstd_reader_read(r,3);assert(out.data);if(!out.length){out.release(out.context,out.data,out.length);break;}
 assert(seen+out.length<=size && !memcmp(out.data,data+seen,out.length));seen+=out.length;out.release(out.context,out.data,out.length);}
 assert(seen==size && zstd_reader_close(r)==0);
 r=zstd_reader_open(text(path),1);assert(r);HeyNativeOwnedBytes out=zstd_reader_read(r,4096);assert(!out.data && zstd_reader_error(r)==5);assert(zstd_reader_close(r)!=0);
 FILE *f=fopen(path,"ab");assert(f);fputc(1,f);fclose(f);r=zstd_reader_open(text(path),4096);assert(r);
 out=zstd_reader_read(r,4096);assert(!out.data && zstd_reader_error(r)==4);assert(zstd_reader_close(r)!=0);
 assert(truncate(path,10)==0);r=zstd_reader_open(text(path),4096);assert(r);out=zstd_reader_read(r,4096);assert(!out.data);assert(zstd_reader_close(r)!=0);
 assert(unlink(path)==0);puts("PASS: bounded exact zstd, exclusive output, expansion/truncation/trailing refusal");return 0;
}
