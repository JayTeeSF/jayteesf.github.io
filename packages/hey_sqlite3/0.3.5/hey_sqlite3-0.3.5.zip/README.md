# hey_sqlite3 0.3.2

`hey_sqlite3` is an independently versioned SQLite package for the current Hey native-extension interface. It uses a real native extension built over Hey's ABI-v2 FFI and exposes a connection contract consumed by `hey_record`.

## Plumbing and porcelain

- `native/hey_sqlite3.c`, `native/hey_sqlite3_load_extension.c`, `native/hey_sqlite3.h`, `hey.native.json`, and `Native.hey` are **plumbing**. They own C signatures, opaque handles, blocking metadata, bindings, stepping, extension loading, and deterministic cleanup.
- `adapter.hey` is **porcelain**. `Sqlite3.connect`, `query_params`, `execute_params`, transactions, typed rows, and the `hey_record` callback shape live here.
- `extensions.hey` is an audited public bridge for packages such as `hey_honker` that need to load a SQLite extension without receiving or inspecting the native `sqlite3*` handle.
- Hey itself owns only the generic native ABI, loader, package manager, and conformance fixtures. SQLite release policy and API evolution belong to this package.

## Build the native library

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
./bin/build-native
```

The default output is `.native-build/<target>/libhey_sqlite3.*`. Applications should build outside the immutable installed package, for example:

```sh
PACKAGE="$PWD/.hey/packages/hey_sqlite3/0.3.2"
OUT="$PWD/.hey/native/hey_sqlite3/0.3.2/darwin-arm64"
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" "$PACKAGE/bin/build-native" --out "$OUT"
export HEY_SQLITE3_LIBRARY="$OUT/libhey_sqlite3.dylib"
```

Linux uses `.so`. Windows awaits Hey's native Windows extension-loader promotion.

## Use it

```hey
import 'pkg:hey_sqlite3@0.3.2/main'

let opened = Sqlite3.connect('app.sqlite3', {})
let database = opened.value

Sqlite3.execute(database,
  'CREATE TABLE IF NOT EXISTS cards (id INTEGER PRIMARY KEY, name TEXT NOT NULL)')

Sqlite3.execute_params(database,
  'INSERT INTO cards (name) VALUES (?)',
  ['Ada'])

let cards = Sqlite3.query_params(database,
  'SELECT id, name FROM cards WHERE name = ?',
  ['Ada'])

Sqlite3.close(database)
```

Database calls are marked blocking. Own each connection and its statements from one bounded worker or partitioned Job lane.

## PostgreSQL-compatible `greatest()` / `least()`

Every connection `Sqlite3.connect` opens carries `greatest()` and `least()` as
real SQLite scalar functions, registered natively (`sqlite3_create_function_v2`)
inside `hey_sqlite3_open`. No API change and no opt-in: caller SQL can just say
`greatest(a, b)`.

They follow PostgreSQL, not SQLite: NULL arguments are **ignored**, and the
result is NULL only when **every** argument is NULL. SQLite ships no
`greatest`/`least` at all, and its multi-argument `max()`/`min()` return NULL if
*any* argument is NULL:

```
SELECT max(NULL, 5)       ->  NULL     -- SQLite's max
SELECT greatest(NULL, 5)  ->  5        -- PostgreSQL semantics, this package
SELECT greatest(NULL, NULL) IS NULL    -- 1: all arguments null
```

That difference is why an application whose SQL was written for PostgreSQL and
rewritten `GREATEST(` -> `max(` changes answers silently as soon as an argument
is nullable.

Both are variadic (one or more arguments) and compare using SQLite's own value
ordering -- NULL < INTEGER/REAL < TEXT < BLOB, numeric comparison across
INTEGER/REAL, bytewise BINARY comparison for TEXT and BLOB -- so
`greatest(2, 'a')` is `'a'` and `greatest(2, 10.5)` is `10.5`. Text always
compares under BINARY: the public `sqlite3_value_*` API exposes no hook onto a
surrounding `COLLATE NOCASE`. `specs/greatest_least_spec.hey` is the contract.

Both live in C, so a consumer on an older build picks them up only after the
native library is rebuilt from the installed package copy (`bin/build-native`).

## Safe loadable-extension bridge

0.3.2 adds a generic extension-loading surface for higher-level packages:

```hey
import 'pkg:hey_sqlite3@0.3.2/main'
import 'pkg:hey_sqlite3@0.3.2/extensions'

let opened = Sqlite3.connect('app.sqlite3', {})
let loaded = Sqlite3Extensions.load(opened.value, '/path/to/extension', 'optional_entrypoint')
```

The driver remains the only owner of `sqlite3*`. The native bridge temporarily enables extension loading, loads exactly the requested library, and disables extension loading again before returning. A missing/invalid library is a typed `sqlite3_load_extension_failed` Result. `specs/load_extension_spec.hey` is a `stdlib:Minispec` contract for this behavior.

This surface is intentionally generic; `hey_sqlite3` contains no Honker-specific code.

## hey_record connection contract

`Sqlite3.connect(database, options)` returns a plain record satisfying the
`hey_record_connection` contract hey_record 0.3.0's `HeyRecordStore` rides
on: a `dialect` field (`'sqlite3'`), the callable set `query`,
`query_params`, `execute`, `execute_params` (plus `begin`, `commit`,
`rollback`, `close`, and `interrupt`), and execute results that carry
`changes` (affected rows) and `last_insert_id`. The `changes` field is what
lets the store's delete report an absent record as the typed error
`not_found` instead of a silent ok. `specs/store_conformance_spec.hey`
proves the store round-trip (store/fetch/delete/list, delete-absent ->
`not_found`) over a real file database; it drives a hand-copied copy of the
store's sqlite3-dialect SQL rather than a locked hey_record dependency,
because hey_record is the consumer of this adapter, not a dependency of it.

### Connect-surface asymmetry

`Sqlite3.connect(database, options)` is positional where
`Mysql.connect(options)` takes one options record. For consumers that want
one shape across adapters, `Sqlite3.connect_options(options)` accepts the
database inside the record:

```hey
let opened = Sqlite3.connect_options({database: 'app.sqlite3'})
```

A missing or empty `database` entry is the typed refusal
`sqlite3_database_missing`. The positional `connect` stays supported
unchanged.

## Version single source

The in-source version literal lives in exactly one place:
`hey_sqlite3_version_value()` in `adapter.hey`. `Sqlite3.version()` and
`HeySqlite3Info.version()` both read it, the native library search path
(`.hey/native/hey_sqlite3/<version>/`) is derived from it, and
`bin/package-check` both greps that literal against the `VERSION` file and
runs `tools/version_receipt.hey` (interpreter and compiled) against
`VERSION`.

## Compiler-lane receipt status

The package gate runs the interpreter/native C receipts and the real SQLite store conformance. The richer callback-bearing adapter remains an explicit LLVM probe rather than a claimed default-LLVM parity surface until the compiler lane supports it.

## Current release boundary

This release links a system SQLite development library discovered through `pkg-config sqlite3` or `-lsqlite3`. A future package release should contain a checksum-pinned amalgamation and license/provenance receipt for reproducible Darwin, Linux, and Windows builds.

## Standard package controls

This package uses `hey_packager` for validation, release construction, source handoff, and immutable registry publication.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_sqlite3`.
