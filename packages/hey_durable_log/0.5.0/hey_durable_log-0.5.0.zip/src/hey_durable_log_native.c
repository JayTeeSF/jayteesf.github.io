/* The retained registry keys journals by device and inode, and -std=c11 defines
   __STRICT_ANSI__, under which glibc exposes neither those types nor stat().
   Same macro, and for the same reason, as src/hey_durable_log.c. */
#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log_native.h"
#include "hey_durable_log.h"

#include <limits.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct hey_durable_log_retained hey_durable_log_retained;

typedef struct {
  hdl_log *log;
  hdl_broker *broker;
  /* NULL for a plain open. Set when this connection is shared through the
     retained registry, which is what routes close to a reference drop instead
     of a real close. */
  hey_durable_log_retained *retained;
} hey_durable_log_connection;

/* Process-wide retained journals.
 
   A Distributed Hey call handler cannot be handed a journal that `program`
   opened: Hey has no top-level mutable state, no closures, and no synchronous
   ask an actor could answer. What a handler CAN do is name the path. So
   retention lives here, in the layer that is allowed process state, and the
   handler re-derives the handle rather than capturing it.
 
   This shares nothing that was independent before. flock is per open-file-
   description, so a second open of a journal this process already holds is
   refused HDL_LOCKED today (see the comment on hdl_log->lock_fd, which is why
   POSIX record locks were rejected). The registry turns that in-process
   refusal into a defined, reference-counted share -- and holds the writer lock
   unbroken for the life of the process, closing the window a follower had
   between two replicated records.
 
   Keyed by DEVICE AND INODE rather than by the path string. Two spellings of
   one directory must not become two entries -- flock would then refuse the
   second rather than share it, and the caller would be told 'locked' about a
   journal it already owns. Comparing strings would miss './journal' against
   'journal'; resolving them first would still miss a symlink, a bind mount, or
   the same volume mounted twice, all of which a container arrangement produces
   routinely. What the kernel locks is the file, so the file is what this keys
   on. (An inode number can be reused after a directory is deleted and
   recreated, which would carry `opens` across to an unrelated journal. It is a
   diagnostic count and the entry holds no connection at that point, so nothing
   but the number is affected.)
 
   An entry outlives its last reference so `opens` keeps counting real recovery
   scans across a close-and-reopen cycle. That count is the gate rather than a
   claim: a follower that reopened per record reports N, and one that retains
   reports 1. */
struct hey_durable_log_retained {
  hey_durable_log_retained *next;
  dev_t device;
  ino_t inode;
  hey_durable_log_connection *connection;
  uint32_t references;
  int64_t opens;
  int32_t queue_capacity;
  int32_t max_batch_records;
  int32_t batch_window_microseconds;
  int64_t segment_size_bytes;
};

static hey_durable_log_retained *retained_journals = NULL;
static pthread_mutex_t retained_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
  hdl_status status;
  hdl_receipt value;
} hey_durable_log_receipt;

typedef struct {
  hdl_status status;
  hdl_broker_stats value;
} hey_durable_log_stats;

typedef struct {
  hdl_status status;
  uint64_t sequence;
  uint64_t batch_id;
  uint64_t stream_id;
  uint8_t *payload;
  uint32_t payload_length;
  uint64_t position;
  uint64_t next_position;
  uint32_t digest;
  uint64_t leader_epoch;
} hey_durable_log_record;

static char *copy_utf8(HeyNativeUtf8View value) {
  char *copy = malloc(value.length + 1);
  if (copy == NULL) return NULL;
  if (value.length > 0 && value.data != NULL) memcpy(copy, value.data, value.length);
  copy[value.length] = '\0';
  return copy;
}

static hey_durable_log_connection *connection_value(HeyNativeHandle handle) {
  return (hey_durable_log_connection *)(uintptr_t)handle;
}

static hey_durable_log_receipt *receipt_value(HeyNativeHandle handle) {
  return (hey_durable_log_receipt *)(uintptr_t)handle;
}

static hey_durable_log_stats *stats_value(HeyNativeHandle handle) {
  return (hey_durable_log_stats *)(uintptr_t)handle;
}

static hdl_cursor *cursor_value(HeyNativeHandle handle) {
  return (hdl_cursor *)(uintptr_t)handle;
}

static hey_durable_log_record *record_value(HeyNativeHandle handle) {
  return (hey_durable_log_record *)(uintptr_t)handle;
}

/* One journal plus its broker, opened for real. Both entry points below share
   it so that a retained open and a plain one cannot drift apart in what they
   configure or in what they clean up on a partial failure. */
static hdl_status open_connection(const char *path,
                                  int32_t queue_capacity,
                                  int32_t max_batch_records,
                                  int32_t batch_window_microseconds,
                                  int64_t segment_size_bytes,
                                  hey_durable_log_connection **out) {
  *out = NULL;
  hey_durable_log_connection *connection = calloc(1, sizeof(*connection));
  if (connection == NULL) return HDL_NOMEM;
  hdl_options journal = {0, 0, 0, 0, (uint64_t)segment_size_bytes};
  hdl_status status = hdl_open(path, &journal, &connection->log);
  if (status == HDL_OK) {
    hdl_broker_options options = {
      (uint32_t)queue_capacity,
      (uint32_t)max_batch_records,
      (uint32_t)batch_window_microseconds
    };
    status = hdl_broker_open(connection->log, &options, &connection->broker);
  }
  if (status != HDL_OK) {
    if (connection->log != NULL) (void)hdl_close(connection->log);
    free(connection);
    return status;
  }
  *out = connection;
  return HDL_OK;
}

/* The identity the kernel would lock, or 0 when there is nothing there yet --
   which is the ordinary case for the very first open of a journal, since
   hdl_open creates the directory. */
static int journal_identity(const char *path, dev_t *device, ino_t *inode) {
  struct stat info;
  if (stat(path, &info) != 0) return 0;
  *device = info.st_dev;
  *inode = info.st_ino;
  return 1;
}

/* Callers hold retained_mutex. */
static hey_durable_log_retained *retained_find(dev_t device, ino_t inode) {
  for (hey_durable_log_retained *entry = retained_journals; entry != NULL;
       entry = entry->next) {
    if (entry->device == device && entry->inode == inode) return entry;
  }
  return NULL;
}

static int retained_bounds_differ(const hey_durable_log_retained *entry,
                                  int32_t queue_capacity,
                                  int32_t max_batch_records,
                                  int32_t batch_window_microseconds,
                                  int64_t segment_size_bytes) {
  return entry->queue_capacity != queue_capacity ||
         entry->max_batch_records != max_batch_records ||
         entry->batch_window_microseconds != batch_window_microseconds ||
         entry->segment_size_bytes != segment_size_bytes;
}

/* Take a reference on the journal at `path`, opening it only if this process is
   not already holding it. Returns an hdl_status, or
   HEY_DURABLE_LOG_RETAINED_CONFLICT when the caller asked for bounds the held
   journal was not opened under -- which is refused rather than silently
   answered with someone else's broker, exactly as a substituted library and a
   defaulted ingress bound are refused elsewhere in this package. */
static int32_t retained_acquire(const char *path,
                                int32_t queue_capacity,
                                int32_t max_batch_records,
                                int32_t batch_window_microseconds,
                                int64_t segment_size_bytes,
                                hey_durable_log_connection **out) {
  *out = NULL;
  pthread_mutex_lock(&retained_mutex);

  /* A journal that is currently held necessarily exists, so failing to stat it
     is not a problem here: there is nothing to share, and the open below both
     creates the directory and settles the question. */
  dev_t device = 0;
  ino_t inode = 0;
  if (journal_identity(path, &device, &inode)) {
    hey_durable_log_retained *held = retained_find(device, inode);
    if (held != NULL && held->references > 0) {
      if (retained_bounds_differ(held, queue_capacity, max_batch_records,
                                 batch_window_microseconds, segment_size_bytes)) {
        pthread_mutex_unlock(&retained_mutex);
        return HEY_DURABLE_LOG_RETAINED_CONFLICT;
      }
      held->references += 1;
      *out = held->connection;
      pthread_mutex_unlock(&retained_mutex);
      return HDL_OK;
    }
  }

  hey_durable_log_connection *connection = NULL;
  hdl_status status = open_connection(path, queue_capacity, max_batch_records,
                                      batch_window_microseconds,
                                      segment_size_bytes, &connection);
  if (status != HDL_OK) {
    pthread_mutex_unlock(&retained_mutex);
    return status;
  }

  hey_durable_log_retained *entry = NULL;
  if (journal_identity(path, &device, &inode)) entry = retained_find(device, inode);
  else {
    /* The journal opened, so the directory is there; if it cannot be stat'd now
       something is wrong enough that sharing it would be a guess. */
    (void)hdl_broker_close(connection->broker);
    (void)hdl_close(connection->log);
    free(connection);
    pthread_mutex_unlock(&retained_mutex);
    return HDL_IO;
  }
  if (entry == NULL) {
    entry = calloc(1, sizeof(*entry));
    if (entry == NULL) {
      (void)hdl_broker_close(connection->broker);
      (void)hdl_close(connection->log);
      free(connection);
      pthread_mutex_unlock(&retained_mutex);
      return HDL_NOMEM;
    }
    entry->device = device;
    entry->inode = inode;
    entry->next = retained_journals;
    retained_journals = entry;
  }
  /* Reusing the entry a previous holder left behind is what keeps `opens`
     counting across a close-and-reopen cycle. */
  entry->connection = connection;
  entry->references = 1;
  entry->opens += 1;
  entry->queue_capacity = queue_capacity;
  entry->max_batch_records = max_batch_records;
  entry->batch_window_microseconds = batch_window_microseconds;
  entry->segment_size_bytes = segment_size_bytes;
  connection->retained = entry;
  *out = connection;
  pthread_mutex_unlock(&retained_mutex);
  return HDL_OK;
}

/* Drop one reference. The journal closes, and the writer lock releases, only at
   zero -- otherwise the first request handler to finish would close the journal
   under the next one. */
static int32_t retained_release(hey_durable_log_connection *connection) {
  pthread_mutex_lock(&retained_mutex);
  hey_durable_log_retained *entry = connection->retained;
  hdl_status broker_status = HDL_OK;
  hdl_status log_status = HDL_OK;
  if (entry->references > 0) entry->references -= 1;
  if (entry->references == 0) {
    broker_status = hdl_broker_close(connection->broker);
    log_status = hdl_close(connection->log);
    entry->connection = NULL;
    free(connection);
  }
  pthread_mutex_unlock(&retained_mutex);
  return broker_status != HDL_OK ? broker_status : log_status;
}

HeyNativeHandle hey_durable_log_native_open(HeyNativeUtf8View path,
                                             int32_t queue_capacity,
                                             int32_t max_batch_records,
                                             int32_t batch_window_microseconds,
                                             int64_t segment_size_bytes) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0 ||
      segment_size_bytes < 0) return (HeyNativeHandle)0;
  char *path_copy = copy_utf8(path);
  if (path_copy == NULL) return (HeyNativeHandle)0;
  hey_durable_log_connection *connection = NULL;
  hdl_status status = open_connection(path_copy, queue_capacity, max_batch_records,
                                      batch_window_microseconds,
                                      segment_size_bytes, &connection);
  free(path_copy);
  if (status != HDL_OK) return (HeyNativeHandle)0;
  return (HeyNativeHandle)(uintptr_t)connection;
}

/* Retention is a SEPARATE surface on purpose. Making `open` hand back a shared
   handle would give a second consumer a broker whose queue capacity, batch size
   and window it never chose, and would do it silently. A caller that wants to
   share says so. */
HeyNativeHandle hey_durable_log_native_open_retained(HeyNativeUtf8View path,
                                                     int32_t queue_capacity,
                                                     int32_t max_batch_records,
                                                     int32_t batch_window_microseconds,
                                                     int64_t segment_size_bytes) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0 ||
      segment_size_bytes < 0) return (HeyNativeHandle)0;
  char *path_copy = copy_utf8(path);
  if (path_copy == NULL) return (HeyNativeHandle)0;
  hey_durable_log_connection *connection = NULL;
  int32_t status = retained_acquire(path_copy, queue_capacity, max_batch_records,
                                    batch_window_microseconds, segment_size_bytes,
                                    &connection);
  free(path_copy);
  if (status != HDL_OK) return (HeyNativeHandle)0;
  return (HeyNativeHandle)(uintptr_t)connection;
}

/* Classify a failed retained open, the way open_status classifies a failed
   plain one. A CONFLICT is answered without touching the journal: the caller is
   asking why it was refused, and re-running the open to find out would both
   inflate `opens` -- the number the follower gate reads -- and take a reference
   nobody is holding. */
int32_t hey_durable_log_native_open_retained_status(HeyNativeUtf8View path,
                                                    int32_t queue_capacity,
                                                    int32_t max_batch_records,
                                                    int32_t batch_window_microseconds,
                                                    int64_t segment_size_bytes) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0 ||
      segment_size_bytes < 0) return HDL_INVALID;
  char *path_copy = copy_utf8(path);
  if (path_copy == NULL) return HDL_NOMEM;

  int32_t conflict = HDL_OK;
  dev_t device = 0;
  ino_t inode = 0;
  pthread_mutex_lock(&retained_mutex);
  if (journal_identity(path_copy, &device, &inode)) {
    hey_durable_log_retained *held = retained_find(device, inode);
    if (held != NULL && held->references > 0 &&
        retained_bounds_differ(held, queue_capacity, max_batch_records,
                               batch_window_microseconds, segment_size_bytes)) {
      conflict = HEY_DURABLE_LOG_RETAINED_CONFLICT;
    }
  }
  pthread_mutex_unlock(&retained_mutex);
  if (conflict != HDL_OK) {
    free(path_copy);
    return conflict;
  }

  hey_durable_log_connection *connection = NULL;
  hdl_status status = open_connection(path_copy, queue_capacity, max_batch_records,
                                      batch_window_microseconds,
                                      segment_size_bytes, &connection);
  free(path_copy);
  if (status == HDL_OK) {
    (void)hdl_broker_close(connection->broker);
    (void)hdl_close(connection->log);
    free(connection);
  }
  return status;
}

/* How many times this PROCESS actually opened -- and therefore recovery-scanned
   -- the journal behind this handle. The measurement a retention claim needs:
   'we hold it' is exactly the kind of thing that regresses silently, because
   every correctness assertion passes either way. Negative for a plain handle,
   which retains nothing and has nothing to report. */
int64_t hey_durable_log_native_retained_opens(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || connection->retained == NULL) return -1;
  pthread_mutex_lock(&retained_mutex);
  int64_t opens = connection->retained->opens;
  pthread_mutex_unlock(&retained_mutex);
  return opens;
}

int32_t hey_durable_log_native_open_status(HeyNativeUtf8View path,
                                            int32_t queue_capacity,
                                            int32_t max_batch_records,
                                            int32_t batch_window_microseconds,
                                            int64_t segment_size_bytes) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0 ||
      segment_size_bytes < 0) return HDL_INVALID;
  char *path_copy = copy_utf8(path);
  if (path_copy == NULL) return HDL_NOMEM;
  hdl_log *log = NULL;
  hdl_options journal = {0, 0, 0, 0, (uint64_t)segment_size_bytes};
  hdl_status status = hdl_open(path_copy, &journal, &log);
  free(path_copy);
  if (log != NULL) (void)hdl_close(log);
  return status;
}

int32_t hey_durable_log_native_close(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return HDL_INVALID;
  if (connection->retained != NULL) return retained_release(connection);
  hdl_status broker_status = hdl_broker_close(connection->broker);
  hdl_status log_status = hdl_close(connection->log);
  free(connection);
  return broker_status != HDL_OK ? broker_status : log_status;
}

HeyNativeHandle hey_durable_log_native_submit(HeyNativeHandle handle,
                                               int64_t stream_id,
                                               HeyNativeBytesView payload,
                                               int64_t term) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || stream_id <= 0 || payload.length > UINT32_MAX ||
      (payload.length > 0 && payload.data == NULL) || term <= 0) {
    return (HeyNativeHandle)0;
  }
  hey_durable_log_receipt *receipt = calloc(1, sizeof(*receipt));
  if (receipt == NULL) return (HeyNativeHandle)0;
  hdl_record record = {(uint64_t)stream_id, payload.data, (uint32_t)payload.length, (uint64_t)term};
  receipt->status = hdl_broker_submit(connection->broker, &record, &receipt->value);
  return (HeyNativeHandle)(uintptr_t)receipt;
}

/* Submit with a bound on how long the caller waits to be ADMITTED. A negative
   deadline is refused rather than treated as "wait forever": a caller who asked
   for a bound and silently got none is the failure this whole call exists to
   prevent. Zero is the explicit unbounded wait. */
HeyNativeHandle hey_durable_log_native_submit_within(HeyNativeHandle handle,
                                                     int64_t stream_id,
                                                     HeyNativeBytesView payload,
                                                     int64_t admission_timeout_microseconds,
                                                     int64_t term) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || stream_id <= 0 || payload.length > UINT32_MAX ||
      (payload.length > 0 && payload.data == NULL) || term <= 0 ||
      admission_timeout_microseconds < 0 || admission_timeout_microseconds > UINT32_MAX) {
    return (HeyNativeHandle)0;
  }
  hey_durable_log_receipt *receipt = calloc(1, sizeof(*receipt));
  if (receipt == NULL) return (HeyNativeHandle)0;
  hdl_record record = {(uint64_t)stream_id, payload.data, (uint32_t)payload.length, (uint64_t)term};
  receipt->status = hdl_broker_submit_within(connection->broker, &record,
                                             (uint32_t)admission_timeout_microseconds,
                                             &receipt->value);
  return (HeyNativeHandle)(uintptr_t)receipt;
}

int32_t hey_durable_log_native_receipt_status(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL ? HDL_INVALID : receipt->status;
}

int64_t hey_durable_log_native_receipt_sequence(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.first_sequence > INT64_MAX
           ? -1 : (int64_t)receipt->value.first_sequence;
}

int64_t hey_durable_log_native_receipt_batch_id(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.batch_id > INT64_MAX
           ? -1 : (int64_t)receipt->value.batch_id;
}

int64_t hey_durable_log_native_receipt_durable_offset(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.durable_offset > INT64_MAX
           ? -1 : (int64_t)receipt->value.durable_offset;
}

void hey_durable_log_native_receipt_close(HeyNativeHandle handle) {
  free(receipt_value(handle));
}

/* One SNAPSHOT of the broker's counters, not four separate reads.
   Four calls into a running broker would hand the caller a torn view -- a record
   count from one instant and a queue depth from another -- and the whole point
   of reporting a bound is that the numbers can be compared with each other. */
typedef struct {
  hdl_status status;
  hdl_snapshot value;
} hey_durable_log_snapshot;

static hey_durable_log_snapshot *snapshot_value(HeyNativeHandle handle) {
  return (hey_durable_log_snapshot *)(uintptr_t)handle;
}

/* Snapshot, verify, restore and retire, from the process that OWNS the journal.
   That is not a convenience: a journal has one writer and holds an exclusive
   lock for the life of the handle, so a separate operator binary cannot open a
   live journal to retire anything. The owner is the only process that can, which
   settles where these belong. */
HeyNativeHandle hey_durable_log_native_snapshot_create(HeyNativeHandle handle,
                                                       HeyNativeUtf8View directory) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || directory.data == NULL || directory.length == 0) {
    return (HeyNativeHandle)0;
  }
  char *directory_copy = copy_utf8(directory);
  hey_durable_log_snapshot *snapshot = calloc(1, sizeof(*snapshot));
  if (directory_copy == NULL || snapshot == NULL) {
    free(directory_copy);
    free(snapshot);
    return (HeyNativeHandle)0;
  }
  snapshot->status = hdl_snapshot_create(connection->log, directory_copy, &snapshot->value);
  free(directory_copy);
  return (HeyNativeHandle)(uintptr_t)snapshot;
}

HeyNativeHandle hey_durable_log_native_snapshot_verify(HeyNativeUtf8View directory) {
  if (directory.data == NULL || directory.length == 0) return (HeyNativeHandle)0;
  char *directory_copy = copy_utf8(directory);
  hey_durable_log_snapshot *snapshot = calloc(1, sizeof(*snapshot));
  if (directory_copy == NULL || snapshot == NULL) {
    free(directory_copy);
    free(snapshot);
    return (HeyNativeHandle)0;
  }
  snapshot->status = hdl_snapshot_verify(directory_copy, &snapshot->value);
  free(directory_copy);
  return (HeyNativeHandle)(uintptr_t)snapshot;
}

int32_t hey_durable_log_native_snapshot_restore(HeyNativeUtf8View snapshot_directory,
                                                HeyNativeUtf8View journal_directory) {
  if (snapshot_directory.data == NULL || journal_directory.data == NULL) return HDL_INVALID;
  char *from = copy_utf8(snapshot_directory);
  char *to = copy_utf8(journal_directory);
  hdl_status status = (from == NULL || to == NULL) ? HDL_NOMEM : hdl_snapshot_restore(from, to);
  free(from);
  free(to);
  return status;
}

int32_t hey_durable_log_native_retire(HeyNativeHandle handle, HeyNativeUtf8View directory) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || directory.data == NULL || directory.length == 0) return HDL_INVALID;
  char *directory_copy = copy_utf8(directory);
  if (directory_copy == NULL) return HDL_NOMEM;
  hdl_status status = hdl_retire_snapshotted(connection->log, directory_copy);
  free(directory_copy);
  return status;
}

int32_t hey_durable_log_native_snapshot_status(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL ? HDL_INVALID : snapshot->status;
}

int64_t hey_durable_log_native_snapshot_records(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.records;
}

int64_t hey_durable_log_native_snapshot_first_sequence(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.first_sequence;
}

int64_t hey_durable_log_native_snapshot_last_sequence(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.last_sequence;
}

int64_t hey_durable_log_native_snapshot_digest(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.digest;
}

void hey_durable_log_native_snapshot_close(HeyNativeHandle handle) {
  free(snapshot_value(handle));
}

int32_t hey_durable_log_native_discard_after(HeyNativeHandle handle, int64_t sequence) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || sequence < 0) return HDL_INVALID;
  return hdl_truncate_to(connection->log, (uint64_t)sequence);
}

/* The term the last committed entry originated in. Half of what the election
   restriction ranks by; last_sequence is the other half. */
int64_t hey_durable_log_native_last_leader_epoch(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return -1;
  uint64_t leader_epoch = 0;
  if (hdl_last_leader_epoch(connection->log, &leader_epoch) != HDL_OK || leader_epoch > INT64_MAX) return -1;
  return (int64_t)leader_epoch;
}

int64_t hey_durable_log_native_last_record_digest(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return -1;
  uint32_t digest = 0;
  if (hdl_last_record_digest(connection->log, &digest) != HDL_OK) return -1;
  return (int64_t)digest;
}

int64_t hey_durable_log_native_last_sequence(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return -1;
  uint64_t sequence = 0;
  if (hdl_last_sequence(connection->log, &sequence) != HDL_OK || sequence > INT64_MAX) return -1;
  return (int64_t)sequence;
}

HeyNativeHandle hey_durable_log_native_stats_open(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return (HeyNativeHandle)0;
  hey_durable_log_stats *stats = calloc(1, sizeof(*stats));
  if (stats == NULL) return (HeyNativeHandle)0;
  stats->status = hdl_broker_get_stats(connection->broker, &stats->value);
  return (HeyNativeHandle)(uintptr_t)stats;
}

int32_t hey_durable_log_native_stats_status(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL ? HDL_INVALID : stats->status;
}

int64_t hey_durable_log_native_stats_records(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK || stats->value.records > INT64_MAX
           ? -1 : (int64_t)stats->value.records;
}

int64_t hey_durable_log_native_stats_durable_batches(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK || stats->value.durable_batches > INT64_MAX
           ? -1 : (int64_t)stats->value.durable_batches;
}

int64_t hey_durable_log_native_stats_largest_batch(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK ? -1 : (int64_t)stats->value.largest_batch;
}

int64_t hey_durable_log_native_stats_max_queue_depth(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK ? -1 : (int64_t)stats->value.max_queue_depth;
}

int64_t hey_durable_log_native_stats_window_waits(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK ? -1 : (int64_t)stats->value.window_waits;
}

void hey_durable_log_native_stats_close(HeyNativeHandle handle) {
  free(stats_value(handle));
}

HeyNativeHandle hey_durable_log_native_cursor_open(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return (HeyNativeHandle)0;
  hdl_cursor *cursor = NULL;
  if (hdl_cursor_open(connection->log, &cursor) != HDL_OK) return (HeyNativeHandle)0;
  return (HeyNativeHandle)(uintptr_t)cursor;
}

HeyNativeHandle hey_durable_log_native_cursor_next(HeyNativeHandle handle) {
  hdl_cursor *cursor = cursor_value(handle);
  if (cursor == NULL) return (HeyNativeHandle)0;
  hey_durable_log_record *record = calloc(1, sizeof(*record));
  if (record == NULL) return (HeyNativeHandle)0;
  hdl_cursor_record value;
  record->status = hdl_cursor_next(cursor, &value);
  if (record->status == HDL_OK) {
    record->sequence = value.sequence;
    record->batch_id = value.batch_id;
    record->stream_id = value.stream_id;
    record->position = value.position;
    record->next_position = value.next_position;
    record->digest = value.digest;
    record->leader_epoch = value.leader_epoch;
    record->payload_length = value.payload_length;
    if (value.payload_length > 0) {
      record->payload = malloc(value.payload_length);
      if (record->payload == NULL) {
        record->status = HDL_NOMEM;
        record->payload_length = 0;
      } else {
        memcpy(record->payload, value.payload, value.payload_length);
      }
    }
  }
  return (HeyNativeHandle)(uintptr_t)record;
}

int32_t hey_durable_log_native_cursor_close(HeyNativeHandle handle) {
  return hdl_cursor_close(cursor_value(handle));
}

int32_t hey_durable_log_native_record_status(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL ? HDL_INVALID : record->status;
}

int64_t hey_durable_log_native_record_sequence(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->sequence > INT64_MAX
           ? -1 : (int64_t)record->sequence;
}

/* Where this record sits, and where the next one starts. A Hey materializer
   stores next_position and hands it back to cursor_open_at, which is what stops
   it re-reading everything it has already applied. */
int64_t hey_durable_log_native_record_position(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->position > INT64_MAX
           ? -1 : (int64_t)record->position;
}

/* The term this replayed entry originated in, preserved from its own frame. */
int64_t hey_durable_log_native_record_leader_epoch(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK ? -1 : (int64_t)record->leader_epoch;
}

int64_t hey_durable_log_native_record_digest(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK ? -1 : (int64_t)record->digest;
}

int64_t hey_durable_log_native_record_next_position(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->next_position > INT64_MAX
           ? -1 : (int64_t)record->next_position;
}

HeyNativeHandle hey_durable_log_native_cursor_open_at(HeyNativeHandle handle, int64_t position) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || position < 0) return (HeyNativeHandle)0;
  hdl_cursor *cursor = NULL;
  if (hdl_cursor_open_at(connection->log, (uint64_t)position, &cursor) != HDL_OK) {
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)cursor;
}

int64_t hey_durable_log_native_record_batch_id(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->batch_id > INT64_MAX
           ? -1 : (int64_t)record->batch_id;
}

int64_t hey_durable_log_native_record_stream_id(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->stream_id > INT64_MAX
           ? -1 : (int64_t)record->stream_id;
}

HeyNativeBytesView hey_durable_log_native_record_payload(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  if (record == NULL || record->status != HDL_OK) return (HeyNativeBytesView){NULL, 0};
  return (HeyNativeBytesView){record->payload, record->payload_length};
}

void hey_durable_log_native_record_close(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  if (record == NULL) return;
  free(record->payload);
  free(record);
}
