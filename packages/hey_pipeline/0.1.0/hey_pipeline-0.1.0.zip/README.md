# hey_pipeline

Local-first, fail-closed CI/CD orchestration for Hey projects.

`hey_pipeline` extracts the successful local-gate model developed in `JayTeeSF/MMeow` and makes it reusable across the Hey ecosystem. GitHub may still provide useful supplementary checks, but private Hey correctness and release authority run on the machine that actually owns the compiler, native dependencies, Docker images, databases, and credentials.

## Principles

- Missing prerequisites are RED, never silent SKIP.
- Independent lanes run in parallel by default.
- Heavy work is bounded explicitly with resource groups instead of globally single-tracking the pipeline.
- Application-specific test scripts stay in the application; `hey_pipeline` orchestrates them.
- Development receipts may describe a dirty tree; release receipts may not.
- Release receipts bind GREEN evidence to an exact Git SHA and manifest hash.
- The runner itself uses only Python's standard library so it can diagnose a missing/broken Hey compiler.

## Quick start

Create `hey-pipeline.json` in the project root, then run:

```sh
$HOME/dev/hey_pipeline/bin/hey-pipeline run hey-pipeline.json
```

A fast profile:

```sh
$HOME/dev/hey_pipeline/bin/hey-pipeline run hey-pipeline.json --profile fast
```

A release candidate:

```sh
candidate="$(git rev-parse HEAD)"
$HOME/dev/hey_pipeline/bin/hey-pipeline run hey-pipeline.json --release --sha "$candidate"
$HOME/dev/hey_pipeline/bin/hey-pipeline verify-receipt ".hey/pipeline/$candidate.json" --release --sha "$candidate"
```

Projects should ignore `.hey/pipeline/`; these are local evidence artifacts, not source files.

See `docs/MANIFEST.md` for the generic contract and `docs/MMEOW_RETROFIT.md` for the reference migration.
