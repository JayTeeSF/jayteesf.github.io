require 'json'
require 'fileutils'
require 'tmpdir'
require 'open3'

root = File.expand_path('..', __dir__)
hey_root = ENV.fetch('HEY_ROOT', File.expand_path('../hey-lang-bootstrap-plan', root))
version = JSON.parse(File.read(File.join(root, 'hey-package.json'))).fetch('dependencies').fetch('hey_zstd')
package = File.join(root, '.hey/packages/hey_zstd', version)
FileUtils.mkdir_p(File.join(root, 'build'))
Dir.mktmpdir('restore-cleanup-', File.join(root, 'build')) do |directory|
  library, status = Open3.capture2(File.join(package, 'bin/build-native'), File.join(directory, 'native'))
  raise 'fixture codec build failed' unless status.success?
  binary = File.join(directory, 'receipt')
  system(File.join(hey_root, 'bin/heyc'), 'build', File.join(root, 'specs/restore_cleanup.hey'), '-o', binary, out: File::NULL, exception: true)
  out, err, status = Open3.capture3({'ZSTD_LIBRARY'=>library.strip, 'CLEANUP_DIRECTORY'=>directory}, binary)
  raise "restore cleanup receipt failed: #{out}; #{err}" unless status.success? && out == "true\n" * 14
end
puts 'PASS: decoded files removed after success and six failures; unrelated cache file preserved'
