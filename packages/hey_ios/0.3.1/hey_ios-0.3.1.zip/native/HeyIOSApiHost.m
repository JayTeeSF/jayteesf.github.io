#import "HeyIOSApiHost.h"
#import "HeyIOSKeychain.h"
#import "HeyIOSAudio.h"
#import "HeyIOSValues.h"
#import <AuthenticationServices/AuthenticationServices.h>
#import <AVKit/AVKit.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>

static const char *(*HeyIOSManifestFunction)(void) = NULL;
static int64_t (*HeyIOSContractFunction)(int64_t) = NULL;
static NSString *const HeyIOSSignedOutNotification = @"HeyIOSSignedOutNotification";
NSNotificationName const HeyIOSApiHostAudioFeedDidChange = @"HeyIOSApiHostAudioFeedDidChange";

// What the audio feed lists may have changed: another scene showing it re-reads.
static void HeyIOSAudioFeedChanged(void) {
  [[NSNotificationCenter defaultCenter] postNotificationName:HeyIOSApiHostAudioFeedDidChange object:nil];
}

void HeyIOSApiHostStart(const char *(*manifest)(void), int64_t (*contract)(int64_t)) {
  HeyIOSManifestFunction = manifest;
  HeyIOSContractFunction = contract;
}

#pragma mark - values

// THE VALUE LANGUAGE LIVES IN HeyIOSValues: paths, templates, lines,
// conditions, body values, parameters, the kinds this renderer draws and
// whether a served description is taken. Foundation only, so bin/conformance
// runs hey_mobile's vectors against the same code on a Mac.
static inline NSDictionary *HD(id v) { return HeyIOSDict(v); }
static inline NSArray *HA(id v) { return HeyIOSArray(v); }
static inline NSString *HS(id v) { return HeyIOSString(v); }

@interface HeyIOSApi : NSObject
+ (instancetype)shared;
// The description being drawn: the baked copy, the last good served copy this
// build stored, or a served copy that arrived while the app ran (source says
// which), always with the baked copy's origin, session and store names.
@property(nonatomic, strong) NSDictionary *manifest;
@property(nonatomic, strong) NSDictionary *baked;
@property(nonatomic, copy) NSString *bakedETag;
@property(nonatomic, strong) NSData *bakedData;
@property(nonatomic, copy) NSString *heldETag;
@property(nonatomic, copy) NSString *source;
@property(nonatomic, strong, nullable) NSDictionary *pending;
@property(nonatomic, copy, nullable) NSString *pendingETag;
@property(nonatomic, assign) BOOL fetching;
@property(nonatomic, copy) NSString *origin;
@property(nonatomic, copy, nullable) NSString *failure;
- (void)refreshDescription:(void (^)(BOOL arrived))done;
- (BOOL)applyPending;
- (nullable NSString *)token;
- (BOOL)setToken:(NSString *)token;
- (void)clearToken;
- (NSDictionary *)screenNamed:(NSString *)name;
- (void)send:(NSDictionary *)route vars:(NSDictionary *)vars row:(nullable id)row completion:(void (^)(NSInteger status, id _Nullable json, NSString *_Nullable error))completion;
- (void)sendText:(NSString *)text route:(NSDictionary *)route vars:(NSDictionary *)vars completion:(void (^)(NSInteger status, id _Nullable json, NSString *_Nullable error))completion;
@end

// Templates read the app's labels ({label:x}) from the description in use.
static NSDictionary *HeyIOSLabels(void);
#define HeyIOSRender(spec, obj) HeyIOSRender((spec), (obj), HeyIOSLabels())
#define HeyIOSLine(spec, obj) HeyIOSLine((spec), (obj), HeyIOSLabels())
#define HeyIOSText(spec, obj) HeyIOSText((spec), (obj), HeyIOSLabels())

// Written by the build tool: the server origin baked beside the description,
// or NULL for a shell that bakes it inside the description (hey_ios 0.2.0).
extern const char *HeyIOSBakedOrigin(void);

static NSAttributedString *HeyIOSStyled(NSString *text, UIFont *font, UIColor *color) {
  NSMutableAttributedString *out = [[NSMutableAttributedString alloc] init];
  NSDictionary *plain = @{NSFontAttributeName: font, NSForegroundColorAttributeName: color};
  UIImageSymbolConfiguration *config = [UIImageSymbolConfiguration configurationWithFont:font scale:UIImageSymbolScaleSmall];
  [text enumerateSubstringsInRange:NSMakeRange(0, text.length) options:NSStringEnumerationByComposedCharacterSequences usingBlock:^(NSString *ch, NSRange r, NSRange er, BOOL *stop) {
    NSString *symbol = [ch isEqualToString:@"★"] ? @"star.fill" : ([ch isEqualToString:@"⯪"] ? @"star.leadinghalf.filled" : ([ch isEqualToString:@"☆"] ? @"star" : nil));
    if (symbol == nil) { [out appendAttributedString:[[NSAttributedString alloc] initWithString:ch attributes:plain]]; return; }
    NSTextAttachment *star = [[NSTextAttachment alloc] init];
    star.image = [[UIImage systemImageNamed:symbol withConfiguration:config] imageWithTintColor:[UIColor systemOrangeColor] renderingMode:UIImageRenderingModeAlwaysOriginal];
    [out appendAttributedString:[NSAttributedString attributedStringWithAttachment:star]];
  }];
  return out;
}

// FIVE STARS, TEN ANSWERS: the left half of a star is the half, the right
// half the whole. A control, not a list of ten menu rows (which a phone cuts
// off). Sends UIControlEventValueChanged; value is halves 0..10.
@interface HeyIOSStarControl : UIControl
@property(nonatomic, assign) NSInteger halves;
@property(nonatomic, strong) NSArray<UIImageView *> *stars;
@end

@implementation HeyIOSStarControl
- (instancetype)initWithFrame:(CGRect)frame {
  self = [super initWithFrame:frame];
  if (self) {
    NSMutableArray *views = [NSMutableArray array];
    UIStackView *row = [[UIStackView alloc] init];
    row.axis = UILayoutConstraintAxisHorizontal;
    row.distribution = UIStackViewDistributionFillEqually;
    row.spacing = 6;
    row.userInteractionEnabled = NO;
    row.translatesAutoresizingMaskIntoConstraints = NO;
    for (NSInteger i = 0; i < 5; i++) {
      UIImageView *v = [[UIImageView alloc] init];
      v.contentMode = UIViewContentModeScaleAspectFit;
      v.tintColor = [UIColor systemOrangeColor];
      v.preferredSymbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:30 weight:UIImageSymbolWeightRegular];
      [row addArrangedSubview:v];
      [views addObject:v];
    }
    [self addSubview:row];
    [NSLayoutConstraint activateConstraints:@[
      [row.leadingAnchor constraintEqualToAnchor:self.leadingAnchor], [row.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
      [row.topAnchor constraintEqualToAnchor:self.topAnchor], [row.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
      [self.heightAnchor constraintGreaterThanOrEqualToConstant:44]
    ]];
    _stars = views;
    self.isAccessibilityElement = YES;
    self.accessibilityTraits = UIAccessibilityTraitAdjustable;
    [self paint];
  }
  return self;
}
- (void)setHalves:(NSInteger)halves { _halves = MAX(0, MIN(10, halves)); [self paint]; }
- (void)paint {
  for (NSInteger i = 1; i <= 5; i++) {
    NSString *name = i * 2 <= self.halves ? @"star.fill" : (i * 2 == self.halves + 1 ? @"star.leadinghalf.filled" : @"star");
    self.stars[i - 1].image = [UIImage systemImageNamed:name];
  }
  self.accessibilityValue = self.halves == 0 ? @"0" : [NSString stringWithFormat:@"%g of 5", self.halves / 2.0];
}
- (void)track:(UITouch *)touch {
  CGFloat x = [touch locationInView:self].x;
  CGFloat each = self.bounds.size.width / 5.0;
  if (each <= 0) return;
  NSInteger star = (NSInteger)floor(x / each);
  star = MAX(0, MIN(4, star));
  BOOL left = (x - star * each) < each / 2.0;
  NSInteger value = (star + 1) * 2 - (left ? 1 : 0);
  if (value != self.halves) { self.halves = value; [self sendActionsForControlEvents:UIControlEventValueChanged]; }
}
- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event { [self track:touch]; return YES; }
- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event { [self track:touch]; return YES; }
- (void)accessibilityIncrement { self.halves += 1; [self sendActionsForControlEvents:UIControlEventValueChanged]; }
- (void)accessibilityDecrement { self.halves -= 1; [self sendActionsForControlEvents:UIControlEventValueChanged]; }
@end

// A half-height sheet holding the star control, the number, Clear and Save.
@interface HeyIOSRatingSheet : UIViewController
@property(nonatomic, copy) NSString *heading;
@property(nonatomic, assign) NSInteger initial;
@property(nonatomic, copy) void (^chosen)(NSInteger halves);
@property(nonatomic, strong) HeyIOSStarControl *control;
@property(nonatomic, strong) UILabel *number;
@end

@implementation HeyIOSRatingSheet
- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = [UIColor systemBackgroundColor];
  UILabel *title = [[UILabel alloc] init];
  title.text = self.heading;
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  title.textAlignment = NSTextAlignmentCenter;
  self.control = [[HeyIOSStarControl alloc] init];
  self.control.halves = self.initial;
  [self.control addTarget:self action:@selector(changed) forControlEvents:UIControlEventValueChanged];
  self.number = [[UILabel alloc] init];
  self.number.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
  self.number.textColor = [UIColor secondaryLabelColor];
  self.number.textAlignment = NSTextAlignmentCenter;
  UILabel *hint = [[UILabel alloc] init];
  hint.text = @"Tap the left half of a star for a half star.";
  hint.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
  hint.textColor = [UIColor secondaryLabelColor];
  hint.textAlignment = NSTextAlignmentCenter;
  hint.numberOfLines = 0;
  UIButton *clear = [UIButton buttonWithConfiguration:[UIButtonConfiguration grayButtonConfiguration] primaryAction:[UIAction actionWithTitle:@"Clear" image:nil identifier:nil handler:^(UIAction *a) { self.control.halves = 0; [self changed]; }]];
  UIButton *save = [UIButton buttonWithConfiguration:[UIButtonConfiguration filledButtonConfiguration] primaryAction:[UIAction actionWithTitle:@"Save" image:nil identifier:nil handler:^(UIAction *a) {
    NSInteger value = self.control.halves;
    [self dismissViewControllerAnimated:YES completion:^{ if (self.chosen) self.chosen(value); }];
  }]];
  save.accessibilityIdentifier = @"rating-save";
  UIStackView *buttons = [[UIStackView alloc] initWithArrangedSubviews:@[clear, save]];
  buttons.spacing = 12;
  buttons.distribution = UIStackViewDistributionFillEqually;
  UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[title, self.control, self.number, hint, buttons]];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.spacing = 14;
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  [self.view addSubview:stack];
  [NSLayoutConstraint activateConstraints:@[
    [stack.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:28],
    [stack.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-28],
    [stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:24],
    [self.control.heightAnchor constraintEqualToConstant:52]
  ]];
  [self changed];
}
- (void)changed { self.number.text = self.control.halves == 0 ? @"Not rated" : [NSString stringWithFormat:@"%g out of 5", self.control.halves / 2.0]; }
@end

static void HeyIOSChooseRating(UIViewController *host, NSString *heading, NSInteger current, void (^chosen)(NSInteger halves)) {
  HeyIOSRatingSheet *sheet = [[HeyIOSRatingSheet alloc] init];
  sheet.heading = heading;
  sheet.initial = current;
  sheet.chosen = chosen;
  sheet.sheetPresentationController.detents = @[[UISheetPresentationControllerDetent mediumDetent]];
  sheet.sheetPresentationController.prefersGrabberVisible = YES;
  [host presentViewController:sheet animated:YES completion:nil];
}

static NSCache *HeyIOSImageCache(void) {
  static NSCache *cache;
  static dispatch_once_t once;
  dispatch_once(&once, ^{ cache = [[NSCache alloc] init]; cache.countLimit = 300; });
  return cache;
}

static void HeyIOSLoadImage(NSString *address, void (^done)(UIImage *image)) {
  NSURL *url = [NSURL URLWithString:address];
  if (url.scheme.length == 0) return;
  UIImage *cached = [HeyIOSImageCache() objectForKey:address];
  if (cached) { done(cached); return; }
  [[[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    (void)response;
    UIImage *image = error == nil && data.length > 0 ? [UIImage imageWithData:data] : nil;
    if (image == nil) return;
    [HeyIOSImageCache() setObject:image forKey:address];
    dispatch_async(dispatch_get_main_queue(), ^{ done(image); });
  }] resume];
}

// The glyph for a row with no picture: symbol_fields (row fields already
// holding an icon name), else icons[row value at icon_by], else icon, else a
// plain link. Level 1 spells these symbols, symbol_by and symbol. Every name
// goes through HeyIOSSymbolName: a neutral icon name becomes its SF Symbol.
static NSString *HeyIOSSymbolFor(NSDictionary *spec, id row) {
  for (NSString *field in HA(spec[@"symbol_fields"])) {
    NSString *direct = HeyIOSSymbolName(HS(HeyIOSAt(row, field)));
    if (direct.length > 0) return direct;
  }
  NSString *by = HS(spec[@"icon_by"]).length > 0 ? HS(spec[@"icon_by"]) : HS(spec[@"symbol_by"]);
  NSDictionary *map = HD(spec[@"icons"]).count > 0 ? HD(spec[@"icons"]) : HD(spec[@"symbols"]);
  NSString *mapped = HeyIOSSymbolName(HS(map[HS(HeyIOSAt(row, by))]));
  if (mapped.length > 0) return mapped;
  NSString *own = HeyIOSSymbolName(HS(spec[@"icon"]).length > 0 ? HS(spec[@"icon"]) : HS(spec[@"symbol"]));
  return own.length > 0 ? own : @"link";
}

// An element's own icon: `icon` (a neutral name), else level 1's
// system_image or symbol. nil when it names nothing this system draws.
static UIImage *HeyIOSImage(NSDictionary *element) {
  NSDictionary *d = HD(element);
  NSString *name = HS(d[@"icon"]).length > 0 ? HS(d[@"icon"]) : (HS(d[@"system_image"]).length > 0 ? HS(d[@"system_image"]) : HS(d[@"symbol"]));
  NSString *symbol = HeyIOSSymbolName(name);
  return symbol.length > 0 ? [UIImage systemImageNamed:symbol] : nil;
}

static void HeyIOSAlert(UIViewController *from, NSString *title, NSString *message) {
  UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
  [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
  [from presentViewController:alert animated:YES completion:nil];
}

#pragma mark - the API

// ONE REQUEST FOR THE DESCRIPTION, READ NO FURTHER THAN THE RENDERER TAKES: a
// body past HeyIOSDescriptionMaxBytes is cancelled as it arrives, so a server
// that answers with something enormous costs a little memory, not the app.
// No cache: a 304 must be seen as a 304.
@interface HeyIOSDescriptionFetch : NSObject <NSURLSessionDataDelegate>
@property(nonatomic, strong) NSMutableData *body;
@property(nonatomic, assign) NSInteger status;
@property(nonatomic, copy, nullable) NSString *etag;
@property(nonatomic, copy, nullable) NSString *failure;
@property(nonatomic, copy) void (^done)(NSInteger status, NSString *_Nullable etag, NSData *body, NSString *_Nullable failure);
- (void)start:(NSURLRequest *)request;
@end

@implementation HeyIOSDescriptionFetch
- (void)start:(NSURLRequest *)request {
  self.body = [NSMutableData data];
  NSURLSessionConfiguration *config = [NSURLSessionConfiguration ephemeralSessionConfiguration];
  config.URLCache = nil;
  config.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
  config.timeoutIntervalForResource = 30;
  NSURLSession *session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:[NSOperationQueue mainQueue]];
  [[session dataTaskWithRequest:request] resume];
  [session finishTasksAndInvalidate];
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)task didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler {
  NSHTTPURLResponse *http = [response isKindOfClass:[NSHTTPURLResponse class]] ? (NSHTTPURLResponse *)response : nil;
  self.status = http.statusCode;
  self.etag = [http valueForHTTPHeaderField:@"etag"];
  if (response.expectedContentLength > (long long)HeyIOSDescriptionMaxBytes) {
    self.failure = @"the answer is larger than this app takes";
    completionHandler(NSURLSessionResponseCancel);
    return;
  }
  completionHandler(NSURLSessionResponseAllow);
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)task didReceiveData:(NSData *)data {
  if (self.body.length + data.length > HeyIOSDescriptionMaxBytes) {
    self.failure = @"the answer is larger than this app takes";
    [task cancel];
    return;
  }
  [self.body appendData:data];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
  NSString *failure = self.failure;
  if (failure == nil && error != nil) failure = [NSString stringWithFormat:@"the server was not reached (%@)", error.localizedDescription];
  if (failure == nil && self.status == 0) failure = @"the server was not reached";
  void (^done)(NSInteger, NSString *, NSData *, NSString *) = self.done;
  self.done = nil;
  if (done) done(self.status, self.etag, self.body, failure);
}
@end

@implementation HeyIOSApi

+ (instancetype)shared {
  static HeyIOSApi *shared;
  static dispatch_once_t once;
  dispatch_once(&once, ^{
    shared = [[HeyIOSApi alloc] init];
    [shared loadManifest];
  });
  return shared;
}

- (void)loadManifest {
  self.manifest = @{};
  self.source = @"none";
  if (HeyIOSManifestFunction == NULL || HeyIOSContractFunction == NULL) { self.failure = @"This build has no app description."; return; }
  const char *raw = HeyIOSManifestFunction();
  size_t length = raw ? strlen(raw) : 0;
  if ((int64_t)length != HeyIOSContractFunction(0)) { self.failure = @"This build's app description is damaged. Rebuild it."; return; }
  NSData *data = [NSData dataWithBytes:raw length:length];
  id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
  if (![parsed isKindOfClass:[NSDictionary class]]) { self.failure = @"This build's app description is not readable."; return; }
  const char *origin = HeyIOSBakedOrigin();
  self.origin = origin != NULL ? [NSString stringWithUTF8String:origin] : HS(parsed[@"origin"]);
  self.baked = parsed;
  self.bakedData = data;
  self.bakedETag = HeyIOSSHA256Hex(data);
  self.manifest = parsed;
  self.heldETag = self.bakedETag;
  self.source = @"baked";
  // THE LAST GOOD SERVED COPY, when this build stored one and it is still one
  // this renderer takes; else the baked copy. A copy stored by another build is
  // never read.
  NSData *stored = [NSData dataWithContentsOfURL:[self storedURL]];
  NSString *source = @"baked";
  NSData *chosen = HeyIOSDescriptionPick(data, stored, nil, nil, &source);
  if ([source isEqualToString:@"stored"]) {
    NSDictionary *storedDescription = nil;
    HeyIOSDescriptionRefusal(chosen, nil, &storedDescription);
    self.manifest = HeyIOSDescriptionMerged(storedDescription, parsed);
    self.heldETag = HeyIOSSHA256Hex(chosen);
    self.source = @"stored";
  } else if (stored.length > 0) {
    NSLog(@"HeyIOSDescription: the stored copy is refused (%@)", HeyIOSDescriptionRefusal(stored, nil, NULL));
  }
  NSLog(@"HeyIOSDescription: drawing the %@ copy %@", self.source, [self.heldETag substringToIndex:12]);
}

- (NSURL *)storedDirectory {
  NSURL *support = [[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
  return [support URLByAppendingPathComponent:@"HeyIOSDescription" isDirectory:YES];
}

- (NSURL *)storedURL {
  return [[self storedDirectory] URLByAppendingPathComponent:[NSString stringWithFormat:@"%@.json", self.bakedETag ?: @"none"]];
}

// One stored copy, named for the baked copy of the build that stored it.
- (void)store:(NSData *)data {
  NSFileManager *files = [NSFileManager defaultManager];
  NSURL *dir = [self storedDirectory];
  [files createDirectoryAtURL:dir withIntermediateDirectories:YES attributes:nil error:nil];
  for (NSURL *old in [files contentsOfDirectoryAtURL:dir includingPropertiesForKeys:nil options:0 error:nil]) {
    if (![old.lastPathComponent isEqualToString:[self storedURL].lastPathComponent]) [files removeItemAtURL:old error:nil];
  }
  if (![data writeToURL:[self storedURL] options:NSDataWritingAtomic error:nil]) NSLog(@"HeyIOSDescription: could not store the served copy");
}

// ASK THE SERVER FOR THIS RENDERER'S DESCRIPTION: platform and level, no
// credentials, If-None-Match the copy in hand. Anything but a 200 this
// renderer takes changes nothing. done(YES) when a new copy is pending.
- (void)refreshDescription:(void (^)(BOOL arrived))done {
  NSDictionary *served = HD(self.baked[@"served"]);
  NSString *path = HS(served[@"path"]);
  if (self.fetching || ![path hasPrefix:@"/"] || self.origin.length == 0) { if (done) done(NO); return; }
  NSString *address = [NSString stringWithFormat:@"%@%@?platform=%@&level=%ld", self.origin, path, HeyIOSRendererPlatform, (long)HeyIOSRendererLevel];
  NSURL *url = [NSURL URLWithString:address];
  if (url == nil) { if (done) done(NO); return; }
  self.fetching = YES;
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15];
  request.HTTPMethod = @"GET";
  [request setValue:@"application/json" forHTTPHeaderField:@"accept"];
  NSString *held = self.pendingETag ?: self.heldETag;
  if (held.length > 0) [request setValue:[NSString stringWithFormat:@"\"%@\"", held] forHTTPHeaderField:@"if-none-match"];
  HeyIOSDescriptionFetch *fetch = [[HeyIOSDescriptionFetch alloc] init];
  fetch.done = ^(NSInteger status, NSString *etag, NSData *body, NSString *failure) {
    self.fetching = NO;
    if (failure != nil) { NSLog(@"HeyIOSDescription: %@; keeping the %@ copy", failure, self.source); if (done) done(NO); return; }
    if (status == 304) { NSLog(@"HeyIOSDescription: unchanged; keeping the %@ copy", self.source); if (done) done(NO); return; }
    if (status != 200) { NSLog(@"HeyIOSDescription: the server answered %ld; keeping the %@ copy", (long)status, self.source); if (done) done(NO); return; }
    NSString *picked = nil;
    HeyIOSDescriptionPick(self.bakedData, nil, body, etag, &picked);
    if (![picked isEqualToString:@"served"]) { NSLog(@"HeyIOSDescription: refused (%@); keeping the %@ copy", HeyIOSDescriptionRefusal(body, etag, NULL), self.source); if (done) done(NO); return; }
    NSDictionary *parsed = nil;
    HeyIOSDescriptionRefusal(body, etag, &parsed);
    NSString *hash = HeyIOSSHA256Hex(body);
    if ([hash isEqualToString:held]) { if (done) done(NO); return; }
    [self store:body];
    self.pending = HeyIOSDescriptionMerged(parsed, self.baked);
    self.pendingETag = hash;
    NSLog(@"HeyIOSDescription: a new served copy %@ is stored", [hash substringToIndex:12]);
    if (done) done(YES);
  };
  [fetch start:request];
}

- (BOOL)applyPending {
  if (self.pending == nil) return NO;
  self.manifest = self.pending;
  self.heldETag = self.pendingETag;
  self.source = @"served";
  self.pending = nil;
  self.pendingETag = nil;
  NSLog(@"HeyIOSDescription: drawing the served copy %@", [self.heldETag substringToIndex:12]);
  return YES;
}

- (NSString *)keychainService { return HS(self.manifest[@"keychain_service"]); }
- (NSString *)token { return HeyIOSKeychainRead([self keychainService], @"session"); }
- (BOOL)setToken:(NSString *)token { return HeyIOSKeychainWrite([self keychainService], @"session", token); }
- (void)clearToken { HeyIOSKeychainDelete([self keychainService], @"session"); }

- (NSDictionary *)screenNamed:(NSString *)name {
  for (NSDictionary *screen in HA(self.manifest[@"screens"])) {
    if ([HS(HD(screen)[@"id"]) isEqualToString:name]) return screen;
  }
  return @{};
}

- (void)send:(NSDictionary *)route vars:(NSDictionary *)vars row:(id)row completion:(void (^)(NSInteger, id, NSString *))completion {
  NSString *path = HeyIOSFillPath(HS(route[@"path"]), vars);
  NSURL *url = [NSURL URLWithString:[self.origin stringByAppendingString:path]];
  if (url == nil) { completion(0, nil, @"This address is not valid."); return; }
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20];
  request.HTTPMethod = HS(route[@"method"]).length > 0 ? HS(route[@"method"]) : @"GET";
  [request setValue:@"application/json" forHTTPHeaderField:@"accept"];
  NSDictionary *session = HD(self.manifest[@"session"]);
  NSString *token = [self token];
  if (token.length > 0) {
    [request setValue:[HS(session[@"prefix"]) stringByAppendingString:token] forHTTPHeaderField:HS(session[@"header"])];
  }
  if ([route[@"body"] isKindOfClass:[NSDictionary class]]) {
    NSMutableDictionary *body = [NSMutableDictionary dictionary];
    [route[@"body"] enumerateKeysAndObjectsUsingBlock:^(id key, id spec, BOOL *stop) {
      id value = HeyIOSValue(spec, vars, row);
      if (value != nil) body[key] = value;
    }];
    request.HTTPBody = [NSJSONSerialization dataWithJSONObject:body options:0 error:nil];
    [request setValue:@"application/json" forHTTPHeaderField:@"content-type"];
  }
  [self perform:request path:path completion:completion];
}

// A body that is a file, not JSON: the text as it is, text/plain.
- (void)sendText:(NSString *)text route:(NSDictionary *)route vars:(NSDictionary *)vars completion:(void (^)(NSInteger, id, NSString *))completion {
  NSString *path = HeyIOSFillPath(HS(route[@"path"]), vars);
  NSURL *url = [NSURL URLWithString:[self.origin stringByAppendingString:path]];
  if (url == nil) { completion(0, nil, @"This address is not valid."); return; }
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:120];
  // The route's own method; POST when it names none.
  request.HTTPMethod = HS(route[@"method"]).length > 0 ? HS(route[@"method"]) : @"POST";
  [request setValue:@"application/json" forHTTPHeaderField:@"accept"];
  [request setValue:@"text/plain" forHTTPHeaderField:@"content-type"];
  NSDictionary *session = HD(self.manifest[@"session"]);
  NSString *token = [self token];
  if (token.length > 0) [request setValue:[HS(session[@"prefix"]) stringByAppendingString:token] forHTTPHeaderField:HS(session[@"header"])];
  request.HTTPBody = [text dataUsingEncoding:NSUTF8StringEncoding];
  [self perform:request path:path completion:completion];
}

- (void)perform:(NSURLRequest *)request path:(NSString *)path completion:(void (^)(NSInteger, id, NSString *))completion {
  NSDictionary *session = HD(self.manifest[@"session"]);
  NSString *token = [self token];
  BOOL isCheck = [path isEqualToString:HS(HD(session[@"check"])[@"path"])];
  [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    NSInteger status = [response isKindOfClass:[NSHTTPURLResponse class]] ? ((NSHTTPURLResponse *)response).statusCode : 0;
    id json = data.length > 0 ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
    NSString *message = nil;
    if (error != nil || status == 0) message = @"Could not reach the server.";
    else if (status >= 400) {
      message = HS(HD(json)[@"error"]);
      if (message.length == 0) message = [NSString stringWithFormat:@"The server answered %ld.", (long)status];
    }
    dispatch_async(dispatch_get_main_queue(), ^{
      if (status == 401 && token.length > 0 && !isCheck) [[NSNotificationCenter defaultCenter] postNotificationName:HeyIOSSignedOutNotification object:nil];
      completion(status, json, message);
    });
  }] resume];
}

@end

static NSDictionary *HeyIOSLabels(void) { return HD([HeyIOSApi shared].manifest[@"labels"]); }

#pragma mark - the audio feed (Listen tab and car)

static NSDictionary *HeyIOSAudioRowFrom(NSDictionary *spec, NSDictionary *raw) {
  NSMutableArray *pages = [NSMutableArray array];
  for (id url in HA(HeyIOSAt(raw, HS(spec[@"audio_urls"])))) if (HS(url).length > 0) [pages addObject:HS(url)];
  id seconds = HeyIOSAt(raw, HS(spec[@"position_seconds"]));
  id page = HeyIOSAt(raw, HS(spec[@"position_page"]));
  // subtitle_when names a field; when the row has none, subtitle_else is used
  // (an episode reads show, date and length; anything else what it is).
  id subtitleSpec = spec[@"subtitle"];
  if (HS(spec[@"subtitle_when"]).length > 0 && HS(HeyIOSAt(raw, HS(spec[@"subtitle_when"]))).length == 0) subtitleSpec = spec[@"subtitle_else"];
  return @{
    @"id": HeyIOSLine(spec[@"id"], raw),
    @"title": HeyIOSLine(spec[@"title"], raw),
    @"subtitle": HeyIOSLine(subtitleSpec, raw),
    @"image_url": HeyIOSLine(spec[@"image_url"], raw),
    @"audio_url": HeyIOSLine(spec[@"audio_url"], raw),
    @"audio_urls": pages,
    @"apple_music_id": HeyIOSLine(spec[@"apple_music_id"], raw),
    @"requires": HeyIOSLine(spec[@"requires"], raw),
    @"kind": HeyIOSLine(spec[@"kind"], raw),
    @"symbol": HeyIOSSymbolFor(spec, raw),
    @"position_seconds": [seconds respondsToSelector:@selector(integerValue)] ? @([seconds integerValue]) : @0,
    @"position_page": [page respondsToSelector:@selector(integerValue)] ? @([page integerValue]) : @0
  };
}

// Where the listener stopped goes back through the description's position
// route; audio on the app's own server carries the session, so a narrated
// article (served only to its owner) plays.
static void HeyIOSConfigureAudio(void) {
  HeyIOSApi *api = [HeyIOSApi shared];
  NSDictionary *audioSpec = HD(api.manifest[@"audio"]);
  HeyIOSAudio *audio = [HeyIOSAudio shared];
  if ([audioSpec[@"report_every_seconds"] doubleValue] > 0) audio.reportInterval = [audioSpec[@"report_every_seconds"] doubleValue];
  audio.headersForURL = ^NSDictionary<NSString *, NSString *> *(NSURL *url) {
    HeyIOSApi *current = [HeyIOSApi shared];
    NSString *token = [current token];
    if (token.length == 0 || current.origin.length == 0 || ![url.absoluteString hasPrefix:current.origin]) return nil;
    NSDictionary *session = HD(current.manifest[@"session"]);
    return @{HS(session[@"header"]): [HS(session[@"prefix"]) stringByAppendingString:token]};
  };
  NSDictionary *route = HD(audioSpec[@"position"]);
  if (route.count == 0) return;
  // ONE REPORT PER ITEM IN FLIGHT, IN ORDER. Measured 2026-09-13: at the end of
  // a narrated page the periodic report (20 s, not finished) and the finish
  // report left together, the server's workers applied them in the other order,
  // and a finished article stayed in the car as started. So a report waits for
  // the one before it, only the newest waiting report is kept, and a finished
  // report is never replaced by an unfinished one.
  static NSMutableSet<NSString *> *inFlight;
  static NSMutableDictionary<NSString *, NSDictionary *> *waiting;
  inFlight = [NSMutableSet set];
  waiting = [NSMutableDictionary dictionary];
  static void (^send)(NSDictionary *route, NSDictionary *vars, NSDictionary *row);
  send = ^(NSDictionary *r, NSDictionary *vars, NSDictionary *row) {
    NSString *key = HS(vars[@"id"]);
    [inFlight addObject:key];
    [[HeyIOSApi shared] send:r vars:vars row:row completion:^(NSInteger status, id json, NSString *error) {
      if ([vars[@"finished"] boolValue] && error == nil) HeyIOSAudioFeedChanged();
      [inFlight removeObject:key];
      NSDictionary *next = waiting[key];
      if (next != nil) {
        [waiting removeObjectForKey:key];
        send(r, next[@"vars"], next[@"row"]);
      }
    }];
  };
  audio.positionReporter = ^(NSDictionary *row, NSInteger seconds, NSInteger page, BOOL finished) {
    NSString *key = HS(row[@"id"]);
    NSDictionary *vars = @{@"id": key, @"seconds": @(seconds), @"page": @(page), @"finished": @(finished)};
    if (![inFlight containsObject:key]) {
      send(route, vars, row);
      return;
    }
    BOOL waitingFinished = [HD(waiting[key])[@"vars"][@"finished"] boolValue];
    if (waitingFinished && !finished) return;
    waiting[key] = @{@"vars": vars, @"row": row};
  };
}

static void HeyIOSLoadAudio(void (^done)(NSArray<NSDictionary *> *sections, NSString *message)) {
  HeyIOSApi *api = [HeyIOSApi shared];
  NSDictionary *audio = HD(api.manifest[@"audio"]);
  if ([api token].length == 0) { done(@[], HS(audio[@"signed_out"])); return; }
  [api send:HD(audio[@"source"]) vars:@{} row:nil completion:^(NSInteger status, id json, NSString *error) {
    if (error != nil) { done(@[], error); return; }
    NSMutableArray *sections = [NSMutableArray array];
    for (NSDictionary *spec in HA(audio[@"sections"])) {
      NSMutableArray *rows = [NSMutableArray array];
      for (NSDictionary *raw in HA(HeyIOSAt(json, HS(spec[@"list"])))) {
        // A WAITING ROW: something saved that cannot play yet. It carries no
        // audio, so the playability filter keeps it out of the car; the phone
        // shows it greyed so the save visibly landed.
        if ([spec[@"waiting"] boolValue]) {
          [rows addObject:@{@"id": HS(HD(raw)[@"id"]), @"title": HeyIOSLine(spec[@"waiting_title"], raw), @"subtitle": HeyIOSLine(spec[@"waiting_subtitle"], raw), @"symbol": @"hourglass", @"_waiting": @YES}];
          continue;
        }
        [rows addObject:HeyIOSAudioRowFrom(HD(audio[@"row"]), HD(raw))];
      }
      [sections addObject:@{@"title": HS(spec[@"title"]), @"rows": rows}];
    }
    done(sections, nil);
  }];
}

#pragma mark - screens

@protocol HeyIOSVarsReceiver <NSObject>
- (void)applyVars:(NSDictionary *)vars;
@end

// A first screen that holds something a person typed, which a redraw loses.
@protocol HeyIOSTypedValues <NSObject>
- (BOOL)hasTypedValues;
@end

static UIViewController *HeyIOSControllerFor(NSDictionary *screen, NSDictionary *vars);

static void HeyIOSOpenScreen(UIViewController *from, NSString *screenID, NSDictionary *vars) {
  NSDictionary *screen = [[HeyIOSApi shared] screenNamed:screenID];
  if (screen.count == 0) return;
  UIViewController *next = HeyIOSControllerFor(screen, vars);
  if (next == nil) return;
  [from.navigationController pushViewController:next animated:YES];
}

// Parameters for the screen a tap opens: '$name', '=word', or a path read
// from the row and then the screen's answer (HeyIOSParam), the same everywhere.
static NSDictionary *HeyIOSParams(NSDictionary *spec, NSDictionary *vars, id row, id json) {
  NSMutableDictionary *params = [NSMutableDictionary dictionary];
  [HD(spec) enumerateKeysAndObjectsUsingBlock:^(id key, id path, BOOL *stop) { params[key] = HeyIOSParam(path, vars, row, json); }];
  return params;
}

@interface HeyIOSFooterLabel : UILabel
@end
@implementation HeyIOSFooterLabel
- (void)drawTextInRect:(CGRect)rect { [super drawTextInRect:UIEdgeInsetsInsetRect(rect, UIEdgeInsetsMake(8, 20, 8, 20))]; }
- (CGSize)intrinsicContentSize { CGSize s = [super intrinsicContentSize]; return CGSizeMake(s.width + 40, s.height + 16); }
@end

// Rows sharing the section's group_by value become ONE row: the first member
// (a server that groups orders the best link first), with `_also` naming the
// other members' group_label values for display, and `_sources` listing every
// member as the description's group_sources map says ({out_key: row_path}), so
// a body can save them all. The host knows no field names of its own here.
static NSArray *HeyIOSGroupRows(NSArray *rows, NSDictionary *spec) {
  NSString *key = HS(spec[@"group_by"]);
  if (key.length == 0) return rows;
  NSString *labelPath = HS(spec[@"group_label"]);
  NSDictionary *sourceMap = HD(spec[@"group_sources"]);
  // group_list_when {field, values}: for these rows `_watch` names EVERY member
  // (with group_notes[member's group_note_field] after its name) and
  // `_one_label` is empty; for the rest `_one_label` is the first member's label.
  NSDictionary *listWhen = HD(spec[@"group_list_when"]);
  NSDictionary *notes = HD(spec[@"group_notes"]);
  NSString *noteField = HS(spec[@"group_note_field"]);
  // group_any_true: a flag that is true for the group when any member has it,
  // carrying group_any_carry fields from that member (in your queue, its id).
  NSString *anyTrue = HS(spec[@"group_any_true"]);
  NSArray *carry = HA(spec[@"group_any_carry"]);
  NSMutableArray<NSString *> *order = [NSMutableArray array];
  NSMutableDictionary<NSString *, NSMutableArray *> *groups = [NSMutableDictionary dictionary];
  for (id candidate in rows) {
    NSDictionary *row = HD(candidate);
    NSString *value = HS(HeyIOSAt(row, key));
    if (value.length == 0) value = [NSString stringWithFormat:@"row-%lu", (unsigned long)order.count];
    if (groups[value] == nil) {
      groups[value] = [NSMutableArray array];
      [order addObject:value];
    }
    [groups[value] addObject:row];
  }
  NSMutableArray *out = [NSMutableArray array];
  for (NSString *value in order) {
    NSArray *members = groups[value];
    NSMutableDictionary *first = [HD(members.firstObject) mutableCopy];
    NSMutableArray<NSString *> *also = [NSMutableArray array];
    NSMutableArray *sources = [NSMutableArray array];
    for (NSUInteger i = 0; i < members.count; i++) {
      NSDictionary *member = members[i];
      if (sourceMap.count > 0) {
        NSMutableDictionary *source = [NSMutableDictionary dictionary];
        [sourceMap enumerateKeysAndObjectsUsingBlock:^(id outKey, id path, BOOL *stop) {
          NSString *v = HS(HeyIOSAt(member, HS(path)));
          if (v.length > 0) source[outKey] = v;
        }];
        if (source.count == sourceMap.count) [sources addObject:source];
      }
      NSString *label = HS(HeyIOSAt(member, labelPath));
      if (i > 0 && label.length > 0 && ![also containsObject:label]) [also addObject:label];
    }
    first[@"_also"] = [also componentsJoinedByString:@", "];
    first[@"_sources"] = sources;
    BOOL listed = listWhen.count > 0 && [HA(listWhen[@"values"]) containsObject:HS(HeyIOSAt(first, HS(listWhen[@"field"])))];
    if (listed) {
      NSMutableArray<NSString *> *watch = [NSMutableArray array];
      for (NSDictionary *member in members) {
        NSString *label = HS(HeyIOSAt(member, labelPath));
        if (label.length == 0) continue;
        NSString *note = HS(notes[HS(HeyIOSAt(member, noteField))]);
        NSString *entry = note.length > 0 ? [NSString stringWithFormat:@"%@ %@", label, note] : label;
        if (![watch containsObject:entry]) [watch addObject:entry];
      }
      first[@"_watch"] = [watch componentsJoinedByString:@", "];
      first[@"_one_label"] = @"";
    } else {
      first[@"_watch"] = @"";
      first[@"_one_label"] = HS(HeyIOSAt(first, labelPath));
    }
    if (anyTrue.length > 0) {
      for (NSDictionary *member in members) {
        if (HeyIOSTruthy(member, anyTrue)) {
          first[anyTrue] = @YES;
          for (NSString *field in carry) first[field] = member[field] ?: @"";
          break;
        }
      }
    }
    [out addObject:first];
  }
  return out;
}

#pragma mark actions

// A screen that can run actions: it has variables (its parameters and any
// chosen values), the JSON its own source answered (for {@path} and '@path'),
// and reloads itself after a write.
@protocol HeyIOSActionHost <NSObject>
- (NSMutableDictionary *)vars;
- (nullable id)screenJSON;
- (void)reloadContent;
@end

// A short line at the bottom of the screen that goes away on its own: an alert
// that has to be dismissed after every save is the wrong weight for "Saved".
static void HeyIOSToast(UIViewController *from, NSString *text) {
  if (text.length == 0) return;
  UIView *root = from.view.window ?: from.view;
  UILabel *label = [[UILabel alloc] init];
  label.text = text;
  label.numberOfLines = 0;
  label.textAlignment = NSTextAlignmentCenter;
  label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
  label.textColor = [UIColor systemBackgroundColor];
  label.backgroundColor = [[UIColor labelColor] colorWithAlphaComponent:0.88];
  label.layer.cornerRadius = 12;
  label.clipsToBounds = YES;
  label.translatesAutoresizingMaskIntoConstraints = NO;
  label.accessibilityIdentifier = @"toast";
  [root addSubview:label];
  [NSLayoutConstraint activateConstraints:@[
    [label.centerXAnchor constraintEqualToAnchor:root.centerXAnchor],
    [label.widthAnchor constraintLessThanOrEqualToAnchor:root.widthAnchor constant:-48],
    [label.widthAnchor constraintGreaterThanOrEqualToConstant:120],
    [label.heightAnchor constraintGreaterThanOrEqualToConstant:44],
    [label.bottomAnchor constraintEqualToAnchor:root.safeAreaLayoutGuide.bottomAnchor constant:-70]
  ]];
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [UIView animateWithDuration:0.25 animations:^{ label.alpha = 0; } completion:^(BOOL finished) { [label removeFromSuperview]; }];
  });
}

// The absolute address of a value: a path on the app's own server is joined
// to its origin.
static NSURL *HeyIOSAddress(NSString *value) {
  if ([value hasPrefix:@"/"]) return [NSURL URLWithString:[[HeyIOSApi shared].origin stringByAppendingString:value]];
  return [NSURL URLWithString:value];
}

static void HeyIOSRunAction(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, id row, UIView *source);

static NSDictionary *HeyIOSVarsWith(UIViewController<HeyIOSActionHost> *host, id row, NSDictionary *extra) {
  NSMutableDictionary *vars = [[host vars] mutableCopy] ?: [NSMutableDictionary dictionary];
  // {@name} in a path reads the row acted on, else the screen's own JSON.
  id json = [host screenJSON];
  if ([json isKindOfClass:[NSDictionary class]]) {
    [json enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
      if ([obj isKindOfClass:[NSString class]] || [obj isKindOfClass:[NSNumber class]]) vars[[@"@" stringByAppendingString:key]] = obj;
    }];
  }
  if ([row isKindOfClass:[NSDictionary class]]) {
    [row enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
      if ([obj isKindOfClass:[NSString class]] || [obj isKindOfClass:[NSNumber class]]) vars[[@"@" stringByAppendingString:key]] = obj;
    }];
  }
  if (extra) [vars addEntriesFromDictionary:extra];
  return vars;
}

static void HeyIOSPresentSheet(UIViewController *host, UIAlertController *sheet, UIView *source) {
  sheet.popoverPresentationController.sourceView = source ?: host.view;
  sheet.popoverPresentationController.sourceRect = source ? source.bounds : CGRectMake(host.view.bounds.size.width / 2, 80, 1, 1);
  [host presentViewController:sheet animated:YES completion:nil];
}

// What happens after a write succeeds: a message, a token to keep, a sheet to
// share a value, and where to go ('reload' by default, 'pop', 'sign_out', or
// {screen, params} read from the response).
static void HeyIOSAfter(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, NSDictionary *vars, id json) {
  NSMutableDictionary *both = [vars mutableCopy];
  if ([json isKindOfClass:[NSDictionary class]]) [both addEntriesFromDictionary:json];
  NSString *tokenPath = HS(action[@"store_token"]);
  if (tokenPath.length > 0 && HS(HeyIOSAt(json, tokenPath)).length > 0) [[HeyIOSApi shared] setToken:HS(HeyIOSAt(json, tokenPath))];
  NSString *done = HeyIOSRender(HS(action[@"done"]), both);
  if (done.length == 0 && HS(action[@"done"]).length > 0 && [HS(action[@"done"]) rangeOfString:@"{"].location == NSNotFound) done = HS(action[@"done"]);
  HeyIOSToast(host, done);
  NSString *sharePath = HS(action[@"share_result"]);
  if (sharePath.length > 0 && HS(HeyIOSAt(json, sharePath)).length > 0) {
    NSString *value = HS(HeyIOSAt(json, sharePath));
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL URLWithString:value] ?: value] applicationActivities:nil];
    share.popoverPresentationController.sourceView = host.view;
    [host presentViewController:share animated:YES completion:nil];
  }
  id then = action[@"then"];
  if ([then isKindOfClass:[NSDictionary class]]) {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [HD(then[@"params"]) enumerateKeysAndObjectsUsingBlock:^(id key, id path, BOOL *stop) {
      params[key] = HeyIOSParam(path, vars, both, nil);
    }];
    UINavigationController *nav = host.navigationController;
    if ([then[@"replace"] boolValue]) [nav popViewControllerAnimated:NO];
    HeyIOSOpenScreen(nav.topViewController ?: host, HS(then[@"screen"]), params);
    return;
  }
  NSString *word = HS(then);
  if ([word isEqualToString:@"pop"]) {
    UINavigationController *nav = host.navigationController;
    [nav popViewControllerAnimated:YES];
    id<HeyIOSActionHost> below = (id<HeyIOSActionHost>)nav.topViewController;
    if ([below respondsToSelector:@selector(reloadContent)]) [below reloadContent];
    return;
  }
  if ([word isEqualToString:@"sign_out"]) {
    [[HeyIOSApi shared] clearToken];
    [[NSNotificationCenter defaultCenter] postNotificationName:HeyIOSSignedOutNotification object:nil];
    return;
  }
  if ([word isEqualToString:@"signed_in"]) {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"HeyIOSSignedInNotification" object:nil];
    return;
  }
  if (![word isEqualToString:@"stay"]) [host reloadContent];
}

static void HeyIOSSend(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, NSDictionary *vars, id row) {
  NSDictionary *route = HD(action[@"request"]);
  if (route.count == 0) { HeyIOSAfter(host, action, vars, nil); return; }
  NSMutableDictionary *filled = [route mutableCopy];
  [[HeyIOSApi shared] send:filled vars:vars row:row completion:^(NSInteger status, id json, NSString *error) {
    if (error != nil) { HeyIOSAlert(host, HS(action[@"failed_title"]).length ? HS(action[@"failed_title"]) : @"That did not work", error); return; }
    HeyIOSAfter(host, action, vars, json);
  }];
}

// Text asked for in an alert: one or more fields, prefilled from the row or
// the screen, each becoming $id.
static void HeyIOSPrompt(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, NSDictionary *vars, id row, void (^then)(NSDictionary *vars)) {
  NSDictionary *prompt = HD(action[@"prompt"]);
  UIAlertController *alert = [UIAlertController alertControllerWithTitle:HS(prompt[@"title"]).length ? HS(prompt[@"title"]) : HS(action[@"title"]) message:HS(prompt[@"message"]).length ? HS(prompt[@"message"]) : nil preferredStyle:UIAlertControllerStyleAlert];
  NSArray *fields = HA(prompt[@"fields"]);
  for (NSDictionary *field in fields) {
    [alert addTextFieldWithConfigurationHandler:^(UITextField *text) {
      text.placeholder = HS(field[@"placeholder"]).length ? HS(field[@"placeholder"]) : HS(field[@"label"]);
      NSString *prefill = HS(field[@"value"]);
      if (prefill.length > 0) text.text = HS(HeyIOSAt(row, prefill)).length ? HS(HeyIOSAt(row, prefill)) : HS(HeyIOSAt([host screenJSON], prefill));
      NSString *kind = HS(field[@"kind"]);
      text.secureTextEntry = [kind isEqualToString:@"secure"];
      text.keyboardType = [kind isEqualToString:@"url"] ? UIKeyboardTypeURL : ([kind isEqualToString:@"number"] ? UIKeyboardTypeNumbersAndPunctuation : UIKeyboardTypeDefault);
      text.autocapitalizationType = [kind isEqualToString:@"prose"] ? UITextAutocapitalizationTypeSentences : UITextAutocapitalizationTypeNone;
      text.accessibilityLabel = HS(field[@"label"]);
    }];
  }
  [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
  __weak UIAlertController *weakAlert = alert;
  [alert addAction:[UIAlertAction actionWithTitle:HS(prompt[@"button"]).length ? HS(prompt[@"button"]) : @"Save" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
    NSMutableDictionary *next = [vars mutableCopy];
    for (NSUInteger i = 0; i < fields.count; i++) {
      NSDictionary *field = fields[i];
      NSString *typed = [weakAlert.textFields[i].text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] ?: @"";
      if ([field[@"required"] boolValue] && typed.length == 0) { HeyIOSAlert(host, HS(action[@"title"]), [NSString stringWithFormat:@"%@ is needed.", HS(field[@"label"])]); return; }
      next[HS(field[@"id"])] = typed;
    }
    then(next);
  }]];
  [host presentViewController:alert animated:YES completion:nil];
}

// Two steps for something that cannot be undone: the question, then the
// destructive button.
static void HeyIOSConfirm(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, UIView *source, void (^then)(void)) {
  NSDictionary *confirm = HD(action[@"confirm"]);
  UIAlertController *sheet = [UIAlertController alertControllerWithTitle:HS(confirm[@"title"]) message:HS(confirm[@"message"]).length ? HS(confirm[@"message"]) : nil preferredStyle:UIAlertControllerStyleActionSheet];
  [sheet addAction:[UIAlertAction actionWithTitle:HS(confirm[@"button"]).length ? HS(confirm[@"button"]) : HS(action[@"title"]) style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) { then(); }]];
  [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
  HeyIOSPresentSheet(host, sheet, source);
}

// The system sign-in sheet (ASWebAuthenticationSession): the service's own
// page in a browser the app cannot read, closing on the app's url scheme.
// Never a credential form of the app's own.
@interface HeyIOSWebAuth : NSObject <ASWebAuthenticationPresentationContextProviding>
@property(nonatomic, weak) UIViewController *host;
@property(nonatomic, strong, nullable) ASWebAuthenticationSession *session;
@end
@implementation HeyIOSWebAuth
- (ASPresentationAnchor)presentationAnchorForWebAuthenticationSession:(ASWebAuthenticationSession *)session { return self.host.view.window; }
@end

static HeyIOSWebAuth *HeyIOSWebAuthKeeper;

static void HeyIOSWebSignIn(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, NSDictionary *vars, id row) {
  [[HeyIOSApi shared] send:HD(action[@"request"]) vars:vars row:row completion:^(NSInteger status, id json, NSString *error) {
    if (error != nil) { HeyIOSAlert(host, HS(action[@"failed_title"]).length ? HS(action[@"failed_title"]) : @"That did not work", error); return; }
    NSURL *url = [NSURL URLWithString:HS(HeyIOSAt(json, HS(action[@"url"]).length ? HS(action[@"url"]) : @"url"))];
    NSString *scheme = HS(HeyIOSAt(json, @"callback_scheme")).length ? HS(HeyIOSAt(json, @"callback_scheme")) : HS([HeyIOSApi shared].manifest[@"url_scheme"]);
    if (url == nil) { HeyIOSAlert(host, HS(action[@"failed_title"]), @"The server did not say where to sign in."); return; }
    HeyIOSWebAuth *keeper = [[HeyIOSWebAuth alloc] init];
    keeper.host = host;
    keeper.session = [[ASWebAuthenticationSession alloc] initWithURL:url callbackURLScheme:scheme completionHandler:^(NSURL *callback, NSError *failure) {
      dispatch_async(dispatch_get_main_queue(), ^{
        HeyIOSWebAuthKeeper = nil;
        if (failure != nil && failure.code == ASWebAuthenticationSessionErrorCodeCanceledLogin) return;
        HeyIOSAfter(host, action, vars, nil);
      });
    }];
    keeper.session.presentationContextProvider = keeper;
    HeyIOSWebAuthKeeper = keeper;
    [keeper.session start];
  }];
}

// A FILE THE PERSON PICKS, sent as the body. A server that takes a megabyte at
// a time gets it in parts cut on a boundary the description names ('lines',
// repeating the first line on every part, or 'records': a } , { boundary), and
// the numbers in each answer named by sum are added up for the message.
@interface HeyIOSDocumentPick : NSObject <UIDocumentPickerDelegate>
@property(nonatomic, weak) UIViewController<HeyIOSActionHost> *host;
@property(nonatomic, strong) NSDictionary *action;
@property(nonatomic, strong) NSDictionary *vars;
@end

static HeyIOSDocumentPick *HeyIOSDocumentKeeper;

static NSArray<NSString *> *HeyIOSSplitText(NSString *text, NSDictionary *split) {
  NSInteger limit = [split[@"max_bytes"] integerValue] > 0 ? [split[@"max_bytes"] integerValue] : 800000;
  NSString *boundary = HS(split[@"boundary"]);
  NSData *all = [text dataUsingEncoding:NSUTF8StringEncoding];
  if ((NSInteger)all.length <= limit) return @[text];
  NSMutableArray *parts = [NSMutableArray array];
  NSString *header = @"";
  NSString *rest = text;
  if ([boundary isEqualToString:@"lines"] && [split[@"repeat_first_line"] boolValue]) {
    NSRange nl = [text rangeOfString:@"\n"];
    if (nl.location != NSNotFound) header = [text substringToIndex:nl.location + 1];
  }
  while (rest.length > 0) {
    NSUInteger end = rest.length;
    // Characters are not bytes: walk down until the piece fits.
    NSUInteger guess = MIN(rest.length, (NSUInteger)limit);
    while (guess > 0 && [[rest substringToIndex:guess] lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > (NSUInteger)limit) guess = guess * 7 / 10;
    if (guess < rest.length) {
      NSRange window = NSMakeRange(0, guess);
      NSRange cut = [boundary isEqualToString:@"records"] ? [rest rangeOfString:@"}," options:NSBackwardsSearch range:window] : [rest rangeOfString:@"\n" options:NSBackwardsSearch range:window];
      end = cut.location != NSNotFound && cut.location > 0 ? cut.location + 1 : guess;
    }
    NSString *piece = [rest substringToIndex:end];
    rest = [rest substringFromIndex:end];
    if ([boundary isEqualToString:@"records"]) {
      // A part starting at ",{" is not JSON on its own; the server scans records, so the comma goes.
      while ([rest hasPrefix:@","] || [rest hasPrefix:@"\n"] || [rest hasPrefix:@" "]) rest = [rest substringFromIndex:1];
    }
    [parts addObject:parts.count > 0 && header.length > 0 ? [header stringByAppendingString:piece] : piece];
  }
  return parts;
}

@implementation HeyIOSDocumentPick
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
  NSURL *url = urls.firstObject;
  UIViewController<HeyIOSActionHost> *host = self.host;
  NSDictionary *action = self.action;
  NSDictionary *vars = self.vars;
  HeyIOSDocumentKeeper = nil;
  if (url == nil || host == nil) return;
  BOOL scoped = [url startAccessingSecurityScopedResource];
  NSString *text = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
  if (scoped) [url stopAccessingSecurityScopedResource];
  if (text.length == 0) { HeyIOSAlert(host, HS(action[@"failed_title"]), @"That file could not be read as text."); return; }
  NSArray *parts = HeyIOSSplitText(text, HD(action[@"split"]));
  NSMutableDictionary *sums = [NSMutableDictionary dictionary];
  __block void (^next)(NSUInteger);
  __block void (^keep)(NSUInteger);
  next = ^(NSUInteger index) {
    if (index >= parts.count) {
      NSMutableDictionary *both = [vars mutableCopy];
      [both addEntriesFromDictionary:sums];
      both[@"parts"] = @(parts.count);
      HeyIOSAfter(host, action, both, sums);
      keep = nil;
      return;
    }
    if (parts.count > 1) HeyIOSToast(host, [NSString stringWithFormat:@"Sending part %lu of %lu", (unsigned long)index + 1, (unsigned long)parts.count]);
    [[HeyIOSApi shared] sendText:parts[index] route:HD(action[@"request"]) vars:vars completion:^(NSInteger status, id json, NSString *error) {
      if (error != nil) {
        NSString *where = parts.count > 1 ? [NSString stringWithFormat:@"Stopped at part %lu of %lu: %@ What was already read is kept.", (unsigned long)index + 1, (unsigned long)parts.count, error] : error;
        HeyIOSAlert(host, HS(action[@"failed_title"]), where);
        keep = nil;
        return;
      }
      for (NSString *key in HA(action[@"sum"])) sums[key] = @([sums[key] integerValue] + [HeyIOSAt(json, key) integerValue]);
      keep(index + 1);
    }];
  };
  keep = next;
  next(0);
}
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller { HeyIOSDocumentKeeper = nil; }
@end

static void HeyIOSPickDocument(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, NSDictionary *vars) {
  NSMutableArray<UTType *> *types = [NSMutableArray array];
  // accept names file kinds (csv, json, text); level 1 named Apple types.
  for (NSString *identifier in HeyIOSTypeIdentifiers(action)) { UTType *t = [UTType typeWithIdentifier:identifier]; if (t) [types addObject:t]; }
  if (types.count == 0) [types addObject:UTTypeText];
  UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
  HeyIOSDocumentPick *delegate = [[HeyIOSDocumentPick alloc] init];
  delegate.host = host;
  delegate.action = action;
  delegate.vars = vars;
  picker.delegate = delegate;
  HeyIOSDocumentKeeper = delegate;
  [host presentViewController:picker animated:YES completion:nil];
}

static void HeyIOSPlayVideo(UIViewController *host, NSString *value) {
  NSURL *url = HeyIOSAddress(value);
  if (url == nil) return;
  AVPlayerViewController *player = [[AVPlayerViewController alloc] init];
  player.player = [AVPlayer playerWithURL:url];
  [host presentViewController:player animated:YES completion:^{ [player.player play]; }];
}

// Choices from a route ({method, path, list, value, label, where}) or a
// literal list ({title, value}), offered as an action sheet; the chosen value
// is $value (and $<set_var>) for what follows.
static void HeyIOSChoose(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, NSDictionary *vars, id row, UIView *source, void (^then)(NSDictionary *vars)) {
  void (^offer)(NSArray *) = ^(NSArray *options) {
    if (options.count == 0) { HeyIOSAlert(host, HS(action[@"title"]), HS(action[@"empty"])); return; }
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:HS(action[@"title"]) message:HS(action[@"prompt_text"]).length ? HS(action[@"prompt_text"]) : nil preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSDictionary *option in options) {
      [sheet addAction:[UIAlertAction actionWithTitle:HS(option[@"title"]) style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSMutableDictionary *next = [vars mutableCopy];
        next[@"value"] = option[@"value"] ?: @"";
        next[@"value_title"] = HS(option[@"title"]);
        if (HS(action[@"set_var"]).length > 0) next[HS(action[@"set_var"])] = option[@"value"] ?: @"";
        then(next);
      }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    HeyIOSPresentSheet(host, sheet, source);
  };
  NSDictionary *choices = HD(action[@"choices"]);
  if (choices.count == 0) { offer(HA(action[@"options"])); return; }
  [[HeyIOSApi shared] send:choices vars:vars row:row completion:^(NSInteger status, id json, NSString *error) {
    if (error != nil) { HeyIOSAlert(host, HS(action[@"failed_title"]), error); return; }
    NSMutableArray *options = [NSMutableArray arrayWithArray:HA(action[@"options"])];
    for (NSDictionary *choice in HA(HeyIOSAt(json, HS(choices[@"list"])))) {
      if (!HeyIOSCondition(choices[@"where"], choice)) continue;
      NSString *value = HS(HeyIOSAt(choice, HS(choices[@"value"])));
      NSString *label = HeyIOSLine(choices[@"label"], choice);
      [options addObject:@{@"title": label.length ? label : value, @"value": value}];
    }
    offer(options);
  }];
}

static void HeyIOSOpenScreenFrom(UIViewController<HeyIOSActionHost> *host, NSDictionary *spec, NSDictionary *vars, id row) {
  NSMutableDictionary *params = [NSMutableDictionary dictionary];
  [HD(spec[@"params"]) enumerateKeysAndObjectsUsingBlock:^(id key, id path, BOOL *stop) {
    params[key] = HeyIOSParam(path, vars, row, [host screenJSON]);
  }];
  HeyIOSOpenScreen(host, HS(spec[@"screen"]), params);
}

// EVERY ACTION A DESCRIPTION CAN NAME. kind: request (the default), choose,
// rating, open_url, open_screen, share, copy, video, web_sign_in, document,
// set_var. Any kind may ask first: prompt {fields} or confirm {title, button}.
// AN ACTION THIS RENDERER DOES NOT RECOGNISE DOES NOTHING. It is hidden where
// it would be drawn, and refused again here, so no path sends its request.
static void HeyIOSRunAction(UIViewController<HeyIOSActionHost> *host, NSDictionary *action, id row, UIView *source) {
  if (!HeyIOSKnownAction(action)) return;
  NSDictionary *vars = HeyIOSVarsWith(host, row, nil);
  NSString *kind = HeyIOSActionKind(action);
  id json = [host screenJSON];
  id subject = row ?: json;
  if ([kind isEqualToString:@"open_url"]) {
    NSURL *url = HeyIOSAddress(HeyIOSLine(action[@"value"], subject));
    if (url) [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    return;
  }
  if ([kind isEqualToString:@"open_screen"]) { HeyIOSOpenScreenFrom(host, action, vars, row); return; }
  if ([kind isEqualToString:@"video"]) { HeyIOSPlayVideo(host, HeyIOSLine(action[@"value"], subject)); return; }
  if ([kind isEqualToString:@"share"] || [kind isEqualToString:@"copy"]) {
    NSString *value = HeyIOSLine(action[@"value"], subject);
    if ([kind isEqualToString:@"copy"]) { [UIPasteboard generalPasteboard].string = value; HeyIOSToast(host, HS(action[@"done"])); return; }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL URLWithString:value] ?: value] applicationActivities:nil];
    share.popoverPresentationController.sourceView = source ?: host.view;
    [host presentViewController:share animated:YES completion:nil];
    return;
  }
  if ([kind isEqualToString:@"rating"]) {
    id raw = HeyIOSAt(subject, HS(action[@"current_halves"]));
    NSInteger current = [raw respondsToSelector:@selector(integerValue)] ? [raw integerValue] : 0;
    HeyIOSChooseRating(host, HS(action[@"title"]), current, ^(NSInteger halves) {
      NSMutableDictionary *next = [vars mutableCopy];
      next[@"value"] = @(halves);
      HeyIOSSend(host, action, next, row);
    });
    return;
  }
  void (^perform)(NSDictionary *) = ^(NSDictionary *ready) {
    if ([kind isEqualToString:@"web_sign_in"]) { HeyIOSWebSignIn(host, action, ready, row); return; }
    if ([kind isEqualToString:@"document"]) { HeyIOSPickDocument(host, action, ready); return; }
    if ([kind isEqualToString:@"set_var"]) { [[host vars] addEntriesFromDictionary:ready]; [host reloadContent]; return; }
    NSDictionary *next = HD(action[@"then_action"]);
    if (next.count > 0 && HS(action[@"request"]).length == 0 && HD(action[@"request"]).count == 0) {
      [[host vars] addEntriesFromDictionary:ready];
      HeyIOSRunAction(host, next, row, source);
      return;
    }
    HeyIOSSend(host, action, ready, row);
  };
  void (^asked)(NSDictionary *) = ^(NSDictionary *chosen) {
    // A chosen value named by set_var belongs to the screen from now on, so
    // its sections send it when they reload.
    NSString *keepAs = HS(action[@"set_var"]);
    if (keepAs.length > 0) {
      [host vars][keepAs] = chosen[keepAs] ?: @"";
      [host vars][[keepAs stringByAppendingString:@"_title"]] = chosen[@"value_title"] ?: @"";
    }
    if (HD(action[@"prompt"]).count > 0) { HeyIOSPrompt(host, action, chosen, row, perform); return; }
    perform(chosen);
  };
  void (^confirmed)(void) = ^{
    if ([kind isEqualToString:@"choose"]) { HeyIOSChoose(host, action, vars, row, source, asked); return; }
    asked(vars);
  };
  if (HD(action[@"confirm"]).count > 0) { HeyIOSConfirm(host, action, source, confirmed); return; }
  confirmed();
}

// The picture, title, lines and body at the top of a screen that has a source.
static UIView *HeyIOSHeaderView(NSDictionary *header, id json, NSString *message, CGFloat width) {
  UIStackView *stack = [[UIStackView alloc] init];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.spacing = 8;
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  NSString *imageAddress = HeyIOSLine(header[@"image"], json);
  if (imageAddress.length > 0) {
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.clipsToBounds = YES;
    imageView.layer.cornerRadius = 10;
    [imageView.heightAnchor constraintEqualToConstant:200].active = YES;
    imageView.image = [HeyIOSImageCache() objectForKey:imageAddress];
    if (imageView.image == nil) HeyIOSLoadImage(imageAddress, ^(UIImage *image) { imageView.image = image; });
    [stack addArrangedSubview:imageView];
  }
  NSString *titleText = json ? HeyIOSLine(header[@"title"], json) : (message ?: @"");
  if (titleText.length == 0 && HS(header[@"title_text"]).length > 0) titleText = HeyIOSText(header[@"title_text"], json);
  UILabel *title = [[UILabel alloc] init];
  title.text = titleText;
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle2];
  title.numberOfLines = 0;
  [stack addArrangedSubview:title];
  NSString *subtitleText = HeyIOSLine(header[@"subtitle"], json);
  if (subtitleText.length > 0) {
    UILabel *subtitle = [[UILabel alloc] init];
    subtitle.attributedText = HeyIOSStyled(subtitleText, [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline], [UIColor secondaryLabelColor]);
    subtitle.numberOfLines = 0;
    [stack addArrangedSubview:subtitle];
  }
  NSString *bodyText = HeyIOSLine(header[@"body"], json);
  if (bodyText.length == 0 && HS(header[@"body_text"]).length > 0) bodyText = HeyIOSText(header[@"body_text"], json);
  if (bodyText.length > 0) {
    UILabel *body = [[UILabel alloc] init];
    body.text = bodyText;
    body.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    body.numberOfLines = 0;
    [stack addArrangedSubview:body];
  }
  UIView *container = [[UIView alloc] init];
  [container addSubview:stack];
  [NSLayoutConstraint activateConstraints:@[
    [stack.leadingAnchor constraintEqualToAnchor:container.leadingAnchor constant:20],
    [stack.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-20],
    [stack.topAnchor constraintEqualToAnchor:container.topAnchor constant:12],
    [stack.bottomAnchor constraintEqualToAnchor:container.bottomAnchor constant:-4]
  ]];
  CGSize size = [container systemLayoutSizeFittingSize:CGSizeMake(width, UILayoutFittingCompressedSize.height) withHorizontalFittingPriority:UILayoutPriorityRequired verticalFittingPriority:UILayoutPriorityFittingSizeLevel];
  container.frame = CGRectMake(0, 0, width, size.height);
  return container;
}

@interface HeyIOSListController : UITableViewController <UISearchBarDelegate, HeyIOSVarsReceiver, HeyIOSActionHost, HeyIOSTypedValues>
@property(nonatomic, strong, nullable) NSDictionary *inlineRating;
@property(nonatomic, weak, nullable) UILabel *ratingNumber;
@property(nonatomic, weak, nullable) HeyIOSStarControl *ratingControl;
@property(nonatomic, assign) NSInteger pendingHalves;
@property(nonatomic, assign) BOOL ratingSending;
@property(nonatomic, strong, nullable) id screenJSON;
@property(nonatomic, copy, nullable) NSString *screenMessage;
@property(nonatomic, strong) NSDictionary *screen;
@property(nonatomic, strong) NSMutableDictionary *vars;
@property(nonatomic, strong) NSMutableArray<NSMutableDictionary *> *sections;
@property(nonatomic, strong, nullable) UISearchBar *searchBar;
@property(nonatomic, strong) NSMutableSet<NSString *> *added;
@property(nonatomic, assign) NSInteger generation;
@property(nonatomic, assign) BOOL appleMusic;
@property(nonatomic, strong, nullable) UILabel *nowPlayingLabel;
@property(nonatomic, strong, nullable) UIButton *nowPlayingButton;
@end

@implementation HeyIOSListController

- (instancetype)initWithScreen:(NSDictionary *)screen vars:(NSDictionary *)vars {
  self = [super initWithStyle:UITableViewStyleInsetGrouped];
  if (self) {
    _screen = screen;
    _vars = [vars mutableCopy] ?: [NSMutableDictionary dictionary];
    _sections = [NSMutableArray array];
    _added = [NSMutableSet set];
  }
  return self;
}

- (NSString *)type { return HS(self.screen[@"type"]); }

- (NSArray *)sectionSpecs {
  if ([[self type] isEqualToString:@"audio"]) return HA(HD([HeyIOSApi shared].manifest[@"audio"])[@"sections"]);
  return HA(self.screen[@"sections"]);
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.title = HS(self.screen[@"title"]);
  self.tableView.accessibilityIdentifier = HS(self.screen[@"id"]);
  // The table's own gap above every section header, hidden sections included,
  // added up to a screen-high blank on the item screen; heights come from
  // heightForHeaderInSection instead.
  self.tableView.sectionHeaderTopPadding = 0;
  [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"row"];
  NSDictionary *right = HD(self.screen[@"nav_right"]);
  if (right.count > 0 && (HD(right[@"action"]).count == 0 || HeyIOSKnownAction(right[@"action"]))) {
    UIBarButtonItem *item = HeyIOSImage(right) != nil
      ? [[UIBarButtonItem alloc] initWithImage:HeyIOSImage(right) style:UIBarButtonItemStylePlain target:self action:@selector(navRight)]
      : [[UIBarButtonItem alloc] initWithTitle:HS(right[@"title"]) style:UIBarButtonItemStylePlain target:self action:@selector(navRight)];
    item.accessibilityLabel = HS(right[@"title"]);
    self.navigationItem.rightBarButtonItem = item;
  }
  // THE WAY TO YOUR ACCOUNT, on every tab's first screen: a person symbol in
  // the navigation bar, the place iOS apps put it (reported: a Sign out
  // button with no way to reach the account itself).
  NSDictionary *left = HD(self.screen[@"nav_left"]);
  if (left.count > 0) {
    UIBarButtonItem *item = HeyIOSImage(left) != nil
      ? [[UIBarButtonItem alloc] initWithImage:HeyIOSImage(left) style:UIBarButtonItemStylePlain target:self action:@selector(navLeft)]
      : [[UIBarButtonItem alloc] initWithTitle:HS(left[@"title"]) style:UIBarButtonItemStylePlain target:self action:@selector(navLeft)];
    item.accessibilityLabel = HS(left[@"title"]);
    item.accessibilityIdentifier = HS(left[@"screen"]);
    self.navigationItem.leftBarButtonItem = item;
  }
  if (HA(self.screen[@"menu"]).count > 0 || HD(self.screen[@"reorder"]).count > 0) [self rebuildMenu];
  if ([[self type] isEqualToString:@"search"]) {
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 320, 56)];
    self.searchBar.placeholder = HS(self.screen[@"placeholder"]);
    self.searchBar.delegate = self;
    self.searchBar.searchBarStyle = UISearchBarStyleMinimal;
    self.searchBar.text = HS(self.vars[@"query"]);
    self.tableView.tableHeaderView = self.searchBar;
  } else {
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(load) forControlEvents:UIControlEventValueChanged];
  }
  if ([[self type] isEqualToString:@"audio"]) {
    [self buildNowPlaying];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audioChanged) name:HeyIOSAudioStateDidChange object:nil];
  }
  [self resetSections];
  [self load];
}

// A list that shows what other screens change (the library, after Add in
// Search) reads again when it comes back into view: reload_on_appear.
- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];
  if ([self.screen[@"reload_on_appear"] boolValue] && self.generation > 0) [self load];
}

- (void)resetSections {
  [self.sections removeAllObjects];
  for (NSDictionary *spec in [self sectionSpecs]) {
    // A section kind this renderer does not know is not drawn.
    if (!HeyIOSKnownSection(spec)) continue;
    [self.sections addObject:[@{@"spec": spec, @"rows": @[], @"footer": @""} mutableCopy]];
  }
  if ([[self type] isEqualToString:@"search"] && HS(self.vars[@"query"]).length == 0 && self.sections.count > 0) {
    self.sections[0][@"footer"] = HS(self.screen[@"hint"]);
  }
  [self.tableView reloadData];
}

- (void)applyVars:(NSDictionary *)vars {
  [self.vars addEntriesFromDictionary:vars];
  if (self.searchBar) self.searchBar.text = HS(self.vars[@"query"]);
  if (self.isViewLoaded) { [self resetSections]; [self load]; }
}

- (void)reloadContent { [self load]; }

// Something a person typed that a redraw would lose.
- (BOOL)hasTypedValues { return self.searchBar.text.length > 0; }

- (void)paintRatingNumber:(NSInteger)halves {
  NSDictionary *row = self.inlineRating;
  self.ratingNumber.text = halves > 0 ? [NSString stringWithFormat:@"%g out of 5", halves / 2.0] : (HS(row[@"unrated"]).length ? HS(row[@"unrated"]) : @"Not rated");
}

- (void)inlineRated:(HeyIOSStarControl *)control {
  self.pendingHalves = control.halves;
  self.ratingSending = YES;
  [self paintRatingNumber:control.halves];
  [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(sendInlineRating) object:nil];
  [self performSelector:@selector(sendInlineRating) withObject:nil afterDelay:0.7];
}

- (void)sendInlineRating {
  NSDictionary *action = self.inlineRating;
  NSInteger halves = self.pendingHalves;
  NSDictionary *vars = HeyIOSVarsWith(self, nil, @{@"value": @(halves)});
  [[HeyIOSApi shared] send:HD(action[@"request"]) vars:vars row:nil completion:^(NSInteger status, id json, NSString *error) {
    self.ratingSending = NO;
    if (error != nil) { HeyIOSAlert(self, HS(action[@"failed_title"]), error); [self load]; return; }
    HeyIOSToast(self, halves > 0 ? HS(action[@"done"]) : HS(action[@"cleared"]));
    [self load];
  }];
}

- (void)navLeft {
  NSDictionary *left = HD(self.screen[@"nav_left"]);
  if (HS(left[@"screen"]).length > 0) HeyIOSOpenScreen(self, HS(left[@"screen"]), @{});
}

// The screen's own actions, in a menu behind the ellipsis, offered only when
// their condition holds on what the screen loaded; and Edit when the list can
// be reordered by dragging.
- (void)rebuildMenu {
  NSMutableArray<UIBarButtonItem *> *items = [NSMutableArray array];
  NSDictionary *right = HD(self.screen[@"nav_right"]);
  if (right.count > 0 && self.navigationItem.rightBarButtonItem && ![self.navigationItem.rightBarButtonItem.accessibilityIdentifier isEqualToString:@"menu"] && ![self.navigationItem.rightBarButtonItem.accessibilityIdentifier isEqualToString:@"reorder"]) {
    [items addObject:self.navigationItem.rightBarButtonItems.lastObject ?: self.navigationItem.rightBarButtonItem];
  }
  NSMutableArray<UIMenuElement *> *elements = [NSMutableArray array];
  for (NSDictionary *action in HA(self.screen[@"menu"])) {
    if (!HeyIOSKnownAction(action) || !HeyIOSCondition(action[@"when"], self.screenJSON)) continue;
    UIAction *element = [UIAction actionWithTitle:HeyIOSText(action[@"title"], self.screenJSON) image:HeyIOSImage(action) identifier:nil handler:^(UIAction *a) { HeyIOSRunAction(self, action, nil, nil); }];
    if ([HS(action[@"style"]) isEqualToString:@"destructive"]) element.attributes = UIMenuElementAttributesDestructive;
    [elements addObject:element];
  }
  if (elements.count > 0) {
    UIBarButtonItem *menu = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"ellipsis.circle"] menu:[UIMenu menuWithChildren:elements]];
    menu.accessibilityIdentifier = @"menu";
    menu.accessibilityLabel = @"More";
    [items insertObject:menu atIndex:0];
  }
  NSDictionary *reorder = HD(self.screen[@"reorder"]);
  if (reorder.count > 0 && HeyIOSCondition(reorder[@"when"], self.screenJSON)) {
    UIBarButtonItem *edit = [[UIBarButtonItem alloc] initWithTitle:self.tableView.editing ? @"Done" : HS(reorder[@"title"]) style:self.tableView.editing ? UIBarButtonItemStyleDone : UIBarButtonItemStylePlain target:self action:@selector(toggleReorder)];
    edit.accessibilityIdentifier = @"reorder";
    [items addObject:edit];
  }
  self.navigationItem.rightBarButtonItems = items;
}

- (void)toggleReorder {
  [self.tableView setEditing:!self.tableView.editing animated:YES];
  [self rebuildMenu];
}

// Sections with no route of their own, filled from the screen's JSON.
- (void)fillStaticSections {
  id json = self.screenJSON;
  for (NSMutableDictionary *section in self.sections) {
    NSDictionary *spec = section[@"spec"];
    NSString *kind = HeyIOSSectionKind(spec);
    if ([kind isEqualToString:@"route"]) continue;
    NSMutableArray *rows = [NSMutableArray array];
    // A section whose condition fails is not drawn at all, title included
    // (seen: an offer's heading over nothing, on an item with no offer).
    section[@"hidden"] = @(!HeyIOSCondition(spec[@"when"], json));
    if ([section[@"hidden"] boolValue]) { section[@"rows"] = rows; section[@"footer"] = @""; continue; }
    if ([kind isEqualToString:@"fields"]) {
      for (NSDictionary *field in HA(spec[@"fields"])) {
        if (!HeyIOSCondition(field[@"when"], json)) continue;
        NSString *value = HeyIOSLine(field[@"value"], json);
        if (value.length > 0) [rows addObject:@{@"label": HS(field[@"label"]), @"value": value, @"spec": field}];
      }
    } else if ([kind isEqualToString:@"actions"]) {
      for (NSDictionary *action in HA(spec[@"actions"])) if (HeyIOSKnownAction(action) && HeyIOSCondition(action[@"when"], json)) [rows addObject:action];
    } else if ([kind isEqualToString:@"rows"]) {
      for (NSDictionary *row in HA(spec[@"rows"])) if (HeyIOSKnownRow(row) && HeyIOSCondition(row[@"when"], json)) [rows addObject:row];
    } else {
      for (id row in HA(HeyIOSAt(json, HS(spec[@"from"])))) if (HeyIOSCondition(spec[@"where"], row)) [rows addObject:row];
    }
    section[@"rows"] = rows;
    section[@"footer"] = rows.count == 0 ? HS(spec[@"empty"]) : HS(spec[@"note"]);
  }
  [self loadBadges];
#if TARGET_OS_SIMULATOR
  // Simulator-only: -HeyIOSDevAction "<title>" runs that button, or that menu
  // action, once, so a run can photograph a sheet or a question without a tap.
  static NSMutableSet *devRan;
  if (devRan == nil) devRan = [NSMutableSet set];
  NSString *devAction = [[NSUserDefaults standardUserDefaults] stringForKey:@"HeyIOSDevAction"];
  if (devAction.length > 0 && ![devRan containsObject:devAction]) {
    NSMutableArray *candidates = [NSMutableArray arrayWithArray:HA(self.screen[@"menu"])];
    for (NSDictionary *section in self.sections) if ([HeyIOSSectionKind(section[@"spec"]) isEqualToString:@"actions"]) [candidates addObjectsFromArray:HA(section[@"rows"])];
    for (NSDictionary *action in candidates) {
      if ([HeyIOSText(action[@"title"], self.screenJSON) isEqualToString:devAction]) {
        [devRan addObject:devAction];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ HeyIOSRunAction(self, action, nil, self.tableView); });
        break;
      }
    }
  }
#endif
}

// A literal row may carry a count from a route: {source, count} (the length of
// an array) or {source, path} (a number).
- (void)loadBadges {
  for (NSUInteger s = 0; s < self.sections.count; s++) {
    NSDictionary *spec = self.sections[s][@"spec"];
    if (![HeyIOSSectionKind(spec) isEqualToString:@"rows"]) continue;
    NSArray *rows = HA(self.sections[s][@"rows"]);
    for (NSUInteger r = 0; r < rows.count; r++) {
      NSDictionary *badge = HD(HD(rows[r])[@"badge"]);
      if (badge.count == 0) continue;
      [[HeyIOSApi shared] send:HD(badge[@"source"]) vars:self.vars row:nil completion:^(NSInteger status, id json, NSString *error) {
        if (error != nil || s >= self.sections.count) return;
        NSInteger n = HS(badge[@"count"]).length ? (NSInteger)HA(HeyIOSAt(json, HS(badge[@"count"]))).count : [HeyIOSAt(json, HS(badge[@"path"])) integerValue];
        NSMutableArray *now = [HA(self.sections[s][@"rows"]) mutableCopy];
        if (r >= now.count) return;
        NSMutableDictionary *row = [HD(now[r]) mutableCopy];
        row[@"_badge"] = n > 0 ? [NSString stringWithFormat:@"%ld", (long)n] : @"";
        now[r] = row;
        self.sections[s][@"rows"] = now;
        [self.tableView reloadData];
      }];
    }
  }
}

- (void)navRight {
  NSDictionary *right = HD(self.screen[@"nav_right"]);
  if (right[@"action"] && [right[@"action"] isKindOfClass:[NSDictionary class]]) { HeyIOSRunAction(self, right[@"action"], nil, nil); return; }
  if ([HS(right[@"action"]) isEqualToString:@"sign_out"]) {
    HeyIOSApi *api = [HeyIOSApi shared];
    [api send:HD(HD(api.manifest[@"session"])[@"sign_out"]) vars:@{} row:nil completion:^(NSInteger status, id json, NSString *error) {
      [api clearToken];
      [[NSNotificationCenter defaultCenter] postNotificationName:HeyIOSSignedOutNotification object:nil];
    }];
    return;
  }
  if (HS(right[@"screen"]).length > 0) HeyIOSOpenScreen(self, HS(right[@"screen"]), self.vars);
}

- (void)load {
  NSInteger generation = ++self.generation;
  if ([[self type] isEqualToString:@"audio"]) {
    HeyIOSLoadAudio(^(NSArray<NSDictionary *> *sections, NSString *message) {
      HeyIOSAudioCheckAppleMusic(^(BOOL appleMusic) {
        if (generation != self.generation) return;
        self.appleMusic = appleMusic;
        for (NSUInteger i = 0; i < self.sections.count; i++) {
          NSArray *rows = i < sections.count ? HA(sections[i][@"rows"]) : @[];
          NSMutableArray *playable = [NSMutableArray array];
          for (NSDictionary *row in rows) if ([row[@"_waiting"] boolValue] || HeyIOSAudioRowPlayable(row, appleMusic)) [playable addObject:row];
          // While anything is waiting, read the lists again on a timer, as
          // long as this screen is on show.
          double every = [HD(self.sections[i][@"spec"])[@"refresh_seconds"] doubleValue];
          if (every > 0 && [HD(self.sections[i][@"spec"])[@"waiting"] boolValue] && rows.count > 0) {
            __weak typeof(self) weakSelf = self;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(every * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
              if (weakSelf.view.window != nil && generation == weakSelf.generation) [weakSelf load];
            });
          }
          self.sections[i][@"rows"] = playable;
          // EVERY LIST SAYS WHAT BELONGS IN IT (reported: an empty Listen tab
          // explained nothing). note when it has rows, empty_note when not.
          NSDictionary *sectionSpec = HD(self.sections[i][@"spec"]);
          self.sections[i][@"footer"] = playable.count == 0 ? HS(sectionSpec[@"empty_note"]) : HS(sectionSpec[@"note"]);
        }
        BOOL nothing = YES;
        for (NSDictionary *section in self.sections) if (HA(section[@"rows"]).count > 0) nothing = NO;
        [self audioExplainer:nothing message:message];
        if (message.length > 0 && self.sections.count > 0) self.sections[0][@"footer"] = message;
        [self.refreshControl endRefreshing];
        [self.tableView reloadData];
#if TARGET_OS_SIMULATOR
        // Simulator-only: -HeyIOSDevPlayTitle "<title>" plays that row once the
        // lists arrive, so a run can prove playback without a tap.
        static BOOL devPlayed = NO;
        NSString *devTitle = [[NSUserDefaults standardUserDefaults] stringForKey:@"HeyIOSDevPlayTitle"];
        if (!devPlayed && devTitle.length > 0) {
          for (NSDictionary *section in self.sections) {
            for (NSDictionary *row in HA(section[@"rows"])) {
              if ([HS(row[@"title"]) isEqualToString:devTitle]) {
                devPlayed = YES;
                [[HeyIOSAudio shared] playRow:row];
              }
            }
          }
        }
#endif
      });
    });
    return;
  }
  if ([[self type] isEqualToString:@"search"] && HS(self.vars[@"query"]).length == 0) {
    [self.refreshControl endRefreshing];
    return;
  }
  NSDictionary *source = HD(self.screen[@"source"]);
  if (source.count > 0) {
    [[HeyIOSApi shared] send:source vars:self.vars row:nil completion:^(NSInteger status, id json, NSString *error) {
      if (generation != self.generation) return;
      [self.refreshControl endRefreshing];
      self.screenJSON = error == nil ? json : nil;
      self.screenMessage = error;
      NSString *titled = HeyIOSLine(self.screen[@"title_from"], json);
      if (titled.length > 0) self.navigationItem.title = titled;
      if (HD(self.screen[@"header"]).count > 0 || error != nil) {
        CGFloat width = self.tableView.bounds.size.width > 0 ? self.tableView.bounds.size.width : UIScreen.mainScreen.bounds.size.width;
        self.tableView.tableHeaderView = HeyIOSHeaderView(HD(self.screen[@"header"]), self.screenJSON, error, width);
      }
      [self fillStaticSections];
      [self rebuildMenu];
      [self.tableView reloadData];
      for (NSUInteger i = 0; i < self.sections.count; i++) {
        if ([HeyIOSSectionKind(self.sections[i][@"spec"]) isEqualToString:@"route"]) [self loadSection:i attempt:0 generation:generation];
      }
    }];
    return;
  }
  [self fillStaticSections];
  [self.tableView reloadData];
  BOOL anyRoute = NO;
  for (NSUInteger i = 0; i < self.sections.count; i++) {
    if ([HeyIOSSectionKind(self.sections[i][@"spec"]) isEqualToString:@"route"]) { anyRoute = YES; [self loadSection:i attempt:0 generation:generation]; }
  }
  if (!anyRoute) [self.refreshControl endRefreshing];
}

- (void)loadSection:(NSUInteger)index attempt:(NSInteger)attempt generation:(NSInteger)generation {
  NSMutableDictionary *section = self.sections[index];
  NSDictionary *spec = section[@"spec"];
  NSDictionary *route = HD(spec[@"source"]).count > 0 ? HD(spec[@"source"]) : HD(spec[@"request"]);
  // `when` holds for a section with a route too: read against the screen's
  // answer, and a section whose condition fails asks for nothing.
  if (!HeyIOSCondition(spec[@"when"], self.screenJSON)) {
    section[@"hidden"] = @YES;
    section[@"rows"] = @[];
    section[@"footer"] = @"";
    [self.refreshControl endRefreshing];
    [self.tableView reloadData];
    return;
  }
  section[@"hidden"] = @NO;
  if (attempt == 0 && [[self type] isEqualToString:@"search"]) {
    section[@"rows"] = @[];
    section[@"footer"] = HS(spec[@"pending_note"]);
    [self.tableView reloadData];
  }
  HeyIOSApi *api = [HeyIOSApi shared];
  [api send:route vars:self.vars row:nil completion:^(NSInteger status, id json, NSString *error) {
    if (generation != self.generation) return;
    [self.refreshControl endRefreshing];
    NSDictionary *fixture = HD(api.manifest[@"find_fixture"]);
    if (status == 404 && fixture.count > 0 && [spec[@"fixture_when_missing"] boolValue]) {
      section[@"rows"] = HeyIOSGroupRows(HA(HeyIOSAt(fixture, HS(spec[@"list"]))), spec);
      section[@"footer"] = HS(spec[@"fixture_note"]);
      if (HeyIOSTruthy(fixture, HS(spec[@"incomplete_key"]))) section[@"footer"] = [NSString stringWithFormat:@"%@ %@", HS(spec[@"fixture_note"]), HS(spec[@"incomplete_note"])];
      [self.tableView reloadData];
      return;
    }
    if (error != nil) {
      section[@"rows"] = @[];
      section[@"footer"] = error;
      [self.tableView reloadData];
      return;
    }
    NSDictionary *poll = HD(spec[@"poll"]);
    NSMutableArray *rows = [NSMutableArray array];
    for (id candidate in HeyIOSGroupRows(HA(HeyIOSAt(json, HS(spec[@"list"]))), spec)) if (HeyIOSCondition(spec[@"where"], candidate)) [rows addObject:candidate];
    section[@"rows"] = rows;
    BOOL pending = poll.count > 0 && [HS(HeyIOSAt(json, HS(poll[@"key"]))) isEqualToString:HS(poll[@"pending"])];
    if (pending && attempt + 1 < [poll[@"max"] integerValue]) {
      section[@"footer"] = HS(spec[@"pending_note"]);
      double delay = [poll[@"every_ms"] doubleValue] / 1000.0;
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (generation == self.generation) [self loadSection:index attempt:attempt + 1 generation:generation];
      });
    } else if (pending) {
      section[@"footer"] = HS(spec[@"gave_up_note"]);
    } else {
      section[@"footer"] = rows.count == 0 ? HS(spec[@"empty"]) : HS(spec[@"note"]);
      if (HeyIOSTruthy(json, HS(spec[@"incomplete_key"]))) section[@"footer"] = HS(spec[@"incomplete_note"]);
    }
    [self.tableView reloadData];
  }];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
  [searchBar resignFirstResponder];
  self.vars[@"query"] = searchBar.text ?: @"";
  [self.added removeAllObjects];
  [self resetSections];
  [self load];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { (void)tableView; return (NSInteger)self.sections.count; }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  (void)tableView;
  return (NSInteger)HA(self.sections[section][@"rows"]).count;
}

- (BOOL)hiddenSection:(NSInteger)section {
  NSDictionary *spec = HD(self.sections[section][@"spec"]);
  if ([self.sections[section][@"hidden"] boolValue]) return YES;
  return [spec[@"hide_when_empty"] boolValue] && HA(self.sections[section][@"rows"]).count == 0;
}

// A hidden section takes no room: its header and footer gaps went too (seen:
// a screen-high blank between an item's link and its buttons).
// An inset-grouped table still draws its default header and footer views for
// a section that returns a near-zero height but no view; an empty view of its
// own is what makes a hidden section take no room.
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
  return [self hiddenSection:section] ? [[UIView alloc] initWithFrame:CGRectZero] : nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
  return [self hiddenSection:section] ? [[UIView alloc] initWithFrame:CGRectZero] : nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
  if ([self hiddenSection:section]) return CGFLOAT_MIN;
  if (HeyIOSText(HD(self.sections[section][@"spec"])[@"title"], self.screenJSON).length == 0) return 12;
  return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
  if ([self hiddenSection:section]) return CGFLOAT_MIN;
  if (HS(self.sections[section][@"footer"]).length == 0) return 12;
  return UITableViewAutomaticDimension;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
  (void)tableView;
  if ([self hiddenSection:section]) return nil;
  NSString *title = HeyIOSText(HD(self.sections[section][@"spec"])[@"title"], self.screenJSON);
  return title.length > 0 ? title : nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
  (void)tableView;
  if ([self hiddenSection:section]) return nil;
  NSString *footer = HS(self.sections[section][@"footer"]);
  return footer.length > 0 ? footer : nil;
}

- (NSDictionary *)rowSpecFor:(NSInteger)section {
  if ([[self type] isEqualToString:@"audio"]) return @{@"title": @"title", @"subtitle": @"subtitle", @"image": @"image_url", @"symbol_fields": @[@"symbol"]};
  NSDictionary *spec = HD(self.sections[section][@"spec"]);
  if ([HeyIOSSectionKind(spec) isEqualToString:@"rows"]) return @{@"title": @"title", @"subtitle": @"subtitle", @"symbol_fields": @[@"icon", @"symbol"]};
  return HD(spec[@"row"]);
}

- (NSArray *)rowActionsFor:(NSIndexPath *)indexPath {
  NSDictionary *spec = HD(self.sections[indexPath.section][@"spec"]);
  id row = HA(self.sections[indexPath.section][@"rows"])[indexPath.row];
  NSMutableArray *out = [NSMutableArray array];
  for (NSDictionary *action in HA(spec[@"row_actions"])) if (HeyIOSKnownAction(action) && HeyIOSCondition(action[@"when"], row)) [out addObject:action];
  return out;
}

- (UIMenu *)menuForRow:(NSIndexPath *)indexPath from:(UIView *)source {
  id row = HA(self.sections[indexPath.section][@"rows"])[indexPath.row];
  NSMutableArray *elements = [NSMutableArray array];
  for (NSDictionary *action in [self rowActionsFor:indexPath]) {
    UIAction *element = [UIAction actionWithTitle:HeyIOSText(action[@"title"], row) image:HeyIOSImage(action) identifier:nil handler:^(UIAction *a) { HeyIOSRunAction(self, action, row, source); }];
    if ([HS(action[@"style"]) isEqualToString:@"destructive"]) element.attributes = UIMenuElementAttributesDestructive;
    [elements addObject:element];
  }
  return [UIMenu menuWithChildren:elements];
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath {
  NSArray *actions = [self rowActionsFor:indexPath];
  if (actions.count == 0) return nil;
  id row = HA(self.sections[indexPath.section][@"rows"])[indexPath.row];
  UIView *source = [tableView cellForRowAtIndexPath:indexPath];
  NSMutableArray *swipes = [NSMutableArray array];
  for (NSDictionary *action in [actions subarrayWithRange:NSMakeRange(0, MIN(actions.count, 3))]) {
    BOOL destructive = [HS(action[@"style"]) isEqualToString:@"destructive"];
    UIContextualAction *swipe = [UIContextualAction contextualActionWithStyle:destructive ? UIContextualActionStyleDestructive : UIContextualActionStyleNormal title:HeyIOSText(action[@"short_title"] ?: action[@"title"], row) handler:^(UIContextualAction *a, UIView *v, void (^done)(BOOL)) {
      done(YES);
      HeyIOSRunAction(self, action, row, source);
    }];
    if (!destructive) swipe.backgroundColor = swipes.count == 0 ? self.view.tintColor : [UIColor systemGrayColor];
    [swipes addObject:swipe];
  }
  UISwipeActionsConfiguration *config = [UISwipeActionsConfiguration configurationWithActions:swipes];
  config.performsFirstActionWithFullSwipe = NO;
  return config;
}

- (UIContextMenuConfiguration *)tableView:(UITableView *)tableView contextMenuConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath point:(CGPoint)point {
  if ([self rowActionsFor:indexPath].count == 0) return nil;
  UIView *source = [tableView cellForRowAtIndexPath:indexPath];
  return [UIContextMenuConfiguration configurationWithIdentifier:nil previewProvider:nil actionProvider:^UIMenu *(NSArray<UIMenuElement *> *suggested) { return [self menuForRow:indexPath from:source]; }];
}

// DRAGGING A ROW IS A SERIES OF ONE-STEP MOVES, the only move the route knows:
// {request with $direction, up, down}. The list reloads from the server after.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
  return HD(HD(self.sections[indexPath.section][@"spec"])[@"reorder"]).count > 0;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath { return UITableViewCellEditingStyleNone; }
- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath { return NO; }
- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)from toProposedIndexPath:(NSIndexPath *)to {
  if (to.section != from.section) return from;
  return to;
}
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)from toIndexPath:(NSIndexPath *)to {
  if (from.section != to.section || from.row == to.row) return;
  NSMutableArray *rows = [HA(self.sections[from.section][@"rows"]) mutableCopy];
  id row = rows[from.row];
  [rows removeObjectAtIndex:from.row];
  [rows insertObject:row atIndex:to.row];
  self.sections[from.section][@"rows"] = rows;
  NSDictionary *reorder = HD(HD(self.sections[from.section][@"spec"])[@"reorder"]);
  NSInteger steps = labs((long)(to.row - from.row));
  NSString *direction = to.row < from.row ? HS(reorder[@"up"]) : HS(reorder[@"down"]);
  NSDictionary *vars = HeyIOSVarsWith(self, row, @{@"direction": direction});
  __block void (^step)(NSInteger);
  __block void (^hold)(NSInteger);
  step = ^(NSInteger left) {
    // Same rule as the form's run block: copy `self` out before clearing `hold`,
    // the last reference to this running block.
    if (left == 0) { __typeof(self) me = self; hold = nil; [me load]; return; }
    [[HeyIOSApi shared] send:HD(reorder[@"request"]) vars:vars row:row completion:^(NSInteger status, id json, NSString *error) {
      if (error != nil) { HeyIOSAlert(self, @"The order was not saved", error); hold = nil; [self load]; return; }
      hold(left - 1);
    }];
  };
  hold = step;
  step(steps);
}

- (NSString *)addedKey:(NSIndexPath *)indexPath {
  NSDictionary *row = HA(self.sections[indexPath.section][@"rows"])[indexPath.row];
  return [NSString stringWithFormat:@"%ld|%@", (long)indexPath.section, HS(row[@"url"]).length ? HS(row[@"url"]) : HS(row[@"title"])];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"row" forIndexPath:indexPath];
  NSDictionary *row = HA(self.sections[indexPath.section][@"rows"])[indexPath.row];
  NSDictionary *spec = [self rowSpecFor:indexPath.section];
  NSDictionary *sectionSpec = HD(self.sections[indexPath.section][@"spec"]);
  NSString *sectionKind = HeyIOSSectionKind(sectionSpec);
  cell.accessoryView = nil;
  cell.accessoryType = UITableViewCellAccessoryNone;
  cell.selectionStyle = UITableViewCellSelectionStyleDefault;
  if ([sectionKind isEqualToString:@"fields"]) {
    UIListContentConfiguration *value = [UIListContentConfiguration valueCellConfiguration];
    value.text = HS(row[@"label"]);
    value.secondaryAttributedText = HeyIOSStyled(HS(row[@"value"]), [UIFont preferredFontForTextStyle:UIFontTextStyleBody], [UIColor secondaryLabelColor]);
    value.prefersSideBySideTextAndSecondaryText = NO;
    value.secondaryTextProperties.numberOfLines = 0;
    cell.contentConfiguration = value;
    BOOL opens = [HD(row[@"spec"])[@"open_url"] boolValue];
    cell.selectionStyle = opens ? UITableViewCellSelectionStyleDefault : UITableViewCellSelectionStyleNone;
    if (opens) cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"arrow.up.right"]];
    return cell;
  }
  if ([sectionKind isEqualToString:@"actions"] && [HS(row[@"kind"]) isEqualToString:@"rating"] && [row[@"inline"] boolValue]) {
    // THE RATING ON THE SCREEN ITSELF: five stars, the left half of a star is
    // the half, and Clear. Saved when the finger stops (a menu of ten rows was
    // cut off on a real phone and had no way to clear).
    UITableViewCell *rating = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    rating.selectionStyle = UITableViewCellSelectionStyleNone;
    id raw = HeyIOSAt(self.screenJSON, HS(row[@"current_halves"]));
    NSInteger halves = [raw respondsToSelector:@selector(integerValue)] ? [raw integerValue] : 0;
    if (self.ratingSending) halves = self.pendingHalves;
    UILabel *title = [[UILabel alloc] init];
    title.text = HS(row[@"title"]);
    title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    UILabel *number = [[UILabel alloc] init];
    number.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    number.textColor = [UIColor secondaryLabelColor];
    number.textAlignment = NSTextAlignmentRight;
    number.accessibilityIdentifier = @"rating-number";
    self.ratingNumber = number;
    self.inlineRating = row;
    [self paintRatingNumber:halves];
    HeyIOSStarControl *stars = [[HeyIOSStarControl alloc] init];
    stars.halves = halves;
    stars.accessibilityLabel = HS(row[@"title"]);
    [stars addTarget:self action:@selector(inlineRated:) forControlEvents:UIControlEventValueChanged];
    [stars.widthAnchor constraintEqualToConstant:200].active = YES;
    self.ratingControl = stars;
    UIButtonConfiguration *clearConfig = [UIButtonConfiguration plainButtonConfiguration];
    clearConfig.title = HS(row[@"clear_title"]).length ? HS(row[@"clear_title"]) : @"Clear";
    clearConfig.titleLineBreakMode = NSLineBreakByClipping;
    clearConfig.contentInsets = NSDirectionalEdgeInsetsMake(8, 8, 8, 0);
    UIButton *clear = [UIButton buttonWithConfiguration:clearConfig primaryAction:[UIAction actionWithHandler:^(UIAction *a) {
      self.ratingControl.halves = 0;
      [self inlineRated:self.ratingControl];
    }]];
    clear.accessibilityIdentifier = @"rating-clear";
    [clear setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [clear setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    UIStackView *top = [[UIStackView alloc] initWithArrangedSubviews:@[title, number]];
    top.distribution = UIStackViewDistributionFill;
    UIStackView *bottom = [[UIStackView alloc] initWithArrangedSubviews:@[stars, [[UIView alloc] init], clear]];
    bottom.alignment = UIStackViewAlignmentCenter;
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[top, bottom]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 8;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [rating.contentView addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
      [stack.leadingAnchor constraintEqualToAnchor:rating.contentView.layoutMarginsGuide.leadingAnchor],
      [stack.trailingAnchor constraintEqualToAnchor:rating.contentView.layoutMarginsGuide.trailingAnchor],
      [stack.topAnchor constraintEqualToAnchor:rating.contentView.topAnchor constant:12],
      [stack.bottomAnchor constraintEqualToAnchor:rating.contentView.bottomAnchor constant:-12]
    ]];
    return rating;
  }
  if ([sectionKind isEqualToString:@"actions"]) {
    UIListContentConfiguration *button = [UIListContentConfiguration subtitleCellConfiguration];
    button.text = HeyIOSText(row[@"title"], self.screenJSON);
    BOOL destructive = [HS(row[@"style"]) isEqualToString:@"destructive"];
    button.textProperties.color = destructive ? [UIColor systemRedColor] : self.view.tintColor;
    UIImage *image = HeyIOSImage(row);
    if (image != nil) {
      button.image = image;
      button.imageProperties.tintColor = destructive ? [UIColor systemRedColor] : self.view.tintColor;
    }
    NSString *secondary = [HS(row[@"kind"]) isEqualToString:@"rating"] ? HeyIOSLine(row[@"current"], self.screenJSON) : HeyIOSText(row[@"subtitle"], self.screenJSON);
    if (secondary.length == 0 && [HS(row[@"kind"]) isEqualToString:@"rating"]) secondary = HS(row[@"unrated"]);
    if (secondary.length > 0) button.secondaryAttributedText = HeyIOSStyled(secondary, [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline], [UIColor secondaryLabelColor]);
    button.secondaryTextProperties.numberOfLines = 0;
    cell.contentConfiguration = button;
    cell.accessibilityLabel = button.text;
    return cell;
  }
  UIListContentConfiguration *content = [UIListContentConfiguration subtitleCellConfiguration];
  BOOL literal = [sectionKind isEqualToString:@"rows"];
  content.text = literal ? HeyIOSText(row[@"title"], self.screenJSON) : HeyIOSLine(spec[@"title"], row);
  NSString *subtitle = literal ? HeyIOSText(row[@"subtitle"], self.screenJSON) : HeyIOSLine(spec[@"subtitle"], row);
  NSString *detail = HeyIOSLine(spec[@"detail"], row);
  if (detail.length > 0) subtitle = subtitle.length > 0 ? [NSString stringWithFormat:@"%@\n%@", subtitle, detail] : detail;
  content.secondaryAttributedText = HeyIOSStyled(subtitle, [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline], [UIColor secondaryLabelColor]);
  content.textProperties.numberOfLines = 2;
  content.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  content.secondaryTextProperties.numberOfLines = 3;
  content.secondaryTextProperties.color = [UIColor secondaryLabelColor];
  content.imageProperties.maximumSize = CGSizeMake(52, 52);
  content.imageProperties.reservedLayoutSize = CGSizeMake(52, 52);
  content.imageProperties.cornerRadius = 6;
  NSString *imageAddress = HeyIOSLine(spec[@"image"], row);
  UIImage *cached = imageAddress.length ? [HeyIOSImageCache() objectForKey:imageAddress] : nil;
  if (cached) {
    content.image = cached;
  } else {
    // No picture: a glyph for what the row IS (the description's symbols),
    // never a generic box, which beside a playable row read as a trash can.
    content.image = [UIImage systemImageNamed:HeyIOSSymbolFor(spec, row)] ?: [UIImage systemImageNamed:@"link"];
    content.imageProperties.preferredSymbolConfiguration = [UIImageSymbolConfiguration configurationWithTextStyle:UIFontTextStyleTitle2];
    content.imageProperties.tintColor = [UIColor secondaryLabelColor];
  }
  if (!cached && imageAddress.length > 0) {
    HeyIOSLoadImage(imageAddress, ^(UIImage *image) {
      UITableViewCell *visible = [tableView cellForRowAtIndexPath:indexPath];
      if (visible) [tableView reconfigureRowsAtIndexPaths:@[indexPath]];
    });
  }
  cell.contentConfiguration = content;
  NSDictionary *action = HD(sectionSpec[@"row_action"]);
  if (action.count > 0 && !HeyIOSKnownAction(action)) action = @{};
  NSArray *rowActions = [self rowActionsFor:indexPath];
  if (literal) {
    NSString *badge = HS(row[@"_badge"]);
    if (badge.length > 0) {
      UILabel *count = [[UILabel alloc] init];
      count.text = [NSString stringWithFormat:@"  %@  ", badge];
      count.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
      count.textColor = [UIColor whiteColor];
      count.backgroundColor = [UIColor systemRedColor];
      count.layer.cornerRadius = 10;
      count.clipsToBounds = YES;
      [count sizeToFit];
      CGRect f = count.frame; f.size.height = 20; count.frame = f;
      cell.accessoryView = count;
    } else {
      cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
  } else if (action.count == 0 && rowActions.count > 0 && ![[self type] isEqualToString:@"audio"]) {
    // THE ACTIONS ARE VISIBLE, not only behind a swipe nobody knows to try.
    UIButton *more = [UIButton buttonWithType:UIButtonTypeSystem];
    [more setImage:[UIImage systemImageNamed:@"ellipsis.circle"] forState:UIControlStateNormal];
    more.frame = CGRectMake(0, 0, 44, 44);
    more.menu = [self menuForRow:indexPath from:more];
    more.showsMenuAsPrimaryAction = YES;
    more.accessibilityLabel = [NSString stringWithFormat:@"Actions for %@", content.text ?: @""];
    cell.accessoryView = more;
  }
  if (action.count > 0) {
    BOOL done = [self.added containsObject:[self addedKey:indexPath]] || HeyIOSTruthy(row, HS(action[@"done_when"]));
    UIButtonConfiguration *config = done ? [UIButtonConfiguration plainButtonConfiguration] : [UIButtonConfiguration tintedButtonConfiguration];
    config.title = done ? HS(action[@"done_title"]) : HS(action[@"title"]);
    UIButton *button = [UIButton buttonWithConfiguration:config primaryAction:nil];
    button.enabled = !done;
    button.tag = indexPath.section * 10000 + indexPath.row;
    button.accessibilityLabel = [NSString stringWithFormat:@"%@ %@", config.title, content.text];
    [button addTarget:self action:@selector(rowAction:) forControlEvents:UIControlEventTouchUpInside];
    [button sizeToFit];
    cell.accessoryView = button;
  } else if ([[self type] isEqualToString:@"audio"] && [row[@"_waiting"] boolValue]) {
    UIListContentConfiguration *greyed = (UIListContentConfiguration *)cell.contentConfiguration;
    greyed.textProperties.color = [UIColor secondaryLabelColor];
    cell.contentConfiguration = greyed;
    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    [spinner startAnimating];
    cell.accessoryView = spinner;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessibilityHint = row[@"subtitle"];
  } else if ([[self type] isEqualToString:@"audio"]) {
    NSDictionary *current = [HeyIOSAudio shared].currentRow;
    BOOL playing = current != nil && [HS(current[@"audio_url"]) isEqualToString:HS(row[@"audio_url"])] && [HS(current[@"title"]) isEqualToString:HS(row[@"title"])];
    cell.accessoryView = playing ? [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"speaker.wave.2.fill"]] : nil;
  } else if (HD(sectionSpec[@"select"]).count > 0) {
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
  }
  return cell;
}

- (void)rowAction:(UIButton *)button {
  NSIndexPath *indexPath = [NSIndexPath indexPathForRow:button.tag % 10000 inSection:button.tag / 10000];
  NSDictionary *row = HA(self.sections[indexPath.section][@"rows"])[indexPath.row];
  NSDictionary *action = HD(HD(self.sections[indexPath.section][@"spec"])[@"row_action"]);
  if (!HeyIOSKnownAction(action)) return;
  button.enabled = NO;
  [[HeyIOSApi shared] send:HD(action[@"request"]) vars:self.vars row:row completion:^(NSInteger status, id json, NSString *error) {
    if (error != nil) {
      button.enabled = YES;
      HeyIOSAlert(self, HS(action[@"failed_title"]), error);
      return;
    }
    [self.added addObject:[self addedKey:indexPath]];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
  }];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  [tableView deselectRowAtIndexPath:indexPath animated:YES];
  NSDictionary *row = HA(self.sections[indexPath.section][@"rows"])[indexPath.row];
  if ([[self type] isEqualToString:@"audio"]) {
    if ([row[@"_waiting"] boolValue]) return;
    [[HeyIOSAudio shared] playRow:row];
    return;
  }
  NSDictionary *sectionSpec = HD(self.sections[indexPath.section][@"spec"]);
  NSString *kind = HeyIOSSectionKind(sectionSpec);
  UIView *source = [tableView cellForRowAtIndexPath:indexPath];
  if ([kind isEqualToString:@"actions"]) { HeyIOSRunAction(self, row, nil, source); return; }
  if ([kind isEqualToString:@"fields"]) {
    if ([HD(row[@"spec"])[@"open_url"] boolValue]) { NSURL *url = HeyIOSAddress(HS(row[@"value"])); if (url) [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil]; }
    return;
  }
  if ([kind isEqualToString:@"rows"]) {
    if (HD(row[@"action"]).count > 0) { HeyIOSRunAction(self, row[@"action"], nil, source); return; }
    if (HS(row[@"screen"]).length > 0) HeyIOSOpenScreenFrom(self, row, self.vars, nil);
    return;
  }
  NSDictionary *select = HD(sectionSpec[@"select"]);
  if (select.count == 0) {
    // A row with actions and nowhere to go offers its actions on a tap.
    if ([self rowActionsFor:indexPath].count > 0) {
      UIAlertController *sheet = [UIAlertController alertControllerWithTitle:HeyIOSLine(HD(sectionSpec[@"row"])[@"title"], row) message:nil preferredStyle:UIAlertControllerStyleActionSheet];
      for (NSDictionary *a in [self rowActionsFor:indexPath]) {
        BOOL destructive = [HS(a[@"style"]) isEqualToString:@"destructive"];
        [sheet addAction:[UIAlertAction actionWithTitle:HeyIOSText(a[@"title"], row) style:destructive ? UIAlertActionStyleDestructive : UIAlertActionStyleDefault handler:^(UIAlertAction *x) { HeyIOSRunAction(self, a, row, source); }]];
      }
      [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
      HeyIOSPresentSheet(self, sheet, source);
    }
    return;
  }
  if (!HeyIOSCondition(select[@"when"], row)) return;
  if (HD(select[@"action"]).count > 0) { HeyIOSRunAction(self, select[@"action"], row, source); return; }
  if (HS(select[@"video"]).length > 0) { HeyIOSPlayVideo(self, HeyIOSLine(select[@"video"], row)); return; }
  if (HS(select[@"open_url"]).length > 0) { NSURL *url = HeyIOSAddress(HeyIOSLine(select[@"open_url"], row)); if (url) [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil]; return; }
  HeyIOSOpenScreen(self, HS(select[@"screen"]), HeyIOSParams(select[@"params"], self.vars, row, self.screenJSON));
}

// Above the lists when all of them are empty: what plays here, how to get
// something here, and a button that goes there (audio.empty_title,
// audio.empty, audio.empty_action {title, link}).
- (void)audioExplainer:(BOOL)nothing message:(NSString *)message {
  NSDictionary *audio = HD([HeyIOSApi shared].manifest[@"audio"]);
  if (!nothing) { [self buildNowPlaying]; return; }
  // A FAILED LOAD IS SAID AT THE TOP. It used to go in the first section's
  // footer, and that section hides when empty, so a server that did not
  // answer looked like an empty queue (seen on a frame).
  if (message.length > 0) audio = @{@"empty_title": @"The lists did not load", @"empty": message};
  UIStackView *stack = [[UIStackView alloc] init];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.spacing = 10;
  stack.alignment = UIStackViewAlignmentLeading;
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  UILabel *title = [[UILabel alloc] init];
  title.text = HS(audio[@"empty_title"]);
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  title.numberOfLines = 0;
  UILabel *body = [[UILabel alloc] init];
  body.text = HS(audio[@"empty"]);
  body.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
  body.textColor = [UIColor secondaryLabelColor];
  body.numberOfLines = 0;
  if (title.text.length > 0) [stack addArrangedSubview:title];
  [stack addArrangedSubview:body];
  NSDictionary *go = HD(audio[@"empty_action"]);
  if (go.count > 0) {
    UIButtonConfiguration *config = [UIButtonConfiguration filledButtonConfiguration];
    config.title = HS(go[@"title"]);
    config.image = HeyIOSImage(go);
    config.imagePadding = 6;
    UIButton *button = [UIButton buttonWithConfiguration:config primaryAction:[UIAction actionWithHandler:^(UIAction *a) {
      NSURL *link = [NSURL URLWithString:HS(go[@"link"])];
      if (link) [[UIApplication sharedApplication] openURL:link options:@{} completionHandler:nil];
    }]];
    [stack addArrangedSubview:button];
  }
  UIView *container = [[UIView alloc] init];
  [container addSubview:stack];
  [NSLayoutConstraint activateConstraints:@[
    [stack.leadingAnchor constraintEqualToAnchor:container.leadingAnchor constant:20],
    [stack.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-20],
    [stack.topAnchor constraintEqualToAnchor:container.topAnchor constant:12],
    [stack.bottomAnchor constraintEqualToAnchor:container.bottomAnchor constant:-8]
  ]];
  CGFloat width = self.tableView.bounds.size.width > 0 ? self.tableView.bounds.size.width : UIScreen.mainScreen.bounds.size.width;
  CGSize size = [container systemLayoutSizeFittingSize:CGSizeMake(width, UILayoutFittingCompressedSize.height) withHorizontalFittingPriority:UILayoutPriorityRequired verticalFittingPriority:UILayoutPriorityFittingSizeLevel];
  container.frame = CGRectMake(0, 0, width, size.height);
  self.tableView.tableHeaderView = container;
}

- (void)buildNowPlaying {
  UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 64)];
  UILabel *label = [[UILabel alloc] init];
  label.translatesAutoresizingMaskIntoConstraints = NO;
  label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
  label.textColor = [UIColor secondaryLabelColor];
  label.numberOfLines = 2;
  UIButton *button = [UIButton buttonWithConfiguration:[UIButtonConfiguration filledButtonConfiguration] primaryAction:nil];
  button.translatesAutoresizingMaskIntoConstraints = NO;
  [button addTarget:[HeyIOSAudio shared] action:@selector(togglePlayPause) forControlEvents:UIControlEventTouchUpInside];
  [header addSubview:label];
  [header addSubview:button];
  [NSLayoutConstraint activateConstraints:@[
    [label.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:20],
    [label.centerYAnchor constraintEqualToAnchor:header.centerYAnchor],
    [label.trailingAnchor constraintLessThanOrEqualToAnchor:button.leadingAnchor constant:-12],
    [button.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-20],
    [button.centerYAnchor constraintEqualToAnchor:header.centerYAnchor]
  ]];
  self.nowPlayingLabel = label;
  self.nowPlayingButton = button;
  self.tableView.tableHeaderView = header;
  [self audioChanged];
}

- (void)audioChanged {
  HeyIOSAudio *audio = [HeyIOSAudio shared];
  NSDictionary *strings = HD(HD([HeyIOSApi shared].manifest[@"audio"])[@"strings"]);
  NSString *title = HS(audio.currentRow[@"title"]);
  switch (audio.state) {
    case HeyIOSAudioStateIdle: self.nowPlayingLabel.text = HS(strings[@"idle"]); break;
    case HeyIOSAudioStateLoading: self.nowPlayingLabel.text = [NSString stringWithFormat:@"%@ %@", HS(strings[@"loading"]), title]; break;
    case HeyIOSAudioStatePlaying: self.nowPlayingLabel.text = [NSString stringWithFormat:@"%@ %@", HS(strings[@"playing"]), title]; break;
    case HeyIOSAudioStatePaused: self.nowPlayingLabel.text = [NSString stringWithFormat:@"%@ %@", HS(strings[@"paused"]), title]; break;
    case HeyIOSAudioStateFailed: self.nowPlayingLabel.text = [NSString stringWithFormat:@"%@ %@", HS(strings[@"failed"]), audio.lastError ?: @""]; break;
  }
  UIButtonConfiguration *config = self.nowPlayingButton.configuration;
  config.image = [UIImage systemImageNamed:audio.state == HeyIOSAudioStatePlaying || audio.state == HeyIOSAudioStateLoading ? @"pause.fill" : @"play.fill"];
  self.nowPlayingButton.configuration = config;
  self.nowPlayingButton.hidden = audio.currentRow == nil;
  self.nowPlayingButton.accessibilityLabel = audio.state == HeyIOSAudioStatePlaying ? HS(strings[@"pause"]) : HS(strings[@"play"]);
  [self.tableView reloadData];
}

@end

@interface HeyIOSFormController : UITableViewController <UITextFieldDelegate, UITextViewDelegate, HeyIOSVarsReceiver, HeyIOSActionHost, HeyIOSTypedValues>
@property(nonatomic, strong) NSDictionary *screen;
@property(nonatomic, strong) NSMutableDictionary *values;
@property(nonatomic, copy, nullable) NSString *message;
@property(nonatomic, assign) BOOL busy;
@property(nonatomic, strong, nullable) id screenJSON;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSArray *> *options;
@property(nonatomic, strong) NSMutableSet<NSString *> *touched;
@property(nonatomic, assign) NSInteger lookups;
@end

@implementation HeyIOSFormController

- (NSMutableDictionary *)vars { return self.values; }
- (void)reloadContent { [self loadSource]; }

// A link or a field of a kind this renderer does not know is not drawn.
- (NSArray *)links {
  NSMutableArray *out = [NSMutableArray array];
  for (NSDictionary *link in HA(self.screen[@"links"])) if (HeyIOSKnownRow(link) && HeyIOSCondition(link[@"when"], self.screenJSON)) [out addObject:link];
  return out;
}

- (BOOL)hasTypedValues { return self.touched.count > 0; }

// PREFILLED FROM THE SERVER when the form edits something that exists:
// source is the route, values maps each field id to a path in its answer.
- (void)loadSource {
  NSDictionary *source = HD(self.screen[@"source"]);
  if (source.count == 0) return;
  [[HeyIOSApi shared] send:source vars:self.values row:nil completion:^(NSInteger status, id json, NSString *error) {
    if (error != nil) { self.message = error; [self.tableView reloadData]; return; }
    self.screenJSON = json;
    [HD(self.screen[@"values"]) enumerateKeysAndObjectsUsingBlock:^(id key, id path, BOOL *stop) {
      id v = HeyIOSAt(json, HS(path));
      if (v != nil) self.values[key] = [v isKindOfClass:[NSNumber class]] ? v : HS(v);
    }];
    [self.tableView reloadData];
  }];
}

- (void)loadChoices {
  for (NSDictionary *field in [self fields]) {
    NSDictionary *choices = HD(field[@"choices"]);
    NSString *fieldID = HS(field[@"id"]);
    if (choices.count == 0) { if (HA(field[@"options"]).count) self.options[fieldID] = HA(field[@"options"]); continue; }
    [[HeyIOSApi shared] send:choices vars:self.values row:nil completion:^(NSInteger status, id json, NSString *error) {
      NSMutableArray *list = [NSMutableArray arrayWithArray:HA(field[@"options"])];
      for (NSDictionary *choice in HA(HeyIOSAt(json, HS(choices[@"list"])))) {
        if (!HeyIOSCondition(choices[@"where"], choice)) continue;
        NSString *value = HS(HeyIOSAt(choice, HS(choices[@"value"])));
        NSString *label = HeyIOSLine(choices[@"label"], choice);
        [list addObject:@{@"title": label.length ? label : value, @"value": value}];
      }
      self.options[fieldID] = list;
      [self.tableView reloadData];
    }];
  }
}

// LOOK AT A LINK WHILE THE REST IS TYPED: lookup {field, request, poll, fills}
// asks the route once the field holds a complete address, polls while the
// answer is pending, and fills only fields nobody has typed in.
- (void)lookupFor:(NSString *)fieldID {
  NSDictionary *lookup = HD(self.screen[@"lookup"]);
  if (![HS(lookup[@"field"]) isEqualToString:fieldID]) return;
  NSString *url = HS(self.values[fieldID]);
  if (![url hasPrefix:@"http://"] && ![url hasPrefix:@"https://"]) return;
  if ([url rangeOfString:@"."].location == NSNotFound) return;
  NSInteger mine = ++self.lookups;
  __block void (^ask)(NSInteger);
  __block void (^keep)(NSInteger);
  ask = ^(NSInteger attempt) {
    [[HeyIOSApi shared] send:HD(lookup[@"request"]) vars:self.values row:nil completion:^(NSInteger status, id json, NSString *error) {
      if (mine != self.lookups || ![HS(self.values[fieldID]) isEqualToString:url] || error != nil) { keep = nil; return; }
      [HD(lookup[@"fills"]) enumerateKeysAndObjectsUsingBlock:^(id key, id path, BOOL *stop) {
        NSString *found = HS(HeyIOSAt(json, HS(path)));
        if (found.length > 0 && ![self.touched containsObject:key] && HS(self.values[key]).length == 0) self.values[key] = found;
      }];
      NSString *note = HeyIOSLine(lookup[@"found"], json);
      self.message = note.length > 0 ? note : self.message;
      [self.tableView reloadData];
      NSDictionary *poll = HD(lookup[@"poll"]);
      BOOL pending = [HS(HeyIOSAt(json, HS(poll[@"key"]))) isEqualToString:HS(poll[@"pending"])];
      if (pending && attempt + 1 < [poll[@"max"] integerValue]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)([poll[@"every_ms"] doubleValue] / 1000.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (keep) keep(attempt + 1); });
      } else {
        keep = nil;
      }
    }];
  };
  keep = ask;
  ask(0);
}

- (instancetype)initWithScreen:(NSDictionary *)screen vars:(NSDictionary *)vars {
  self = [super initWithStyle:UITableViewStyleInsetGrouped];
  if (self) { _screen = screen; _values = [vars mutableCopy] ?: [NSMutableDictionary dictionary]; }
  return self;
}

- (NSArray *)fields {
  NSMutableArray *out = [NSMutableArray array];
  for (NSDictionary *field in HA(self.screen[@"fields"])) if (HeyIOSKnownField(field)) [out addObject:field];
  return out;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.title = HS(self.screen[@"title"]);
  self.tableView.accessibilityIdentifier = HS(self.screen[@"id"]);
  self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
  self.options = [NSMutableDictionary dictionary];
  self.touched = [NSMutableSet set];
  [self loadSource];
  [self loadChoices];
  if (HS(HD(self.screen[@"lookup"])[@"field"]).length > 0) [self lookupFor:HS(HD(self.screen[@"lookup"])[@"field"])];
}

- (void)applyVars:(NSDictionary *)vars {
  [self.values addEntriesFromDictionary:vars];
  self.message = nil;
  if (self.isViewLoaded) [self.tableView reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { (void)tableView; return [self links].count > 0 ? 3 : 2; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { (void)tableView; return section == 0 ? (NSInteger)[self fields].count : (section == 1 ? 1 : (NSInteger)[self links].count); }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section { (void)tableView; return section == 0 ? HS(self.screen[@"header"]) : nil; }

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
  (void)tableView;
  if (section == 0) return HS(self.screen[@"footer"]).length ? HS(self.screen[@"footer"]) : nil;
  if (section == 2) return HS(self.screen[@"links_footer"]).length ? HS(self.screen[@"links_footer"]) : nil;
  return self.message.length ? self.message : nil;
}

- (UITableViewCell *)fieldStack:(NSDictionary *)field control:(UIView *)control {
  UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
  cell.selectionStyle = UITableViewCellSelectionStyleNone;
  UILabel *label = [[UILabel alloc] init];
  label.text = HS(field[@"label"]);
  label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
  label.textColor = [UIColor secondaryLabelColor];
  UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[label, control]];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.spacing = 4;
  stack.alignment = UIStackViewAlignmentFill;
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  [cell.contentView addSubview:stack];
  [NSLayoutConstraint activateConstraints:@[
    [stack.leadingAnchor constraintEqualToAnchor:cell.contentView.layoutMarginsGuide.leadingAnchor],
    [stack.trailingAnchor constraintEqualToAnchor:cell.contentView.layoutMarginsGuide.trailingAnchor],
    [stack.topAnchor constraintEqualToAnchor:cell.contentView.topAnchor constant:10],
    [stack.bottomAnchor constraintEqualToAnchor:cell.contentView.bottomAnchor constant:-10]
  ]];
  return cell;
}

- (void)textViewDidChange:(UITextView *)textView {
  NSDictionary *spec = HD([self fields][textView.tag]);
  self.values[HS(spec[@"id"])] = textView.text ?: @"";
  [self.touched addObject:HS(spec[@"id"])];
  [UIView performWithoutAnimation:^{ [self.tableView beginUpdates]; [self.tableView endUpdates]; }];
}

- (void)starsChanged:(HeyIOSStarControl *)control {
  NSDictionary *spec = HD([self fields][control.tag]);
  self.values[HS(spec[@"id"])] = @(control.halves);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section == 1) {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    UIListContentConfiguration *content = [UIListContentConfiguration cellConfiguration];
    NSDictionary *primary = HD(self.screen[@"primary"]);
    content.text = self.busy ? HS(primary[@"busy_title"]) : HS(primary[@"title"]);
    content.textProperties.alignment = UIListContentTextAlignmentCenter;
    content.textProperties.color = self.busy ? [UIColor secondaryLabelColor] : self.view.tintColor;
    content.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    cell.contentConfiguration = content;
    cell.accessibilityTraits = UIAccessibilityTraitButton;
    return cell;
  }
  if (indexPath.section == 2) {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    UIListContentConfiguration *content = [UIListContentConfiguration cellConfiguration];
    NSDictionary *link = HD([self links][indexPath.row]);
    content.text = HS(link[@"title"]);
    content.textProperties.color = self.view.tintColor;
    content.image = HeyIOSImage(link);
    cell.contentConfiguration = content;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
  }
  NSDictionary *field = HD([self fields][indexPath.row]);
  NSString *kind = HS(field[@"kind"]);
  NSString *fieldID = HS(field[@"id"]);
  if ([kind isEqualToString:@"multiline"]) {
    UITextView *view = [[UITextView alloc] init];
    view.text = HS(self.values[fieldID]);
    view.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    view.scrollEnabled = NO;
    view.backgroundColor = [UIColor clearColor];
    view.textContainerInset = UIEdgeInsetsZero;
    view.textContainer.lineFragmentPadding = 0;
    view.delegate = self;
    view.tag = indexPath.row;
    view.accessibilityLabel = HS(field[@"label"]);
    [view.heightAnchor constraintGreaterThanOrEqualToConstant:66].active = YES;
    return [self fieldStack:field control:view];
  }
  if ([kind isEqualToString:@"rating"]) {
    HeyIOSStarControl *stars = [[HeyIOSStarControl alloc] init];
    stars.halves = [self.values[fieldID] integerValue];
    stars.tag = indexPath.row;
    stars.accessibilityLabel = HS(field[@"label"]);
    [stars addTarget:self action:@selector(starsChanged:) forControlEvents:UIControlEventValueChanged];
    [stars.widthAnchor constraintLessThanOrEqualToConstant:260].active = YES;
    UIStackView *holder = [[UIStackView alloc] initWithArrangedSubviews:@[stars, [[UIView alloc] init]]];
    holder.axis = UILayoutConstraintAxisHorizontal;
    return [self fieldStack:field control:holder];
  }
  if ([kind isEqualToString:@"choice"]) {
    NSArray *options = self.options[fieldID] ?: HA(field[@"options"]);
    NSString *current = HS(self.values[fieldID]);
    NSString *shown = HS(field[@"none_title"]);
    NSMutableArray *elements = [NSMutableArray array];
    for (NSDictionary *option in options) {
      NSString *value = HS(option[@"value"]);
      if ([value isEqualToString:current]) shown = HS(option[@"title"]);
      UIAction *element = [UIAction actionWithTitle:HS(option[@"title"]) image:nil identifier:nil handler:^(UIAction *a) {
        self.values[fieldID] = value;
        [self.touched addObject:fieldID];
        [self.tableView reloadData];
      }];
      element.state = [value isEqualToString:current] ? UIMenuElementStateOn : UIMenuElementStateOff;
      [elements addObject:element];
    }
    UIButtonConfiguration *config = [UIButtonConfiguration grayButtonConfiguration];
    config.title = shown.length ? shown : current;
    config.image = [UIImage systemImageNamed:@"chevron.up.chevron.down"];
    config.imagePlacement = NSDirectionalRectEdgeTrailing;
    config.imagePadding = 6;
    UIButton *button = [UIButton buttonWithConfiguration:config primaryAction:nil];
    button.menu = [UIMenu menuWithChildren:elements];
    button.showsMenuAsPrimaryAction = YES;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeading;
    button.accessibilityLabel = HS(field[@"label"]);
    return [self fieldStack:field control:button];
  }
  UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
  cell.selectionStyle = UITableViewCellSelectionStyleNone;
  UILabel *label = [[UILabel alloc] init];
  label.text = HS(field[@"label"]);
  label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
  label.textColor = [UIColor secondaryLabelColor];
  UITextField *text = [[UITextField alloc] init];
  text.text = HS(self.values[HS(field[@"id"])]);
  text.placeholder = HS(field[@"placeholder"]);
  text.secureTextEntry = [kind isEqualToString:@"secure"];
  text.autocapitalizationType = [kind isEqualToString:@"prose"] ? UITextAutocapitalizationTypeSentences : ([kind isEqualToString:@"code"] ? UITextAutocapitalizationTypeAllCharacters : UITextAutocapitalizationTypeNone);
  if ([kind isEqualToString:@"new_secure"]) { text.secureTextEntry = YES; text.textContentType = UITextContentTypeNewPassword; }
  text.autocorrectionType = [kind isEqualToString:@"prose"] ? UITextAutocorrectionTypeDefault : UITextAutocorrectionTypeNo;
  text.keyboardType = [kind isEqualToString:@"url"] ? UIKeyboardTypeURL : ([kind isEqualToString:@"number"] ? UIKeyboardTypeNumbersAndPunctuation : UIKeyboardTypeDefault);
  text.textContentType = [kind isEqualToString:@"secure"] ? UITextContentTypePassword : ([HS(field[@"id"]) isEqualToString:@"username"] ? UITextContentTypeUsername : nil);
  text.clearButtonMode = UITextFieldViewModeWhileEditing;
  text.accessibilityLabel = label.text;
  text.tag = indexPath.row;
  text.delegate = self;
  text.returnKeyType = indexPath.row + 1 < (NSInteger)[self fields].count ? UIReturnKeyNext : UIReturnKeyGo;
  [text addTarget:self action:@selector(edited:) forControlEvents:UIControlEventEditingChanged];
  UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[label, text]];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.spacing = 4;
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  [cell.contentView addSubview:stack];
  [NSLayoutConstraint activateConstraints:@[
    [stack.leadingAnchor constraintEqualToAnchor:cell.contentView.layoutMarginsGuide.leadingAnchor],
    [stack.trailingAnchor constraintEqualToAnchor:cell.contentView.layoutMarginsGuide.trailingAnchor],
    [stack.topAnchor constraintEqualToAnchor:cell.contentView.topAnchor constant:10],
    [stack.bottomAnchor constraintEqualToAnchor:cell.contentView.bottomAnchor constant:-10],
    [text.heightAnchor constraintGreaterThanOrEqualToConstant:30]
  ]];
  return cell;
}

- (void)edited:(UITextField *)field {
  NSDictionary *spec = HD([self fields][field.tag]);
  self.values[HS(spec[@"id"])] = field.text ?: @"";
  [self.touched addObject:HS(spec[@"id"])];
  NSString *fieldID = HS(spec[@"id"]);
  if ([HS(HD(self.screen[@"lookup"])[@"field"]) isEqualToString:fieldID]) {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(lookupFor:) object:fieldID];
    [self performSelector:@selector(lookupFor:) withObject:fieldID afterDelay:0.7];
  }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
  if (textField.returnKeyType == UIReturnKeyGo) { [textField resignFirstResponder]; [self submit]; }
  else {
    UITableViewCell *next = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:textField.tag + 1 inSection:0]];
    for (UIView *view in next.contentView.subviews.firstObject.subviews) if ([view isKindOfClass:[UITextField class]]) [view becomeFirstResponder];
  }
  return YES;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  [tableView deselectRowAtIndexPath:indexPath animated:YES];
  if (indexPath.section == 1) [self submit];
  if (indexPath.section == 2) HeyIOSOpenScreenFrom(self, HD([self links][indexPath.row]), self.values, nil);
}

- (void)submit {
  if (self.busy) return;
  [self.view endEditing:YES];
  for (NSDictionary *field in [self fields]) {
    if ([field[@"required"] boolValue] && HS(self.values[HS(field[@"id"])]).length == 0) {
      // {label} is the field's label (level 1 wrote %@). Never a format
      // string: a served text is not trusted with printf.
      NSString *said = HS(self.screen[@"missing"]).length ? HS(self.screen[@"missing"]) : @"{label} is needed.";
      said = [said stringByReplacingOccurrencesOfString:@"{label}" withString:HS(field[@"label"])];
      self.message = [said stringByReplacingOccurrencesOfString:@"%@" withString:HS(field[@"label"])];
      [self.tableView reloadData];
      return;
    }
  }
  NSDictionary *primary = HD(self.screen[@"primary"]);
  self.busy = YES;
  self.message = nil;
  [self.tableView reloadData];
  HeyIOSApi *api = [HeyIOSApi shared];
  for (NSDictionary *field in [self fields]) {
    NSString *same = HS(field[@"same_as"]);
    if (same.length > 0 && ![HS(self.values[HS(field[@"id"])]) isEqualToString:HS(self.values[same])]) {
      self.busy = NO;
      self.message = HS(field[@"differs"]).length ? HS(field[@"differs"]) : @"The two entries differ.";
      [self.tableView reloadData];
      return;
    }
  }
  // SEVERAL REQUESTS, ONE SAVE: requests run in order and stop at the first
  // refusal; a request with skip_empty is left out when that field is empty.
  NSMutableArray *queue = [NSMutableArray array];
  for (NSDictionary *route in (HA(primary[@"requests"]).count ? HA(primary[@"requests"]) : @[HD(primary[@"request"])])) {
    if (HS(route[@"skip_empty"]).length > 0 && HS(self.values[HS(route[@"skip_empty"])]).length == 0) continue;
    [queue addObject:route];
  }
  __block void (^run)(NSUInteger, id);
  __block void (^hold)(NSUInteger, id);
  void (^finish)(NSInteger, id, NSString *) = ^(NSInteger status, id json, NSString *error) {
    self.busy = NO;
    if (error != nil) { self.message = error; [self.tableView reloadData]; return; }
    NSDictionary *success = HD(primary[@"on_success"]);
    NSString *tokenPath = HS(success[@"store_token"]);
    if (tokenPath.length > 0) {
      NSString *token = HS(HeyIOSAt(json, tokenPath));
      if (token.length == 0) { self.message = HS(success[@"no_token"]); [self.tableView reloadData]; return; }
      // A Keychain that refuses the write (a build without an application
      // identifier: -34018) must say so, not bounce back to this screen.
      if (![api setToken:token]) {
        self.message = @"Signed in, but this phone would not store the session. The app needs rebuilding.";
        [self.tableView reloadData];
        return;
      }
      [[NSNotificationCenter defaultCenter] postNotificationName:@"HeyIOSSignedInNotification" object:nil];
      return;
    }
    NSString *message = HeyIOSLine(success[@"message"], json);
    NSString *existing = HS(success[@"existing_path"]);
    if (existing.length > 0 && [HeyIOSAt(json, existing) boolValue]) message = HS(success[@"existing_message"]);
    self.message = message;
    NSString *sharePath = HS(success[@"share"]);
    if (sharePath.length > 0 && HS(HeyIOSAt(json, sharePath)).length > 0) {
      NSURL *url = [NSURL URLWithString:HS(HeyIOSAt(json, sharePath))];
      UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url ?: HS(HeyIOSAt(json, sharePath))] applicationActivities:nil];
      share.popoverPresentationController.sourceView = self.view;
      [self presentViewController:share animated:YES completion:nil];
    }
    if ([success[@"clear"] boolValue]) [self.values removeAllObjects];
    [self.tableView reloadData];
    if (HS(success[@"go"]).length > 0) HeyIOSOpenScreen(self, HS(success[@"go"]), HeyIOSParams(success[@"params"], self.values, json, nil));
    if (success[@"then"] != nil) HeyIOSAfter(self, @{@"then": success[@"then"], @"store_token": success[@"keep_token"] ?: @""}, self.values, json);
  };
  run = ^(NSUInteger index, id last) {
    // `hold` is the last strong reference to THIS block: clearing it frees the
    // block while it runs, so everything used afterwards is copied out first.
    // Reading `finish` from the freed block crashed sign-in on a phone
    // (EXC_BAD_ACCESS at 0x10); the simulator had not reused the memory yet.
    if (index >= queue.count) {
      void (^done)(NSInteger, id, NSString *) = finish;
      id result = last;
      hold = nil;
      done(200, result, nil);
      return;
    }
    [api send:queue[index] vars:self.values row:nil completion:^(NSInteger status, id json, NSString *error) {
      if (error != nil) { hold = nil; finish(status, json, error); return; }
      hold(index + 1, json);
    }];
  };
  hold = run;
  run(0, nil);
}

@end

// A SCREEN TYPE THIS RENDERER DOES NOT KNOW IS NOT DRAWN: nil, and nothing
// opens it (it used to be drawn as an empty list).
static UIViewController *HeyIOSControllerFor(NSDictionary *screen, NSDictionary *vars) {
  if (!HeyIOSKnownScreen(screen)) return nil;
  NSString *type = HS(screen[@"type"]);
  if ([type isEqualToString:@"form"]) return [[HeyIOSFormController alloc] initWithScreen:screen vars:vars];
  return [[HeyIOSListController alloc] initWithScreen:screen vars:vars];
}

#pragma mark - the host

@interface HeyIOSHost : NSObject <UITabBarControllerDelegate>
+ (instancetype)shared;
- (void)refreshBadges;
- (void)refreshDescription;
@property(nonatomic, weak, nullable) UIWindow *window;
@property(nonatomic, strong, nullable) NSURL *pendingLink;
- (void)showRoot;
- (void)openLink:(NSURL *)url;
@end

// The screen ids of the tabs actually drawn, in order (a tab whose screen
// type this renderer does not know is left out).
static NSArray<NSString *> *HeyIOSDrawnTabs(UITabBarController *tabs) {
  NSMutableArray *ids = [NSMutableArray array];
  for (UIViewController *controller in tabs.viewControllers) [ids addObject:controller.tabBarItem.accessibilityIdentifier ?: @""];
  return ids;
}

@implementation HeyIOSHost

+ (instancetype)shared {
  static HeyIOSHost *shared;
  static dispatch_once_t once;
  dispatch_once(&once, ^{
    shared = [[HeyIOSHost alloc] init];
    [[NSNotificationCenter defaultCenter] addObserver:shared selector:@selector(signedOut) name:HeyIOSSignedOutNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:shared selector:@selector(signedIn) name:@"HeyIOSSignedInNotification" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:shared selector:@selector(refreshBadges) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:shared selector:@selector(cameToForeground) name:UIApplicationWillEnterForegroundNotification object:nil];
  });
  return shared;
}

// THE SERVER'S SCREENS, ON LAUNCH AND ON EVERY RETURN TO THE FOREGROUND. What
// is drawn meanwhile is the stored or baked copy, so nothing waits on the
// network and a failure changes nothing.
- (void)refreshDescription {
  [[HeyIOSApi shared] refreshDescription:^(BOOL arrived) {
    if (arrived) [self applyDescriptionIfAtRest];
  }];
}

- (void)cameToForeground {
  [self applyDescriptionIfAtRest];
  [self refreshDescription];
}

// NOTHING IN PROGRESS: every tab at its first screen, no sheet, nothing typed.
// A new copy is never drawn over a half-filled form or a pushed screen it
// might not have; it waits for the next launch or return.
- (BOOL)atRest {
  UIViewController *root = self.window.rootViewController;
  if (root == nil) return YES;
  if (root.presentedViewController != nil) return NO;
  NSArray *stacks = [root isKindOfClass:[UITabBarController class]] ? ((UITabBarController *)root).viewControllers : @[root];
  for (UIViewController *stack in stacks) {
    if (![stack isKindOfClass:[UINavigationController class]]) continue;
    UINavigationController *nav = (UINavigationController *)stack;
    if (nav.viewControllers.count > 1 || nav.presentedViewController != nil) return NO;
    id top = nav.viewControllers.firstObject;
    if ([top conformsToProtocol:@protocol(HeyIOSTypedValues)] && [(id<HeyIOSTypedValues>)top hasTypedValues]) return NO;
  }
  return YES;
}

- (void)applyDescriptionIfAtRest {
  HeyIOSApi *api = [HeyIOSApi shared];
  if (api.pending == nil || api.failure.length > 0) return;
  if (![self atRest]) { NSLog(@"HeyIOSDescription: something is in progress; the new copy waits"); return; }
  [api applyPending];
  HeyIOSConfigureAudio();
  [self showRoot];
  HeyIOSAudioFeedChanged();
}

- (void)signedOut {
  [[HeyIOSApi shared] clearToken];
  [[HeyIOSAudio shared] stop];
  [self showRoot];
  HeyIOSAudioFeedChanged();
}

- (void)signedIn {
  [self showRoot];
  HeyIOSAudioFeedChanged();
  if (self.pendingLink) { NSURL *link = self.pendingLink; self.pendingLink = nil; [self openLink:link]; }
}

- (void)showRoot {
  HeyIOSApi *api = [HeyIOSApi shared];
  if (api.failure.length > 0) {
    UIViewController *broken = [[UIViewController alloc] init];
    broken.view.backgroundColor = [UIColor systemBackgroundColor];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectInset(UIScreen.mainScreen.bounds, 24, 24)];
    label.text = api.failure;
    label.numberOfLines = 0;
    label.textAlignment = NSTextAlignmentCenter;
    [broken.view addSubview:label];
    self.window.rootViewController = broken;
    return;
  }
  NSDictionary *session = HD(api.manifest[@"session"]);
  if ([api token].length == 0) {
    UIViewController *form = HeyIOSControllerFor([api screenNamed:HS(session[@"sign_in_screen"])], @{});
    if (form == nil) form = [[UIViewController alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:form];
    nav.navigationBar.prefersLargeTitles = YES;
    self.window.rootViewController = nav;
    return;
  }
  UITabBarController *tabs = [[UITabBarController alloc] init];
  NSMutableArray *controllers = [NSMutableArray array];
  for (NSString *screenID in HA(api.manifest[@"tabs"])) {
    NSDictionary *screen = [api screenNamed:screenID];
    UIViewController *root = HeyIOSControllerFor(screen, @{});
    if (root == nil) continue;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:root];
    nav.navigationBar.prefersLargeTitles = YES;
    NSDictionary *tab = HD(screen[@"tab"]);
    nav.tabBarItem = [[UITabBarItem alloc] initWithTitle:HS(tab[@"title"]) image:HeyIOSImage(tab) tag:(NSInteger)controllers.count];
    nav.tabBarItem.accessibilityIdentifier = screenID;
    [controllers addObject:nav];
  }
  tabs.viewControllers = controllers;
  tabs.delegate = self;
  self.window.rootViewController = tabs;
  [self refreshBadges];
  [api send:HD(session[@"check"]) vars:@{} row:nil completion:^(NSInteger status, id json, NSString *error) {
    if (status == 401) [[NSNotificationCenter defaultCenter] postNotificationName:HeyIOSSignedOutNotification object:nil];
  }];
}

// A WEB ADDRESS, OPENED AS THE SCREEN THAT DOES THE SAME THING. web_links is
// an ordered list of {path: '/share/set/{slug}', screen, from_tab, query:
// {name: var}, signed_out}; the first whose literal segments match wins and
// each {name} becomes a variable. nil when nothing matches.
static NSDictionary *HeyIOSMatchWebPath(NSString *path, NSString *query) {
  NSArray *have = [[path stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/"]] componentsSeparatedByString:@"/"];
  if ([path stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/"]].length == 0) have = @[];
  NSURLComponents *qc = [[NSURLComponents alloc] init];
  qc.query = query;
  NSMutableDictionary *queryVars = [NSMutableDictionary dictionary];
  for (NSURLQueryItem *item in qc.queryItems) if (item.value) queryVars[item.name] = item.value;
  for (NSDictionary *link in HA([HeyIOSApi shared].manifest[@"web_links"])) {
    NSString *pattern = [HS(link[@"path"]) stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/"]];
    NSArray *want = pattern.length ? [pattern componentsSeparatedByString:@"/"] : @[];
    if (want.count != have.count) continue;
    NSMutableDictionary *vars = [NSMutableDictionary dictionary];
    BOOL ok = YES;
    for (NSUInteger i = 0; i < want.count; i++) {
      NSString *w = want[i];
      if ([w hasPrefix:@"{"] && [w hasSuffix:@"}"]) vars[[w substringWithRange:NSMakeRange(1, w.length - 2)]] = [have[i] stringByRemovingPercentEncoding] ?: have[i];
      else if (![w isEqualToString:have[i]]) { ok = NO; break; }
    }
    if (!ok) continue;
    NSDictionary *needs = HD(link[@"query"]);
    BOOL missing = NO;
    for (NSString *name in needs) { if (HS(queryVars[name]).length == 0) missing = YES; else vars[HS(needs[name])] = queryVars[name]; }
    if (missing) continue;
    return @{@"link": link, @"vars": vars};
  }
  return nil;
}

- (void)openWebURL:(NSURL *)url {
  NSDictionary *match = HeyIOSMatchWebPath(url.path ?: @"/", url.query ?: @"");
  if (match == nil) {
    // Not a screen this app has: the browser, which the web answers.
    if ([url.scheme hasPrefix:@"http"]) [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    return;
  }
  [self openScreenFor:match[@"link"] vars:match[@"vars"] url:url];
}

- (void)openScreenFor:(NSDictionary *)link vars:(NSDictionary *)vars url:(NSURL *)url {
  HeyIOSApi *api = [HeyIOSApi shared];
  NSString *screenID = HS(link[@"screen"]);
  if ([api token].length == 0) {
    // SIGNED OUT, AS ON THE WEB: an invitation or a setup link opens where it
    // is (it is how an account gets made); anything else waits for sign-in
    // and then lands on its screen.
    if ([link[@"signed_out"] boolValue]) {
      UINavigationController *nav = [self.window.rootViewController isKindOfClass:[UINavigationController class]] ? (UINavigationController *)self.window.rootViewController : nil;
      [nav popToRootViewControllerAnimated:NO];
      UIViewController *next = HeyIOSControllerFor([api screenNamed:screenID], vars);
      if (nav && next) [nav pushViewController:next animated:NO];
      return;
    }
    self.pendingLink = url;
    return;
  }
  UITabBarController *tabs = [self.window.rootViewController isKindOfClass:[UITabBarController class]] ? (UITabBarController *)self.window.rootViewController : nil;
  if (tabs == nil) return;
  NSArray *tabIDs = HeyIOSDrawnTabs(tabs);
  NSUInteger tabIndex = [tabIDs indexOfObject:screenID];
  if (tabIndex != NSNotFound) {
    tabs.selectedIndex = tabIndex;
    UINavigationController *nav = tabs.viewControllers[tabIndex];
    [nav popToRootViewControllerAnimated:NO];
    id<HeyIOSVarsReceiver> root = (id<HeyIOSVarsReceiver>)nav.viewControllers.firstObject;
    if ([root respondsToSelector:@selector(applyVars:)]) [root applyVars:vars];
    return;
  }
  UIViewController *next = HeyIOSControllerFor([api screenNamed:screenID], vars);
  if (next == nil) return;
  NSUInteger from = [tabIDs indexOfObject:HS(link[@"from_tab"])];
  if (from != NSNotFound && from < tabs.viewControllers.count) tabs.selectedIndex = from;
  UINavigationController *nav = (UINavigationController *)tabs.selectedViewController;
  [nav popToRootViewControllerAnimated:NO];
  [nav pushViewController:next animated:NO];
}

// Counts on the tab bar: tab.badge {source, count (an array's length) | path}.
- (void)refreshBadges {
  UITabBarController *tabs = [self.window.rootViewController isKindOfClass:[UITabBarController class]] ? (UITabBarController *)self.window.rootViewController : nil;
  HeyIOSApi *api = [HeyIOSApi shared];
  if (tabs == nil || [api token].length == 0) return;
  NSArray *tabIDs = HeyIOSDrawnTabs(tabs);
  for (NSUInteger i = 0; i < tabIDs.count && i < tabs.viewControllers.count; i++) {
    NSDictionary *badge = HD(HD([api screenNamed:tabIDs[i]][@"tab"])[@"badge"]);
    if (badge.count == 0) continue;
    UIViewController *controller = tabs.viewControllers[i];
    [api send:HD(badge[@"source"]) vars:@{} row:nil completion:^(NSInteger status, id json, NSString *error) {
      if (error != nil) return;
      NSInteger n = HS(badge[@"count"]).length ? (NSInteger)HA(HeyIOSAt(json, HS(badge[@"count"]))).count : [HeyIOSAt(json, HS(badge[@"path"])) integerValue];
      controller.tabBarItem.badgeValue = n > 0 ? [NSString stringWithFormat:@"%ld", (long)n] : nil;
    }];
  }
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController { [self refreshBadges]; }

- (void)openLink:(NSURL *)url {
  HeyIOSApi *api = [HeyIOSApi shared];
  if ([url.scheme isEqualToString:@"https"] || [url.scheme isEqualToString:@"http"]) { [self openWebURL:url]; return; }
  if (![url.scheme isEqualToString:HS(api.manifest[@"url_scheme"])]) return;
  NSDictionary *link = HD(HD(api.manifest[@"deep_links"])[url.host ?: @""]);
  if (link.count == 0) {
    // scheme://a/b/c is looked up as the web path /a/b/c.
    NSString *path = [NSString stringWithFormat:@"/%@%@", url.host ?: @"", url.path ?: @""];
    NSDictionary *match = HeyIOSMatchWebPath(path, url.query ?: @"");
    if (match) [self openScreenFor:match[@"link"] vars:match[@"vars"] url:url];
    return;
  }
  if ([api token].length == 0) { self.pendingLink = url; return; }
  NSMutableDictionary *vars = [NSMutableDictionary dictionary];
  NSURLComponents *components = [NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];
  for (NSURLQueryItem *item in components.queryItems) if (item.value) vars[item.name] = item.value;
  NSArray *parts = [url.path componentsSeparatedByString:@"/"];
  if (HS(link[@"param"]).length > 0 && parts.count > 1 && HS(parts[1]).length > 0) vars[HS(link[@"param"])] = parts[1];
  NSString *screenID = HS(link[@"screen"]);
  UITabBarController *tabs = [self.window.rootViewController isKindOfClass:[UITabBarController class]] ? (UITabBarController *)self.window.rootViewController : nil;
  if (tabs == nil) return;
  NSArray *tabIDs = HeyIOSDrawnTabs(tabs);
  NSUInteger tabIndex = [tabIDs indexOfObject:screenID];
  if (tabIndex != NSNotFound) {
    tabs.selectedIndex = tabIndex;
    UINavigationController *nav = tabs.viewControllers[tabIndex];
    [nav popToRootViewControllerAnimated:NO];
    id<HeyIOSVarsReceiver> root = (id<HeyIOSVarsReceiver>)nav.viewControllers.firstObject;
    if ([root respondsToSelector:@selector(applyVars:)]) [root applyVars:vars];
    return;
  }
  UIViewController *next = HeyIOSControllerFor([api screenNamed:screenID], vars);
  if (next == nil) return;
  NSUInteger from = [tabIDs indexOfObject:HS(link[@"from_tab"])];
  if (from != NSNotFound && from < tabs.viewControllers.count) tabs.selectedIndex = from;
  UINavigationController *nav = (UINavigationController *)tabs.selectedViewController;
  [nav popToRootViewControllerAnimated:NO];
  [nav pushViewController:next animated:NO];
}

@end

#pragma mark - the audio feed, for another scene

NSString *HeyIOSApiHostAudioTitle(void) {
  return HS(HD([HeyIOSApi shared].manifest[@"audio"])[@"title"]);
}

void HeyIOSApiHostLoadAudioFeed(HeyIOSApiHostAudioFeedCompletion completion) {
  HeyIOSLoadAudio(^(NSArray<NSDictionary *> *sections, NSString *message) {
    BOOL any = NO;
    for (NSDictionary *section in sections) if (HA(section[@"rows"]).count > 0) any = YES;
    completion(sections, message ?: (any ? nil : HS(HD([HeyIOSApi shared].manifest[@"audio"])[@"empty"])));
  });
}

#pragma mark - application and scenes

@implementation HeyIOSAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
  (void)application; (void)launchOptions;
  HeyIOSApi *api = [HeyIOSApi shared];
#if TARGET_OS_SIMULATOR
  // Simulator-only launch arguments, so a screenshot run never types a
  // passphrase: -HeyIOSDevToken <token>, -HeyIOSDevSignOut YES.
  NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
  if ([defaults boolForKey:@"HeyIOSDevSignOut"]) [api clearToken];
  NSString *devToken = [defaults stringForKey:@"HeyIOSDevToken"];
  if (devToken.length > 0 && ![api setToken:devToken]) NSLog(@"HeyIOSDevToken: the keychain refused the session");
#endif
  (void)api;
  HeyIOSConfigureAudio();
  return YES;
}

- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)session options:(UISceneConnectionOptions *)options {
  (void)application; (void)options;
  // ANY OTHER SCENE ROLE (a car screen, say) is configured from the Info.plist
  // declaration written by the package that added it (the build tool's
  // --extension). The host names no such role itself.
  if (![session.role isEqualToString:UIWindowSceneSessionRoleApplication]) {
    NSDictionary *declared = HD(HA(HD(HD([NSBundle mainBundle].infoDictionary[@"UIApplicationSceneManifest"])[@"UISceneConfigurations"])[session.role]).firstObject);
    Class delegateClass = NSClassFromString(HS(declared[@"UISceneDelegateClassName"]));
    if (delegateClass != Nil) {
      UISceneConfiguration *other = [[UISceneConfiguration alloc] initWithName:HS(declared[@"UISceneConfigurationName"]) sessionRole:session.role];
      other.sceneClass = NSClassFromString(HS(declared[@"UISceneClassName"]));
      other.delegateClass = delegateClass;
      return other;
    }
  }
  UISceneConfiguration *phone = [[UISceneConfiguration alloc] initWithName:@"Phone" sessionRole:session.role];
  phone.delegateClass = [HeyIOSPhoneSceneDelegate class];
  return phone;
}

@end

@implementation HeyIOSPhoneSceneDelegate

- (void)scene:(UIScene *)scene willConnectToSession:(UISceneSession *)session options:(UISceneConnectionOptions *)connectionOptions {
  (void)session;
  if (![scene isKindOfClass:[UIWindowScene class]]) return;
  self.window = [[UIWindow alloc] initWithWindowScene:(UIWindowScene *)scene];
  HeyIOSHost *host = [HeyIOSHost shared];
  host.window = self.window;
  [host showRoot];
  [self.window makeKeyAndVisible];
  [host refreshDescription];
  for (UIOpenURLContext *context in connectionOptions.URLContexts) [host openLink:context.URL];
  // A universal link that launched the app: a web address iOS handed over
  // because the server's apple-app-site-association claims its path.
  for (NSUserActivity *activity in connectionOptions.userActivities) {
    if ([activity.activityType isEqualToString:NSUserActivityTypeBrowsingWeb] && activity.webpageURL) [host openLink:activity.webpageURL];
  }
#if TARGET_OS_SIMULATOR
  NSString *open = [[NSUserDefaults standardUserDefaults] stringForKey:@"HeyIOSDevOpen"];
  if (open.length > 0) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [host openLink:[NSURL URLWithString:open]]; });
  }
#endif
}

- (void)scene:(UIScene *)scene openURLContexts:(NSSet<UIOpenURLContext *> *)URLContexts {
  (void)scene;
  for (UIOpenURLContext *context in URLContexts) [[HeyIOSHost shared] openLink:context.URL];
}

- (void)scene:(UIScene *)scene continueUserActivity:(NSUserActivity *)userActivity {
  (void)scene;
  if ([userActivity.activityType isEqualToString:NSUserActivityTypeBrowsingWeb] && userActivity.webpageURL) [[HeyIOSHost shared] openLink:userActivity.webpageURL];
}

@end
