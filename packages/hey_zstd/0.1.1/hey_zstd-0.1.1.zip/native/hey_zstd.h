#pragma once
#include "hey_native_abi.h"
HeyNativeHandle zstd_writer_open(HeyNativeUtf8View path, int32_t level);
int32_t zstd_writer_write(HeyNativeHandle writer, HeyNativeBytesView data);
int32_t zstd_writer_close(HeyNativeHandle writer);
HeyNativeHandle zstd_reader_open(HeyNativeUtf8View path, uint64_t max_output_bytes);
HeyNativeOwnedBytes zstd_reader_read(HeyNativeHandle reader, uint32_t max_bytes);
uint32_t zstd_reader_error(HeyNativeHandle reader);
int32_t zstd_reader_close(HeyNativeHandle reader);
