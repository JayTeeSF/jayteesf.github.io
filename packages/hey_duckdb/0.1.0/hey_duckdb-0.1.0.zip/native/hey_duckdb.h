#ifndef HEY_DUCKDB_H
#define HEY_DUCKDB_H

#include "hey_native_abi.h"

/* Database / connection lifecycle */
HeyNativeHandle hey_duckdb_open(HeyNativeUtf8View path);
HeyNativeHandle hey_duckdb_connect(HeyNativeHandle database);
void hey_duckdb_disconnect(HeyNativeHandle connection);
void hey_duckdb_close(HeyNativeHandle database);

/* Direct query -> owned result wrapper */
HeyNativeHandle hey_duckdb_query(HeyNativeHandle connection, HeyNativeUtf8View sql);

/* Prepared statements */
HeyNativeHandle hey_duckdb_prepare(HeyNativeHandle connection, HeyNativeUtf8View sql);
HeyNativeUtf8View hey_duckdb_prepare_error(HeyNativeHandle statement);
int64_t hey_duckdb_nparams(HeyNativeHandle statement);
int32_t hey_duckdb_bind_varchar(HeyNativeHandle statement, int32_t index, HeyNativeUtf8View value);
int32_t hey_duckdb_bind_null(HeyNativeHandle statement, int32_t index);
HeyNativeHandle hey_duckdb_execute_prepared(HeyNativeHandle statement);
void hey_duckdb_destroy_prepare(HeyNativeHandle statement);

/* Result inspection (over the owned wrapper) */
HeyNativeBool hey_duckdb_result_success(HeyNativeHandle result);
HeyNativeUtf8View hey_duckdb_result_error(HeyNativeHandle result);
int64_t hey_duckdb_row_count(HeyNativeHandle result);
int64_t hey_duckdb_column_count(HeyNativeHandle result);
HeyNativeUtf8View hey_duckdb_column_name(HeyNativeHandle result, int32_t column);
int32_t hey_duckdb_column_type(HeyNativeHandle result, int32_t column);
HeyNativeBool hey_duckdb_value_is_null(HeyNativeHandle result, int32_t column, int64_t row);
HeyNativeUtf8View hey_duckdb_value_varchar(HeyNativeHandle result, int32_t column, int64_t row);
void hey_duckdb_destroy_result(HeyNativeHandle result);

#endif
