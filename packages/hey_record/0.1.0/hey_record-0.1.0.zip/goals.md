# Goals

## High level

Provide a clear, composable Hey relational-data API with Sequel-like datasets and optional Active Record-like model conventions.

## Tactical

- Keep adapters replaceable through callable connection descriptors.
- Make SQL generation deterministic and reject unsafe identifiers/unscoped writes.
- Add prepared statements, pools, migrations, associations, validations, callbacks, and schema reflection in measured slices.
