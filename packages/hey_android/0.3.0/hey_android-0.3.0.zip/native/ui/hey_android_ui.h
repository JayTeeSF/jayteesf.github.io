/* hey_android_ui.h: the Android View shims a Hey program calls through stdlib:Native.
 *
 * Two sides:
 *   - The Hey side (declared in hey.native.json, called from the Hey program's thread):
 *     begin, text_row, commit, next_event, errors. These never touch JNI.
 *   - The glue side (called from native/glue on the UI thread): attach, detach and the
 *     input queue. All JNI runs here, on the UI thread.
 *
 * native/ui/hey_android_ui.c explains the threads.
 */
#ifndef HEY_ANDROID_UI_H
#define HEY_ANDROID_UI_H

#include <stdint.h>

#include "hey_native_abi.h"

/* ---- called by Hey (through the generated hey_android_ui_ffi.c) ---- */
int64_t hey_android_ui_begin(void);
int64_t hey_android_ui_text_row(HeyNativeUtf8View label, HeyNativeUtf8View id);
int64_t hey_android_ui_commit(void);
HeyNativeUtf8View hey_android_ui_next_event(void);
HeyNativeUtf8View hey_android_ui_errors(void);

/* ---- called by the glue, on the UI thread ---- */
struct ANativeActivity;
struct AInputQueue;
void hey_android_ui_attach(struct ANativeActivity *activity);
void hey_android_ui_detach(struct ANativeActivity *activity);
void hey_android_ui_input_queue_created(struct ANativeActivity *activity, struct AInputQueue *queue);
void hey_android_ui_input_queue_destroyed(struct ANativeActivity *activity, struct AInputQueue *queue);

#endif
