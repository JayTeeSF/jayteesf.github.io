# hey_android

`hey_android` turns a Hey program that uses the Hey runtime into a signed APK
that installs and runs on Android 16 (API 36), arm64, with no Java or Kotlin
anywhere: no source, no `classes.dex`, no Gradle.

The APK declares the framework's own `android.app.NativeActivity` with
`hasCode="false"`. That activity loads one shared library, which holds the Hey
program (compiled through Hey's LLVM lane), the Hey runtime from the pinned Hey
checkout (compiled unmodified for Android), and a small C entry point.

## What works in 0.2.0

- **Build:** `tools/hey-android-app.sh` builds a Hey program into a signed APK.
  It uses heyc, NDK r28 clang, aapt2, zipalign and apksigner, with no Gradle.
- **Run:** it installs and launches the APK on the API 36 emulator.
  - What the program `says` appears in logcat, byte for byte as on the Mac.
  - A Hey runtime error appears in logcat and ends the activity cleanly.
- **Runtime features on Android:**
  - maps, arrays, `Text.join` and JSON;
  - SHA-256 of text and of files;
  - secure random bytes and constant-time compare.
- **Reported as unavailable:** TLS, AES-256-GCM, scrypt and Argon2id each
  return a named error, never a fake result.
- **Checks between steps:**
  - The IR is target-neutral.
  - The library is aarch64 with 16 KB LOAD alignment, and every undefined
    symbol comes from libc, libm, libdl, liblog or libandroid.
  - No OpenSSL, Apple crypto or Homebrew trace is in the build.
  - The APK has no dex, stores the library uncompressed with 16 KB alignment,
    and has a verifying signature.
- **Evidence:** every run writes `receipt.json`.
- **Pins:** `bin/android-doctor` checks and prints them: platform 36,
  build-tools 36.0.0, NDK 28.2.13676358, the API 36 Play system image and
  JDK 17. It also prints the Hey checkout's identity. Anything missing comes
  with the exact `sdkmanager` line.
- **Gate:** `bin/check` runs all of this, including the emulator, with a
  negative control for every check. See `docs/TESTING.md`.

## The commands

```sh
cd ~/dev/hey_android
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"   # the Hey checkout whose runtime ships in the app

bin/android-doctor                                    # pins, SDK pieces, JDK, Hey identity
tools/hey-android-emulator.sh create-avd              # once: AVD hey_android_API_36 ("hey_android API 36")

tools/hey-android-app.sh \
  --source examples/hello_runtime.hey \
  --out /tmp/hey-hello \
  --package-id com.jayteesf.hey.hello \
  --label 'Hey Hello' \
  --emulator hey_android_API_36 --launch
```

**What `--emulator` does:**
- boots the AVD headless if it is not running;
- installs and launches the app;
- waits for the program to end;
- writes these into `--out`: `app.apk`, `receipt.json`, `stdout.txt`,
  `stderr.txt`, `logcat-hey.txt` and `logcat.txt`;
- shuts the emulator down again.

**Other options:**
- `--device SERIAL` uses a device that is already running instead.
- Leave out both `--emulator` and `--device` to only build.
- `--keystore FILE --key-alias ALIAS` signs for release. The password comes
  from `HEY_ANDROID_KEYSTORE_PASSWORD`.

**Where the output goes** (see `native/glue/hey_android_glue.c`):
- stdout goes to logcat tag `hey.out`;
- stderr goes to `hey.err`;
- the entry point's own lines go to `hey.app`.

```sh
adb logcat -v tag -s 'hey.app:*' 'hey.out:*' 'hey.err:*'
```

When several agents build at once, set `HEY_HEYC_LOCK` to a lock command, for
example `HEY_HEYC_LOCK="with-lock.sh build --"`. The tool puts it in front of
heyc, whose build cache is not safe for parallel builds.

## What is not done

- **No UI.** Hey can print, but it cannot call Android's Java APIs yet (views,
  Keystore, HTTP, media). That is phase 2 in `docs/ROADMAP.md`.
- **Programs are run once.** The Hey runtime has no library entry point that
  can be called many times and that returns errors instead of exiting. So
  after the program ends and its activity closes, the process exits, and the
  next launch starts a fresh runtime.
- **One target:** arm64-v8a, minimum API 35, target API 36. There is no x86_64
  or armv7 library and no AAB yet.
- **16 KB pages are checked, not run.** The alignment is verified statically;
  the emulator kernel uses 4 KB pages.
- **LLVM-lane limits.** Some Hey code does not compile through the LLVM lane
  yet: `Array#join`, closures such as `names.map(fn(n) ...)`, `a ? b : c`,
  `Bytes.from_text` and `Tls.available`. Those programs cannot be built for
  Android until heyc lowers them. The list, with reproductions, is in
  `docs/ROADMAP.md`.
- **Stdlib calls that need the toolchain are refused.**
  - On the LLVM lane, a stdlib call without a native route in the runtime is
    handed to a Hey toolchain at run time, and a phone has none.
    `Files.write_text` is one such call; use `Files.write_atomic` instead.
  - The IR check refuses these calls by name before anything is built.
- **Networking.** The Hey runtime has no TLS on Android. HTTPS will come
  through the platform in phase 2.

The earlier Gradle lane (API 34, AGP 8.5.2, NDK 26.1, a generated Java
Activity) was removed in 0.2.0.

## Package import

```hey
import 'pkg:hey_android@0.2.0/main'
```

`HeyAndroidToolchain.versions()` returns the pins, and
`HeyAndroid.native_receipt?(receipt)` recognises a clean run receipt.

## Standard package controls

`hey_packager` validates, releases and publishes the package.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
bin/check          # includes the emulator run; about three minutes
bin/release
bin/publish
```
