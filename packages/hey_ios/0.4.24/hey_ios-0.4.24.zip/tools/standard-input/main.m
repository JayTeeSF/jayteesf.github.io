#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wnullability-completeness"
#import "HeyIOSApiHost.m"
#pragma clang diagnostic pop
const char *HeyIOSBakedOrigin(void) { return "https://input.example.test"; }
static int failures;
static UIWindow *window;
static void check(BOOL ok, NSString *why) { if (!ok) { fprintf(stderr,"standard-input FAIL: %s\n",why.UTF8String); failures++; } }
static NSArray *descendants(UIView *v) { NSMutableArray *a=[NSMutableArray array]; for(UIView *c in v.subviews) { [a addObject:c]; [a addObjectsFromArray:descendants(c)]; } return a; }
static void after(double t, void(^b)(void)) { dispatch_after(dispatch_time(DISPATCH_TIME_NOW,t*NSEC_PER_SEC),dispatch_get_main_queue(),b); }
static void focusState(NSString *stage, HeyIOSListController *search) {
  UITextField *field=search.searchBar.searchTextField;
  fprintf(stdout,"standard-input readiness stage=%s applicationState=%ld keyWindow=%d mounted=%d arriving=%d canBecome=%d firstResponder=%d\n",stage.UTF8String,(long)UIApplication.sharedApplication.applicationState,window.isKeyWindow,field.window != nil,search.arriving,field.canBecomeFirstResponder,field.isFirstResponder); fflush(stdout);
}
static void whenSearchSettled(HeyIOSListController *search, CFAbsoluteTime deadline, void (^then)(void)) {
  // The renderer refuses editing during arrival. Observe lifecycle readiness
  // without focusing; the original focus assertion still runs exactly once.
  BOOL ready=UIApplication.sharedApplication.applicationState==UIApplicationStateActive && window.isKeyWindow && search.searchBar.searchTextField.window==window && !search.arriving;
  if (ready || CFAbsoluteTimeGetCurrent()>=deadline) {
    focusState(ready?@"settled":@"readiness-timeout",search);
    check(ready,@"search did not settle within five seconds");
    then();
    return;
  }
  focusState(@"waiting-for-transition",search);
  after(0.1, ^{ whenSearchSettled(search,deadline,then); });
}
@interface InputDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation InputDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
  self.window=[[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds]; window=self.window;
  HeyIOSListController *search=[[HeyIOSListController alloc] initWithScreen:@{@"id":@"search",@"type":@"search",@"title":@"Synthetic Search",@"placeholder":@"Title or link",@"speech_input":@YES,@"sections":@[]} vars:@{}];
  UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:search];
  window.rootViewController=nav; [window makeKeyAndVisible];
  after(0, ^{
    focusState(@"initial",search);
    whenSearchSettled(search,CFAbsoluteTimeGetCurrent()+5, ^{
    NSString *mode=[[NSUserDefaults standardUserDefaults] stringForKey:@"Mode"];
    if ([mode hasPrefix:@"old"]) {
      if ([mode isEqual:@"old-listening"]) { SEL sel=NSSelectorFromString(@"showVoiceActivity:"); if ([search respondsToSelector:sel]) ((void(*)(id,SEL,BOOL))[search methodForSelector:sel])(search,sel,YES); }
      return;
    }
    // Exercise the wrapper's failure propagation with a real native failure.
    check(![mode isEqual:@"negative-control"],@"intentional runner negative control");
    check(search.tableView.tableHeaderView == search.searchBar,@"search retains app-owned recording UI");
    check(search.searchBar.searchTextField.inputView == nil,@"search replaces system keyboard");
    focusState(@"before-search-focus",search);
    check([search.searchBar.searchTextField becomeFirstResponder],@"search cannot focus normal keyboard");
    focusState(@"after-search-focus",search);
    search.searchBar.text=@"keep OLD tail";
    UITextField *s=search.searchBar.searchTextField;
    s.selectedTextRange=[s textRangeFromPosition:[s positionFromPosition:s.beginningOfDocument offset:5] toPosition:[s positionFromPosition:s.beginningOfDocument offset:8]];
    [s insertText:@"new"];
    check([s.text isEqual:@"keep new tail"],@"search input does not replace selection");
    check(HS(search.vars[@"query"]).length==0,@"inserting text submitted search");
    if ([mode isEqual:@"search"]) return;
    NSMutableArray *fields=[NSMutableArray array];
    for(NSString *key in @[@"note",@"message",@"reason"]) [fields addObject:@{@"id":key,@"label":key,@"kind":@"multiline",@"speech_input":@YES}];
    [fields addObject:@{@"id":@"title",@"label":@"Title",@"kind":@"text",@"speech_input":@YES}];
    HeyIOSFormController *form=[[HeyIOSFormController alloc] initWithScreen:@{@"id":@"form",@"type":@"form",@"title":@"Synthetic drafts",@"fields":fields,@"primary":@{@"title":@"Save"}} vars:@{}];
    [nav pushViewController:form animated:NO];
    after(0.5, ^{
      for(NSInteger i=0;i<fields.count;i++) {
        NSIndexPath *path=[NSIndexPath indexPathForRow:i inSection:0];
        UITableViewCell *cell=[form.tableView cellForRowAtIndexPath:path] ?: [form tableView:form.tableView cellForRowAtIndexPath:path];
        UIView *editor=nil;
        for(UIView *v in descendants(cell)) {
          check(![v.accessibilityIdentifier hasPrefix:@"form_microphone_"],@"form retains app-owned recording button");
          if([v isKindOfClass:UITextView.class] || [v isKindOfClass:UITextField.class]) editor=v;
        }
        check(editor!=nil,@"prose field missing native text editor");
        if(!editor) continue;
        if(i==0) check([editor becomeFirstResponder],@"mounted multiline editor cannot focus keyboard");
        check([(id)editor inputView]==nil,@"prose replaces system keyboard");
        NSString *key=fields[i][@"id"];
        if([editor isKindOfClass:UITextView.class]) {
          UITextView *t=(id)editor; t.text=@"keep OLD\ntail"; t.selectedRange=NSMakeRange(5,3); [t insertText:@"new"]; [form textViewDidChange:t];
          check([form.values[key] isEqual:@"keep new\ntail"],@"multiline insertion did not preserve draft and selection");
          check(NSEqualRanges(t.selectedRange,NSMakeRange(8,0)),@"cursor lost after insertion");
        } else { UITextField *t=(id)editor; t.text=@"draft"; [t sendActionsForControlEvents:UIControlEventEditingChanged]; check([form.values[key] isEqual:@"draft"],@"single line edit lost"); }
      }
      check(!form.busy && form.savedShareValues==nil,@"input automatically saved or shared");
      HeyIOSPrompt(form,@{@"prompt":@{@"title":@"Synthetic prompt",@"fields":@[@{@"id":@"reason",@"label":@"Reason",@"speech_input":@YES}]}},@{},nil, ^(NSDictionary *v) { check(NO,@"prompt insertion performed action"); });
      after(0.5, ^{
        UIAlertController *actual=(id)form.presentedViewController;
        check([actual isKindOfClass:UIAlertController.class] && actual.textFields.count==1,@"native prompt field missing");
        UITextField *t=actual.textFields.firstObject;
        check(t.inputView==nil && t.isFirstResponder,@"prompt lacks normal focused keyboard");
        [t insertText:@"draft reason"];
        check([t.text isEqual:@"draft reason"],@"prompt insertion lost");
        if([mode isEqual:@"prompt"]) return;
        fprintf(stdout,"hey_ios_standard_input=%s failures=%d\n",failures?"false":"true",failures); fflush(stdout); exit(failures?1:0);
      });
    });
    });
  }); return YES;
}
@end
int main(int argc,char **argv) { @autoreleasepool { return UIApplicationMain(argc,argv,nil,NSStringFromClass(InputDelegate.class)); } }
