# Shared by bin/build-exe and bin/wine-smoke: the tools/winbox container, which
# holds mingw-w64 (to cross-compile), Wine and a virtual display (to run what
# was built without a Windows machine). Sourced, not executed.
#
# ALWAYS linux/amd64. The executable is x86-64 and Wine runs only programs of
# its own architecture, so on an Apple-silicon host the container runs under
# the engine's amd64 emulation (Rosetta or QEMU). Compiling is fast either
# way; Wine's first start is slow under emulation.
WINBOX_IMAGE="${HEY_WINDOWS_IMAGE:-hey-winbox:0.2}"
WINBOX_PLATFORM=linux/amd64
winbox_docker() {
  if [ -n "${HEY_WINDOWS_DOCKER_CONTEXT:-}" ]; then
    docker --context "$HEY_WINDOWS_DOCKER_CONTEXT" "$@"
  else
    docker "$@"
  fi
}
winbox_ensure_image() {
  if [ "$(winbox_docker image inspect "$WINBOX_IMAGE" --format '{{.Architecture}}' 2>/dev/null)" != amd64 ]; then
    echo "winbox: building $WINBOX_IMAGE ($WINBOX_PLATFORM) from tools/winbox/Dockerfile (once)" >&2
    winbox_docker build --platform "$WINBOX_PLATFORM" -t "$WINBOX_IMAGE" "$ROOT/tools/winbox" >/dev/null
  fi
}
# Runs a command in the container with the package mounted at /work. The
# package must live under the home folder: Docker Desktop, Colima and Rancher
# share only that by default.
winbox_run() {
  winbox_docker run --rm --platform "$WINBOX_PLATFORM" -v "$ROOT":/work -w /work "$WINBOX_IMAGE" "$@"
}
# Runs a command with the package at /work and an application folder at /app
# (both must live under the home folder). Signing credentials, when present in
# this environment, are passed through by name only; they are never written to
# a file or a command line.
winbox_run_app() {
  app_dir="$1"; shift
  set -- --rm --platform "$WINBOX_PLATFORM" -v "$ROOT":/work -v "$app_dir":/app -w /app \
    -e AZURE_TENANT_ID -e AZURE_CLIENT_ID -e AZURE_CLIENT_SECRET "$WINBOX_IMAGE" "$@"
  winbox_docker run "$@"
}
