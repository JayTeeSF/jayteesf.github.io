# Done

- 0.1.0: extracted tvOS UIKit/focus/remote generation from Hey core.

## 0.4.20

- Depends on `hey_ios` ^0.3.0 instead of exactly 0.3.0, so an app can take hey_ios 0.3.1, where signing in no longer crashes on a phone. The television renderer is unchanged.

## 0.4.19

- Depends on `hey_ios` 0.3.0 (served descriptions for phone apps). The television renderer is unchanged: an app holds one `hey_ios` version, so this package moves with it.

## 0.4.18

The first registry release after 0.4.14. 0.4.15 (the device lane links after the TLS-server runtime symbols), 0.4.16 (the fake-OpenSSL stub bank deleted) and 0.4.17 (the Hey checkout compiled into the app is named, verified and printed) were committed but never published; they ship here. Every feature below is additive: a scene that does not use a field renders as it did in 0.4.14. Built and measured against My Queue on a Living Room Apple TV; the fields are in `docs/SCENE_CONTRACT.md`.

- **`grid` widget.** Artwork tiles in rows with a provider badge, a title that takes only the lines that fit, a meta line that yields to the stars, one selected tile, and a server-owned cursor. The focused tile lifts to 1.16 and every unfocused tile dims to 55%, so the control is visible across a room. `clip_height` shows the top band of a full-size row (a peek row), rather than squashing tiles.
- **`chips` widget, drawn as a section bar.** Large words with a solid bar under the current one; focused and selected are drawn differently, so leaving the row keeps your place.
- **`compact` document flag.** Tighter spacing and margins for a dense shelf.
- **`open_url` document field.** Hands a URL to the app that registered its scheme, once per distinct value, so a re-polled scene does not bounce the viewer back into the other app. Coming back to the app polls at once.
- **`audio` document field.** A stream under the scene with no layer (a radio while a page is read). The same url keeps playing, `{stop: true}` stops it, and an absent field leaves it alone. Volume follows the soundtrack mute.
- **`X-Hey-TV-Apps` request header and `--query-schemes`.** The renderer probes the schemes Info.plist declares with `canOpenURL` once per launch and sends the ones that answer yes on every poll. The app supplies the list (`--query-schemes`, `HEY_IOS_TV_QUERY_SCHEMES`); the renderer names no service.
- **System search keyboard (`keyboard_submit`, `keyboard_placeholder`).** The tvOS keyboard with dictation replaces a chip keyboard. Results follow the text (debounced 0.35 s; the newest query wins) in focusable tiles inside the search controller, and Menu closes the keyboard without leaving the app.
- **`rail` slot.** A left column for tools (search, settings, account) beside the content; a scene with no rail lays out exactly as before.
- **Text layout.** `max_width` (readable prose), `min_width` (rows that share a left edge), `line_spacing` and `paragraph_spacing` in points.
- **`spinner` and `listrow` widgets.** Three dots that animate while a server is slow, and a settings row with a focus band and an on/off symbol.
- **Press latency.** A remote press keeps the views on screen, sends its fetch at once, and lets a newer press cancel the one in flight. `press -> scene on screen in N ms` is logged.
- **Walkthrough video is inset** (0.22 margin with a visible edge), so a recording of the app does not look like the app.
- **One identity per installation.** A distribution pack bakes `__HEY_TV_DEVICE__`; the renderer mints a random 96-bit id on first launch and keeps it in `NSUserDefaults` (`hey_ios_tv.device_id`). `forget_device` drops it: signing out as the half only the television can do. A per-room pack bakes its id and is unaffected.
- **App Store distribution.** The Xcode and SDK provenance keys App Store Connect validates are stamped. `HEY_IOS_TV_SHORT_VERSION` and `HEY_IOS_TV_BUILD` set the bundle version, because a fixed build number allows one submission ever.
- **`hey_ios` 0.2.0.** The tool accepts hey_ios 0.2.x or 0.1.3. Without `HEY_IOS_ROOT` it uses the hey_ios installed beside this package before `~/dev/hey_ios`.
