#ifndef HEY_DURABLE_LOG_H
#define HEY_DURABLE_LOG_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct hdl_log hdl_log;
typedef struct hdl_broker hdl_broker;
typedef struct hdl_cursor hdl_cursor;

typedef enum {
  HDL_OK = 0,
  HDL_INVALID = 1,
  HDL_IO = 2,
  HDL_CORRUPTION = 3,
  HDL_NOMEM = 4,
  HDL_LIMIT = 5,
  HDL_CLOSED = 6,
  HDL_DONE = 7,
  /* A durability barrier failed on this handle, so it can no longer tell the
     truth about what is durable and will not acknowledge anything further.
     Reading still works. Reopening re-runs recovery, which re-derives the
     committed state from the bytes on disk; that is the only way to clear it. */
  HDL_POISONED = 8,
  /* Another writer already owns this journal. A caller's response to this is
     nothing like its response to an I/O error -- wait, or fail over, rather than
     page someone about a disk -- so it is a status of its own rather than an
     I/O failure with a different message. */
  HDL_LOCKED = 9,
  /* The submission could not be ADMITTED within the deadline the caller gave,
     and was not accepted. The record is not in the queue and will not become
     durable; retrying it is safe and losing it is the caller's decision to
     make, which is the whole point of being told rather than blocked. */
  HDL_BUSY = 10,
  /* The position asked for is no longer in this journal: the segments holding
     it were retired against a verified snapshot. The records are not lost -- the
     caller has to read them from the snapshot -- so this is emphatically not
     corruption, and must not be treated as one. */
  HDL_RETIRED = 11,
  /* The journal on disk was written in a format this build cannot safely read.
     Emphatically NOT corruption: the bytes are intact and a build that
     understands them can read them. It is separate because the operator
     responses differ completely -- restore from a snapshot versus run the
     migration, or run the older build.

     v2 journals reach this. They carry no per-entry term, and a term cannot be
     invented for a record that was written before terms existed: fabricating
     one would manufacture exactly the consensus history that the election
     restriction then trusts. */
  HDL_UNSUPPORTED_FORMAT = 12
} hdl_status;

typedef struct {
  uint64_t stream_id;
  const void *payload;
  uint32_t payload_length;
  /* THE LEADER EPOCH this entry ORIGINATED in: an opaque, writer-supplied
     counter naming which leadership era created it, never the era of whoever
     is storing it now.

     The log does not know what a leader is. All it enforces is that this value
     never decreases, that it is recovered from the bytes, and that it is inside
     the frame CRC. A consensus layer maps its own notion onto it -- Raft's
     `term`, Paxos's ballot, VR's view number. Kafka calls exactly this a leader
     epoch and uses it for exactly this purpose (KIP-101: replication truncation
     decided by leader epoch rather than high watermark), which is where the
     name comes from. `epoch` alone would collide with the segment header's Unix
     timestamp, and `generation` is already the segment generation.

     A receiver that re-stamped replicated entries with its own current term
     would destroy the ordering this field exists to provide: the election
     restriction ranks candidates by (last entry's term, last index), and that
     ranking is only meaningful if the term travels with the entry. Raft
     Figure 2, and sections 5.3-5.4.

     Epochs never decrease along a log. An entry whose epoch is below its
     predecessor's is refused (HDL_INVALID): no legal sequence of leaders
     produces one. */
  uint64_t leader_epoch;
} hdl_record;

typedef struct {
  uint64_t batch_id;
  uint64_t first_sequence;
  uint64_t last_sequence;
  uint64_t durable_offset;
} hdl_receipt;

typedef struct {
  uint64_t generation;
  /* Byte position where this log BEGINS, in the log-global byte space. It is
     recorded in the first segment's name and header when the journal is
     created, and every later segment's base follows from it, so it is only read
     when a journal is created. Zero is the ordinary answer.

     Frames record the log-global position they were written for, so frames left
     over from a file's previous life -- at a different origin, or a different
     segment -- no longer name their own position and are rejected. */
  uint64_t base_position;
  uint32_t max_record_bytes;
  uint32_t max_batch_records;
  /* The size at which the active segment is closed and the next one is cut.
     Zero takes the default. A batch is never split across segments, so a batch
     larger than this bound produces a segment larger than it rather than a
     partial one. */
  uint64_t segment_size_bytes;
} hdl_options;

typedef struct {
  uint32_t queue_capacity;
  uint32_t max_batch_records;
  uint32_t batch_window_microseconds;
} hdl_broker_options;

typedef struct {
  uint64_t records;
  uint64_t durable_batches;
  uint32_t largest_batch;
  /* High-water mark of the ingress queue. "Keep queues bounded" is only a
     promise if the bound can be observed, so this is reported rather than
     inferred: it must never exceed the configured queue_capacity. */
  uint32_t max_queue_depth;
  /* How many durable batches actually waited out the batch window before being
     written. The broker holds the first record of a batch so concurrent callers
     can join it, which is what makes it faster than SQLite under load and pure
     added latency when there is nobody to join. Counted rather than timed,
     because "we stopped waiting when waiting could not help" is a claim a
     consumer should be able to check, and a stopwatch on a laptop is not a
     check. */
  uint64_t window_waits;
} hdl_broker_stats;

typedef struct {
  uint64_t sequence;
  uint64_t batch_id;
  uint64_t stream_id;
  const void *payload;
  uint32_t payload_length;
  /* Where this record sits in the log, and where the next one starts. A
     materializer that has applied this record stores `next_position` and hands
     it back to hdl_cursor_open_at, which is what stops a catching-up reader
     re-walking everything it has already seen. */
  uint64_t position;
  uint64_t next_position;
  /* This record's identity -- the same value hdl_last_record_digest reports
     once it is the last one. A leader streaming a catch-up carries the previous
     record's identity with each record, so healing a follower runs the same
     agreement check the live path does. */
  uint32_t digest;
  /* The leader epoch this entry originated in, recovered from its own frame. */
  uint64_t leader_epoch;
} hdl_cursor_record;

/* What a snapshot covers, and what it must restore to.
   No timestamp and no path: a receipt for the same committed prefix is written
   byte-for-byte identically every time, which is what makes it checkable rather
   than merely present. */
typedef struct {
  uint64_t first_index;
  uint64_t last_index;
  uint64_t first_position;
  uint64_t end_position;
  uint64_t first_sequence;
  uint64_t last_sequence;
  uint64_t records;
  /* CRC32 over the ordered record stream -- sequence, stream id and payload of
     every record the snapshot covers. Two snapshots with the same digest hold
     the same committed prefix. */
  uint32_t digest;
  /* Last included index and its TERM. A node restarting from a snapshot has to
     answer the election restriction about entries the snapshot replaced, and it
     cannot do that from the surviving log alone -- so the boundary carries the
     term with it. Raft section 7. */
  uint64_t last_included_leader_epoch;
} hdl_snapshot;

typedef int (*hdl_scan_callback)(void *context,
                                 uint64_t sequence,
                                 uint64_t batch_id,
                                 uint64_t stream_id,
                                 const void *payload,
                                 uint32_t payload_length);

/* Names the durability barrier this build issues before acknowledging a batch.
   It is public because the barrier IS the promise: a caller (and a gate) must
   be able to ask whether this build flushes the storage device's cache or only
   hands bytes to the drive. */
const char *hdl_sync_barrier_name(void);

/* The term of the last entry in this log, re-derived from the bytes by
   recovery rather than remembered across a restart. Zero for an empty log.

   This is half of the pair the election restriction compares; hdl_last_sequence
   is the other. A node that could not answer this after a restart could not
   vote safely, which is the whole reason the term is on disk. */
hdl_status hdl_last_leader_epoch(hdl_log *log, uint64_t *out);

hdl_status hdl_open(const char *path, const hdl_options *options, hdl_log **out);
hdl_status hdl_append_batch(hdl_log *log,
                            const hdl_record *records,
                            size_t count,
                            hdl_receipt *receipt);
hdl_status hdl_scan(hdl_log *log, hdl_scan_callback callback, void *context);

/* The last sequence this log has committed, in O(1). */
hdl_status hdl_last_sequence(hdl_log *log, uint64_t *out);

/* Discard every record after `sequence`, so this log ends there.

   This is the only operation besides retirement that deliberately destroys
   records, and unlike retirement it destroys records that look COMMITTED to the
   node holding them -- which is exactly what a replica must do when its history
   has parted from its cluster's and it cannot rejoin while holding records
   nobody else has. What is about to be discarded is recorded durably first.

   `sequence` must be a batch boundary: truncating inside a batch would leave a
   half-batch that recovery treats as a torn tail, silently discarding more than
   was asked. A sequence beyond the end is refused rather than satisfied. */
hdl_status hdl_truncate_to(hdl_log *log, uint64_t sequence);

/* The identity of this log's last committed record -- sequence, stream and
   payload -- in O(1), and deliberately independent of how it was batched: a
   leader group-commits many records into one batch while a replica applies one
   per request, so any fingerprint that depended on framing would differ between
   two logs holding identical records.

   It is how a replica tells "I am behind" from "I have diverged", which look
   identical to a sequence number and need opposite responses. */
hdl_status hdl_last_record_digest(hdl_log *log, uint32_t *out);
hdl_status hdl_cursor_open(hdl_log *log, hdl_cursor **out);

/* Replay from `position` -- a log-global position, as carried by
   `hdl_cursor_record.next_position` and by `hdl_receipt.durable_offset`.

   The position must name a frame boundary. One that does not is REFUSED rather
   than resynchronised by scanning forward: guessing where a record starts is
   how a reader silently invents one. A position at the committed end is not an
   error -- it is a reader that is caught up, and the cursor is simply empty. A
   position below the log's origin returns HDL_RETIRED, because those records
   are in a snapshot rather than gone. */
hdl_status hdl_cursor_open_at(hdl_log *log, uint64_t position, hdl_cursor **out);
hdl_status hdl_cursor_next(hdl_cursor *cursor, hdl_cursor_record *out);
hdl_status hdl_cursor_close(hdl_cursor *cursor);
hdl_status hdl_close(hdl_log *log);

/* Copy every COMPLETE segment -- everything but the one still being appended to
   -- into `snapshot_directory`, then verify the copy by reading it back as a
   journal and comparing the record stream it replays against the receipt. A
   snapshot that cannot be read back is not written. */
hdl_status hdl_snapshot_create(hdl_log *log, const char *snapshot_directory, hdl_snapshot *out);

/* Read a snapshot back and check it against its own receipt, record by record.
   This is what "verified" means here: restored and compared, not written and
   assumed. */
hdl_status hdl_snapshot_verify(const char *snapshot_directory, hdl_snapshot *out);

/* Restore a verified snapshot into a journal directory that does not yet exist. */
hdl_status hdl_snapshot_restore(const char *snapshot_directory, const char *journal_directory);

/* Retire the segments a verified snapshot covers. This is the only operation in
   this package that deliberately destroys data, so it verifies the snapshot
   first, records what it is about to retire, and only then deletes anything. */
hdl_status hdl_retire_snapshotted(hdl_log *log, const char *snapshot_directory);
hdl_status hdl_broker_open(hdl_log *log,
                           const hdl_broker_options *options,
                           hdl_broker **out);
hdl_status hdl_broker_submit(hdl_broker *broker,
                             const hdl_record *record,
                             hdl_receipt *receipt);

/* Submit, waiting at most `admission_timeout_microseconds` for QUEUE SPACE.
   Zero waits forever, which is exactly `hdl_broker_submit`.

   THE BOUND COVERS ADMISSION ONLY, and that is a limit of the design rather
   than an omission. Once a record has been admitted it is in a batch on its way
   to a durability barrier, and two things follow. The caller's answer is no
   longer "refused" -- the record may already be durable, and saying otherwise
   would be the one lie this package must never tell. And the request itself
   lives on the submitting thread's stack, where the writer thread holds a
   pointer to it; a caller that returned early would hand the writer memory that
   no longer exists.

   So: a caller can bound how long it waits to be LET IN. Once in, it waits for
   the truth. A submission refused here was never accepted and is not in the log. */
hdl_status hdl_broker_submit_within(hdl_broker *broker,
                                    const hdl_record *record,
                                    uint32_t admission_timeout_microseconds,
                                    hdl_receipt *receipt);
hdl_status hdl_broker_get_stats(hdl_broker *broker, hdl_broker_stats *out);
hdl_status hdl_broker_close(hdl_broker *broker);
const char *hdl_status_name(hdl_status status);

#ifdef __cplusplus
}
#endif

#endif
