# Done

- v0.1.0: release, checksums, documentation, immutable website publication, version bump, and source handoff porcelain.
- v0.1.2: validation ordering, safe output cleanup, explicit source-handoff status, and HEY_ROOT-correct documentation-example execution.
- v0.1.7: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes. Bump fixed for BSD sed.
- v0.1.8: declared version copies (`hey-version-files`) and a `bin/package-bump` hook; bump verifies, restores, dry-runs and normalizes; release/publish run the full check with explicit overrides; `update-packages` replaces the v3 updater.
- v0.1.9: bump and update-packages keep each rewritten file's final newline (present or missing) and mode — VERSION, hey-package.json, declared copies and import references. update-packages proven against the real Hey on hey_carplay.
- v0.1.12: update-packages writes portable locks. 0.1.11 resolved against an index in its own scratch directory with absolute archive paths, so refreshed locks named /Users/... and /var/folders/.../hey-packager.XXXXXX/... paths; it now passes the registry's own registry-v1.json relative to the project, checks that index lists every published release of a dependency, and refuses (and restores) a lock with an absolute or temporary path. `bin/registry-prune` ships, rewritten from embedded Python to Ruby with a spec; package-check refuses any bin/ command that runs Python.
