# Todo

1. Migration locking, status reporting, and down execution (the ledger and
   idempotent ensure landed with migrate.hey; the rest of the bookkeeping
   remains).
2. Compiled-lane fix for HeyRecordModel.find: HeyRecord.first is
   mis-resolved by the trunk LLVM subset as the collections builtin
   `first`; needs an upstream fix or a package-side rename, then model.hey
   joins the compiled receipt. Related: HeyRecord.first returns
   Result.ok(nil) on empty rows -- nil across a compiled API -- and should
   become a typed miss at the same time.
3. Store probe/inventory tooling (generalizing RecallCoach's
   db/records_probe.hey) as a tools/ program against a configured backend.
4. Validations and error collections without callbacks hidden in
   persistence.
5. Explicit associations and eager-loading plans.
6. Pool and partitioned Job ownership helpers supplied by adapters/app
   infrastructure.
7. Schema introspection and portable type mapping.
