# DONE — hey_cache

## 0.1.0 — the read-through chain

Shipped: `HeyCache.open` / `lookup` / `write` / `fetch` / `forget` / `probe`
/ `sweep` / `advance` / `stats`, a memory layer, an injected store layer,
per-entry and per-layer TTL, configurable write-back with downward clamping,
namespacing, a sensitive-value guard, and typed layer-error reporting.

Evidence (`bin/check`, all five gates, `heyc` 0.99.474a):

    1.  version drift guard ok (single literal, matches VERSION 0.1.0)
    1b. knob coverage ok (every hey_cache_option_value key appears in README.md)
    2.  7 specs pass on the interpreter lane
    3.  two-lane receipt ok (59 lines, interpreter == compiled, byte for byte)
    4.  real hey_record file store ok (written in one process, served cold in
        another, invalidated on disk)
    5.  real hey_sqlite3 + hey_record SQL store ok (cross-process, and 0 rows
        left in the database after forget)

Twelve deliberate defects were injected one at a time into a fresh copy of
the tree and each named gate was confirmed to go RED; the table is in
`docs/TESTING.md`. Two of them — deleting the persisted file between the two
processes, and leaving a row in the database — still exited 0, which is why
gates 4 and 5 assert values rather than exit codes.

## Deliberately not built

No file layer, no SQLite layer, no MySQL layer *in this package*:
`hey_record`'s `HeyRecordStore` already is all three, and a store layer takes
it by injection. No single-flight. No eviction policy. No wire protocol, no
server, no distributed mode. See `docs/ROADMAP.md`.

## Failures worth keeping

- The first design was going to avoid callables entirely, because the
  ecosystem brief says callables do not survive the compiled lane. Measured:
  `bind()` does not lower, but a BARE callable does — including a
  module-qualified one stored in a record inside a list. The restriction was
  narrower than the warning, and believing the warning would have produced
  the wrong API.
- A field named `entries` was silently shadowed by the `entries` builtin
  dot-accessor: `layer.entries` returned the record's key/value PAIRS, and
  `keys(layer.entries)` returned `[0,1]` — a plausible wrong answer, not an
  error. Renamed to `slots`.
- `layer.layer` (field named the same as the variable) ran fine on the
  interpreter and could not be lowered at all. Renamed to `backing`.
- A local variable named `read` shadowed the `read` builtin and made *stdlib
  Files* crash on the interpreter while the compiled binary was correct.
