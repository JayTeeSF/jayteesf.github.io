# IN PROGRESS — hey_reports

Nothing in flight. 0.1.0 is complete and `bin/check` is green in both
lanes.

The live questions for 0.2.0, in the order they should be answered:

1. **Does the maintainer want television line/pie charts enough to ask
   hey_tv for a `path` widget kind?** That is the single cheapest
   change that unblocks them — the tvOS renderer already has
   UIBezierPath. Everything else on the TV side is a workaround.
2. **Is anyone going to render on a real device?** Both non-web
   surfaces are `designed`, not `proved`, and only a device can move
   them. Until then the labels stay as they are.
3. **Fractional axis ticks or time-series x axis first?** Both need a
   scaled-integer domain threaded through `project`; doing them in one
   pass is cheaper than doing them separately.

See `docs/ROADMAP.md` for what each item is blocked on.
