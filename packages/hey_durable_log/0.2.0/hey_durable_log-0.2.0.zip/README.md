# hey_durable_log

`hey_durable_log` is the crash-safe mutation journal being built for the
cagents v2 server. It keeps accepted mutations hot in memory at the service
layer while making acknowledgement depend on a small append-only durable
record, not on SQLite page updates.

The active implementation is on this repository's `main_v2` branch. The
default `main` branch is only the stable landing/handoff branch for now. New
work should start with `git switch main_v2`; do not merge it to `main` merely
because it compiles. The durability, recovery, replay, concurrency and
end-to-end gates below define readiness.

The current checkpoint contains the portable C storage core, bounded ingress
broker, committed-prefix replay, and a Hey ABI-v2 write-path wrapper with owned
durability receipts. Replication and cagents integration remain follow-up work.

## Current guarantees

- `hdl_append_batch` serializes concurrent callers and returns only after the
  DATA frames, the COMMIT frame, and a durability barrier that flushes the
  storage device's cache all complete. The barrier is `fdatasync` on Linux and
  `fcntl(F_FULLFSYNC)` on Darwin, where `fdatasync` only reaches the drive and
  not the platters; `hdl_sync_barrier_name()` reports which one this build
  issues, and the gate asserts it per platform. There is no silent fallback to
  a weaker barrier.
- `hdl_broker_submit` feeds a bounded in-memory queue whose single writer
  combines concurrent requests into one durable batch and applies
  backpressure when the queue is full.
- Recovery publishes only batches with a complete, checksummed COMMIT frame.
- A physically short final frame or an uncommitted valid tail is truncated to
  the last committed boundary.
- A checksum failure in a complete frame fails closed as corruption.
- A newly created segment is synchronized before it can accept a batch.
- Each replay cursor snapshots the last validated COMMIT boundary, streams one
  record at a time, and never observes a half-written concurrent batch.

These are local-disk guarantees: they hold across process crash, OS crash and
power loss on this host. Surviving loss of the host or the disk itself requires
quorum replication before acknowledgement, which is not yet implemented. Until
it is, describe this package as local-durable and nothing more.

## Immediate handoff

The C, native-adapter and Hey gates pass, and the package is released through
`hey_packager` — see "Standard package controls" below. The C gates now build on
hosts without `pthread_barrier_t` (Darwin) as well as on hosts that have it.
Supply a current `hey-lang-bootstrap-plan` checkout through `HEY_ROOT` and run
`bin/check`.

Then implement, in order, each one test-first:

1. atomically published segment rotation plus crash tests at every create,
   sync, rename and manifest boundary;
2. bounded-memory/backpressure soak and real filesystem-exhaustion tests;
3. verified snapshots and restore receipts before segment retirement;
4. representative-NVMe latency, throughput, queue-depth and replay-lag tests;
5. fenced three-node quorum replication with minority refusal, leader-loss,
   catch-up and committed-prefix agreement tests.

Record each passing checkpoint in
`JayTeeSF/cagents@main_v2/projects/cagents/tasks/durable-mutation-journal`.
Do not integrate this package as cagents authority until the Hey gate and the
relevant failure/replay gates pass.

Non-negotiable rules: never acknowledge RAM alone; never skip a complete
corrupt frame; truncate only a partial/uncommitted tail; preserve ambiguous
post-COMMIT responses through application idempotency; keep queues bounded;
and never make SQLite or Git the hidden acknowledgement boundary.

## Check

`bin/check` is the shared `hey_packager` validation — manifest, `VERSION`, every
declared file, required documentation, the archive-entry pre-flight, and the
executable documentation example — followed by this package's own gate:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" bin/check
```

The package-specific portion is available directly as `bin/package-check`. It
runs the version drift guard, `make clean check`, and `bin/check-hey`. The C
core alone, without a Hey toolchain, is `make clean check`.

To validate only the generated dispatcher plus both the interpreter and
stage0-compiled receipts:

```sh
HEY_ROOT=/path/to/hey-lang-bootstrap-plan bin/check-hey
```

The gates compile with strict warnings, run append/scan recovery tests, truncate
a two-batch journal at every byte boundary, verify corruption is not silently
discarded, inject short-write and failed-sync errors, exercise real `SIGKILL` at
write/sync/receipt boundaries, exercise concurrent append callers, and prove the
broker uses fewer durable batches than records.

See [docs/FORMAT.md](docs/FORMAT.md) for the v1 byte format and recovery rules,
and [docs/TESTING.md](docs/TESTING.md) for the full gate description. The first
packaged-core measurements are in
[docs/BENCHMARK-2026-09-04.md](docs/BENCHMARK-2026-09-04.md).

For a local concurrency measurement (writers, operations per writer, maximum
batch, and batch window in microseconds):

```sh
bin/benchmark 8 250 64 250
```

## Standard package controls

This package uses `hey_packager` 0.1.6 or newer for validation, release
construction, source handoff, and immutable registry publication. The tool is
vendored as `bin/hey-packager`; it is release tooling, not a runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/package-zip` remains a compatibility alias for `bin/release`. Use
`bin/publish` only when the version does not already exist under
`$HOME/dev/jayteesf.github.io/packages/hey_durable_log`; published versions are
immutable, so change `VERSION` (through `bin/bump`) whenever released bytes
change.
