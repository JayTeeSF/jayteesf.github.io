#include "hey_jose.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/ecdsa.h>
#include <openssl/param_build.h>
#include <openssl/core_names.h>
#include <openssl/hmac.h>

/* ---- base64url decode ---- */
static int b64url_val(unsigned char c) {
  if (c >= 'A' && c <= 'Z') return c - 'A';
  if (c >= 'a' && c <= 'z') return c - 'a' + 26;
  if (c >= '0' && c <= '9') return c - '0' + 52;
  if (c == '-') return 62;
  if (c == '_') return 63;
  return -1;
}

/* Decode base64url into a freshly malloc'd buffer. Returns length, or -1 on
 * malformed input. *out is set to the buffer (caller frees) on success. */
static long b64url_decode(const char *data, size_t len, unsigned char **out) {
  unsigned char *buf = (unsigned char *)malloc(len / 4 * 3 + 4);
  if (!buf) return -1;
  size_t o = 0;
  int quad[4];
  int qn = 0;
  for (size_t i = 0; i < len; i++) {
    unsigned char c = (unsigned char)data[i];
    if (c == '=' || c == '\r' || c == '\n') continue;
    int v = b64url_val(c);
    if (v < 0) { free(buf); return -1; }
    quad[qn++] = v;
    if (qn == 4) {
      buf[o++] = (unsigned char)((quad[0] << 2) | (quad[1] >> 4));
      buf[o++] = (unsigned char)((quad[1] << 4) | (quad[2] >> 2));
      buf[o++] = (unsigned char)((quad[2] << 6) | quad[3]);
      qn = 0;
    }
  }
  if (qn == 1) { free(buf); return -1; }
  if (qn == 2) {
    buf[o++] = (unsigned char)((quad[0] << 2) | (quad[1] >> 4));
  } else if (qn == 3) {
    buf[o++] = (unsigned char)((quad[0] << 2) | (quad[1] >> 4));
    buf[o++] = (unsigned char)((quad[1] << 4) | (quad[2] >> 2));
  }
  *out = buf;
  return (long)o;
}

HeyNativeUtf8View hey_jose_b64url_to_text(HeyNativeUtf8View input) {
  static char *scratch = NULL;
  if (scratch) { free(scratch); scratch = NULL; }
  unsigned char *decoded = NULL;
  long n = b64url_decode(input.data, input.length, &decoded);
  if (n < 0) return (HeyNativeUtf8View){"", 0};
  scratch = (char *)malloc((size_t)n + 1);
  if (!scratch) { free(decoded); return (HeyNativeUtf8View){"", 0}; }
  memcpy(scratch, decoded, (size_t)n);
  scratch[n] = '\0';
  free(decoded);
  return (HeyNativeUtf8View){scratch, (size_t)n};
}

/* ---- HMAC-SHA256 (the HS256 primitive; also Stripe/webhook signatures) ----
 * Computes HMAC-SHA256(key, message) and returns it as lowercase hex in a
 * per-call static scratch buffer (the runtime copies the view immediately).
 * key and message are byte-safe (data+length), so binary secrets and raw
 * request bodies are handled correctly. Returns an empty view on failure. */
HeyNativeUtf8View hey_jose_hmac_sha256_hex(HeyNativeUtf8View key,
                                           HeyNativeUtf8View message) {
  static char hex[65];
  unsigned char mac[EVP_MAX_MD_SIZE];
  unsigned int maclen = 0;
  const unsigned char *out =
    HMAC(EVP_sha256(),
         key.data, (int)key.length,
         (const unsigned char *)message.data, message.length,
         mac, &maclen);
  if (!out || maclen != 32) return (HeyNativeUtf8View){"", 0};
  static const char digits[] = "0123456789abcdef";
  for (unsigned int i = 0; i < 32; i++) {
    hex[i * 2] = digits[(mac[i] >> 4) & 0xF];
    hex[i * 2 + 1] = digits[mac[i] & 0xF];
  }
  hex[64] = '\0';
  return (HeyNativeUtf8View){hex, 64};
}

static const EVP_MD *md_for(int32_t sha_bits) {
  if (sha_bits == 384) return EVP_sha384();
  if (sha_bits == 512 || sha_bits == 521) return EVP_sha512();
  return EVP_sha256();
}

/* ---- RSA verify ---- */
int32_t hey_jose_verify_rsa(int32_t sha_bits, int32_t pss,
                            HeyNativeUtf8View signing_input,
                            HeyNativeUtf8View signature_b64url,
                            HeyNativeUtf8View n_b64url,
                            HeyNativeUtf8View e_b64url) {
  unsigned char *sig = NULL, *nraw = NULL, *eraw = NULL;
  long siglen = b64url_decode(signature_b64url.data, signature_b64url.length, &sig);
  long nlen = b64url_decode(n_b64url.data, n_b64url.length, &nraw);
  long elen = b64url_decode(e_b64url.data, e_b64url.length, &eraw);
  int32_t rc = -1;
  BIGNUM *n = NULL, *e = NULL;
  OSSL_PARAM_BLD *bld = NULL;
  OSSL_PARAM *params = NULL;
  EVP_PKEY_CTX *pctx = NULL;
  EVP_PKEY *pkey = NULL;
  EVP_MD_CTX *mdctx = NULL;
  EVP_PKEY_CTX *vctx = NULL;

  if (siglen < 0 || nlen < 0 || elen < 0) { rc = -1; goto done; }
  n = BN_bin2bn(nraw, (int)nlen, NULL);
  e = BN_bin2bn(eraw, (int)elen, NULL);
  if (!n || !e) { rc = -2; goto done; }

  bld = OSSL_PARAM_BLD_new();
  if (!bld) { rc = -2; goto done; }
  if (!OSSL_PARAM_BLD_push_BN(bld, "n", n) || !OSSL_PARAM_BLD_push_BN(bld, "e", e)) { rc = -2; goto done; }
  params = OSSL_PARAM_BLD_to_param(bld);
  if (!params) { rc = -2; goto done; }

  pctx = EVP_PKEY_CTX_new_from_name(NULL, "RSA", NULL);
  if (!pctx || EVP_PKEY_fromdata_init(pctx) <= 0) { rc = -2; goto done; }
  if (EVP_PKEY_fromdata(pctx, &pkey, EVP_PKEY_PUBLIC_KEY, params) <= 0 || !pkey) { rc = -2; goto done; }

  mdctx = EVP_MD_CTX_new();
  if (!mdctx) { rc = -2; goto done; }
  if (EVP_DigestVerifyInit(mdctx, &vctx, md_for(sha_bits), NULL, pkey) <= 0) { rc = -2; goto done; }
  if (pss) {
    if (EVP_PKEY_CTX_set_rsa_padding(vctx, RSA_PKCS1_PSS_PADDING) <= 0) { rc = -2; goto done; }
    if (EVP_PKEY_CTX_set_rsa_pss_saltlen(vctx, RSA_PSS_SALTLEN_DIGEST) <= 0) { rc = -2; goto done; }
    if (EVP_PKEY_CTX_set_rsa_mgf1_md(vctx, md_for(sha_bits)) <= 0) { rc = -2; goto done; }
  } else {
    if (EVP_PKEY_CTX_set_rsa_padding(vctx, RSA_PKCS1_PADDING) <= 0) { rc = -2; goto done; }
  }
  if (EVP_DigestVerifyUpdate(mdctx, signing_input.data, signing_input.length) <= 0) { rc = -2; goto done; }
  {
    int v = EVP_DigestVerifyFinal(mdctx, sig, (size_t)siglen);
    rc = (v == 1) ? 1 : 0;
  }

done:
  if (mdctx) EVP_MD_CTX_free(mdctx);
  if (pkey) EVP_PKEY_free(pkey);
  if (pctx) EVP_PKEY_CTX_free(pctx);
  if (params) OSSL_PARAM_free(params);
  if (bld) OSSL_PARAM_BLD_free(bld);
  if (n) BN_free(n);
  if (e) BN_free(e);
  free(sig); free(nraw); free(eraw);
  return rc;
}

/* ---- EC (ECDSA) verify ---- */
static const char *ec_group_for(int32_t sha_bits) {
  if (sha_bits == 384) return "P-384";
  if (sha_bits == 521) return "P-521";
  return "P-256";
}

int32_t hey_jose_verify_ec(int32_t sha_bits,
                           HeyNativeUtf8View signing_input,
                           HeyNativeUtf8View signature_b64url,
                           HeyNativeUtf8View x_b64url,
                           HeyNativeUtf8View y_b64url) {
  unsigned char *sig = NULL, *xraw = NULL, *yraw = NULL, *pub = NULL, *der = NULL;
  long siglen = b64url_decode(signature_b64url.data, signature_b64url.length, &sig);
  long xlen = b64url_decode(x_b64url.data, x_b64url.length, &xraw);
  long ylen = b64url_decode(y_b64url.data, y_b64url.length, &yraw);
  int32_t rc = -1;
  BIGNUM *r = NULL, *s = NULL;
  ECDSA_SIG *ecsig = NULL;
  OSSL_PARAM_BLD *bld = NULL;
  OSSL_PARAM *params = NULL;
  EVP_PKEY_CTX *pctx = NULL;
  EVP_PKEY *pkey = NULL;
  EVP_MD_CTX *mdctx = NULL;

  if (siglen < 0 || xlen < 0 || ylen < 0) { rc = -1; goto done; }
  if (xlen != ylen || (siglen != xlen * 2)) { rc = -1; goto done; } /* JWS raw R||S */

  /* Build the uncompressed public point 0x04 || X || Y. */
  pub = (unsigned char *)malloc((size_t)(1 + xlen + ylen));
  if (!pub) { rc = -2; goto done; }
  pub[0] = 0x04;
  memcpy(pub + 1, xraw, (size_t)xlen);
  memcpy(pub + 1 + xlen, yraw, (size_t)ylen);

  bld = OSSL_PARAM_BLD_new();
  if (!bld) { rc = -2; goto done; }
  if (!OSSL_PARAM_BLD_push_utf8_string(bld, OSSL_PKEY_PARAM_GROUP_NAME, ec_group_for(sha_bits), 0)) { rc = -2; goto done; }
  if (!OSSL_PARAM_BLD_push_octet_string(bld, OSSL_PKEY_PARAM_PUB_KEY, pub, (size_t)(1 + xlen + ylen))) { rc = -2; goto done; }
  params = OSSL_PARAM_BLD_to_param(bld);
  if (!params) { rc = -2; goto done; }

  pctx = EVP_PKEY_CTX_new_from_name(NULL, "EC", NULL);
  if (!pctx || EVP_PKEY_fromdata_init(pctx) <= 0) { rc = -2; goto done; }
  if (EVP_PKEY_fromdata(pctx, &pkey, EVP_PKEY_PUBLIC_KEY, params) <= 0 || !pkey) { rc = -2; goto done; }

  /* Convert raw R||S to a DER ECDSA_SIG. */
  r = BN_bin2bn(sig, (int)(siglen / 2), NULL);
  s = BN_bin2bn(sig + siglen / 2, (int)(siglen / 2), NULL);
  ecsig = ECDSA_SIG_new();
  if (!r || !s || !ecsig) { rc = -2; goto done; }
  if (ECDSA_SIG_set0(ecsig, r, s) != 1) { rc = -2; goto done; }
  r = NULL; s = NULL; /* owned by ecsig now */
  {
    int derlen = i2d_ECDSA_SIG(ecsig, &der);
    if (derlen <= 0) { rc = -2; goto done; }
    mdctx = EVP_MD_CTX_new();
    if (!mdctx) { rc = -2; goto done; }
    if (EVP_DigestVerifyInit(mdctx, NULL, md_for(sha_bits), NULL, pkey) <= 0) { rc = -2; goto done; }
    if (EVP_DigestVerifyUpdate(mdctx, signing_input.data, signing_input.length) <= 0) { rc = -2; goto done; }
    int v = EVP_DigestVerifyFinal(mdctx, der, (size_t)derlen);
    rc = (v == 1) ? 1 : 0;
  }

done:
  if (mdctx) EVP_MD_CTX_free(mdctx);
  if (pkey) EVP_PKEY_free(pkey);
  if (pctx) EVP_PKEY_CTX_free(pctx);
  if (params) OSSL_PARAM_free(params);
  if (bld) OSSL_PARAM_BLD_free(bld);
  if (ecsig) ECDSA_SIG_free(ecsig);
  if (r) BN_free(r);
  if (s) BN_free(s);
  if (der) OPENSSL_free(der);
  free(sig); free(xraw); free(yraw); free(pub);
  return rc;
}
