package hey.android.api;
import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

/** Real native widgets with synthetic data and exact multiline drafts. */
public final class ChoiceInstrumentation extends Instrumentation {
  Activity activity;
  boolean staticOnly, lateOnly, focusOnly, retryOnly;
  static Object field(Object o,String n)throws Exception {Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
  static Object call(Object o,String n)throws Exception {Method m=o.getClass().getDeclaredMethod(n);m.setAccessible(true);return m.invoke(o);}
  static View find(View v,String label) {if(label.equals(v.getContentDescription()))return v; if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){View found=find(((ViewGroup)v).getChildAt(i),label);if(found!=null)return found;}return null;}
  static View text(View v,String label) {if(v instanceof TextView && label.contentEquals(((TextView)v).getText()))return v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){View got=text(((ViewGroup)v).getChildAt(i),label);if(got!=null)return got;}return null;}
  static void require(boolean b,String name){if(!b)throw new AssertionError(name);}
  static Object getValues(Object page){try{return field(page,"values");}catch(Exception e){throw new RuntimeException(e);}}
  @Override public void onCreate(Bundle args){super.onCreate(args);staticOnly="static".equals(args.getString("scenario"));lateOnly="late".equals(args.getString("scenario"));focusOnly="focus".equals(args.getString("scenario"));retryOnly="retry".equals(args.getString("scenario"));start();}
  void ui(Runnable run)throws Exception {AtomicReference<Throwable> failed=new AtomicReference<>();runOnMainSync(()->{try{run.run();}catch(Throwable t){failed.set(t);}});if(failed.get()!=null)throw new AssertionError(failed.get());waitForIdleSync();}
  void await(AlertDialog dialog,String label,boolean byText)throws Exception {
    for(int i=0;i<200;i++) { AtomicReference<View> found=new AtomicReference<>();runOnMainSync(()->found.set(byText?text(dialog.getWindow().getDecorView(),label):find(dialog.getWindow().getDecorView(),label))); if(found.get()!=null)return;Thread.sleep(100); }
    throw new AssertionError("Timed out waiting for "+label);
  }
  void shot(String name)throws Exception {android.graphics.Bitmap b=getUiAutomation().takeScreenshot();try(java.io.FileOutputStream out=new java.io.FileOutputStream(new java.io.File(activity.getFilesDir(),name+".png"))){b.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}}
  void oversized(Object page,View root,String draft)throws Exception {
    Map<String,Object> choice=null;
    for(Object o:Json.list(Json.dict(field(page,"screen")).get("fields"))) {Map<String,Object> f=Json.dict(o);if("choice".equals(f.get("kind")))choice=f;}
    require(choice!=null,"choice fixture field");
    final Map<String,Object> target=choice;Object options=target.get("options"),source=target.remove("choices");
    try {
      for(boolean longLabel:new boolean[]{false,true}) {
        List<Object> invalid=new ArrayList<>();for(int i=0;i<(longLabel?1:1001);i++){Map<String,Object> option=new LinkedHashMap<>();option.put("title",longLabel?"x".repeat(4097):"entry "+i);option.put("value","v"+i);invalid.add(option);}
        target.put("options",invalid);ui(()->find(root,"Folder").performClick());
        AlertDialog error=(AlertDialog)field(page,"choiceDialog");require(error!=null && error.isShowing(),"malformed static data keeps a cancellable dialog");
        ui(()->require(text(error.getWindow().getDecorView(),"These choices could not be loaded.")!=null,"oversized static choices show error"));
        ui(()->error.cancel());require(draft.equals(((Map<?,?>)field(page,"values")).get("body")),"oversized static choices preserve exact draft");
      }
    } finally {target.put("options",options);target.put("choices",source);}
  }
  /**
   * A choices reply that arrives after the page has left must change nothing:
   * not the loaded labels, not the shown Folder label. The read goes to
   * /choices-late, which the fixture answers 0.9 s later with every label
   * renamed, so a reply that slipped past the guard would be visible. The field
   * is made untouched for the check, so a late label would be allowed to show.
   */
  @SuppressWarnings("unchecked")
  void lateReply(Object page,View root,String draft)throws Exception {
    Map<String,Object> choice=null;
    for(Object o:Json.list(Json.dict(field(page,"screen")).get("fields"))) {Map<String,Object> f=Json.dict(o);if("choice".equals(f.get("kind")))choice=f;}
    require(choice!=null,"choice fixture field");
    Map<String,Object> source=Json.dict(choice.get("choices"));Object path=source.get("path");
    Set<String> touched=(Set<String>)field(page,"touched");boolean wasTouched=touched.contains("folder");
    try {
      source.put("path","/choices-late");
      Map<String,String> labelsBefore=new LinkedHashMap<>((Map<String,String>)field(page,"choiceLabels"));
      AtomicReference<String> shownBefore=new AtomicReference<>();
      ui(()->{touched.remove("folder");shownBefore.set(((TextView)find(root,"Folder")).getText().toString());find(root,"Folder").performClick();});
      AlertDialog late=(AlertDialog)field(page,"choiceDialog");require(late!=null && late.isShowing(),"late choices dialog opens");
      ui(()->{try{call(page,"leave");}catch(Exception e){throw new RuntimeException(e);}});
      Thread.sleep(3000);waitForIdleSync();
      require(!late.isShowing(),"page departure dismisses choices");
      ui(()->{
        // Both are judged before failing, so the mutation control can see each one.
        boolean labelsKept=labelsBefore.equals(getField(page,"choiceLabels"));
        String shownNow=((TextView)find(root,"Folder")).getText().toString();
        boolean shownKept=shownBefore.get().equals(shownNow);
        require(labelsKept && shownKept,"a choices reply after leave() changed nothing: loaded labels "+(labelsKept?"kept":"changed")+" "+getField(page,"choiceLabels")+"; shown Folder label "+(shownKept?"kept":"changed")+" '"+shownNow+"'");
      });
      if(draft!=null) require(draft.equals(((Map<?,?>)field(page,"values")).get("body")),"late choice preserves draft");
    } finally {source.put("path",path);if(wasTouched)ui(()->touched.add("folder"));}
  }
  static Object getField(Object page,String name){try{return field(page,name);}catch(Exception e){throw new RuntimeException(e);}}
  void reload(Object page,String method)throws Exception {ui(()->{try{Method m=activity.getClass().getDeclaredMethod(method,page.getClass());m.setAccessible(true);m.invoke(activity,page);}catch(Exception e){throw new RuntimeException(e);}});}
  static Map<String,Object> choiceField(Object page)throws Exception {
    for(Object o:Json.list(Json.dict(field(page,"screen")).get("fields"))) {Map<String,Object> f=Json.dict(o);if("choice".equals(f.get("kind")))return f;}
    throw new AssertionError("choice fixture field");
  }
  static Object folder(Object page)throws Exception {return ((Map<?,?>)field(page,"values")).get("folder");}
  static String shown(View root){View v=find(root,"Folder");return v instanceof TextView?((TextView)v).getText().toString():"none";}
  /** The current value is marked for the eye (a check) and for TalkBack (selected, "Selected"); another row is not. */
  static void requireMarked(View d,String chosen,String other){
    View c=find(d,"Select "+chosen);require(c!=null,"current choice row "+chosen);
    android.view.accessibility.AccessibilityNodeInfo info=c.createAccessibilityNodeInfo();
    require(c.isSelected() && info.isSelected() && "Selected".contentEquals(String.valueOf(info.getStateDescription())),"the current choice '"+chosen+"' is selected for TalkBack");
    require(text((View)c.getParent(),"✓")!=null,"the current choice '"+chosen+"' shows a check");
    View o=find(d,"Select "+other);require(o!=null,"other choice row "+other);
    require(!o.isSelected() && o.getStateDescription()==null && text((View)o.getParent(),"✓")==null,"'"+other+"' is not marked as the current choice");
  }
  /**
   * A double-tapped Retry sends one read. The fixture fails the first two reads
   * of a fresh /choices-retry/ path, the second one late, and answers the third,
   * so if the double tap sent two reads the tree would be drawn and the older
   * failure would then land beneath it.
   */
  AlertDialog retryOnce(Object page,View root)throws Exception {
    Map<String,Object> source=Json.dict(choiceField(page).get("choices"));Object path=source.get("path");
    source.put("path","/choices-retry/"+System.nanoTime());
    try {
      ui(()->find(root,"Folder").performClick());
      AlertDialog dialog=(AlertDialog)field(page,"choiceDialog");require(dialog!=null,"dynamic choice dialog opens");
      await(dialog,"Retry",true);
      ui(()->{View retry=text(dialog.getWindow().getDecorView(),"Retry");require(retry!=null,"failed choices offer retry");retry.performClick();retry.performClick();});
      Thread.sleep(2000);waitForIdleSync();
      ui(()->{View d=dialog.getWindow().getDecorView();boolean tree=find(d,"Expand work")!=null,failed=text(d,"Synthetic retry")!=null;
        require(!(tree&&failed),"a double-tapped Retry let a stale failure land beneath the tree");
        require(failed && text(d,"Retry")!=null && text(d,"Retry").isEnabled(),"one read per double-tapped Retry; its failure offers Retry again");});
      ui(()->text(dialog.getWindow().getDecorView(),"Retry").performClick());
      await(dialog,"Expand work",false);
      Thread.sleep(1000);waitForIdleSync();
      ui(()->require(text(dialog.getWindow().getDecorView(),"Synthetic retry")==null,"a successful retry leaves no error beneath the tree"));
      return dialog;
    } finally {source.put("path",path);}
  }
  /** A source read that fails while someone types keeps their field and cursor. */
  void sourceFailureKeepsFocus(Object page,View root)throws Exception {
    Map<String,Object> source=Json.dict(Json.dict(field(page,"screen")).get("source"));Object path=source.get("path");
    source.put("path","/defaults-fail");
    try {
      ui(()->{EditText typing=(EditText)find(root,"Message");typing.requestFocus();typing.setSelection(5);});
      reload(page,"loadForm");
      for(int i=0;i<100 && !"Synthetic source retry".equals(field(page,"message"));i++)Thread.sleep(100);
      require("Synthetic source retry".equals(field(page,"message")),"source failure remains retryable without losing draft");
      waitForIdleSync();
      ui(()->{View now=activity.getCurrentFocus();require(now instanceof EditText && "Message".equals(String.valueOf(now.getContentDescription())) && ((EditText)now).getSelectionStart()==5,"a failed source keeps the field being typed in and its cursor");});
    } finally {source.put("path",path);}
  }
  @Override public void onStart(){Bundle out=new Bundle();try{
    activity=startActivitySync(new Intent().setClassName(getTargetContext().getPackageName(),"hey.android.api.HeyAndroidApiActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));waitForIdleSync();
    final String draft="Mixed CASE, exact punctuation!\n\nSecond line — stays here.  ";
    Object page=call(activity,"top"); View root=activity.getWindow().getDecorView();
    Field initialToken=activity.getClass().getDeclaredField("token");initialToken.setAccessible(true);initialToken.set(activity,"synthetic-choice-account");
    // Persist the same synthetic account, so a pause/resume during a busy gate run is not mistaken for a sign-out that rebuilds the screen.
    {Field storeField=activity.getClass().getDeclaredField("store");storeField.setAccessible(true);Object store=storeField.get(activity);Method write=store.getClass().getDeclaredMethod("write",String.class);write.setAccessible(true);require(Boolean.TRUE.equals(write.invoke(store,"synthetic-choice-account")),"synthetic account is stored");}
    if(staticOnly) {
      ui(()->((EditText)find(root,"Message")).setText(draft));oversized(page,root,draft);
      out.putString("choices","true");finish(Activity.RESULT_OK,out);return;
    }
    // The launch-time reads went out signed out, and their answers are dropped
    // once the account changes, so whether they landed was a race. Load the
    // form again under the synthetic account: its source and its choices.
    reload(page,"load");
    if(lateOnly) {
      // Let the source default land and redraw first, so only the late reply could change the form.
      for(int i=0;i<100 && !"science-slug".equals(folder(page));i++)Thread.sleep(100);
      require("science-slug".equals(folder(page)),"late scenario source default");
      // And the form's own choices read, so only the late reply could change the labels.
      for(int i=0;i<100 && !((Map<?,?>)field(page,"choiceLabels")).containsKey("folder\u0000science-slug");i++)Thread.sleep(100);
      require(((Map<?,?>)field(page,"choiceLabels")).containsKey("folder\u0000science-slug"),"late scenario form choices");
      Thread.sleep(500);waitForIdleSync();lateReply(page,root,null);
      out.putString("choices","true");finish(Activity.RESULT_OK,out);return;
    }
    if(focusOnly) {
      ui(()->((EditText)find(root,"Message")).setText(draft));
      for(int i=0;i<100 && !"science-slug".equals(folder(page));i++)Thread.sleep(100);
      Thread.sleep(500);waitForIdleSync();sourceFailureKeepsFocus(page,root);
      out.putString("choices","true");finish(Activity.RESULT_OK,out);return;
    }
    if(retryOnly) {
      AlertDialog dialog=retryOnce(page,root);ui(()->dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick());
      out.putString("choices","true");finish(Activity.RESULT_OK,out);return;
    }
    ui(()->{EditText message=(EditText)find(root,"Message");require(message!=null,"message field");message.setText(draft);require((message.getInputType()&0x2c000)==0x2c000,"multiline traits");});
    // The form loads its choices with it: the stored id is shown by its label without the picker ever opening.
    for(int i=0;i<150 && !("science-slug".equals(folder(page)) && "science".equals(shown(root)));i++)Thread.sleep(100);
    waitForIdleSync();
    require("science-slug".equals(folder(page)),"the server's saved choice arrives");
    require(field(page,"choiceDialog")==null,"the picker was never opened");
    ui(()->require("science".equals(shown(root)),"stored choice is shown by its label, not its value: "+shown(root)));

    AlertDialog dialog=retryOnce(page,root);
    ui(()->{View d=dialog.getWindow().getDecorView();require(find(d,"Select Only this item")!=null,"static empty choice");require(find(d,"Select private")==null,"private root cannot select");find(d,"Expand work").performClick();require(find(d,"Select science")!=null,"short leaf label");});
    ui(()->{View d=dialog.getWindow().getDecorView();int[] parentAt=new int[2],childAt=new int[2];find(d,"Select work").getLocationOnScreen(parentAt);find(d,"Select science").getLocationOnScreen(childAt);require(childAt[0]>parentAt[0],"child label is indented beneath parent");requireMarked(d,"science","work");requireMarked(d,"science","Only this item");});shot("choice-expanded");
    ui(()->dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick());
    require(draft.equals(((Map<?,?>)field(page,"values")).get("body")),"cancel preserves exact prose");
    // Opening and cancelling the picker is not a choice.
    require("science-slug".equals(folder(page)),"cancel keeps the server's saved choice");
    waitForIdleSync();ui(()->require("science".equals(shown(root)),"cancel keeps the label shown: "+shown(root)));
    ui(()->find(root,"Folder").performClick());Thread.sleep(500);
    AlertDialog chosen=(AlertDialog)field(page,"choiceDialog");
    await(chosen,"Select work",false);
    ui(()->find(chosen.getWindow().getDecorView(),"Select work").performClick());
    require("work-slug".equals(folder(page)),"public parent can select");require(draft.equals(((Map<?,?>)field(page,"values")).get("body")),"select preserves exact prose");
    Object previousKey=((Map<?,?>)field(page,"values")).get("request_key");
    sourceFailureKeepsFocus(page,root);
    reload(page,"loadForm");
    for(int i=0;i<100 && Objects.equals(previousKey,((Map<?,?>)field(page,"values")).get("request_key"));i++)Thread.sleep(100);
    require(!Objects.equals(previousKey,((Map<?,?>)field(page,"values")).get("request_key")),"source metadata arrives despite touched draft");
    require(field(page,"message")==null,"successful source retry clears its previous error");
    waitForIdleSync();ui(()->{View now=activity.getCurrentFocus();require(now instanceof EditText && "Message".equals(String.valueOf(now.getContentDescription())) && ((EditText)now).getSelectionStart()==5,"a late source keeps the field being typed in and its cursor");});
    require("work-slug".equals(folder(page)),"touched selection wins over late source default");
    require(draft.equals(((Map<?,?>)field(page,"values")).get("body")),"late source preserves exact message");
    ui(()->find(root,"Folder").performClick());Thread.sleep(500);AlertDialog privateTree=(AlertDialog)field(page,"choiceDialog");
    await(privateTree,"Expand private",false);
    ui(()->{View d=privateTree.getWindow().getDecorView();find(d,"Expand private").performClick();require(find(d,"Select visible")!=null,"private branch expands");requireMarked(d,"work","visible");});shot("choice-private");
    sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);waitForIdleSync();
    require(!privateTree.isShowing(),"Back closes choices");
    require("work-slug".equals(folder(page)),"Back leaves the folder value unchanged");
    require(draft.equals(((Map<?,?>)field(page,"values")).get("body")),"Back leaves the draft unchanged");
    ui(()->require("work".equals(shown(root)),"Back leaves the shown folder unchanged: "+shown(root)));
    ui(()->find(root,"Folder").performClick());AlertDialog emptyChoice=(AlertDialog)field(page,"choiceDialog");
    ui(()->find(emptyChoice.getWindow().getDecorView(),"Select Only this item").performClick());
    require("".equals(folder(page)),"static empty choice can select while loading");
    ui(()->find(root,"Folder").performClick());AlertDialog parentAgain=(AlertDialog)field(page,"choiceDialog");await(parentAgain,"Select work",false);
    ui(()->find(parentAgain.getWindow().getDecorView(),"Select work").performClick());
    lateReply(page,root,draft);
    java.util.function.BooleanSupplier scope=(java.util.function.BooleanSupplier)call(page,"actionScope");
    Field token=activity.getClass().getDeclaredField("token");token.setAccessible(true);
    // On the main thread, so no onResume can see the momentary in-memory account.
    ui(()->{try{Object previous=token.get(activity);token.set(activity,"different-synthetic-account");boolean stale=!scope.getAsBoolean();token.set(activity,previous);require(stale,"account change invalidates choice scope");}catch(IllegalAccessException e){throw new RuntimeException(e);}});
    ui(()->{EditText username=(EditText)find(root,"Username");username.setText("MiXeD.User");require("MiXeD.User".equals(((Map<?,?>)getValues(page)).get("username")),"username retains typed case");});
    oversized(page,root,draft);
    shot("choice-parent-selected");
    ui(()->text(root,"Send").performClick());Thread.sleep(700);
    out.putString("choices","true");finish(Activity.RESULT_OK,out);
  }catch(Throwable e){out.putString("error",android.util.Log.getStackTraceString(e));finish(Activity.RESULT_CANCELED,out);}}
}
