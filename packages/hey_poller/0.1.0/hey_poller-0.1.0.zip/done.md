# Done

- 0.1.0: Poller (version/backend_for/backend/open/wait/next/data/send/drop/
  stats/close) over hey_epoll 0.1.1, hey_kqueue 0.1.0 and hey_iocp 0.0.1;
  selection at open() from Env.os() (override: HEY_POLLER_BACKEND or
  options.backend); serving calls go straight to the loaded extension (shared
  native function table); bin/build-native builds only the selected backend.
  Specs: the selection rule per OS with negative controls, hey_epoll's loop
  contract through Poller on this Mac (kqueue) and in a Linux container (epoll).
