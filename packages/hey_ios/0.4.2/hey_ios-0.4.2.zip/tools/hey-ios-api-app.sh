#!/usr/bin/env sh
# Build an iOS app from a Hey shell described by hey_mobile api_screens.
#
#   hey-ios-api-app.sh --source APP.hey --out DIR --bundle-id ID --display-name NAME
#       [--extension DIR]... [--share-extension] [--url-scheme SCHEME] [--allow-http]
#       [--minimum-ios 16.0] [--apple-music-reason TEXT] [--icon-png PNG] [--sim-udid UDID]
#
# The Hey shell must export
#   fn ios_app_manifest()        the description, as a literal JSON string
#   fn ios_action_code(0)        that string's byte length
# and may export
#   fn ios_app_origin()          the server origin, as a literal string. Since
#                                hey_ios 0.3.0 a description can be served and
#                                its bytes are the same for every build, so the
#                                origin is baked beside it. Without this export
#                                the host reads `origin` from the description,
#                                as 0.2.0 did.
# It is compiled through the LLVM lane (heyc build --emit-llvm-ir), its program
# `main` is removed so no Hey runtime is linked, and the object is linked with
# the native host (native/HeyIOSApiHost, HeyIOSKeychain, HeyIOSAudio).
#
# --extension DIR links another package's native code into the app (repeatable).
# DIR/ios-extension.json describes it:
#   {"name": "example",
#    "sources": ["native/X.m"], "headers": ["native/X.h"],
#    "frameworks": ["SomeFramework"],
#    "entitlements": ["com.apple.developer.some-entitlement"],
#    "scenes": [{"role": "...", "name": "...", "scene_class": "...", "delegate_class": "..."}]}
# Sources compile beside the host (they may import HeyIOSApiHost.h and
# HeyIOSAudio.h), frameworks are linked, each scene is declared in Info.plist
# (the host configures it from there), and each entitlement is linked into a
# simulator build and carried on a device only when the profile grants it.
# hey_carplay is such a package: --extension <its root>.
#
# --allow-http is for a development server on plain http (NSAllowsArbitraryLoads).
# Media streams on http are always allowed (NSAllowsArbitraryLoadsForMedia).
# With --sim-udid the app is uninstalled, installed and left for the caller to
# launch (so launch arguments stay the caller's).
#
# DEVICE: --device-udid UDID --sign-identity "Apple Development: ..." --profile P
# [--extension-profile P] builds for iphoneos, signs with the development
# profiles (their entitlements decide: an extension's restricted entitlement is
# carried only when Apple has granted it on the App ID), installs with
# devicectl and launches.
#
# DISTRIBUTION: --distribution --sign-identity "Apple Distribution: ..." --profile P
# [--extension-profile P] [--export-compliance exempt|nonexempt] [--sign-keychain KC]
# builds for iphoneos, signs with App Store profiles (no ProvisionedDevices,
# get-task-allow false), stamps the Xcode and SDK provenance keys App Store
# Connect validates, and writes DIR/<Name>.ipa. Nothing is installed. No
# --allow-http, no local-network keys, and no linked simulator entitlements.
# HEY_IOS_SHORT_VERSION and HEY_IOS_BUILD set the two version strings.
#
# UNIVERSAL LINKS: --associated-domain HOST (repeatable) signs the app with
# com.apple.developer.associated-domains = applinks:HOST on a device or
# distribution build, whose profile must grant Associated Domains; a profile
# that does not stops the build with the portal step. A simulator build claims
# no domain.
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
: "${HEY_ROOT:?set HEY_ROOT to the Hey toolchain}"
HEYC="$HEY_ROOT/bin/heyc"
source=''; out=''; bundle_id=''; display_name=''; extensions=''; scheme=''; allow_http=false; share=false
distribution=false; export_compliance=''; sign_keychain=''; associated_domains=''; signed_domains=''
minimum='16.0'; sim_udid=''; device_udid=''; sign_identity=''; app_profile=''; ext_profile=''; icon_png=''; music_reason='Plays Apple Music tracks you saved, when you subscribe.'
while [ "$#" -gt 0 ]; do
  case "$1" in
    --source) source="$2"; shift 2 ;;
    --out) out="$2"; shift 2 ;;
    --bundle-id) bundle_id="$2"; shift 2 ;;
    --display-name) display_name="$2"; shift 2 ;;
    --extension)
      [ -f "${2:-}/ios-extension.json" ] || { echo "hey-ios-api-app: --extension needs a directory holding ios-extension.json (got '${2:-}')" >&2; exit 64; }
      extensions="$extensions
$(CDPATH= cd -- "$2" && pwd)"; shift 2 ;;
    --with) echo "hey-ios-api-app: --with was replaced by --extension DIR in hey_ios 0.2.0 (CarPlay is the hey_carplay package: --extension <its root>)" >&2; exit 64 ;;
    --url-scheme) scheme="$2"; shift 2 ;;
    --allow-http) allow_http=true; shift ;;
    --share-extension) share=true; shift ;;
    --minimum-ios) minimum="$2"; shift 2 ;;
    --apple-music-reason) music_reason="$2"; shift 2 ;;
    --sim-udid) sim_udid="$2"; shift 2 ;;
    --device-udid) device_udid="$2"; shift 2 ;;
    --sign-identity) sign_identity="$2"; shift 2 ;;
    --profile) app_profile="$2"; shift 2 ;;
    --extension-profile) ext_profile="$2"; shift 2 ;;
    --icon-png) icon_png="$2"; shift 2 ;;
    --distribution) distribution=true; shift ;;
    --export-compliance)
      export_compliance="${2:-}"; shift 2
      case "$export_compliance" in exempt|nonexempt) ;; *) echo "hey-ios-api-app: --export-compliance must be exempt or nonexempt" >&2; exit 64 ;; esac ;;
    --sign-keychain) sign_keychain="$2"; shift 2 ;;
    --associated-domain)
      case "${2:-}" in ''|*[!a-z0-9.-]*|.*|*.) echo "hey-ios-api-app: --associated-domain takes a host name such as example.com (got '${2:-}')" >&2; exit 64 ;; esac
      associated_domains="$associated_domains $2"; shift 2 ;;
    -h|--help) sed -n '2,/^set -eu$/p' "$0" | sed '$d'; exit 0 ;;
    *) echo "hey-ios-api-app: unknown argument: $1" >&2; exit 64 ;;
  esac
done
[ -f "$source" ] || { echo "hey-ios-api-app: --source must name a Hey file" >&2; exit 64; }
[ -n "$out" ] && [ -n "$bundle_id" ] && [ -n "$display_name" ] || { echo "hey-ios-api-app: --out, --bundle-id and --display-name are required" >&2; exit 64; }
[ -x "$HEYC" ] || { echo "hey-ios-api-app: no compiler at $HEYC" >&2; exit 69; }
if [ "$distribution" = true ]; then
  [ -z "$device_udid" ] && [ -z "$sim_udid" ] || { echo "hey-ios-api-app: --distribution installs nothing; drop --device-udid and --sim-udid" >&2; exit 64; }
  [ "$allow_http" = false ] || { echo "hey-ios-api-app: --distribution refuses --allow-http (App Review and strangers get https only)" >&2; exit 64; }
  case "$sign_identity" in "Apple Distribution:"*) ;; *) echo "hey-ios-api-app: --distribution needs an \"Apple Distribution: ...\" --sign-identity (TestFlight rejects a Development signature)" >&2; exit 64 ;; esac
  [ -f "$app_profile" ] || { echo "hey-ios-api-app: --distribution needs --profile (an App Store profile)" >&2; exit 64; }
  [ "$share" = false ] || [ -f "$ext_profile" ] || { echo "hey-ios-api-app: --share-extension with --distribution needs --extension-profile" >&2; exit 64; }
  for p in "$app_profile" ${ext_profile:+"$ext_profile"}; do
    pl="$(security cms -D -i "$p" 2>/dev/null)" || { echo "hey-ios-api-app: $p is not a provisioning profile" >&2; exit 65; }
    if printf '%s' "$pl" | plutil -extract ProvisionedDevices raw - >/dev/null 2>&1 || [ "$(printf '%s' "$pl" | plutil -extract Entitlements.get-task-allow raw - 2>/dev/null)" = true ]; then
      echo "hey-ios-api-app: $p is a development or ad-hoc profile; --distribution needs an App Store profile" >&2; exit 65
    fi
  done
fi

exe=$(printf '%s' "$display_name" | tr -cd 'A-Za-z0-9')
[ -n "$exe" ] || exe=App
app="$out/$exe.app"
rm -rf "$out"
mkdir -p "$out/src" "$out/objects" "$app"

# ---- extensions (--extension DIR) -----------------------------------------------
# Read every manifest before anything is compiled, so a bad one stops the build in
# one line. Every name that reaches a plist or a command line must be plain
# (letters, digits, dot, dash, underscore).
plain() { case "$1" in ''|*[!A-Za-z0-9._-]*) return 1 ;; esac; }
ext_die() { echo "hey-ios-api-app: $1" >&2; exit 65; }
ext_names=''; ext_sources=''; ext_frameworks=''; ext_entitlement_keys=''; ext_scenes=''
while IFS= read -r dir; do
  [ -n "$dir" ] || continue
  manifest="$dir/ios-extension.json"
  plutil -convert xml1 -o /dev/null "$manifest" 2>/dev/null || ext_die "$manifest is not valid JSON"
  name=$(plutil -extract name raw -o - "$manifest" 2>/dev/null) || ext_die "$manifest has no name"
  plain "$name" || ext_die "$manifest: name '$name' is not plain"
  ext_names="$ext_names $name"
  for kind in headers sources; do
    i=0
    while file=$(plutil -extract "$kind.$i" raw -o - "$manifest" 2>/dev/null); do
      [ -f "$dir/$file" ] || ext_die "extension $name: no such file $dir/$file"
      base=$(basename "$file")
      plain "$base" || ext_die "extension $name: file name '$base' is not plain"
      [ ! -e "$out/src/$base" ] || ext_die "extension $name: $base is already taken by another source"
      cp "$dir/$file" "$out/src/$base"
      if [ "$kind" = sources ]; then
        case "$base" in *.m) ;; *) ext_die "extension $name: sources must be .m files ($base)" ;; esac
        ext_sources="$ext_sources $base"
      fi
      i=$((i + 1))
    done
  done
  i=0
  while value=$(plutil -extract "frameworks.$i" raw -o - "$manifest" 2>/dev/null); do
    plain "$value" || ext_die "extension $name: framework '$value' is not plain"
    ext_frameworks="$ext_frameworks -framework $value"; i=$((i + 1))
  done
  i=0
  while value=$(plutil -extract "entitlements.$i" raw -o - "$manifest" 2>/dev/null); do
    plain "$value" || ext_die "extension $name: entitlement '$value' is not plain"
    ext_entitlement_keys="$ext_entitlement_keys $value"; i=$((i + 1))
  done
  i=0
  while role=$(plutil -extract "scenes.$i.role" raw -o - "$manifest" 2>/dev/null); do
    scene_name=$(plutil -extract "scenes.$i.name" raw -o - "$manifest" 2>/dev/null || true)
    scene_class=$(plutil -extract "scenes.$i.scene_class" raw -o - "$manifest" 2>/dev/null || true)
    delegate_class=$(plutil -extract "scenes.$i.delegate_class" raw -o - "$manifest" 2>/dev/null || true)
    for value in "$role" "$scene_name" "$scene_class" "$delegate_class"; do
      plain "$value" || ext_die "extension $name: scene $i needs a plain role, name, scene_class and delegate_class"
    done
    [ "$role" != UIWindowSceneSessionRoleApplication ] || ext_die "extension $name: the phone's window scene belongs to the host"
    ext_scenes="$ext_scenes<key>$role</key><array><dict><key>UISceneClassName</key><string>$scene_class</string><key>UISceneConfigurationName</key><string>$scene_name</string><key>UISceneDelegateClassName</key><string>$delegate_class</string></dict></array>"
    i=$((i + 1))
  done
done <<EOF_EXTENSIONS
$extensions
EOF_EXTENSIONS
json_list() { # words -> ["a","b"]
  list=''
  for word in "$@"; do list="$list,\"$word\""; done
  printf '[%s]' "${list#,}"
}

# ---- Hey through the LLVM lane --------------------------------------------------
HEY_STDLIB_PATH="$HEY_ROOT/stdlib" "$HEYC" build --emit-llvm-ir "$source" -o "$out/src/app.ll" >/dev/null
grep -F 'define ptr @hey_fn_ios_app_manifest()' "$out/src/app.ll" >/dev/null || { echo "hey-ios-api-app: $source does not export fn ios_app_manifest() returning a string" >&2; exit 65; }
grep -F 'define i64 @hey_fn_ios_action_code(i64 ' "$out/src/app.ll" >/dev/null || { echo "hey-ios-api-app: $source does not export fn ios_action_code(action_id)" >&2; exit 65; }
has_origin=0
grep -F 'define ptr @hey_fn_ios_app_origin()' "$out/src/app.ll" >/dev/null && has_origin=1
awk '
BEGIN { skipping = 0; depth = 0; removed = 0 }
!skipping && /^define i32 @main\(/ { skipping = 1; depth = 1; removed++; next }
skipping { opens = gsub(/\{/, "{"); closes = gsub(/\}/, "}"); depth += opens - closes; if (depth <= 0) skipping = 0; next }
{ print }
END { if (removed != 1 || skipping) exit 42 }
' "$out/src/app.ll" > "$out/src/app-ios.ll" || { echo "hey-ios-api-app: could not remove the program main from the IR" >&2; exit 65; }
if grep -E 'call .*@hey_(runtime_(init|set_argv|shutdown|error)|llvm_)' "$out/src/app-ios.ll" >/dev/null; then
  echo "hey-ios-api-app: the shell calls the Hey runtime; it must only return literals (no runtime is linked)" >&2
  grep -n -E 'call .*@hey_(runtime_|llvm_)' "$out/src/app-ios.ll" | head -5 >&2
  exit 65
fi

if [ -n "$device_udid" ] || [ "$distribution" = true ]; then
  [ -n "$sign_identity" ] && [ -f "$app_profile" ] || { echo "hey-ios-api-app: --device-udid needs --sign-identity and --profile" >&2; exit 64; }
  [ "$share" = false ] || [ -f "$ext_profile" ] || { echo "hey-ios-api-app: --share-extension on a device needs --extension-profile" >&2; exit 64; }
  sdk=iphoneos; platform=iPhoneOS
  triple="arm64-apple-ios$minimum"
else
  sdk=iphonesimulator; platform=iPhoneSimulator
  case "$(uname -m)" in arm64|aarch64) arch=arm64 ;; *) arch=x86_64 ;; esac
  triple="$arch-apple-ios$minimum-simulator"
  [ -z "$associated_domains" ] || echo "hey-ios-api-app: note: associated domains are signed only with a profile (a device or distribution build); this simulator build claims none"
fi
# Whether a decoded profile grants Associated Domains. A profile grants it as
# the string "*" or as a list; xml1 extracts either (json refuses a bare
# string, which read a granting profile as one that does not grant).
grants_associated_domains() { # decoded-profile-plist
  printf '%s' "$1" | plutil -extract 'Entitlements.com\.apple\.developer\.associated-domains' xml1 -o - - >/dev/null 2>&1
}
# The entitlements a development profile grants, for signing with it: exactly
# the keys the profile carries, with keychain groups narrowed to the app's own.
# For the app itself (with_extensions=true) an extension's entitlement is added
# only when the profile carries it.
profile_entitlements() { # profile bundle_id group_id out with_extensions
  pl="$(security cms -D -i "$1")"
  pteam="$(printf '%s' "$pl" | plutil -extract TeamIdentifier.0 raw -)"
  granted=''
  if [ "$5" = true ]; then
    for key in $ext_entitlement_keys; do
      escaped=$(printf '%s' "$key" | sed 's/\./\\./g')
      if printf '%s' "$pl" | plutil -extract "Entitlements.$escaped" raw - >/dev/null 2>&1; then
        granted="$granted<key>$key</key><true/>"
      fi
    done
  fi
  # UNIVERSAL LINKS: the app claims each --associated-domain as applinks:HOST,
  # and only with a profile that grants Associated Domains. Without the grant
  # iOS refuses the signature at install, so the build stops here instead.
  if [ "$5" = true ] && [ -n "$associated_domains" ]; then
    if ! grants_associated_domains "$pl"; then
      claims=''
      for d in $associated_domains; do claims="$claims applinks:$d"; done
      echo "hey-ios-api-app: the profile $(basename "$1") does not grant Associated Domains, so $2 cannot claim$claims and universal links will not open the app." >&2
      echo "  The account holder: developer.apple.com > Certificates, IDs & Profiles > Identifiers > $2 > Capabilities > Associated Domains, then regenerate the profiles." >&2
      exit 69
    fi
    domains_xml=''
    signed_domains=''
    for d in $associated_domains; do domains_xml="$domains_xml<string>applinks:$d</string>"; signed_domains="$signed_domains applinks:$d"; done
    granted="$granted<key>com.apple.developer.associated-domains</key><array>$domains_xml</array>"
  fi
  # App Store Connect refuses get-task-allow; an App Store profile carries
  # beta-reports-active, which TestFlight reads from the signature.
  gta='<true/>'
  if [ "$distribution" = true ]; then
    gta='<false/>'
    [ "$(printf '%s' "$pl" | plutil -extract Entitlements.beta-reports-active raw - 2>/dev/null)" = true ] && granted="$granted<key>beta-reports-active</key><true/>"
  fi
  printf '%s\n' '<?xml version="1.0" encoding="UTF-8"?>' '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">' \
    "<plist version=\"1.0\"><dict><key>application-identifier</key><string>$pteam.$2</string><key>com.apple.developer.team-identifier</key><string>$pteam</string><key>get-task-allow</key>$gta<key>keychain-access-groups</key><array><string>$pteam.$3</string></array>$granted</dict></plist>" > "$4"
  plutil -lint "$4" >/dev/null
}
clang=$(xcrun --sdk "$sdk" --find clang)
sdk_path=$(xcrun --sdk "$sdk" --show-sdk-path)
"$clang" --target="$triple" -isysroot "$sdk_path" -Wno-override-module -c "$out/src/app-ios.ll" -o "$out/objects/app.o"

# ---- the native host ------------------------------------------------------------
cat > "$out/src/main.m" <<'EOF_MAIN'
#import <UIKit/UIKit.h>
#import "HeyIOSApiHost.h"
extern const char *hey_fn_ios_app_manifest(void);
extern int64_t hey_fn_ios_action_code(int64_t action_id);
int main(int argc, char *argv[]) {
  @autoreleasepool {
    HeyIOSApiHostStart(hey_fn_ios_app_manifest, hey_fn_ios_action_code);
    return UIApplicationMain(argc, argv, nil, @"HeyIOSAppDelegate");
  }
}
EOF_MAIN
for f in HeyIOSApiHost.h HeyIOSApiHost.m HeyIOSValues.h HeyIOSValues.m HeyIOSKeychain.h HeyIOSKeychain.m HeyIOSAudio.h HeyIOSAudio.m; do
  [ ! -e "$out/src/$f" ] || { echo "hey-ios-api-app: an extension ships $f, which is the host's own" >&2; exit 65; }
  cp "$PACKAGE_ROOT/native/$f" "$out/src/"
done
# The origin the shell bakes beside its description, for the app and the share
# extension alike; NULL for a shell that keeps it inside the description.
if [ "$has_origin" = 1 ]; then
  printf '%s\n' 'extern const char *hey_fn_ios_app_origin(void);' 'const char *HeyIOSBakedOrigin(void) { return hey_fn_ios_app_origin(); }' > "$out/src/HeyIOSBakedOrigin.m"
else
  printf '%s\n' 'const char *HeyIOSBakedOrigin(void) { return 0; }' > "$out/src/HeyIOSBakedOrigin.m"
fi
sources="main.m HeyIOSApiHost.m HeyIOSValues.m HeyIOSBakedOrigin.m HeyIOSKeychain.m HeyIOSAudio.m$ext_sources"
frameworks="-framework UIKit -framework Foundation -framework Security -framework AVFoundation -framework MediaPlayer -framework StoreKit -framework AVKit -framework AuthenticationServices -framework UniformTypeIdentifiers$ext_frameworks"
objects="$out/objects/app.o"
for s in $sources; do
  o="$out/objects/$(basename "$s" .m).o"
  "$clang" --target="$triple" -isysroot "$sdk_path" -fobjc-arc -fmodules -Wall -Wno-unused-parameter -I"$out/src" -c "$out/src/$s" -o "$o"
  objects="$objects $o"
done
# SIMULATOR ENTITLEMENTS ARE LINKED IN, NOT SIGNED IN. Measured 2026-09-12 on
# Xcode 26.5 with the CarPlay audio entitlement: an ad-hoc signature carrying a
# restricted entitlement is refused at spawn ("Security policy issue",
# SpringBoard "Launchd job spawn failed"); the same binary signed with no
# entitlements launches. Xcode's own simulator builds put the plist in a
# __TEXT,__entitlements section and sign ad-hoc without it, which is what this does.
# AND THE KEYCHAIN NEEDS AN APPLICATION IDENTIFIER. Measured the same day:
# without application-identifier / keychain-access-groups every SecItem call
# fails with -34018 ("Client has neither application-identifier nor
# keychain-access-groups entitlements"), so a stored session silently never
# exists. A device build gets these from its provisioning profile; the
# simulator takes any team prefix (HEY_IOS_TEAM_ID, default HEYSIMTEAM).
entitlements="$out/app.entitlements"
team="${HEY_IOS_TEAM_ID:-HEYSIMTEAM}"
ext_keys=''
for key in $ext_entitlement_keys; do ext_keys="$ext_keys<key>$key</key><true/>"; done
printf '%s\n' '<?xml version="1.0" encoding="UTF-8"?>' '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">' \
  "<plist version=\"1.0\"><dict><key>application-identifier</key><string>$team.$bundle_id</string><key>keychain-access-groups</key><array><string>$team.$bundle_id</string></array>$ext_keys</dict></plist>" > "$entitlements"
plutil -lint "$entitlements" >/dev/null
# A distribution binary carries only what its signature grants: no linked
# simulator team prefix, no restricted key the profile did not grant.
if [ "$distribution" = true ]; then
  "$clang" --target="$triple" -isysroot "$sdk_path" -fobjc-arc $objects $frameworks -o "$app/$exe"
else
  "$clang" --target="$triple" -isysroot "$sdk_path" -fobjc-arc $objects $frameworks -Wl,-sectcreate,__TEXT,__entitlements,"$entitlements" -o "$app/$exe"
fi

# ---- Info.plist and entitlements ------------------------------------------------
url_types=''
[ -n "$scheme" ] && url_types="<key>CFBundleURLTypes</key><array><dict><key>CFBundleURLName</key><string>$bundle_id</string><key>CFBundleURLSchemes</key><array><string>$scheme</string></array></dict></array>"
arbitrary=''
[ "$allow_http" = true ] && arbitrary='<key>NSAllowsArbitraryLoads</key><true/>'
# A development build may talk to a server on this network; a distribution build
# talks to its https origin, so it neither asks for the local network nor allows it.
local_network='<key>NSAllowsLocalNetworking</key><true/>'
local_reason='<key>NSLocalNetworkUsageDescription</key><string>Connects to your server on this network.</string>'
[ "$distribution" = true ] && { local_network=''; local_reason=''; }
cat > "$app/Info.plist" <<EOF_PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDevelopmentRegion</key><string>en</string>
<key>CFBundleDisplayName</key><string>$display_name</string>
<key>CFBundleExecutable</key><string>$exe</string>
<key>CFBundleIdentifier</key><string>$bundle_id</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleName</key><string>$display_name</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>${HEY_IOS_SHORT_VERSION:-0.1.0}</string>
<key>CFBundleVersion</key><string>${HEY_IOS_BUILD:-1}</string>
<key>CFBundleSupportedPlatforms</key><array><string>$platform</string></array>
<key>LSRequiresIPhoneOS</key><true/>
<key>MinimumOSVersion</key><string>$minimum</string>
<key>UIDeviceFamily</key><array><integer>1</integer></array>
<key>UILaunchScreen</key><dict/>
<key>UISupportedInterfaceOrientations</key><array><string>UIInterfaceOrientationPortrait</string></array>
<key>UIBackgroundModes</key><array><string>audio</string></array>
<key>NSAppleMusicUsageDescription</key><string>$music_reason</string>
$local_reason
<key>NSAppTransportSecurity</key><dict><key>NSAllowsArbitraryLoadsForMedia</key><true/>$local_network$arbitrary</dict>
$url_types
<key>UIApplicationSceneManifest</key><dict>
<key>UIApplicationSupportsMultipleScenes</key><false/>
<key>UISceneConfigurations</key><dict>
<key>UIWindowSceneSessionRoleApplication</key><array><dict><key>UISceneConfigurationName</key><string>Phone</string><key>UISceneDelegateClassName</key><string>HeyIOSPhoneSceneDelegate</string></dict></array>
$ext_scenes
</dict></dict>
</dict></plist>
EOF_PLIST
plutil -lint "$app/Info.plist" >/dev/null
# App Store Connect validates the Xcode and SDK provenance keys Xcode injects
# into every bundle it builds; this tool links directly, so it stamps the same
# values from the active Xcode (as hey_ios_tv does for tvOS).
stamp_provenance() { # Info.plist
  b=/usr/libexec/PlistBuddy
  $b -c "Add :BuildMachineOSBuild string $(sw_vers -buildVersion)" "$1" >/dev/null
  $b -c 'Add :DTCompiler string com.apple.compilers.llvm.clang.1_0' "$1" >/dev/null
  $b -c "Add :DTPlatformBuild string $sdk_build" "$1" >/dev/null
  $b -c 'Add :DTPlatformName string iphoneos' "$1" >/dev/null
  $b -c "Add :DTPlatformVersion string $sdk_version" "$1" >/dev/null
  $b -c "Add :DTSDKBuild string $sdk_build" "$1" >/dev/null
  $b -c "Add :DTSDKName string iphoneos$sdk_version" "$1" >/dev/null
  $b -c "Add :DTXcode string $xcode_numeric" "$1" >/dev/null
  $b -c "Add :DTXcodeBuild string $xcode_build" "$1" >/dev/null
}
if [ "$distribution" = true ]; then
  sdk_version=$(xcrun --sdk iphoneos --show-sdk-version)
  sdk_build=$(xcrun --sdk iphoneos --show-sdk-build-version)
  xcode_version=$(xcodebuild -version | awk 'NR==1 {print $2}')
  xcode_build=$(xcodebuild -version | awk 'NR==2 {print $3}')
  xcode_numeric=$(printf '%s\n' "$xcode_version" | awk -F. '{printf "%d%02d", $1, ($2 * 10) + ($3 + 0)}')
  stamp_provenance "$app/Info.plist"
  /usr/libexec/PlistBuddy -c 'Add :UIRequiredDeviceCapabilities array' -c 'Add :UIRequiredDeviceCapabilities:0 string arm64' "$app/Info.plist" >/dev/null
fi
case "$export_compliance" in
  exempt) /usr/libexec/PlistBuddy -c 'Add :ITSAppUsesNonExemptEncryption bool false' "$app/Info.plist" >/dev/null ;;
  nonexempt) /usr/libexec/PlistBuddy -c 'Add :ITSAppUsesNonExemptEncryption bool true' "$app/Info.plist" >/dev/null ;;
esac

# ---- the app icon (--icon-png, one 1024x1024 square with no alpha) ------------------
# iOS takes a compiled asset catalog, not loose PNGs. A single universal 1024 entry
# is enough since Xcode 14: actool derives every size and writes the Info.plist keys
# (CFBundleIcons) into a partial plist, which is merged rather than hand-written.
# --target-device iphone is required: without it actool filters the icon out, exits
# 0 and writes nothing (the same silent failure hey_ios_tv documents for tvOS).
if [ -n "$icon_png" ]; then
  [ -f "$icon_png" ] || { echo "hey-ios-api-app: --icon-png: no such file: $icon_png" >&2; exit 66; }
  set -- $(sips -g pixelWidth -g pixelHeight "$icon_png" 2>/dev/null | awk '/pixel/ {print $2}')
  [ "${1:-}" = 1024 ] && [ "${2:-}" = 1024 ] || { echo "hey-ios-api-app: --icon-png must be 1024x1024 (got ${1:-?}x${2:-?})" >&2; exit 65; }
  cat_dir="$out/Assets.xcassets"
  rm -rf "$cat_dir"; mkdir -p "$cat_dir/AppIcon.appiconset"
  printf '{"info":{"author":"hey_ios","version":1}}\n' > "$cat_dir/Contents.json"
  cp "$icon_png" "$cat_dir/AppIcon.appiconset/AppIcon-1024.png"
  printf '{"images":[{"filename":"AppIcon-1024.png","idiom":"universal","platform":"ios","size":"1024x1024"}],"info":{"author":"hey_ios","version":1}}\n' > "$cat_dir/AppIcon.appiconset/Contents.json"
  if ! xcrun actool "$cat_dir" --compile "$app" --platform "$sdk" --minimum-deployment-target "$minimum" \
        --target-device iphone --app-icon AppIcon --output-partial-info-plist "$out/icon-partial.plist" \
        --errors --warnings --notices > "$out/actool.log" 2>&1; then
    echo "hey-ios-api-app: actool failed; see $out/actool.log" >&2; tail -20 "$out/actool.log" >&2; exit 65
  fi
  [ -f "$app/Assets.car" ] || { echo "hey-ios-api-app: actool wrote no Assets.car; see $out/actool.log" >&2; exit 65; }
  /usr/libexec/PlistBuddy -c "Merge $out/icon-partial.plist" "$app/Info.plist" >/dev/null
  plutil -lint "$app/Info.plist" >/dev/null
  echo "hey-ios-api-app: app icon compiled (Assets.car $(wc -c < "$app/Assets.car" | tr -d ' ') bytes)"
fi

# ---- the share extension (--share-extension) ----------------------------------------
# A second bundle inside the app: PlugIns/<Exe>Share.appex, entry point
# NSExtensionMain, principal class HeyIOSShareViewController. It links the SAME
# Hey shell object as the app, so it reads the same description, and carries the
# app's keychain group as its first group, so the session the app stored is the
# one it sends. Signed before the app, which seals it.
if [ "$share" = true ]; then
  appex="$app/PlugIns/${exe}Share.appex"
  mkdir -p "$appex"
  cp "$PACKAGE_ROOT/native/HeyIOSShareController.h" "$PACKAGE_ROOT/native/HeyIOSShareController.m" "$out/src/"
  ext_objects="$out/objects/app.o"
  for s in HeyIOSShareController.m HeyIOSKeychain.m HeyIOSBakedOrigin.m; do
    o="$out/objects/ext-$(basename "$s" .m).o"
    "$clang" --target="$triple" -isysroot "$sdk_path" -fobjc-arc -fmodules -fapplication-extension -Wall -Wno-unused-parameter -I"$out/src" -c "$out/src/$s" -o "$o"
    ext_objects="$ext_objects $o"
  done
  ext_entitlements="$out/share.entitlements"
  printf '%s\n' '<?xml version="1.0" encoding="UTF-8"?>' '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">' \
    "<plist version=\"1.0\"><dict><key>application-identifier</key><string>$team.$bundle_id.share</string><key>keychain-access-groups</key><array><string>$team.$bundle_id</string></array></dict></plist>" > "$ext_entitlements"
  plutil -lint "$ext_entitlements" >/dev/null
  if [ "$distribution" = true ]; then
    "$clang" --target="$triple" -isysroot "$sdk_path" -fobjc-arc -fapplication-extension $ext_objects \
      -framework UIKit -framework Foundation -framework Security \
      -Wl,-e,_NSExtensionMain -o "$appex/${exe}Share"
  else
    "$clang" --target="$triple" -isysroot "$sdk_path" -fobjc-arc -fapplication-extension $ext_objects \
      -framework UIKit -framework Foundation -framework Security \
      -Wl,-e,_NSExtensionMain -Wl,-sectcreate,__TEXT,__entitlements,"$ext_entitlements" -o "$appex/${exe}Share"
  fi
  cat > "$appex/Info.plist" <<EOF_EXT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDevelopmentRegion</key><string>en</string>
<key>CFBundleDisplayName</key><string>$display_name</string>
<key>CFBundleExecutable</key><string>${exe}Share</string>
<key>CFBundleIdentifier</key><string>$bundle_id.share</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleName</key><string>${exe}Share</string>
<key>CFBundlePackageType</key><string>XPC!</string>
<key>CFBundleShortVersionString</key><string>${HEY_IOS_SHORT_VERSION:-0.1.0}</string>
<key>CFBundleVersion</key><string>${HEY_IOS_BUILD:-1}</string>
<key>CFBundleSupportedPlatforms</key><array><string>$platform</string></array>
<key>MinimumOSVersion</key><string>$minimum</string>
<key>NSAppTransportSecurity</key><dict>$local_network$arbitrary</dict>
<key>NSExtension</key><dict>
<key>NSExtensionPointIdentifier</key><string>com.apple.share-services</string>
<key>NSExtensionPrincipalClass</key><string>HeyIOSShareViewController</string>
<key>NSExtensionAttributes</key><dict><key>NSExtensionActivationRule</key><dict>
<key>NSExtensionActivationSupportsWebURLWithMaxCount</key><integer>1</integer>
<key>NSExtensionActivationSupportsText</key><true/>
</dict></dict>
</dict>
</dict></plist>
EOF_EXT
  plutil -lint "$appex/Info.plist" >/dev/null
  [ "$distribution" = true ] && stamp_provenance "$appex/Info.plist"
  if [ "$distribution" = true ]; then
    cp "$ext_profile" "$appex/embedded.mobileprovision"
    profile_entitlements "$ext_profile" "$bundle_id.share" "$bundle_id" "$out/share.distribution.entitlements" false
    codesign --force --sign "$sign_identity" ${sign_keychain:+--keychain "$sign_keychain"} --entitlements "$out/share.distribution.entitlements" --timestamp "$appex"
  elif [ -n "$device_udid" ]; then
    cp "$ext_profile" "$appex/embedded.mobileprovision"
    profile_entitlements "$ext_profile" "$bundle_id.share" "$bundle_id" "$out/share.device.entitlements" false
    codesign --force --sign "$sign_identity" --entitlements "$out/share.device.entitlements" --timestamp=none "$appex"
  else
    codesign --force --sign - --timestamp=none "$appex" >/dev/null 2>&1
  fi
fi

if [ "$distribution" = true ]; then
  cp "$app_profile" "$app/embedded.mobileprovision"
  profile_entitlements "$app_profile" "$bundle_id" "$bundle_id" "$out/app.distribution.entitlements" true
  codesign --force --sign "$sign_identity" ${sign_keychain:+--keychain "$sign_keychain"} --entitlements "$out/app.distribution.entitlements" --timestamp "$app"
  codesign --verify --strict --deep "$app"
  granted_keys=''
  for key in $ext_entitlement_keys; do
    grep -qF "<key>$key</key>" "$out/app.distribution.entitlements" && granted_keys="$granted_keys $key"
  done
  # THE .ipa: Payload/<Name>.app, zipped without extended attributes or
  # __MACOSX entries. Nothing is installed; uploading it is the account holder's.
  rm -rf "$out/Payload" "$out/$exe.ipa"
  mkdir -p "$out/Payload"
  ditto "$app" "$out/Payload/$exe.app"
  (cd "$out" && zip -qryX "$exe.ipa" Payload) || { echo "hey-ios-api-app: could not package the .ipa" >&2; exit 70; }
  rm -rf "$out/Payload"
  printf '{"kind":"hey-ios-api-app-v2","bundle_id":"%s","app":"%s","ipa":"%s","extensions":%s,"entitlements_granted":%s,"allow_http":false,"runtime_linked":false,"codesign":"distribution","short_version":"%s","build":"%s","export_compliance":"%s","associated_domains":%s}\n' "$bundle_id" "$app" "$out/$exe.ipa" "$(json_list $ext_names)" "$(json_list $granted_keys)" "${HEY_IOS_SHORT_VERSION:-0.1.0}" "${HEY_IOS_BUILD:-1}" "$export_compliance" "$(json_list $signed_domains)" > "$out/receipt.json"
  echo "hey-ios-api-app: distribution signing, extension entitlements granted by the profile: ${granted_keys:- none}; associated domains:${signed_domains:- none}"
  echo "hey-ios-api-app: $out/$exe.ipa"
  exit 0
elif [ -n "$device_udid" ]; then
  cp "$app_profile" "$app/embedded.mobileprovision"
  profile_entitlements "$app_profile" "$bundle_id" "$bundle_id" "$out/app.device.entitlements" true
  codesign --force --sign "$sign_identity" --entitlements "$out/app.device.entitlements" --timestamp=none "$app"
  granted_keys=''
  for key in $ext_entitlement_keys; do
    grep -qF "<key>$key</key>" "$out/app.device.entitlements" && granted_keys="$granted_keys $key"
  done
  echo "hey-ios-api-app: device signing, extension entitlements granted by the profile: ${granted_keys:- none}; associated domains:${signed_domains:- none}"
else
  codesign --force --sign - --timestamp=none "$app" >/dev/null 2>&1
fi
codesign --verify --strict "$app"

if [ -n "$device_udid" ]; then
  xcrun devicectl device install app --device "$device_udid" "$app" >"$out/device-install.log" 2>&1 || { echo "hey-ios-api-app: device install failed; see $out/device-install.log" >&2; tail -15 "$out/device-install.log" >&2; exit 70; }
  xcrun devicectl device process launch --device "$device_udid" --terminate-existing "$bundle_id" >"$out/device-launch.log" 2>&1 || { echo "hey-ios-api-app: installed, but launch failed (a locked phone refuses; unlock and open the app); see $out/device-launch.log" >&2; tail -8 "$out/device-launch.log" >&2; }
  printf '{"kind":"hey-ios-api-app-v2","bundle_id":"%s","app":"%s","extensions":%s,"entitlements_granted":%s,"allow_http":%s,"runtime_linked":false,"codesign":"development","device_udid":"%s","associated_domains":%s}\n' "$bundle_id" "$app" "$(json_list $ext_names)" "$(json_list $granted_keys)" "$allow_http" "$device_udid" "$(json_list $signed_domains)" > "$out/receipt.json"
  echo "hey-ios-api-app: $app installed on $device_udid"
  exit 0
fi

installed=false
if [ -n "$sim_udid" ]; then
  xcrun simctl list devices | grep -F "$sim_udid" | grep -q Booted || { xcrun simctl boot "$sim_udid" >/dev/null 2>&1 || true; xcrun simctl bootstatus "$sim_udid" -b >/dev/null; }
  xcrun simctl terminate "$sim_udid" "$bundle_id" >/dev/null 2>&1 || true
  xcrun simctl uninstall "$sim_udid" "$bundle_id" >/dev/null 2>&1 || true
  xcrun simctl install "$sim_udid" "$app"
  installed=true
fi
printf '{"kind":"hey-ios-api-app-v2","bundle_id":"%s","app":"%s","extensions":%s,"allow_http":%s,"runtime_linked":false,"codesign":"ad-hoc","simulator_install":%s,"simulator_udid":"%s"}\n' "$bundle_id" "$app" "$(json_list $ext_names)" "$allow_http" "$installed" "$sim_udid" > "$out/receipt.json"
echo "hey-ios-api-app: $app extensions=$(json_list $ext_names) installed=$installed"
