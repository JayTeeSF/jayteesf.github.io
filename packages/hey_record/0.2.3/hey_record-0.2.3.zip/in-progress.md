# In progress

v0.2.2 is the package-compatibility release for the existing dialect-aware parameterized plans and adapter callback contract used by `hey_sqlite3@0.2.3` and `hey_mysql@0.2.3`. The next porcelain work is migration bookkeeping, validations, associations, and pool/Job ownership conventions.
