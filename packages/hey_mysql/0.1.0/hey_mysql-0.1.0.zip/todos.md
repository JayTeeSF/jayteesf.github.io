# Todos

- Add live MySQL integration receipts and error-code normalization.
- Add typed values and prepared statements.
- Add persistent connections, pools, reconnect policy, streaming, TLS options, and native protocol/binding support.
- Replace `MYSQL_PWD` with a native secret-safe connection path.
