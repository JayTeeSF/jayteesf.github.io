# hey_jose

Reusable Hey JOSE package for JWT/JWS/JWKS verification using mature native cryptography.

## Status

**AUTHORITATIVE PACKAGE CONTRACT.** This repository is the permanent home for `hey_jose`. The release must use the current Hey native-package generator/schema; do not invent `hey.native.json`, release hashes, or lock data manually.

## Scope

Primary purpose is secure **verification**, not a kitchen-sink crypto API.

### `Jose.JWT`

- `parse(token)` -> decoded protected header + claims without trusting them
- `verify(token, policy)` -> verified claims or typed failure
- reject malformed compact serialization, duplicate/conflicting critical fields, unsupported algorithms, invalid base64url, bad signatures, and invalid claims

### `Jose.JWKS`

- parse JWKS documents
- select a key by `kid` plus compatible `alg`/`kty`/`use`
- bounded HTTP fetch integration through caller-provided fetch function or `stdlib:Http`
- cache with expiry/ETag/Cache-Control support
- refresh once on unknown `kid`, then fail closed
- bounded key/document sizes
- rotation-safe cache replacement

### `Jose.OIDC`

Verification policy supports:

- expected issuer
- expected audience(s)
- expiration required
- not-before and issued-at skew policy
- authorized-party/client checks where required
- nonce where applicable
- scope/permission extraction after verification

## Algorithms

MMeoww-required verification algorithms:

- RS256
- PS256 where provider requires it
- ES256

Do not support `alg=none`. Do not infer an algorithm from key material when the verification policy pins/permits a specific algorithm set.

Use OpenSSL/libcrypto or another explicitly approved mature crypto implementation. Do not implement RSA, ECDSA, SHA, ASN.1, or constant-time primitives in application/ordinary Hey code.

## Auth0 integration target

MMeoww uses OAuth 2.x / OIDC Authorization Code + PKCE. `hey_jose` validates API access tokens/JWTs against Auth0 issuer/JWKS/audience policy. Authentication provider SDKs are not required by the Hey API.

## Error taxonomy

Typed errors must distinguish at least:

- malformed token
- unsupported/forbidden algorithm
- missing/unknown key
- JWKS fetch/cache failure
- invalid signature
- expired
- not yet valid
- issuer mismatch
- audience mismatch
- required claim missing
- claim type invalid
- key/algorithm mismatch

Errors exposed to callers must not leak secrets or unsafe raw token material.

## Tests required

- known-good RS256/PS256/ES256 vectors
- corrupted header/payload/signature
- `none` and algorithm-confusion attempts
- wrong issuer/audience
- expired/future nbf/iat skew boundaries
- missing claims
- duplicate/ambiguous header conditions where parser permits detection
- unknown `kid` refresh behavior
- JWKS rotation
- maliciously oversized token/JWKS
- malformed JWK coordinates/modulus/exponent
- cache expiry and concurrent refresh stampede protection
- fuzz/property tests for compact parser and base64url decoder

## Security rule

Parsing is not verification. Ordinary application modules receive trusted identity claims only from the successful `verify` result.
