#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
OUT="$ROOT/build/package-scaffold"
rm -rf "$OUT"
"$ROOT/tools/hey-party.sh" init --out "$OUT" --name package_party --base-url https://party.example >/dev/null
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}" "$OUT/bin/check" > "$OUT.check"
grep -F 'party project checks passed' "$OUT.check" >/dev/null
grep -F 'spades=true' "$OUT.check" >/dev/null
grep -F 'bid_whist=true' "$OUT.check" >/dev/null
grep -F 'ghost=true' "$OUT.check" >/dev/null
grep -F '"hey_party": "^0.1.0"' "$OUT/hey-package.json" >/dev/null
grep -F '"hey_tv": "^0.1.0"' "$OUT/hey-package.json" >/dev/null
grep -F '"hey_web": "^0.1.6"' "$OUT/hey-package.json" >/dev/null
grep -F '"hey_mobile": "^0.1.3"' "$OUT/hey-package.json" >/dev/null
! grep -F '"hey_ios"' "$OUT/hey-package.json" >/dev/null
! grep -F '"hey_android"' "$OUT/hey-package.json" >/dev/null
printf '%s
' 'hey_party scaffold integration ok package_owned=true platform_adapters=consumer_selected'
