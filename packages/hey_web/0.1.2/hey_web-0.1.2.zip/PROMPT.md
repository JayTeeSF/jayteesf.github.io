# Continue hey_web

Continue the reusable Hey packages in this workspace against Hey 0.99.259a or the newest supplied compatible release.

The original goal is to make `hey_web` replace curl/wget-style shell commands and Puma-style Ruby serving while providing Rails-familiar routes, controllers, EHY views/layouts, JSON endpoints, model modules, and Jobs. Database work is split into `hey_record`, `hey_sqlite3`, and `hey_mysql`.

Read in this order:

1. `goals.md`
2. `in-progress.md`
3. `todos.md`
4. `done.md`
5. `README.md`
6. `docs/*.md`
7. `*.hey` package modules
8. `specs/*.hey`

Rules:

- Do not duplicate `stdlib:web`, `stdlib:http`, `stdlib:net`, TLS, EHY, Jobs, or package-manager responsibilities.
- Keep route handlers as first-class source callables; config files may select only explicitly supported built-in middleware.
- Preserve pure controller dispatch tests and add live receipts separately.
- Slow/retryable work belongs in Jobs.
- Existing specs stay unless explicitly obsolete and replaced by stricter coverage.
- Update `PROMPT.md`, `goals.md`, `todos.md`, `done.md`, and `in-progress.md` with every slice.
- Run `HEY_ROOT=/path/to/hey ./bin/check`, then pack immutable release assets.
- Keep exported module files at the package root while targeting Hey 0.99.259a: its `pkg:` resolver currently verifies `module.hey` directly and does not follow non-root manifest module paths.
