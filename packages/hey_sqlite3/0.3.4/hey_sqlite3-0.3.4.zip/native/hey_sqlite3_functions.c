/* PostgreSQL-compatible greatest() and least() for SQLite.
 *
 * SQLite ships no greatest/least, and its multi-argument max()/min() return
 * NULL when ANY argument is NULL:
 *
 *     SELECT max(NULL, 5)  ->  NULL
 *     SELECT max(3, 5)     ->  5
 *
 * PostgreSQL's GREATEST/LEAST ignore NULL arguments and return NULL only when
 * EVERY argument is NULL. Application SQL written for PostgreSQL and rewritten
 * `GREATEST(` -> `max(` therefore changes answers silently the moment an
 * argument is nullable. Registering real greatest()/least() functions on the
 * connection (the same fix Rails applies through sqlite3-ruby's
 * create_function) lets caller SQL keep saying greatest(a, b).
 *
 * These are registered on every connection hey_sqlite3_open() hands back, so
 * no Hey-side API change is needed. The Hey<->native FFI in this package
 * exposes fixed entry points and has no C->Hey callback path, so the function
 * bodies live here in C rather than behind a create_function binding.
 */

#include "hey_sqlite3_functions.h"

#include <string.h>

/* Exact i64-vs-double ordering, mirroring SQLite's own sqlite3IntFloatCompare:
   compare in integer space first (so a 64-bit integer too large to round-trip
   through a double is still ordered correctly), then in double space to break
   the tie. */
static int hey_sqlite3_int_float_compare(sqlite3_int64 i, double r) {
  sqlite3_int64 truncated;
  double widened;
  if (r != r) return +1;                        /* NaN sorts below everything */
  if (r < -9223372036854775808.0) return +1;
  if (r >= 9223372036854775808.0) return -1;
  truncated = (sqlite3_int64)r;
  if (i < truncated) return -1;
  if (i > truncated) return +1;
  widened = (double)i;
  if (widened < r) return -1;
  if (widened > r) return +1;
  return 0;
}

/* SQLite's storage-class sort order: NULL < INTEGER/REAL < TEXT < BLOB. */
static int hey_sqlite3_value_class(sqlite3_value *value) {
  switch (sqlite3_value_type(value)) {
    case SQLITE_NULL: return 0;
    case SQLITE_INTEGER: return 1;
    case SQLITE_FLOAT: return 1;
    case SQLITE_TEXT: return 2;
    default: return 3; /* SQLITE_BLOB */
  }
}

/* Compares two values the way SQLite compares them: storage class first, then
   numerically across INTEGER/REAL, then bytewise (the BINARY collation) for
   TEXT and BLOB with the shorter prefix sorting first.

   Honest scope: the public sqlite3_value_* API exposes no hook onto the
   collating sequence SQLite would derive from the surrounding expression, so
   text here always compares under BINARY. That matches SQLite's default; a
   column declared COLLATE NOCASE is the one case where greatest()/least()
   would order differently from a bare `<` on that column. */
static int hey_sqlite3_value_compare(sqlite3_value *left, sqlite3_value *right) {
  int left_class = hey_sqlite3_value_class(left);
  int right_class = hey_sqlite3_value_class(right);
  if (left_class != right_class) return left_class < right_class ? -1 : +1;

  if (left_class == 1) {
    int left_type = sqlite3_value_type(left);
    int right_type = sqlite3_value_type(right);
    if (left_type == SQLITE_INTEGER && right_type == SQLITE_INTEGER) {
      sqlite3_int64 a = sqlite3_value_int64(left);
      sqlite3_int64 b = sqlite3_value_int64(right);
      if (a < b) return -1;
      return a > b ? +1 : 0;
    }
    if (left_type == SQLITE_INTEGER) {
      return hey_sqlite3_int_float_compare(sqlite3_value_int64(left), sqlite3_value_double(right));
    }
    if (right_type == SQLITE_INTEGER) {
      return -hey_sqlite3_int_float_compare(sqlite3_value_int64(right), sqlite3_value_double(left));
    }
    {
      double a = sqlite3_value_double(left);
      double b = sqlite3_value_double(right);
      if (a < b) return -1;
      return a > b ? +1 : 0;
    }
  }

  {
    const unsigned char *left_bytes;
    const unsigned char *right_bytes;
    int left_length;
    int right_length;
    int shared;
    int ordering;

    if (left_class == 2) {
      /* text() before bytes(): the conversion sets the byte count. */
      left_bytes = sqlite3_value_text(left);
      left_length = sqlite3_value_bytes(left);
      right_bytes = sqlite3_value_text(right);
      right_length = sqlite3_value_bytes(right);
    } else {
      left_bytes = (const unsigned char *)sqlite3_value_blob(left);
      left_length = sqlite3_value_bytes(left);
      right_bytes = (const unsigned char *)sqlite3_value_blob(right);
      right_length = sqlite3_value_bytes(right);
    }
    if (left_length < 0) left_length = 0;
    if (right_length < 0) right_length = 0;

    shared = left_length < right_length ? left_length : right_length;
    ordering = 0;
    if (shared > 0 && left_bytes && right_bytes) ordering = memcmp(left_bytes, right_bytes, (size_t)shared);
    if (ordering != 0) return ordering < 0 ? -1 : +1;
    if (left_length < right_length) return -1;
    return left_length > right_length ? +1 : 0;
  }
}

/* `direction` is +1 for greatest and -1 for least. NULL arguments are skipped
   entirely; with nothing left the answer is NULL, which is PostgreSQL's
   all-arguments-null case. sqlite3_result_value() copies the winning argument,
   so the result keeps the winner's storage class. */
static void hey_sqlite3_extreme(sqlite3_context *context, int argc, sqlite3_value **argv, int direction) {
  sqlite3_value *best = NULL;
  int index;
  for (index = 0; index < argc; index++) {
    sqlite3_value *candidate = argv[index];
    if (sqlite3_value_type(candidate) == SQLITE_NULL) continue;
    if (!best || direction * hey_sqlite3_value_compare(candidate, best) > 0) best = candidate;
  }
  if (!best) {
    sqlite3_result_null(context);
    return;
  }
  sqlite3_result_value(context, best);
}

static void hey_sqlite3_greatest(sqlite3_context *context, int argc, sqlite3_value **argv) {
  hey_sqlite3_extreme(context, argc, argv, +1);
}

static void hey_sqlite3_least(sqlite3_context *context, int argc, sqlite3_value **argv) {
  hey_sqlite3_extreme(context, argc, argv, -1);
}

/* SQLITE_DETERMINISTIC (3.8.3) and SQLITE_INNOCUOUS (3.31) are optional
   hardening flags; build against an older amalgamation without them. */
#ifdef SQLITE_DETERMINISTIC
#define HEY_SQLITE3_DETERMINISTIC SQLITE_DETERMINISTIC
#else
#define HEY_SQLITE3_DETERMINISTIC 0
#endif
#ifdef SQLITE_INNOCUOUS
#define HEY_SQLITE3_INNOCUOUS SQLITE_INNOCUOUS
#else
#define HEY_SQLITE3_INNOCUOUS 0
#endif

int hey_sqlite3_register_functions(sqlite3 *database) {
  int flags = SQLITE_UTF8 | HEY_SQLITE3_DETERMINISTIC | HEY_SQLITE3_INNOCUOUS;
  int rc;
  if (!database) return SQLITE_MISUSE;
  /* -1 arguments: variadic, exactly like PostgreSQL's GREATEST/LEAST. */
  rc = sqlite3_create_function_v2(database, "greatest", -1, flags, NULL, hey_sqlite3_greatest, NULL, NULL, NULL);
  if (rc != SQLITE_OK) return rc;
  return sqlite3_create_function_v2(database, "least", -1, flags, NULL, hey_sqlite3_least, NULL, NULL, NULL);
}
