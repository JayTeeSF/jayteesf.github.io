# Goals

- Keep MySQL/MariaDB integration independently versioned outside Hey runtime and stdlib.
- Preserve opaque handles, explicit lifecycle, bounded blocking policy, deterministic diagnostics, and provider-neutral TLS modes.
- Add server-side prepared statements and a stable database-neutral adapter contract without leaking Connector/C types.
- Maintain honest, separate compile/load/refusal and configured live-server receipts.
