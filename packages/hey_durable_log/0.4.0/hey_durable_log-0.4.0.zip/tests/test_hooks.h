#ifndef HEY_DURABLE_LOG_TEST_HOOKS_H
#define HEY_DURABLE_LOG_TEST_HOOKS_H

#ifdef HDL_ENABLE_TEST_HOOKS
void hdl_test_fail_next_sync(void);
void hdl_test_fail_write_after_bytes(long long bytes);
void hdl_test_kill_during_write_after_bytes(long long bytes);
void hdl_test_kill_before_next_sync(void);
void hdl_test_kill_after_next_sync(void);

/* Every step of the cut, so the crash matrix can be enumerated rather than
   sampled. The numbering is the sequence itself. */
typedef enum {
  HDL_ROTATION_POINT_NONE = 0,
  HDL_ROTATION_POINT_AFTER_CREATE = 1,
  HDL_ROTATION_POINT_DURING_HEADER_WRITE = 2,
  HDL_ROTATION_POINT_AFTER_HEADER_WRITE = 3,
  HDL_ROTATION_POINT_AFTER_HEADER_SYNC = 4,
  HDL_ROTATION_POINT_AFTER_RENAME = 5,
  HDL_ROTATION_POINT_AFTER_DIRECTORY_SYNC = 6
} hdl_rotation_point;

void hdl_test_kill_at_rotation(int point);

/* Kill the process partway through writing a snapshot: after this many segments
   have been copied and published, and therefore before the receipt exists. */
void hdl_test_kill_during_snapshot_after_segments(long long segments);

/* Make the next durability barrier take this long. A slow disk is the only
   condition under which a bounded queue actually stays full long enough for a
   submitter to give up, so it has to be reproducible rather than raced. */
void hdl_test_stall_next_sync_microseconds(long long microseconds);
void hdl_test_fail_rotation_sync(void);
void hdl_test_clear_failures(void);
#endif

#endif
