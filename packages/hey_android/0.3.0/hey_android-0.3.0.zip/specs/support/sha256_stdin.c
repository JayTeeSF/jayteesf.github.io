/* Hashes standard input with the vendored SHA-256 (native/vendor/sha256) and
 * prints the hex digest. Built for the host by specs/sha256_host_spec.sh only;
 * it is never part of an app. */
#include <stdio.h>

#include "sha256.h"

int main(void) {
  SHA256_CTX ctx;
  BYTE buffer[65536];
  BYTE digest[SHA256_BLOCK_SIZE];
  size_t got;
  sha256_init(&ctx);
  while ((got = fread(buffer, 1, sizeof buffer, stdin)) > 0) sha256_update(&ctx, buffer, got);
  sha256_final(&ctx, digest);
  for (int i = 0; i < SHA256_BLOCK_SIZE; i++) printf("%02x", digest[i]);
  printf("\n");
  return ferror(stdin) ? 1 : 0;
}
