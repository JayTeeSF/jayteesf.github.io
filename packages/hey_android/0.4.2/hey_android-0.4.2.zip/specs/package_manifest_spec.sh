#!/usr/bin/env bash
# The package manifest must carry every renderer source needed by the installed
# build tool. Source-root checks cannot prove this because javac can see files
# that an immutable package archive omits.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"

python3 - "$ROOT" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
declared = set(json.loads((root / "hey-package.json").read_text())["files"])
renderer = {
    path.relative_to(root).as_posix()
    for path in (root / "renderer").rglob("*")
    if path.is_file()
}
missing = sorted(renderer - declared)
if missing:
    raise SystemExit("FAIL: renderer files omitted from hey-package.json: " + ", ".join(missing))
print(f"PASS: hey-package.json carries all {len(renderer)} renderer files used by source-root builds")
PY
