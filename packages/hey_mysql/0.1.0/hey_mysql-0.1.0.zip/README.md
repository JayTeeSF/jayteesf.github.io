# hey_mysql 0.1.0

MySQL adapter descriptors for `hey_record`.

```hey
import 'pkg:hey_mysql@0.1.0/main'

let db = Mysql.connect({
  host: '127.0.0.1',
  port: 3306,
  username: 'app',
  password: Env.get('MYSQL_PASSWORD'),
  database: 'app_development'
})
```

The first release invokes the native `mysql` client with direct argv and batch/raw tabular output. Passwords are passed through `MYSQL_PWD` rather than command arguments. It does not yet provide prepared statements, persistent connections, native MySQL protocol support, or a pool.

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```
