#import "HeyIOSShareController.h"
#import "HeyIOSKeychain.h"

extern const char *hey_fn_ios_app_manifest(void);
extern int64_t hey_fn_ios_action_code(int64_t action_id);
// Written by the build tool: the origin baked beside the description, or NULL.
extern const char *HeyIOSBakedOrigin(void);

static NSDictionary *HSD(id v) { return [v isKindOfClass:[NSDictionary class]] ? v : @{}; }
static NSString *HSS(id v) {
  if ([v isKindOfClass:[NSString class]]) return v;
  if ([v isKindOfClass:[NSNumber class]]) return [v stringValue];
  return @"";
}

@interface HeyIOSShareViewController () <UITextFieldDelegate>
@property(nonatomic, strong) NSDictionary *manifest;
@property(nonatomic, strong) NSDictionary *share;
@property(nonatomic, copy, nullable) NSString *link;
@property(nonatomic, copy, nullable) NSString *token;
@property(nonatomic, strong) UILabel *linkLabel;
@property(nonatomic, strong) UITextField *titleField;
@property(nonatomic, strong) UITextField *hookField;
@property(nonatomic, strong) UILabel *statusLabel;
@property(nonatomic, strong) UIBarButtonItem *saveButton;
@property(nonatomic, assign) BOOL busy;
@end

@implementation HeyIOSShareViewController

- (void)loadManifest {
  self.manifest = @{};
  const char *raw = hey_fn_ios_app_manifest();
  size_t length = raw ? strlen(raw) : 0;
  if ((int64_t)length != hey_fn_ios_action_code(0)) return;
  id parsed = [NSJSONSerialization JSONObjectWithData:[NSData dataWithBytes:raw length:length] options:0 error:nil];
  if ([parsed isKindOfClass:[NSDictionary class]]) self.manifest = parsed;
}

- (NSString *)word:(NSString *)key { return HSS(self.share[key]); }

- (UITextField *)fieldWithPlaceholder:(NSString *)placeholder label:(NSString *)label {
  UITextField *field = [[UITextField alloc] init];
  field.placeholder = placeholder;
  field.accessibilityLabel = label;
  field.borderStyle = UITextBorderStyleRoundedRect;
  field.autocapitalizationType = UITextAutocapitalizationTypeSentences;
  field.returnKeyType = UIReturnKeyDone;
  field.delegate = self;
  return field;
}

- (UILabel *)caption:(NSString *)text {
  UILabel *label = [[UILabel alloc] init];
  label.text = text;
  label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
  label.textColor = [UIColor secondaryLabelColor];
  return label;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  [self loadManifest];
  self.share = HSD(self.manifest[@"share"]);
  self.token = HeyIOSKeychainRead(HSS(self.manifest[@"keychain_service"]), @"session");
  self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];

  UINavigationBar *bar = [[UINavigationBar alloc] init];
  bar.translatesAutoresizingMaskIntoConstraints = NO;
  UINavigationItem *item = [[UINavigationItem alloc] initWithTitle:[self word:@"title"]];
  item.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:[self word:@"cancel"] style:UIBarButtonItemStylePlain target:self action:@selector(cancel)];
  self.saveButton = [[UIBarButtonItem alloc] initWithTitle:[self word:@"save"] style:UIBarButtonItemStyleDone target:self action:@selector(save)];
  item.rightBarButtonItem = self.saveButton;
  bar.items = @[item];
  [self.view addSubview:bar];

  self.linkLabel = [[UILabel alloc] init];
  self.linkLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
  self.linkLabel.numberOfLines = 2;
  self.linkLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
  self.titleField = [self fieldWithPlaceholder:[self word:@"title_placeholder"] label:[self word:@"title_label"]];
  self.hookField = [self fieldWithPlaceholder:[self word:@"hook_placeholder"] label:[self word:@"hook_label"]];
  self.statusLabel = [[UILabel alloc] init];
  self.statusLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
  self.statusLabel.numberOfLines = 0;
  self.statusLabel.textColor = [UIColor secondaryLabelColor];

  UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[
    [self caption:[self word:@"link_label"]], self.linkLabel,
    [self caption:[self word:@"title_label"]], self.titleField,
    [self caption:[self word:@"hook_label"]], self.hookField,
    self.statusLabel
  ]];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.spacing = 8;
  [stack setCustomSpacing:18 afterView:self.linkLabel];
  [stack setCustomSpacing:18 afterView:self.titleField];
  [stack setCustomSpacing:18 afterView:self.hookField];
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  [self.view addSubview:stack];
  UILayoutGuide *safe = self.view.safeAreaLayoutGuide;
  [NSLayoutConstraint activateConstraints:@[
    [bar.topAnchor constraintEqualToAnchor:safe.topAnchor],
    [bar.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [bar.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [stack.topAnchor constraintEqualToAnchor:bar.bottomAnchor constant:20],
    [stack.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor constant:20],
    [stack.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor constant:-20]
  ]];

  if (self.token.length == 0 || self.manifest.count == 0) {
    self.statusLabel.text = [self word:@"signed_out"];
    self.saveButton.enabled = NO;
  }
  self.saveButton.enabled = NO;
  [self findLink];
}

// The link a host app shares arrives as a URL, or as text holding one (some
// apps share "Title https://..."). The first http(s) link wins.
- (void)findLink {
  NSExtensionItem *first = self.extensionContext.inputItems.firstObject;
  NSString *offeredTitle = first.attributedTitle.string ?: @"";
  if (offeredTitle.length == 0) offeredTitle = first.attributedContentText.string ?: @"";
  NSMutableArray<NSItemProvider *> *providers = [NSMutableArray array];
  for (NSExtensionItem *extensionItem in self.extensionContext.inputItems) [providers addObjectsFromArray:extensionItem.attachments ?: @[]];
  [self tryProviders:providers index:0 title:offeredTitle];
}

- (void)tryProviders:(NSArray<NSItemProvider *> *)providers index:(NSUInteger)index title:(NSString *)title {
  if (index >= providers.count) { [self showLink:nil title:title]; return; }
  NSItemProvider *provider = providers[index];
  NSString *type = [provider hasItemConformingToTypeIdentifier:@"public.url"] ? @"public.url" : ([provider hasItemConformingToTypeIdentifier:@"public.plain-text"] ? @"public.plain-text" : nil);
  if (type == nil) { [self tryProviders:providers index:index + 1 title:title]; return; }
  [provider loadItemForTypeIdentifier:type options:nil completionHandler:^(id<NSSecureCoding> loaded, NSError *error) {
    NSString *found = nil;
    if ([(id)loaded isKindOfClass:[NSURL class]]) {
      NSURL *url = (NSURL *)loaded;
      if ([url.scheme hasPrefix:@"http"]) found = url.absoluteString;
    } else if ([(id)loaded isKindOfClass:[NSString class]]) {
      NSDataDetector *detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:nil];
      NSString *text = (NSString *)loaded;
      for (NSTextCheckingResult *match in [detector matchesInString:text options:0 range:NSMakeRange(0, text.length)]) {
        if ([match.URL.scheme hasPrefix:@"http"]) { found = match.URL.absoluteString; break; }
      }
    }
    dispatch_async(dispatch_get_main_queue(), ^{
      if (found.length > 0) [self showLink:found title:title];
      else [self tryProviders:providers index:index + 1 title:title];
    });
  }];
}

- (void)showLink:(nullable NSString *)link title:(NSString *)title {
  self.link = link;
  self.linkLabel.text = link ?: @"";
  if (title.length > 0 && ![title isEqualToString:link]) self.titleField.text = title;
  if (link.length == 0) {
    self.statusLabel.text = [self word:@"no_link"];
    return;
  }
  if (self.token.length > 0 && self.manifest.count > 0) self.saveButton.enabled = YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
  [textField resignFirstResponder];
  return YES;
}

- (void)cancel {
  [self.extensionContext cancelRequestWithError:[NSError errorWithDomain:NSCocoaErrorDomain code:NSUserCancelledError userInfo:nil]];
}

- (id)value:(id)spec vars:(NSDictionary *)vars {
  if (![spec isKindOfClass:[NSString class]] || ![(NSString *)spec hasPrefix:@"$"]) return spec;
  NSString *s = spec;
  BOOL optional = [s hasSuffix:@"?"];
  NSString *name = [s substringWithRange:NSMakeRange(1, s.length - 1 - (optional ? 1 : 0))];
  NSString *value = HSS(vars[name]);
  if (value.length == 0) return optional ? nil : @"";
  return value;
}

- (void)save {
  if (self.busy || self.link.length == 0) return;
  [self.view endEditing:YES];
  self.busy = YES;
  self.saveButton.enabled = NO;
  self.statusLabel.text = [self word:@"saving"];
  NSDictionary *route = HSD(self.share[@"request"]);
  NSDictionary *vars = @{@"url": self.link, @"title": self.titleField.text ?: @"", @"hook": self.hookField.text ?: @""};
  NSMutableDictionary *body = [NSMutableDictionary dictionary];
  [HSD(route[@"body"]) enumerateKeysAndObjectsUsingBlock:^(id key, id spec, BOOL *stop) {
    id value = [self value:spec vars:vars];
    if (value != nil) body[key] = value;
  }];
  // The share sheet reads the description this build baked, never a served
  // one: it runs in its own process, and a link is saved the same way either way.
  const char *baked = HeyIOSBakedOrigin();
  NSString *origin = baked != NULL ? [NSString stringWithUTF8String:baked] : HSS(self.manifest[@"origin"]);
  NSURL *url = [NSURL URLWithString:[origin stringByAppendingString:HSS(route[@"path"])]];
  if (url == nil) { self.busy = NO; self.saveButton.enabled = YES; self.statusLabel.text = [self word:@"failed"]; return; }
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20];
  request.HTTPMethod = HSS(route[@"method"]);
  request.HTTPBody = [NSJSONSerialization dataWithJSONObject:body options:0 error:nil];
  [request setValue:@"application/json" forHTTPHeaderField:@"content-type"];
  [request setValue:@"application/json" forHTTPHeaderField:@"accept"];
  NSDictionary *session = HSD(self.manifest[@"session"]);
  [request setValue:[HSS(session[@"prefix"]) stringByAppendingString:self.token ?: @""] forHTTPHeaderField:HSS(session[@"header"])];
  [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    NSInteger status = [response isKindOfClass:[NSHTTPURLResponse class]] ? ((NSHTTPURLResponse *)response).statusCode : 0;
    NSDictionary *json = HSD(data.length ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil);
    dispatch_async(dispatch_get_main_queue(), ^{
      self.busy = NO;
      if (error != nil || status == 0) {
        self.statusLabel.text = [self word:@"unreachable"];
        self.saveButton.enabled = YES;
        return;
      }
      if (status == 401) {
        self.statusLabel.text = [self word:@"signed_out"];
        return;
      }
      if (status >= 400) {
        NSString *said = HSS(json[@"error"]);
        self.statusLabel.text = said.length > 0 ? said : [self word:@"failed"];
        self.saveButton.enabled = YES;
        return;
      }
      self.statusLabel.text = [json[@"existing"] boolValue] ? [self word:@"existing"] : [self word:@"saved"];
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.9 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.extensionContext completeRequestReturningItems:@[] completionHandler:nil];
      });
    });
  }] resume];
}

@end
