/* hey_epoll: a batched, edge-triggered TCP event loop for Hey.
 *
 * The loop does the work a Hey program cannot do itself today: it owns the
 * readiness set (epoll on Linux, kqueue on Darwin/BSD), accepts every pending
 * connection, reads every readable socket until EAGAIN into a per-connection
 * input buffer, and flushes queued output when a socket becomes writable.
 *
 * Hey sees one batch per wait():  wait -> next/data ... -> send.  The bytes
 * are handed over as text (UTF-8 without NUL; anything else is refused and
 * the connection closed), protocol parsing stays in Hey, and the program says
 * how many input bytes each reply consumed.  Unconsumed input stays here and
 * the connection is offered again on the next wait, so partial and pipelined
 * requests need no state on the Hey side.
 *
 * One loop belongs to one thread.  Nothing here is global, so separate
 * Native.open instances (one per worker) never share state.
 */
#define _GNU_SOURCE
#include "hey_epoll.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#if defined(__linux__)
#include <sys/epoll.h>
#define HEY_EPOLL_BACKEND "epoll"
#define HEY_EPOLL_LINUX 1
#else
#include <sys/event.h>
#include <sys/time.h>
#define HEY_EPOLL_BACKEND "kqueue"
#define HEY_EPOLL_LINUX 0
#endif

#define HEY_EPOLL_MAX_EVENTS 1024
#define HEY_EPOLL_READ_CHUNK 65536
#define HEY_EPOLL_MAX_INPUT (1024 * 1024)

typedef struct HeyEpollConn {
  char *in;
  char *out;
  size_t in_off, in_len, in_cap;
  size_t out_off, out_len, out_cap;
  uint32_t gen;
  uint8_t open;
  uint8_t want_close;
  uint8_t queued;
  uint8_t write_armed;
} HeyEpollConn;

typedef struct HeyEpollLoop {
  int poller;
  int listener;
  int port;
  HeyEpollConn *conns;
  size_t conns_cap;
  int *ready;
  size_t ready_len, ready_pos, ready_cap;
  int *pending;
  size_t pending_len, pending_cap;
  char *scratch;
  char stats_text[512];
  uint64_t accepted, closed, live, waits, batches_ready, bytes_in, bytes_out;
  uint64_t accept_errors, oversize, invalid_text, partial_writes;
} HeyEpollLoop;

static HeyEpollLoop *hey_epoll_loop(HeyNativeHandle value) { return (HeyEpollLoop *)(uintptr_t)value; }

static int64_t hey_epoll_id(HeyEpollLoop *loop, int fd) {
  return ((int64_t)loop->conns[fd].gen << 32) | (int64_t)(uint32_t)fd;
}

static HeyEpollConn *hey_epoll_lookup(HeyEpollLoop *loop, int64_t id, int *fd_out) {
  if (!loop || id < 0) return NULL;
  int fd = (int)(id & 0xffffffff);
  uint32_t gen = (uint32_t)((uint64_t)id >> 32);
  if (fd < 0 || (size_t)fd >= loop->conns_cap) return NULL;
  HeyEpollConn *c = &loop->conns[fd];
  if (!c->open || c->gen != gen) return NULL;
  if (fd_out) *fd_out = fd;
  return c;
}

static int hey_epoll_grow_ints(int **items, size_t *cap, size_t need) {
  if (need <= *cap) return 1;
  size_t next = *cap ? *cap * 2 : 256;
  while (next < need) next *= 2;
  int *grown = (int *)realloc(*items, next * sizeof(int));
  if (!grown) return 0;
  *items = grown;
  *cap = next;
  return 1;
}

static int hey_epoll_ensure_conn(HeyEpollLoop *loop, int fd) {
  if ((size_t)fd < loop->conns_cap) return 1;
  size_t next = loop->conns_cap ? loop->conns_cap : 1024;
  while (next <= (size_t)fd) next *= 2;
  HeyEpollConn *grown = (HeyEpollConn *)realloc(loop->conns, next * sizeof(HeyEpollConn));
  if (!grown) return 0;
  memset(grown + loop->conns_cap, 0, (next - loop->conns_cap) * sizeof(HeyEpollConn));
  loop->conns = grown;
  loop->conns_cap = next;
  return 1;
}

static int hey_epoll_set_nonblocking(int fd) {
  int flags = fcntl(fd, F_GETFL, 0);
  if (flags < 0) return -1;
  if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) return -1;
  (void)fcntl(fd, F_SETFD, FD_CLOEXEC);
  return 0;
}

/* ---- readiness registration ------------------------------------------- */

static int hey_epoll_watch(HeyEpollLoop *loop, int fd, int want_write, int add) {
#if HEY_EPOLL_LINUX
  struct epoll_event ev;
  memset(&ev, 0, sizeof(ev));
  ev.events = EPOLLIN | EPOLLRDHUP | EPOLLET | (want_write ? EPOLLOUT : 0);
  ev.data.fd = fd;
  return epoll_ctl(loop->poller, add ? EPOLL_CTL_ADD : EPOLL_CTL_MOD, fd, &ev);
#else
  struct kevent changes[2];
  int n = 0;
  if (add) { EV_SET(&changes[n], fd, EVFILT_READ, EV_ADD | EV_CLEAR, 0, 0, NULL); n++; }
  if (want_write) { EV_SET(&changes[n], fd, EVFILT_WRITE, EV_ADD | EV_ONESHOT, 0, 0, NULL); n++; }
  if (n == 0) return 0;
  return kevent(loop->poller, changes, n, NULL, 0, NULL);
#endif
}

static void hey_epoll_close_fd(HeyEpollLoop *loop, int fd) {
  HeyEpollConn *c = &loop->conns[fd];
  if (!c->open) return;
  free(c->in);
  free(c->out);
  uint32_t gen = c->gen;
  memset(c, 0, sizeof(*c));
  c->gen = gen + 1;     /* every id handed out for the old socket is now stale */
  close(fd);            /* closing removes it from epoll/kqueue */
  loop->closed++;
  if (loop->live) loop->live--;
}

/* ---- output ------------------------------------------------------------- */

static ssize_t hey_epoll_write_some(int fd, const char *data, size_t len) {
#if defined(MSG_NOSIGNAL)
  return send(fd, data, len, MSG_NOSIGNAL);
#else
  return send(fd, data, len, 0);
#endif
}

/* Returns 0 when the connection had to be closed. */
static int hey_epoll_flush(HeyEpollLoop *loop, int fd) {
  HeyEpollConn *c = &loop->conns[fd];
  while (c->out_off < c->out_len) {
    ssize_t n = hey_epoll_write_some(fd, c->out + c->out_off, c->out_len - c->out_off);
    if (n > 0) { c->out_off += (size_t)n; loop->bytes_out += (uint64_t)n; continue; }
    if (n < 0 && errno == EINTR) continue;
    if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
      if (!c->write_armed) {
        c->write_armed = 1;
        if (hey_epoll_watch(loop, fd, 1, 0) != 0) { hey_epoll_close_fd(loop, fd); return 0; }
      }
#if !HEY_EPOLL_LINUX
      else (void)hey_epoll_watch(loop, fd, 1, 0);   /* kqueue write filter is one-shot */
#endif
      return 1;
    }
    hey_epoll_close_fd(loop, fd);
    return 0;
  }
  c->out_off = c->out_len = 0;
  if (c->out_cap > 65536) { free(c->out); c->out = NULL; c->out_cap = 0; }
  if (c->write_armed) {
    c->write_armed = 0;
#if HEY_EPOLL_LINUX
    (void)hey_epoll_watch(loop, fd, 0, 0);
#endif
  }
  if (c->want_close) { hey_epoll_close_fd(loop, fd); return 0; }
  return 1;
}

/* ---- input -------------------------------------------------------------- */

static void hey_epoll_mark_ready(HeyEpollLoop *loop, int fd) {
  HeyEpollConn *c = &loop->conns[fd];
  if (c->queued || c->in_len == c->in_off) return;
  if (!hey_epoll_grow_ints(&loop->ready, &loop->ready_cap, loop->ready_len + 1)) return;
  c->queued = 1;
  loop->ready[loop->ready_len++] = fd;
}

/* Reads until EAGAIN. Returns 0 when the connection was closed. */
static int hey_epoll_read_all(HeyEpollLoop *loop, int fd, int drain) {
  HeyEpollConn *c = &loop->conns[fd];
  for (;;) {
    ssize_t n = recv(fd, loop->scratch, HEY_EPOLL_READ_CHUNK, 0);
    if (n > 0) {
      loop->bytes_in += (uint64_t)n;
      if (c->in_off == c->in_len) c->in_off = c->in_len = 0;
      size_t need = c->in_len + (size_t)n;
      if (need - c->in_off > HEY_EPOLL_MAX_INPUT) { loop->oversize++; hey_epoll_close_fd(loop, fd); return 0; }
      if (need > c->in_cap) {
        if (c->in_off > 0) {       /* reclaim consumed space before growing */
          memmove(c->in, c->in + c->in_off, c->in_len - c->in_off);
          c->in_len -= c->in_off;
          c->in_off = 0;
          need = c->in_len + (size_t)n;
        }
        if (need > c->in_cap) {
          size_t cap = c->in_cap ? c->in_cap : 1024;
          while (cap < need) cap *= 2;
          char *grown = (char *)realloc(c->in, cap);
          if (!grown) { hey_epoll_close_fd(loop, fd); return 0; }
          c->in = grown;
          c->in_cap = cap;
        }
      }
      memcpy(c->in + c->in_len, loop->scratch, (size_t)n);
      c->in_len += (size_t)n;
      /* A short read means the socket was drained at that moment; any later
         arrival raises a new edge, so the extra recv() for EAGAIN is skipped,
         unless the peer also hung up (then read on to see the 0). */
      if (!drain && (size_t)n < HEY_EPOLL_READ_CHUNK) return 1;
      continue;
    }
    if (n == 0) { hey_epoll_close_fd(loop, fd); return 0; }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) return 1;
    hey_epoll_close_fd(loop, fd);
    return 0;
  }
}

static void hey_epoll_accept_all(HeyEpollLoop *loop) {
  for (;;) {
#if HEY_EPOLL_LINUX
    int fd = accept4(loop->listener, NULL, NULL, SOCK_NONBLOCK | SOCK_CLOEXEC);
#else
    int fd = accept(loop->listener, NULL, NULL);
#endif
    if (fd < 0) {
      if (errno == EINTR) continue;
      if (errno != EAGAIN && errno != EWOULDBLOCK) loop->accept_errors++;
      return;
    }
#if !HEY_EPOLL_LINUX
    if (hey_epoll_set_nonblocking(fd) != 0) { close(fd); loop->accept_errors++; continue; }
    { int one = 1; setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)); }
#endif
    { int one = 1; setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one)); }
    if (!hey_epoll_ensure_conn(loop, fd)) { close(fd); loop->accept_errors++; continue; }
    HeyEpollConn *c = &loop->conns[fd];
    uint32_t gen = c->gen;
    memset(c, 0, sizeof(*c));
    c->gen = gen;
    c->open = 1;
    if (hey_epoll_watch(loop, fd, 0, 1) != 0) { c->open = 0; close(fd); loop->accept_errors++; continue; }
    loop->accepted++;
    loop->live++;
    /* Clients usually send the request with the handshake: read it now
       instead of waiting one more round for the readiness event. */
    if (hey_epoll_read_all(loop, fd, 0)) hey_epoll_mark_ready(loop, fd);
  }
}

/* ---- text check: the hand-over is UTF-8 text without NUL --------------- */

/* Length of the longest valid prefix; *bad is set when an invalid byte (not a
   merely truncated final sequence) was found. */
static size_t hey_epoll_text_prefix(const unsigned char *s, size_t n, int *bad) {
  size_t i = 0;
  *bad = 0;
  while (i < n) {
    unsigned char b = s[i];
    if (b >= 0x01 && b < 0x80) { i++; continue; }
    if (b == 0) { *bad = 1; return i; }
    size_t need;
    uint32_t cp;
    if (b >= 0xc2 && b <= 0xdf) { need = 1; cp = b & 0x1f; }
    else if (b >= 0xe0 && b <= 0xef) { need = 2; cp = b & 0x0f; }
    else if (b >= 0xf0 && b <= 0xf4) { need = 3; cp = b & 0x07; }
    else { *bad = 1; return i; }
    if (i + need >= n) {
      /* fewer continuation bytes than needed remain: maybe a split read */
      for (size_t k = i + 1; k < n; k++) if ((s[k] & 0xc0) != 0x80) { *bad = 1; return i; }
      return i;
    }
    for (size_t k = 1; k <= need; k++) {
      if ((s[i + k] & 0xc0) != 0x80) { *bad = 1; return i; }
      cp = (cp << 6) | (s[i + k] & 0x3f);
    }
    if ((need == 2 && cp < 0x800) || (need == 3 && (cp < 0x10000 || cp > 0x10ffff)) || (cp >= 0xd800 && cp <= 0xdfff)) {
      *bad = 1;
      return i;
    }
    i += need + 1;
  }
  return i;
}

/* ---- public functions ---------------------------------------------------- */

HeyNativeHandle hey_epoll_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport) {
  char host_c[64];
  if (host.length >= sizeof(host_c)) return (HeyNativeHandle)0;
  memcpy(host_c, host.data, host.length);
  host_c[host.length] = '\0';

  /* Use the descriptor allowance the process was given (its hard limit). */
  struct rlimit rl;
  if (getrlimit(RLIMIT_NOFILE, &rl) == 0 && rl.rlim_cur < rl.rlim_max) {
    rl.rlim_cur = rl.rlim_max;
#if defined(__APPLE__)
    if (rl.rlim_cur > 10240) rl.rlim_cur = 10240;   /* Darwin refuses RLIM_INFINITY here */
#endif
    (void)setrlimit(RLIMIT_NOFILE, &rl);
  }

  struct sockaddr_in addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons((uint16_t)port);
  if (inet_pton(AF_INET, host_c, &addr.sin_addr) != 1) return (HeyNativeHandle)0;

  int lfd = socket(AF_INET, SOCK_STREAM, 0);
  if (lfd < 0) return (HeyNativeHandle)0;
  int one = 1;
  setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
  if (reuseport) setsockopt(lfd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(one));
  if (bind(lfd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(lfd, backlog > 0 ? backlog : 4096) != 0 ||
      hey_epoll_set_nonblocking(lfd) != 0) {
    close(lfd);
    return (HeyNativeHandle)0;
  }
  socklen_t alen = sizeof(addr);
  getsockname(lfd, (struct sockaddr *)&addr, &alen);

  HeyEpollLoop *loop = (HeyEpollLoop *)calloc(1, sizeof(HeyEpollLoop));
  if (!loop) { close(lfd); return (HeyNativeHandle)0; }
  loop->listener = lfd;
  loop->port = ntohs(addr.sin_port);
  loop->scratch = (char *)malloc(HEY_EPOLL_READ_CHUNK);
#if HEY_EPOLL_LINUX
  loop->poller = epoll_create1(EPOLL_CLOEXEC);
#else
  loop->poller = kqueue();
#endif
  if (loop->poller < 0 || !loop->scratch) {
    if (loop->poller >= 0) close(loop->poller);
    close(lfd);
    free(loop->scratch);
    free(loop);
    return (HeyNativeHandle)0;
  }
#if HEY_EPOLL_LINUX
  struct epoll_event ev;
  memset(&ev, 0, sizeof(ev));
  ev.events = EPOLLIN;
  ev.data.fd = lfd;
  epoll_ctl(loop->poller, EPOLL_CTL_ADD, lfd, &ev);
#else
  struct kevent change;
  EV_SET(&change, lfd, EVFILT_READ, EV_ADD, 0, 0, NULL);
  kevent(loop->poller, &change, 1, NULL, 0, NULL);
#endif
  return (HeyNativeHandle)(uintptr_t)loop;
}

int32_t hey_epoll_close(HeyNativeHandle value) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  if (!loop) return -1;
  for (size_t fd = 0; fd < loop->conns_cap; fd++) if (loop->conns[fd].open) hey_epoll_close_fd(loop, (int)fd);
  close(loop->listener);
  close(loop->poller);
  free(loop->conns);
  free(loop->ready);
  free(loop->pending);
  free(loop->scratch);
  free(loop);
  return 0;
}

int32_t hey_epoll_wait(HeyNativeHandle value, int32_t timeout_ms) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  if (!loop) return -1;
  /* Clear the previous batch; anything Hey did not take stays buffered and
     is offered again because its input is still unconsumed. */
  /* Connections of the last batch that Hey did not take (it may stop early to
     bound a batch) are carried into this one; the ones it took wait for new
     input or for a send() that leaves pipelined bytes behind. */
  size_t untaken_from = loop->ready_pos;
  for (size_t i = 0; i < loop->ready_len; i++) {
    int fd = loop->ready[i];
    if ((size_t)fd < loop->conns_cap) loop->conns[fd].queued = 0;
    if (i >= untaken_from && hey_epoll_grow_ints(&loop->pending, &loop->pending_cap, loop->pending_len + 1)) {
      loop->pending[loop->pending_len++] = fd;
    }
  }
  loop->ready_len = loop->ready_pos = 0;
  size_t carried = loop->pending_len;
  for (size_t i = 0; i < carried; i++) {
    int fd = loop->pending[i];
    if ((size_t)fd < loop->conns_cap && loop->conns[fd].open) hey_epoll_mark_ready(loop, fd);
  }
  loop->pending_len = 0;
  int timeout = loop->ready_len ? 0 : timeout_ms;
  loop->waits++;

#if HEY_EPOLL_LINUX
  struct epoll_event events[HEY_EPOLL_MAX_EVENTS];
  int n;
  do { n = epoll_wait(loop->poller, events, HEY_EPOLL_MAX_EVENTS, timeout); } while (n < 0 && errno == EINTR);
  for (int i = 0; i < n; i++) {
    int fd = events[i].data.fd;
    uint32_t e = events[i].events;
    if (fd == loop->listener) { hey_epoll_accept_all(loop); continue; }
    if ((size_t)fd >= loop->conns_cap || !loop->conns[fd].open) continue;
    if (e & EPOLLOUT) { if (!hey_epoll_flush(loop, fd)) continue; }
    if (e & (EPOLLIN | EPOLLRDHUP | EPOLLHUP | EPOLLERR)) {
      if (!hey_epoll_read_all(loop, fd, (e & (EPOLLRDHUP | EPOLLHUP | EPOLLERR)) != 0)) continue;
    }
    hey_epoll_mark_ready(loop, fd);
  }
#else
  struct kevent events[HEY_EPOLL_MAX_EVENTS];
  struct timespec ts, *tsp = NULL;
  if (timeout >= 0) { ts.tv_sec = timeout / 1000; ts.tv_nsec = (long)(timeout % 1000) * 1000000L; tsp = &ts; }
  int n;
  do { n = kevent(loop->poller, NULL, 0, events, HEY_EPOLL_MAX_EVENTS, tsp); } while (n < 0 && errno == EINTR);
  for (int i = 0; i < n; i++) {
    int fd = (int)events[i].ident;
    if (fd == loop->listener) { hey_epoll_accept_all(loop); continue; }
    if ((size_t)fd >= loop->conns_cap || !loop->conns[fd].open) continue;
    if (events[i].filter == EVFILT_WRITE) {
      loop->conns[fd].write_armed = 0;
      if (!hey_epoll_flush(loop, fd)) continue;
    } else if (events[i].filter == EVFILT_READ) {
      if (!hey_epoll_read_all(loop, fd, (events[i].flags & (EV_EOF | EV_ERROR)) != 0)) continue;
    }
    hey_epoll_mark_ready(loop, fd);
  }
#endif
  loop->batches_ready += loop->ready_len;
  return (int32_t)loop->ready_len;
}

int64_t hey_epoll_next(HeyNativeHandle value) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  if (!loop) return -1;
  while (loop->ready_pos < loop->ready_len) {
    int fd = loop->ready[loop->ready_pos++];
    if ((size_t)fd < loop->conns_cap && loop->conns[fd].open && loop->conns[fd].in_len > loop->conns[fd].in_off) {
      return hey_epoll_id(loop, fd);
    }
  }
  return -1;
}

HeyNativeUtf8View hey_epoll_data(HeyNativeHandle value, int64_t id) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  int fd = -1;
  HeyEpollConn *c = hey_epoll_lookup(loop, id, &fd);
  if (!c) return (HeyNativeUtf8View){"", 0};
  const char *start = c->in + c->in_off;
  size_t len = c->in_len - c->in_off;
  int bad = 0;
  size_t ok = hey_epoll_text_prefix((const unsigned char *)start, len, &bad);
  if (bad) {
    loop->invalid_text++;
    hey_epoll_close_fd(loop, fd);
    return (HeyNativeUtf8View){"", 0};
  }
  return (HeyNativeUtf8View){start, ok};
}

int32_t hey_epoll_send(HeyNativeHandle value, int64_t id, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  int fd = -1;
  HeyEpollConn *c = hey_epoll_lookup(loop, id, &fd);
  if (!c) return 0;
  size_t available = c->in_len - c->in_off;
  size_t take = consumed < 0 ? 0 : (size_t)consumed;
  if (take > available) take = available;
  c->in_off += take;
  if (c->in_off == c->in_len) {
    c->in_off = c->in_len = 0;
    if (c->in_cap > 16384) { free(c->in); c->in = NULL; c->in_cap = 0; }
  }
  if (close_after) c->want_close = 1;

  const char *src = data.data;
  size_t len = data.length;
  if (c->out_len == c->out_off && len > 0) {
    /* nothing queued: write straight from the caller's text */
    for (;;) {
      ssize_t n = hey_epoll_write_some(fd, src, len);
      if (n > 0) { loop->bytes_out += (uint64_t)n; src += n; len -= (size_t)n; if (len == 0) break; continue; }
      if (n < 0 && errno == EINTR) continue;
      if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
      hey_epoll_close_fd(loop, fd);
      return 0;
    }
  }
  if (len > 0) {
    loop->partial_writes++;
    if (c->out_off > 0 && c->out_off == c->out_len) c->out_off = c->out_len = 0;
    size_t need = c->out_len + len;
    if (need > c->out_cap) {
      size_t cap = c->out_cap ? c->out_cap : 4096;
      while (cap < need) cap *= 2;
      char *grown = (char *)realloc(c->out, cap);
      if (!grown) { hey_epoll_close_fd(loop, fd); return 0; }
      c->out = grown;
      c->out_cap = cap;
    }
    memcpy(c->out + c->out_len, src, len);
    c->out_len += len;
    if (!hey_epoll_flush(loop, fd)) return 1;   /* closed after the reply, or failed */
  } else if (c->want_close && c->out_len == c->out_off) {
    hey_epoll_close_fd(loop, fd);
    return 1;
  }
  /* Pipelined input after this request: offer it again on the next wait. */
  if (c->open && c->in_len > c->in_off && hey_epoll_grow_ints(&loop->pending, &loop->pending_cap, loop->pending_len + 1)) {
    loop->pending[loop->pending_len++] = fd;
  }
  return 1;
}

int32_t hey_epoll_drop(HeyNativeHandle value, int64_t id) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  int fd = -1;
  if (!hey_epoll_lookup(loop, id, &fd)) return 0;
  hey_epoll_close_fd(loop, fd);
  return 1;
}

int32_t hey_epoll_port(HeyNativeHandle value) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  return loop ? loop->port : -1;
}

HeyNativeUtf8View hey_epoll_stats(HeyNativeHandle value) {
  HeyEpollLoop *loop = hey_epoll_loop(value);
  if (!loop) return (HeyNativeUtf8View){"{}", 2};
  int n = snprintf(loop->stats_text, sizeof(loop->stats_text),
    "{\"backend\":\"%s\",\"live\":%llu,\"accepted\":%llu,\"closed\":%llu,\"waits\":%llu,\"ready\":%llu,"
    "\"bytes_in\":%llu,\"bytes_out\":%llu,\"accept_errors\":%llu,\"oversize\":%llu,\"invalid_text\":%llu,\"partial_writes\":%llu}",
    HEY_EPOLL_BACKEND, (unsigned long long)loop->live, (unsigned long long)loop->accepted, (unsigned long long)loop->closed,
    (unsigned long long)loop->waits, (unsigned long long)loop->batches_ready, (unsigned long long)loop->bytes_in,
    (unsigned long long)loop->bytes_out, (unsigned long long)loop->accept_errors, (unsigned long long)loop->oversize,
    (unsigned long long)loop->invalid_text, (unsigned long long)loop->partial_writes);
  if (n < 0) n = 0;
  if ((size_t)n >= sizeof(loop->stats_text)) n = (int)sizeof(loop->stats_text) - 1;
  return (HeyNativeUtf8View){loop->stats_text, (size_t)n};
}

HeyNativeUtf8View hey_epoll_backend(void) {
  return (HeyNativeUtf8View){HEY_EPOLL_BACKEND, sizeof(HEY_EPOLL_BACKEND) - 1};
}
