#!/usr/bin/env bash
# bin/android-doctor passes on this machine's pinned SDK, and refuses an SDK
# from the old lane (API 34, build-tools 34.0.0, NDK 26.1) with the exact
# sdkmanager line for each missing pin.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
. "$ROOT/tools/android-pins.env"
HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
SDK=${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-doctor.XXXXXX")
trap 'rm -rf "$work"' EXIT

if "$ROOT/bin/android-doctor" --hey-root "$HEY_ROOT" > "$work/real.txt" 2>&1 && grep -q '^android-doctor ok' "$work/real.txt"; then
  echo "PASS: bin/android-doctor passes: platform $HEY_ANDROID_COMPILE_SDK, build-tools $HEY_ANDROID_BUILD_TOOLS, NDK $HEY_ANDROID_NDK, the API $HEY_ANDROID_TARGET_SDK Play image, JDK $HEY_ANDROID_JDK, HEY_ROOT $(sed -n 's/^hey      head=\([^ ]*\) version=\([^ ]*\) compiler_identity=\([^ ]*\).*/\1 \2 \3/p' "$work/real.txt")"
else
  echo 'FAIL: bin/android-doctor does not pass on this machine:'
  sed 's/^/  /' "$work/real.txt"
  failed=1
fi

# An SDK holding only the old lane's packages, linked from the real SDK.
old=$work/sdk-api34
mkdir -p "$old/platforms" "$old/build-tools" "$old/ndk" "$old/system-images"
for keep in platform-tools emulator cmdline-tools licenses; do [ -e "$SDK/$keep" ] && ln -s "$SDK/$keep" "$old/$keep"; done
[ -e "$SDK/platforms/android-34" ] && ln -s "$SDK/platforms/android-34" "$old/platforms/android-34"
[ -e "$SDK/build-tools/34.0.0" ] && ln -s "$SDK/build-tools/34.0.0" "$old/build-tools/34.0.0"
[ -e "$SDK/ndk/26.1.10909125" ] && ln -s "$SDK/ndk/26.1.10909125" "$old/ndk/26.1.10909125"
[ -e "$SDK/system-images/android-34" ] && ln -s "$SDK/system-images/android-34" "$old/system-images/android-34"
if ANDROID_HOME=$old ANDROID_SDK_ROOT=$old "$ROOT/bin/android-doctor" --hey-root "$HEY_ROOT" > "$work/old.txt" 2>&1; then
  echo 'FAIL (control): bin/android-doctor accepted an API 34 / NDK 26.1 SDK'
  failed=1
else
  missing=0
  for pin in "platforms;android-$HEY_ANDROID_COMPILE_SDK" "build-tools;$HEY_ANDROID_BUILD_TOOLS" "ndk;$HEY_ANDROID_NDK" "$HEY_ANDROID_SYSTEM_IMAGE"; do
    grep -F "sdkmanager\" --sdk_root=\"$old\" \"$pin\"" "$work/old.txt" > /dev/null || { echo "  no sdkmanager line for $pin"; missing=1; }
  done
  if [ "$missing" = 0 ]; then
    echo "PASS (control): an API 34 / build-tools 34 / NDK 26.1 SDK is refused, with the sdkmanager line for each of the 4 missing pins"
  else
    echo 'FAIL (control): the refusal did not name every fix'
    sed 's/^/  /' "$work/old.txt"
    failed=1
  fi
fi

if env -u HEY_ROOT "$ROOT/bin/android-doctor" > "$work/noroot.txt" 2>&1; then
  echo 'FAIL (control): bin/android-doctor passed without a named Hey checkout'
  failed=1
elif grep -q 'MISSING  hey_root: no Hey checkout was named' "$work/noroot.txt"; then
  echo 'PASS (control): with no HEY_ROOT named, the doctor fails rather than guessing a checkout'
else
  echo 'FAIL (control): the doctor failed without HEY_ROOT, but not for that reason:'
  sed 's/^/  /' "$work/noroot.txt"
  failed=1
fi
exit $failed
