#!/usr/bin/env bash
# tools/hey-android-api-app.sh: a hey_mobile description, drawn by hey_android's
# native renderer (renderer/), as a signed APK for Android 16 (API 36), and with
# --aab as the Android App Bundle that Google Play takes.
#
#   tools/hey-android-api-app.sh --description FILE --origin URL --package-id ID --label NAME --out DIR
#       [--version-code N] [--version-name TEXT] [--icon PNG]
#       [--release --keystore KS [--key-alias ALIAS]
#            (--keychain-service SERVICE [--keychain-account ACCOUNT] | --keystore-password-env VAR) [--aab]]
#       [--device SERIAL [--launch]]
#
# FILE is the description to bake, byte for byte (a server's
# GET <served path>?platform=android&level=1 answer). URL is the server the app
# talks to, baked with it: https://host[:port], or, for a debug build only,
# http:// to the emulator's host alias 10.0.2.2, 127.0.0.1 or localhost.
#
# PNG is a square launcher icon of at least 432 pixels, resized into the five
# mipmap densities.
#
# --release signs with KS's key ALIAS (default: upload) instead of the debug
# keystore, and the app is not debuggable. The keystore password (also the key
# password) comes from the macOS Keychain, a generic password with service
# SERVICE and account ACCOUNT (default: ALIAS), or from the environment variable
# VAR. It is never an argument and never written to a log or the receipt. A
# release talks only to https. --aab also writes app.aab, validated by the pinned
# bundletool and signed with the same key.
#
# Steps, each checked before the next:
#   1. the pinned build-tools, android-36 platform and JDK 17 (tools/android-pins.env);
#      for a release, the keystore opens and holds ALIAS;
#   2. the renderer's pure classes compile and run on the host, and take FILE as
#      it is (renderer/host BakeCheckMain): no APK ships a copy it would refuse;
#   3. javac --release 17 against android.jar, then d8 --min-api 35: one classes.dex;
#   4. with --icon: sips into mipmap PNGs, aapt2 compile;
#   5. aapt2 link with the manifest template and assets/hey-api (description.json,
#      origin.txt), the dex added, zipalign -P 16, apksigner, apksigner verify;
#      a release is checked not debuggable and signed by the keystore's certificate;
#   6. with --aab: aapt2 link --proto-format into a base module, bundletool
#      build-bundle and validate, jarsigner, and the same checks on the bundle;
#   7. with --device: adb install; with --launch: start the Activity;
#   8. receipt.json in DIR.
#
# No heyc is run, so this tool takes no build lock.
set -euo pipefail
HEY_ANDROID_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
. "$HEY_ANDROID_ROOT/tools/android-env.sh"

usage() { awk 'NR == 1 { next } /^#/ { sub(/^# ?/, ""); print; next } { exit }' "$0"; }
description=''
origin=''
package_id=''
label=''
out=''
version_code=1
version_name=0.1
icon=''
release=false
keystore=''
key_alias=upload
keychain_service=''
keychain_account=''
password_env=''
aab=false
serial=''
launch=false
while [ "$#" -gt 0 ]; do
  case "$1" in
    --description) shift; description=${1:?--description needs a file} ;;
    --origin) shift; origin=${1:?--origin needs a URL} ;;
    --package-id) shift; package_id=${1:?--package-id needs an id} ;;
    --label) shift; label=${1:?--label needs a name} ;;
    --out) shift; out=${1:?--out needs a directory} ;;
    --version-code) shift; version_code=${1:?--version-code needs a number} ;;
    --version-name) shift; version_name=${1:?--version-name needs text} ;;
    --icon) shift; icon=${1:?--icon needs a PNG} ;;
    --release) release=true ;;
    --keystore) shift; keystore=${1:?--keystore needs a file} ;;
    --key-alias) shift; key_alias=${1:?--key-alias needs a name} ;;
    --keychain-service) shift; keychain_service=${1:?--keychain-service needs a name} ;;
    --keychain-account) shift; keychain_account=${1:?--keychain-account needs a name} ;;
    --keystore-password-env) shift; password_env=${1:?--keystore-password-env needs a variable name} ;;
    --aab) aab=true ;;
    --device) shift; serial=${1:?--device needs a serial} ;;
    --launch) launch=true ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
die() { printf 'hey-android-api-app: %s\n' "$*" >&2; exit 1; }
[ -n "$description" ] && [ -f "$description" ] || { echo "--description must name a file (got '$description')" >&2; exit 2; }
[ -n "$out" ] || { echo '--out is required' >&2; exit 2; }
[ -n "$label" ] || { echo '--label is required' >&2; exit 2; }
printf '%s\n' "$package_id" | grep -Eq '^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$' || { echo "--package-id must look like com.example.app (got '$package_id')" >&2; exit 2; }
case "$version_code" in ''|*[!0-9]*) echo '--version-code must be a whole number' >&2; exit 2 ;; esac
[ "${#version_code}" -le 10 ] && [ "$version_code" -ge 1 ] && [ "$version_code" -le 2100000000 ] || { echo '--version-code must be between 1 and 2100000000 (Play refuses larger)' >&2; exit 2; }
if [ "$launch" = true ] && [ -z "$serial" ]; then echo '--launch needs --device SERIAL' >&2; exit 2; fi
if [ "$release" = true ]; then
  [ -n "$keystore" ] && [ -f "$keystore" ] || { echo "--release needs --keystore naming a file (got '$keystore')" >&2; exit 2; }
  if [ -n "$keychain_service" ] && [ -n "$password_env" ]; then echo 'give --keychain-service or --keystore-password-env, not both' >&2; exit 2; fi
  [ -n "$keychain_service" ] || [ -n "$password_env" ] || { echo '--release needs --keychain-service SERVICE or --keystore-password-env VAR' >&2; exit 2; }
  [ -z "$password_env" ] || printf '%s\n' "$password_env" | grep -Eq '^[A-Za-z_][A-Za-z0-9_]*$' || { echo "--keystore-password-env must name a variable (got '$password_env')" >&2; exit 2; }
else
  if [ -n "$keystore$keychain_service$keychain_account$password_env" ]; then
    echo '--keystore, --keychain-service, --keychain-account and --keystore-password-env need --release' >&2; exit 2
  fi
  [ "$aab" = false ] || { echo '--aab needs --release: Play takes no debug bundle' >&2; exit 2; }
fi
if [ -n "$icon" ]; then
  [ -f "$icon" ] || { echo "--icon must name a PNG file (got '$icon')" >&2; exit 2; }
  icon_info=$(/usr/bin/sips -g pixelWidth -g pixelHeight -g format "$icon" 2> /dev/null || true)
  icon_w=$(printf '%s\n' "$icon_info" | awk '/pixelWidth/ { print $2 }')
  icon_h=$(printf '%s\n' "$icon_info" | awk '/pixelHeight/ { print $2 }')
  icon_format=$(printf '%s\n' "$icon_info" | awk '/format/ { print $2 }')
  if [ "$icon_format" != png ] || [ -z "$icon_w" ] || [ "$icon_w" != "$icon_h" ] || [ "$icon_w" -lt 432 ]; then
    echo "--icon must be a square PNG of at least 432 pixels (got ${icon_format:-unreadable} ${icon_w:-?}x${icon_h:-?})" >&2; exit 2
  fi
fi

# The origin: scheme, host and port only. Cleartext only to the emulator's host or loopback, and never in a release.
origin_host=$(printf '%s' "$origin" | sed -nE 's#^https?://([A-Za-z0-9.-]+)(:[0-9]{1,5})?$#\1#p')
[ -n "$origin_host" ] || { echo "--origin must be http(s)://host[:port] with no path (got '$origin')" >&2; exit 2; }
case "$origin" in
  https://*) cleartext=false ;;
  http://*)
    case "$origin_host" in
      10.0.2.2|127.0.0.1|localhost) cleartext=true ;;
      *) echo "--origin: http is allowed only to 10.0.2.2, 127.0.0.1 or localhost; use https for $origin_host" >&2; exit 2 ;;
    esac ;;
esac
if [ "$release" = true ] && [ "$cleartext" = true ]; then echo "--release talks only to https (got '$origin')" >&2; exit 2; fi

description=$(CDPATH= cd -- "$(dirname -- "$description")" && pwd)/$(basename -- "$description")
[ -z "$icon" ] || icon=$(CDPATH= cd -- "$(dirname -- "$icon")" && pwd)/$(basename -- "$icon")
[ -z "$keystore" ] || keystore=$(CDPATH= cd -- "$(dirname -- "$keystore")" && pwd)/$(basename -- "$keystore")
mkdir -p "$out"
out=$(CDPATH= cd -- "$out" && pwd)
if [ -n "$(ls -A "$out")" ] && [ ! -f "$out/.hey-android-api-app" ]; then
  echo "refusing to clear $out: it is not empty and was not made by this tool" >&2
  exit 2
fi
find "$out" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
touch "$out/.hey-android-api-app"
logs=$out/logs
mkdir -p "$logs" "$out/host" "$out/classes" "$out/dex" "$out/assets/hey-api" "$out/apk"

# Read before the environment is reduced; exported only to the signing tools.
if [ "$release" = true ]; then
  if [ -n "$password_env" ]; then
    HEY_ANDROID_KS_PASS=${!password_env:-}
    [ -n "$HEY_ANDROID_KS_PASS" ] || die "the environment variable $password_env is empty"
  else
    HEY_ANDROID_KS_PASS=$(/usr/bin/security find-generic-password -s "$keychain_service" -a "${keychain_account:-$key_alias}" -w 2> /dev/null || true)
    [ -n "$HEY_ANDROID_KS_PASS" ] || die "no Keychain password with service '$keychain_service' and account '${keychain_account:-$key_alias}'"
  fi
  export HEY_ANDROID_KS_PASS
fi

hey_android_isolate
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
java_home=$(hey_android_java_home)
printf '== toolchain\n'
[ -n "$java_home" ] || die "JDK $HEY_ANDROID_JDK not found; run bin/android-doctor"
for tool in aapt2 d8 zipalign apksigner; do [ -x "$bt/$tool" ] || die "build-tools $HEY_ANDROID_BUILD_TOOLS has no $tool; run bin/android-doctor"; done
[ -f "$HEY_ANDROID_PLATFORM_JAR" ] || die "no $HEY_ANDROID_PLATFORM_JAR; run bin/android-doctor"
javac=$java_home/bin/javac
java=$java_home/bin/java
keytool=$java_home/bin/keytool
jarsigner=$java_home/bin/jarsigner
renderer=$HEY_ANDROID_ROOT/renderer
cert_of_keystore() { "$keytool" -list -v -keystore "$keystore" -alias "$key_alias" -storepass:env HEY_ANDROID_KS_PASS 2> /dev/null | sed -n 's/^[[:space:]]*SHA256: //p' | head -1 | tr -d ':' | tr 'A-F' 'a-f' || true; }
keystore_cert=''
if [ "$release" = true ]; then
  keystore_cert=$(cert_of_keystore)
  [ -n "$keystore_cert" ] || die "the keystore $keystore does not open with that password, or holds no key '$key_alias'"
  printf 'release key %s, certificate sha256 %s\n' "$key_alias" "$keystore_cert"
else
  [ -f "$HOME/.android/debug.keystore" ] || die "no debug keystore at $HOME/.android/debug.keystore"
fi
if [ "$aab" = true ]; then
  [ -f "$HEY_ANDROID_BUNDLETOOL_JAR" ] || die "no bundletool at $HEY_ANDROID_BUNDLETOOL_JAR; run bin/android-doctor"
  [ "$(hey_android_sha256 "$HEY_ANDROID_BUNDLETOOL_JAR")" = "$HEY_ANDROID_BUNDLETOOL_SHA256" ] || die "$HEY_ANDROID_BUNDLETOOL_JAR is not the pinned bundletool $HEY_ANDROID_BUNDLETOOL (sha256 differs)"
fi

printf '== the description, checked by the renderer on the host\n'
find "$renderer/java" "$renderer/host" -name '*.java' | sort > "$logs/host-sources.txt"
"$javac" --release 17 -d "$out/host" @"$logs/host-sources.txt" > "$logs/javac-host.log" 2>&1 || { cat "$logs/javac-host.log" >&2; die 'the renderer does not compile on the host'; }
if ! bake=$("$java" -cp "$out/host" hey.android.api.BakeCheckMain "$description" 2> "$logs/bake-check.err"); then
  die "the renderer refuses this description: $bake $(cat "$logs/bake-check.err")"
fi
printf '%s\n' "$bake"
case "$bake" in *' drawn_tabs=0 '*) die "the renderer draws none of this description's tabs: $bake" ;; esac

printf '== javac and d8\n'
find "$renderer/java" "$renderer/android" -name '*.java' | sort > "$logs/sources.txt"
"$javac" --release 17 -Xlint:-options -classpath "$HEY_ANDROID_PLATFORM_JAR" -d "$out/classes" @"$logs/sources.txt" > "$logs/javac.log" 2>&1 || { cat "$logs/javac.log" >&2; die 'javac failed'; }
find "$out/classes" -name '*.class' | sort > "$logs/classes.txt"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/d8" --min-api "$HEY_ANDROID_MIN_SDK" --lib "$HEY_ANDROID_PLATFORM_JAR" --output "$out/dex" @"$logs/classes.txt" > "$logs/d8.log" 2>&1 || { cat "$logs/d8.log" >&2; die 'd8 failed'; }
[ -f "$out/dex/classes.dex" ] || die 'd8 wrote no classes.dex'

# WHAT MAKES THIS A MEDIA APP TO A CAR. Always written, never optional: a head
# unit reads this resource to decide whether to list the app at all, and an app
# that plays audio but is invisible in a car is a bug with no error message.
mkdir -p "$out/res/xml"
cat > "$out/res/xml/automotive_app_desc.xml" <<'CARXML'
<?xml version="1.0" encoding="utf-8"?>
<automotiveApp>
  <uses name="media"/>
</automotiveApp>
CARXML
icon_attr=''
if [ -n "$icon" ]; then
  printf '== launcher icon\n'
  for density in mdpi:48 hdpi:72 xhdpi:96 xxhdpi:144 xxxhdpi:192; do
    dir=$out/res/mipmap-${density%%:*}
    size=${density#*:}
    mkdir -p "$dir"
    /usr/bin/sips -s format png -z "$size" "$size" "$icon" --out "$dir/ic_launcher.png" >> "$logs/sips.log" 2>&1 || { cat "$logs/sips.log" >&2; die 'sips could not resize the icon'; }
  done
  icon_attr='android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher" '
fi
# Compiled from inside DIR with a relative path: aapt2 keeps each file's source path in
# the bundle's resources.pb, and an absolute one would carry this Mac's home directory.
(cd "$out" && "$bt/aapt2" compile --dir res -o res.zip) > "$logs/aapt2-compile.log" 2>&1 || { cat "$logs/aapt2-compile.log" >&2; die 'aapt2 compile failed'; }
res_flags=(-R "$out/res.zip")

printf '== aapt2, zipalign, apksigner\n'
cp "$description" "$out/assets/hey-api/description.json"
printf '%s' "$origin" > "$out/assets/hey-api/origin.txt"
esc() { printf '%s' "$1" | sed -e 's/[&/\]/\\&/g' -e 's/"/\&quot;/g' -e 's/</\&lt;/g'; }
sed -e "s/@PACKAGE_ID@/$package_id/" -e "s/@VERSION_CODE@/$version_code/" -e "s/@VERSION_NAME@/$(esc "$version_name")/" \
  -e "s/@MIN_SDK@/$HEY_ANDROID_MIN_SDK/" -e "s/@TARGET_SDK@/$HEY_ANDROID_TARGET_SDK/" -e "s/@LABEL@/$(esc "$label")/" \
  -e "s/@CLEARTEXT@/$cleartext/" -e "s#@ICON@#$icon_attr#" "$renderer/android/AndroidManifest.xml.in" > "$out/apk/AndroidManifest.xml"
link_flags=(--manifest "$out/apk/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -A "$out/assets" ${res_flags[@]+"${res_flags[@]}"})
[ "$release" = true ] || link_flags+=(--debug-mode)
"$bt/aapt2" link "${link_flags[@]}" -o "$out/apk/base.apk" > "$logs/aapt2.log" 2>&1 || { cat "$logs/aapt2.log" >&2; die 'aapt2 link failed'; }
(cd "$out/dex" && /usr/bin/zip -q -X "$out/apk/base.apk" classes.dex) || die 'adding classes.dex failed'
"$bt/zipalign" -P 16 -f 4 "$out/apk/base.apk" "$out/apk/aligned.apk" > "$logs/zipalign.log" 2>&1 || { cat "$logs/zipalign.log" >&2; die 'zipalign failed'; }
if [ "$release" = true ]; then
  sign_flags=(--ks "$keystore" --ks-key-alias "$key_alias" --ks-pass env:HEY_ANDROID_KS_PASS --key-pass env:HEY_ANDROID_KS_PASS)
else
  sign_flags=(--ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android)
fi
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" sign "${sign_flags[@]}" --v4-signing-enabled false \
  --out "$out/app.apk" "$out/apk/aligned.apk" > "$logs/apksigner.log" 2>&1 || { cat "$logs/apksigner.log" >&2; die 'apksigner failed'; }
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" verify --verbose --print-certs "$out/app.apk" > "$logs/verify.log" 2>&1 || { cat "$logs/verify.log" >&2; die 'apksigner verify failed'; }
apk_cert=$(sed -n 's/^Signer #1 certificate SHA-256 digest: //p' "$logs/verify.log" | head -1)
[ -n "$apk_cert" ] || die 'apksigner named no signer certificate'
"$bt/zipalign" -c -P 16 -v 4 "$out/app.apk" > "$logs/zipalign-check.log" 2>&1 || die 'the signed APK is not aligned'
"$bt/aapt2" dump badging "$out/app.apk" > "$logs/badging.txt" 2>&1 || die 'aapt2 dump badging failed'
grep -q "targetSdkVersion:'$HEY_ANDROID_TARGET_SDK'" "$logs/badging.txt" || die "the APK does not target API $HEY_ANDROID_TARGET_SDK"
grep -q "versionCode='$version_code'" "$logs/badging.txt" || die "the APK's version code is not $version_code"
if [ -n "$icon" ] && ! grep -q "^application-icon-" "$logs/badging.txt"; then die 'the APK has no launcher icon'; fi
if [ "$release" = true ]; then
  if grep -q 'application-debuggable' "$logs/badging.txt"; then die 'the release APK is debuggable'; fi
  [ "$apk_cert" = "$keystore_cert" ] || die "the APK is signed by $apk_cert, not by the keystore's $keystore_cert"
fi
apk_sha=$(hey_android_sha256 "$out/app.apk")
printf 'apk %s sha256=%s bytes=%s\n' "$out/app.apk" "$apk_sha" "$(wc -c < "$out/app.apk" | tr -d ' ')"

aab_sha=''
if [ "$aab" = true ]; then
  printf '== app bundle\n'
  b=$out/bundle
  mkdir -p "$b/proto" "$b/base/manifest" "$b/base/dex"
  proto_flags=(--proto-format --manifest "$out/apk/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -A "$out/assets" ${res_flags[@]+"${res_flags[@]}"})
  "$bt/aapt2" link "${proto_flags[@]}" -o "$b/proto.apk" > "$logs/aapt2-proto.log" 2>&1 || { cat "$logs/aapt2-proto.log" >&2; die 'aapt2 link --proto-format failed'; }
  (cd "$b/proto" && /usr/bin/unzip -q "$b/proto.apk") || die 'could not unpack the proto APK'
  mv "$b/proto/AndroidManifest.xml" "$b/base/manifest/AndroidManifest.xml"
  for part in resources.pb res assets; do
    if [ -e "$b/proto/$part" ]; then mv "$b/proto/$part" "$b/base/$part"; fi
  done
  cp "$out/dex/classes.dex" "$b/base/dex/classes.dex"
  (cd "$b/base" && /usr/bin/zip -q -r -X -D "$b/base.zip" .) || die 'could not zip the base module'
  bundletool() { env JAVA_HOME="$java_home" "$java" -jar "$HEY_ANDROID_BUNDLETOOL_JAR" "$@"; }
  bundletool build-bundle --modules="$b/base.zip" --output="$b/unsigned.aab" > "$logs/bundletool-build.log" 2>&1 || { cat "$logs/bundletool-build.log" >&2; die 'bundletool build-bundle failed'; }
  bundletool validate --bundle="$b/unsigned.aab" > "$logs/bundletool-validate.log" 2>&1 || { cat "$logs/bundletool-validate.log" >&2; die 'bundletool validate refused the bundle'; }
  "$jarsigner" -keystore "$keystore" -storepass:env HEY_ANDROID_KS_PASS -keypass:env HEY_ANDROID_KS_PASS -sigalg SHA256withRSA -digestalg SHA-256 \
    -signedjar "$out/app.aab" "$b/unsigned.aab" "$key_alias" > "$logs/jarsigner.log" 2>&1 || { cat "$logs/jarsigner.log" >&2; die 'jarsigner failed'; }
  "$jarsigner" -verify "$out/app.aab" > "$logs/jarsigner-verify.log" 2>&1 && grep -q 'jar verified' "$logs/jarsigner-verify.log" || { cat "$logs/jarsigner-verify.log" >&2; die 'jarsigner could not verify the bundle'; }
  aab_cert=$("$keytool" -printcert -jarfile "$out/app.aab" 2> /dev/null | sed -n 's/^[[:space:]]*SHA256: //p' | head -1 | tr -d ':' | tr 'A-F' 'a-f' || true)
  [ "$aab_cert" = "$keystore_cert" ] || die "the bundle is signed by '$aab_cert', not by the keystore's $keystore_cert"
  bundletool validate --bundle="$out/app.aab" > "$logs/bundletool-validate-signed.log" 2>&1 || { cat "$logs/bundletool-validate-signed.log" >&2; die 'bundletool validate refused the signed bundle'; }
  bundletool dump manifest --bundle="$out/app.aab" > "$logs/aab-manifest.xml" 2>&1 || { cat "$logs/aab-manifest.xml" >&2; die 'bundletool dump manifest failed'; }
  grep -q "package=\"$package_id\"" "$logs/aab-manifest.xml" || die "the bundle's package is not $package_id"
  grep -q "android:versionCode=\"$version_code\"" "$logs/aab-manifest.xml" || die "the bundle's version code is not $version_code"
  grep -q "android:targetSdkVersion=\"$HEY_ANDROID_TARGET_SDK\"" "$logs/aab-manifest.xml" || die "the bundle does not target API $HEY_ANDROID_TARGET_SDK"
  if grep -q 'android:debuggable="true"' "$logs/aab-manifest.xml"; then die 'the bundle is debuggable'; fi
  for built in "$out/app.apk" "$out/app.aab"; do
    if /usr/bin/unzip -p "$built" | LC_ALL=C grep -aqF -e "$out" -e "$HOME/"; then die "$(basename "$built") holds a path of this Mac ($out or $HOME)"; fi
  done
  aab_sha=$(hey_android_sha256 "$out/app.aab")
  printf 'aab %s sha256=%s bytes=%s\n' "$out/app.aab" "$aab_sha" "$(wc -c < "$out/app.aab" | tr -d ' ')"
fi

installed=false
launched=false
if [ -n "$serial" ]; then
  printf '== install on %s\n' "$serial"
  "$HEY_ANDROID_ADB" -s "$serial" install -r "$out/app.apk" > "$logs/install.log" 2>&1 || { cat "$logs/install.log" >&2; die 'adb install failed'; }
  installed=true
  if [ "$launch" = true ]; then
    "$HEY_ANDROID_ADB" -s "$serial" shell am start -W -n "$package_id/hey.android.api.HeyAndroidApiActivity" > "$logs/launch.log" 2>&1 || { cat "$logs/launch.log" >&2; die 'am start failed'; }
    grep -q 'Status: ok' "$logs/launch.log" || { cat "$logs/launch.log" >&2; die 'the Activity did not start'; }
    launched=true
  fi
fi

R_OUT=$out R_BAKE=$bake R_DESC=$description R_ORIGIN=$origin R_CLEAR=$cleartext R_PKG=$package_id R_LABEL=$label \
R_VC=$version_code R_VN=$version_name R_APK_SHA=$apk_sha R_DEX_SHA=$(hey_android_sha256 "$out/dex/classes.dex") \
R_VERSION=$HEY_ANDROID_VERSION R_SERIAL=$serial R_INSTALLED=$installed R_LAUNCHED=$launched R_TARGET=$HEY_ANDROID_TARGET_SDK R_MIN=$HEY_ANDROID_MIN_SDK \
R_RELEASE=$release R_CERT=$apk_cert R_ICON=$([ -n "$icon" ] && echo true || echo false) R_AAB=$aab R_AAB_SHA=$aab_sha \
R_BUNDLETOOL=$HEY_ANDROID_BUNDLETOOL R_ALIAS=$([ "$release" = true ] && printf '%s' "$key_alias" || printf androiddebugkey) \
/usr/bin/python3 - <<'PY'
import json, os
e = os.environ.get
bake = dict(p.split("=", 1) for p in e("R_BAKE").split()[1:])
out = e("R_OUT")
release = e("R_RELEASE") == "true"
receipt = {
  "kind": "hey-android-api-app-v1",
  "hey_android_version": e("R_VERSION"),
  "renderer": {"platform": "android", "level": 1, "language": "java", "sources": "renderer/java, renderer/android"},
  "description": {"file": e("R_DESC"), "sha256": bake["sha256"], "level": int(bake["level"]), "platform": bake["platform"],
                  "screens": int(bake["screens"]), "tabs": int(bake["tabs"]), "drawn_tabs": int(bake["drawn_tabs"]),
                  "sign_in_screen": bake["sign_in"], "served_path": bake.get("served", "")},
  "origin": e("R_ORIGIN"), "cleartext": e("R_CLEAR") == "true",
  "apk": {"file": "app.apk", "sha256": e("R_APK_SHA"), "bytes": os.path.getsize(os.path.join(out, "app.apk")),
          "package_id": e("R_PKG"), "label": e("R_LABEL"), "version_code": int(e("R_VC")), "version_name": e("R_VN"),
          "classes_dex_sha256": e("R_DEX_SHA"), "min_sdk": int(e("R_MIN")), "target_sdk": int(e("R_TARGET")),
          "signing": "release" if release else "debug", "debuggable": not release, "key_alias": e("R_ALIAS"),
          "certificate_sha256": e("R_CERT"), "icon": e("R_ICON") == "true", "zipalign_16k": True},
  "bundle": None if e("R_AAB") != "true" else {
          "file": "app.aab", "sha256": e("R_AAB_SHA"), "bytes": os.path.getsize(os.path.join(out, "app.aab")),
          "bundletool": e("R_BUNDLETOOL"), "validated": True, "certificate_sha256": e("R_CERT")},
  "device": {"serial": e("R_SERIAL") or None, "installed": e("R_INSTALLED") == "true", "launched": e("R_LAUNCHED") == "true"},
}
with open(os.path.join(out, "receipt.json"), "w") as f:
    json.dump(receipt, f, indent=2)
    f.write("\n")
PY
printf 'receipt %s/receipt.json\n' "$out"
