# hey_i18n

Reusable Hey localization/internationalization package for server, web-shared logic, iOS, Android and other Hey targets.

## Status

**AUTHORITATIVE EVOLUTION CONTRACT.** Preserve the existing `hey_i18n` v0.1.x implementation and history. Extend that package to satisfy this contract; do not replace it with a parallel implementation or reset its repository lineage. Use current Hey package/native tooling at release time.

## Goals

- One localization contract across MMeoww website and native apps.
- Locale-aware messages without putting learner-facing copy into business logic.
- Deterministic fallback and complete missing-key diagnostics.
- First-class plural/select formatting, number/date/time formatting, RTL metadata and localized resources.
- Domain Packs may ship locale-specific instructional content without changing application code.

## Required public modules

### `I18n.Locale`

- parse/canonicalize BCP 47 locale identifiers
- expose language/script/region where present
- negotiate requested locales against supported locales
- deterministic fallback chain, e.g. `zh-Hant-TW -> zh-Hant -> zh -> default`
- never silently substitute an unrelated language

### `I18n.Messages`

- load compiled message catalogs by locale/namespace
- `t(key, values: {}, locale:)`
- plural/select rules using CLDR-compatible semantics
- interpolation escapes/validates values according to output surface
- missing key produces structured telemetry and configured fallback; developer/test mode can fail hard

### `I18n.Format`

- decimal/percent/currency formatting
- date/time/duration formatting
- timezone-aware presentation
- list formatting
- relative-time formatting
- platform/native adapters may use ICU/CLDR-backed facilities, but the Hey public contract stays target-neutral

### `I18n.Direction`

- locale text direction metadata (`ltr`/`rtl`)
- logical start/end rather than hard-coded left/right guidance
- bidi-safe interpolation requirements for mixed-direction identifiers/numbers

### `I18n.Resources`

- localized asset selection (images/audio/captions/alt text)
- deterministic fallback
- accessibility labels and captions are localized resources, not afterthoughts

## Catalog format

Use a machine-readable source format compiled during build. Catalog entries have stable semantic keys, not English sentences as identifiers. Namespaces should follow product ownership, for example:

- `shell.*`
- `today.*`
- `progress.*`
- `mistakes.*`
- `diagnostic.*`
- `lesson.*`
- `practice.*`
- `simulation.*`
- `companion.*`
- `notifications.*`
- `billing.*`
- `settings.*`
- `accessibility.*`

Domain Pack localized instructional content remains in the Domain Pack and references canonical content/objective IDs.

## Source-language and fallback policy

- Canonical source locale: `en-US` unless product explicitly changes it.
- Every production locale must pass key coverage validation for required namespaces.
- Missing translations never mutate educational meaning or mastery criteria.
- Legal/safety/consent copy can be marked `must_translate`; release fails if absent for an enabled locale.

## Web/native integration

- Hey owns locale preference, negotiation, keys/catalog contracts and formatting semantics.
- UI renderers receive already-resolved strings/format instructions where practical.
- Native Hey iOS/Android packages bridge ICU/platform formatting and accessibility APIs where required; no Swift/Objective-C product source is introduced.
- Browser-specific layout can still respond to `dir=rtl`, locale and formatted values.

## Learner locale model

Store separately:

- account UI locale
- instructional/content locale
- preferred explanation language(s)
- timezone
- number/date formatting locale if explicitly overridden

Do not assume the language a learner wants for UI is always the language they want instructional content in.

## AI localization rules

AI may translate or adapt learner-facing explanations only when the role contract permits it. Generated translation is not automatically canonical catalog content. Canonical UI/legal/safety translations require review/provenance. AI prompts include requested language/locale but not unnecessary identity information.

## Testing

- preserve all existing v0.1.x behavior and compiled-lane receipts
- BCP 47 parsing/canonicalization
- fallback/negotiation
- plural categories across representative languages
- RTL rendering metadata
- number/currency/date/time/timezone boundaries
- missing key behavior
- placeholder mismatches
- catalog completeness
- pseudolocalization expansion/accent mode
- very long strings
- CJK/Arabic/Hebrew/Devanagari/Latin examples
- accessibility labels and screen-reader strings
- locale switching without corrupting app state

## MMeoww requirement

All user-visible application copy, notifications, accessibility labels and locale-sensitive formatting must go through this package or Domain Pack localization contracts. Product modules must not scatter hard-coded English strings.
