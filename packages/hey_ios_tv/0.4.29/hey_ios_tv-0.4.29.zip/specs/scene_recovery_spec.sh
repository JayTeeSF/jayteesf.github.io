#!/usr/bin/env sh
# Runs the production legacy fetch/timer/recovery methods in a Foundation host
# against a local HTTP fixture. UIKit drawing is represented by its title only.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
RUNTIME="${1:-$ROOT/tools/hey_native_tv_runtime.m}"
WORK="$(mktemp -d)"
pid=''
cleanup(){ [ -z "$pid" ] || kill "$pid" 2>/dev/null || true; rm -rf "$WORK"; }
trap cleanup EXIT HUP INT TERM
cat > "$WORK/server.rb" <<'RUBY'
require 'socket'
require 'json'
server=TCPServer.new('127.0.0.1',0)
port=server.addr[1]
File.write(ARGV.fetch(0),port.to_s)
attempts=0
loop do
  socket=server.accept
  while (line=socket.gets) && line!="\r\n"; end
  attempts+=1
  body=if attempts==1
    '{"schema":'
  else
    JSON.generate({schema:'hey-tv-scene-v2',widgets:[{kind:'text',text:'Recovered'}],fetch:{id:'test',url:"http://127.0.0.1:#{port}/sequence",mode:'scene',ms:250}})
  end
  socket.write("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: #{body.bytesize}\r\nConnection: close\r\n\r\n#{body}")
  socket.close
end
RUBY
ruby "$WORK/server.rb" "$WORK/port" >"$WORK/server.log" 2>&1 &
pid=$!
i=0
until [ -s "$WORK/port" ]; do i=$((i+1)); [ "$i" -lt 40 ] || { cat "$WORK/server.log"; exit 1; }; sleep 0.05; done
ruby - "$RUNTIME" "$WORK/recovery.m" <<'RUBY'
source=File.read(ARGV.fetch(0))
names=%w[parsedScene syncLiveDataWithScene onLiveDataTimer startFetch fetchUrlInScene noteFailedScenePoll]
methods=names.map do |name|
  match=source.match(/^- \([^\n]+\)#{name}(?=[: {])[^\n]*\n.*?^\}/m)
  abort "missing production method #{name}" unless match
  match[0]
end
header=<<~'OBJC'
#import <Foundation/Foundation.h>
#if __has_include("hey_tv_scene_poll.h")
#import "hey_tv_scene_poll.h"
#endif
static const NSInteger kHeySceneFetchFailureLimit=5;
static NSString *HeyScreenModeName(NSInteger mode) { (void)mode; return @"auto"; }
static void expect(BOOL ok, NSString *label) { if (!ok) { fprintf(stderr,"FAIL %s\n",label.UTF8String); exit(1); } printf("PASS %s\n",label.UTF8String); }
@interface RecoveryHost : NSObject
@property(copy,nonatomic) NSString *sceneJson;
@property(copy,nonatomic) NSString *bootstrapFetchUrl;
@property(copy,nonatomic) NSString *pollSignature;
@property(strong,nonatomic) NSTimer *pollTimer;
@property(strong,nonatomic) NSURLSessionDataTask *sceneTask;
@property(nonatomic) BOOL fetchInFlight;
@property(nonatomic) double lastPressAt;
@property(nonatomic) NSInteger consecutiveFetchFailures;
@property(nonatomic) NSInteger screenMode;
@property(nonatomic) NSInteger renderCount;
@property(copy,nonatomic) NSString *displayedTitle;
@property(strong,nonatomic) id scenePoll;
@property(nonatomic) double scenePollBaseInterval;
@property(nonatomic) BOOL bundledUI;
@property(nonatomic) NSUInteger modelFetchFailures;
@property(nonatomic) NSTimeInterval nextModelFetchAt;
- (NSDictionary *)parsedScene;
- (void)syncLiveDataWithScene:(NSDictionary *)scene;
- (void)onLiveDataTimer;
- (void)startFetch:(NSDictionary *)fetch;
- (NSString *)fetchUrlInScene:(NSDictionary *)scene;
- (void)noteFailedScenePoll;
@end
@implementation RecoveryHost
- (NSString *)installedSchemes { return @""; }
- (void)stepWithEvent:(NSString *)event { (void)event; }
- (void)startModelFetch:(NSDictionary *)fetch { (void)fetch; }
- (void)renderScene {
  self.renderCount++;
  NSDictionary *scene=[self parsedScene];
  NSArray *widgets=[scene[@"widgets"] isKindOfClass:NSArray.class] ? scene[@"widgets"] : @[];
  self.displayedTitle=widgets.count ? widgets[0][@"text"] : @"";
  [self syncLiveDataWithScene:scene];
}
OBJC
footer=<<~'OBJC'
@end
static BOOL until(BOOL (^condition)(void), double seconds) {
  double end=NSDate.timeIntervalSinceReferenceDate+seconds;
  while (!condition() && NSDate.timeIntervalSinceReferenceDate<end) {
    [NSRunLoop.currentRunLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:0.02]];
  }
  return condition();
}
int main(int argc, char **argv) { @autoreleasepool {
  expect(argc==2,@"local fixture port supplied");
  NSString *url=[NSString stringWithFormat:@"http://127.0.0.1:%s/sequence",argv[1]];
  NSDictionary *initial=@{@"schema":@"hey-tv-scene-v2",@"widgets":@[@{@"kind":@"text",@"text":@"Last good"}],@"fetch":@{@"id":@"test",@"url":url,@"mode":@"scene",@"ms":@250}};
  RecoveryHost *host=[RecoveryHost new];
  host.sceneJson=[[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:initial options:0 error:NULL] encoding:NSUTF8StringEncoding];
  NSString *lastGood=host.sceneJson;
  host.bootstrapFetchUrl=url;
  [host renderScene];
  [host startFetch:initial[@"fetch"]];
  expect(until(^BOOL { return host.consecutiveFetchFailures>0 || host.renderCount>1; },3),@"malformed HTTP200 completed");
  printf("observed rejected-response state: renders=%ld titleLength=%lu pollActive=%d\n",(long)host.renderCount,(unsigned long)host.displayedTitle.length,(int)host.pollTimer.isValid);
  expect([host.sceneJson isEqual:lastGood] && [host.displayedTitle isEqual:@"Last good"] && host.renderCount==1,@"malformed HTTP200 cannot replace or blank last-good scene");
  expect(host.pollTimer.isValid,@"rejected payload keeps the actual poll timer alive");
  expect(until(^BOOL { return [host.displayedTitle isEqual:@"Recovered"]; },5),@"later valid HTTP200 recovers without relaunch");
  expect(host.pollTimer.isValid && host.consecutiveFetchFailures==0,@"successful recovery keeps polling and resets fallback streak");
  [host.pollTimer invalidate];
#if __has_include("hey_tv_scene_poll.h")
  RecoveryHost *fallback=[RecoveryHost new];
  NSMutableDictionary *room=[initial mutableCopy];
  room[@"fetch"]=@{@"url":[url stringByAppendingString:@"/expired-room"],@"mode":@"scene",@"ms":@250};
  fallback.sceneJson=[[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:room options:0 error:NULL] encoding:NSUTF8StringEncoding];
  fallback.bootstrapFetchUrl=url;
  [fallback renderScene];
  HeyTVScenePoll *policy=[HeyTVScenePoll new];
  for (int i=0;i<5;i++) { [policy acceptBody:@"{" status:200 transportError:NO at:100 baseInterval:2]; }
  fallback.scenePoll=policy;
  fallback.consecutiveFetchFailures=4;
  double retry=policy.retryAt;
  [fallback noteFailedScenePoll];
  expect([[fallback fetchUrlInScene:[fallback parsedScene]] isEqual:url] && [fallback.displayedTitle isEqual:@"Last good"],@"bootstrap recovery changes only the fetch target and preserves valid widgets");
  expect(policy.failures==5 && policy.retryAt==retry && fallback.pollTimer.isValid,@"bootstrap URL change preserves outage backoff and poll timer");
  [fallback.pollTimer invalidate];
#endif
  puts("legacy scene HTTP recovery spec passed");
} return 0; }
OBJC
File.write(ARGV.fetch(1),header+methods.join("\n\n")+"\n"+footer)
RUBY
clang -fobjc-arc -Wno-unused-variable -framework Foundation -I "$ROOT/tools" "$WORK/recovery.m" -o "$WORK/recovery"
"$WORK/recovery" "$(cat "$WORK/port")"
