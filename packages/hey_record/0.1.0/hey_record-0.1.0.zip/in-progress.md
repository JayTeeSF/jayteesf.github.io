# In progress

0.1.0 core is implemented and verified with fake adapter callables. The packed release passes clean installation, lockfile pinning, installed-hash verification, and compiled `pkg:hey_record@0.1.0/main` import. Live SQLite/MySQL integration receipts remain external.
