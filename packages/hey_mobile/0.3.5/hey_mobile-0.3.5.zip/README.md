# hey_mobile

Cross-platform application primitives for ordinary Hey mobile apps. It owns lifecycle state transitions, platform-neutral screen/action/accessibility descriptions, QR/server enrollment payload validation, and development-vs-release transport policy. It does not own UIKit, Android Views/Compose, cryptographic keys, product screens, business data, signing, installation, or deployment.

`hey_mobile` is the interface layer above independently versioned `hey_ios` and future `hey_android` adapters. The CLI porcelain remains in the Hey language repository (`hey mobile ios ...`, `hey mobile android ...`).

## Header artwork links (0.3.5)

Headers may bind `image_open_url` beside `image`. Supporting renderers open the
HTTP(S) content URL when the artwork is tapped and expose it as an accessible
link. Missing or unsafe URLs stay inert; older renderers ignore the optional
field. See `docs/RENDERERS.md`.

## Searchable multi-choice without losing selections (0.3.4)

- **`choices.search` on `choose_many`.** A large chooser may load a bounded useful first page, then search the same option space remotely. Search uses the parent `list/value/label/where` mapping, so an app names that schema once.
- **Selections survive search.** `HeyMobileValues.merge_options(existing, found)` keeps existing option order/title and appends only unseen values. The level-3 conformance vectors compose that merge with `chosen`, proving a ticked value remains in `$values` after new search results arrive.
- **Capability discovery.** `routes()` lists the nested search route as well as the initial choices route and the action request.
- **Older renderers are unchanged.** This is an optional level-3 behavior; an app can continue to write `min_level: 3` plus a single-choice `instead`.

## A row template's action is a route (0.3.3)

- **`routes()` walks a data-driven row.** A section lists its rows two ways: `rows` is literal, and `source` plus `row` draws that one row for every record the source returns. Both draw an `action` on the row and both renderers fire it; only the literal branch was collected, so any route reachable from a data-driven row was missing from the list. A section's `row.badge.source` is collected now too, for the same reason.
- **Why it matters.** `routes()` is how a host learns which addresses an app actually reaches. A host checking whether its phone can do what its web can was told a working on/off switch was absent from the app, which is worse than a plain yes or no: it sends somebody looking for a bug that is not in their code.
- **Spec.** `specs/api_screens_spec.hey` builds a switches section the way such a screen is really built and asserts the action's route is listed, with the section's own source asserted beside it so it cannot pass vacuously, and a control where the same template carries no action and no route appears.

## Level 3: choosing several, offers, and audio with no credential (0.3.2)

- **`choose_many`**, an action with the same `choices` or `options` as `choose`: the viewer ticks several and presses Done, and what follows sends `$values` (a list) and can say `{value_titles}`.
- **`offers`** on a form's `lookup`, beside `fills`: what the lookup found, shown under a field the viewer typed something else in and taken with one tap.
- **Fitting.** `HeyMobileLevels.current()` is 3. Below level 3, `for_level` removes every `choose_many` (write `min_level: 3` and an `instead` holding a `choose`, so an older renderer keeps its single choice) and removes `offers` from every lookup. A description with nothing of level 3 in it is the level-2 answer said as level 3; a renderer asks for its own level, so a level-2 renderer is served exactly what it was before.
- **Vectors.** `conformance/level3.json`: description vectors for a level-3 renderer, value vectors for `chosen` and `offers` (the reference is `values.hey`), and fitting vectors for servers, each with negative cases. `descriptions.json`, `values.json` and `names.json` are unchanged, so a level-2 renderer's harness passes as before.
- **`audio.sign`**, a route whose body reads `$url`: a renderer exchanges an audio address on the app's own server for a short-lived one that needs no request header (`docs/RENDERERS.md`). `routes()` lists it.

## Screens bound to JSON routes (`api_screens`, 0.2.0)

`api_screens.hey` (module `HeyMobileApiScreens`) describes a whole app in ordinary Hey: every screen, the route that feeds it, which response fields a row shows, and exactly what each button, form and row action sends. A native host executes the description (`hey_ios` 0.2.0 ships `native/HeyIOSApiHost` for iOS); the host holds no product knowledge, so one description serves every platform.

```hey
import 'pkg:hey_mobile@0.3.0/api_screens'

let row = {title: 'title'}
let library = HeyMobileApiScreens.list_screen('library', 'Library', HeyMobileApiScreens.tab('Library', 'books.vertical'),
  [HeyMobileApiScreens.section('Recent', HeyMobileApiScreens.route('GET', '/v1/items', nil), 'items', row, nil, 'Nothing saved yet')])
let signin = HeyMobileApiScreens.form_screen('signin', 'Sign in', nil, [HeyMobileApiScreens.field('username', 'Name', 'text', true)],
  {title: 'Sign in', request: HeyMobileApiScreens.route('POST', '/v1/session', {username: '$username'})})
let session = {sign_in_screen: 'signin', check: HeyMobileApiScreens.route('GET', '/v1/session', nil), sign_out: HeyMobileApiScreens.route('POST', '/v1/session/revoke', {})}
let app = {schema: HeyMobileApiScreens.schema_version(), tabs: ['library'], session: session, screens: [library, signin]}
HeyMobileApiScreens.problems(app)   # [] when every tab, select and path is sound
HeyMobileApiScreens.routes(app)     # every route the app calls, for a server-side contract check
```

`problems` names each fault (a tab naming no screen, a relative path, a dangling select); `routes` lists every route a description can call, from sections, actions, menus, row actions, forms, audio position reports and the share extension.

## Levels, served descriptions and conformance (0.3.0)

A renderer declares a level, the highest level of the contract it draws, and a server answers `HeyMobileLevels.for_level(app, platform, level)`: the description with anything that level cannot draw removed and spelled for it. Level 2 names icons and file kinds for any platform (`icons.hey`) and requires a renderer to hide every kind it does not know, never sending a request for an action it does not recognise. `values.hey` is the reference evaluator for the value language and `conformance/` holds the vectors every renderer must pass. The rules a renderer keeps, and how a served copy, a stored copy and the baked copy take turns, are in `docs/RENDERERS.md`.

```hey
import 'pkg:hey_mobile@0.3.0/levels'

let answer = HeyMobileLevels.for_level(app, 'ios', 2)
HeyMobileLevels.problems_for_level(answer, 2)   # [] when level 2 can draw all of it
```

## Check and release

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
bin/release
```

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_mobile`.
