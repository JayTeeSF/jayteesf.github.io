#!/usr/bin/env bash
# Real chooser payload and private artwork stream on a disposable API 36 AVD.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-share.XXXXXX")
evidence=${HEY_ANDROID_SHARE_EVIDENCE:-}
mkdir -p "$work"
java_home=$(hey_android_java_home)
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
adb=$HEY_ANDROID_ADB
emulator_pid=''
serial=emulator-5592
export ANDROID_AVD_HOME="$work/avds"
mkdir -p "$ANDROID_AVD_HOME"
cleanup() {
  status=$?
  if [ -n "$emulator_pid" ]; then
    if [ -n "$evidence" ]; then "$adb" -s "$serial" logcat -d -v threadtime > "$work/device.log" 2>&1 || true; fi
    "$adb" -s "$serial" emu kill >/dev/null 2>&1 || true
    wait "$emulator_pid" 2>/dev/null || true
  fi
  if [ -n "$evidence" ]; then
    mkdir -p "$evidence"
    for log in "$work"/*.log; do [ ! -f "$log" ] || cp "$log" "$evidence/"; done
  fi
  rm -rf -- "$work"
  exit "$status"
}
trap cleanup EXIT
if "$adb" devices | grep -q "$serial"; then echo 'test emulator port 5592 is busy' >&2; exit 1; fi

"$ROOT/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/api_fixture_description.json" \
  --origin http://10.0.2.2:3581 --package-id hey.android.sharefixture --label 'Share fixture' \
  --out "$work/app" >"$work/build.log" 2>&1 || { tail -15 "$work/build.log"; exit 1; }
mkdir -p "$work/test/classes" "$work/test/dex"
"$java_home/bin/javac" --release 17 -classpath "$HEY_ANDROID_PLATFORM_JAR:$work/app/classes" \
  -d "$work/test/classes" "$ROOT/renderer/instrumentation/hey/android/api/ShareInstrumentation.java"
find "$work/test/classes" -name '*.class' > "$work/test/classes.txt"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/d8" --min-api 35 \
  --lib "$HEY_ANDROID_PLATFORM_JAR" --classpath "$work/app/classes" --output "$work/test/dex" @"$work/test/classes.txt"
"$bt/aapt2" link --manifest "$ROOT/specs/support/share_instrumentation/AndroidManifest.xml" \
  -I "$HEY_ANDROID_PLATFORM_JAR" -o "$work/test/base.apk"
(cd "$work/test/dex" && zip -q "$work/test/base.apk" classes.dex)
"$bt/zipalign" -P 16 -f 4 "$work/test/base.apk" "$work/test/aligned.apk"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" sign \
  --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android \
  --key-pass pass:android --out "$work/test/app.apk" "$work/test/aligned.apk"
printf 'no\n' | env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$HEY_ANDROID_AVDMANAGER" \
  create avd --force --name share_fixture --package "$HEY_ANDROID_SYSTEM_IMAGE" --device "$HEY_ANDROID_AVD_DEVICE" \
  > "$work/avd.log" 2>&1
"$HEY_ANDROID_EMULATOR_BIN" -avd share_fixture -port 5592 -no-window -no-audio -no-snapshot \
  -no-boot-anim -gpu swiftshader_indirect > "$work/emulator.log" 2>&1 &
emulator_pid=$!
booted=false
for _ in $(seq 1 240); do
  if [ "$("$adb" -s "$serial" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ]; then booted=true; break; fi
  kill -0 "$emulator_pid" 2>/dev/null || break
  sleep 1
done
if [ "$booted" != true ]; then tail -15 "$work/emulator.log"; exit 1; fi
"$adb" -s "$serial" shell wm dismiss-keyguard >/dev/null 2>&1 || true
"$adb" -s "$serial" install -r "$work/app/app.apk" > "$work/install.log"
"$adb" -s "$serial" install -r "$work/test/app.apk" >> "$work/install.log"
for scenario in normal deadline; do
  "$adb" -s "$serial" shell am force-stop hey.android.sharefixture
  "$adb" -s "$serial" shell am instrument -w -e scenario "$scenario" hey.android.sharetest/hey.android.api.ShareInstrumentation | tee "$work/$scenario.log"
  grep -q 'share_instrumentation=true' "$work/$scenario.log"
done
echo 'PASS: native sharing supplies a real read-only PNG attachment and exact authored text'
echo 'PASS (control): occupied share worker returns bounded text fallback; explicit retry supplies the real attachment'
