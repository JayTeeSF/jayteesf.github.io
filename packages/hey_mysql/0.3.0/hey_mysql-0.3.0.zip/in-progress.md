# In progress

Staged for the next release (target 0.3.0, not yet bumped): the
configuration and dev-provisioning tier extracted from RecallCoach --
`config_from_env.hey` (MysqlConfig, with a compiled receipt in all three
lanes), the `mysql-dev` locked package command dispatching to `tools/dev/`
(compose wrapper, idempotent mysql-up with `--force` as the only
destructive path, mysql-down, clean-containers, configure-auth gated on
the compose-managed probe, select-mysql-port, db-create with grants for
every environment, env layering via a sourceable load-env,
install-system-deps, build-native-lib), and shell specs for the
daemon-free surface. The docker-daemon-dependent provisioning paths
(compose up/down, the managed verdict, live configure-auth) still need a
proving run on a box with a running daemon before release.

0.2.4 is the current native-command compatibility release. The base package gate uses the stable `hey native` interface. The configured live-server gate must still be run on real MySQL and MariaDB servers with the desired authentication and TLS policies. Full live-SQL direct-LLVM execution remains a generic compiler supported-subset receipt, not a reason to move driver code into Hey.
