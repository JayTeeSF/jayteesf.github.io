// Native boundary test: reference-file interoperability, set operations, paging and refusal
// of malformed input. Links the built extension directly.
#include "hey_native_abi.h"
#include "hey_roaring.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures = 0;
#define CHECK(cond) do { if (!(cond)) { fprintf(stderr, "FAIL %s:%d %s\n", __FILE__, __LINE__, #cond); failures++; } } while (0)

static uint8_t *slurp(const char *path, size_t *size) {
  FILE *f = fopen(path, "rb"); if (!f) return NULL;
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  uint8_t *data = malloc((size_t)n); if (data && fread(data, 1, (size_t)n, f) != (size_t)n) { free(data); data = NULL; }
  fclose(f); *size = (size_t)n; return data;
}
static void release(HeyNativeOwnedBytes b) { if (b.release) b.release(b.context, b.data, b.length); }
static HeyNativeBytesView view(const uint8_t *data, size_t length) { return (HeyNativeBytesView){data, length}; }

// Built as the Java writer built it: individual adds give bitset containers; the run file
// is the same set after run optimization.
static HeyNativeHandle reference_set(int runs) {
  HeyNativeHandle b = hey_roaring_new();
  for (uint32_t k = 0; k < 100000; k += 1000) hey_roaring_add(b, k);
  for (uint32_t k = 100000; k < 200000; ++k) hey_roaring_add(b, 3 * k);
  for (uint32_t k = 700000; k < 800000; ++k) hey_roaring_add(b, k);
  if (runs) hey_roaring_optimize(b);
  return b;
}

static void check_reference(const char *path, int runs) {
  size_t size = 0; uint8_t *data = slurp(path, &size);
  CHECK(data != NULL);
  if (!data) return;
  HeyNativeHandle loaded = hey_roaring_deserialize(view(data, size));
  CHECK(loaded != 0);
  CHECK(hey_roaring_cardinality(loaded) == 200100);
  CHECK(hey_roaring_contains(loaded, 99000) == 1 && hey_roaring_contains(loaded, 99001) == 0);
  CHECK(hey_roaring_contains(loaded, 300000) == 1 && hey_roaring_contains(loaded, 599997) == 1 && hey_roaring_contains(loaded, 300001) == 0);
  CHECK(hey_roaring_contains(loaded, 700000) == 1 && hey_roaring_contains(loaded, 799999) == 1 && hey_roaring_contains(loaded, 800000) == 0);
  HeyNativeHandle expected = reference_set(runs);
  CHECK(hey_roaring_intersection_cardinality(loaded, expected) == 200100);
  HeyNativeOwnedBytes ours = hey_roaring_serialize(expected, 1 << 20);
  CHECK(ours.data != NULL && ours.length == size && memcmp(ours.data, data, size) == 0);
  release(ours);
  // Truncated, padded and corrupted inputs are refused, never partially read.
  CHECK(hey_roaring_deserialize(view(data, size - 1)) == 0);
  uint8_t *padded = malloc(size + 1); memcpy(padded, data, size); padded[size] = 0;
  CHECK(hey_roaring_deserialize(view(padded, size + 1)) == 0);
  free(padded);
  uint8_t *corrupt = malloc(size); memcpy(corrupt, data, size); memset(corrupt + 4, 0xff, 8);
  HeyNativeHandle bad = hey_roaring_deserialize(view(corrupt, size));
  CHECK(bad == 0);
  if (bad) hey_roaring_free(bad);
  free(corrupt);
  hey_roaring_free(expected); hey_roaring_free(loaded); free(data);
}

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  char path[4096];
  snprintf(path, sizeof path, "%s/bitmapwithoutruns.bin", argv[1]); check_reference(path, 0);
  snprintf(path, sizeof path, "%s/bitmapwithruns.bin", argv[1]); check_reference(path, 1);

  HeyNativeHandle left = hey_roaring_new(), right = hey_roaring_new();
  uint8_t packed[16] = {1,0,0,0, 2,0,0,0, 0xff,0xff,0xff,0xff, 3,0,0,0};
  CHECK(hey_roaring_add_many(left, view(packed, sizeof packed)) == 0);
  CHECK(hey_roaring_add_many(left, view(packed, 3)) == 1);
  CHECK(hey_roaring_add_range(right, 2, 5) == 0 && hey_roaring_add_range(right, 5, 4) == 1);
  CHECK(hey_roaring_add_range(right, 4294967295u, UINT64_C(4294967296)) == 0);
  HeyNativeHandle both = hey_roaring_intersection(left, right), either = hey_roaring_union(left, right);
  CHECK(hey_roaring_cardinality(both) == 3 && hey_roaring_cardinality(either) == 5);
  HeyNativeOwnedBytes page = hey_roaring_values(either, 1, 3);
  uint8_t expected_page[12] = {2,0,0,0, 3,0,0,0, 4,0,0,0};
  CHECK(page.length == 12 && memcmp(page.data, expected_page, 12) == 0);
  release(page);
  HeyNativeOwnedBytes tail = hey_roaring_values(either, 5, 3);
  CHECK(tail.data != NULL && tail.length == 0);
  release(tail);
  CHECK(hey_roaring_values(either, 0, 1048577).data == NULL);
  CHECK(hey_roaring_serialize(either, 1).data == NULL);
  CHECK(hey_roaring_remove(either, 2) == 0 && hey_roaring_contains(either, 2) == 0);
  CHECK(hey_roaring_deserialize(view(NULL, 0)) == 0);
  hey_roaring_free(left); hey_roaring_free(right); hey_roaring_free(both); hey_roaring_free(either);
  if (failures) return 1;
  puts("PASS: native interoperability, set operations, paging and malformed-input refusal");
  return 0;
}
