# Todo

1. Several cores on macOS: SO_REUSEPORT does not spread connections across
   listeners there, so one loop per worker needs a shared listener (accept in
   one loop, hand descriptors to the others) or EVFILT_READ on one listener in
   several kqueues. Measure before building.
2. IPv6 listeners (shared with hey_epoll's todo).
3. A per-connection idle deadline (EVFILT_TIMER is a natural fit here).
4. Run the specs on a FreeBSD host (the code builds for the BSDs by design but
   has only been run on macOS).
