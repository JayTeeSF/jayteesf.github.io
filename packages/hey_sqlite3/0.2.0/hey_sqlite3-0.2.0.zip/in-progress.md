# In progress

v0.2.0 is the first native-FFI release. The API, C wrapper, package build, prepared query/execute paths, blobs, transactions, and Linux product receipts are implemented. Darwin should be built and verified by the package maintainer; native Windows loading remains gated by Hey's Windows extension-loader milestone.
