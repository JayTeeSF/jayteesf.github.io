# Todos

- 0.1.1: prepared/bound statements and typed adapter values.
- 0.1.2: connection pools, transaction nesting/savepoints, migration ledger.
- 0.2.0: associations, validations, timestamps, callbacks, dirty tracking, schema reflection.
- Replace CLI transports with native drivers after a stable package/native extension boundary exists.
