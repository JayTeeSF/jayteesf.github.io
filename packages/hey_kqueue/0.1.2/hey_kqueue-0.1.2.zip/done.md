# Done

- 0.1.0: the kqueue backend split out of hey_epoll, same API name for name
  (version/backend/open/wait/next/data/send/drop/stats/close). Registrations
  ride a changelist into the next wait's kevent() (flushed early with
  EV_RECEIPT at 64), accepted sockets rely on inherited O_NONBLOCK/SO_NOSIGPIPE/
  TCP_NODELAY (checked once per loop), the listener's pending count bounds
  accept(). Builds only on macOS/BSD; open() refuses other systems with
  kqueue_unsupported_os. Two specs, product-compiler receipt, two negative
  controls; bench/macos compares it with hey_epoll's kqueue path and Web.serve.
- 0.1.1: documentation only. The measurements were redone on a quiet machine:
  keep-alive throughput equals hey_epoll's kqueue path (177k req/s, within
  1%; 0.1.0's 3-12% gap was noise from a busy machine), and under connection
  churn hey_kqueue spends about 10% less CPU per request. No code change.
