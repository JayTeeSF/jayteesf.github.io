# Goals

- Provide readable database porcelain without coupling Hey to a specific engine.
- Keep SQL and parameter values separate through datasets and model operations.
- Support explicit connections, immutable datasets, transactions, models, and migrations.
- Offer a JSON record store and a migration ledger so document-style applications get the same adapter independence.
- Allow database drivers and this ORM layer to release independently.
