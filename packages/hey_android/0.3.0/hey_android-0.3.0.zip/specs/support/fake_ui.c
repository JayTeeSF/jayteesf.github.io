/* fake_ui.c: the native/ui shims with no Android, for running a UI program's Hey
 * logic on the Mac through the same stdlib:Native descriptor (specs/android_ui_host_spec.sh).
 *
 * next_event plays the events in FAKE_UI_EVENTS, separated by '|', then reports destroy.
 * begin, text_row and commit print what an Android screen would show, one line each,
 * on stderr: "fake_ui: row <id> <label>" and "fake_ui: commit <n>".
 */
#include "hey_android_ui.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int64_t rows;
static char event_text[512];
static size_t event_offset;

int64_t hey_android_ui_begin(void) {
  rows = 0;
  return 0;
}

int64_t hey_android_ui_text_row(HeyNativeUtf8View label, HeyNativeUtf8View id) {
  if (id.length == 0) return -1;
  rows++;
  fprintf(stderr, "fake_ui: row %.*s %.*s\n", (int)id.length, id.data, (int)label.length, label.data);
  return rows;
}

int64_t hey_android_ui_commit(void) {
  fprintf(stderr, "fake_ui: commit %lld\n", (long long)rows);
  return rows;
}

HeyNativeUtf8View hey_android_ui_next_event(void) {
  const char *events = getenv("FAKE_UI_EVENTS");
  if (!events) events = "{\"kind\":\"start\"}";
  size_t total = strlen(events);
  if (event_offset >= total) {
    snprintf(event_text, sizeof event_text, "{\"kind\":\"destroy\"}");
  } else {
    const char *start = events + event_offset;
    const char *bar = strchr(start, '|');
    size_t length = bar ? (size_t)(bar - start) : strlen(start);
    if (length >= sizeof event_text) length = sizeof event_text - 1;
    memcpy(event_text, start, length);
    event_text[length] = '\0';
    event_offset += length + (bar ? 1 : 0);
  }
  HeyNativeUtf8View view = {event_text, strlen(event_text)};
  return view;
}

HeyNativeUtf8View hey_android_ui_errors(void) {
  HeyNativeUtf8View view = {"", 0};
  return view;
}

/* The glue side is not used on the Mac. */
void hey_android_ui_attach(struct ANativeActivity *activity) { (void)activity; }
void hey_android_ui_detach(struct ANativeActivity *activity) { (void)activity; }
void hey_android_ui_input_queue_created(struct ANativeActivity *activity, struct AInputQueue *queue) { (void)activity; (void)queue; }
void hey_android_ui_input_queue_destroyed(struct ANativeActivity *activity, struct AInputQueue *queue) { (void)activity; (void)queue; }
