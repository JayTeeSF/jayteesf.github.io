#!/usr/bin/env sh
# Cross-package gate: does hey_reports' scene document pass hey_tv's OWN
# validator, running hey_tv's OWN source?
#
# This is the only assertion in the suite that is not this package
# marking its own homework. `ReportsScene.valid_scene?` re-implements
# the structural rules; this runs `Television.validate_scene` itself.
#
# Two things make it a shell spec rather than a .hey spec:
#
#  1. hey_tv is not a dependency. Taking one would make `bin/check`
#     require a registry fetch for a gate that is informational. If
#     hey_tv is not on this machine the spec SKIPS, loudly.
#  2. `Television.validate_scene` opens with `type(doc) != 'object'`,
#     and `type()` cannot be lowered by the LLVM backend
#     ("llvm backend supported subset cannot lower: function call
#     type(...)"). So hey_tv's validator is INTERPRETER-ONLY and this
#     gate can only ever run in one lane. That is a fact about hey_tv,
#     not about hey_reports.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
HEY_TV_ROOT="${HEY_TV_ROOT:-$HOME/dev/hey_tv}"
TELEVISION="$HEY_TV_ROOT/src/Television.hey"

if [ ! -f "$TELEVISION" ]; then
  echo "SKIP: tv contract gate -- hey_tv source not found at $TELEVISION" >&2
  echo "      set HEY_TV_ROOT to run it. This gate is informational; the"
  echo "      package's own structural check runs in specs/scene_spec.hey."
  exit 0
fi

mkdir -p "$ROOT/tmp"
PROG="$ROOT/tmp/tv_contract_gate.hey"
OUT="$ROOT/tmp/tv_contract_gate.out"

cat > "$PROG" <<HEYEOF
import '$TELEVISION'
import '$ROOT/src/scene.hey'

program
  let theme = ReportsTheme.tv()
  let cats = ['Mon', 'Tue', 'Wed']
  let chart = Reports.chart('bar', 'Signups', cats, [Reports.series('Web', [120, 305, 210])])
  let doc = ReportsScene.scene(chart, theme)
  let verdict = Television.validate_scene(doc)
  says 'hey_tv_validate_ok=' + verdict.ok
  says 'hey_tv_validate_error=[' + verdict.error + ']'
  says 'widgets=' + doc.widgets.length

  # And the NEGATIVE control: hey_tv must reject an invented widget
  # kind, which is why hey_reports emits only text and rect.
  let broken = {...doc, widgets: [{kind: 'chart', id: 'c', data: []}]}
  let rejected = Television.validate_scene(broken)
  says 'invented_kind_ok=' + rejected.ok
  says 'invented_kind_error=[' + rejected.error + ']'
end
HEYEOF

# Never put the command whose exit code is the evidence on the left of a
# pipe: redirect, then read the file.
( cd "$ROOT" && env HEY_ROOT="$HEY_ROOT" HEY_STDLIB_PATH="$HEY_ROOT/stdlib" "$HEY_ROOT/bin/heyc" "$PROG" ) > "$OUT" 2>&1 || {
  echo "FAIL: tv contract gate -- program did not run" >&2
  cat "$OUT" >&2
  exit 1
}

cat "$OUT"

grep -q '^hey_tv_validate_ok=true$' "$OUT" || {
  echo "FAIL: hey_tv Television.validate_scene REJECTED the hey_reports scene" >&2
  exit 1
}
grep -q '^invented_kind_ok=false$' "$OUT" || {
  echo "FAIL: negative control did not fire -- hey_tv accepted an invented widget kind," >&2
  echo "      so this gate proves nothing. Investigate before trusting the green above." >&2
  exit 1
}
grep -q '^widgets=10$' "$OUT" || {
  echo "FAIL: expected 10 widgets" >&2
  exit 1
}
echo "PASS: hey_tv scene contract (validated by hey_tv's own Television.validate_scene)"
