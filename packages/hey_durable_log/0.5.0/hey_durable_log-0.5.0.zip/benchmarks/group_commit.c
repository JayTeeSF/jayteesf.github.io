#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log.h"

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "test_barrier.h"

/* Where a benchmark puts its journal.
 *
 * These hardcoded /tmp. On Linux /tmp is tmpfs -- RAM -- so the barrier being
 * measured was a memcpy, not a device flush: 0.1 us against 6119 us for the
 * same fdatasync on NVMe-backed btrfs, a 60,000x gap. Every "Linux" figure
 * written that way is fiction. It never surfaced on Darwin because /tmp there
 * is APFS, a real disk. Found by the linux actor before recording a number.
 *
 * HEY_DURABLE_LOG_BENCH_PATH names the directory; TMPDIR is honoured next, and
 * /tmp is the last resort. A benchmark must be able to say which filesystem it
 * measured, so this is reported alongside the results. */
static const char *benchmark_directory(void) {
  const char *chosen = getenv("HEY_DURABLE_LOG_BENCH_PATH");
  if (chosen != NULL && chosen[0] != '\0') return chosen;
  chosen = getenv("TMPDIR");
  if (chosen != NULL && chosen[0] != '\0') return chosen;
  return "/tmp";
}

static void benchmark_path(char *out, size_t size, const char *leaf) {
  const char *base = benchmark_directory();
  size_t length = strlen(base);
  while (length > 1 && base[length - 1] == '/') length--;
  snprintf(out, size, "%.*s/%s", (int)length, base, leaf);
}

typedef struct {
  hdl_broker *broker;
  int writer_id;
  int operations;
  int failures;
  int64_t *latencies_microseconds;
  hdl_test_barrier *start;
} benchmark_writer;

static int64_t monotonic_microseconds(void) {
  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);
  return (int64_t)now.tv_sec * 1000000 + now.tv_nsec / 1000;
}

static void *run_writer(void *opaque) {
  benchmark_writer *writer = opaque;
  hdl_test_barrier_wait(writer->start);
  for (int operation = 0; operation < writer->operations; operation++) {
    char payload[128];
    int length = snprintf(payload, sizeof(payload),
                          "{\"writer\":%d,\"operation\":%d,\"kind\":\"message.created\"}",
                          writer->writer_id, operation);
    hdl_record record = {(uint64_t)writer->writer_id + 1, payload, (uint32_t)length, 1};
    int64_t started = monotonic_microseconds();
    hdl_status status = hdl_broker_submit(writer->broker, &record, NULL);
    writer->latencies_microseconds[operation] = monotonic_microseconds() - started;
    if (status != HDL_OK) writer->failures++;
  }
  return NULL;
}

static int compare_i64(const void *left, const void *right) {
  int64_t a = *(const int64_t *)left;
  int64_t b = *(const int64_t *)right;
  return (a > b) - (a < b);
}

static int64_t percentile(int64_t *values, size_t count, double fraction) {
  size_t index = (size_t)(fraction * (double)(count - 1));
  return values[index];
}

int main(int argc, char **argv) {
  int writers = argc > 1 ? atoi(argv[1]) : 8;
  int operations = argc > 2 ? atoi(argv[2]) : 250;
  int max_batch = argc > 3 ? atoi(argv[3]) : 64;
  int window_us = argc > 4 ? atoi(argv[4]) : 250;
  if (writers <= 0 || operations <= 0 || max_batch <= 0 || window_us <= 0) {
    fprintf(stderr, "usage: group_commit [writers] [operations] [max_batch] [window_us]\n");
    return 2;
  }

  char path[4096];
  benchmark_path(path, sizeof(path), "hdl-benchmark-XXXXXX");
  int placeholder = mkstemp(path);
  if (placeholder < 0) return 1;
  close(placeholder);
  unlink(path);

  hdl_log *log = NULL;
  hdl_broker *broker = NULL;
  if (hdl_open(path, NULL, &log) != HDL_OK) return 1;
  hdl_broker_options options = {(uint32_t)(writers * 4), (uint32_t)max_batch, (uint32_t)window_us};
  if (hdl_broker_open(log, &options, &broker) != HDL_OK) return 1;

  pthread_t *threads = calloc((size_t)writers, sizeof(*threads));
  benchmark_writer *arguments = calloc((size_t)writers, sizeof(*arguments));
  int64_t *latencies = calloc((size_t)writers * (size_t)operations, sizeof(*latencies));
  if (threads == NULL || arguments == NULL || latencies == NULL) return 1;
  hdl_test_barrier start;
  hdl_test_barrier_init(&start, (unsigned)writers + 1);
  for (int writer = 0; writer < writers; writer++) {
    arguments[writer] = (benchmark_writer){
      broker, writer, operations, 0, latencies + writer * operations, &start
    };
    pthread_create(&threads[writer], NULL, run_writer, &arguments[writer]);
  }
  int64_t started = monotonic_microseconds();
  hdl_test_barrier_wait(&start);
  int failures = 0;
  for (int writer = 0; writer < writers; writer++) {
    pthread_join(threads[writer], NULL);
    failures += arguments[writer].failures;
  }
  int64_t elapsed = monotonic_microseconds() - started;
  hdl_broker_stats stats;
  hdl_broker_get_stats(broker, &stats);
  hdl_broker_close(broker);
  hdl_close(log);

  size_t total = (size_t)writers * (size_t)operations;
  qsort(latencies, total, sizeof(*latencies), compare_i64);
  double throughput = elapsed == 0 ? 0.0 : (double)total * 1000000.0 / (double)elapsed;
  double average_batch = stats.durable_batches == 0 ? 0.0
                           : (double)stats.records / (double)stats.durable_batches;
  printf("writers=%d operations=%d records=%zu failures=%d\n", writers, operations, total, failures);
  printf("throughput=%.0f records/s elapsed=%.3f ms\n", throughput, (double)elapsed / 1000.0);
  printf("latency p50=%.3f ms p95=%.3f ms p99=%.3f ms\n",
         (double)percentile(latencies, total, 0.50) / 1000.0,
         (double)percentile(latencies, total, 0.95) / 1000.0,
         (double)percentile(latencies, total, 0.99) / 1000.0);
  printf("max_queue_depth=%u queue_capacity=%u\n", stats.max_queue_depth, options.queue_capacity);
  printf("durable_batches=%llu average_batch=%.2f largest_batch=%u\n",
         (unsigned long long)stats.durable_batches, average_batch, stats.largest_batch);

  hdl_test_barrier_destroy(&start);
  free(latencies);
  free(arguments);
  free(threads);
  unlink(path);
  return failures == 0 ? 0 : 1;
}

