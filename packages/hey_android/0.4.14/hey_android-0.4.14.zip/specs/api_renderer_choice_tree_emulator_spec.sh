#!/usr/bin/env bash
# Native expandable choices, cancellation and exact multiline drafts on API 36.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-choices.XXXXXX")
evidence=${HEY_ANDROID_CHOICES_EVIDENCE:-}
java_home=$(hey_android_java_home)
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
adb=$HEY_ANDROID_ADB
serial=''
server_pid=''
cleanup() {
  local status=$?
  if [ -n "$serial" ]; then
    "$adb" -s "$serial" uninstall hey.android.sharetest >/dev/null 2>&1 || true
    "$adb" -s "$serial" uninstall hey.android.sharefixture >/dev/null 2>&1 || true
    "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" >/dev/null 2>&1 || status=1
  fi
  if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi
  if [ -n "$evidence" ]; then mkdir -p "$evidence"; cp "$work"/*.log "$evidence/" 2>/dev/null || true; fi
  rm -rf "$work"
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
port=3596
mkdir -p "$work/test/classes" "$work/test/dex"
"$HEY_ANDROID_RUBY" -rjson -e 'd={schema:"hey-mobile-api-app-v1",level:1,platform:"android",title:"Choice fixture",session:{sign_in_screen:"reply",header:"Authorization",prefix:"Bearer "},tabs:["saved"],screens:[{id:"reply",type:"form",title:"Reply",source:{method:"GET",path:"/defaults"},values:{request_key:"request_key",folder:"default_folder"},fields:[{id:"username",label:"Username",kind:"text"},{id:"body",label:"Message",kind:"multiline"},{id:"folder",label:"Folder",kind:"choice",options:[{title:"Only this item",value:""}],choices:{method:"GET",path:"/choices",body:{},list:"nodes",value:"slug",label:"label",tree:{id:"path",parent:"parent",selectable:"selectable"}}}],primary:{title:"Send",request:{method:"POST",path:"/messages",body:{body:"$body",folder:"$folder",request_key:"$request_key",username:"$username"}},on_success:{message:"Saved",then:"stay"}}},{id:"saved",type:"list",title:"Saved",sections:[]}]};File.write(ARGV[0],JSON.generate(d))' "$work/description.json"
sdk=${HEY_ANDROID_CHOICES_SDK_ROOT:-$ROOT}
"$sdk/tools/hey-android-api-app.sh" --description "$work/description.json" --origin "http://10.0.2.2:$port" --package-id hey.android.sharefixture --label 'Dictation fixture' --out "$work/app" > "$work/build.log" 2>&1
"$java_home/bin/javac" --release 17 -classpath "$HEY_ANDROID_PLATFORM_JAR:$work/app/classes" -d "$work/test/classes" "$ROOT/renderer/instrumentation/choices/hey/android/api/ChoiceInstrumentation.java"
find "$work/test/classes" -name '*.class' > "$work/test/classes.txt"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/d8" --min-api 35 --lib "$HEY_ANDROID_PLATFORM_JAR" --classpath "$work/app/classes" --output "$work/test/dex" @"$work/test/classes.txt"
sed 's/hey.android.api.ShareInstrumentation/hey.android.api.ChoiceInstrumentation/' "$ROOT/specs/support/share_instrumentation/AndroidManifest.xml" > "$work/test/AndroidManifest.xml"
"$bt/aapt2" link --manifest "$work/test/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -o "$work/test/base.apk"
(cd "$work/test/dex" && zip -q "$work/test/base.apk" classes.dex)
"$bt/zipalign" -P 16 -f 4 "$work/test/base.apk" "$work/test/aligned.apk"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" sign --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$work/test/app.apk" "$work/test/aligned.apk"
"$HEY_ANDROID_RUBY" "$ROOT/specs/support/choice_tree_server.rb" "$port" "$work/requests.log" > "$work/server.log" 2>&1 &
server_pid=$!
# A caller may supply an owned, initialized AVD_HOME. Otherwise prime a fresh
# factory AVD from configuration only; never inherit the shared AVD's accounts.
fresh_avd=false
choices_avd_source=${ANDROID_AVD_HOME:-$HOME/.android/avd}
if [ "$choices_avd_source" = "$HOME/.android/avd" ]; then
  export ANDROID_AVD_HOME="$work/owned-avds"
  mkdir -p "$ANDROID_AVD_HOME/$HEY_ANDROID_AVD.avd"
  cp "$choices_avd_source/$HEY_ANDROID_AVD.avd/config.ini" "$ANDROID_AVD_HOME/$HEY_ANDROID_AVD.avd/config.ini"
  printf 'avd.ini.encoding=UTF-8\npath=%s/%s.avd\ntarget=android-36\n' "$ANDROID_AVD_HOME" "$HEY_ANDROID_AVD" > "$ANDROID_AVD_HOME/$HEY_ANDROID_AVD.ini"
  fresh_avd=true
fi
[ -z "$(pgrep -f 'qemu-system.*-port 5586( |$)' || true)" ] || { echo 'FAIL: emulator port already owned'; exit 1; }
serial=emulator-5586
boot_owned() {
  "$HEY_ANDROID_EMULATOR_BIN" -avd "$HEY_ANDROID_AVD" -port 5586 "$@" -no-window -no-audio -no-snapshot -no-boot-anim -gpu swiftshader_indirect >> "$work/emulator.log" 2>&1 &
  owned_emulator_pid=$!
  for ((attempt=0;attempt<150;attempt++)); do
    kill -0 "$owned_emulator_pid" 2>/dev/null || { echo 'FAIL: owned emulator exited'; return 1; }
    booted=$("$adb" -s "$serial" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r' || true)
    [ "$booted" != 1 ] || break
    sleep 2
  done
  [ "$booted" = 1 ] || { echo 'FAIL: owned emulator boot'; return 1; }
  "$adb" -s "$serial" shell wm dismiss-keyguard >/dev/null 2>&1 || true
}
if [ "$fresh_avd" = true ]; then
  boot_owned
  "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" > "$work/prime-shutdown.log" 2>&1
fi
# The fixture itself always runs from a read-only overlay and saves no snapshot.
boot_owned -read-only
"$adb" -s "$serial" uninstall hey.android.sharefixture >/dev/null 2>&1 || true
"$adb" -s "$serial" install -r "$work/app/app.apk" > "$work/install.log"
"$adb" -s "$serial" install -r "$work/test/app.apk" >> "$work/install.log"
# The emulator can finish booting before its route to the host carries TCP.
# Every read in the fixture then fails and the picker never loads (seen once as
# "Timed out waiting for Expand work"), so wait until the device reaches it.
reachable=false
for ((attempt=0;attempt<60;attempt++)); do
  if "$adb" -s "$serial" shell "printf 'GET /ready HTTP/1.0\r\n\r\n' | nc -w 3 10.0.2.2 $port" 2>/dev/null | grep -q '^HTTP/1.1 200'; then reachable=true; break; fi
  sleep 1
done
[ "$reachable" = true ] || { echo 'FAIL: the emulator cannot reach the fixture server'; exit 1; }
"$adb" -s "$serial" shell am instrument -w -e scenario "${HEY_ANDROID_CHOICES_SCENARIO:-full}" hey.android.sharetest/hey.android.api.ChoiceInstrumentation | tee "$work/choices.log"
grep -q 'choices=true' "$work/choices.log"
if [ "${HEY_ANDROID_CHOICES_SCENARIO:-full}" != static ]; then
"$HEY_ANDROID_RUBY" -rjson -e 'rows=File.readlines(ARGV[0]).map{|line|JSON.parse(line)};writes=rows.select{|r|r["method"]=="POST"};abort "expected Send alone to write once" unless writes.length==1 && writes[0]["path"]=="/messages";body=JSON.parse(writes[0].fetch("body"));abort "draft, metadata or chosen parent changed" unless body["body"]=="Mixed CASE, exact punctuation!\n\nSecond line — stays here.  " && body["folder"]=="work-slug" && body["username"]=="MiXeD.User" && body["request_key"].to_s.start_with?("synthetic-request-")' "$work/requests.log"
"$HEY_ANDROID_RUBY" -rjson -e 'rows=File.readlines(ARGV[0]).map{|line|JSON.parse(line)}; choices=rows.select{|r|r["path"].start_with?("/choices")};signed_out=choices.take_while{|r|r["authorization"].nil?};choices=choices.drop(signed_out.length);abort "missing authenticated choices" if choices.empty? || choices.any?{|r|r["authorization"]!="Bearer synthetic-choice-account"};abort "the late choices read was never sent" unless choices.any?{|r|r["path"]=="/choices-late"}' "$work/requests.log"
fi
if [ "${HEY_ANDROID_CHOICES_SCENARIO:-full}" = full ]; then
  # Mutation controls: the same SDK with one guard removed must fail the
  # scenario that checks it, for the reason it checks, or that check proves
  # nothing. mutant NAME SCENARIO EXPECTED, with the mutation as Ruby on stdin
  # (it edits s, the activity source, and aborts unless it matches).
  mutant() {
    local name=$1 scenario=$2 expected=$3 dir="$work/mutant-$1"
    mkdir -p "$dir/sdk"
    (cd "$sdk" && tar cf - --exclude ./build --exclude ./dist --exclude ./.git .) | (cd "$dir/sdk" && tar xf -)
    "$HEY_ANDROID_RUBY" -e 'p=ARGV[0];s=File.read(p);eval(STDIN.read);File.write(p,s)' "$dir/sdk/renderer/android/hey/android/api/HeyAndroidApiActivity.java" || { echo "FAIL: the $name mutation did not apply"; exit 1; }
    "$dir/sdk/tools/hey-android-api-app.sh" --description "$work/description.json" --origin "http://10.0.2.2:$port" --package-id hey.android.sharefixture --label 'Dictation fixture' --out "$dir/app" > "$work/mutant-$name-build.log" 2>&1
    # A fresh install: an earlier run left its synthetic account in the store.
    "$adb" -s "$serial" uninstall hey.android.sharefixture >/dev/null 2>&1 || true
    "$adb" -s "$serial" install -r "$dir/app/app.apk" >> "$work/install.log"
    "$adb" -s "$serial" shell am instrument -w -e scenario "$scenario" hey.android.sharetest/hey.android.api.ChoiceInstrumentation > "$work/mutant-$name-choices.log" 2>&1 || true
    if grep -q 'choices=true' "$work/mutant-$name-choices.log"; then echo "FAIL: the $name mutant passed"; exit 1; fi
    grep -q "$expected" "$work/mutant-$name-choices.log" || { echo "FAIL: the $name mutant failed for another reason"; cat "$work/mutant-$name-choices.log"; exit 1; }
    rm -rf "$dir"
  }
  # The picker reply's `active` guard removed: the late reply must change the form.
  mutant guard late 'loaded labels changed .*shown Folder label changed' <<'RB'
old="        if (!active.getAsBoolean()) return;\n        ChoiceTree tree = null;\n"
abort "mutation did not match" unless s.scan(old).length==1
s=s.sub(old,"        ChoiceTree tree = null;\n")
RB
  # A failed source redrawn with render(): the field being typed in must lose focus.
  mutant focus focus 'a failed source keeps the field being typed in and its cursor' <<'RB'
old="        else if (top() == page) renderKeepingFocus();\n        return;\n"
abort "mutation did not match" unless s.scan(old).length==1
s=s.sub(old,"        else if (top() == page) render();\n        return;\n")
RB
  # Retry neither numbered nor held while loading: a double tap's stale failure must land beneath the tree.
  mutant retry retry 'a double-tapped Retry let a stale failure land beneath the tree' <<'RB'
olds=["        if (mine != request[0]) return;\n","          if (!active.getAsBoolean() || reading[0] || mine != request[0]) return;\n          v.setEnabled(false);\n"]
news=["","          if (!active.getAsBoolean()) return;\n"]
olds.zip(news).each{|o,n| abort "mutation did not match" unless s.scan(o).length==1; s=s.sub(o,n)}
RB
fi
if [ -n "$evidence" ] && [ "${HEY_ANDROID_CHOICES_SCENARIO:-full}" != static ]; then
  mkdir -p "$evidence"
  for frame in choice-expanded choice-private choice-parent-selected; do
    "$adb" -s "$serial" exec-out run-as hey.android.sharefixture cat "files/$frame.png" > "$evidence/$frame.png"
  done
fi
if [ "${HEY_ANDROID_CHOICES_SCENARIO:-full}" = static ]; then
  echo 'PASS: oversized static choices and labels show cancellable errors and preserve prose'
else
  echo 'PASS: expandable folders, parent selection, private ancestors, cancellation and exact multiline prose'
  echo 'PASS: the form loads its choices, so a stored id shows its label before the picker opens; the picker marks the current choice for the eye and TalkBack'
  echo 'PASS: a double-tapped Retry sends one read; a failed or late source keeps the field being typed in and its cursor; Back changes neither draft nor folder'
  echo 'PASS: Send alone writes once with the exact draft, source metadata and chosen parent; every choices read after sign-in carries the session'
  echo 'PASS: leaving the page dismisses the picker; a choices reply after leave() changes neither the loaded labels nor the shown Folder label'
  echo 'PASS (control): with the picker reply guard removed, the late reply changes both the loaded labels and the shown Folder label, and the run fails'
  echo 'PASS (control): with a failed source redrawn by render(), the field being typed in loses focus, and the run fails'
  echo 'PASS (control): with Retry neither numbered nor held while loading, a double tap lands a stale failure beneath the tree, and the run fails'
fi
