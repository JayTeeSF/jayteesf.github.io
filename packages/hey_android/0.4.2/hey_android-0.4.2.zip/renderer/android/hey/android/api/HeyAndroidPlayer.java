package hey.android.api;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Playing one thing at a time, and telling the server where the listener got
 * to.
 *
 * <p>FRAMEWORK CLASSES ONLY. This build is javac and d8 against android.jar
 * with no dependency manager, so there is no ExoPlayer and no androidx media
 * here: {@link MediaPlayer} is what there is. It is enough for what this feed
 * holds -- one address, played start to finish -- and its limits are real ones
 * to know: no gapless joins between pages, and it stops when the app does.
 *
 * <p>WHILE THE APP IS IN THE FOREGROUND, and no further. Playing on after the
 * listener leaves needs a foreground Service declared in the manifest, which is
 * a separate slice; pretending otherwise would mean audio that dies silently in
 * a pocket.
 *
 * <p>PAGES. A narrated article arrives as several addresses, one per page, and
 * they are played in order. Everything else has exactly one.
 */
final class HeyAndroidPlayer {
  static final String TAG = "hey.api";

  interface Watcher {
    /** Something changed that the screen should redraw: started, stopped, failed, moved on a page. */
    void changed();

    /**
     * Tell the server where the listener stopped.
     *
     * @param finished true when the whole thing was played to its end
     */
    void report(String id, int seconds, int page, boolean finished);
  }

  /** What the screen says about the current track. */
  enum State { IDLE, LOADING, PLAYING, PAUSED, FAILED }

  private final Handler main = new Handler(Looper.getMainLooper());
  private final Watcher watcher;
  private final int reportEvery;

  private MediaPlayer player;
  private Screens.Track track;
  private int page;
  private State state = State.IDLE;
  private String failure = "";
  /**
   * Which run of the player a timer belongs to. Every start, pause or stop
   * makes a new one, so a timer armed by an older run reports nothing when it
   * comes round: a boolean guard is not enough, because pausing ends a loop and
   * resuming starts another, and two loops then report the same second twice.
   * Measured on the device: reports 0.47s apart on one 15-second tick.
   */
  private int run;
  /**
   * True only between onPrepared and release. ASKING A PLAYER THAT IS STILL
   * OPENING FOR ITS LENGTH IS AN ERROR, and not one that can be caught: the
   * native layer does not throw, it logs "Attempt to call getDuration in wrong
   * state" and posts error -38 to the error listener, which then marks a
   * perfectly good stream as failed. Seen on the device the moment a running
   * time was added to the player bar, which draws while the file is still
   * opening.
   */
  private boolean prepared;

  HeyAndroidPlayer(Watcher watcher, int reportEverySeconds) {
    this.watcher = watcher;
    this.reportEvery = Math.max(5, reportEverySeconds);
  }

  State state() { return state; }

  String failure() { return failure; }

  Screens.Track track() { return track; }

  boolean holding(Screens.Track other) {
    return track != null && other != null && !track.id.isEmpty() && track.id.equals(other.id);
  }

  /** Where the listener is now, in seconds into the current page. */
  int seconds() {
    if (player == null || !prepared) return track == null ? 0 : track.positionSeconds;
    try {
      return player.getCurrentPosition() / 1000;
    } catch (IllegalStateException e) {
      return 0;
    }
  }

  int page() { return page; }

  /**
   * How long the current page runs, in seconds, or 0 when that is not known.
   *
   * <p>ASKED OF THE MEDIA, not of the feed. The row's own duration is a field
   * in somebody else's description, and this renderer knows no field names of
   * its own; the file that is open knows exactly how long it is. Live radio
   * has no end and answers 0, which the screen shows as a count up with
   * nothing to count towards.
   */
  int duration() {
    if (player == null || !prepared) return 0;
    try {
      int ms = player.getDuration();
      return ms > 0 ? ms / 1000 : 0;
    } catch (IllegalStateException e) {
      return 0;
    }
  }

  /**
   * Start something, from where it was left.
   *
   * <p>headers are sent ONLY for an address on this app's own server: a
   * narrated article is served to its owner alone and needs the session, and
   * everything else is somebody else's file, where a token has no business
   * being. The caller decides which is which.
   */
  void play(Screens.Track wanted, Map<String, String> headers, android.content.Context context, String origin) {
    stop(true);
    if (wanted == null || !wanted.playable) return;
    track = wanted;
    run = run + 1;
    page = Math.max(0, Math.min(wanted.positionPage, wanted.pages.size() - 1));
    state = State.LOADING;
    failure = "";
    watcher.changed();
    open(context, headers, origin, wanted.positionSeconds);
  }

  private void open(android.content.Context context, Map<String, String> headers, String origin, int startAt) {
    List<String> pages = track.pages;
    if (page < 0 || page >= pages.size()) {
      finish();
      return;
    }
    String address = pages.get(page);
    MediaPlayer mp = new MediaPlayer();
    player = mp;
    try {
      mp.setAudioAttributes(new AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_MEDIA)
          .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
          .build());
      Map<String, String> send = new LinkedHashMap<>();
      if (!origin.isEmpty() && address.startsWith(origin) && headers != null) send.putAll(headers);
      mp.setDataSource(context, Uri.parse(address), send);
      mp.setOnPreparedListener(ready -> {
        if (player != ready) return;
        prepared = true;
        if (startAt > 0) {
          try {
            ready.seekTo(startAt * 1000);
          } catch (IllegalStateException ignored) {
            // A stream that cannot seek starts at its beginning, which is
            // better than refusing to play it at all.
          }
        }
        ready.start();
        state = State.PLAYING;
        watcher.changed();
        tick();
      });
      mp.setOnCompletionListener(done -> {
        if (player != done) return;
        // ON TO THE NEXT PAGE, and only the LAST one finishes the thing: a
        // narrated article reported as finished at the end of page one would
        // leave the rest unread and marked done.
        if (page + 1 < track.pages.size()) {
          watcher.report(track.id, 0, page + 1, false);
          page = page + 1;
          release();
          state = State.LOADING;
          watcher.changed();
          open(context, headers, origin, 0);
          return;
        }
        finish();
      });
      mp.setOnErrorListener((bad, what, extra) -> {
        if (player != bad) return true;
        state = State.FAILED;
        failure = "what=" + what + " extra=" + extra;
        Log.i(TAG, "audio failed: " + address + " (" + failure + ")");
        release();
        watcher.changed();
        return true;
      });
      mp.prepareAsync();
    } catch (Exception e) {
      state = State.FAILED;
      failure = String.valueOf(e.getMessage());
      Log.i(TAG, "audio could not open " + address + ": " + e);
      release();
      watcher.changed();
    }
  }

  private void finish() {
    if (track != null) watcher.report(track.id, seconds(), page, true);
    release();
    state = State.IDLE;
    track = null;
    page = 0;
    watcher.changed();
  }

  /**
   * Move by delta seconds, clamped to the thing being played.
   *
   * <p>GUARDED ON prepared, like every other question asked of the player: a
   * seek on one that is still opening is the same uncatchable error -38 that
   * marked a good stream failed once already.
   *
   * <p>IT DOES NOT REPORT. Somebody hunting for a spot presses these several
   * times in a row, and a write per press is a lot of noise for a position that
   * is about to change again; the next tick, or a pause, sends where they
   * actually settled.
   */
  void skip(int delta) {
    if (player == null || !prepared) return;
    int to = seconds() + delta;
    if (to < 0) to = 0;
    int end = duration();
    if (end > 0 && to > end) to = end;
    seekTo(to);
  }

  void seekTo(int second) {
    if (player == null || !prepared) return;
    try {
      player.seekTo(Math.max(0, second) * 1000);
    } catch (IllegalStateException ignored) {
      return;
    }
    watcher.changed();
  }

  void pause() {
    if (player == null || state != State.PLAYING) return;
    try {
      player.pause();
    } catch (IllegalStateException ignored) {
      return;
    }
    state = State.PAUSED;
    run = run + 1;
    if (track != null) watcher.report(track.id, seconds(), page, false);
    watcher.changed();
  }

  void resume() {
    if (player == null || state != State.PAUSED) return;
    try {
      player.start();
    } catch (IllegalStateException ignored) {
      return;
    }
    state = State.PLAYING;
    run = run + 1;
    watcher.changed();
    tick();
  }

  /**
   * Stop, and say where the listener got to first.
   *
   * <p>Called when another track is chosen and when the screen goes away: a
   * position that is not reported is a place somebody has to find again.
   */
  void stop(boolean quiet) {
    if (track != null && (state == State.PLAYING || state == State.PAUSED)) {
      watcher.report(track.id, seconds(), page, false);
    }
    release();
    state = State.IDLE;
    run = run + 1;
    track = null;
    page = 0;
    if (!quiet) watcher.changed();
  }

  private void release() {
    MediaPlayer mp = player;
    player = null;
    prepared = false;
    if (mp == null) return;
    try {
      mp.reset();
    } catch (Exception ignored) {
      // A player that is already gone needs no resetting.
    }
    mp.release();
  }

  /** One report every reportEvery seconds while this run is still the current one. */
  private void tick() {
    final int mine = run;
    main.postDelayed(new Runnable() {
      @Override public void run() {
        if (mine != run || state != State.PLAYING || track == null) return;
        watcher.report(track.id, seconds(), page, false);
        watcher.changed();
        tick();
      }
    }, reportEvery * 1000L);
  }
}
