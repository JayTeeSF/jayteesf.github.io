# In progress

- A CarPlay frame from the CarPlay Simulator (Additional Tools for Xcode) with a USB iPhone: Simulator 26.5 has no CarPlay menu.
