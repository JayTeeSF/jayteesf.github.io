require 'json'
require 'zlib'
require_relative 'fixture_http'
port, log = ARGV
png_chunk = lambda {|kind,data| [data.bytesize].pack('N') + kind + data + [Zlib.crc32(kind + data)].pack('N') }
compressor = Zlib::Deflate.new
compressed = ''.b
row = "\0".b + "\x33\x66\x99\xff".b * 4096
4096.times { compressed << compressor.deflate(row) }
compressed << compressor.finish
compressor.close
large_png = "\x89PNG\r\n\x1a\n".b + png_chunk.call('IHDR', [4096,4096,8,6,0,0,0].pack('NNCCCCC')) + png_chunk.call('IDAT',compressed) + png_chunk.call('IEND',''.b)
oversized_pixels = "\x89PNG\r\n\x1a\n".b + png_chunk.call('IHDR', [100000,100000,8,6,0,0,0].pack('NNCCCCC')) + png_chunk.call('IDAT',Zlib::Deflate.deflate(''.b)) + png_chunk.call('IEND',''.b)
small_png = lambda {|pixel| "\x89PNG\r\n\x1a\n".b + png_chunk.call('IHDR',[1,1,8,6,0,0,0].pack('NNCCCCC')) + png_chunk.call('IDAT',Zlib::Deflate.deflate("\0".b + pixel)) + png_chunk.call('IEND',''.b) }
red_png = small_png.call("\xff\0\0\xff".b)
blue_png = small_png.call("\0\0\xff\xff".b)
messages = []
reads = 0
lock = Mutex.new
FixtureHttp.serve(Integer(port), 'synthetic reply fixture', lambda do |req|
  body = '{}'; status = 200
  if req.path == '/image/account-a' || req.path == '/image/account-b' || req.path == '/image/account-slow'
    sleep 0.4 if req.path == '/image/account-slow'
    image = req.path == '/image/account-b' ? blue_png : red_png
    req.respond(200, image, [['content-type','image/png'],['content-length',image.bytesize.to_s]])
    next
  elsif req.path == '/image/drip'
    req.respond(200, '', [['content-type','image/png'],['content-length','65536']])
    socket = req.instance_variable_get(:@socket)
    200.times { socket.write('x'); sleep 0.1 }
    next
  elsif req.path == '/image/large'
    req.respond(200, large_png, [['content-type','image/png'],['content-length',large_png.bytesize.to_s]])
    next
  elsif req.path == '/image/oversized-pixels'
    req.respond(200, oversized_pixels, [['content-type','image/png'],['content-length',oversized_pixels.bytesize.to_s]])
    next
  elsif req.path == '/image/oversized-header'
    req.respond(200, '', [['content-type','image/png'],['content-length',(4*1024*1024+1).to_s]])
    next
  elsif req.path == '/image/oversized-body'
    req.respond(200, 'x' * (4*1024*1024+1), [['content-type','image/png'],['connection','close']])
    req.instance_variable_get(:@socket).close
    next
  elsif req.path == '/image/broken'
    req.respond(200, 'broken', [['content-type','image/png'],['content-length','6']])
    next
  end
  if req.path == '/reset'
    lock.synchronize { messages.clear; reads = 0 }
  elsif req.method == 'POST' && req.path == '/messages'
    text = JSON.parse(req.body).fetch('body')
    lock.synchronize { messages << text }
  elsif req.path == '/stats'
    body = JSON.generate(writes: lock.synchronize { messages.size }, reads: reads)
  elsif req.path != '/messages' && !req.path.start_with?('/saved/')
    status = 404
  end
  if req.path == '/messages' || req.path.start_with?('/saved/')
    reads += 1 if req.path.start_with?('/saved/')
    index = req.path.start_with?('/saved/') ? req.path.split('/').last.to_i - 1 : messages.size - 1
    text = lock.synchronize { messages[index] }
    body = JSON.generate(id: index + 1, body: text, url: 'https://example.invalid/shared/synthetic/thread/author', share_presentation: {title: 'Synthetic item', text: text, url: 'https://example.invalid/shared/synthetic/thread/author', image_url: 'https://example.invalid/reply-art.png'})
  end
  lock.synchronize { File.open(log, 'a') {|f|f.puts JSON.generate(method: req.method, path: req.path, writes: messages.size)} }
  req.respond(status, body, [['content-type','application/json'],['content-length',body.bytesize.to_s]])
end)
