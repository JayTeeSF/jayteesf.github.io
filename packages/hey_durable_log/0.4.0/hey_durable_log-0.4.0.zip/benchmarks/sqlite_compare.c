/* Head-to-head: SQLite versus the durable-log broker, same host, same run,
 * SAME DURABILITY BARRIER.
 *
 * This benchmark exists to answer one question honestly: is putting this
 * journal in front of SQLite actually faster than writing to SQLite directly?
 * If it is not, the package has no reason to exist.
 *
 * The fairness rules are the whole point, because the earlier research found
 * that with fsync NOT acting as a barrier, SQLite comfortably beats this broker.
 * A comparison is only meaningful if both sides are made to survive the same
 * failure:
 *
 *   - both run on the same machine, in the same process invocation, back to back;
 *   - both do the same unit of work: one small record per call, and the caller
 *     WAITS for durability before issuing the next;
 *   - both use a real device-cache barrier. SQLite gets journal_mode=WAL,
 *     synchronous=FULL and (on Darwin) fullfsync=ON, which is what makes its
 *     commit issue F_FULLFSYNC -- exactly the barrier hdl issues;
 *   - each SQLite writer gets its OWN connection, because SQLite serialises
 *     writers and sharing one would measure a mutex instead of the engine;
 *   - busy_timeout is generous so SQLITE_BUSY is not counted as throughput.
 *
 * Anything that would flatter either side is refused. In particular there is no
 * multi-row batching on the SQLite side, because the journal side is not
 * batching at the CALLER either -- both are "one record, wait".
 */

#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log.h"
#include "test_barrier.h"

#include <pthread.h>
#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct {
  const char *db_path;
  hdl_broker *broker;
  int thread_id;
  int operations;
  int failures;
  hdl_test_barrier *start;
  double *latencies;
} bench_args;

static double now_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}

static int compare_double(const void *a, const void *b) {
  double x = *(const double *)a, y = *(const double *)b;
  return x < y ? -1 : (x > y ? 1 : 0);
}

static double percentile(double *values, size_t count, double fraction) {
  if (count == 0) return 0.0;
  size_t index = (size_t)(fraction * (double)(count - 1));
  return values[index];
}

/* ---- SQLite lane ---------------------------------------------------------- */

static void configure_connection(sqlite3 *db) {
  char *error = NULL;
  sqlite3_exec(db, "PRAGMA journal_mode=WAL;", NULL, NULL, &error);
  sqlite3_exec(db, "PRAGMA synchronous=FULL;", NULL, NULL, &error);
  /* On Darwin this is what turns SQLite's commit fsync into F_FULLFSYNC. It is
     a no-op elsewhere, which is correct: on Linux fdatasync already reaches the
     device once the metadata is stable. */
  sqlite3_exec(db, "PRAGMA fullfsync=ON;", NULL, NULL, &error);
  sqlite3_busy_timeout(db, 30000);
}

static void *sqlite_writer(void *opaque) {
  bench_args *args = opaque;
  sqlite3 *db = NULL;
  if (sqlite3_open(args->db_path, &db) != SQLITE_OK) { args->failures = args->operations; return NULL; }
  configure_connection(db);
  sqlite3_stmt *insert = NULL;
  if (sqlite3_prepare_v2(db, "INSERT INTO mutations (stream_id, payload) VALUES (?, ?)", -1, &insert, NULL) != SQLITE_OK) {
    sqlite3_close(db); args->failures = args->operations; return NULL;
  }
  char payload[64];
  hdl_test_barrier_wait(args->start);
  for (int index = 0; index < args->operations; index++) {
    int length = snprintf(payload, sizeof(payload), "thread=%d operation=%d", args->thread_id, index);
    double began = now_ms();
    sqlite3_reset(insert);
    sqlite3_bind_int64(insert, 1, args->thread_id + 1);
    sqlite3_bind_text(insert, 2, payload, length, SQLITE_STATIC);
    int status = sqlite3_step(insert);
    if (status != SQLITE_DONE) args->failures++;
    args->latencies[index] = now_ms() - began;
  }
  sqlite3_finalize(insert);
  sqlite3_close(db);
  return NULL;
}

/* ---- durable-log lane ----------------------------------------------------- */

static void *journal_writer(void *opaque) {
  bench_args *args = opaque;
  char payload[64];
  hdl_test_barrier_wait(args->start);
  for (int index = 0; index < args->operations; index++) {
    int length = snprintf(payload, sizeof(payload), "thread=%d operation=%d", args->thread_id, index);
    hdl_record record = {(uint64_t)args->thread_id + 1, payload, (uint32_t)length};
    double began = now_ms();
    if (hdl_broker_submit(args->broker, &record, NULL) != HDL_OK) args->failures++;
    args->latencies[index] = now_ms() - began;
  }
  return NULL;
}

/* ---- driver --------------------------------------------------------------- */

typedef struct { double throughput, p50, p95, p99, elapsed_ms; int failures; } lane_result;

static lane_result run_lane(void *(*body)(void *), const char *db_path, hdl_broker *broker,
                            int writers, int operations) {
  pthread_t *threads = calloc((size_t)writers, sizeof(*threads));
  bench_args *args = calloc((size_t)writers, sizeof(*args));
  double *all = calloc((size_t)writers * (size_t)operations, sizeof(*all));
  hdl_test_barrier start;
  hdl_test_barrier_init(&start, (unsigned)writers);

  for (int index = 0; index < writers; index++) {
    args[index] = (bench_args){db_path, broker, index, operations, 0, &start,
                               all + (size_t)index * (size_t)operations};
    pthread_create(&threads[index], NULL, body, &args[index]);
  }
  double began = now_ms();
  int failures = 0;
  for (int index = 0; index < writers; index++) {
    pthread_join(threads[index], NULL);
    failures += args[index].failures;
  }
  double elapsed = now_ms() - began;
  hdl_test_barrier_destroy(&start);

  size_t total = (size_t)writers * (size_t)operations;
  qsort(all, total, sizeof(*all), compare_double);
  lane_result result = {
    (double)total / (elapsed / 1000.0),
    percentile(all, total, 0.50), percentile(all, total, 0.95), percentile(all, total, 0.99),
    elapsed, failures
  };
  free(threads); free(args); free(all);
  return result;
}

static void report(const char *name, lane_result r, int writers, int operations) {
  printf("%-12s writers=%d ops=%d records=%d failures=%d\n",
         name, writers, operations, writers * operations, r.failures);
  printf("%-12s throughput=%.0f records/s elapsed=%.1f ms\n", "", r.throughput, r.elapsed_ms);
  printf("%-12s latency p50=%.3f ms p95=%.3f ms p99=%.3f ms\n", "", r.p50, r.p95, r.p99);
}

int main(int argc, char **argv) {
  int writers = argc > 1 ? atoi(argv[1]) : 8;
  int operations = argc > 2 ? atoi(argv[2]) : 100;
  int max_batch = argc > 3 ? atoi(argv[3]) : 64;
  int window_us = argc > 4 ? atoi(argv[4]) : 250;
  if (writers <= 0 || operations <= 0) { fprintf(stderr, "usage: sqlite_compare [writers] [ops] [max_batch] [window_us]\n"); return 2; }

  printf("barrier=%s sqlite=%s\n", hdl_sync_barrier_name(), sqlite3_libversion());

  /* ---- SQLite lane ---- */
  char db_path[] = "/tmp/hdl-compare-XXXXXX";
  int placeholder = mkstemp(db_path);
  if (placeholder >= 0) close(placeholder);
  unlink(db_path);
  sqlite3 *setup = NULL;
  if (sqlite3_open(db_path, &setup) != SQLITE_OK) { fprintf(stderr, "cannot open sqlite db\n"); return 1; }
  configure_connection(setup);
  char *error = NULL;
  if (sqlite3_exec(setup, "CREATE TABLE mutations (id INTEGER PRIMARY KEY, stream_id INTEGER NOT NULL, payload TEXT NOT NULL);",
                   NULL, NULL, &error) != SQLITE_OK) {
    fprintf(stderr, "cannot create table: %s\n", error ? error : "?"); return 1;
  }
  lane_result sqlite_lane = run_lane(sqlite_writer, db_path, NULL, writers, operations);
  sqlite3_close(setup);

  /* ---- durable-log lane ---- */
  char log_path[] = "/tmp/hdl-compare-log-XXXXXX";
  placeholder = mkstemp(log_path);
  if (placeholder >= 0) close(placeholder);
  unlink(log_path);
  hdl_log *log = NULL;
  hdl_broker *broker = NULL;
  if (hdl_open(log_path, NULL, &log) != HDL_OK) { fprintf(stderr, "cannot open journal\n"); return 1; }
  hdl_broker_options options = {(uint32_t)(writers * 2), (uint32_t)max_batch, (uint32_t)window_us};
  if (hdl_broker_open(log, &options, &broker) != HDL_OK) { fprintf(stderr, "cannot open broker\n"); return 1; }
  lane_result journal_lane = run_lane(journal_writer, NULL, broker, writers, operations);
  hdl_broker_stats stats;
  hdl_broker_get_stats(broker, &stats);
  hdl_broker_close(broker);
  hdl_close(log);

  report("sqlite", sqlite_lane, writers, operations);
  report("durable_log", journal_lane, writers, operations);
  printf("%-12s durable_batches=%llu average_batch=%.2f max_queue_depth=%u\n", "",
         (unsigned long long)stats.durable_batches,
         stats.durable_batches ? (double)stats.records / (double)stats.durable_batches : 0.0,
         stats.max_queue_depth);
  printf("ratio        throughput=%.2fx p50=%.2fx p99=%.2fx\n",
         sqlite_lane.throughput > 0 ? journal_lane.throughput / sqlite_lane.throughput : 0.0,
         journal_lane.p50 > 0 ? sqlite_lane.p50 / journal_lane.p50 : 0.0,
         journal_lane.p99 > 0 ? sqlite_lane.p99 / journal_lane.p99 : 0.0);
  unlink(db_path); unlink(log_path);
  return 0;
}
