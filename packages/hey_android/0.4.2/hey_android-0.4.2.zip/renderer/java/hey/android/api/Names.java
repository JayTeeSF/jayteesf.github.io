package hey.android.api;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Icon names and file kinds (hey_mobile icons.hey, conformance/names.json). A
 * description names an icon by what it shows ('library'); at level 1 it spells
 * the same icon as the SF Symbol hey_ios draws ('books.vertical'). Android maps
 * both spellings to one Material Symbols name, and draws DEFAULT_ICON for a
 * name it does not hold. File kinds map to MIME types for a document picker.
 */
public final class Names {
  private Names() {}

  public static final String DEFAULT_ICON = "circle";

  /** neutral name, SF Symbol, Material Symbol. */
  private static final String[][] ICONS = {
    {"library", "books.vertical", "local_library"},
    {"search", "magnifyingglass", "search"},
    {"add", "plus.circle", "add_circle"},
    {"headphones", "headphones", "headphones"},
    {"people", "person.2", "group"},
    {"person", "person.crop.circle", "account_circle"},
    {"person_add", "person.badge.plus", "person_add"},
    {"person_remove", "person.crop.circle.badge.minus", "person_remove"},
    {"person_key", "person.badge.key", "passkey"},
    {"video", "play.rectangle", "smart_display"},
    {"tv", "tv", "tv"},
    {"tv_box", "appletv", "connected_tv"},
    {"movie", "film", "movie"},
    {"book", "book.closed", "book"},
    {"mic", "mic", "mic"},
    {"music", "music.note", "music_note"},
    {"article", "doc.plaintext", "article"},
    {"read_aloud", "text.book.closed", "auto_stories"},
    {"radio", "antenna.radiowaves.left.and.right", "podcasts"},
    {"document", "doc.text", "description"},
    {"photo", "photo", "image"},
    {"photo_frame", "photo.on.rectangle", "photo_library"},
    {"photo_check", "photo.badge.checkmark", "image_search"},
    {"link", "link", "link"},
    {"link_circle", "link.circle", "add_link"},
    {"open_external", "arrow.up.right.square", "open_in_new"},
    {"tag", "number", "tag"},
    {"stack", "square.stack", "stacks"},
    {"stack_shared", "square.stack.3d.up", "layers"},
    {"stack_add", "plus.square.on.square", "library_add"},
    {"screen_add", "plus.rectangle.on.rectangle", "add_to_queue"},
    {"grid", "square.grid.2x2", "grid_view"},
    {"edit", "square.and.pencil", "edit_square"},
    {"edit_line", "pencil.line", "edit_note"},
    {"pencil", "pencil", "edit"},
    {"delete", "trash", "delete"},
    {"check", "checkmark", "check"},
    {"check_circle", "checkmark.circle", "check_circle"},
    {"check_stack", "checkmark.rectangle.stack", "library_add_check"},
    {"close", "xmark", "close"},
    {"cancel_circle", "xmark.circle", "cancel"},
    {"remove_circle", "minus.circle", "do_not_disturb_on"},
    {"send", "paperplane", "send"},
    {"share", "square.and.arrow.up", "share"},
    {"import", "square.and.arrow.down", "download"},
    {"download", "arrow.down.circle", "download_for_offline"},
    {"upgrade", "arrow.up.circle", "upgrade"},
    {"arrow_up", "arrow.up", "arrow_upward"},
    {"arrow_down", "arrow.down", "arrow_downward"},
    {"arrow_down_line", "arrow.down.to.line", "vertical_align_bottom"},
    {"arrow_forward_circle", "arrow.right.circle", "arrow_circle_right"},
    {"undo", "arrow.uturn.backward", "undo"},
    {"refresh", "arrow.clockwise", "refresh"},
    {"history", "clock.arrow.circlepath", "history"},
    {"mail", "envelope", "mail"},
    {"mail_open", "envelope.open", "drafts"},
    {"inbox", "tray", "inbox"},
    {"inbox_out", "tray.and.arrow.down", "move_to_inbox"},
    {"bell", "bell", "notifications"},
    {"gift", "gift", "redeem"},
    {"hand", "hand.raised", "front_hand"},
    {"seen", "eye", "visibility"},
    {"not_seen", "eye.slash", "visibility_off"},
    {"help", "questionmark.circle", "help"},
    {"info", "info.circle", "info"},
    {"warning", "exclamationmark.triangle", "warning"},
    {"play_circle", "play.circle", "play_circle"},
    {"play_tv", "play.tv", "live_tv"},
    {"sliders", "slider.horizontal.3", "tune"},
    {"ruler", "ruler", "straighten"},
    {"key", "key", "key"},
    {"lock", "lock", "lock"},
    {"sign_out", "rectangle.portrait.and.arrow.right", "logout"},
    {"phone_off", "iphone.slash", "mobile_off"},
    {"settings", "gearshape", "settings"},
    {"list", "list.bullet", "list"},
    {"folder", "folder", "folder"},
    {"calendar", "calendar", "calendar_month"},
    {"web", "globe", "language"},
    {"star", "star", "star"},
    {"qr_code", "qrcode", "qr_code"},
  };

  private static final Map<String, String[]> BY_NAME = new LinkedHashMap<>();
  private static final Map<String, String[]> BY_SYMBOL = new HashMap<>();

  static {
    for (String[] row : ICONS) {
      BY_NAME.put(row[0], row);
      BY_SYMBOL.putIfAbsent(row[1], row);
    }
  }

  /** Every neutral name this renderer holds, in table order. */
  public static List<String> iconNames() {
    return Collections.unmodifiableList(Arrays.asList(BY_NAME.keySet().toArray(new String[0])));
  }

  /** The SF Symbol hey_ios draws for a neutral name, or null. */
  public static String appleSymbol(String name) {
    String[] row = BY_NAME.get(name);
    return row == null ? null : row[1];
  }

  /** The Material Symbol for a neutral name or its level-1 SF Symbol spelling; DEFAULT_ICON otherwise. */
  public static String materialSymbol(String name) {
    if (name == null || name.isEmpty()) return DEFAULT_ICON;
    String[] row = BY_NAME.get(name);
    if (row == null) row = BY_SYMBOL.get(name);
    return row == null ? DEFAULT_ICON : row[2];
  }

  private static final Map<String, List<String>> APPLE_TYPES = new LinkedHashMap<>();
  private static final Map<String, List<String>> MIME_TYPES = new LinkedHashMap<>();

  static {
    APPLE_TYPES.put("csv", Arrays.asList("public.comma-separated-values-text"));
    APPLE_TYPES.put("json", Arrays.asList("public.json"));
    APPLE_TYPES.put("text", Arrays.asList("public.plain-text"));
    MIME_TYPES.put("csv", Arrays.asList("text/csv", "text/comma-separated-values"));
    MIME_TYPES.put("json", Arrays.asList("application/json"));
    MIME_TYPES.put("text", Arrays.asList("text/plain"));
  }

  public static List<String> fileKinds() {
    return Arrays.asList(MIME_TYPES.keySet().toArray(new String[0]));
  }

  public static List<String> appleTypes(String kind) {
    List<String> t = APPLE_TYPES.get(kind);
    return t == null ? Collections.<String>emptyList() : t;
  }

  /** MIME types for a file kind; an unknown kind names nothing. */
  public static List<String> mimeTypes(String kind) {
    List<String> t = MIME_TYPES.get(kind);
    return t == null ? Collections.<String>emptyList() : t;
  }
}
