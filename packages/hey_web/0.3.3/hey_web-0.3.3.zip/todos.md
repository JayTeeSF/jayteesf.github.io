# Todos

- Release the staged 0.3.0: BREAKING (maintainer ruling 2026-07-30 --
  broken middleware serving lane deleted, one Web.serve lane) plus the
  fast-lane modules and pages-embed. Pipeline: bump, bin/check,
  release, publish.
- Like-for-like measurement (owned by the RecallCoach side; its
  framework-extraction.md section 8, G1): serve-fixed middleware lane
  vs stdlib:Web, identical flat route table, asserted NON-EMPTY bodies.
  Until it runs, keep the README's unmeasured-cost wording.
- Run live HTTP/HTTPS client and server receipts on target hosts.
- Add cookies, signed sessions, form decoding, named routes, request-test helpers, and streaming conveniences.
- Add multipart/range/graceful-drain production work.
- Track stdlib HTTP/2, pooling, WebSocket, and server TLS capabilities without duplicating them here.
- When the upstream Ehy cwd ask lands (filed from the app side),
  drop the chdir from bin/pages-embed and tools/check_specs.hey.
