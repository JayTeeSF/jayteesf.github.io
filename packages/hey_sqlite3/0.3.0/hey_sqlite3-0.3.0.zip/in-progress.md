# In progress

Staged for the next release (unbumped; framework-extraction slice S3):

- The in-source version-literal defect is fixed: sources reported `0.2.2` at package version 0.2.6 (and the native library search path was pinned to `0.2.5`). The version now has a single source, `hey_sqlite3_version_value()` in `adapter.hey`, and `bin/package-check` guards it against `VERSION` with a grep plus a compiled version receipt.
- `Sqlite3.connect_options(options)` added (additively) as the config-record connect surface mirroring `Mysql.connect(options)`; the positional `connect(database, options)` is unchanged. Q4 (signature unification) stays open.
- `specs/store_conformance_spec.hey` proves the `hey_record_connection` store contract (store/fetch/delete/list, delete-absent -> `not_found` via `changes`) over a real file database, using a hand-copied shim of hey_record 0.3.0's sqlite3 store SQL.

Native Windows loading remains gated by Hey's Windows extension-loader milestone.
