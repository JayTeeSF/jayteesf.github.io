# hey_record 0.1.0

`hey_record` provides a small database-independent layer for Hey. Its query API is closer to Sequel datasets; its model descriptors and conventions are familiar to Active Record users.

It deliberately avoids pretending that Hey currently has Ruby-style classes or reflection. Models are explicit descriptors, rows are ordinary objects, and adapters are first-class callable values.

```hey
import 'pkg:hey_record@0.1.0/main'
import 'pkg:hey_sqlite3@0.1.0/main'
import 'stdlib:result'

program
  let db = Sqlite3.connect('db/app.sqlite3', {})
  let users = HeyRecord.from(db, 'users')

  let created = HeyRecord.insert(users, {name: 'Ada', active: true})
  let rows = result.value(HeyRecord.all(HeyRecord.where(users, {active: true}))).rows

  let User = HeyRecordModel.define(db, 'users', {primary_key: 'id', timestamps: true})
  let ada = result.value(HeyRecordModel.find(User, 1))
end
```

## Included

- SQL identifier/literal builders;
- immutable datasets with select/where/order/limit/offset;
- all/first/insert/update/delete operations;
- explicit model descriptors;
- result-based transactions;
- schema/migration SQL helpers;
- adapter contract through callable `query` and `execute` fields.

## Not yet included

Prepared statements, pooling, associations, validations, callbacks, dirty tracking, automatic timestamps, schema reflection, and migration bookkeeping remain roadmap work. Current adapters use shell-free direct argv calls to native database CLIs because package-level C FFI is not available in Hey 0.99.259a.

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/package-zip
./bin/reproduce-prompt
```
