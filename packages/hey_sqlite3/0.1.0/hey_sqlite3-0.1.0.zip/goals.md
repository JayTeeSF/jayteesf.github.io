# Goals

Provide a production-grade SQLite adapter for Hey and `hey_record`, progressing from a transparent direct-argv adapter to persistent native prepared connections.
