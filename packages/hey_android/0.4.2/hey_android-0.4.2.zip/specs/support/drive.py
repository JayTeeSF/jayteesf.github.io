#!/usr/bin/env python3
"""drive.py: drive an emulator by what its View tree says, for specs/api_renderer_emulator_spec.sh.

ADB (environment) names the adb binary.

  drive.py SERIAL tap TEXT [--contains]        tap the centre of the first node whose text (or content-desc) is TEXT
  drive.py SERIAL wait TEXT SECONDS [--contains] succeed when a node with that text appears
  drive.py SERIAL scrollto TEXT [SWIPES]         swipe up until a node with that text is on screen
  drive.py SERIAL gone TEXT SECONDS            succeed when no node has that text
  drive.py SERIAL type LABEL TEXT              tap the EditText whose content-desc is LABEL, then type TEXT
  drive.py SERIAL shot PATH                    screenshot (PNG) and the View tree next to it (PATH.xml)
  drive.py SERIAL texts                        print every node's text
  drive.py SERIAL logwait PATTERN SECONDS      succeed when logcat tag hey.api has a line containing PATTERN
"""
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ADB = os.environ.get("ADB", os.path.expanduser("~/Library/Android/sdk/platform-tools/adb"))
serial = sys.argv[1]
cmd = sys.argv[2]
args = sys.argv[3:]


def adb(*a, binary=False):
    out = subprocess.run([ADB, "-s", serial, *a], capture_output=True)
    return out.stdout if binary else out.stdout.decode("utf-8", "replace")


def tree():
    for _ in range(5):
        adb("shell", "uiautomator", "dump", "/sdcard/drive.xml")
        raw = adb("exec-out", "cat", "/sdcard/drive.xml")
        if raw.strip().startswith("<?xml"):
            try:
                return raw, ET.fromstring(raw)
            except ET.ParseError:
                pass
        time.sleep(0.5)
    return "", None


def find(root, text, contains=False, cls=None):
    if root is None:
        return None
    for node in root.iter("node"):
        if cls and node.get("class") != cls:
            continue
        for key in ("text", "content-desc"):
            v = node.get(key) or ""
            if (contains and text in v) or (not contains and v == text):
                m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", node.get("bounds", ""))
                if m:
                    x0, y0, x1, y1 = map(int, m.groups())
                    if x1 > x0 and y1 > y0:
                        return (x0 + x1) // 2, (y0 + y1) // 2
    return None


contains = "--contains" in args
args = [a for a in args if a != "--contains"]

if cmd == "tap":
    _, root = tree()
    at = find(root, args[0], contains)
    if at is None:
        sys.exit("no node with text %r" % args[0])
    adb("shell", "input", "tap", str(at[0]), str(at[1]))
    print("tapped %r at %d,%d" % (args[0], at[0], at[1]))
elif cmd == "wait":
    deadline = time.time() + float(args[1])
    while time.time() < deadline:
        _, root = tree()
        if find(root, args[0], contains):
            print("seen %r" % args[0])
            sys.exit(0)
        time.sleep(1)
    sys.exit("not seen within %ss: %r" % (args[1], args[0]))
elif cmd == "scrollto":
    for _ in range(int(args[1]) if len(args) > 1 else 12):
        _, root = tree()
        at = find(root, args[0], contains)
        if at and 300 < at[1] < 2000:
            print("scrolled to %r at %d,%d" % (args[0], at[0], at[1]))
            sys.exit(0)
        adb("shell", "input", "swipe", "540", "1700", "540", "900", "400")
        time.sleep(1.2)
    sys.exit("not reached by scrolling: %r" % args[0])
elif cmd == "gone":
    deadline = time.time() + float(args[1])
    while time.time() < deadline:
        _, root = tree()
        if root is not None and not find(root, args[0]):
            print("gone %r" % args[0])
            sys.exit(0)
        time.sleep(1)
    sys.exit("still there after %ss: %r" % (args[1], args[0]))
elif cmd == "type":
    _, root = tree()
    at = find(root, args[0], cls="android.widget.EditText")
    if at is None:
        sys.exit("no field %r" % args[0])
    adb("shell", "input", "tap", str(at[0]), str(at[1]))
    time.sleep(0.8)
    adb("shell", "input", "text", args[1])
    print("typed into %r" % args[0])
elif cmd == "shot":
    png = adb("exec-out", "screencap", "-p", binary=True)
    open(args[0], "wb").write(png)
    raw, _ = tree()
    open(args[0] + ".xml", "w").write(raw)
    print("shot %s (%d bytes)" % (args[0], len(png)))
elif cmd == "texts":
    _, root = tree()
    for node in (root.iter("node") if root is not None else []):
        t = node.get("text") or ""
        if t:
            print(t)
elif cmd == "logwait":
    deadline = time.time() + float(args[1])
    while time.time() < deadline:
        log = adb("logcat", "-d", "-v", "tag", "-s", "hey.api:*")
        if args[0] in log:
            print("logged %r" % args[0])
            sys.exit(0)
        time.sleep(1)
    sys.exit("not logged within %ss: %r" % (args[1], args[0]))
else:
    sys.exit(__doc__)
