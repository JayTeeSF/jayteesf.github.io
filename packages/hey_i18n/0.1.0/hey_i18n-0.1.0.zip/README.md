# hey_i18n

Pure catalog/chain internationalization for Hey applications: locale
fallback chains, single-pass `{name}` interpolation, CLDR-shaped plural
categories, whole-page-body token substitution, and catalog-aware
Accept-Language negotiation.

This is an independently versioned third-party Hey package. It is not part
of Hey core or the standard library. It was extracted from a working
prototype built inside the RecallCoach application (see `docs/DESIGN.md`
for the full design record).

## Why the API is pure functions

Hey has no mutable module/global store, so there is no `register_locale()`
side effect. A locale is registered by adding a block to a catalog RECORD
your app builds and passes as an ordinary argument. Every function is
pure: catalog in, chain in, string out. No hidden state, no boot-order
dependency, and everything is testable with a literal record.

## Catalog shape

A catalog is `{locale_code: {key: template_string, ...}, ...}`. The
default language is just another locale in the catalog; the fallback
chain guarantees it as the ultimate fallback.

```hey
import 'hey_i18n:i18n'

let catalog = {
  en: {app_name: 'Demo App', greeting: 'Hello {name}'},
  es: {greeting: 'Hola {name}'},
}
let chain = I18n.chain('es-MX', 'en')            # ['es-MX', 'es', 'en']
I18n.format(catalog, chain, 'greeting', {name: 'Ada'})   # 'Hola Ada'
I18n.t(catalog, chain, 'app_name')               # 'Demo App' (falls through to en)
```

Plural-aware keys live in a SEPARATE plural catalog, keyed the same way,
but each value is a record of CLDR category -> template:

```hey
let plural_catalog = {
  pl: {file_count: {one: '1 plik', few: '{count} pliki', many: '{count} plikow'}},
}
I18n.plural(plural_catalog, I18n.chain('pl', 'en'), 'file_count', 5, {count: 5})
```

## The apostrophe rule

No ASCII apostrophe (`'`, U+0027) in any catalog VALUE, ever — use the
Unicode right single quotation mark (`’`, U+2019) instead, or phrase
without contractions. Catalog entries are single-quoted Hey string
literals, so a literal ASCII apostrophe ends the string early (a syntax
error), and long `'''...'''` heredocs containing one can fail HIR
emission. U+2019 is also the typographically correct character for an
apostrophe in running text (French `l’application`, never
`l'application`), so this rule costs nothing linguistically.

## Development

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
```

## Release and publish

```sh
bin/release
bin/source-zip
bin/publish --no-commit
```

Existing immutable versions must never be replaced.

## Build and release tooling

`hey_packager` is invoked as local build/release tooling through
`bin/release`, `bin/package-zip`, `bin/source-zip`, and `bin/publish`. It
is deliberately not a runtime package dependency and is therefore not
written into application locks.
