# Negative control: remove the manifest-named Activity from optimized dex by
# renaming its type descriptor in place. All type references remain consistent;
# no renderer source is compiled and no production dex is re-optimized.
require 'digest'
require 'zlib'
bytes = File.binread(ARGV.fetch(0))
raise 'not a dex file' unless bytes.start_with?("dex\n")
u32 = ->(offset) { bytes.byteslice(offset, 4).unpack1('V') }
string_count, string_offset = u32.call(56), u32.call(60)
offsets = []
strings = Array.new(string_count) do |i|
  offset = u32.call(string_offset + i * 4)
  offset += 1 while bytes.getbyte(offset) & 0x80 != 0
  offset += 1
  offsets << offset
  bytes.byteslice(offset, bytes.index("\0", offset) - offset)
end
original = 'Lhey/android/api/HeyAndroidApiActivity;'
renamed = 'Lhey/android/api/HeyAndroidApiActivitx;'
index = strings.index(original)
raise 'preserved Activity descriptor missing' unless index
raise 'descriptor rename changes string length' unless renamed.bytesize == original.bytesize
raise 'descriptor rename breaks string table order' unless (index.zero? || strings[index - 1] < renamed) && (index == strings.length - 1 || renamed < strings[index + 1])
type_offset = u32.call(68)
count, offset = u32.call(96), u32.call(100)
matching_definitions = (0...count).count do |i|
  type_index = u32.call(offset + i * 32)
  u32.call(type_offset + type_index * 4) == index
end
raise "expected one preserved Activity definition, got #{matching_definitions}" unless matching_definitions == 1
bytes[offsets[index], original.bytesize] = renamed
bytes[12, 20] = Digest::SHA1.digest(bytes.byteslice(32..-1))
bytes[8, 4] = [Zlib.adler32(bytes.byteslice(12..-1))].pack('V')
File.binwrite(ARGV.fetch(1), bytes)
puts "removed manifest-named Activity definition by descriptor rename #{original} -> #{renamed}; repaired dex signature and checksum"
