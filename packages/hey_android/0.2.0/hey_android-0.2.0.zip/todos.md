# Todo

- Phase 2 (docs/ROADMAP.md): the library entry point request, a C function-pointer call from Hey, the UI-thread hand-off, generated JNI bindings (View tree, Keystore, HTTP), and the media decision.
- x86_64 library for x86 emulators; an AAB with `bundletool validate`.
- Run the 16 KB alignment on a 16 KB kernel (the `_ps16k` system image) instead of checking it statically only.
- Phase 3: the My Queue Android app on the served description, then Android Auto.
