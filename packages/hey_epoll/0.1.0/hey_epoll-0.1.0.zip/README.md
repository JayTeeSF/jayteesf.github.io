# hey_epoll

A batched, edge-triggered TCP event loop for Hey servers. One native call
waits for readiness, accepts every pending connection and reads every readable
socket; the Hey program then takes each connection's unconsumed input as text,
parses its protocol in Hey, and hands back a reply plus the number of bytes it
consumed. Partial and pipelined requests therefore need no state on the Hey side.

- Linux: `epoll` (edge-triggered, `accept4`, `SO_REUSEPORT` for one loop per worker).
- Darwin/BSD: `kqueue`, for development and tests on a Mac. Same API and semantics.

Why it exists: Hey's own networking (`stdlib:Net`, `Io.select`, `Web.serve`)
gives a thread (or a blocking wait) per connection or a poll over every handle
on every call. A server that holds tens of thousands of idle keep-alive
connections on one core needs a readiness set that only reports what changed,
and it needs to batch: one call per wake-up, not one per socket.

## Build the native library

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/build-native
```

Output: `.native-build/<target>/libhey_epoll.{so,dylib}`. Applications build it
outside the immutable installed package, for example into
`.hey/native/hey_epoll/<version>/<target>/`, or point `HEY_EPOLL_LIBRARY` at it.
No libraries beyond libc.

## Use it

```hey
import 'pkg:hey_epoll@0.1.0/epoll'

program
  let loop = Epoll.open('0.0.0.0', 8080, {backlog: 4096}).value
  while true
    let ready = Epoll.wait(loop, 1000)          # connections with new input
    let id = Epoll.next(loop)
    while id >= 0
      let text = Epoll.data(loop, id)           # every unconsumed byte so far
      # ... frame one request of `used` bytes, build `reply` ...
      let sent = Epoll.send(loop, id, used, reply, false)
      set id = Epoll.next(loop)
    end
  end
end
```

| Call | What it does |
|---|---|
| `Epoll.open(host, port, options)` | Listen (IPv4). `backlog` (4096), `reuseport` (false), `library_path`. Raises the process's soft descriptor limit to its hard limit. Result value: `{extension, handle, port, backend}`. |
| `Epoll.wait(loop, timeout_ms)` | The only blocking call. Returns how many connections have unconsumed input (-1 if the loop is gone). Connections the program did not take from the previous batch, and connections left with pipelined bytes after a `send`, are offered again without waiting. |
| `Epoll.next(loop)` | Next connection id of the batch, or -1. Ids carry a generation, so an id of a closed socket never reaches a new one. |
| `Epoll.data(loop, id)` | The connection's unconsumed input as text. Input that is not UTF-8 text (or holds NUL) closes the connection and returns `''`. A UTF-8 sequence split across reads is held back until it is complete. |
| `Epoll.send(loop, id, consumed, text, close_after)` | Drops `consumed` input bytes, writes `text` (queued with write-readiness backpressure if the socket is full), and closes after the write when asked. False when the connection is gone. |
| `Epoll.drop(loop, id)` | Close now. |
| `Epoll.stats(loop)` | Counters: live, accepted, closed, waits, ready, bytes in/out, refusals. |
| `Epoll.close(loop)` | Close every connection, the listener, and unload. |

### Ownership and threads

A loop belongs to the thread that opened it. Each `Epoll.open` loads its own
extension instance, so loops on different workers never share a lock or state.
To use several cores, open one loop per worker with `reuseport: true` on the
same port; the kernel spreads new connections across them.

### Limits

Input per connection is capped at 1 MiB of unconsumed bytes (the connection is
closed beyond that). A connection is closed when its peer closes; requests it
sent but that were not answered yet are dropped with it. Idle connections are
kept until the peer closes them.

## Check

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

`bin/package-check` builds the library, runs `specs/loop_spec.hey` in the
interpreter, runs `tools/serve_receipt.hey` through the ordinary product
compiler, and then rebuilds the library with a deliberate defect (pipelined
input is not offered again) to prove the spec fails on it.
