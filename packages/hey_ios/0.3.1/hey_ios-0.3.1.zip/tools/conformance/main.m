// Runs hey_mobile's conformance vectors against native/HeyIOSValues.m, compiled
// for this Mac: the same source the app compiles, with no UIKit in it.
//
//   conformance <hey_mobile conformance dir> [names|values|descriptions]...
//
// Prints one line per failure and a summary; exits 1 on any failure.
#import <Foundation/Foundation.h>
#import "HeyIOSValues.h"

static id Load(NSString *dir, NSString *name) {
  NSData *data = [NSData dataWithContentsOfFile:[dir stringByAppendingPathComponent:name]];
  return data ? [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingFragmentsAllowed error:nil] : nil;
}

static NSString *Encode(id value) {
  if (value == nil) return @"<omitted>";
  NSData *data = [NSJSONSerialization dataWithJSONObject:@[value] options:NSJSONWritingSortedKeys error:nil];
  NSString *text = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"<unencodable>";
  return [text substringWithRange:NSMakeRange(1, text.length - 2)];
}

static id Null(id value) { return value == [NSNull null] ? nil : value; }

static id Run(NSDictionary *v, NSDictionary *labels) {
  NSString *fn = v[@"fn"];
  id spec = Null(v[@"spec"]);
  id data = Null(v[@"data"]);
  if ([fn isEqualToString:@"render"]) return HeyIOSRender(spec, data, labels);
  if ([fn isEqualToString:@"line"]) return HeyIOSLine(spec, data, labels);
  if ([fn isEqualToString:@"text"]) return HeyIOSText(spec, data, labels);
  if ([fn isEqualToString:@"when"]) return @(HeyIOSCondition(spec, data));
  if ([fn isEqualToString:@"truthy"]) return @(HeyIOSTruthyValue(spec));
  if ([fn isEqualToString:@"value"]) return HeyIOSValue(spec, Null(v[@"vars"]), Null(v[@"row"]));
  if ([fn isEqualToString:@"param"]) return HeyIOSParam(spec, Null(v[@"vars"]), Null(v[@"row"]), data);
  if ([fn isEqualToString:@"path"]) return HeyIOSFillPath(HeyIOSString(spec), Null(v[@"vars"]));
  if ([fn isEqualToString:@"known"]) return @(HeyIOSKnown(v[@"category"], spec, [v[@"level"] integerValue]));
  return @"<unknown fn>";
}

// Booleans from a condition and JSON true must encode the same way.
static NSString *Normal(id value) {
  if ([value isKindOfClass:[NSNumber class]] && !HeyIOSIsBoolean(value) && ([value isEqual:@YES] || [value isEqual:@NO]) && strcmp([value objCType], "c") == 0) {
    return [value boolValue] ? @"true" : @"false";
  }
  return Encode(value);
}

int main(int argc, const char *argv[]) {
  @autoreleasepool {
    if (argc < 2) { fprintf(stderr, "usage: conformance DIR [names|values|descriptions]...\n"); return 64; }
    NSString *dir = [NSString stringWithUTF8String:argv[1]];
    NSMutableSet *parts = [NSMutableSet set];
    for (int i = 2; i < argc; i++) [parts addObject:[NSString stringWithUTF8String:argv[i]]];
    if (parts.count == 0) [parts addObjectsFromArray:@[@"names", @"values", @"descriptions"]];
    NSInteger failed = 0;
    NSMutableArray *summary = [NSMutableArray array];

    if ([parts containsObject:@"names"]) {
      NSDictionary *names = Load(dir, @"names.json");
      NSDictionary *icons = names[@"icons"];
      NSInteger n = 0;
      if (![icons isKindOfClass:[NSDictionary class]] || icons.count == 0) { printf("FAIL names.json has no icons\n"); failed++; }
      for (NSString *name in icons) {
        n++;
        if (![HeyIOSIconTable()[name] isEqualToString:icons[name]]) { printf("FAIL icon %s: native %s, contract %s\n", name.UTF8String, [HeyIOSIconTable()[name] ?: @"missing" UTF8String], [icons[name] UTF8String]); failed++; }
      }
      for (NSString *name in HeyIOSIconTable()) {
        if (icons[name] == nil) { printf("FAIL icon %s is native only\n", name.UTF8String); failed++; }
      }
      NSDictionary *kinds = names[@"file_kinds"];
      for (NSString *kind in kinds) {
        if (![HeyIOSFileKindTable()[kind] isEqualToArray:kinds[kind]]) { printf("FAIL file kind %s\n", kind.UTF8String); failed++; }
      }
      if (kinds.count != HeyIOSFileKindTable().count) { printf("FAIL file kinds differ in number\n"); failed++; }
      [summary addObject:[NSString stringWithFormat:@"icons=%ld", (long)n]];
    }

    if ([parts containsObject:@"values"]) {
      NSDictionary *doc = Load(dir, @"values.json");
      NSArray *vectors = doc[@"vectors"];
      if (![vectors isKindOfClass:[NSArray class]] || vectors.count == 0) { printf("FAIL values.json has no vectors\n"); failed++; }
      for (NSDictionary *v in vectors) {
        id got = Run(v, doc[@"labels"]);
        NSString *gotText = Normal(got);
        NSString *want = [v[@"omitted"] boolValue] ? @"<omitted>" : Encode(v[@"expect"]);
        if (![gotText isEqualToString:want]) { printf("FAIL %s: got %s, want %s\n", [v[@"name"] UTF8String], gotText.UTF8String, want.UTF8String); failed++; }
      }
      [summary addObject:[NSString stringWithFormat:@"values=%lu", (unsigned long)vectors.count]];
    }

    if ([parts containsObject:@"descriptions"]) {
      NSDictionary *doc = Load(dir, @"descriptions.json");
      NSArray *vectors = doc[@"vectors"];
      if ([doc[@"max_bytes"] unsignedIntegerValue] != HeyIOSDescriptionMaxBytes) { printf("FAIL max_bytes: native %lu, contract %s\n", (unsigned long)HeyIOSDescriptionMaxBytes, [[doc[@"max_bytes"] description] UTF8String]); failed++; }
      if ([doc[@"renderer"][@"level"] integerValue] != HeyIOSRendererLevel || ![doc[@"renderer"][@"platform"] isEqualToString:HeyIOSRendererPlatform]) { printf("FAIL the vectors are for another renderer\n"); failed++; }
      for (NSDictionary *v in vectors) {
        NSMutableData *body = [[v[@"body"] dataUsingEncoding:NSUTF8StringEncoding] mutableCopy];
        NSUInteger pad = [v[@"pad_to"] unsignedIntegerValue];
        if (pad > body.length) {
          NSMutableData *spaces = [NSMutableData dataWithLength:pad - body.length];
          memset(spaces.mutableBytes, ' ', spaces.length);
          [body appendData:spaces];
        }
        NSDictionary *parsed = nil;
        NSString *why = HeyIOSDescriptionRefusal(body, Null(v[@"etag"]), &parsed);
        NSString *got = why ? [@"refuse " stringByAppendingString:why] : @"accept";
        NSString *want = [v[@"expect"] isEqualToString:@"accept"] ? @"accept" : [@"refuse " stringByAppendingString:v[@"reason"]];
        if (![got isEqualToString:want]) { printf("FAIL %s: got %s, want %s\n", [v[@"name"] UTF8String], got.UTF8String, want.UTF8String); failed++; }
        if (why == nil && parsed == nil) { printf("FAIL %s: taken without a description\n", [v[@"name"] UTF8String]); failed++; }
      }
      [summary addObject:[NSString stringWithFormat:@"descriptions=%lu", (unsigned long)vectors.count]];
    }

    printf("hey_ios_conformance=%s %s failed=%ld\n", failed == 0 ? "true" : "false", [[summary componentsJoinedByString:@" "] UTF8String], (long)failed);
    return failed == 0 ? 0 : 1;
  }
}
