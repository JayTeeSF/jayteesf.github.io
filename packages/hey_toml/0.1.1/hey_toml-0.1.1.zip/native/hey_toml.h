#ifndef HEY_TOML_H
#define HEY_TOML_H
#include "hey_native_abi.h"
HeyNativeOwnedBytes toml_document(HeyNativeBytesView input,uint32_t input_limit,uint32_t memory_limit,uint32_t output_limit,uint32_t typed);
#endif
