# Done

- v0.1.0 extracted from `hey_ios` (working copy branch `my-queue-carplay-audio`, merged into hey_ios main at 0dc2029): the CarPlay audio scene (`native/HeyIOSCarPlay`), a CPListTemplate of playable rows with a glyph until the artwork arrives, and CPNowPlayingTemplate through `HeyIOSAudio`. It now reads the host's audio feed through `HeyIOSApiHostLoadAudioFeed` and re-reads on `HeyIOSApiHostAudioFeedDidChange`, so `hey_ios` names no CarPlay code.
- `ios-extension.json` for `hey_ios` 0.2.0's `--extension`, held in agreement with `carplay.hey` by `bin/package-check`, which also compiles the scene against the locked `hey_ios` headers.
- v0.1.1 depends on `hey_ios` 0.3.0; no change to the scene.
