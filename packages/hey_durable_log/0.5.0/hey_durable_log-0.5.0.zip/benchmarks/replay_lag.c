#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log.h"

#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* Where a benchmark puts its journal.
 *
 * These hardcoded /tmp. On Linux /tmp is tmpfs -- RAM -- so the barrier being
 * measured was a memcpy, not a device flush: 0.1 us against 6119 us for the
 * same fdatasync on NVMe-backed btrfs, a 60,000x gap. Every "Linux" figure
 * written that way is fiction. It never surfaced on Darwin because /tmp there
 * is APFS, a real disk. Found by the linux actor before recording a number.
 *
 * HEY_DURABLE_LOG_BENCH_PATH names the directory; TMPDIR is honoured next, and
 * /tmp is the last resort. A benchmark must be able to say which filesystem it
 * measured, so this is reported alongside the results. */
static const char *benchmark_directory(void) {
  const char *chosen = getenv("HEY_DURABLE_LOG_BENCH_PATH");
  if (chosen != NULL && chosen[0] != '\0') return chosen;
  chosen = getenv("TMPDIR");
  if (chosen != NULL && chosen[0] != '\0') return chosen;
  return "/tmp";
}

static void benchmark_path(char *out, size_t size, const char *leaf) {
  const char *base = benchmark_directory();
  size_t length = strlen(base);
  while (length > 1 && base[length - 1] == '/') length--;
  snprintf(out, size, "%.*s/%s", (int)length, base, leaf);
}

/* Replay lag: submit to observed, end to end.
 *
 * The number a consumer experiences includes the batch window, the durability
 * barrier AND the cursor cadence -- a cursor snapshots the committed boundary
 * when it opens, so a materializer drains a finite prefix and opens another
 * cursor, and the gap between passes is lag the consumer really waits through.
 * Measuring from "durable" to "read" instead would report a number nobody sees.
 *
 * Each record carries the monotonic nanosecond clock at submit time in its first
 * eight bytes, so the lag is measured against the record itself rather than
 * against a global rate. */

/* nanosleep rather than usleep: usleep is not declared under _POSIX_C_SOURCE
   200809L on glibc, and this must build identically on both platforms. */
static void pause_microseconds(long long microseconds) {
  struct timespec pause;
  pause.tv_sec = (time_t)(microseconds / 1000000);
  pause.tv_nsec = (long)((microseconds % 1000000) * 1000);
  (void)nanosleep(&pause, NULL);
}

static uint64_t monotonic_nanoseconds(void) {
  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);
  return (uint64_t)now.tv_sec * 1000000000ull + (uint64_t)now.tv_nsec;
}

static void put_u64(unsigned char *out, uint64_t value) {
  for (int index = 0; index < 8; index++) out[index] = (unsigned char)(value >> (index * 8));
}

static uint64_t get_u64(const unsigned char *in) {
  uint64_t value = 0;
  for (int index = 0; index < 8; index++) value |= (uint64_t)in[index] << (index * 8);
  return value;
}

typedef struct {
  hdl_broker *broker;
  int operations;
  int failures;
} writer_args;

static void *writer_thread(void *opaque) {
  writer_args *args = opaque;
  for (int index = 0; index < args->operations; index++) {
    unsigned char payload[64];
    memset(payload, 0, sizeof(payload));
    put_u64(payload, monotonic_nanoseconds());
    hdl_record record = {1, payload, sizeof(payload), 1};
    if (hdl_broker_submit(args->broker, &record, NULL) != HDL_OK) args->failures++;
  }
  return NULL;
}

typedef struct {
  hdl_log *log;
  _Atomic int writers_finished;
  uint64_t expected;
  uint64_t *lags;
  uint64_t observed;
  uint64_t passes;
  uint64_t empty_passes;
  /* 1: resume where the last pass stopped. 0: re-open at the origin every pass,
     which is what a consumer had to do before hdl_cursor_open_at existed, and
     what made replay lag grow with the length of the log. */
  int resume;
  uint64_t position;
} reader_args;

static void *reader_thread(void *opaque) {
  reader_args *args = opaque;
  for (;;) {
    hdl_cursor *cursor = NULL;
    hdl_status opened = args->resume ? hdl_cursor_open_at(args->log, args->position, &cursor)
                                     : hdl_cursor_open(args->log, &cursor);
    if (opened != HDL_OK) break;
    uint64_t before = args->observed;
    hdl_cursor_record record;
    while (hdl_cursor_next(cursor, &record) == HDL_OK) {
      if (args->observed >= args->expected) continue;
      /* Without resume, every pass starts at the origin, so what has already
         been accounted for has to be skipped rather than counted twice -- and
         re-walking it is exactly the cost being measured. */
      uint64_t index = record.sequence - 1;
      if (index < args->observed) continue;
      if (record.payload_length >= 8) {
        args->lags[args->observed] = monotonic_nanoseconds() - get_u64(record.payload);
      }
      args->observed++;
      args->position = record.next_position;
    }
    hdl_cursor_close(cursor);
    args->passes++;
    if (args->observed == before) {
      args->empty_passes++;
      if (atomic_load(&args->writers_finished) && args->observed >= args->expected) break;
      pause_microseconds(1000);
    }
    if (args->observed >= args->expected && atomic_load(&args->writers_finished)) break;
  }
  return NULL;
}

static int compare_u64(const void *left, const void *right) {
  uint64_t a = *(const uint64_t *)left;
  uint64_t b = *(const uint64_t *)right;
  return a < b ? -1 : (a > b ? 1 : 0);
}

static double percentile_ms(uint64_t *sorted, uint64_t count, double fraction) {
  if (count == 0) return 0.0;
  uint64_t index = (uint64_t)(fraction * (double)(count - 1));
  return (double)sorted[index] / 1000000.0;
}

int main(int argc, char **argv) {
  int writers = argc > 1 ? atoi(argv[1]) : 8;
  int operations = argc > 2 ? atoi(argv[2]) : 200;
  int max_batch = argc > 3 ? atoi(argv[3]) : 64;
  int window = argc > 4 ? atoi(argv[4]) : 250;
  int capacity = argc > 5 ? atoi(argv[5]) : 256;
  int resume = argc > 6 ? atoi(argv[6]) : 1;
  if (writers <= 0 || operations <= 0) {
    fprintf(stderr, "usage: replay_lag [writers] [operations] [max_batch] [window_us] [capacity] [resume]\n");
    return 2;
  }

  char directory[256];
  {
    char leaf[64];
    snprintf(leaf, sizeof(leaf), "hdl-replay-lag-%d", (int)getpid());
    benchmark_path(directory, sizeof(directory), leaf);
  }
  char command[512];
  snprintf(command, sizeof(command), "rm -rf %s", directory);
  if (system(command) != 0) return 2;

  hdl_log *log = NULL;
  if (hdl_open(directory, NULL, &log) != HDL_OK) {
    fprintf(stderr, "could not open the journal\n");
    return 1;
  }
  hdl_broker *broker = NULL;
  hdl_broker_options options = {(uint32_t)capacity, (uint32_t)max_batch, (uint32_t)window};
  if (hdl_broker_open(log, &options, &broker) != HDL_OK) {
    fprintf(stderr, "could not open the broker\n");
    return 1;
  }

  uint64_t total = (uint64_t)writers * (uint64_t)operations;
  uint64_t *lags = calloc(total, sizeof(*lags));
  if (lags == NULL) return 1;

  reader_args reader = {log, 0, total, lags, 0, 0, 0, resume, 0};
  pthread_t reader_id;
  if (pthread_create(&reader_id, NULL, reader_thread, &reader) != 0) return 1;

  pthread_t *threads = calloc((size_t)writers, sizeof(*threads));
  writer_args *args = calloc((size_t)writers, sizeof(*args));
  uint64_t started = monotonic_nanoseconds();
  for (int index = 0; index < writers; index++) {
    args[index] = (writer_args){broker, operations, 0};
    if (pthread_create(&threads[index], NULL, writer_thread, &args[index]) != 0) return 1;
  }
  int failures = 0;
  for (int index = 0; index < writers; index++) {
    pthread_join(threads[index], NULL);
    failures += args[index].failures;
  }
  uint64_t elapsed = monotonic_nanoseconds() - started;
  atomic_store(&reader.writers_finished, 1);
  pthread_join(reader_id, NULL);

  hdl_broker_stats stats;
  hdl_broker_get_stats(broker, &stats);
  hdl_broker_close(broker);

  uint64_t observed = reader.observed;
  uint64_t half = observed / 2;
  uint64_t *first_half = calloc(half ? half : 1, sizeof(uint64_t));
  uint64_t *second_half = calloc(observed - half ? observed - half : 1, sizeof(uint64_t));
  memcpy(first_half, lags, half * sizeof(uint64_t));
  memcpy(second_half, lags + half, (observed - half) * sizeof(uint64_t));
  qsort(first_half, half, sizeof(uint64_t), compare_u64);
  qsort(second_half, observed - half, sizeof(uint64_t), compare_u64);
  double first_p50 = percentile_ms(first_half, half, 0.50);
  double second_p50 = percentile_ms(second_half, observed - half, 0.50);

  qsort(lags, observed, sizeof(uint64_t), compare_u64);
  printf("writers=%d operations=%d max_batch=%d window_us=%d capacity=%d reader=%s\n",
         writers, operations, max_batch, window, capacity,
         resume ? "resuming" : "from-the-origin");
  printf("records=%llu observed=%llu failures=%d elapsed=%.3f ms throughput=%.0f records/s\n",
         (unsigned long long)total, (unsigned long long)observed, failures,
         (double)elapsed / 1000000.0,
         (double)total / ((double)elapsed / 1000000000.0));
  printf("replay_lag p50=%.3f ms p95=%.3f ms p99=%.3f ms max=%.3f ms\n",
         percentile_ms(lags, observed, 0.50), percentile_ms(lags, observed, 0.95),
         percentile_ms(lags, observed, 0.99), percentile_ms(lags, observed, 1.0));
  printf("replay_lag first_half_p50=%.3f ms second_half_p50=%.3f ms growth=%.2fx\n",
         first_p50, second_p50, first_p50 > 0.0 ? second_p50 / first_p50 : 0.0);
  printf("cursor_passes=%llu empty_passes=%llu\n",
         (unsigned long long)reader.passes, (unsigned long long)reader.empty_passes);
  printf("max_queue_depth=%u queue_capacity=%u durable_batches=%llu largest_batch=%u\n",
         stats.max_queue_depth, options.queue_capacity,
         (unsigned long long)stats.durable_batches, stats.largest_batch);

  hdl_close(log);
  snprintf(command, sizeof(command), "rm -rf %s", directory);
  if (system(command) != 0) return 2;
  free(first_half);
  free(second_half);
  free(lags);
  free(threads);
  free(args);
  return 0;
}
