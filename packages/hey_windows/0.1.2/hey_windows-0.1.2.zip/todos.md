# Todos

- User-agent suffix and application icon (ROADMAP 2).
- Authenticode signing and winget or MSIX distribution (ROADMAP 3).
- Native hey_mobile rendering when Hey targets Windows (ROADMAP 4).
- A real-PC receipt recorded in docs/TESTING.md once the owner runs one.
- Sign in on real Windows and reopen, to prove the session persists in %LOCALAPPDATA%\MyQueue.
