# hey_ios

Apple-specific capability contracts layered under `hey_mobile`. This first slice declares UIKit lifecycle hosting, Keychain, LocalAuthentication, protected files, AVFoundation QR scanning, URLSession, Apple frameworks, and entitlement metadata. Native adapters remain opaque; no Keychain item, LAContext, key, or UIKit object crosses into ordinary Hey values.

Compiler/SDK/sign/install/launch porcelain for ordinary Hey iOS apps remains in the Hey language repository under `hey mobile ios ...`.

## A level-2 renderer with served descriptions (0.3.0)

`hey_mobile` 0.3.0 lets a server send an app its screens. This host is a renderer at level 2 of that contract (`api-renderer.json`; `docs/RENDERERS.md` in hey_mobile):

- **Served, stored, baked.** On launch it draws the last good served copy this build stored, else the baked copy, at once. On launch and on every return to the foreground it asks the description's `served` route (`?platform=ios&level=2`, `If-None-Match` the copy in hand, no credentials) and draws a new copy it takes when nothing is in progress. A network failure, an error status or a refused body changes nothing. The origin, the session header and checks, the Keychain service and the url scheme always come from the baked copy.
- **Hide what you do not know.** An unknown screen type, section, action, field or row kind is not drawn, and no action it does not recognise sends a request.
- **One evaluator.** `native/HeyIOSValues.{h,m}` (Foundation only) holds the value language, the kinds, icon and file-kind names and the rules for taking a served body. `bin/conformance` compiles it for this Mac and runs hey_mobile's `conformance/` vectors against it, with a negative control; `bin/package-check` runs it.
- The Hey shell may export `fn ios_app_origin()`: the origin, baked beside a description whose bytes are the server's.

## The native host for api_screens apps (0.2.0)

An app described with `hey_mobile` 0.2.0 `api_screens` runs on iPhone through this package. Nothing here names a product, a route or a service: the description decides every screen and request.

| file | what it is |
|---|---|
| `native/HeyIOSApiHost.{h,m}` | the renderer: tabs, lists, forms, search with polling, sign-in, deep links, document upload, video, web links, badges, the Listen tab, and the served description |
| `native/HeyIOSValues.{h,m}` | the value language, kinds, names and served-description rules, Foundation only |
| `native/HeyIOSKeychain.{h,m}` | the session token, readable after first unlock |
| `native/HeyIOSAudio.{h,m}` | playback through AVQueuePlayer (pages in order, resume, position reports) or Apple Music, Now Playing and remote commands |
| `native/HeyIOSShareController.{h,m}` | a share extension that saves a link through the description's share route |
| `audio.hey` | the audio capability contract (background mode, session category, Info.plist keys) |
| `tools/hey-ios-api-app.sh` | compiles the Hey shell through the LLVM lane (no Hey runtime linked), links the host, builds the share extension and icon, signs, installs on a simulator or a paired iPhone |

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
  "$HEY_IOS/tools/hey-ios-api-app.sh" --source ios/app.hey --out build/ios \
  --bundle-id com.example.app --display-name 'Example' --share-extension \
  --url-scheme example --icon-png build/AppIcon-1024.png [--sim-udid UDID]
# a paired iPhone: --device-udid ID --sign-identity "Apple Development: ..." --profile P --extension-profile P
```

The Hey shell exports `fn ios_app_manifest()` (the description as a literal string) and `fn ios_action_code(0)` (its byte length).

### Extensions (`--extension DIR`)

Another package adds native code to the app through `DIR/ios-extension.json`: sources compiled beside the host, frameworks, entitlements (linked into a simulator build, carried on a device only when the profile grants them) and scene declarations for Info.plist. The host configures any scene role other than the phone's window from that declaration, and a scene reads the audio feed with `HeyIOSApiHostLoadAudioFeed`, re-reading on `HeyIOSApiHostAudioFeedDidChange`. `hey_carplay` (the CarPlay audio scene) is the first extension. `--with carplay` from the unpublished working copy is gone.

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_ios`.
