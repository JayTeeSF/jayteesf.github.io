# Continue hey_kqueue

Read README.md, docs/README.md, todos.md, done.md, hey.native.json, the
native source and the specs before editing.

hey_kqueue is an independent package: the kqueue backend (macOS and the BSDs)
behind the same API as hey_epoll's Epoll. Hey owns the generic native ABI,
loader and package plumbing; this package owns the event loop. Keep handles
opaque, blocking calls honest (`wait` is the only blocking function), one loop
per thread, and the API name-for-name equal to Epoll so hey_poller can swap it.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
bench/macos            # keep-alive HTTP comparison (wrk)
```

Published versions are immutable. Change the version whenever released bytes change.
