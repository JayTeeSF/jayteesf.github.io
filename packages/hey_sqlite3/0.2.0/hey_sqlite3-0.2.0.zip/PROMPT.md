# Continue hey_sqlite3

Read README.md, docs/DESIGN.md, goals.md, in-progress.md, todos.md, done.md, manifests, implementation files, and specs before editing.

This is an independent SQLite package. Hey owns generic FFI/loader/package plumbing; this package owns SQLite behavior and releases. Keep native handles opaque, blocking calls honest, and statements finalized deterministically.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

Published versions are immutable. Change the package version whenever released bytes change.

## Files the next LLM needs

For focused work, upload:

1. the latest full Hey source ZIP (`hey-lang-bootstrap-plan-v0.99.268a(1).zip` or newer);
2. this package's latest source/release ZIP (`hey_sqlite3-0.2.0.zip`).

For coordinated adapter/porcelain work, upload `hey_database-stack-v0.2.0.zip` instead of the individual package ZIP; it already contains all three packages, release metadata, cross-package verification, language findings, and the roadmap.
