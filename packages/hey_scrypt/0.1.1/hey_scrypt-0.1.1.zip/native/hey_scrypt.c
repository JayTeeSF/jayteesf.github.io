#include "hey_scrypt.h"
#include <openssl/evp.h>
#include <openssl/crypto.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
static void release(void *ctx,uint8_t *p,size_t n){(void)ctx;OPENSSL_cleanse(p,n);free(p);}
static int hexval(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;return -1;}
static int component(const char **p,uint64_t *out){
  uint64_t n=0;unsigned digits=0;
  while(**p&&**p!='$'){int h=hexval(**p);if(h<0||++digits>16||n>(UINT64_MAX-(unsigned)h)/16)return 0;n=n*16+(unsigned)h;(*p)++;}
  if(!digits||**p!='$')return 0;(*p)++;*out=n;return 1;
}
HeyNativeOwnedBytes scrypt_hash(HeyNativeBytesView secret,HeyNativeUtf8View salt_view,uint32_t key_len,uint64_t max_memory){
  HeyNativeOwnedBytes no={0};char salt[128];if(!salt_view.data||salt_view.length>=sizeof(salt)||memchr(salt_view.data,0,salt_view.length))return no;memcpy(salt,salt_view.data,salt_view.length);salt[salt_view.length]=0;if(!secret.data||secret.length>16384||key_len<16||key_len>512||max_memory<1048576||max_memory>1073741824)return no;
  if(strnlen(salt,128)>=128)return no;
  const char *p=salt;uint64_t n,r,parallel;
  if(!component(&p,&n)||!component(&p,&r)||!component(&p,&parallel)||n<2||(n&(n-1))||n>16777216||r<1||r>1024||parallel<1||parallel>1024)return no;
  size_t hex_len=strlen(p);if(hex_len<16||hex_len>64||hex_len%2||hex_len==40)return no;
  uint8_t raw_salt[32],key[512];size_t salt_len=hex_len/2;
  for(size_t i=0;i<salt_len;i++){int a=hexval(p[i*2]),b=hexval(p[i*2+1]);if(a<0||b<0)return no;raw_salt[i]=(uint8_t)(a*16+b);}
  /* The compatible modern format strips whole leading 00 salt pairs. */
  size_t skip=0;while(skip<salt_len&&raw_salt[skip]==0)skip++;
  if(EVP_PBE_scrypt((const char*)secret.data,secret.length,raw_salt+skip,salt_len-skip,n,r,parallel,max_memory,key,key_len)!=1){OPENSSL_cleanse(key,sizeof(key));return no;}
  size_t prefix_len=strlen(salt),length=prefix_len+1+key_len*2;uint8_t *out=malloc(length+1);
  if(!out){OPENSSL_cleanse(key,sizeof(key));return no;}
  memcpy(out,salt,prefix_len);out[prefix_len]='$';const char *hex="0123456789abcdef";
  for(size_t i=0;i<key_len;i++){out[prefix_len+1+i*2]=(uint8_t)hex[key[i]>>4];out[prefix_len+2+i*2]=(uint8_t)hex[key[i]&15];}out[length]=0;
  OPENSSL_cleanse(key,sizeof(key));return(HeyNativeOwnedBytes){out,length,release,NULL};
}
