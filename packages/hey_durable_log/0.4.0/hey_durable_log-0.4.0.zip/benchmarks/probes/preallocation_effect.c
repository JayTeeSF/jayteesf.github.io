#define _DARWIN_C_SOURCE 1
#define _POSIX_C_SOURCE 200809L
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static double ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000.0+t.tv_nsec/1e6;}
#ifdef __APPLE__
static int barrier(int fd){return fcntl(fd,F_FULLFSYNC,0);}
static const char*bname="F_FULLFSYNC";
#else
static int barrier(int fd){return fdatasync(fd);}
static const char*bname="fdatasync";
#endif
static void bench(const char*label,int preallocate){
  char path[]="/tmp/pa-XXXXXX"; int fd=mkstemp(path); if(fd<0){perror("mkstemp");return;}
  char buf[128]; memset(buf,'x',sizeof buf);
  size_t total=(size_t)128*400;
  if(preallocate){
#ifdef __APPLE__
    fstore_t st={F_ALLOCATECONTIG|F_ALLOCATEALL,F_PEOFPOSMODE,0,(off_t)total,0};
    if(fcntl(fd,F_PREALLOCATE,&st)==-1){st.fst_flags=F_ALLOCATEALL;fcntl(fd,F_PREALLOCATE,&st);}
#endif
    if(ftruncate(fd,(off_t)total)!=0) perror("ftruncate");
    barrier(fd);
  }
  for(int i=0;i<5;i++){ if(write(fd,buf,sizeof buf)<0){} barrier(fd);} /* warm */
  if(preallocate) lseek(fd,0,SEEK_SET);
  int n=100; double t0=ms();
  for(int i=0;i<n;i++){ if(write(fd,buf,sizeof buf)<0){} barrier(fd);}
  double el=ms()-t0;
  printf("%-34s %6.3f ms/op  %8.0f ops/s\n",label,el/n,n/(el/1000.0));
  close(fd); unlink(path);
}
int main(void){
  printf("barrier = %s\n",bname);
  bench("append (file EXTENDS each write)",0);
  bench("in-place (file PREALLOCATED)",1);
  return 0;
}
