# Done

## 0.4.8: outgoing artwork and exact messages (2026-10-29)

The action `share_result` and form `on_success.share` paths share the same
response reader. A plain URL can be enriched by `share_presentation` only when
its URL matches exactly, preserving a usable link for older renderers. The
Activity preserves multiline message text and appends the canonical URL. HTTPS
artwork reuses the picture cache and is encoded off the UI thread into a private
PNG cache; ACTION_SEND carries its content URI, ClipData and temporary read grant.
The provider rejects writes and paths outside that cache. Missing artwork keeps
the text and link. Renderer level remains 1.

Verification: the host renderer suite passes 112 checks and mutation controls.
`specs/api_renderer_share_spec.sh` captures the real Activity's chooser payload on
a disposable API 36 emulator, opens the PNG through ContentResolver and checks
permissions, path rejection and the plain-text fallback. Its baseline failed
because EXTRA_STREAM was missing; the updated renderer passes.


- v0.1.0 package boundary, modules, tests, toolchain installer, emulator/device launcher, docs, packaging, and LLM handoff.
- Fixed the macOS installer so `sdkmanager` and `avdmanager` share the same exported Android SDK root before AVD creation.
- Fixed AVD creation by installing Android command-line tools inside the selected SDK and invoking those SDK-local binaries; Homebrew's avdmanager no longer resolves packages from its separate root.


The Android runtime build now selects the core-supported HEY_NO_FAST_TLS pthread-slot implementation for its dlopened shared library. On 605a the unchanged runtime passes the native emulator gate: clean startup/relaunch, reference bytes, SHA vectors, platform capabilities, and runtime-error/exit controls. This removes the earlier initial-exec TLS startup blocker without editing core sources.

## Unreleased (2026-10-23): no Python; why native programs die on the emulator

Nothing in `bin/`, `specs/` or `tools/` runs Python any more, and `bin/package-check` fails if anything does. The emulator driver, the screen reader and the two fixture servers are Ruby (`specs/support/drive.rb`, `screen.rb`, `fake_api_server.rb`, `fake_inbox_server.rb`, with `fixture_http.rb` as their HTTP/1.1 server); the receipts, JSON fields, IR scans and the test PNG are Ruby run as `HEY_ANDROID_RUBY` (`tools/android-env.sh`). The hey_packager controls are 0.1.12's, and `hey.lock.json` pins hey_packager 0.1.12 with relative paths. The renderer emulator specs pass with the Ruby helpers (56 and 9 checks).

The 10 native-program failures seen since 0.4.4 are a Hey runtime defect, not this package's. Hey core c9ea28a0e (2026-10-10) declares `hey_alloc_shard_tls` and `hey_box_pool_tls` with the initial-exec TLS model on every ELF target. On Android the runtime lives in `libhey_app.so`, which NativeActivity loads with dlopen, and bionic refuses initial-exec TLS in a dlopened library: logcat says `dlopen failed: TLS symbol "(null)" ... using IE access model`, then `UnsatisfiedLinkError` (the two crash markers). `program says 1 end` fails the same way. Built with `-DHEY_NO_FAST_TLS=1` (a scratch copy, not committed), hello_runtime runs and ends cleanly. Release waits on the runtime choosing the thread-specific slot on Android.

## 0.4.4 (2026-10-13): an empty search says "nothing" once

A search whose answered sections each show their own `empty` text no longer adds "No results for ..." under them (a two-section search said it three ways). `Screens.noResults(screen, json, query)` returns the screen's own `empty` when it has one, nothing when every asked section says its own, else the query named. ModelMain checks both halves; the emulator spec expects the shelf section's own empty text and no repeat under it. Matches hey_ios 0.4.10.

Not yet published: on 2026-10-13 `bin/check` also had 10 failures that the unchanged 0.4.3 tree has too -- compiled Hey programs (hello_runtime, runtime_error, rows) exit on the emulator before reporting their end (crash_markers=2) -- so publishing waits on that.

## 0.4.3 (2026-10-07): a list that has not loaded yet no longer says it is empty

Seen on a Nexus 5X just after a restart: Library said "Nothing in this Library
view. Change Filter / Sort, or use Add." for several seconds while 582 rows were
on their way. A `fields` or `from` section read the screen's answer before it
arrived, found nothing, and said its `empty` text. Route sections already said
nothing until answered; now these do too (`Screens.list`). Answered with nothing,
they still say it. Gated by ModelMain 8 and its mutation control
`unanswered-says-empty`.

## 0.4.2 (2026-10-07): a search screen's keyboard, and where a search stands

Not a version: VERSION stays 0.4.1 until the Maintainer releases it.

- Measured on the API 36 emulator against a local API backend, before the
  fix: after the search key the keyboard stayed up attached to no field (typing
  went nowhere), because every answer rebuilt the box; emptying the box left it
  up; a tap on the empty screen did nothing; opening Account with it up kept it
  up, and Back there navigated instead of hiding it. System Back on a tab root
  did hide it (the platform's own IME callback).
- The search box is pinned above the scrolling body and made once per page, so
  a redraw keeps its focus and text. Cancel beside it whenever it has focus or
  text (it clears and hides the keyboard); the search key hides it; a touch
  below the box (a tap or the start of a drag) hides it; the keyboard going away
  on its own takes the focus with it; and any change of screen hides it and
  clears focus, so returning to a search screen never raises it.
- Tab stacks were measured and are NOT the iOS bug here: `selectTab` empties
  the stack, so a tab shows its root and Account is never kept on it.
- Where a search stands, from `Screens.searchState`: a spinner and "Searching
  for “q”…" while any section is unanswered or still pending; "No results for
  “q”." (or the screen's own `empty`) when every section answered with nothing;
  "The search did not finish." with Try again when one failed and nothing was
  found, and a failed section's error drawn in red. A pending section out of
  polls now shows its `gave_up_note` (as hey_ios does) instead of looking busy
  for ever. Clearing the box starts a new generation, so late answers and polls
  for the old query are dropped.
- `specs/api_renderer_emulator_spec.sh` section 7 drives the fixture's Later tab
  (now with a search section, an Account button and a `POST /v1/search` in the
  fake server); `ModelMain` section 7 checks the search states, with three new
  mutation controls in `specs/api_renderer_host_spec.sh`. Run against the
  unfixed renderer the new emulator checks fail on Cancel, the search key, tap
  outside, drag and all four search states.

## 0.4.1 (2026-09-30): complete immutable renderer archive

- `hey-package.json` now carries all 19 renderer files used by source-root
  builds. Published 0.4.0 omitted `HeyAndroidAudioService`,
  `HeyAndroidPictures`, `HeyAndroidPlayback`, and `HeyAndroidPlayer`, so an
  installed package could not compile `HeyAndroidApiActivity` even though the
  source checkout passed its renderer gate.
- `specs/package_manifest_spec.sh` compares the real renderer tree with the
  package manifest. It failed on those four omissions before the fix and now
  prevents source-root-only files from escaping future immutable releases.

## 0.3.0 (2026-09-13): Views drawn by a Hey program, and a tap, with no Java in any form

- Measured first: on NativeActivity, Views set with `setContentView` are laid
  out but never drawn while NativeActivity holds the window's surface. After
  `getWindow().takeSurface(null)` through JNI they draw.
- Measured: `Native.open` of the app's own `libhey_app.so` works on the device,
  by soname and by the `dladdr` path.
- `native/ui`: five C shims declared in `hey.native.json` and wrapped by
  `hey native`: `begin`, `text_row`, `commit`, `next_event` (`thread_safe`)
  and `errors`. Every JNI call runs on the UI thread through an `ALooper` pipe;
  the UI thread never waits on Hey.
- Taps with no dex: NativeActivity's input queue, hit-tested against the rows'
  View bounds, queued as `{"kind":"tap","id":"row-3"}`.
- `src/android_ui.hey` (`HeyAndroidUi`) and `examples/rows.hey`: a `program`
  that loops on `next_event`, draws rows and shows "Row N was tapped".
  `examples/rows_error.hey` fails in the loop on purpose.
- The glue attaches the shims, forwards the input queue, and ends the process
  once the program and the activity are both gone, in either order. The
  manifest uses a light theme with no action bar.
- `tools/hey-android-app.sh --ui` waits for the first commit instead of the
  program's end; the receipt records commits and views on screen.
  `HEY_ANDROID_NEGATIVE_CONTROL=surface-taken` builds the drawing control.
- New specs, each check with a negative control:
  `specs/android_ui_host_spec.sh` (the Hey side on the Mac against
  `specs/support/fake_ui.c`) and `specs/android_ui_emulator_spec.sh` (pixels
  drawn, a tap changes the text, rotation, a second launch, an error in the
  loop, no dex).
- Docs: `docs/ROADMAP.md` corrects phase 2 (no library entry point or function
  pointer needed; the Proxy idea was wrong; no attach rule while JNI stays on
  the UI thread). It records the Maintainer's rule of no Java in any form, and
  what that rule costs on Android. It also lists the LLVM-lane miscompiles found
  while building the slice. `docs/PHASE2_FEASIBILITY.md` is committed with the
  withdrawn in-memory dex plan marked.

## 0.2.0 (2026-09-13): a Hey program with the runtime, on Android 16, with no Java or Kotlin

- `tools/hey-android-app.sh` builds a Hey program into a signed APK:
  - heyc's LLVM IR, compiled by NDK r28 clang for `aarch64-linux-android35`;
  - the unmodified Hey runtime from HEY_ROOT with the package's Android profile;
  - one 16 KB-aligned library;
  - aapt2, zipalign `-P 16` and apksigner.
  - The manifest has `hasCode="false"` and uses `android.app.NativeActivity`.
  - It installs and launches with adb, then writes a receipt.
- `native/glue`, the entry point:
  - the program runs on an 8 MiB thread, and so do the runtime's own threads;
  - stdout and stderr go to logcat;
  - `exit()` finishes the activity;
  - one program per process.
- `native/runtime_profile` gives the runtime real secure random, constant-time
  compare and SHA-256 (vendored from Brad Conte, public domain) through its
  platform-crypto seam. TLS, AEAD, scrypt and Argon2id report named
  unavailable errors.
- Build isolation:
  - every compiler-search variable is cleared, and `PATH` is reduced;
  - the include search path goes into the receipt, and any host directory
    fails the build.
- `bin/android-doctor` checks and prints the new pins and the Hey checkout's
  identity: platform 36, build-tools 36.0.0, NDK 28.2.13676358, the API 36
  Play image, JDK 17. It fails with the exact sdkmanager line for anything
  missing.
- `tools/hey-android-emulator.sh` owns the dedicated AVD `hey_android_API_36`:
  - it boots headless;
  - it shuts down and waits until no emulator process remains.
- `bin/check` runs the Hey specs and five shell specs: pins, SHA-256 on the
  host, the doctor, the build lane and the emulator. Every check has a
  negative control:
  - a Mac target triple is refused;
  - a Homebrew-contaminated runtime is caught;
  - a 4 KB library is refused;
  - a dex in the APK is refused;
  - `hasCode="true"` is refused;
  - a wrong digest fails;
  - an API 34 SDK is refused;
  - a build linked without `--wrap=exit` fails.
- On the emulator:
  - `hello_runtime`'s logcat output equals the Mac run byte for byte;
  - the NIST vectors pass through the runtime;
  - a runtime error ends the activity with no crash.
- Removed the Gradle lane: `tooling/01-*`, `tooling/02-*` and their spec, with
  the API 34, AGP 8.5.2 and NDK 26.1 pins.

## 0.4.0 (2026-09-14): a native renderer for served screens, level 1

- The Maintainer withdrew the no-Java rule; `docs/ROADMAP.md` records it and
  keeps the no-Java cost table as the record of the JNI-only route.
- `renderer/`: a Java renderer for hey_mobile api_screens descriptions at level
  1, platform android, mirroring hey_ios's HeyIOSApiHost and HeyIOSValues.
  Pure layer (`Json`, `Values`, `Descriptions`, `Names`, `Screens`, `Actions`)
  with no Android import; Android layer (`HeyAndroidApiActivity`,
  `HeyAndroidHttp`, `HeyAndroidSecureStore`, `HeyAndroidDescription`).
- Served, stored, baked with ETag and If-None-Match; baked-only origin and
  session keys; unknown and undrawn kinds hidden and never sent; the token
  sealed with an Android Keystore key in the no-backup directory.
- `tools/hey-android-api-app.sh`: javac, d8, aapt2, zipalign, apksigner, no
  Gradle; refuses a baked description the renderer refuses.
- hey_mobile 0.3.1's conformance vectors vendored and passing (117 values,
  names, 21 descriptions), with eleven mutation controls.
- New specs: `specs/api_renderer_host_spec.sh` and
  `specs/api_renderer_emulator_spec.sh` (fake server, sign-in, list, detail,
  back, kept session, sign-out, served/stored/baked).
- Measured by hand against a local API backend on the API 36 emulator:
  sign in, the seeded library, an item, back, sign out.

## 0.4.5: sharing and header image links

The level-1 renderer now draws `choose` actions. It combines literal options
with a `choices` route's `list`, `value`, `label` and `where` mapping, asks for
one recipient, then any optional prompt, and sends `$value`, `$value_title`
and the entered fields. Cancel at either dialog sends no write.

A successful request with `share_result` resolves that path in the response
and presents Android's system share sheet (`ACTION_SEND`, `text/plain`) with
the HTTP(S) link. The action's `then` still runs, including `reload`; the
recipient and note have already reached the server before the sheet opens.
Absent, malformed or non-HTTP(S) links do not launch the share sheet, and
request failures do not navigate or share.

`header.image_open_url` resolves against the screen response independently of
`header.image`. A valid HTTP(S) content URL makes the header image focusable
and accessible as “Open <title>”; tapping opens that URL. Missing or invalid
content URLs leave the picture inert.

The declared renderer level stays **1**. Servers continue fitting level-3
`choose_many` to their authored single-choice `instead`; multiple selection,
remote chooser search and form lookup offers are not claimed by this build.

### Verification on 2026-10-15

Renderer host rules, shared conformance vectors, mutation controls, debug APK
and signed release APK/AAB gates passed. The full emulator run passed sharing,
notes, cancellations, reloads and delayed-response lifecycle checks. Its header
assertion originally depended on Chrome's first-run task state; the same header
check now uses a test-only intent receiver. The focused rerun passed both the
exact ACTION_VIEW content URL and the loaded invalid-URL inert-image control,
then restored the browser role and shut down the emulator.

`bin/check` completed with 135 passing checks, 67 passing negative controls and
11 failures: that replaced header harness assertion plus these ten failures in
the native Hey lane, the same runtime family already documented for 0.4.4:

- hello_runtime did not run cleanly;
- hello_runtime logcat output differed from the Mac;
- the 8 MiB program-thread stack marker was absent;
- the second hello_runtime launch did not repeat Mac output;
- SHA-256 emulator vectors did not pass;
- Android capability answers differed;
- runtime_error did not end cleanly;
- runtime_error output differed from the Mac;
- the surface-taken negative-control build did not commit a screen;
- rows did not commit a screen.

The native programs exit before their end markers with crash_markers=2. This
slice does not change that lane. No package release or publication was made
from the red full gate; the checked renderer source is available for the app
build. The full package gate was not repeated after the isolated harness fix.

## 0.4.7 (2026-10-20): a kept session enters the app

`then: 'signed_in'` (an action's or a form's `on_success.then`) now leaves the signed-out screens for the signed-in app (`Actions.Host.signedIn()`, the Activity's `signedInWith` with the session `keep_token` already stored). Before, it fell through to a reload, so after making an account from a public queue or set the recovery-code screen's Continue did nothing until the app was restarted. ModelMain 3b, which fails (`[reload]`) without it; `specs/api_renderer_host_spec.sh` 109 passed. Matches hey_ios, which already had it.

## 0.4.6 (2026-10-20): displayed text can be copied whole; long shared messages are not cut off

Static content text (`text(...)`: titles, header lines, detail fields such as description, note, message and tags) is natively selectable, and a long press selects the whole value rather than the word under the finger, so one Copy takes a full multi-word title into search. The platform handles still narrow the selection, and the Copy/Share toolbar is Android's own. Controls (Back, Account, tabs, Cancel, choice fields) opt out so their short taps still work; tappable rows forward short taps through their selectable text. `specs/api_renderer_text_selection_spec.sh` holds the source contract (15/15). On a disposable Pixel 7 API 36 AVD the emulator spec long-presses the title and four synthetic fields, copies, pastes each into Later and checks the search state and request (56/56 overall).

Also merged: shared conversation messages are drawn in full (`detail_multiline`), with `specs/api_renderer_inbox_emulator_spec.sh` (9/9) proving a long multi-paragraph reply scrolls to its last sentence and the unread marker clears after reading.

## 0.4.9 implementation

Parsed media origins and a redirect-refusing range source replace prefix credential matching. Session changes discard playback, car feed/metadata and pending callbacks; watcher teardown uses stable identities. The renderer loads only bundled definitions and has no remote UI fetch/cache/merge path. `docs/SECURITY-BOUNDARIES.md` describes the credential, identity and bundled-definition contracts and their focused tests.

## 0.4.10 saved-response sharing implementation

The app may declare share_retry_title for an exact successful form response that can be shared again without repeating its request. Native image preparation no longer waits behind thumbnails, is visibly bounded, and cannot present stale/duplicate choosers. `docs/REPLY-SHARING.md` describes the response protocol and focused form/presentation regression tests.
