#define _POSIX_C_SOURCE 200809L

/* Gate for the portable barrier the broker group-commit test depends on.
 *
 * The broker gate proves "fewer durable batches than records", and it can only
 * prove it if the writer threads genuinely contend -- which is the barrier's
 * whole job. A barrier that released early would leave that gate passing on
 * timing luck instead of on group commit, so the barrier gets its own gate.
 *
 * Invariant: no thread leaves cycle N until every thread has entered cycle N,
 * and the barrier holds that across repeated reuse, not just the first cycle.
 */

#include "test_barrier.h"

#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>

enum { THREADS = 8, ROUNDS = 64 };

typedef struct {
  hdl_test_barrier *barrier;
  atomic_int *arrived;
  int failures;
} barrier_args;

static void fail(const char *message) {
  fprintf(stderr, "barrier test failure: %s\n", message);
  exit(1);
}

static void *participant(void *opaque) {
  barrier_args *args = opaque;
  for (int round = 0; round < ROUNDS; round++) {
    atomic_fetch_add(args->arrived, 1);
    if (hdl_test_barrier_wait(args->barrier) != 0) {
      args->failures++;
      return NULL;
    }
    /* Every participant of this round has incremented; none can have started
     * the next round, because that requires passing the second wait below. */
    int observed = atomic_load(args->arrived);
    if (observed != THREADS * (round + 1)) args->failures++;
    if (hdl_test_barrier_wait(args->barrier) != 0) {
      args->failures++;
      return NULL;
    }
  }
  return NULL;
}

int main(void) {
  hdl_test_barrier barrier;
  if (hdl_test_barrier_init(&barrier, THREADS) != 0) fail("init barrier");
  atomic_int arrived = 0;
  pthread_t threads[THREADS];
  barrier_args args[THREADS];
  for (int index = 0; index < THREADS; index++) {
    args[index] = (barrier_args){&barrier, &arrived, 0};
    if (pthread_create(&threads[index], NULL, participant, &args[index]) != 0) fail("create participant");
  }
  for (int index = 0; index < THREADS; index++) {
    pthread_join(threads[index], NULL);
    if (args[index].failures != 0) fail("barrier released a thread before every thread arrived");
  }
  if (hdl_test_barrier_destroy(&barrier) != 0) fail("destroy barrier");
  if (atomic_load(&arrived) != THREADS * ROUNDS) fail("barrier lost a cycle");
  printf("PASS: portable barrier holds every cycle\n");
  return 0;
}
