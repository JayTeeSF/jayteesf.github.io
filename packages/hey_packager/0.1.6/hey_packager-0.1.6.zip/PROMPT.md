# Continuation prompt

Maintain `hey_packager` as an independently versioned third-party Hey package.
Every change must update VERSION, `hey-package.json`, tests, README, all public
docs, roadmap/status files, package archive, website publication payload, source
handoff, and command `--help`. Never move the default website path into Hey core.
