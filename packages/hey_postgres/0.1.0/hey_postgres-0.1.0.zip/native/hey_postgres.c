#include "hey_postgres.h"
#include <libpq-fe.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* A growable, owned parameter buffer for PQexecParams. Each value is either a
 * NUL-terminated C string (text format) or NULL for a SQL NULL. */
typedef struct {
  char **values;
  int count;
  int capacity;
} HeyPgParams;

static char *hey_pg_c_string(HeyNativeUtf8View value) {
  char *out = (char *)malloc(value.length + 1);
  if (!out) return NULL;
  if (value.length && value.data) memcpy(out, value.data, value.length);
  out[value.length] = '\0';
  return out;
}

static PGconn *hey_pg_conn(HeyNativeHandle value) { return (PGconn *)(uintptr_t)value; }
static PGresult *hey_pg_result(HeyNativeHandle value) { return (PGresult *)(uintptr_t)value; }
static HeyPgParams *hey_pg_params(HeyNativeHandle value) { return (HeyPgParams *)(uintptr_t)value; }

static HeyNativeUtf8View hey_pg_view(const char *s) {
  if (!s) return (HeyNativeUtf8View){"", 0};
  return (HeyNativeUtf8View){s, strlen(s)};
}

/* ---- connection ---- */
HeyNativeHandle hey_postgres_connect(HeyNativeUtf8View conninfo) {
  char *c = hey_pg_c_string(conninfo);
  if (!c) return (HeyNativeHandle)0;
  PGconn *conn = PQconnectdb(c);
  free(c);
  return (HeyNativeHandle)(uintptr_t)conn;
}

int32_t hey_postgres_status(HeyNativeHandle connection) {
  PGconn *conn = hey_pg_conn(connection);
  if (!conn) return -1;
  return (int32_t)PQstatus(conn); /* CONNECTION_OK == 0 */
}

HeyNativeUtf8View hey_postgres_error_message(HeyNativeHandle connection) {
  PGconn *conn = hey_pg_conn(connection);
  return hey_pg_view(conn ? PQerrorMessage(conn) : "invalid PostgreSQL connection handle");
}

int32_t hey_postgres_server_version(HeyNativeHandle connection) {
  PGconn *conn = hey_pg_conn(connection);
  return conn ? (int32_t)PQserverVersion(conn) : 0;
}

int32_t hey_postgres_set_nonblocking_off(HeyNativeHandle connection) {
  PGconn *conn = hey_pg_conn(connection);
  return conn ? (int32_t)PQsetnonblocking(conn, 0) : -1;
}

void hey_postgres_finish(HeyNativeHandle connection) {
  PGconn *conn = hey_pg_conn(connection);
  if (conn) PQfinish(conn);
}

int32_t hey_postgres_ping(HeyNativeUtf8View conninfo) {
  char *c = hey_pg_c_string(conninfo);
  if (!c) return -1;
  int rc = (int)PQping(c); /* PQPING_OK == 0 */
  free(c);
  return (int32_t)rc;
}

/* ---- parameter accumulator ---- */
HeyNativeHandle hey_postgres_params_new(void) {
  HeyPgParams *p = (HeyPgParams *)calloc(1, sizeof(HeyPgParams));
  return (HeyNativeHandle)(uintptr_t)p;
}

static int hey_pg_params_push(HeyPgParams *p, char *value) {
  if (p->count == p->capacity) {
    int cap = p->capacity ? p->capacity * 2 : 8;
    char **grown = (char **)realloc(p->values, (size_t)cap * sizeof(char *));
    if (!grown) return -1;
    p->values = grown;
    p->capacity = cap;
  }
  p->values[p->count++] = value;
  return 0;
}

int32_t hey_postgres_params_add_text(HeyNativeHandle params, HeyNativeUtf8View value) {
  HeyPgParams *p = hey_pg_params(params);
  if (!p) return -1;
  char *copy = hey_pg_c_string(value);
  if (!copy) return -1;
  return (int32_t)hey_pg_params_push(p, copy);
}

int32_t hey_postgres_params_add_null(HeyNativeHandle params) {
  HeyPgParams *p = hey_pg_params(params);
  if (!p) return -1;
  return (int32_t)hey_pg_params_push(p, NULL);
}

int32_t hey_postgres_params_count(HeyNativeHandle params) {
  HeyPgParams *p = hey_pg_params(params);
  return p ? (int32_t)p->count : 0;
}

void hey_postgres_params_free(HeyNativeHandle params) {
  HeyPgParams *p = hey_pg_params(params);
  if (!p) return;
  for (int i = 0; i < p->count; i++) free(p->values[i]);
  free(p->values);
  free(p);
}

/* ---- execution ---- */
HeyNativeHandle hey_postgres_exec_params(HeyNativeHandle connection, HeyNativeUtf8View sql, HeyNativeHandle params) {
  PGconn *conn = hey_pg_conn(connection);
  if (!conn) return (HeyNativeHandle)0;
  char *sql_c = hey_pg_c_string(sql);
  if (!sql_c) return (HeyNativeHandle)0;
  HeyPgParams *p = hey_pg_params(params);
  int n = p ? p->count : 0;
  const char *const *values = (const char *const *)(p ? p->values : NULL);
  PGresult *res = PQexecParams(conn, sql_c, n, NULL, values, NULL, NULL, 0);
  free(sql_c);
  return (HeyNativeHandle)(uintptr_t)res;
}

HeyNativeHandle hey_postgres_prepare(HeyNativeHandle connection, HeyNativeUtf8View name, HeyNativeUtf8View sql) {
  PGconn *conn = hey_pg_conn(connection);
  if (!conn) return (HeyNativeHandle)0;
  char *name_c = hey_pg_c_string(name);
  char *sql_c = hey_pg_c_string(sql);
  PGresult *res = NULL;
  if (name_c && sql_c) res = PQprepare(conn, name_c, sql_c, 0, NULL);
  free(name_c);
  free(sql_c);
  return (HeyNativeHandle)(uintptr_t)res;
}

HeyNativeHandle hey_postgres_exec_prepared(HeyNativeHandle connection, HeyNativeUtf8View name, HeyNativeHandle params) {
  PGconn *conn = hey_pg_conn(connection);
  if (!conn) return (HeyNativeHandle)0;
  char *name_c = hey_pg_c_string(name);
  if (!name_c) return (HeyNativeHandle)0;
  HeyPgParams *p = hey_pg_params(params);
  int n = p ? p->count : 0;
  const char *const *values = (const char *const *)(p ? p->values : NULL);
  PGresult *res = PQexecPrepared(conn, name_c, n, values, NULL, NULL, 0);
  free(name_c);
  return (HeyNativeHandle)(uintptr_t)res;
}

/* ---- result ---- */
int32_t hey_postgres_result_status(HeyNativeHandle result) {
  PGresult *res = hey_pg_result(result);
  if (!res) return -1;
  return (int32_t)PQresultStatus(res);
}

HeyNativeUtf8View hey_postgres_result_error(HeyNativeHandle result) {
  PGresult *res = hey_pg_result(result);
  return hey_pg_view(res ? PQresultErrorMessage(res) : "null result");
}

HeyNativeUtf8View hey_postgres_result_error_field(HeyNativeHandle result, int32_t code) {
  PGresult *res = hey_pg_result(result);
  return hey_pg_view(res ? PQresultErrorField(res, code) : NULL);
}

int32_t hey_postgres_result_ntuples(HeyNativeHandle result) {
  PGresult *res = hey_pg_result(result);
  return res ? (int32_t)PQntuples(res) : 0;
}

int32_t hey_postgres_result_nfields(HeyNativeHandle result) {
  PGresult *res = hey_pg_result(result);
  return res ? (int32_t)PQnfields(res) : 0;
}

HeyNativeUtf8View hey_postgres_result_fname(HeyNativeHandle result, int32_t column) {
  PGresult *res = hey_pg_result(result);
  return hey_pg_view(res ? PQfname(res, column) : NULL);
}

int64_t hey_postgres_result_ftype(HeyNativeHandle result, int32_t column) {
  PGresult *res = hey_pg_result(result);
  return res ? (int64_t)PQftype(res, column) : 0;
}

HeyNativeBool hey_postgres_result_getisnull(HeyNativeHandle result, int32_t row, int32_t column) {
  PGresult *res = hey_pg_result(result);
  return (HeyNativeBool)(res && PQgetisnull(res, row, column));
}

HeyNativeUtf8View hey_postgres_result_getvalue(HeyNativeHandle result, int32_t row, int32_t column) {
  PGresult *res = hey_pg_result(result);
  if (!res) return (HeyNativeUtf8View){"", 0};
  const char *value = PQgetvalue(res, row, column);
  int length = PQgetlength(res, row, column);
  if (!value) return (HeyNativeUtf8View){"", 0};
  return (HeyNativeUtf8View){value, (size_t)(length < 0 ? 0 : length)};
}

HeyNativeBytesView hey_postgres_result_getbytes(HeyNativeHandle result, int32_t row, int32_t column) {
  static const uint8_t empty = 0;
  PGresult *res = hey_pg_result(result);
  if (!res) return (HeyNativeBytesView){&empty, 0};
  const char *value = PQgetvalue(res, row, column);
  int length = PQgetlength(res, row, column);
  if (!value) return (HeyNativeBytesView){&empty, 0};
  return (HeyNativeBytesView){(const uint8_t *)value, (size_t)(length < 0 ? 0 : length)};
}

HeyNativeUtf8View hey_postgres_result_cmdtuples(HeyNativeHandle result) {
  PGresult *res = hey_pg_result(result);
  return hey_pg_view(res ? PQcmdTuples(res) : "");
}

void hey_postgres_clear(HeyNativeHandle result) {
  PGresult *res = hey_pg_result(result);
  if (res) PQclear(res);
}
