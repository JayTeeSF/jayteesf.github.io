#include "hey_duckdb.h"
#include <duckdb.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* Owned result wrapper: the duckdb_result struct plus a scratch pointer for the
 * most recently converted varchar (freed on the next conversion / on destroy),
 * so borrowed value views never leak. */
typedef struct {
  duckdb_result result;
  char *scratch;
  int has_result;
  int success;
} HeyDuckResult;

static char *hey_duck_c_string(HeyNativeUtf8View value) {
  char *out = (char *)malloc(value.length + 1);
  if (!out) return NULL;
  if (value.length && value.data) memcpy(out, value.data, value.length);
  out[value.length] = '\0';
  return out;
}

static duckdb_database hey_duck_db(HeyNativeHandle v) { return (duckdb_database)(uintptr_t)v; }
static duckdb_connection hey_duck_con(HeyNativeHandle v) { return (duckdb_connection)(uintptr_t)v; }
static duckdb_prepared_statement hey_duck_stmt(HeyNativeHandle v) { return (duckdb_prepared_statement)(uintptr_t)v; }
static HeyDuckResult *hey_duck_res(HeyNativeHandle v) { return (HeyDuckResult *)(uintptr_t)v; }

static HeyNativeUtf8View hey_duck_view(const char *s) {
  if (!s) return (HeyNativeUtf8View){"", 0};
  return (HeyNativeUtf8View){s, strlen(s)};
}

/* ---- lifecycle ---- */
HeyNativeHandle hey_duckdb_open(HeyNativeUtf8View path) {
  char *path_c = hey_duck_c_string(path);
  duckdb_database db = NULL;
  const char *p = (path_c && path_c[0]) ? path_c : NULL; /* NULL / "" -> in-memory */
  duckdb_state state = duckdb_open(p, &db);
  free(path_c);
  if (state != DuckDBSuccess) {
    if (db) duckdb_close(&db);
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)db;
}

HeyNativeHandle hey_duckdb_connect(HeyNativeHandle database) {
  duckdb_database db = hey_duck_db(database);
  if (!db) return (HeyNativeHandle)0;
  duckdb_connection con = NULL;
  if (duckdb_connect(db, &con) != DuckDBSuccess) {
    if (con) duckdb_disconnect(&con);
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)con;
}

void hey_duckdb_disconnect(HeyNativeHandle connection) {
  duckdb_connection con = hey_duck_con(connection);
  if (con) duckdb_disconnect(&con);
}

void hey_duckdb_close(HeyNativeHandle database) {
  duckdb_database db = hey_duck_db(database);
  if (db) duckdb_close(&db);
}

/* ---- query ---- */
static HeyNativeHandle hey_duck_wrap(duckdb_result result, int state_ok) {
  HeyDuckResult *w = (HeyDuckResult *)calloc(1, sizeof(HeyDuckResult));
  if (!w) return (HeyNativeHandle)0;
  w->result = result;
  w->has_result = 1;
  w->success = state_ok;
  w->scratch = NULL;
  return (HeyNativeHandle)(uintptr_t)w;
}

HeyNativeHandle hey_duckdb_query(HeyNativeHandle connection, HeyNativeUtf8View sql) {
  duckdb_connection con = hey_duck_con(connection);
  if (!con) return (HeyNativeHandle)0;
  char *sql_c = hey_duck_c_string(sql);
  if (!sql_c) return (HeyNativeHandle)0;
  duckdb_result result;
  memset(&result, 0, sizeof(result));
  duckdb_state state = duckdb_query(con, sql_c, &result);
  free(sql_c);
  return hey_duck_wrap(result, state == DuckDBSuccess);
}

/* ---- prepared statements ---- */
HeyNativeHandle hey_duckdb_prepare(HeyNativeHandle connection, HeyNativeUtf8View sql) {
  duckdb_connection con = hey_duck_con(connection);
  if (!con) return (HeyNativeHandle)0;
  char *sql_c = hey_duck_c_string(sql);
  if (!sql_c) return (HeyNativeHandle)0;
  duckdb_prepared_statement stmt = NULL;
  (void)duckdb_prepare(con, sql_c, &stmt); /* stmt allocated even on error */
  free(sql_c);
  return (HeyNativeHandle)(uintptr_t)stmt;
}

HeyNativeUtf8View hey_duckdb_prepare_error(HeyNativeHandle statement) {
  duckdb_prepared_statement stmt = hey_duck_stmt(statement);
  return hey_duck_view(stmt ? duckdb_prepare_error(stmt) : "null prepared statement");
}

int64_t hey_duckdb_nparams(HeyNativeHandle statement) {
  duckdb_prepared_statement stmt = hey_duck_stmt(statement);
  return stmt ? (int64_t)duckdb_nparams(stmt) : 0;
}

int32_t hey_duckdb_bind_varchar(HeyNativeHandle statement, int32_t index, HeyNativeUtf8View value) {
  duckdb_prepared_statement stmt = hey_duck_stmt(statement);
  if (!stmt) return (int32_t)DuckDBError;
  char *v = hey_duck_c_string(value);
  if (!v) return (int32_t)DuckDBError;
  duckdb_state s = duckdb_bind_varchar(stmt, (idx_t)index, v);
  free(v);
  return (int32_t)s;
}

int32_t hey_duckdb_bind_null(HeyNativeHandle statement, int32_t index) {
  duckdb_prepared_statement stmt = hey_duck_stmt(statement);
  return stmt ? (int32_t)duckdb_bind_null(stmt, (idx_t)index) : (int32_t)DuckDBError;
}

HeyNativeHandle hey_duckdb_execute_prepared(HeyNativeHandle statement) {
  duckdb_prepared_statement stmt = hey_duck_stmt(statement);
  if (!stmt) return (HeyNativeHandle)0;
  duckdb_result result;
  memset(&result, 0, sizeof(result));
  duckdb_state state = duckdb_execute_prepared(stmt, &result);
  return hey_duck_wrap(result, state == DuckDBSuccess);
}

void hey_duckdb_destroy_prepare(HeyNativeHandle statement) {
  duckdb_prepared_statement stmt = hey_duck_stmt(statement);
  if (stmt) duckdb_destroy_prepare(&stmt);
}

/* ---- result inspection ---- */
HeyNativeBool hey_duckdb_result_success(HeyNativeHandle result) {
  HeyDuckResult *w = hey_duck_res(result);
  return (HeyNativeBool)(w && w->success);
}

HeyNativeUtf8View hey_duckdb_result_error(HeyNativeHandle result) {
  HeyDuckResult *w = hey_duck_res(result);
  if (!w) return hey_duck_view("null result");
  return hey_duck_view(duckdb_result_error(&w->result));
}

int64_t hey_duckdb_row_count(HeyNativeHandle result) {
  HeyDuckResult *w = hey_duck_res(result);
  return w ? (int64_t)duckdb_row_count(&w->result) : 0;
}

int64_t hey_duckdb_column_count(HeyNativeHandle result) {
  HeyDuckResult *w = hey_duck_res(result);
  return w ? (int64_t)duckdb_column_count(&w->result) : 0;
}

HeyNativeUtf8View hey_duckdb_column_name(HeyNativeHandle result, int32_t column) {
  HeyDuckResult *w = hey_duck_res(result);
  return hey_duck_view(w ? duckdb_column_name(&w->result, (idx_t)column) : NULL);
}

int32_t hey_duckdb_column_type(HeyNativeHandle result, int32_t column) {
  HeyDuckResult *w = hey_duck_res(result);
  return w ? (int32_t)duckdb_column_type(&w->result, (idx_t)column) : 0;
}

HeyNativeBool hey_duckdb_value_is_null(HeyNativeHandle result, int32_t column, int64_t row) {
  HeyDuckResult *w = hey_duck_res(result);
  return (HeyNativeBool)(w && duckdb_value_is_null(&w->result, (idx_t)column, (idx_t)row));
}

HeyNativeUtf8View hey_duckdb_value_varchar(HeyNativeHandle result, int32_t column, int64_t row) {
  HeyDuckResult *w = hey_duck_res(result);
  if (!w) return (HeyNativeUtf8View){"", 0};
  if (w->scratch) {
    duckdb_free(w->scratch);
    w->scratch = NULL;
  }
  w->scratch = duckdb_value_varchar(&w->result, (idx_t)column, (idx_t)row);
  return hey_duck_view(w->scratch);
}

void hey_duckdb_destroy_result(HeyNativeHandle result) {
  HeyDuckResult *w = hey_duck_res(result);
  if (!w) return;
  if (w->scratch) duckdb_free(w->scratch);
  if (w->has_result) duckdb_destroy_result(&w->result);
  free(w);
}
