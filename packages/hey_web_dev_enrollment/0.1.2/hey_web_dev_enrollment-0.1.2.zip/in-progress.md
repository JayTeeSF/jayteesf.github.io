# In progress

The 0.1.2 package compatibility release is ready for validation and immutable publication.

- VSS server is the first consumer.
