#include "hey_durable_log_native.h"
#include "hey_durable_log.h"

#include <limits.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  hdl_log *log;
  hdl_broker *broker;
} hey_durable_log_connection;

typedef struct {
  hdl_status status;
  hdl_receipt value;
} hey_durable_log_receipt;

typedef struct {
  hdl_status status;
  hdl_broker_stats value;
} hey_durable_log_stats;

typedef struct {
  hdl_status status;
  uint64_t sequence;
  uint64_t batch_id;
  uint64_t stream_id;
  uint8_t *payload;
  uint32_t payload_length;
  uint64_t position;
  uint64_t next_position;
} hey_durable_log_record;

static char *copy_utf8(HeyNativeUtf8View value) {
  char *copy = malloc(value.length + 1);
  if (copy == NULL) return NULL;
  if (value.length > 0 && value.data != NULL) memcpy(copy, value.data, value.length);
  copy[value.length] = '\0';
  return copy;
}

static hey_durable_log_connection *connection_value(HeyNativeHandle handle) {
  return (hey_durable_log_connection *)(uintptr_t)handle;
}

static hey_durable_log_receipt *receipt_value(HeyNativeHandle handle) {
  return (hey_durable_log_receipt *)(uintptr_t)handle;
}

static hey_durable_log_stats *stats_value(HeyNativeHandle handle) {
  return (hey_durable_log_stats *)(uintptr_t)handle;
}

static hdl_cursor *cursor_value(HeyNativeHandle handle) {
  return (hdl_cursor *)(uintptr_t)handle;
}

static hey_durable_log_record *record_value(HeyNativeHandle handle) {
  return (hey_durable_log_record *)(uintptr_t)handle;
}

HeyNativeHandle hey_durable_log_native_open(HeyNativeUtf8View path,
                                             int32_t queue_capacity,
                                             int32_t max_batch_records,
                                             int32_t batch_window_microseconds,
                                             int64_t segment_size_bytes) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0 ||
      segment_size_bytes < 0) return (HeyNativeHandle)0;
  char *path_copy = copy_utf8(path);
  hey_durable_log_connection *connection = calloc(1, sizeof(*connection));
  if (path_copy == NULL || connection == NULL) {
    free(path_copy);
    free(connection);
    return (HeyNativeHandle)0;
  }
  hdl_options journal = {0, 0, 0, 0, (uint64_t)segment_size_bytes};
  hdl_status status = hdl_open(path_copy, &journal, &connection->log);
  free(path_copy);
  if (status == HDL_OK) {
    hdl_broker_options options = {
      (uint32_t)queue_capacity,
      (uint32_t)max_batch_records,
      (uint32_t)batch_window_microseconds
    };
    status = hdl_broker_open(connection->log, &options, &connection->broker);
  }
  if (status != HDL_OK) {
    if (connection->log != NULL) (void)hdl_close(connection->log);
    free(connection);
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)connection;
}

int32_t hey_durable_log_native_open_status(HeyNativeUtf8View path,
                                            int32_t queue_capacity,
                                            int32_t max_batch_records,
                                            int32_t batch_window_microseconds,
                                            int64_t segment_size_bytes) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0 ||
      segment_size_bytes < 0) return HDL_INVALID;
  char *path_copy = copy_utf8(path);
  if (path_copy == NULL) return HDL_NOMEM;
  hdl_log *log = NULL;
  hdl_options journal = {0, 0, 0, 0, (uint64_t)segment_size_bytes};
  hdl_status status = hdl_open(path_copy, &journal, &log);
  free(path_copy);
  if (log != NULL) (void)hdl_close(log);
  return status;
}

int32_t hey_durable_log_native_close(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return HDL_INVALID;
  hdl_status broker_status = hdl_broker_close(connection->broker);
  hdl_status log_status = hdl_close(connection->log);
  free(connection);
  return broker_status != HDL_OK ? broker_status : log_status;
}

HeyNativeHandle hey_durable_log_native_submit(HeyNativeHandle handle,
                                               int64_t stream_id,
                                               HeyNativeBytesView payload) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || stream_id <= 0 || payload.length > UINT32_MAX ||
      (payload.length > 0 && payload.data == NULL)) {
    return (HeyNativeHandle)0;
  }
  hey_durable_log_receipt *receipt = calloc(1, sizeof(*receipt));
  if (receipt == NULL) return (HeyNativeHandle)0;
  hdl_record record = {(uint64_t)stream_id, payload.data, (uint32_t)payload.length};
  receipt->status = hdl_broker_submit(connection->broker, &record, &receipt->value);
  return (HeyNativeHandle)(uintptr_t)receipt;
}

/* Submit with a bound on how long the caller waits to be ADMITTED. A negative
   deadline is refused rather than treated as "wait forever": a caller who asked
   for a bound and silently got none is the failure this whole call exists to
   prevent. Zero is the explicit unbounded wait. */
HeyNativeHandle hey_durable_log_native_submit_within(HeyNativeHandle handle,
                                                     int64_t stream_id,
                                                     HeyNativeBytesView payload,
                                                     int64_t admission_timeout_microseconds) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || stream_id <= 0 || payload.length > UINT32_MAX ||
      (payload.length > 0 && payload.data == NULL) ||
      admission_timeout_microseconds < 0 || admission_timeout_microseconds > UINT32_MAX) {
    return (HeyNativeHandle)0;
  }
  hey_durable_log_receipt *receipt = calloc(1, sizeof(*receipt));
  if (receipt == NULL) return (HeyNativeHandle)0;
  hdl_record record = {(uint64_t)stream_id, payload.data, (uint32_t)payload.length};
  receipt->status = hdl_broker_submit_within(connection->broker, &record,
                                             (uint32_t)admission_timeout_microseconds,
                                             &receipt->value);
  return (HeyNativeHandle)(uintptr_t)receipt;
}

int32_t hey_durable_log_native_receipt_status(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL ? HDL_INVALID : receipt->status;
}

int64_t hey_durable_log_native_receipt_sequence(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.first_sequence > INT64_MAX
           ? -1 : (int64_t)receipt->value.first_sequence;
}

int64_t hey_durable_log_native_receipt_batch_id(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.batch_id > INT64_MAX
           ? -1 : (int64_t)receipt->value.batch_id;
}

int64_t hey_durable_log_native_receipt_durable_offset(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.durable_offset > INT64_MAX
           ? -1 : (int64_t)receipt->value.durable_offset;
}

void hey_durable_log_native_receipt_close(HeyNativeHandle handle) {
  free(receipt_value(handle));
}

/* One SNAPSHOT of the broker's counters, not four separate reads.
   Four calls into a running broker would hand the caller a torn view -- a record
   count from one instant and a queue depth from another -- and the whole point
   of reporting a bound is that the numbers can be compared with each other. */
typedef struct {
  hdl_status status;
  hdl_snapshot value;
} hey_durable_log_snapshot;

static hey_durable_log_snapshot *snapshot_value(HeyNativeHandle handle) {
  return (hey_durable_log_snapshot *)(uintptr_t)handle;
}

/* Snapshot, verify, restore and retire, from the process that OWNS the journal.
   That is not a convenience: a journal has one writer and holds an exclusive
   lock for the life of the handle, so a separate operator binary cannot open a
   live journal to retire anything. The owner is the only process that can, which
   settles where these belong. */
HeyNativeHandle hey_durable_log_native_snapshot_create(HeyNativeHandle handle,
                                                       HeyNativeUtf8View directory) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || directory.data == NULL || directory.length == 0) {
    return (HeyNativeHandle)0;
  }
  char *directory_copy = copy_utf8(directory);
  hey_durable_log_snapshot *snapshot = calloc(1, sizeof(*snapshot));
  if (directory_copy == NULL || snapshot == NULL) {
    free(directory_copy);
    free(snapshot);
    return (HeyNativeHandle)0;
  }
  snapshot->status = hdl_snapshot_create(connection->log, directory_copy, &snapshot->value);
  free(directory_copy);
  return (HeyNativeHandle)(uintptr_t)snapshot;
}

HeyNativeHandle hey_durable_log_native_snapshot_verify(HeyNativeUtf8View directory) {
  if (directory.data == NULL || directory.length == 0) return (HeyNativeHandle)0;
  char *directory_copy = copy_utf8(directory);
  hey_durable_log_snapshot *snapshot = calloc(1, sizeof(*snapshot));
  if (directory_copy == NULL || snapshot == NULL) {
    free(directory_copy);
    free(snapshot);
    return (HeyNativeHandle)0;
  }
  snapshot->status = hdl_snapshot_verify(directory_copy, &snapshot->value);
  free(directory_copy);
  return (HeyNativeHandle)(uintptr_t)snapshot;
}

int32_t hey_durable_log_native_snapshot_restore(HeyNativeUtf8View snapshot_directory,
                                                HeyNativeUtf8View journal_directory) {
  if (snapshot_directory.data == NULL || journal_directory.data == NULL) return HDL_INVALID;
  char *from = copy_utf8(snapshot_directory);
  char *to = copy_utf8(journal_directory);
  hdl_status status = (from == NULL || to == NULL) ? HDL_NOMEM : hdl_snapshot_restore(from, to);
  free(from);
  free(to);
  return status;
}

int32_t hey_durable_log_native_retire(HeyNativeHandle handle, HeyNativeUtf8View directory) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || directory.data == NULL || directory.length == 0) return HDL_INVALID;
  char *directory_copy = copy_utf8(directory);
  if (directory_copy == NULL) return HDL_NOMEM;
  hdl_status status = hdl_retire_snapshotted(connection->log, directory_copy);
  free(directory_copy);
  return status;
}

int32_t hey_durable_log_native_snapshot_status(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL ? HDL_INVALID : snapshot->status;
}

int64_t hey_durable_log_native_snapshot_records(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.records;
}

int64_t hey_durable_log_native_snapshot_first_sequence(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.first_sequence;
}

int64_t hey_durable_log_native_snapshot_last_sequence(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.last_sequence;
}

int64_t hey_durable_log_native_snapshot_digest(HeyNativeHandle handle) {
  hey_durable_log_snapshot *snapshot = snapshot_value(handle);
  return snapshot == NULL || snapshot->status != HDL_OK ? -1 : (int64_t)snapshot->value.digest;
}

void hey_durable_log_native_snapshot_close(HeyNativeHandle handle) {
  free(snapshot_value(handle));
}

int64_t hey_durable_log_native_last_sequence(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return -1;
  uint64_t sequence = 0;
  if (hdl_last_sequence(connection->log, &sequence) != HDL_OK || sequence > INT64_MAX) return -1;
  return (int64_t)sequence;
}

HeyNativeHandle hey_durable_log_native_stats_open(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return (HeyNativeHandle)0;
  hey_durable_log_stats *stats = calloc(1, sizeof(*stats));
  if (stats == NULL) return (HeyNativeHandle)0;
  stats->status = hdl_broker_get_stats(connection->broker, &stats->value);
  return (HeyNativeHandle)(uintptr_t)stats;
}

int32_t hey_durable_log_native_stats_status(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL ? HDL_INVALID : stats->status;
}

int64_t hey_durable_log_native_stats_records(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK || stats->value.records > INT64_MAX
           ? -1 : (int64_t)stats->value.records;
}

int64_t hey_durable_log_native_stats_durable_batches(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK || stats->value.durable_batches > INT64_MAX
           ? -1 : (int64_t)stats->value.durable_batches;
}

int64_t hey_durable_log_native_stats_largest_batch(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK ? -1 : (int64_t)stats->value.largest_batch;
}

int64_t hey_durable_log_native_stats_max_queue_depth(HeyNativeHandle handle) {
  hey_durable_log_stats *stats = stats_value(handle);
  return stats == NULL || stats->status != HDL_OK ? -1 : (int64_t)stats->value.max_queue_depth;
}

void hey_durable_log_native_stats_close(HeyNativeHandle handle) {
  free(stats_value(handle));
}

HeyNativeHandle hey_durable_log_native_cursor_open(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return (HeyNativeHandle)0;
  hdl_cursor *cursor = NULL;
  if (hdl_cursor_open(connection->log, &cursor) != HDL_OK) return (HeyNativeHandle)0;
  return (HeyNativeHandle)(uintptr_t)cursor;
}

HeyNativeHandle hey_durable_log_native_cursor_next(HeyNativeHandle handle) {
  hdl_cursor *cursor = cursor_value(handle);
  if (cursor == NULL) return (HeyNativeHandle)0;
  hey_durable_log_record *record = calloc(1, sizeof(*record));
  if (record == NULL) return (HeyNativeHandle)0;
  hdl_cursor_record value;
  record->status = hdl_cursor_next(cursor, &value);
  if (record->status == HDL_OK) {
    record->sequence = value.sequence;
    record->batch_id = value.batch_id;
    record->stream_id = value.stream_id;
    record->position = value.position;
    record->next_position = value.next_position;
    record->payload_length = value.payload_length;
    if (value.payload_length > 0) {
      record->payload = malloc(value.payload_length);
      if (record->payload == NULL) {
        record->status = HDL_NOMEM;
        record->payload_length = 0;
      } else {
        memcpy(record->payload, value.payload, value.payload_length);
      }
    }
  }
  return (HeyNativeHandle)(uintptr_t)record;
}

int32_t hey_durable_log_native_cursor_close(HeyNativeHandle handle) {
  return hdl_cursor_close(cursor_value(handle));
}

int32_t hey_durable_log_native_record_status(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL ? HDL_INVALID : record->status;
}

int64_t hey_durable_log_native_record_sequence(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->sequence > INT64_MAX
           ? -1 : (int64_t)record->sequence;
}

/* Where this record sits, and where the next one starts. A Hey materializer
   stores next_position and hands it back to cursor_open_at, which is what stops
   it re-reading everything it has already applied. */
int64_t hey_durable_log_native_record_position(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->position > INT64_MAX
           ? -1 : (int64_t)record->position;
}

int64_t hey_durable_log_native_record_next_position(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->next_position > INT64_MAX
           ? -1 : (int64_t)record->next_position;
}

HeyNativeHandle hey_durable_log_native_cursor_open_at(HeyNativeHandle handle, int64_t position) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || position < 0) return (HeyNativeHandle)0;
  hdl_cursor *cursor = NULL;
  if (hdl_cursor_open_at(connection->log, (uint64_t)position, &cursor) != HDL_OK) {
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)cursor;
}

int64_t hey_durable_log_native_record_batch_id(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->batch_id > INT64_MAX
           ? -1 : (int64_t)record->batch_id;
}

int64_t hey_durable_log_native_record_stream_id(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->stream_id > INT64_MAX
           ? -1 : (int64_t)record->stream_id;
}

HeyNativeBytesView hey_durable_log_native_record_payload(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  if (record == NULL || record->status != HDL_OK) return (HeyNativeBytesView){NULL, 0};
  return (HeyNativeBytesView){record->payload, record->payload_length};
}

void hey_durable_log_native_record_close(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  if (record == NULL) return;
  free(record->payload);
  free(record);
}
