#!/usr/bin/env sh
# Pins the 0.4.0 live-data renderer contract in tools/hey_native_tv_runtime.m
# and the App Transport Security exception in tools/hey-ios-tv-app.sh.
#
# These are Objective-C and shell, not Hey, so the Hey spec harness cannot
# reach them. What IS mechanically checkable, and what actually broke real
# apps before, is: (1) the file compiles for the tvOS SDK, and (2) the four
# load-bearing decisions below are still present. Each grep documents why it
# matters.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
RUNTIME="$ROOT/tools/hey_native_tv_runtime.m"
BUILDER="$ROOT/tools/hey-ios-tv-app.sh"

fail() { echo "live-data renderer spec: $1" >&2; exit 1; }

# 1. A repeating timer must exist, or a scene declaring tick/fetch never
#    advances and the display freezes on its first frame.
grep -q 'scheduledTimerWithTimeInterval' "$RUNTIME" || fail 'no NSTimer: live scenes would never poll'

# 2. Networking must be NSURLSession. The Hey runtime compiles its TLS client
#    OUT for this target (there is no OpenSSL on tvOS), so it replaces every
#    OpenSSL symbol with abort(), so an HTTPS request from Hey's stdlib
#    terminates the app. This is the single most dangerous regression here.
grep -q 'NSURLSession' "$RUNTIME" || fail 'no NSURLSession: networking must not go through stdlib:Http on tvOS'

# 3. mode "scene" installs the fetched document directly. Without it a Hey
#    app would have to parse JSON, which the tvOS LLVM subset cannot do.
grep -q '"scene"' "$RUNTIME" || fail 'scene mode missing: display apps could not project server state'

# 4. Cleartext HTTP to a LAN address is refused by default ATS, so a party
#    server on 192.168.x.x is unreachable without this exception.
grep -q 'NSAllowsLocalNetworking' "$BUILDER" || fail 'Info.plist lost NSAllowsLocalNetworking: LAN HTTP would be blocked'

# 5. Bootstrap fallback. A scene-mode poll can re-arm the renderer onto a
#    room-specific url; when that room later goes away every poll fails and
#    the screen would be frozen FOREVER without a way back. All three parts
#    must survive: the baked url is remembered, failures are counted, and the
#    limit is a named constant.
grep -q 'bootstrapFetchUrl' "$RUNTIME" || fail 'baked bootstrap url not remembered: a dead room would strand the screen'
grep -q 'consecutiveFetchFailures' "$RUNTIME" || fail 'consecutive fetch failures not counted: fallback can never trigger'
grep -q 'kHeySceneFetchFailureLimit' "$RUNTIME" || fail 'fallback threshold constant missing'
grep -q 'noteFailedScenePoll' "$RUNTIME" || fail 'failed-poll path missing: failures would not reach the fallback'

# 6. It has to actually build for the Apple TV SDK.
if [ "$(uname -s)" = Darwin ] && xcrun --sdk appletvos --show-sdk-path >/dev/null 2>&1; then
  clang=$(xcrun --sdk appletvos --find clang)
  sdk=$(xcrun --sdk appletvos --show-sdk-path)
  "$clang" --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -fsyntax-only "$RUNTIME" || fail 'renderer does not compile for tvOS'
else
  echo 'live-data renderer spec: no tvOS SDK here, skipped the compile check'
fi

echo 'live-data renderer spec passed'
