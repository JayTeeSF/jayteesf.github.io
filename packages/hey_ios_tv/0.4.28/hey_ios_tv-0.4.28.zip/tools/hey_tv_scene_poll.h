#import <Foundation/Foundation.h>
#include <math.h>

// Native scene-v2 boundary only. The opaque-i64 v1 app contract has no scene
// fetches. Unknown widget kinds retain the renderer's visible placeholder;
// unknown extra fields remain forward compatible.
static BOOL HeyTVSceneObjectArray(id value) {
  if (![value isKindOfClass:NSArray.class]) { return NO; }
  for (id item in value) { if (![item isKindOfClass:NSDictionary.class]) { return NO; } }
  return YES;
}

static BOOL HeyTVSceneBodyValid(NSString *body) {
  if (!body.length) { return NO; }
  NSData *bytes = [body dataUsingEncoding:NSUTF8StringEncoding];
  id scene = bytes ? [NSJSONSerialization JSONObjectWithData:bytes options:0 error:NULL] : nil;
  if (![scene isKindOfClass:NSDictionary.class] || ![scene[@"schema"] isEqual:@"hey-tv-scene-v2"]
      || !HeyTVSceneObjectArray(scene[@"widgets"])) { return NO; }
  for (NSDictionary *widget in scene[@"widgets"]) {
    NSString *kind = widget[@"kind"];
    if (![kind isKindOfClass:NSString.class] || !kind.length) { return NO; }
    if ([kind isEqual:@"text"] && ![widget[@"text"] isKindOfClass:NSString.class]) { return NO; }
    if ([kind isEqual:@"qr"] && ![widget[@"payload"] isKindOfClass:NSString.class]) { return NO; }
    if ([kind isEqual:@"rect"] && ![widget[@"color"] isKindOfClass:NSString.class]) { return NO; }
    if ([kind isEqual:@"image"] && ![widget[@"symbol"] isKindOfClass:NSString.class]
        && ![widget[@"url"] isKindOfClass:NSString.class]) { return NO; }
    if (([kind isEqual:@"hand"] || [kind isEqual:@"stack"]) && widget[@"cards"]
        && !HeyTVSceneObjectArray(widget[@"cards"])) { return NO; }
    if ([kind isEqual:@"grid"] && widget[@"items"] && !HeyTVSceneObjectArray(widget[@"items"])) { return NO; }
    if ([kind isEqual:@"chips"] && widget[@"items"]) {
      if (![widget[@"items"] isKindOfClass:NSArray.class]) { return NO; }
      for (id item in widget[@"items"]) { if (![item isKindOfClass:NSString.class]) { return NO; } }
    }
  }
  for (NSString *key in @[@"fetch", @"tick"]) {
    id declaration = scene[key];
    if (!declaration) { continue; }
    if (![declaration isKindOfClass:NSDictionary.class]) { return NO; }
    id ms = declaration[@"ms"];
    if (ms && (![ms isKindOfClass:NSNumber.class] || !isfinite([ms doubleValue]))) { return NO; }
    if ([key isEqual:@"fetch"]) {
      if (![declaration[@"url"] isKindOfClass:NSString.class] || ![declaration[@"url"] length]) { return NO; }
      NSURL *url = [NSURL URLWithString:declaration[@"url"]];
      if (!url.scheme.length || (([url.scheme.lowercaseString isEqual:@"http"] || [url.scheme.lowercaseString isEqual:@"https"]) && !url.host.length)) { return NO; }
      for (NSString *field in @[@"id", @"mode"]) {
        if (declaration[field] && ![declaration[field] isKindOfClass:NSString.class]) { return NO; }
      }
    }
  }
  return YES;
}

@interface HeyTVScenePoll : NSObject
@property(nonatomic) NSUInteger failures;
@property(nonatomic) NSTimeInterval retryAt;
- (BOOL)shouldAttemptAt:(NSTimeInterval)now;
- (void)reset;
- (NSString *)acceptBody:(NSString *)body status:(NSInteger)status transportError:(BOOL)transportError
                     at:(NSTimeInterval)now baseInterval:(NSTimeInterval)base;
@end

@implementation HeyTVScenePoll
- (BOOL)shouldAttemptAt:(NSTimeInterval)now { return now >= self.retryAt; }
- (void)reset { self.failures = 0; self.retryAt = 0; }
- (NSString *)acceptBody:(NSString *)body status:(NSInteger)status transportError:(BOOL)transportError
                     at:(NSTimeInterval)now baseInterval:(NSTimeInterval)base {
  if (!transportError && status == 200 && HeyTVSceneBodyValid(body)) { [self reset]; return body; }
  self.failures = MIN(self.failures + 1, 16);
  NSTimeInterval delay = isfinite(base) && base > 0 ? MIN(base, 60) : 2;
  for (NSUInteger i = 1; i < self.failures && delay < 60; i++) { delay = MIN(delay * 2, 60); }
  self.retryAt = now + delay;
  return nil;
}
@end
