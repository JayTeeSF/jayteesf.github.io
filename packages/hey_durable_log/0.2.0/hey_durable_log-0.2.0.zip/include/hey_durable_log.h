#ifndef HEY_DURABLE_LOG_H
#define HEY_DURABLE_LOG_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct hdl_log hdl_log;
typedef struct hdl_broker hdl_broker;
typedef struct hdl_cursor hdl_cursor;

typedef enum {
  HDL_OK = 0,
  HDL_INVALID = 1,
  HDL_IO = 2,
  HDL_CORRUPTION = 3,
  HDL_NOMEM = 4,
  HDL_LIMIT = 5,
  HDL_CLOSED = 6,
  HDL_DONE = 7,
  /* A durability barrier failed on this handle, so it can no longer tell the
     truth about what is durable and will not acknowledge anything further.
     Reading still works. Reopening re-runs recovery, which re-derives the
     committed state from the bytes on disk; that is the only way to clear it. */
  HDL_POISONED = 8
} hdl_status;

typedef struct {
  uint64_t stream_id;
  const void *payload;
  uint32_t payload_length;
} hdl_record;

typedef struct {
  uint64_t batch_id;
  uint64_t first_sequence;
  uint64_t last_sequence;
  uint64_t durable_offset;
} hdl_receipt;

typedef struct {
  uint64_t generation;
  uint32_t max_record_bytes;
  uint32_t max_batch_records;
} hdl_options;

typedef struct {
  uint32_t queue_capacity;
  uint32_t max_batch_records;
  uint32_t batch_window_microseconds;
} hdl_broker_options;

typedef struct {
  uint64_t records;
  uint64_t durable_batches;
  uint32_t largest_batch;
} hdl_broker_stats;

typedef struct {
  uint64_t sequence;
  uint64_t batch_id;
  uint64_t stream_id;
  const void *payload;
  uint32_t payload_length;
} hdl_cursor_record;

typedef int (*hdl_scan_callback)(void *context,
                                 uint64_t sequence,
                                 uint64_t batch_id,
                                 uint64_t stream_id,
                                 const void *payload,
                                 uint32_t payload_length);

/* Names the durability barrier this build issues before acknowledging a batch.
   It is public because the barrier IS the promise: a caller (and a gate) must
   be able to ask whether this build flushes the storage device's cache or only
   hands bytes to the drive. */
const char *hdl_sync_barrier_name(void);

hdl_status hdl_open(const char *path, const hdl_options *options, hdl_log **out);
hdl_status hdl_append_batch(hdl_log *log,
                            const hdl_record *records,
                            size_t count,
                            hdl_receipt *receipt);
hdl_status hdl_scan(hdl_log *log, hdl_scan_callback callback, void *context);
hdl_status hdl_cursor_open(hdl_log *log, hdl_cursor **out);
hdl_status hdl_cursor_next(hdl_cursor *cursor, hdl_cursor_record *out);
hdl_status hdl_cursor_close(hdl_cursor *cursor);
hdl_status hdl_close(hdl_log *log);
hdl_status hdl_broker_open(hdl_log *log,
                           const hdl_broker_options *options,
                           hdl_broker **out);
hdl_status hdl_broker_submit(hdl_broker *broker,
                             const hdl_record *record,
                             hdl_receipt *receipt);
hdl_status hdl_broker_get_stats(hdl_broker *broker, hdl_broker_stats *out);
hdl_status hdl_broker_close(hdl_broker *broker);
const char *hdl_status_name(hdl_status status);

#ifdef __cplusplus
}
#endif

#endif
