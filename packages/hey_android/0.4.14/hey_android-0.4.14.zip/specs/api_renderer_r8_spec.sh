#!/usr/bin/env bash
# Exercise signed artifacts, rather than just checking optimizer command text.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-r8.XXXXXX")
evidence=${HEY_ANDROID_R8_EVIDENCE:-}
cleanup(){ status=$?; if [ -n "$evidence" ]; then mkdir -p "$evidence"; cp "$work"/*.log "$evidence/" 2>/dev/null || true; fi; rm -rf "$work"; exit "$status"; }
trap cleanup EXIT
java_home=$(hey_android_java_home)
[ -n "$java_home" ]
export HEY_R8_TEST_PASS='sdk-fixture-password'
"$java_home/bin/keytool" -genkeypair -noprompt -keystore "$work/upload.p12" -storetype PKCS12 -alias upload -storepass:env HEY_R8_TEST_PASS -keypass:env HEY_R8_TEST_PASS -keyalg RSA -keysize 2048 -validity 2 -dname 'CN=SDK release fixture' > "$work/key.log" 2>&1
# An unreachable class in a fixture copy must be removed, not just renamed.
mkdir -p "$work/sdk"
cp -R "$ROOT/tools" "$ROOT/renderer" "$work/sdk/"
cp "$ROOT/VERSION" "$work/sdk/"
cat > "$work/sdk/renderer/java/hey/android/api/UnusedR8Fixture.java" <<'JAVA'
package hey.android.api;
public final class UnusedR8Fixture { public static String value() { return "unreachable-r8-fixture"; } }
JAVA
build(){ "$work/sdk/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/api_fixture_description.json" --origin https://example.invalid --package-id hey.android.r8fixture --label 'R8 fixture' --out "$1" --release --keystore "$work/upload.p12" --keystore-password-env HEY_R8_TEST_PASS --version-code 17 --version-name 1.0 --aab; }
build "$work/release" > "$work/release.log" 2>&1
[ -s "$work/release/mapping.txt" ] || { echo 'FAIL: release build has no R8 mapping'; exit 1; }
unzip -p "$work/release/app.aab" BUNDLE-METADATA/com.android.tools.build.obfuscation/proguard.map > "$work/embedded.map"
cmp "$work/release/mapping.txt" "$work/embedded.map"
if unzip -Z1 "$work/release/app.apk" | grep -Eq '(mapping\.txt|proguard\.map)$'; then echo 'FAIL: developer mapping shipped in installable APK'; exit 1; fi
unzip -p "$work/release/app.apk" classes.dex > "$work/release.dex"
"$HEY_ANDROID_BUILD_TOOLS_DIR/dexdump" -f "$work/release.dex" > "$work/dexdump.log"
"$HEY_ANDROID_RUBY" -rjson -rdigest - "$work" <<'RB'
work=ARGV[0]
map=File.read(work+'/embedded.map');dex=File.read(work+'/dexdump.log')
abort 'FAIL: unreachable fixture class was retained' if map.include?('UnusedR8Fixture') || dex.include?('UnusedR8Fixture') || dex.include?('unreachable-r8-fixture')
%w[HeyAndroidApiActivity HeyAndroidAudioService HeyAndroidShareProvider].each do |name|
  full='hey.android.api.'+name
  abort 'FAIL: platform component was removed/renamed: '+full unless map.include?(full+' -> '+full+':') && dex.include?('Lhey/android/api/'+name+';')
end
renamed=map.lines.filter_map{|line|m=/\A(hey\.android\.api\.[^ ]+) -> ([^:]+):\s*$/.match(line);m if m && m[1]!=m[2]}
abort 'FAIL: renderer classes were not obfuscated' if renamed.empty?
r=JSON.parse(File.read(work+'/release/receipt.json')).fetch('optimizer')
abort 'FAIL: receipt does not identify R8 release' unless r['name']=='R8' && r['mode']=='release'
abort 'FAIL: receipt does not bind mapping bytes' unless r.dig('mapping','sha256')==Digest::SHA256.hexdigest(map)
abort 'FAIL: missing optimizer provenance' unless %w[version jar_sha256 keep_rules_sha256].all?{|k|r[k].is_a?(String)&&!r[k].empty?}
puts "PASS: signed release shrinks/obfuscates renderer, keeps framework entry points and embeds exact developer mapping (#{renamed.size} renamed classes)"
RB
"$ROOT/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/api_fixture_description.json" --origin http://10.0.2.2:3581 --package-id hey.android.r8debug --label 'Debug fixture' --out "$work/debug" > "$work/debug.log" 2>&1
[ ! -e "$work/debug/mapping.txt" ]
"$HEY_ANDROID_RUBY" -rjson - "$work/debug/receipt.json" <<'RB'
r=JSON.parse(File.read(ARGV[0])).fetch('optimizer');abort 'FAIL: debug unexpectedly optimized' unless r['name']=='D8'&&r['mode']=='debug'&&r['mapping'].nil?
puts 'PASS: debug build retains ordinary D8 lane without mapping'
RB
# A real production copy with its pinned optimizer digest corrupted must refuse
# before it writes a signed release; no mock optimizer can make this pass.
cp -R "$ROOT/tools" "$work/tools"
ln -s "$ROOT/renderer" "$work/renderer"
cp "$ROOT/VERSION" "$work/VERSION"
sed -i '' 's/^HEY_ANDROID_R8_SHA256=.*/HEY_ANDROID_R8_SHA256=0000000000000000000000000000000000000000000000000000000000000000/' "$work/tools/android-pins.env"
if "$work/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/api_fixture_description.json" --origin https://example.invalid --package-id hey.android.r8bad --label Bad --out "$work/bad" --release --keystore "$work/upload.p12" --keystore-password-env HEY_R8_TEST_PASS > "$work/tampered.log" 2>&1; then echo 'FAIL: unverified optimizer was accepted'; exit 1; fi
grep -q 'R8.*sha256' "$work/tampered.log"
[ ! -e "$work/bad/app.apk" ]
echo 'PASS (control): tampered optimizer pin is refused before a release can be signed'
# Drop the mapping at the actual optimizer boundary: signing must never begin.
cp -R "$ROOT/tools" "$work/map-tools"
mv "$work/tools" "$work/tampered-tools"
mv "$work/map-tools" "$work/tools"
"$HEY_ANDROID_RUBY" - "$work/tools/hey-android-api-app.sh" <<'RB'
path=ARGV[0];source=File.read(path)
before='--pg-map-output "$out/mapping.txt"'
abort 'control did not mutate the real producer' unless source.include?(before)
File.write(path,source.sub(before,'--pg-map-output "$out/lost-mapping.txt"'))
RB
if "$work/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/api_fixture_description.json" --origin https://example.invalid --package-id hey.android.r8missing --label Missing --out "$work/missing" --release --keystore "$work/upload.p12" --keystore-password-env HEY_R8_TEST_PASS > "$work/missing.log" 2>&1; then echo 'FAIL: release without its mapping was signed'; exit 1; fi
grep -q 'R8 produced no mapping' "$work/missing.log"
[ ! -e "$work/missing/app.apk" ]
echo 'PASS (control): missing mapping is refused before a release can be signed'
