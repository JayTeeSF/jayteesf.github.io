# Verification record

Verified with Hey v0.99.198a.

The maintained check covers:

1. direct client request/response behavior;
2. server worker-plan behavior;
3. the `main` facade;
4. a real loopback server serving four parallel clients;
5. `hey package verify`;
6. deterministic `hey package pack` output;
7. archive/manifest/content SHA-256 verification during install;
8. generated `.hey-package-install.json` receipt;
9. generated consumer `hey.lock.json` pin;
10. verified `pkg:hey_web@0.1.1/...` imports;
11. a real request through the installed client/server package;
12. rejection after tampering with an installed module.

Recorded release hashes:

```text
archive_sha256  e9235a19a86774253412dfcc990d400c93598420ecb3c2a4046e54bb9f46fbc2
manifest_sha256 dc4078da8b72ec72a98271692270561b54ef50af4a48c1af692bb16604a3e502
content_sha256  ed88895ba4d8c2a3898bcf08e9f417181ac3b7b1c457a04a4fa4d458309c5089
```

Run again with:

```sh
HEY_BIN=/path/to/hey-lang/bin/hey ./bin/check
```
