#!/usr/bin/env sh
# Env-layering precedence, _test-suffix derivation, and override discipline
# for tools/dev/load-env. Pure shell -- no docker, no network.
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
LOAD_ENV="$PACKAGE_ROOT/tools/dev/load-env"

tmp="$(mktemp -d "${TMPDIR:-/tmp}/hey-mysql-env-spec.XXXXXX")"
cleanup() { rm -rf "$tmp"; }
trap cleanup EXIT HUP INT TERM

fail() {
  echo "FAIL: env_layering_spec: $1" >&2
  exit 1
}

# A hermetic runner: clears every variable load-env consults, applies the
# case's own presets, sources load-env in the project dir, prints one value.
run_case() {
  presets="$1"
  expression="$2"
  env -u APP_ENV -u MYSQL_DATABASE -u MYSQL_PORT -u HEY_MYSQL_BASE_DATABASE \
      -u HEY_MYSQL_ENV_VAR -u HEY_MYSQL_APP_NAME \
      -u HEY_MYSQL_TEST_DATABASE_OVERRIDE -u SPEC_KEY -u SPEC_LOCAL \
      sh -c "cd '$tmp' && $presets . '$LOAD_ENV' && printf '%s\n' $expression"
}

cat > "$tmp/.env" <<'ENV'
SPEC_KEY=from_dot_env
MYSQL_DATABASE=widgets
MYSQL_PORT=4001
ENV
cat > "$tmp/.env.local" <<'ENV'
SPEC_KEY=from_dot_env_local
SPEC_LOCAL=gap_filled
ENV
cat > "$tmp/.env.test" <<'ENV'
SPEC_KEY=from_dot_env_test
ENV

# 1. .env wins over .env.local; .env.local fills gaps.
test "$(run_case '' '"$SPEC_KEY"')" = 'from_dot_env' || fail '.env should beat .env.local'
test "$(run_case '' '"$SPEC_LOCAL"')" = 'gap_filled' || fail '.env.local should fill gaps'

# 2. The environment layer (.env.test) wins over .env.
test "$(run_case 'APP_ENV=test' '"$SPEC_KEY"')" = 'from_dot_env_test' || fail '.env.<env> should beat .env'

# 3. The shell wins over every file.
test "$(run_case 'APP_ENV=test SPEC_KEY=from_shell' '"$SPEC_KEY"')" = 'from_shell' || fail 'shell should beat files'

# 4. Development: MYSQL_DATABASE comes from the file; base database matches.
test "$(run_case '' '"$MYSQL_DATABASE"')" = 'widgets' || fail 'development database should be the configured one'
test "$(run_case '' '"$HEY_MYSQL_BASE_DATABASE"')" = 'widgets' || fail 'base database should match'

# 5. Test env FORCES the _test database, even over an inherited shell value
#    (the one exception to "the shell wins").
test "$(run_case 'APP_ENV=test' '"$MYSQL_DATABASE"')" = 'widgets_test' || fail 'test env should force the _test database'
test "$(run_case 'APP_ENV=test MYSQL_DATABASE=widgets' '"$MYSQL_DATABASE"')" = 'widgets_test' || fail 'an inherited MYSQL_DATABASE must not beat the test forcing'

# 6. Base-database derivation strips one _test suffix (no widgets_test_test).
test "$(run_case 'APP_ENV=test MYSQL_DATABASE=widgets_test' '"$MYSQL_DATABASE"')" = 'widgets_test' || fail 'a _test-suffixed input must not grow another suffix'

# 7. Only the explicit override renames the test database.
test "$(run_case 'APP_ENV=test HEY_MYSQL_TEST_DATABASE_OVERRIDE=custom_test' '"$MYSQL_DATABASE"')" = 'custom_test' || fail 'explicit test-database override should win'

# 8. The environment-selector variable is itself parameterized.
test "$(run_case 'HEY_MYSQL_ENV_VAR=RECALL_COACH_ENV RECALL_COACH_ENV=test' '"$MYSQL_DATABASE"')" = 'widgets_test' || fail 'HEY_MYSQL_ENV_VAR should rebind the selector'

# 9. The selector value can come from .env itself (shell silent).
cat > "$tmp/.env" <<'ENV'
APP_ENV=test
SPEC_KEY=from_dot_env
MYSQL_DATABASE=widgets
ENV
test "$(run_case '' '"$SPEC_KEY"')" = 'from_dot_env_test' || fail '.env should be able to select the environment'
cat > "$tmp/.env" <<'ENV'
SPEC_KEY=from_dot_env
MYSQL_DATABASE=widgets
MYSQL_PORT=4001
ENV

# 10. Default database identity comes from HEY_MYSQL_APP_NAME when nothing
#     configures MYSQL_DATABASE.
rm "$tmp/.env"
test "$(run_case 'HEY_MYSQL_APP_NAME=gadget' '"$MYSQL_DATABASE"')" = 'gadget' || fail 'HEY_MYSQL_APP_NAME should seed the default database'
test "$(run_case 'HEY_MYSQL_APP_NAME=gadget APP_ENV=test' '"$MYSQL_DATABASE"')" = 'gadget_test' || fail 'HEY_MYSQL_APP_NAME test database should derive _test'

# 11. An invalid environment name is refused (exit 64), not sanitized.
if env -u APP_ENV sh -c "cd '$tmp' && APP_ENV='bad;name' . '$LOAD_ENV'" 2>/dev/null; then
  fail 'an invalid environment name must be refused'
fi

echo 'PASS: hey_mysql env layering precedence, _test forcing, and overrides'
