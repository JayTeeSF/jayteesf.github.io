# Done

- Replaced the mysql CLI subprocess adapter with Connector/C over Hey native ABI v2.
- Added explicit connection/result ownership, timeouts, TLS settings, charset selection, rows, transactions, ping, insert IDs, and affected rows.
- Added safe Connector/C escaping for generated parameter plans with an explicit non-prepared capability marker.
- Added interpreter and native-C compile/load/expected-failure receipts on Linux; retained an opt-in LLVM probe that currently exposes a v0.99.268a self-hosted lowering gap for the richer adapter surface.
