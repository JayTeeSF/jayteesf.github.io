# Continuation prompt

Continue `hey_android` as an independently versioned package. Preserve the
plumbing/porcelain boundary: do not add Android syntax to Hey, do not move
application policy into this package, and do not duplicate cross-platform
vocabulary that belongs in `hey_mobile`.

For every slice:

1. update VERSION;
2. add executable specs;
3. update README, design, roadmap, extraction ledger, in-progress/todos/done;
4. keep both macOS scripts working and self-documenting;
5. run `bin/check`, `bin/package-zip`, and `bin/source-zip`;
6. publish immutable package assets under
   `$HOME/dev/jayteesf.github.io/packages/hey_android/VERSION/`.
