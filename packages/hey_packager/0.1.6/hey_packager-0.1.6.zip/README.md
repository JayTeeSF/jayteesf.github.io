# hey_packager

`hey_packager` is package-owned porcelain for releasing and publishing Hey
packages. It keeps website-specific policy out of `stdlib:Packages` while giving
every package the same verified ZIP, release metadata, checksums, documentation,
source handoff, and immutable registry workflow.

```sh
bin/hey-packager --help
bin/check
bin/release
bin/publish
```

The default website registry is:

```text
$HOME/dev/jayteesf.github.io/packages
```

Override it with `--registry-root` or `HEY_PACKAGE_REGISTRY_ROOT`.

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer for validation, release construction, source handoff, and immutable registry publication.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_packager`.
