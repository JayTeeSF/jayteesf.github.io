# Todo

1. Simulator receipt.
2. Physical Apple TV receipt.
3. Signing/archive receipt.
