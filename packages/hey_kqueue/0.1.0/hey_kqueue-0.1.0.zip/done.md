# Done

- 0.1.0: the kqueue backend split out of hey_epoll, same API name for name
  (version/backend/open/wait/next/data/send/drop/stats/close). Registrations
  ride a changelist into the next wait's kevent() (flushed early with
  EV_RECEIPT at 64), accepted sockets rely on inherited O_NONBLOCK/SO_NOSIGPIPE/
  TCP_NODELAY (checked once per loop), the listener's pending count bounds
  accept(). Builds only on macOS/BSD; open() refuses other systems with
  kqueue_unsupported_os. Two specs, product-compiler receipt, two negative
  controls; bench/macos compares it with hey_epoll's kqueue path and Web.serve.
