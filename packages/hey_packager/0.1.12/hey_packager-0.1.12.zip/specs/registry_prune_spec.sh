#!/usr/bin/env sh
# bin/registry-prune: the closure prune keeps every current version and
# everything a kept version pins, reports by default, and writes a candidate
# index only outside the registry, never over the live one.
#
# Fixture graph (current = highest):
#   app   1.0.0, 2.0.0 (current)  -- app 2.0.0 pins lib 1.0.0 EXACTLY
#   lib   1.0.0, 1.1.0, 2.0.0 (current) -- lib 1.0.0 pins base 1.0.0
#   base  1.0.0, 1.1.0 (current)
#   lone  0.9.0, 0.10.0 (current) -- semver order, not string order
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
PRUNE="$ROOT/bin/registry-prune"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/registry-prune-spec.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
unset HEY_PACKAGE_REGISTRY_ROOT

passed=0
ok() { passed=$((passed + 1)); echo "ok $passed - $*"; }
die() { echo "not ok - $*" >&2; [ ! -f "$tmp/out" ] || cat "$tmp/out" >&2; exit 1; }
has() { grep -F -- "$2" "$1" >/dev/null || die "$3"; }
hasnt() { if grep -F -- "$2" "$1" >/dev/null; then die "$3"; fi; }

reg="$tmp/registry"
publish() {
  p_name=$1 p_version=$2 p_deps=$3
  p_dir="$reg/$p_name/$p_version"
  mkdir -p "$p_dir/src"
  printf '{"name":"%s","version":"%s","dependencies":%s}\n' "$p_name" "$p_version" "$p_deps" > "$p_dir/src/hey-package.json"
  (cd "$p_dir/src" && zip -X -q "../$p_name-$p_version.zip" hey-package.json)
  rm -rf "$p_dir/src"
}
publish app 1.0.0 '{}'
publish app 2.0.0 '{"lib":"1.0.0"}'
publish lib 1.0.0 '{"base":"1.0.0"}'
publish lib 1.1.0 '{}'
publish lib 2.0.0 '{}'
publish base 1.0.0 '{}'
publish base 1.1.0 '{}'
publish lone 0.9.0 '{}'
publish lone 0.10.0 '{}'
entry() { printf '"%s":{"archive":"%s/%s/%s-%s.zip"}' "$2" "$1" "$2" "$1" "$2"; }
{
  printf '{"packages":{'
  printf '"app":{%s,%s},' "$(entry app 1.0.0)" "$(entry app 2.0.0)"
  printf '"base":{%s,%s},' "$(entry base 1.0.0)" "$(entry base 1.1.0)"
  printf '"lib":{%s,%s,%s},' "$(entry lib 1.0.0)" "$(entry lib 1.1.0)" "$(entry lib 2.0.0)"
  printf '"lone":{%s,%s}' "$(entry lone 0.10.0)" "$(entry lone 0.9.0)"
  printf '},"registry_version":1}\n'
} > "$reg/registry-v1.json"
cp "$reg/registry-v1.json" "$tmp/live-before"

"$PRUNE" --registry-root "$reg" > "$tmp/out" 2>&1 || die "report-only run failed"
has "$tmp/out" "versions     9 total -> 6 retained, 3 droppable" "the report miscounted the closure"
has "$tmp/out" "reported only" "a run without --out did not say it only reported"
cmp -s "$tmp/live-before" "$reg/registry-v1.json" || die "report-only run changed the live index"
ok "report-only: counts the closure and writes nothing"

has "$tmp/out" "    lib@1.0.0" "NEGATIVE CONTROL: lib@1.0.0, pinned by the current app, would be dropped"
has "$tmp/out" "    base@1.0.0" "base@1.0.0, pinned by a retained lib, would be dropped"
ok "control: versions a current release depends on (directly and transitively) are kept"

hasnt "$tmp/out" "lone@0.9.0" "0.9.0 was treated as current (string order instead of semver)"
ok "current is chosen by semver order"

mkdir -p "$tmp/consumers/proj"
printf '{"dependencies":{"lib":"1.1.0"}}\n' > "$tmp/consumers/proj/hey-package.json"
"$PRUNE" --registry-root "$reg" --consumers "$tmp/consumers" > "$tmp/out" 2>&1 || die "--consumers run failed"
has "$tmp/out" "lib@1.1.0  (requirement 1.1.0)" "a consumer's exact pin was not retained"
has "$tmp/out" "-> 7 retained, 2 droppable" "consumer evidence was not counted"
ok "--consumers retains what a scanned project pins"

if "$PRUNE" --registry-root "$reg" --out "$reg/pruned.json" > "$tmp/out" 2>&1; then die "--out inside the registry root was accepted"; fi
has "$tmp/out" "refusing to write inside the registry root" "the refusal did not say why"
if "$PRUNE" --registry-root "$reg" --out "$reg/registry-v1.json" > "$tmp/out" 2>&1; then die "--out over the live index was accepted"; fi
cmp -s "$tmp/live-before" "$reg/registry-v1.json" || die "a refused --out changed the live index"
[ ! -e "$reg/pruned.json" ] || die "a refused --out left a file in the registry"
ok "negative control: --out inside the registry root (or over the live index) is refused"

"$PRUNE" --registry-root "$reg" --out "$tmp/candidate/pruned.json" > "$tmp/out" 2>&1 || die "--out outside the registry failed"
has "$tmp/candidate/pruned.json" '"1.0.0":{"archive":"lib/1.0.0/lib-1.0.0.zip"}' "the candidate lost a needed version"
hasnt "$tmp/candidate/pruned.json" 'app/1.0.0' "the candidate kept a droppable version"
hasnt "$tmp/candidate/pruned.json" 'lone/0.9.0' "the candidate kept a droppable version"
cmp -s "$tmp/live-before" "$reg/registry-v1.json" || die "writing a candidate changed the live index"
ok "--out writes a pruned candidate outside the registry and leaves the live index alone"

printf 'not a zip' > "$reg/lib/1.0.0/lib-1.0.0.zip"
if "$PRUNE" --registry-root "$reg" --out "$tmp/candidate/again.json" > "$tmp/out" 2>&1; then die "an unreadable archive did not stop the prune"; fi
has "$tmp/out" "REFUSING TO PRUNE" "the refusal did not say why"
has "$tmp/out" "lib@1.0.0" "the refusal did not name the unreadable archive"
[ ! -e "$tmp/candidate/again.json" ] || die "a refused prune wrote a candidate"
ok "negative control: an unreadable archive refuses the prune (its pins are unknown)"

echo "registry-prune specs: $passed passed"
