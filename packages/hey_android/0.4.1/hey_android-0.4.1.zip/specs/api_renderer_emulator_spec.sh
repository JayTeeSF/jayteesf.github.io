#!/usr/bin/env bash
# The api_screens renderer on the Android 16 (API 36) emulator, headless, against
# specs/support/fake_api_server.py on the Mac (the emulator reaches it at 10.0.2.2).
#
#   1. Launch: the baked description is drawn, and the server is asked with its
#      ETag and answers 304. Control: the same route asked with another ETag is 200.
#   2. Sign-in: the form draws its known fields, not the unknown one. An empty
#      form says what is needed and sends nothing; a wrong passphrase shows the
#      server's refusal and keeps no session. Control: the right one does.
#   3. The session is sealed: the token the server issued is not in the kept
#      file. Control: the same search finds it in the server's own list.
#   4. The list: rows from the server; the unknown section, button, row kinds and
#      the undrawn tab are not drawn, and nothing ever asks for their routes.
#      Control: tapping the known button beside them is asked for.
#   5. A row opens its screen with the bearer token; back returns to the list.
#   6. A kept session opens the list on the next launch with no sign-in.
#   7. Sign-out asks first, revokes, removes the kept session and shows sign-in.
#   8. A new served description is stored and drawn; with the server gone the
#      next launch draws the stored copy; a damaged stored copy falls back to the
#      baked one. Control: each title differs, so the checks tell the copies apart.
#   9. No crash of the app in logcat.
#
# HEY_ANDROID_API_EVIDENCE=DIR keeps the screenshots in DIR.
# THE EMULATOR AND THE SERVER ARE ALWAYS STOPPED, on success, failure and interrupt.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-api-emulator-spec.XXXXXX")
mkdir -p "$work/shots"
serial=''
server_pid=''
evidence=${HEY_ANDROID_API_EVIDENCE:-}
package=com.jayteesf.hey.api.fixture
activity=hey.android.api.HeyAndroidApiActivity
pass() { echo "PASS: $*"; }
control() { echo "PASS (control): $*"; }
bad() { echo "FAIL: $*"; failed=1; }
export ADB=$HEY_ANDROID_ADB

stop_server() {
  if [ -n "$server_pid" ]; then
    kill "$server_pid" 2> /dev/null
    wait "$server_pid" 2> /dev/null
    server_pid=''
  fi
}
on_exit() {
  status=$?
  stop_server
  if [ -n "$serial" ]; then
    "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" > "$work/shutdown.log" 2>&1 || { cat "$work/shutdown.log"; status=1; }
  fi
  if pgrep -f "qemu-system.*-avd $HEY_ANDROID_AVD( |$)" > /dev/null 2>&1; then
    echo "FAIL: an emulator process for $HEY_ANDROID_AVD is still running after shutdown"
    status=1
  fi
  if [ -n "$evidence" ]; then mkdir -p "$evidence" && cp "$work"/shots/*.png "$evidence"/ 2> /dev/null || true; fi
  rm -rf "$work"
  exit "$status"
}
trap on_exit EXIT
trap 'exit 130' INT TERM

adbs() { "$HEY_ANDROID_ADB" -s "$serial" "$@"; }
drive() { /usr/bin/python3 "$ROOT/specs/support/drive.py" "$serial" "$@" > "$work/drive.last" 2>&1; }
texts() { /usr/bin/python3 "$ROOT/specs/support/drive.py" "$serial" texts 2> /dev/null; }
shot() { /usr/bin/python3 "$ROOT/specs/support/drive.py" "$serial" shot "$work/shots/$1.png" > /dev/null 2>&1; }
logged() { adbs logcat -d -v tag -s 'hey.api:*' 2> /dev/null | grep -c -- "$1"; }
requests() { # METHOD PATH: how many the server has seen
  /usr/bin/python3 -c 'import json,sys
n = 0
for line in open(sys.argv[1]):
    r = json.loads(line)
    if r["method"] == sys.argv[2] and r["path"].startswith(sys.argv[3]): n += 1
print(n)' "$work/requests.jsonl" "$1" "$2"
}
last_request() { # METHOD PATH FIELD
  /usr/bin/python3 -c 'import json,sys
hit = None
for line in open(sys.argv[1]):
    r = json.loads(line)
    if r["method"] == sys.argv[2] and r["path"].startswith(sys.argv[3]): hit = r
print(json.dumps(hit.get(sys.argv[4])) if hit else "none")' "$work/requests.jsonl" "$1" "$2" "$3"
}
session_files() { adbs shell run-as "$package" ls no_backup 2> /dev/null | tr -d '\r' | grep -c '^hey-session-' ; }
launch() {
  adbs shell am force-stop "$package"
  adbs logcat -c
  adbs shell am start -W -n "$package/$activity" > "$work/launch.txt" 2>&1
}

port=$(/usr/bin/python3 -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1]); s.close()')
served=$work/served.json
cp "$ROOT/specs/support/api_fixture_description.json" "$served"
: > "$work/requests.jsonl"
: > "$work/tokens.txt"
start_server() {
  /usr/bin/python3 "$ROOT/specs/support/fake_api_server.py" --port "$port" --description "$served" --log "$work/requests.jsonl" --tokens "$work/tokens.txt" > "$work/server.log" 2>&1 &
  server_pid=$!
  for _ in $(seq 1 50); do
    curl -s -o /dev/null "http://127.0.0.1:$port/v1/session" && return 0
    /bin/sleep 0.2
  done
  return 1
}
start_server || { bad "the fake server did not start on port $port: $(cat "$work/server.log")"; exit 1; }
baked_sha=$(hey_android_sha256 "$ROOT/specs/support/api_fixture_description.json")

# ---- build and boot --------------------------------------------------------------------------------
if ! "$ROOT/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/api_fixture_description.json" --origin "http://10.0.2.2:$port" \
  --package-id "$package" --label 'Hey api fixture' --out "$work/apk" > "$work/build.log" 2>&1; then
  bad "the fixture APK did not build: $(tail -5 "$work/build.log")"
  exit 1
fi
"$ROOT/tools/hey-android-emulator.sh" create-avd > "$work/avd.log" 2>&1 || { bad "could not create the AVD: $(cat "$work/avd.log")"; exit 1; }
if ! boot_line=$("$ROOT/tools/hey-android-emulator.sh" boot 2> "$work/boot.err"); then
  bad "the emulator did not boot: $(tail -5 "$work/boot.err")"
  exit 1
fi
serial=$(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^serial=//p')
pass "booted AVD $HEY_ANDROID_AVD headless as $serial; fake server on port $port"
adbs shell settings put system accelerometer_rotation 0 > /dev/null 2>&1
adbs shell svc power stayon true > /dev/null 2>&1 || true
adbs uninstall "$package" > /dev/null 2>&1
adbs install -r "$work/apk/app.apk" > "$work/install.log" 2>&1 || { bad "install failed: $(cat "$work/install.log")"; exit 1; }

# ---- 1. launch -------------------------------------------------------------------------------------------
launch
if drive logwait 'screen ready: signin' 60 && drive logwait 'description: unchanged (304' 30; then
  held=$(last_request GET /v1/app/description if_none_match)
  if [ "$(logged "drawing the baked copy ${baked_sha:0:12}")" -ge 1 ] && [ "$held" = "\"\\\"$baked_sha\\\"\"" ] \
    && [ "$(last_request GET /v1/app/description query)" = '"platform=android&level=1"' ] && [ "$(last_request GET /v1/app/description bearer)" = false ]; then
    pass "the app draws its baked copy ${baked_sha:0:12}, then asks platform=android&level=1 with If-None-Match of that copy and no token, and is answered 304"
  else
    bad "launch: If-None-Match $held, query $(last_request GET /v1/app/description query)"
  fi
else
  bad "launch: no sign-in screen, or no 304 ($(adbs logcat -d -v tag -s 'hey.api:*' | tail -3))"
fi
other=$(curl -s -o /dev/null -w '%{http_code}' -H 'if-none-match: "0000000000000000000000000000000000000000000000000000000000000000"' "http://127.0.0.1:$port/v1/app/description?platform=android&level=1")
[ "$other" = 200 ] && control "the same route asked with another ETag is answered 200" || bad "(control) another ETag was answered $other"

# ---- 2. sign-in -------------------------------------------------------------------------------------------
shot 1-signin
screen=$(texts)
if printf '%s\n' "$screen" | grep -qx 'Name' && printf '%s\n' "$screen" | grep -qx 'Passphrase' && ! printf '%s\n' "$screen" | grep -q 'Face scan'; then
  pass "the sign-in form draws Name and Passphrase and not the camera field it does not know"
  control "the known fields beside the hidden one are on screen"
else
  bad "sign-in shows: $(printf '%s' "$screen" | tr '\n' '|')"
fi
before=$(requests POST /v1/session)
drive tap 'Sign in'
if drive wait 'Name is needed.' 20 && [ "$(requests POST /v1/session)" = "$before" ]; then
  pass "an empty form says 'Name is needed.' and sends no request"
else
  bad "the empty form: $(cat "$work/drive.last"), $(requests POST /v1/session) sign-in requests"
fi
drive type Name ann
drive type Passphrase wrong-pass
adbs shell input keyevent 111
drive tap 'Sign in'
if drive wait 'wrong name or passphrase' 30 && [ "$(session_files)" = 0 ]; then
  shot 2-refused
  pass "a wrong passphrase shows the server's refusal and no session is kept"
else
  bad "the wrong passphrase: $(cat "$work/drive.last"), session files $(session_files)"
fi
drive type Passphrase ''
adbs shell input keycombination 113 29 > /dev/null 2>&1
adbs shell input keyevent 67
adbs shell input text fixture-pass-1
adbs shell input keyevent 111
drive tap 'Sign in'
if drive logwait 'screen ready: library' 40 && drive wait '3 kept' 30; then
  shot 3-library
  if [ "$(session_files)" = 1 ]; then
    control "after the right passphrase the same listing finds one kept session file"
  else
    bad "(control) no session file after signing in"
  fi
else
  bad "signing in did not show the list: $(adbs logcat -d -v tag -s 'hey.api:*' | tail -4)"
fi
if drive logwait 'request: POST /v1/events -> 200' 20 \
  && [ "$(requests POST /v1/events)" = 1 ] \
  && [ "$(last_request POST /v1/events surface)" = '"android"' ] \
  && [ "$(last_request GET /v1/items surface)" = '"android"' ]; then
  pass "the signed-in library view emits one manifest-declared semantic event, and ordinary API requests identify the android surface"
else
  bad "telemetry after sign-in: events $(requests POST /v1/events), event surface $(last_request POST /v1/events surface), items surface $(last_request GET /v1/items surface)"
fi

# ---- 3. sealed --------------------------------------------------------------------------------------------
token=$(tail -1 "$work/tokens.txt")
name=$(adbs shell run-as "$package" ls no_backup 2> /dev/null | tr -d '\r' | grep '^hey-session-' | head -1)
adbs exec-out run-as "$package" cat "no_backup/$name" > "$work/sealed.bin" 2> /dev/null
sealed_bytes=$(wc -c < "$work/sealed.bin" | tr -d ' ')
if [ "${#token}" = 64 ] && [ "$sealed_bytes" -gt 64 ] && ! grep -q "$token" "$work/sealed.bin" && ! LC_ALL=C grep -qa "${token:0:16}" "$work/sealed.bin" \
  && [ "$(logged 'sealed with Keystore key')" -ge 1 ]; then
  pass "the kept session no_backup/$name ($sealed_bytes bytes) does not hold the issued token or any 16 characters of it; it was sealed with an Android Keystore key"
else
  bad "the kept session: token ${#token} chars, file $sealed_bytes bytes"
fi
grep -q "$token" "$work/tokens.txt" && control "the same search finds the token in the server's list of issued tokens" || bad "(control) the token search found nothing"

# ---- 4. hidden kinds --------------------------------------------------------------------------------------
drive scrollto 'Your account' 6
shot 4-library-bottom
screen=$(texts; drive scrollto 'Kept' 0; texts)
hidden_seen=''
for word in Teleport Carousel CAROUSEL Portal Beam; do printf '%s\n' "$screen" | grep -qx "$word" && hidden_seen="$hidden_seen $word"; done
if [ -z "$hidden_seen" ] && printf '%s\n' "$screen" | grep -qx 'Stalker' && printf '%s\n' "$screen" | grep -qx 'Mark all read' \
  && printf '%s\n' "$screen" | grep -qx 'Your account' && printf '%s\n' "$screen" | grep -qx 'Later'; then
  pass "the list draws the server's rows, 'Mark all read', 'Your account' and the supported search tab Later, while hiding Teleport, Carousel, Portal and Beam"
else
  bad "hidden/required kinds on screen:$hidden_seen; screen: $(printf '%s' "$screen" | tr '\n' '|' | cut -c1-300)"
fi
drive scrollto 'Mark all read' 6
drive tap 'Mark all read'
/bin/sleep 3
never=$(requests GET /v1/never)$(requests POST /v1/never)
if [ "$never" = 00 ] && [ "$(requests POST /v1/mark)" = 1 ]; then
  pass "nothing ever asked for a hidden kind's route (/v1/never: 0 requests)"
  control "the tap on the known button beside them was sent (POST /v1/mark: 1)"
else
  bad "hidden routes asked: $never; POST /v1/mark: $(requests POST /v1/mark)"
fi

# ---- 5. a row, and back ------------------------------------------------------------------------------------
drive scrollto 'Stalker' 6
drive tap 'Stalker'
if drive wait 'Andrei Tarkovsky' 30 && drive wait 'Made by' 10; then
  shot 5-item
  on_item=$(texts)
  if [ "$(last_request GET /v1/items/i2 bearer)" = true ] && ! printf '%s\n' "$on_item" | grep -qx '3 kept'; then
    pass "tapping 'Stalker' opens its screen: GET /v1/items/i2 with the bearer token, 'Made by Andrei Tarkovsky'"
  else
    bad "the item screen: bearer $(last_request GET /v1/items/i2 bearer)"
  fi
else
  bad "tapping the row did not open the item: $(cat "$work/drive.last")"
fi
adbs shell input keyevent 4
if drive logwait 'back to: library' 20 && drive wait '3 kept' 20; then
  shot 6-back
  pass "system back returns to the list ('3 kept' again; it was not on the item screen)"
else
  bad "back did not return to the list"
fi
i=0
while [ "$(requests POST /v1/events)" -lt 3 ] && [ "$i" -lt 20 ]; do i=$((i + 1)); sleep 0.25; done
if [ "$(requests POST /v1/events)" -ge 3 ] && [ "$(last_request POST /v1/events status)" = 200 ]; then
  pass "opening the item and returning to Library each emit a screen view; telemetry follows presentation rather than redraws"
else
  bad "screen-view sequence emitted $(requests POST /v1/events) events"
fi

# ---- 6. kept session ---------------------------------------------------------------------------------------
checks=$(requests GET /v1/session)
launch
if drive logwait 'screen ready: library' 40 && [ "$(logged 'screen ready: signin')" = 0 ] && [ "$(requests GET /v1/session)" -gt "$checks" ]; then
  pass "launched again with a kept session, the app checks it (GET /v1/session) and opens the list with no sign-in"
else
  bad "the kept session did not open the list"
fi

# ---- 7. sign-out --------------------------------------------------------------------------------------------
drive tap Account
drive wait 'Signed in as' 30
drive scrollto 'Sign out of this phone' 6
drive tap 'Sign out of this phone'
if drive wait 'Sign out of this phone?' 20; then
  shot 7-confirm
  revokes=$(requests POST /v1/session/revoke)
  drive tap 'Sign out'
  if drive logwait 'signed out' 30 && drive logwait 'screen ready: signin' 30 && [ "$(requests POST /v1/session/revoke)" = $((revokes + 1)) ] && [ "$(session_files)" = 0 ]; then
    shot 8-signed-out
    pass "sign-out asked first, then POST /v1/session/revoke, removed the kept session and showed sign-in"
    [ "$revokes" = 0 ] && control "nothing was revoked before the confirmation was answered" || bad "(control) a revoke was sent before confirming"
  else
    bad "sign-out: revokes $(requests POST /v1/session/revoke), session files $(session_files)"
  fi
else
  bad "sign-out did not ask first"
fi

# ---- 8. served, stored, baked --------------------------------------------------------------------------------
sed 's/"title":"Fixture sign-in"/"title":"Fixture sign-in, served"/' "$ROOT/specs/support/api_fixture_description.json" > "$served.new" && mv "$served.new" "$served"
served_sha=$(hey_android_sha256 "$served")
launch
if drive logwait "a new served copy ${served_sha:0:12} is stored" 40 && drive wait 'Fixture sign-in, served' 30; then
  shot 9-served
  pass "a new served description (${served_sha:0:12}) is stored and drawn while nothing is in progress"
else
  bad "the served copy was not drawn: $(adbs logcat -d -v tag -s 'hey.api:*' | tail -3)"
fi
stop_server
launch
if drive logwait "drawing the stored copy ${served_sha:0:12}" 40 && drive wait 'Fixture sign-in, served' 30 && [ "$(logged 'could not reach the server')" -ge 1 ]; then
  pass "with the server gone, the next launch draws the stored copy at once"
else
  bad "the stored copy was not drawn offline"
fi
# One string for adb shell: split arguments lose their quoting, and the redirect would run outside run-as.
adbs shell "run-as $package sh -c 'echo damaged > files/hey-description/$baked_sha.json'" 2> /dev/null
launch
if drive logwait 'the stored copy is refused (not_json)' 40 && drive logwait "drawing the baked copy ${baked_sha:0:12}" 10 && drive wait 'Fixture sign-in' 20 && ! texts | grep -q 'Fixture sign-in, served'; then
  pass "a damaged stored copy is refused and the baked copy is drawn"
  control "the baked, served and stored titles differ, so each check saw the copy it names"
else
  bad "the damaged stored copy: $(adbs logcat -d -v tag -s 'hey.api:*' | tail -3)"
fi

# ---- 9. no crash ---------------------------------------------------------------------------------------------
adbs logcat -d -b crash > "$work/crash.txt" 2>&1
if ! grep -q "$package" "$work/crash.txt"; then
  pass "the crash buffer names no crash of $package"
else
  bad "the app crashed: $(grep -m3 -A3 "$package" "$work/crash.txt")"
fi

exit "$failed"
