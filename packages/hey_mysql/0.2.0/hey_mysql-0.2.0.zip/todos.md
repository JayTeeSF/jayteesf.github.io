# Todo

1. Implement `MYSQL_STMT` prepared statements and typed/binary parameter/result bindings.
2. Add explicit live MariaDB and MySQL server matrices, authentication plugins, and TLS verification receipts.
3. Add connection pool and partitioned Job ownership helpers.
4. Produce Darwin and Windows native package receipts after Hey's Windows loader is promoted.
5. Evaluate a future pure-Hey asynchronous wire-protocol adapter behind the same porcelain contract.
