# Done

## 0.1.1

- A large tree no longer takes minutes: the OAuth file test lowered each whole
  source with Text.lower (a character-by-character Hey loop, quadratic); it now
  probes the spellings with find. recall_coach_app: minutes -> 26 s.
  bin/package-check refuses a whole-source Text.lower.

## 0.1.0

- `secret-lint` command (package manifest `commands`): scans a project's own
  `.hey` sources, one line per finding plus a summary, exit 1 on findings.
- Flags `==` / `!=` on secret-looking names and Basic/Bearer literals; never on
  presence checks, enum literals, lengths, predicates or content hashes.
- Flags `Crypto.constant_time_equal?` given an argument that is not visibly
  bytes (the runtime answers false for text), including calls spread over
  lines.
- OAuth `state` round-trip compares in files that mention OAuth.
- `# secret-lint: ok <reason>` suppression; an empty reason is a finding.
- Calibrated against eight apps before release: bare scheme checks, content
  hashes, non-OAuth `state` and spec code were false positives and are
  excluded (fixtures in specs/fixtures/clean/calibrated.hey).
