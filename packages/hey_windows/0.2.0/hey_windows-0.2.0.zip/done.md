# Done

- 0.1.0: Win32 + WebView2 host, Hey manifest tool and spec, mingw cross-build and Wine smoke in tools/winbox (linux/amd64), vendored WebView2 SDK 1.0.2903.40. bin/check green on 2026-11-11: the window opens under Wine with the manifest title and size and writes its receipt (webview2=absent there, as expected).
- 0.1.1: application icon, version and publisher details, and an embedded application manifest (asInvoker, Windows 10 and 11, PerMonitorV2 DPI with sizes scaled per monitor, UTF-8 code page, long paths). Receipt gains hey_windows_dpi.
- 0.1.2: publisher shown on the program is the company, JayTeeSF LLC.
- 0.2.0: bin/hey-windows-app (init questionnaire, check, build, installer, release, publish, sign) for any Hey app, driven by its hey-windows-app.json; builds link the Universal C Runtime (llvm-mingw 20261104); 64-bit per-user NSIS installers with Start menu and Settings > Apps entries (CLI apps go on PATH); signing with Microsoft Artifact Signing via Jsign 7.6; releases fingerprinted and published to the site apps/ pages. docs/SHIPPING.md.
