#!/usr/bin/env ruby
# frozen_string_literal: true

# Generate real known-good JWS test vectors (RS256 + ES256) with Ruby's OpenSSL
# bindings. Emits shell `export` lines that bin/package-check sources. Uses only
# the Ruby standard library; no third-party crypto. TEST-ONLY.
require 'base64'
require 'json'
require 'openssl'

def b64u(data)
  Base64.urlsafe_encode64(data, padding: false)
end

# An ECDSA signature arrives as DER SEQUENCE { INTEGER r, INTEGER s }; JWS wants raw R||S.
def der_to_raw_ecdsa(der, size = 32)
  r, s = OpenSSL::ASN1.decode(der).value.map { |integer| integer.value.to_s(2) }
  r.rjust(size, "\x00") + s.rjust(size, "\x00")
end

def make_jwt(header, claims, key, ec:)
  segment = "#{b64u(JSON.generate(header))}.#{b64u(JSON.generate(claims))}"
  raw = key.sign(OpenSSL::Digest.new('SHA256'), segment)
  raw = der_to_raw_ecdsa(raw) if ec
  "#{segment}.#{b64u(raw)}"
end

iss = 'https://issuer.example/'
aud = 'mmeoww-api'
claims = {'iss' => iss, 'aud' => aud, 'sub' => 'user-1', 'exp' => 4_102_444_800, 'nbf' => 0, 'iat' => 0}

# --- RSA / RS256 ---
rsa = OpenSSL::PKey::RSA.new(2048)
rsa_jwks = {'keys' => [{'kty' => 'RSA', 'kid' => 'rsa1', 'alg' => 'RS256', 'use' => 'sig', 'n' => b64u(rsa.n.to_s(2)), 'e' => b64u(rsa.e.to_s(2))}]}
rs_token = make_jwt({'alg' => 'RS256', 'typ' => 'JWT', 'kid' => 'rsa1'}, claims, rsa, ec: false)
# tampered: flip the last character of the signature
tampered = rs_token[0...-1] + (rs_token[-1] == 'A' ? 'B' : 'A')
# alg=none forgery (no signature)
none_token = "#{b64u(JSON.generate('alg' => 'none', 'typ' => 'JWT', 'kid' => 'rsa1'))}.#{b64u(JSON.generate(claims))}."

# --- EC / ES256 (P-256) ---
ec = OpenSSL::PKey::EC.generate('prime256v1')
point = ec.public_key.to_bn.to_s(2)
raise "unexpected EC point length #{point.bytesize}" unless point.getbyte(0) == 0x04 && point.bytesize == 65
ec_jwks = {'keys' => [{'kty' => 'EC', 'kid' => 'ec1', 'alg' => 'ES256', 'crv' => 'P-256', 'use' => 'sig', 'x' => b64u(point[1, 32]), 'y' => b64u(point[33, 32])}]}
es_token = make_jwt({'alg' => 'ES256', 'typ' => 'JWT', 'kid' => 'ec1'}, claims, ec, ec: true)

{
  'HEY_JOSE_ISS' => iss,
  'HEY_JOSE_AUD' => aud,
  'HEY_JOSE_RS256_TOKEN' => rs_token,
  'HEY_JOSE_RS256_JWKS' => JSON.generate(rsa_jwks),
  'HEY_JOSE_TAMPERED_TOKEN' => tampered,
  'HEY_JOSE_NONE_TOKEN' => none_token,
  'HEY_JOSE_ES256_TOKEN' => es_token,
  'HEY_JOSE_ES256_JWKS' => JSON.generate(ec_jwks)
}.each do |name, value|
  raise "#{name} cannot be single-quoted" if value.include?("'")

  # single-quote for safe shell sourcing
  puts "export #{name}='#{value}'"
end
