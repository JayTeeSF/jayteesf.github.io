#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log.h"
#include "hey_durable_log_native.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int count_record(void *context, uint64_t sequence, uint64_t batch_id,
                        uint64_t stream_id, const void *payload,
                        uint32_t payload_length) {
  int *count = context;
  if (sequence != 1 || batch_id != 1 || stream_id != 42 || payload_length != 5 ||
      memcmp(payload, "hello", 5) != 0) return 1;
  (*count)++;
  return 0;
}

int main(void) {
  char path[] = "/tmp/hdl-native-XXXXXX";
  int placeholder = mkstemp(path);
  if (placeholder < 0) return 1;
  close(placeholder);
  unlink(path);

  HeyNativeUtf8View path_view = {path, strlen(path)};
  HeyNativeHandle connection = hey_durable_log_native_open(path_view, 64, 16, 250, 0);
  if (connection == 0) return 1;
  const uint8_t payload[] = {'h', 'e', 'l', 'l', 'o'};
  HeyNativeBytesView payload_view = {payload, sizeof(payload)};
  HeyNativeHandle receipt = hey_durable_log_native_submit(connection, 42, payload_view);
  if (receipt == 0 || hey_durable_log_native_receipt_status(receipt) != HDL_OK ||
      hey_durable_log_native_receipt_sequence(receipt) != 1 ||
      hey_durable_log_native_receipt_batch_id(receipt) != 1 ||
      hey_durable_log_native_receipt_durable_offset(receipt) <= 64) return 1;
  hey_durable_log_native_receipt_close(receipt);

  HeyNativeHandle cursor = hey_durable_log_native_cursor_open(connection);
  if (cursor == 0) return 1;
  HeyNativeHandle replayed = hey_durable_log_native_cursor_next(cursor);
  if (replayed == 0 || hey_durable_log_native_record_status(replayed) != HDL_OK ||
      hey_durable_log_native_record_sequence(replayed) != 1 ||
      hey_durable_log_native_record_batch_id(replayed) != 1 ||
      hey_durable_log_native_record_stream_id(replayed) != 42) return 1;
  HeyNativeBytesView replayed_payload = hey_durable_log_native_record_payload(replayed);
  if (replayed_payload.length != 5 || memcmp(replayed_payload.data, "hello", 5) != 0) return 1;
  hey_durable_log_native_record_close(replayed);
  HeyNativeHandle finished = hey_durable_log_native_cursor_next(cursor);
  if (finished == 0 || hey_durable_log_native_record_status(finished) != HDL_DONE) return 1;
  hey_durable_log_native_record_close(finished);
  if (hey_durable_log_native_cursor_close(cursor) != HDL_OK) return 1;

  if (hey_durable_log_native_close(connection) != HDL_OK) return 1;

  hdl_log *log = NULL;
  if (hdl_open(path, NULL, &log) != HDL_OK) return 1;
  int count = 0;
  if (hdl_scan(log, count_record, &count) != HDL_OK || count != 1) return 1;
  if (hdl_close(log) != HDL_OK) return 1;
  unlink(path);
  puts("PASS: native adapter durability receipt");
  return 0;
}
