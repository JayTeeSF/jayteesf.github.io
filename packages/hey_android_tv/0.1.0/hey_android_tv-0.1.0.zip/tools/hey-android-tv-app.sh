#!/usr/bin/env sh
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
HEY_ANDROID_ROOT=${HEY_ANDROID_ROOT:-$HOME/dev/hey_android}
out=''
source="$PACKAGE_ROOT/examples/native_android_tv_app.hey"
application_id='com.hey_lang.party_tv'
display_name='Hey Party TV'
build_app=false
launch=false
device=''
usage() {
  cat <<'HELP'
usage: hey android-tv-app --out DIRECTORY [options]

Generate a native Android TV / Google TV application from ordinary Hey.

Options:
  --source FILE.hey
  --application-id ID
  --display-name NAME
  --build
  --launch
  --device SERIAL
  --plan-only
HELP
}
while [ "$#" -gt 0 ]; do
  case "$1" in
    --out) shift; out=${1:?missing --out value} ;;
    --source) shift; source=${1:?missing --source value} ;;
    --application-id) shift; application_id=${1:?missing --application-id value} ;;
    --display-name) shift; display_name=${1:?missing --display-name value} ;;
    --build) build_app=true ;;
    --launch) build_app=true; launch=true ;;
    --device) shift; device=${1:?missing --device value} ;;
    --plan-only) build_app=false; launch=false ;;
    --help|-h) usage; exit 0 ;;
    *) echo "unknown Android TV option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
[ -n "$out" ] || { echo '--out is required' >&2; exit 2; }
[ -f "$HEY_ANDROID_ROOT/hey-package.json" ] || {
  echo "hey_android package is required: $HEY_ANDROID_ROOT" >&2
  echo "Install and lock hey_android 0.1.4 before using hey_android_tv." >&2
  exit 69
}
grep -F '"name": "hey_android"' "$HEY_ANDROID_ROOT/hey-package.json" >/dev/null
grep -F '0.1.4' "$HEY_ANDROID_ROOT/VERSION" >/dev/null || {
  echo "hey_android 0.1.4 is required: $HEY_ANDROID_ROOT" >&2
  exit 69
}

# Generic Android source-to-project/ELF targeting remains shared plumbing. The
# published hey_android package supplies toolchain, emulator/device, lifecycle,
# and generic Android evidence conventions; this package applies only TV deltas.
"$HEY_ROOT/bin/hey" mobile android app \
  --out "$out" \
  --source "$source" \
  --entry android_tv_app_manifest \
  --action-entry android_tv_action_code \
  --application-id "$application_id" \
  --display-name "$display_name" \
  --minimum-api 23 \
  --target-sdk 35 \
  --plan-only >/dev/null

cat > "$out/app/src/main/AndroidManifest.xml" <<EOF_XML
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
  <uses-feature android:name="android.software.leanback" android:required="true" />
  <uses-feature android:name="android.hardware.touchscreen" android:required="false" />
  <uses-feature android:name="android.hardware.gamepad" android:required="false" />
  <application android:allowBackup="false" android:banner="@drawable/tv_banner"
    android:label="$display_name" android:theme="@android:style/Theme.Material.NoActionBar">
    <activity android:name=".MainActivity" android:exported="true"
      android:screenOrientation="landscape">
      <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
      </intent-filter>
    </activity>
  </application>
</manifest>
EOF_XML
mkdir -p "$out/app/src/main/res/drawable"
cat > "$out/app/src/main/res/drawable/tv_banner.xml" <<'EOF_BANNER'
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
  <solid android:color="#101820" />
  <corners android:radius="8dp" />
</shape>
EOF_BANNER

java_file=$(find "$out/app/src/main/java" -name MainActivity.java -print -quit)
python3 - "$java_file" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
s = s.replace('import android.view.Gravity;\n', 'import android.view.Gravity;\nimport android.view.KeyEvent;\n')
marker = '\n}\n'
addition = '''\n  @Override public boolean dispatchKeyEvent(KeyEvent event) {
    if (event.getAction() == KeyEvent.ACTION_UP &&
        (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_CENTER ||
         event.getKeyCode() == KeyEvent.KEYCODE_ENTER ||
         event.getKeyCode() == KeyEvent.KEYCODE_BUTTON_A)) {
      View focused = getCurrentFocus();
      if (focused != null && focused.performClick()) return true;
    }
    return super.dispatchKeyEvent(event);
  }
'''
pos = s.rfind(marker)
if pos < 0:
    raise SystemExit('MainActivity class terminator missing')
s = s[:pos] + addition + s[pos:]
s = s.replace('      renderScreen(first);\n', '      renderScreen(first);\n      View initial = content.focusSearch(View.FOCUS_DOWN);\n      if (initial != null) initial.requestFocus();\n')
p.write_text(s)
PY

grep -F 'android.intent.category.LEANBACK_LAUNCHER' "$out/app/src/main/AndroidManifest.xml" >/dev/null
grep -F 'android.hardware.touchscreen" android:required="false' "$out/app/src/main/AndroidManifest.xml" >/dev/null
grep -F 'KEYCODE_DPAD_CENTER' "$java_file" >/dev/null
grep -F 'requestFocus()' "$java_file" >/dev/null

built=false; installed=false; launched=false; apk=''; serial="$device"
if [ "$build_app" = true ]; then
  [ -f "${HEY_ANDROID_ENV_FILE:-$HOME/.config/hey/android.env}" ] && . "${HEY_ANDROID_ENV_FILE:-$HOME/.config/hey/android.env}"
  command -v gradle >/dev/null 2>&1 || { echo 'gradle is required for --build; use hey_android tooling/01-install-android-toolchain-macos.sh' >&2; exit 69; }
  [ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ] || { echo 'ANDROID_HOME or ANDROID_SDK_ROOT is required for --build' >&2; exit 69; }
  [ -n "${ANDROID_NDK_HOME:-}" ] || { echo 'ANDROID_NDK_HOME is required for --build' >&2; exit 69; }
  gradle -p "$out" --no-daemon assembleDebug | tee "$out/gradle-build.log"
  apk="$out/app/build/outputs/apk/debug/app-debug.apk"
  [ -f "$apk" ] || { echo "debug APK missing: $apk" >&2; exit 70; }
  built=true
fi
if [ "$launch" = true ]; then
  command -v adb >/dev/null 2>&1 || { echo 'adb is required for --launch' >&2; exit 69; }
  if [ -z "$serial" ]; then serial=$(adb devices | awk 'NR > 1 && $2 == "device" {print $1; exit}'); fi
  [ -n "$serial" ] || { echo 'no Android TV emulator/device found' >&2; exit 70; }
  adb -s "$serial" install -r "$apk" | tee "$out/adb-install.txt"
  adb -s "$serial" shell am force-stop "$application_id"
  adb -s "$serial" shell am start -n "$application_id/.MainActivity" | tee "$out/adb-launch.txt"
  installed=true; launched=true
fi
cat > "$out/television-receipt.json" <<EOF_RECEIPT
{"kind":"hey-android-tv-app-v1","ordinary_hey_source":true,"semantic_hir":true,"abi_mir":true,"direct_llvm":true,"elf":true,"leanback":true,"touchscreen_required":false,"landscape":true,"dpad_focus":true,"remote_primary_action":true,"public_state_only":true,"qr_join_payload":true,"gradle_build":"$built","device_install":"$installed","device_launch":"$launched","device_serial":"$serial","play_store_ready":false}
EOF_RECEIPT
printf 'Android TV application regression ok ordinary_hey=true hir=true mir=true direct_llvm=true elf=true leanback=true touchscreen=false landscape=true dpad=true focus=true remote_action=true public_only=true qr_payload=true built=%s installed=%s launched=%s\n' "$built" "$installed" "$launched"
