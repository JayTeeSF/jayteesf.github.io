# Done

- 0.1.0: Win32 + WebView2 host, Hey manifest tool and spec, mingw cross-build and Wine smoke in tools/winbox (linux/amd64), vendored WebView2 SDK 1.0.2903.40. bin/check green on 2026-11-11: the window opens under Wine with the manifest title and size and writes its receipt (webview2=absent there, as expected).
- 0.1.1: application icon, version and publisher details, and an embedded application manifest (asInvoker, Windows 10 and 11, PerMonitorV2 DPI with sizes scaled per monitor, UTF-8 code page, long paths). Receipt gains hey_windows_dpi.
- 0.1.2: publisher shown on the program is the company, JayTeeSF LLC.
