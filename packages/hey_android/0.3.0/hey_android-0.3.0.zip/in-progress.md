# In progress

- Nothing. Phase 2's first slice (Views and a native tap) shipped in 0.3.0; slice 2 is next in docs/ROADMAP.md.
