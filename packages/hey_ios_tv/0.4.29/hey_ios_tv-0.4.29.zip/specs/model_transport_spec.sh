#!/usr/bin/env sh
# Execute the same Foundation helpers the tvOS renderer uses.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT HUP INT TERM
cat > "$WORK/model.m" <<'OBJC'
#import <Foundation/Foundation.h>
#import "hey_tv_model_transport.h"
static void expect(BOOL ok, NSString *label) {
  if (!ok) { fprintf(stderr, "FAIL %s\n", label.UTF8String); exit(1); }
  printf("PASS %s\n", label.UTF8String);
}
int main(void) { @autoreleasepool {
  NSURL *origin = [NSURL URLWithString:@"https://queue.example.org/v1/tv/state"];
  NSDictionary *fetch = @{@"url": @"https://queue.example.org/v1/tv/pairing", @"mode": @"model", @"schema": @"example-model-v1", @"credential": @"device", @"method": @"POST", @"body": @{@"viewer": @"alice"}};
  NSMutableURLRequest *request = HeyTVModelRequest(fetch, origin, @"synthetic-secret");
  expect(request != nil && [request.HTTPMethod isEqual:@"POST"], @"bundled request selects method");
  expect([[request valueForHTTPHeaderField:@"Authorization"] isEqual:@"Bearer synthetic-secret"] && ![request.URL.absoluteString containsString:@"synthetic-secret"], @"device bearer is only a header");
  expect(request.timeoutInterval == 12 && !request.HTTPShouldHandleCookies && request.cachePolicy == NSURLRequestReloadIgnoringLocalCacheData, @"bounded request excludes cookies and caches");
  NSDictionary *body = [NSJSONSerialization JSONObjectWithData:request.HTTPBody options:0 error:NULL];
  expect([body[@"viewer"] isEqual:@"alice"], @"bundled request encodes content command");
  for (NSString *url in @[@"https://queue.example.org.evil.test/v1/tv/state", @"https://queue.example.org:444/v1/tv/state", @"http://queue.example.org/v1/tv/state", @"https://user@queue.example.org/v1/tv/state", @"file:///tmp/state", @"https://elsewhere.test/v1/tv/state"]) {
    NSMutableDictionary *attack = fetch.mutableCopy; attack[@"url"] = url;
    expect(HeyTVModelRequest(attack, origin, @"synthetic-secret") == nil, @"credential refuses alternate origin or userinfo");
  }
  NSMutableDictionary *httpsPort = fetch.mutableCopy; httpsPort[@"url"] = @"https://QUEUE.example.org:443/v1/tv/state";
  expect(HeyTVModelRequest(httpsPort, origin, @"synthetic-secret") != nil, @"canonical default port and hostname match");
  NSMutableDictionary *invalid = fetch.mutableCopy; invalid[@"method"] = @"DELETE";
  expect(HeyTVModelRequest(invalid, origin, @"synthetic-secret") == nil, @"unsupported methods refused");
  invalid = fetch.mutableCopy; invalid[@"schema"] = @"";
  expect(HeyTVModelRequest(invalid, origin, @"synthetic-secret") == nil, @"model requires bundled schema");
  for (NSString *bad in @[@"", @"{", @"<html>down</html>", @"[]", @"null", @"{\"schema\":\"other-v1\"}", @"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[]}"]) {
    expect(HeyTVModelEvent([bad dataUsingEncoding:NSUTF8StringEncoding], @"example-model-v1", @"queue", 200) == nil, @"invalid/wrong-schema payload cannot become a model event");
  }
  NSData *data = [@"{\"schema\":\"example-model-v1\",\"title\":\"Content\"}" dataUsingEncoding:NSUTF8StringEncoding];
  NSDictionary *event = HeyTVModelEvent(data, @"example-model-v1", @"queue", 200);
  expect([event[@"kind"] isEqual:@"data"] && [event[@"data"][@"title"] isEqual:@"Content"] && [event[@"body"] isKindOfClass:NSString.class], @"validated content enters Hey as structured data");
  expect(HeyTVModelRetryDelay(1) == 1 && HeyTVModelRetryDelay(3) == 4 && HeyTVModelRetryDelay(100) == 60, @"failure retry doubles to bounded 60 second cap");
  __block BOOL redirectRefused = NO;
  NSURLSession *session = NSURLSession.sharedSession;
  NSURLSessionDataTask *task = [session dataTaskWithRequest:request];
  NSHTTPURLResponse *redirect = [[NSHTTPURLResponse alloc] initWithURL:request.URL statusCode:302 HTTPVersion:@"HTTP/1.1" headerFields:@{}];
  [[HeyTVModelSessionDelegate new] URLSession:session task:task willPerformHTTPRedirection:redirect newRequest:request completionHandler:^(NSURLRequest *next) { redirectRefused = next == nil; }];
  expect(redirectRefused, @"authenticated model transport delegate refuses redirects");
  puts("model transport spec passed");
} return 0; }
OBJC
clang -fobjc-arc -framework Foundation -I "$ROOT/tools" "$WORK/model.m" -o "$WORK/model"
"$WORK/model"
# Compile the actual scene renderer, including the native integration. Older
# syntax checks exercised only the v1 preprocessor branch.
if xcrun --sdk appletvos --show-sdk-path >/dev/null 2>&1; then
  sdk="$(xcrun --sdk appletvos --show-sdk-path)"
  CLANG_MODULE_CACHE_PATH="$WORK/modules" xcrun --sdk appletvos clang \
    --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -DHEY_SCENE_V2 -fsyntax-only "$ROOT/tools/hey_native_tv_runtime.m"
  echo 'PASS actual scene-v2 runtime compiles for tvOS'
fi
