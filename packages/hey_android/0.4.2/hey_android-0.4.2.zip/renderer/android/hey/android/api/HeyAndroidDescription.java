package hey.android.api;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Map;

/**
 * The description this renderer draws: the last good served copy this build
 * stored, when this renderer still takes it, else the copy baked into the APK.
 * It never waits on the network to draw. refresh() asks the served route with
 * the platform, this renderer's level and If-None-Match; a new copy it takes is
 * stored at once and drawn when the host applies it (nothing in progress).
 * A stored copy is named for the baked copy of the build that stored it, so a
 * new build starts from its own.
 */
final class HeyAndroidDescription {
  private static final String TAG = "hey.api";
  static final String ASSET = "hey-api/description.json";
  static final String ORIGIN_ASSET = "hey-api/origin.txt";

  final byte[] bakedBytes;
  final Map<String, Object> baked;
  final String bakedEtag;
  final String origin;
  private final File storedDir;

  Map<String, Object> current;
  String heldEtag;
  String source = "baked";
  Map<String, Object> pending;
  String pendingEtag;
  private boolean fetching;

  HeyAndroidDescription(Context context) throws IOException {
    bakedBytes = asset(context, ASSET);
    Object parsed = Json.parseOrNull(bakedBytes);
    if (!(parsed instanceof Map)) throw new IOException("the baked description is not a JSON object");
    baked = Json.dict(parsed);
    bakedEtag = Descriptions.sha256Hex(bakedBytes);
    origin = new String(asset(context, ORIGIN_ASSET), StandardCharsets.UTF_8).trim();
    storedDir = new File(context.getFilesDir(), "hey-description");
    current = baked;
    heldEtag = bakedEtag;
    File stored = storedFile();
    byte[] storedBytes = stored.exists() ? Files.readAllBytes(stored.toPath()) : null;
    Descriptions.Pick pick = Descriptions.pick(bakedBytes, storedBytes, null, null, Values.RENDERER_PLATFORM, Values.RENDERER_LEVEL);
    if (pick.source.equals("stored")) {
      current = Descriptions.merged(Json.dict(Json.parseOrNull(pick.bytes)), baked);
      heldEtag = Descriptions.sha256Hex(pick.bytes);
      source = "stored";
    } else if (storedBytes != null) {
      Log.w(TAG, "description: the stored copy is refused (" + Descriptions.refusal(storedBytes, null) + ")");
    }
    Log.i(TAG, "description: drawing the " + source + " copy " + heldEtag.substring(0, 12) + " (android level " + Values.RENDERER_LEVEL + ")");
  }

  private static byte[] asset(Context context, String name) throws IOException {
    try (InputStream in = context.getAssets().open(name)) {
      return HeyAndroidHttp.readAll(in);
    }
  }

  File storedFile() { return new File(storedDir, bakedEtag + ".json"); }

  private void store(byte[] body) {
    if (!storedDir.exists() && !storedDir.mkdirs()) return;
    File[] old = storedDir.listFiles();
    if (old != null) for (File f : old) if (!f.getName().equals(storedFile().getName())) f.delete();
    File tmp = new File(storedDir, "incoming.tmp");
    try (FileOutputStream out = new FileOutputStream(tmp)) {
      out.write(body);
      out.getFD().sync();
    } catch (IOException e) {
      Log.w(TAG, "description: could not store the served copy");
      return;
    }
    if (!tmp.renameTo(storedFile())) Log.w(TAG, "description: could not store the served copy");
  }

  interface Arrived {
    void done(boolean arrived);
  }

  /** Ask for this renderer's description; done(true) when a new copy is pending. */
  void refresh(HeyAndroidHttp http, Arrived done) {
    String path = Values.string(Json.dict(baked.get("served")).get("path"));
    if (fetching || !path.startsWith("/")) {
      done.done(false);
      return;
    }
    fetching = true;
    String held = pendingEtag != null ? pendingEtag : heldEtag;
    String query = path + "?platform=" + Values.RENDERER_PLATFORM + "&level=" + Values.RENDERER_LEVEL;
    http.fetchDescription(query, held, (status, etag, body, failure) -> {
      fetching = false;
      if (failure != null) {
        Log.i(TAG, "description: " + failure + "; keeping the " + source + " copy");
        done.done(false);
        return;
      }
      if (status == 304) {
        Log.i(TAG, "description: unchanged (304 for " + held.substring(0, 12) + "); keeping the " + source + " copy");
        done.done(false);
        return;
      }
      if (status != 200) {
        Log.i(TAG, "description: the server answered " + status + "; keeping the " + source + " copy");
        done.done(false);
        return;
      }
      String refusal = Descriptions.refusal(body, etag);
      if (refusal != null) {
        Log.i(TAG, "description: refused (" + refusal + "); keeping the " + source + " copy");
        done.done(false);
        return;
      }
      String hash = Descriptions.sha256Hex(body);
      if (hash.equals(held)) {
        done.done(false);
        return;
      }
      store(body);
      pending = Descriptions.merged(Json.dict(Json.parseOrNull(body)), baked);
      pendingEtag = hash;
      Log.i(TAG, "description: a new served copy " + hash.substring(0, 12) + " is stored");
      done.done(true);
    });
  }

  boolean applyPending() {
    if (pending == null) return false;
    current = pending;
    heldEtag = pendingEtag;
    source = "served";
    pending = null;
    pendingEtag = null;
    Log.i(TAG, "description: drawing the served copy " + heldEtag.substring(0, 12));
    return true;
  }

  Map<String, Object> screenNamed(String id) {
    for (Object s : Json.list(current.get("screens"))) {
      Map<String, Object> screen = Json.dict(s);
      if (Values.string(screen.get("id")).equals(id)) return screen;
    }
    return null;
  }

  Map<String, Object> labels() { return Json.dict(current.get("labels")); }

  String storeName() {
    String name = Values.string(baked.get("secure_store"));
    return name.isEmpty() ? Values.string(baked.get("keychain_service")) : name;
  }
}
