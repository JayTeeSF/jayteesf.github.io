// Actual shipped Foundation selector: valid remote UI must never win.
#import "HeyIOSValues.h"

static NSData *description(NSString *title) {
  return [NSJSONSerialization dataWithJSONObject:@{
    @"schema": @"hey-mobile-api-app-v1", @"platform": @"ios", @"level": @3,
    @"served": @{@"path": @"/retired-definition"},
    @"session": @{@"sign_in_screen": @"login"}, @"tabs": @[@"home"],
    @"screens": @[@{@"id": @"home", @"type": @"list", @"title": title},
                  @{@"id": @"login", @"type": @"form", @"title": title}]
  } options:NSJSONWritingSortedKeys error:nil];
}

int main(void) {
  @autoreleasepool {
    NSData *baked = description(@"Bundled UI");
    NSData *replacement = description(@"REMOTE REPLACEMENT");
    // A refused fixture would not reproduce the old override.
    if (HeyIOSDescriptionRefusal(replacement, HeyIOSSHA256Hex(replacement), NULL)) return 2;
    NSInteger failures = 0;
    for (NSInteger mode = 0; mode < 4; mode++) {
      NSString *source = nil;
      NSData *got = HeyIOSDescriptionPick(baked, mode & 1 ? replacement : nil,
        mode & 2 ? replacement : nil, HeyIOSSHA256Hex(replacement), &source);
      if (![got isEqualToData:baked] || ![source isEqualToString:@"baked"]) {
        fprintf(stderr, "baked-ui: stored=%d served=%d selected %s instead of bundled UI\n",
          !!(mode & 1), !!(mode & 2), source.UTF8String);
        failures++;
      }
    }
    if (failures) return 1;
    puts("hey_ios_baked_ui_selection=true (valid stored/served replacements ignored)");
    return 0;
  }
}
