# fake_api_server.rb: a server shaped like a hey_mobile api_screens backend, for
# specs/api_renderer_emulator_spec.sh. It names no product.
#
#   fake_api_server.rb --port N --description FILE --log FILE --tokens FILE
#
# GET  /v1/app/description?platform=android&level=1
#                          FILE's bytes as they are now (re-read each time), ETag the
#                          SHA-256, Cache-Control no-cache; 304 on a matching If-None-Match
# POST /v1/session         {username: ann, passphrase: fixture-pass-1} -> {token}; else 401
# GET  /v1/session         who the bearer token is, or 401
# POST /v1/session/revoke  the token stops working
# GET  /v1/items           {items, item_count}
# GET  /v1/items/<id>      {item, hook}
# GET  /v1/account         {username}
# POST /v1/mark            {ok}
# POST /v1/search          {q} -> {items} whose title contains q; q "broken" is a 500,
#                          and a q starting "slow" is answered after ten seconds
# anything else            404
#
# Every request is one JSON line in --log: method, path, query, whether it carried
# a bearer token, If-None-Match, the status answered, and the body's keys. Never
# the token itself, so the spec can look for the token in the app's files and not
# find it here by accident. --tokens gets every token issued, one per line, so a
# spec can look for it.
require 'digest'
require 'json'
require 'optparse'
require 'securerandom'
require_relative 'fixture_http'

opts = {}
OptionParser.new do |o|
  o.on('--port N', Integer) { |v| opts[:port] = v }
  o.on('--description FILE') { |v| opts[:description] = v }
  o.on('--log FILE') { |v| opts[:log] = v }
  o.on('--tokens FILE') { |v| opts[:tokens] = v }
end.parse!
%i[port description log tokens].each { |k| abort("--#{k} is required") unless opts[k] }

ITEMS = [
  { 'id' => 'i1', 'title' => 'The Left Hand of Darkness', 'media_type' => 'book', 'creator' => 'Ursula K. Le Guin', 'hook' => 'An envoy on a winter world' },
  { 'id' => 'i2', 'title' => 'Stalker', 'media_type' => 'movie', 'creator' => 'Andrei Tarkovsky', 'hook' => 'Three men walk into the Zone',
    'description' => 'copy sentinel description', 'note' => 'copy sentinel private note',
    'message' => 'copy sentinel message', 'tags_text' => 'copy sentinel tag one and tag two' },
  { 'id' => 'i3', 'title' => 'Longform', 'media_type' => 'podcast', 'creator' => 'Various', 'hook' => 'Writers on how they work' }
].freeze
tokens = {}
# Falsy: nil, false, 0, and empty strings, lists and objects.
falsy = ->(v) { v.nil? || v == false || v == 0 || (v.respond_to?(:empty?) && v.empty?) }
lock = Mutex.new

record = lambda do |req, status, keys|
  auth = req.header('authorization') || ''
  line = { 'method' => req.method, 'path' => req.path, 'query' => req.query,
           'bearer' => auth.start_with?('Bearer '),
           'surface' => req.header('x-my-queue-surface'),
           'if_none_match' => req.header('if-none-match'), 'status' => status, 'body_keys' => keys }
  lock.synchronize { File.open(opts[:log], 'a') { |f| f.write(JSON.generate(line) + "\n") } }
end

who = lambda do |req|
  auth = req.header('authorization') || ''
  next nil unless auth.start_with?('Bearer ')
  lock.synchronize { tokens[auth['Bearer '.length..-1]] }
end

reply = lambda do |req, status, payload: nil, raw: nil, headers: {}, keys: []|
  record.call(req, status, keys)
  body = raw || (payload.nil? ? '' : JSON.generate(payload, ascii_only: true))
  out = headers.to_a
  out << ['content-type', 'application/json'] unless status == 304
  out << ['content-length', (status == 304 ? 0 : body.bytesize).to_s]
  req.respond(status, status == 304 ? '' : body, out)
end

get = lambda do |req|
  path = req.path
  if path == '/v1/app/description'
    q = req.query_values
    next reply.call(req, 400, payload: { 'ok' => false, 'error' => 'platform and level' }) if q['platform'] != ['android'] || q['level'] != ['1']
    data = File.binread(opts[:description])
    etag = "\"#{Digest::SHA256.hexdigest(data)}\""
    held = (req.header('if-none-match') || '').gsub('W/') { '' }
    next reply.call(req, 304, headers: { 'etag' => etag, 'cache-control' => 'no-cache' }) if held == etag
    next reply.call(req, 200, raw: data, headers: { 'etag' => etag, 'cache-control' => 'no-cache' })
  end
  user = who.call(req)
  next reply.call(req, 401, payload: { 'ok' => false, 'error' => 'sign in first' }) if user.nil?
  case path
  when '/v1/session' then reply.call(req, 200, payload: { 'ok' => true, 'username' => user })
  when '/v1/friends/slow'
    sleep 4
    reply.call(req, 200, payload: { 'friends' => [{ 'id' => 'friend-1', 'name' => 'Alex Fixture' }] })
  when '/v1/friends' then reply.call(req, 200, payload: { 'friends' => [{ 'id' => 'friend-1', 'name' => 'Alex Fixture' }] })
  when '/v1/items' then reply.call(req, 200, payload: { 'ok' => true, 'items' => ITEMS, 'item_count' => ITEMS.length })
  when '/v1/account' then reply.call(req, 200, payload: { 'ok' => true, 'username' => user })
  else
    if path.start_with?('/v1/items/')
      item = ITEMS.find { |i| path == '/v1/items/' + i['id'] }
      next reply.call(req, 404, payload: { 'ok' => false, 'error' => 'no such item' }) if item.nil?
      shown = item.merge('poster' => 'https://example.test/poster.png',
                         'url' => item['id'] == 'i2' ? 'https://example.test/watch' : 'javascript:alert(1)')
      answer = { 'ok' => true, 'item' => shown, 'hook' => item['hook'] }
      if item['id'] == 'i2'
        answer['events'] = [{
          'actor' => 'Ron',
          'created_at' => 'Today',
          'body' => "Ron sent this synthetic message to prove the full thread is readable. It has a second paragraph with enough words to exceed three lines on a phone.\n\nFINAL SENTENCE: I am glad you enjoyed the video."
        }]
      end
      next reply.call(req, 200, payload: answer)
    end
    reply.call(req, 404, payload: { 'ok' => false, 'error' => 'not found' })
  end
end

post = lambda do |req|
  path = req.path
  body = begin
    req.body.empty? ? {} : JSON.parse(req.body)
  rescue JSON::ParserError
    {}
  end
  keys = body.is_a?(Hash) ? body.keys.sort : []
  if path == '/v1/session'
    if body['username'] == 'ann' && body['passphrase'] == 'fixture-pass-1'
      token = SecureRandom.hex(32)
      lock.synchronize do
        tokens[token] = 'ann'
        File.open(opts[:tokens], 'a') { |f| f.write(token + "\n") }
      end
      next reply.call(req, 200, payload: { 'ok' => true, 'username' => 'ann', 'token' => token }, keys: keys)
    end
    next reply.call(req, 401, payload: { 'ok' => false, 'error' => 'wrong name or passphrase' }, keys: keys)
  end
  next reply.call(req, 401, payload: { 'ok' => false, 'error' => 'sign in first' }, keys: keys) if who.call(req).nil?
  case path
  when '/v1/session/revoke'
    held = req.header('authorization')['Bearer '.length..-1]
    lock.synchronize { tokens.delete(held) }
    reply.call(req, 200, payload: { 'ok' => true, 'revoked' => 'this' }, keys: keys)
  when '/v1/items/i2/share'
    next reply.call(req, 400, payload: { 'error' => 'wrong selected recipient or note' }, keys: keys) if body != { 'recipient' => 'friend-1', 'note' => 'For you' }
    reply.call(req, 200, payload: { 'url' => 'https://example.test/item/shared' }, keys: keys)
  when '/v1/slow-share'
    sleep 4
    reply.call(req, 200, payload: { 'url' => 'https://example.test/late' }, keys: keys)
  when '/v1/sets/share' then reply.call(req, 200, payload: { 'url' => 'https://example.test/set/shared' }, keys: keys)
  when '/v1/invalid-link' then reply.call(req, 200, payload: { 'url' => 'javascript:alert(1)' }, keys: keys)
  when '/v1/mark' then reply.call(req, 200, payload: { 'ok' => true }, keys: keys)
  when '/v1/search'
    q = (body['q'] || '').to_s.downcase
    next reply.call(req, 500, payload: { 'ok' => false, 'error' => 'the search broke' }, keys: keys) if q == 'broken'
    # Keep the request in flight long enough for uiautomator to read the
    # spinner under a saturated emulator. It must still finish and be ignored
    # after a cleared field, proving the same race with a bounded delay.
    sleep 10 if q.start_with?('slow')
    hits = ITEMS.select { |item| !q.empty? && item['title'].downcase.include?(q) }
    reply.call(req, 200, payload: { 'ok' => true, 'items' => hits }, keys: keys)
  when '/v1/events'
    if body['event_name'] != 'screen.view' || body['surface'] != 'android' || falsy.call(body['screen'])
      next reply.call(req, 400, payload: { 'ok' => false, 'error' => 'bad semantic event' }, keys: keys)
    end
    reply.call(req, 200, payload: { 'ok' => true }, keys: keys)
  else
    reply.call(req, 404, payload: { 'ok' => false, 'error' => 'not found' }, keys: keys)
  end
end

FixtureHttp.serve(opts[:port], "fake api server on 127.0.0.1:#{opts[:port]}",
                  ->(req) { req.method == 'GET' ? get.call(req) : post.call(req) })
