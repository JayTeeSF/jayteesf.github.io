package hey.android.api;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * hey_mobile's conformance vectors against this renderer, on the Mac:
 *
 *   java hey.android.api.ConformanceMain CONFORMANCE_DIR [DESCRIPTION_FILE...]
 *
 * values.json   every vector's answer equals expect (as JSON), or is omitted where omitted is true
 * names.json    every icon name and file kind the vocabulary holds is mapped here, to the same
 *               SF Symbol and Apple types hey_ios draws, and to a Material Symbol and MIME types
 * descriptions  every body is taken or refused as expect says, by the renderer the file names
 *
 * Each DESCRIPTION_FILE (a served android level-1 body) must be taken by this
 * renderer as it is, and refused once its level is raised above this renderer's.
 * Prints one PASS or FAIL line per file, and FAIL lines naming each vector that
 * failed; exits 1 when any fails.
 */
public final class ConformanceMain {
  static int failures = 0;

  static void fail(String what) {
    failures++;
    System.out.println("FAIL: " + what);
  }

  static byte[] read(Path p) throws Exception { return Files.readAllBytes(p); }

  public static void main(String[] args) throws Exception {
    if (args.length < 1) {
      System.err.println("usage: ConformanceMain CONFORMANCE_DIR [DESCRIPTION_FILE...]");
      System.exit(2);
    }
    Path dir = Paths.get(args[0]);
    values(Json.dict(Json.parse(read(dir.resolve("values.json")))));
    names(Json.dict(Json.parse(read(dir.resolve("names.json")))));
    descriptions(Json.dict(Json.parse(read(dir.resolve("descriptions.json")))));
    for (int i = 1; i < args.length; i++) served(Paths.get(args[i]));
    System.exit(failures == 0 ? 0 : 1);
  }

  static void values(Map<String, Object> file) {
    Map<String, Object> labels = Json.dict(file.get("labels"));
    int total = 0;
    int bad = 0;
    Set<String> fns = new HashSet<>();
    for (Object o : Json.list(file.get("vectors"))) {
      Map<String, Object> v = Json.dict(o);
      total++;
      String fn = Values.string(v.get("fn"));
      fns.add(fn);
      Object spec = v.containsKey("spec") ? v.get("spec") : Json.NULL;
      if (spec == Json.NULL) spec = null;
      Object data = v.get("data");
      Map<String, Object> vars = Json.dict(v.get("vars"));
      Object row = v.get("row");
      Object got;
      switch (fn) {
        case "render": got = Values.render(spec, data, labels); break;
        case "line": got = Values.line(spec, data, labels); break;
        case "text": got = Values.text(spec, data, labels); break;
        case "when": got = Values.when(spec, data); break;
        case "truthy": got = Values.truthy(spec == null ? Json.NULL : spec); break;
        case "value": got = Values.value(spec, vars, row); break;
        case "param": got = Values.param(spec, vars, row, data); break;
        case "path": got = Values.fillPath(Values.string(spec), vars); break;
        case "known": got = Values.known(Values.string(v.get("category")), spec, (int) Values.integer(v.get("level"))); break;
        default:
          bad++;
          fail("values.json: '" + v.get("name") + "' names a function this runner does not know: " + fn);
          continue;
      }
      boolean ok;
      if (Values.truthy(v.get("omitted"))) ok = got == Values.OMIT;
      else ok = got != Values.OMIT && Json.same(got, v.get("expect"));
      if (!ok) {
        bad++;
        fail("values.json: '" + v.get("name") + "' (" + fn + ") answered " + (got == Values.OMIT ? "(omitted)" : Json.encode(got))
            + ", expected " + (Values.truthy(v.get("omitted")) ? "(omitted)" : Json.encode(v.get("expect"))));
      }
    }
    if (bad == 0 && total > 0) System.out.println("PASS: values.json: " + total + " of " + total + " vectors (" + String.join(", ", new java.util.TreeSet<>(fns)) + ")");
    else fail("values.json: " + (total - bad) + " of " + total + " vectors");
  }

  static void names(Map<String, Object> file) {
    Map<String, Object> icons = Json.dict(file.get("icons"));
    Map<String, Object> kinds = Json.dict(file.get("file_kinds"));
    int bad = 0;
    for (Map.Entry<String, Object> e : icons.entrySet()) {
      String name = e.getKey();
      String sf = Values.string(e.getValue());
      String material = Names.materialSymbol(name);
      if (!sf.equals(Names.appleSymbol(name))) { bad++; fail("names.json: '" + name + "' is " + sf + " in the vocabulary, " + Names.appleSymbol(name) + " here"); }
      if (material.equals(Names.DEFAULT_ICON)) { bad++; fail("names.json: '" + name + "' has no Material Symbol here"); }
      if (!Names.materialSymbol(sf).equals(material)) { bad++; fail("names.json: the level-1 spelling '" + sf + "' draws " + Names.materialSymbol(sf) + ", but '" + name + "' draws " + material); }
    }
    Set<String> extra = new HashSet<>(Names.iconNames());
    extra.removeAll(icons.keySet());
    if (!extra.isEmpty()) { bad++; fail("names.json: this renderer holds names the vocabulary does not: " + extra); }
    for (Map.Entry<String, Object> e : kinds.entrySet()) {
      List<String> apple = new ArrayList<>();
      for (Object t : Json.list(e.getValue())) apple.add(Values.string(t));
      if (!apple.equals(Names.appleTypes(e.getKey()))) { bad++; fail("names.json: file kind '" + e.getKey() + "' is " + apple + " in the vocabulary, " + Names.appleTypes(e.getKey()) + " here"); }
      if (Names.mimeTypes(e.getKey()).isEmpty()) { bad++; fail("names.json: file kind '" + e.getKey() + "' has no MIME type here"); }
    }
    if (!new HashSet<>(Names.fileKinds()).equals(kinds.keySet())) { bad++; fail("names.json: file kinds here are " + Names.fileKinds() + ", the vocabulary has " + kinds.keySet()); }
    if (!Names.materialSymbol("teleport").equals(Names.DEFAULT_ICON) || !Names.materialSymbol("").equals(Names.DEFAULT_ICON)) { bad++; fail("names.json: an unknown name does not draw the default glyph"); }
    if (!Names.mimeTypes("exe").isEmpty()) { bad++; fail("names.json: an unknown file kind names MIME types"); }
    if (bad == 0) System.out.println("PASS: names.json: " + icons.size() + " icon names and " + kinds.size() + " file kinds map to the same SF Symbols and Apple types as the vocabulary, and each to a Material Symbol and MIME types; an unknown name draws '" + Names.DEFAULT_ICON + "'");
  }

  static void descriptions(Map<String, Object> file) {
    Map<String, Object> renderer = Json.dict(file.get("renderer"));
    String platform = Values.string(renderer.get("platform"));
    int level = (int) Values.integer(renderer.get("level"));
    if (Values.integer(file.get("max_bytes")) != Descriptions.MAX_BYTES) fail("descriptions.json: max_bytes is " + file.get("max_bytes") + ", this renderer takes " + Descriptions.MAX_BYTES);
    int total = 0;
    int bad = 0;
    for (Object o : Json.list(file.get("vectors"))) {
      Map<String, Object> v = Json.dict(o);
      total++;
      byte[] body = Values.string(v.get("body")).getBytes(StandardCharsets.UTF_8);
      long padTo = Values.integer(v.get("pad_to"));
      if (padTo > body.length) {
        byte[] padded = Arrays.copyOf(body, (int) padTo);
        Arrays.fill(padded, body.length, padded.length, (byte) ' ');
        body = padded;
      }
      String etag = v.get("etag") instanceof String ? (String) v.get("etag") : null;
      String refusal = Descriptions.refusal(body, etag, platform, level);
      String got = refusal == null ? "accept" : "refuse";
      if (!got.equals(v.get("expect"))) {
        bad++;
        fail("descriptions.json: '" + v.get("name") + "' was " + got + (refusal == null ? "" : " (" + refusal + ")") + ", expected " + v.get("expect"));
      }
    }
    // The same rules at this renderer's own platform and level.
    Map<String, Object> sound = null;
    for (Object o : Json.list(file.get("vectors"))) {
      Map<String, Object> v = Json.dict(o);
      if ("accept".equals(v.get("expect")) && !v.containsKey("etag")) {
        sound = Json.dict(Json.parseOrNull(Values.string(v.get("body")).getBytes(StandardCharsets.UTF_8)));
        break;
      }
    }
    if (sound == null) {
      bad++;
      fail("descriptions.json: no sound description to carry to android level 1");
    } else {
      sound.put("platform", "android");
      sound.put("level", 1L);
      String asOwn = Descriptions.refusal(Json.encodeBytes(sound), null);
      sound.put("level", 2L);
      String above = Descriptions.refusal(Json.encodeBytes(sound), null);
      sound.put("level", 1L);
      sound.put("platform", "ios");
      String other = Descriptions.refusal(Json.encodeBytes(sound), null);
      if (asOwn != null) { bad++; fail("descriptions.json: the sound description as android level 1 is refused here (" + asOwn + ")"); }
      if (!"level".equals(above)) { bad++; fail("descriptions.json: the sound description as android level 2 is not refused for its level (" + above + ")"); }
      if (!"platform".equals(other)) { bad++; fail("descriptions.json: the sound description as ios level 1 is not refused for its platform (" + other + ")"); }
    }
    if (bad == 0) System.out.println("PASS: descriptions.json: " + total + " of " + total + " bodies taken or refused as expected by " + platform + " level " + level + ", and the sound one is taken as android level 1, refused as android level 2 and as ios");
    else fail("descriptions.json: " + bad + " problems in " + total + " vectors");
  }

  static void served(Path path) throws Exception {
    byte[] body = read(path);
    String refusal = Descriptions.refusal(body, "\"" + Descriptions.sha256Hex(body) + "\"");
    Map<String, Object> d = Json.dict(Json.parse(body));
    d.put("level", 2L);
    String raised = Descriptions.refusal(Json.encodeBytes(d), null);
    if (refusal == null && "level".equals(raised)) {
      System.out.println("PASS: " + path.getFileName() + " (" + body.length + " bytes) is taken by android level 1 with its ETag, and refused once its level says 2");
    } else {
      fail(path.getFileName() + ": taken as it is: " + (refusal == null) + " (" + refusal + "); refused at level 2: " + raised);
    }
  }
}
