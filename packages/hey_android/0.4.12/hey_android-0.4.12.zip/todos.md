# Todo

- Renderer level 2 (docs/ROADMAP.md, phase 2B): draw icons, search and audio screens, rating, direct share/copy, web sign-in, document and set_var actions, row actions, badges; then declare level 2.
- Renderer: RecyclerView lists, pull to refresh and paging; App Links (the Play signing key's fingerprint); Media3 audio and Android Auto.
- JNI route, research only: scrolling, text entry, back and TalkBack from Hey with no Java.
- Toolchain (docs/ROADMAP.md): a per-call error boundary, and the LLVM-lane miscompiles found in slice 1.
- x86_64 library for x86 emulators.
- Run the 16 KB alignment on a 16 KB kernel (the `_ps16k` system image) instead of checking it statically only.

- Level 3: multiple-recipient chooser, remote chooser search and lookup offers; retain the honest level-1 single-choice fallback until conformance is complete.

- Real microphone and device recognizer availability are user/device dependent;
  synthetic renderer instrumentation does not certify audio recognition.
