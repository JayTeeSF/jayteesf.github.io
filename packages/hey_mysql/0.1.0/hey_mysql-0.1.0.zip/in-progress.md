# In progress

0.1.0 argv construction and batch-row parsing are complete. The packed release passes clean installation, lockfile pinning, installed-hash verification, and compiled `pkg:hey_mysql@0.1.0/main` import. A live MySQL server/client receipt remains external.
