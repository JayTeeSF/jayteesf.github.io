# hey_cache

A **read-through cache chain** for Hey applications. A lookup walks an
ordered list of layers; the first live hit wins; a miss falls through; the
last resort is calling the application to compute the value, which is then
populated back up the chain.

It is the role Redis usually plays, not the protocol. See
[What this is not](#what-this-is-not).

```hey
import 'pkg:hey_cache@0.1.0/main'

fn render_page(key)
  return expensive_render(key)
end

let cache = HeyCache.open({
  namespace: 'pages',
  layers: [
    HeyCache.memory_layer('mem', {ttl_ms: 30000}),
    HeyCache.store_layer('disk', HeyCache.binding(
      HeyRecordStore.file('/var/cache/pages'),
      HeyRecordStore.fetch, HeyRecordStore.store, HeyRecordStore.delete
    ), {ttl_ms: 3600000}),
  ],
  default_ttl_ms: 60000,
})

let hit = HeyCache.fetch(cache, 'home', render_page, {})
says hit.value        # the page
says hit.layer        # which layer answered ('' when the app computed it)
set cache = hit.cache # every operation returns a NEW cache
```

## The layer model

```
  HeyCache.fetch(cache, key, compute, options)
        |
        v
  [0] memory  ──hit?──> return, and that's it
        |  miss / expired
        v
  [1] store   ──hit?──> return, AND write back into layer 0
        |  miss / expired
        v
  [2] store   ──hit?──> return, AND write back into layers 0 and 1
        |  miss / expired
        v
  compute(key)  ── the application ── then write into every writable layer
```

**Layer 0 is normally `memory_layer`** — a process-local hash living inside
the cache value. Fastest, and it dies with the process.

**Layers 1..N are `store_layer`s** — each one an *injected* binding of four
things: a handle plus `fetch` / `write` / `erase` callables. That contract is
exactly `hey_record`'s store surface, so:

| you want | you inject |
|---|---|
| a file layer | `HeyRecordStore.file(root)` |
| a SQLite layer | `HeyRecordStore.sql(sqlite_connection, table)` |
| a MySQL layer | `HeyRecordStore.sql(mysql_connection, table)` |
| something else | any record whose three callables honour the contract |

`hey_cache` writes **no SQL, no file layout, and no connection handling**,
and declares **no dependencies**. It never imports `hey_record`,
`hey_sqlite3` or `hey_mysql`; it is handed their behaviour. That is the same
coupling `hey_record` itself uses ("never dials and never imports a driver")
and is the ecosystem's actual practice — no `hey_*` package has a
cross-package import.

### The binding contract

```
fetch(handle, namespace, key)        -> Result; code 'not_found' when absent
write(handle, namespace, key, value) -> Result
erase(handle, namespace, key)        -> Result; code 'not_found' when absent
```

`not_found` is a **miss**. Any other failing code is a **real error**: it is
reported by layer name in `result.errors`, it increments the error counter,
and the walk continues. A dead database must not look like a cold cache.

## Every knob

### `HeyCache.open(options)`

| key | default | meaning |
|---|---|---|
| `namespace` | *required* | scopes every key. Becomes the collection in a store layer. Non-empty, no `/`, `\` or `..`. |
| `layers` | *required* | ordered list, nearest first. At least one. |
| `default_ttl_ms` | `0` | ttl when neither the write nor the layer specifies one. `0` = never expires. |
| `write_back` | `true` | on a hit at layer *i*, populate layers `0..i-1`. |
| `write_through` | `true` | `write`/`fetch` store into every writable layer. `false` = layer 0 only. |
| `clock` | `HeyCache.system_clock()` | or `HeyCache.fixed_clock(ms)` for deterministic expiry. |

Invalid configuration **fails** rather than returning a `Result`: a cache
with no namespace is a programmer bug. Invalid *keys* at call time are data,
and come back as a typed `invalid_key` refusal with `compute` never called.

### `HeyCache.memory_layer(name, options)` / `HeyCache.store_layer(name, binding, options)`

| key | memory default | store default | meaning |
|---|---|---|---|
| `ttl_ms` | `-1` | `-1` | `-1` inherit, `0` never expires, `>0` milliseconds. |
| `read_only` | `false` | `false` | never written, only read. Refusals are reported. |
| `allow_sensitive` | `true` | `false` | whether this layer accepts values marked sensitive. |

### `HeyCache.write(cache, key, value, options)` / `HeyCache.fetch(cache, key, compute, options)`

| key | default | meaning |
|---|---|---|
| `ttl_ms` | `-1` | per-entry ttl. Same sentinels. Beats the layer, which beats the cache. |
| `sensitive` | `false` | mark the value as not-for-persistence. See below. |

TTL resolution, outermost wins: **write option → layer → cache default**.

## Operations

| call | returns |
|---|---|
| `HeyCache.lookup(cache, key)` | walk the chain, no compute |
| `HeyCache.write(cache, key, value, options)` | store into the writable layers |
| `HeyCache.fetch(cache, key, compute, options)` | read-through; `compute` called at most once |
| `HeyCache.forget(cache, key)` | invalidate in **every** layer |
| `HeyCache.probe(cache, layer_name, key)` | read ONE named layer directly |
| `HeyCache.sweep(cache)` | drop expired entries from the memory layers |
| `HeyCache.advance(cache, delta_ms)` | move a fixed clock (specs, and expiry reasoning) |
| `HeyCache.stats(cache)` | counters |
| `HeyCache.layer_names(cache)` | ordered layer names |

Every mutating call returns a record with a **`cache` field holding the new
cache**. Thread it; the old value is still valid and still holds the old
memory layer.

`compute` is a plain callable, passed by **bare name**
(`HeyCache.fetch(cache, k, MyApp.render, {})`). Do **not** wrap it in
`bind()` — `bind()` does not lower in the compiled lane; bare callables do,
including module-qualified ones stored in records.

### A compute with nothing to return

Return `HeyCache.no_value()`. Nothing is cached and `fetch` comes back with
`code: 'not_cached'` and `value: nil`.

**Never return a bare `nil` from a compute callable.** In the compiled lane a
`nil` returned through a dynamically invoked callable arrives as the integer
`0`; the cache would then store a real `0` in compiled builds and store
nothing on the interpreter. `HeyCache.no_value()` is a record, and records
round-trip identically in both lanes. This is measured, not defensive: the
gate that runs every spec compiled caught exactly this.

Negative caching — *remembering* the absence so the next miss does not call
the app — is **not supported at 0.1.0**
(`capabilities().negative_caching == false`).

## Write-back

On a hit at layer *i*, the entry is written into layers `0..i-1`. The
promoted entry **keeps its original `expires_at_ms`**: a promotion may never
extend a value's life. Where the receiving layer's own ttl is *shorter*, the
entry is clamped **down** to it, never up. A layer that refuses the promotion
(read-only, or a sensitive value meeting a layer that did not opt in) appears
in `promotion_refused`.

Turn it off with `{write_back: false}`.

## Expiry

Expiry is checked **at read**. An expired entry is a miss, it is evicted from
the layer that held it, and **the walk continues** — an expired layer-0 entry
must not mask a live layer-1 entry.

`HeyCache.sweep` drops expired entries from memory layers eagerly. Store
layers are not swept: enumerating a whole collection is a backing-store
decision, not a cache decision. Their expired entries are still evicted
lazily by the read that finds them.

## Invalidation

`HeyCache.forget(cache, key)` attempts **every** layer and **never stops
early**, including after a layer fails:

```hey
let gone = HeyCache.forget(cache, 'user:1')
says gone.ok        # false only if a layer FAILED
says gone.removed   # layer names that held it
says gone.missing   # layer names that did not (not an error)
says gone.errors    # [{layer, code, error}] -- act on these
```

A delete that stops at layer 0 looks correct through the chain: the next
lookup misses, recomputes, repopulates. It is wrong only later, when layer 0
is cold and the stale layer-2 copy surfaces and is **promoted back up as if
it were fresh**. That is a machine for serving stale data, and it passes any
test that reads through the chain.

So verify invalidation with `HeyCache.probe`, layer by layer — never through
the chain:

```hey
says HeyCache.probe(gone.cache, 'mem', 'user:1').found   # false
says HeyCache.probe(gone.cache, 'disk', 'user:1').found  # false
```

`probe` reports **raw physical presence** in `found` and the separate logical
question in `expired`, and it does no fallthrough, no write-back and no
eviction.

## Namespacing

Every key is scoped by the cache's `namespace`. Two caches over the *same*
store handle with different namespaces cannot read or invalidate each
other's values: the memory layer keys on `namespace + '/' + key`, and the
store layer passes the namespace as the collection.

Namespaces and keys are validated with `hey_record`'s rule — non-empty, no
`/`, no `\`, no `..` — at the cache boundary, so a bad key is one typed
refusal rather than a half-applied write discovered at layer 3.

## What is not cacheable

Mark a value `{sensitive: true}` and **store layers refuse it by default**.
A credential in the memory layer dies with the process; the same value
written through to a persistent layer outlives the process, the request, and
ends up in a backup.

```hey
let out = HeyCache.write(cache, 'token', secret, {sensitive: true})
says out.written   # ["mem"]
says out.refused   # [{layer: 'disk', code: 'sensitive_refused'}]
```

The refusal is **reported, never silent**, and counted in
`HeyCache.stats(cache).refusals` so you can alarm on it. Write-back honours
it too. A layer that genuinely should hold such values opts in with
`{allow_sensitive: true}`.

This is a guard against *accident*, not a secrets manager. It does not
encrypt anything, and it cannot stop you passing `{sensitive: false}`.

## The miss storm (thundering herd)

**0.1.0 does nothing about it, deliberately.**

When a hot key expires, every caller that reaches the end of the chain calls
`compute`. With N concurrent callers you get N computes.

There is no shared mutable state in this design to coordinate on: a cache is
a value, and two processes holding two cache values cannot see each other.
Single-flight would need either an actor owning the cache or a lock in a
shared layer, and both are real design decisions rather than a patch.

What you can do today:
- give hot keys a longer `ttl_ms` at the persistent layer than at memory, so
  a memory expiry falls through to a warm layer instead of to the app;
- refresh hot keys ahead of expiry with an explicit `HeyCache.write`.

`HeyCache.capabilities().single_flight` reports `false`. It is stated rather
than silent because silence about a missing guarantee is the defect.

## What this is not

- **Not the Redis wire protocol**, not a network server, not a distributed
  cache. "Redis-like substitute" means the ROLE, not the protocol.
- **Not a service.** A cache is a value; operations return a new value.
- **Not concurrent.** No locking, no single-flight, no cross-process
  coordination beyond whatever the injected store itself provides.
- **Not an eviction policy.** There is no LRU and no size bound: memory
  layers grow until entries expire or `HeyCache.sweep` runs. A memory layer
  with `default_ttl_ms: 0` and no sweeping is an unbounded map.
- **The MySQL layer is UNMEASURED.** The layer table above shows
  `HeyRecordStore.sql(mysql_connection, table)`, and that is a statement
  about `hey_record`'s interface — not a receipt from this package.
  `bin/check` exercises the file store and a real `hey_sqlite3`
  connection; **no gate has ever run hey_cache against MySQL.** It ought
  to work, because this package is handed a store's behaviour rather than
  talking to a database itself, and that indirection is the whole design.
  But "ought to work" and "was measured" are different claims and only one
  of them is in the gates. Treat MySQL as untested until a gate says
  otherwise.

## Checking it

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
bin/check
```

Six gates: the version drift guard, knob coverage, every spec on the
interpreter lane, every spec COMPILED against its own expect block, a
two-lane receipt (built with `heyc build` *and* interpreted, stdouts diffed
byte for byte), the real `hey_record` file store written in one process and
read cold in another, and the real `hey_record` SQL store over a real
`hey_sqlite3` connection with the row count asserted against the database
itself.

Gates 4 and 5 need sibling checkouts and **skip loudly** when they are
absent. For gate 5, build the native library first:

```sh
(cd ../hey_sqlite3 && bin/build-native --out /tmp/hey_sqlite3_lib)
export HEY_SQLITE3_LIBRARY=/tmp/hey_sqlite3_lib/libhey_sqlite3.dylib
bin/check
```

## Version

0.1.0. The single in-source version literal is
`hey_cache_version_value()` in `cache.hey`; `bin/check` greps it against
`VERSION`.
