# Todo

1. Move `mount_helper_spec` into `bin/check-compiled`'s COMPILABLE list
   once the trunk's `bind()` fix lands, and make `HeyAdmin.mount` the
   recommended mounting form in the README.
2. Add a `HeyRecordModel` source when `hey_record`'s `model.hey` lowers.
3. Replace `form.hey`'s ASCII printable-table decoder when
   `Text.from_code_point` lands, and delete the limit from the README.
4. CSRF tokens. Needed before anyone exposes this to a browser that
   visits other origins; deliberately not faked at 0.1.0.
5. A `hey_i18n` bridge that resolves a catalog into the `labels` record.
6. Search, filtering, sort-by-column — all need a query vocabulary the
   source contract does not currently have.
