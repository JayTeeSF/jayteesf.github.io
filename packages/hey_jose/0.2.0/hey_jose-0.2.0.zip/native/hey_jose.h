#ifndef HEY_JOSE_H
#define HEY_JOSE_H

#include "hey_native_abi.h"

/* base64url-decode to a UTF-8 text view (used to read the JWS header/claims
 * JSON). Returns an empty view on malformed input. The view is valid until the
 * next call to this function. */
HeyNativeUtf8View hey_jose_b64url_to_text(HeyNativeUtf8View input);

/* HMAC-SHA256(key, message) as lowercase hex (the HS256 primitive; also used
 * for Stripe/webhook signature verification). key and message are byte-safe.
 * Returns a 64-char hex view (valid until the next call), or empty on failure. */
HeyNativeUtf8View hey_jose_hmac_sha256_hex(HeyNativeUtf8View key,
                                           HeyNativeUtf8View message);

/* Verify an RSA JWS signature. sha_bits selects the digest (256/384/512); pss
 * selects RSASSA-PSS (1) vs RSASSA-PKCS1-v1_5 (0). signing_input is the exact
 * ASCII "<header>.<payload>". signature/n/e are base64url (RFC 7518).
 * Returns 1 = verified, 0 = signature mismatch, negative = error. */
int32_t hey_jose_verify_rsa(int32_t sha_bits, int32_t pss,
                            HeyNativeUtf8View signing_input,
                            HeyNativeUtf8View signature_b64url,
                            HeyNativeUtf8View n_b64url,
                            HeyNativeUtf8View e_b64url);

/* Verify an ECDSA (P-256/P-384/P-521) JWS signature. sha_bits selects the
 * digest and curve (256->P-256, 384->P-384, 521->P-521). The JWS signature is
 * the raw R||S; x/y are base64url coordinates.
 * Returns 1 = verified, 0 = signature mismatch, negative = error. */
int32_t hey_jose_verify_ec(int32_t sha_bits,
                           HeyNativeUtf8View signing_input,
                           HeyNativeUtf8View signature_b64url,
                           HeyNativeUtf8View x_b64url,
                           HeyNativeUtf8View y_b64url);

/* Sign `signing_input` with an EC private key. Returns the JWS signature as
 * raw R||S, base64url, unpadded (RFC 7515) -- or an EMPTY view on any failure,
 * matching hey_jose_b64url_to_text. The view is valid until the next call.
 *
 * sha_bits selects digest and curve (256->P-256/ES256, 384->P-384, 521->P-521).
 * private_key_pem is a PEM private key -- PKCS#8 (Apple's .p8) or SEC1.
 *
 * This is the primitive Sign in with Apple needs: Apple issues no static client
 * secret, only a short-lived ES256-signed JWT. */
HeyNativeUtf8View hey_jose_sign_ec(int32_t sha_bits,
                                   HeyNativeUtf8View signing_input,
                                   HeyNativeUtf8View private_key_pem);

#endif
