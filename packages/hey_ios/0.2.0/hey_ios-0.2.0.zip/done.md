# Done

- v0.1.0 capability and framework contracts.
- Development entitlement metadata without manufacturing unsupported profile entitlements.
- Updated package controls for external `hey_packager` tooling and the repaired `hey_mobile` dependency.
- v0.2.0 native host for `hey_mobile` 0.2.0 `api_screens` apps: the renderer (tabs, lists, detail, forms, inline half-star rating, sign-in sheet, search with polling and a note when incomplete, document upload, video, web links, tab badges, rows still being looked up), the Keychain session, audio (pages in order with resume and one position report per item in flight, Apple Music, Now Playing, remote commands), a share extension, and `tools/hey-ios-api-app.sh` for simulator and paired-iPhone builds with development profiles and an app icon from one 1024 square. CarPlay moved out to `hey_carplay` behind `--extension DIR` and three audio-feed hooks, so the host names no extension. First consumer: My Queue.
