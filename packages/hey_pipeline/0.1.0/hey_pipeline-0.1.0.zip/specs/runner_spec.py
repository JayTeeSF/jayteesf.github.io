#!/usr/bin/env python3
import json, pathlib, subprocess, sys, tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
RUNNER = ROOT / "bin" / "hey-pipeline"

def run(args, cwd):
    return subprocess.run([sys.executable, str(RUNNER), *args], cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def git(cwd, *args):
    subprocess.run(["git", *args], cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def main():
    with tempfile.TemporaryDirectory() as td:
        root = pathlib.Path(td)
        git(root, "init")
        git(root, "config", "user.email", "pipeline@example.invalid")
        git(root, "config", "user.name", "pipeline spec")
        manifest = {
            "manifest_version":1, "name":"spec", "max_parallel":4,
            "resources":{"heavy":1}, "profiles":{"fast":{"exclude_tags":["slow"]}},
            "lanes":[
                {"name":"pass","command":[sys.executable,"-c","print('pass')"]},
                {"name":"negative","command":[sys.executable,"-c","raise SystemExit(7)"],"expect":"failure"},
                {"name":"dependent","command":[sys.executable,"-c","print('dep')"],"needs":["pass"]},
                {"name":"slow","command":[sys.executable,"-c","print('slow')"],"tags":["slow"]}
            ]
        }
        (root/"hey-pipeline.json").write_text(json.dumps(manifest))
        (root/".gitignore").write_text(".hey/pipeline/\n")
        (root/"tracked").write_text("x")
        git(root, "add", "."); git(root, "commit", "-m", "fixture")
        p = run(["run", "hey-pipeline.json", "--profile", "fast"], root)
        assert p.returncode == 0, p.stdout
        receipt = json.loads((root/".hey/pipeline/latest.json").read_text())
        assert receipt["result"] == "GREEN"
        assert {x["name"] for x in receipt["lanes"]} == {"pass","negative","dependent"}
        assert all(x["status"] == "PASS" for x in receipt["lanes"])
        sha = subprocess.check_output(["git","rev-parse","HEAD"], cwd=root, text=True).strip()
        p = run(["run", "hey-pipeline.json", "--release", "--sha", sha], root)
        assert p.returncode == 0, p.stdout
        rp = root/".hey/pipeline"/(sha+".json")
        p = run(["verify-receipt", str(rp), "--release", "--sha", sha], root)
        assert p.returncode == 0, p.stdout
        (root/"tracked").write_text("dirty")
        p = run(["run", "hey-pipeline.json", "--release", "--sha", sha], root)
        assert p.returncode != 0 and "dirty" in p.stdout.lower(), p.stdout
        git(root, "checkout", "--", "tracked")
        bad = dict(manifest); bad["lanes"] = [{"name":"missing","command":["definitely-not-a-real-tool"],"requires":["definitely-not-a-real-tool"]}]
        (root/"hey-pipeline.json").write_text(json.dumps(bad))
        p = run(["run", "hey-pipeline.json"], root)
        assert p.returncode != 0 and "missing required tool" in p.stdout, p.stdout
    print("runner_spec: green")

if __name__ == "__main__": main()
