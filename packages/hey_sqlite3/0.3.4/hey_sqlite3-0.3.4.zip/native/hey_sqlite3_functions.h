#ifndef HEY_SQLITE3_FUNCTIONS_H
#define HEY_SQLITE3_FUNCTIONS_H

#include <sqlite3.h>

/* Registers the package's built-in SQL scalar functions on `database`.
   Called once per connection from hey_sqlite3_open(). Returns SQLITE_OK or
   the first failing sqlite3_create_function_v2() status.

   This header is deliberately NOT part of the FFI surface declared in
   hey_sqlite3.h / hey.native.json: nothing here crosses the Hey boundary, so
   it takes a real `sqlite3 *` rather than a HeyNativeHandle. */
int hey_sqlite3_register_functions(sqlite3 *database);

#endif
