package hey.android.api;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The one player in this process, and the one thing that reports where the
 * listener got to.
 *
 * <p>WHY IT IS A SINGLETON. Two things now want to play audio: the Listen tab
 * and, in a car, a head unit browsing this app's media service. They are
 * separate components of the same app, and if each held its own player then
 * pressing play in the car while the phone was already playing would run two at
 * once -- two voices, and two different ideas of where the listener stopped,
 * the last one written winning. There is one player, and whichever side is
 * looking watches it.
 *
 * <p>ONE REPORTER, for the same reason. The position route is sent from here
 * alone; a screen and a service both reporting would write the same second
 * twice and, worse, disagree.
 */
final class HeyAndroidPlayback implements HeyAndroidPlayer.Watcher, HeyAndroidHttp.Session {
  static final String TAG = "hey.api";

  private static HeyAndroidPlayback shared;

  /** The process's player, built on first use by whichever side got there first. */
  static synchronized HeyAndroidPlayback of(Context context) {
    if (shared == null) shared = new HeyAndroidPlayback(context.getApplicationContext());
    return shared;
  }

  /** The one already built, or null. For a caller that must not build one. */
  static synchronized HeyAndroidPlayback existing() {
    return shared;
  }

  final HeyAndroidPlayer player;
  final HeyAndroidDescription description;
  final HeyAndroidHttp http;
  private final HeyAndroidSecureStore store;
  private final List<Runnable> watching = new ArrayList<>();

  private HeyAndroidPlayback(Context context) {
    HeyAndroidDescription read = null;
    try {
      read = new HeyAndroidDescription(context);
    } catch (Exception e) {
      Log.e(TAG, "playback: no readable description (" + e.getMessage() + ")");
    }
    description = read;
    String origin = description == null ? "" : description.origin;
    http = new HeyAndroidHttp(origin, this);
    store = description == null ? null : new HeyAndroidSecureStore(context, description.storeName());
    player = new HeyAndroidPlayer(this, Screens.reportEvery(audio()));
  }

  /** The description's audio block: what the feed is and how to report a position. */
  Map<String, Object> audio() {
    if (description == null) return new LinkedHashMap<>();
    return Json.dict(description.current.get("audio"));
  }

  /** The session header to send with audio served by this app's own server, and nothing else. */
  Map<String, String> headers() {
    Map<String, String> out = new LinkedHashMap<>();
    if (description == null) return out;
    Map<String, Object> session = Json.dict(description.current.get("session"));
    String header = Values.string(session.get("header"));
    String held = token();
    if (header.isEmpty() || held == null || held.isEmpty()) return out;
    out.put(header, Values.string(session.get("prefix")) + held);
    return out;
  }

  void watch(Runnable onChange) {
    if (!watching.contains(onChange)) watching.add(onChange);
  }

  void unwatch(Runnable onChange) {
    watching.remove(onChange);
  }

  // ---- what the player tells everyone watching -------------------------------------------

  @Override public void changed() {
    // A copy, because a watcher may stop watching while being told.
    for (Runnable r : new ArrayList<>(watching)) r.run();
  }

  @Override public void report(String id, int seconds, int page, boolean finished) {
    Map<String, Object> route = Json.dict(audio().get("position"));
    if (route.isEmpty() || id == null || id.isEmpty()) return;
    Map<String, Object> vars = new LinkedHashMap<>();
    vars.put("id", id);
    vars.put("seconds", seconds);
    vars.put("page", page);
    vars.put("finished", finished);
    http.send(route, vars, null, (status, json, error) -> {
      if (error != null) Log.i(TAG, "could not report where the listener stopped: " + error);
    });
  }

  // ---- the session this app's own server expects ------------------------------------------

  @Override public String token() {
    return store == null ? null : store.read();
  }

  @Override public Map<String, Object> description() {
    return description == null ? new LinkedHashMap<>() : description.current;
  }

  @Override public void signedOut() {
    // NOTHING PLAYS FOR SOMEBODY WHO IS SIGNED OUT. The screen has its own
    // answer to this; here the only right thing is to stop.
    player.stop(false);
  }
}
