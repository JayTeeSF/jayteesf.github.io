# In progress

0.1.0 descriptor and JSON-row implementation is complete. The packed release passes clean installation, lockfile pinning, installed-hash verification, and compiled `pkg:hey_sqlite3@0.1.0/main` import. A live sqlite3 executable receipt remains external.
