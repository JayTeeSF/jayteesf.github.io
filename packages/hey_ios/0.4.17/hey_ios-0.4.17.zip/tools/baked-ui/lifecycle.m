// Runs the shipped app delegate, scene delegate, loader and UIKit controllers.
// Only Keychain and transport are replaced; all data is synthetic.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wnullability-completeness"
#import "HeyIOSApiHost.m"
#pragma clang diagnostic pop
#import <objc/runtime.h>

static NSData *bundled;
static NSData *replacement;
static NSMutableArray<NSURLRequest *> *requests;
static BOOL offline;
static NSInteger cacheReads;
static NSInteger failures;

const char *HeyIOSBakedOrigin(void) { return "https://baked-ui.example.test"; }
static const char *manifest(void) { return bundled.bytes; }
static int64_t manifestLength(void) { return (int64_t)bundled.length - 1; }

static void check(BOOL ok, NSString *message) {
  if (!ok) { fprintf(stderr, "baked-ui: %s\n", message.UTF8String); failures++; }
}
static void later(void (^run)(void)) {
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue(), run);
}
static void checkBundled(HeyIOSApi *api, NSString *phase) {
  check(api.failure.length == 0, [phase stringByAppendingString:@": bundled UI failed to load"]);
  check([[api screenNamed:@"home"][@"title"] isEqual:@"Bundled home"], [phase stringByAppendingString:@": remote UI replaced bundled home"]);
  check([api screenNamed:@"compose"].count > 0, [phase stringByAppendingString:@": bundled form disappeared"]);
  check(cacheReads == 0, [phase stringByAppendingString:@": downloaded UI cache was read"]);
  @synchronized (requests) {
    for (NSURLRequest *request in requests) {
      check(![request.URL.path isEqual:@"/retired-definition"], [phase stringByAppendingString:@": definition network request"]);
      check([request.URL.host isEqual:@"baked-ui.example.test"], @"request escaped synthetic transport origin");
      check([[request valueForHTTPHeaderField:@"authorization"] isEqual:@"Bearer synthetic-session"], @"content request lost its session header");
    }
  }
}

@interface BakedTransport : NSURLProtocol
@end
@implementation BakedTransport
+ (BOOL)canInitWithRequest:(NSURLRequest *)request { return YES; }
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }
- (void)startLoading {
  @synchronized (requests) { [requests addObject:self.request]; }
  if (offline) {
    [self.client URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorNotConnectedToInternet userInfo:nil]];
    return;
  }
  NSData *body = [self.request.URL.path isEqual:@"/retired-definition"] ? replacement :
    [@"{\"rows\":[{\"title\":\"Bundled content\"}],\"count\":2}" dataUsingEncoding:NSUTF8StringEncoding];
  NSHTTPURLResponse *response = [[NSHTTPURLResponse alloc] initWithURL:self.request.URL statusCode:200 HTTPVersion:@"HTTP/1.1" headerFields:@{@"Content-Type": @"application/json", @"ETag": HeyIOSSHA256Hex(body)}];
  [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
  [self.client URLProtocol:self didLoadData:body];
  [self.client URLProtocolDidFinishLoading:self];
}
- (void)stopLoading {}
@end

@interface BakedTestDelegate : HeyIOSAppDelegate
@end
@implementation BakedTestDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
  BOOL launched = [super application:application didFinishLaunchingWithOptions:options];
  later(^{
    HeyIOSApi *api = [HeyIOSApi shared];
    HeyIOSHost *host = [HeyIOSHost shared];
    checkBundled(api, @"cold launch");
    check([host.window.rootViewController isKindOfClass:UITabBarController.class], @"real scene did not draw bundled tabs");
    check(![api respondsToSelector:NSSelectorFromString(@"refreshDescription:")] &&
          ![api respondsToSelector:NSSelectorFromString(@"applyPending")] &&
          ![host respondsToSelector:NSSelectorFromString(@"refreshDescription")], @"production UI replacement methods remain");
    [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationDidBecomeActiveNotification object:nil];
    later(^{
      checkBundled(api, @"foreground");
      UITabBarController *tabs = (UITabBarController *)host.window.rootViewController;
      UINavigationController *nav = (UINavigationController *)tabs.viewControllers.firstObject;
      HeyIOSListController *list = (HeyIOSListController *)nav.viewControllers.firstObject;
      [list reloadContent]; // same load path as the pull-to-refresh control
      later(^{
        checkBundled(api, @"manual refresh");
        check([list.screenJSON[@"rows"] count] == 1, @"content refresh stopped working");
        check([nav.tabBarItem.badgeValue isEqual:@"2"], @"foreground badge refresh stopped working");
        offline = YES;
        HeyIOSApi *fresh = [[HeyIOSApi alloc] init];
        [fresh loadManifest]; // actual cold loader, with transport now offline
        checkBundled(fresh, @"offline startup");
        [list reloadContent];
        [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationWillEnterForegroundNotification object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationDidBecomeActiveNotification object:nil];
        later(^{
          checkBundled(api, @"offline refresh/resume");
          check(requests.count > 0, @"transport observer saw no content requests");
          if (!failures) puts("hey_ios_baked_ui_lifecycle=true (cold launch, foreground, manual refresh, stale cache, offline, authenticated content and badges)");
          fflush(stdout);
          exit(failures ? 1 : 0);
        });
      });
    });
  });
  return launched;
}
@end

int main(int argc, char **argv) {
  @autoreleasepool {
    requests = [NSMutableArray array];
    NSDictionary *home = @{@"id": @"home", @"type": @"list", @"title": @"Bundled home",
      @"tab": @{@"title": @"Home", @"badge": @{@"source": @{@"path": @"/content/badge"}, @"path": @"count"}},
      @"source": @{@"path": @"/content/home"}, @"sections": @[@{@"type": @"rows", @"from": @"rows", @"row": @{@"title": @"title"}}]};
    NSDictionary *fixture = @{@"schema": @"hey-mobile-api-app-v1", @"platform": @"ios", @"level": @3,
      @"served": @{@"path": @"/retired-definition"}, @"tabs": @[@"home"],
      @"session": @{@"header": @"authorization", @"prefix": @"Bearer ", @"sign_in_screen": @"compose", @"check": @{@"path": @"/content/session"}},
      @"screens": @[home, @{@"id": @"compose", @"type": @"form", @"title": @"Bundled form", @"fields": @[@{@"id": @"message", @"type": @"text"}]}]};
    NSMutableData *bytes = [[NSJSONSerialization dataWithJSONObject:fixture options:NSJSONWritingSortedKeys error:nil] mutableCopy];
    replacement = [NSJSONSerialization dataWithJSONObject:@{@"schema": @"hey-mobile-api-app-v1", @"platform": @"ios", @"level": @3,
      @"tabs": @[@"home"], @"session": @{@"sign_in_screen": @"home"},
      @"screens": @[@{@"id": @"home", @"type": @"list", @"title": @"REMOTE REPLACEMENT"}]} options:0 error:nil];
    check(HeyIOSDescriptionRefusal(replacement, nil, NULL) == nil, @"stale cache fixture is invalid");
    // A matching old cache in this isolated test app's sandbox. No real app data.
    NSURL *support = [[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    NSURL *cache = [support URLByAppendingPathComponent:@"HeyIOSDescription" isDirectory:YES];
    [[NSFileManager defaultManager] createDirectoryAtURL:cache withIntermediateDirectories:YES attributes:nil error:nil];
    [replacement writeToURL:[cache URLByAppendingPathComponent:[HeyIOSSHA256Hex(bytes) stringByAppendingString:@".json"]] atomically:YES];
    [bytes appendBytes:"\0" length:1];
    bundled = bytes;
    HeyIOSApiHostStart(manifest, manifestLength);
    Method token = class_getInstanceMethod(HeyIOSApi.class, @selector(token));
    method_setImplementation(token, imp_implementationWithBlock(^NSString *(id self) { return @"synthetic-session"; }));
    Method read = class_getClassMethod(NSData.class, @selector(dataWithContentsOfURL:));
    IMP originalRead = method_getImplementation(read);
    method_setImplementation(read, imp_implementationWithBlock(^NSData *(id cls, NSURL *url) {
      if ([url.path containsString:@"HeyIOSDescription"]) cacheReads++;
      return ((NSData *(*)(id, SEL, NSURL *))originalRead)(cls, @selector(dataWithContentsOfURL:), url);
    }));
    [NSURLProtocol registerClass:BakedTransport.class];
    // Ephemeral sessions also use the synthetic transport, if a regression
    // restores the legacy fetcher. Never open a real socket from this harness.
    Method config = class_getClassMethod(NSURLSessionConfiguration.class, @selector(ephemeralSessionConfiguration));
    IMP originalConfig = method_getImplementation(config);
    method_setImplementation(config, imp_implementationWithBlock(^NSURLSessionConfiguration *(id cls) {
      NSURLSessionConfiguration *c = ((id (*)(id, SEL))originalConfig)(cls, @selector(ephemeralSessionConfiguration));
      c.protocolClasses = @[BakedTransport.class];
      return c;
    }));
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(BakedTestDelegate.class));
  }
}
