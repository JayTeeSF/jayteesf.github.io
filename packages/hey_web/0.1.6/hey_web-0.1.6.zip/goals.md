# Goals

## High level

Make `hey_web` the standard application framework above Hey's official web stack: a practical replacement for curl/wget-style commands and Puma-style serving, written in Hey and shaped for routes, controllers, views, JSON APIs, models, and Jobs.

## Tactical

- Keep protocol/socket primitives in stdlib.
- Keep handlers testable through pure dispatch.
- Make operational configuration file-based while keeping callables in source.
- Integrate cleanly with `hey_record`, `hey_sqlite3`, and `hey_mysql`.
- Preserve immutable package releases and reproducible handoff artifacts.
