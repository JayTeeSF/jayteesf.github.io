# Done

- Added direct argv command construction and batch/raw row parsing.
- Added callable adapter descriptors, Result normalization, defaults, and capability reporting.
- Added package/docs/spec/handoff tooling.
- Verified the packed release through clean package install, lockfile pinning, installed-content verification, and compiled `pkg:` import.
