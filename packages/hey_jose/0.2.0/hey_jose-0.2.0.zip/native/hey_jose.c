#include "hey_jose.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/ecdsa.h>
#include <openssl/param_build.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/core_names.h>
#include <openssl/hmac.h>

/* ---- base64url decode ---- */
static int b64url_val(unsigned char c) {
  if (c >= 'A' && c <= 'Z') return c - 'A';
  if (c >= 'a' && c <= 'z') return c - 'a' + 26;
  if (c >= '0' && c <= '9') return c - '0' + 52;
  if (c == '-') return 62;
  if (c == '_') return 63;
  return -1;
}

/* Decode base64url into a freshly malloc'd buffer. Returns length, or -1 on
 * malformed input. *out is set to the buffer (caller frees) on success. */
static long b64url_decode(const char *data, size_t len, unsigned char **out) {
  unsigned char *buf = (unsigned char *)malloc(len / 4 * 3 + 4);
  if (!buf) return -1;
  size_t o = 0;
  int quad[4];
  int qn = 0;
  for (size_t i = 0; i < len; i++) {
    unsigned char c = (unsigned char)data[i];
    if (c == '=' || c == '\r' || c == '\n') continue;
    int v = b64url_val(c);
    if (v < 0) { free(buf); return -1; }
    quad[qn++] = v;
    if (qn == 4) {
      buf[o++] = (unsigned char)((quad[0] << 2) | (quad[1] >> 4));
      buf[o++] = (unsigned char)((quad[1] << 4) | (quad[2] >> 2));
      buf[o++] = (unsigned char)((quad[2] << 6) | quad[3]);
      qn = 0;
    }
  }
  if (qn == 1) { free(buf); return -1; }
  if (qn == 2) {
    buf[o++] = (unsigned char)((quad[0] << 2) | (quad[1] >> 4));
  } else if (qn == 3) {
    buf[o++] = (unsigned char)((quad[0] << 2) | (quad[1] >> 4));
    buf[o++] = (unsigned char)((quad[1] << 4) | (quad[2] >> 2));
  }
  *out = buf;
  return (long)o;
}

HeyNativeUtf8View hey_jose_b64url_to_text(HeyNativeUtf8View input) {
  static char *scratch = NULL;
  if (scratch) { free(scratch); scratch = NULL; }
  unsigned char *decoded = NULL;
  long n = b64url_decode(input.data, input.length, &decoded);
  if (n < 0) return (HeyNativeUtf8View){"", 0};
  scratch = (char *)malloc((size_t)n + 1);
  if (!scratch) { free(decoded); return (HeyNativeUtf8View){"", 0}; }
  memcpy(scratch, decoded, (size_t)n);
  scratch[n] = '\0';
  free(decoded);
  return (HeyNativeUtf8View){scratch, (size_t)n};
}

/* ---- HMAC-SHA256 (the HS256 primitive; also Stripe/webhook signatures) ----
 * Computes HMAC-SHA256(key, message) and returns it as lowercase hex in a
 * per-call static scratch buffer (the runtime copies the view immediately).
 * key and message are byte-safe (data+length), so binary secrets and raw
 * request bodies are handled correctly. Returns an empty view on failure. */
HeyNativeUtf8View hey_jose_hmac_sha256_hex(HeyNativeUtf8View key,
                                           HeyNativeUtf8View message) {
  static char hex[65];
  unsigned char mac[EVP_MAX_MD_SIZE];
  unsigned int maclen = 0;
  const unsigned char *out =
    HMAC(EVP_sha256(),
         key.data, (int)key.length,
         (const unsigned char *)message.data, message.length,
         mac, &maclen);
  if (!out || maclen != 32) return (HeyNativeUtf8View){"", 0};
  static const char digits[] = "0123456789abcdef";
  for (unsigned int i = 0; i < 32; i++) {
    hex[i * 2] = digits[(mac[i] >> 4) & 0xF];
    hex[i * 2 + 1] = digits[mac[i] & 0xF];
  }
  hex[64] = '\0';
  return (HeyNativeUtf8View){hex, 64};
}

static const EVP_MD *md_for(int32_t sha_bits) {
  if (sha_bits == 384) return EVP_sha384();
  if (sha_bits == 512 || sha_bits == 521) return EVP_sha512();
  return EVP_sha256();
}

/* ---- RSA verify ---- */
int32_t hey_jose_verify_rsa(int32_t sha_bits, int32_t pss,
                            HeyNativeUtf8View signing_input,
                            HeyNativeUtf8View signature_b64url,
                            HeyNativeUtf8View n_b64url,
                            HeyNativeUtf8View e_b64url) {
  unsigned char *sig = NULL, *nraw = NULL, *eraw = NULL;
  long siglen = b64url_decode(signature_b64url.data, signature_b64url.length, &sig);
  long nlen = b64url_decode(n_b64url.data, n_b64url.length, &nraw);
  long elen = b64url_decode(e_b64url.data, e_b64url.length, &eraw);
  int32_t rc = -1;
  BIGNUM *n = NULL, *e = NULL;
  OSSL_PARAM_BLD *bld = NULL;
  OSSL_PARAM *params = NULL;
  EVP_PKEY_CTX *pctx = NULL;
  EVP_PKEY *pkey = NULL;
  EVP_MD_CTX *mdctx = NULL;
  EVP_PKEY_CTX *vctx = NULL;

  if (siglen < 0 || nlen < 0 || elen < 0) { goto done; }
  n = BN_bin2bn(nraw, (int)nlen, NULL);
  e = BN_bin2bn(eraw, (int)elen, NULL);
  if (!n || !e) { goto done; }

  bld = OSSL_PARAM_BLD_new();
  if (!bld) { goto done; }
  if (!OSSL_PARAM_BLD_push_BN(bld, "n", n) || !OSSL_PARAM_BLD_push_BN(bld, "e", e)) { goto done; }
  params = OSSL_PARAM_BLD_to_param(bld);
  if (!params) { goto done; }

  pctx = EVP_PKEY_CTX_new_from_name(NULL, "RSA", NULL);
  if (!pctx || EVP_PKEY_fromdata_init(pctx) <= 0) { goto done; }
  if (EVP_PKEY_fromdata(pctx, &pkey, EVP_PKEY_PUBLIC_KEY, params) <= 0 || !pkey) { goto done; }

  mdctx = EVP_MD_CTX_new();
  if (!mdctx) { goto done; }
  if (EVP_DigestVerifyInit(mdctx, &vctx, md_for(sha_bits), NULL, pkey) <= 0) { goto done; }
  if (pss) {
    if (EVP_PKEY_CTX_set_rsa_padding(vctx, RSA_PKCS1_PSS_PADDING) <= 0) { goto done; }
    if (EVP_PKEY_CTX_set_rsa_pss_saltlen(vctx, RSA_PSS_SALTLEN_DIGEST) <= 0) { goto done; }
    if (EVP_PKEY_CTX_set_rsa_mgf1_md(vctx, md_for(sha_bits)) <= 0) { goto done; }
  } else {
    if (EVP_PKEY_CTX_set_rsa_padding(vctx, RSA_PKCS1_PADDING) <= 0) { goto done; }
  }
  if (EVP_DigestVerifyUpdate(mdctx, signing_input.data, signing_input.length) <= 0) { goto done; }
  {
    int v = EVP_DigestVerifyFinal(mdctx, sig, (size_t)siglen);
    rc = (v == 1) ? 1 : 0;
  }

done:
  if (mdctx) EVP_MD_CTX_free(mdctx);
  if (pkey) EVP_PKEY_free(pkey);
  if (pctx) EVP_PKEY_CTX_free(pctx);
  if (params) OSSL_PARAM_free(params);
  if (bld) OSSL_PARAM_BLD_free(bld);
  if (n) BN_free(n);
  if (e) BN_free(e);
  free(sig); free(nraw); free(eraw);
  return rc;
}

/* ---- EC (ECDSA) verify ---- */
static const char *ec_group_for(int32_t sha_bits) {
  if (sha_bits == 384) return "P-384";
  if (sha_bits == 521) return "P-521";
  return "P-256";
}

int32_t hey_jose_verify_ec(int32_t sha_bits,
                           HeyNativeUtf8View signing_input,
                           HeyNativeUtf8View signature_b64url,
                           HeyNativeUtf8View x_b64url,
                           HeyNativeUtf8View y_b64url) {
  unsigned char *sig = NULL, *xraw = NULL, *yraw = NULL, *pub = NULL, *der = NULL;
  long siglen = b64url_decode(signature_b64url.data, signature_b64url.length, &sig);
  long xlen = b64url_decode(x_b64url.data, x_b64url.length, &xraw);
  long ylen = b64url_decode(y_b64url.data, y_b64url.length, &yraw);
  int32_t rc = -1;
  BIGNUM *r = NULL, *s = NULL;
  ECDSA_SIG *ecsig = NULL;
  OSSL_PARAM_BLD *bld = NULL;
  OSSL_PARAM *params = NULL;
  EVP_PKEY_CTX *pctx = NULL;
  EVP_PKEY *pkey = NULL;
  EVP_MD_CTX *mdctx = NULL;

  if (siglen < 0 || xlen < 0 || ylen < 0) { goto done; }
  if (xlen != ylen || (siglen != xlen * 2)) { goto done; } /* JWS raw R||S */

  /* Build the uncompressed public point 0x04 || X || Y. */
  pub = (unsigned char *)malloc((size_t)(1 + xlen + ylen));
  if (!pub) { goto done; }
  pub[0] = 0x04;
  memcpy(pub + 1, xraw, (size_t)xlen);
  memcpy(pub + 1 + xlen, yraw, (size_t)ylen);

  bld = OSSL_PARAM_BLD_new();
  if (!bld) { goto done; }
  if (!OSSL_PARAM_BLD_push_utf8_string(bld, OSSL_PKEY_PARAM_GROUP_NAME, ec_group_for(sha_bits), 0)) { goto done; }
  if (!OSSL_PARAM_BLD_push_octet_string(bld, OSSL_PKEY_PARAM_PUB_KEY, pub, (size_t)(1 + xlen + ylen))) { goto done; }
  params = OSSL_PARAM_BLD_to_param(bld);
  if (!params) { goto done; }

  pctx = EVP_PKEY_CTX_new_from_name(NULL, "EC", NULL);
  if (!pctx || EVP_PKEY_fromdata_init(pctx) <= 0) { goto done; }
  if (EVP_PKEY_fromdata(pctx, &pkey, EVP_PKEY_PUBLIC_KEY, params) <= 0 || !pkey) { goto done; }

  /* Convert raw R||S to a DER ECDSA_SIG. */
  r = BN_bin2bn(sig, (int)(siglen / 2), NULL);
  s = BN_bin2bn(sig + siglen / 2, (int)(siglen / 2), NULL);
  ecsig = ECDSA_SIG_new();
  if (!r || !s || !ecsig) { goto done; }
  if (ECDSA_SIG_set0(ecsig, r, s) != 1) { goto done; }
  r = NULL; s = NULL; /* owned by ecsig now */
  {
    int derlen = i2d_ECDSA_SIG(ecsig, &der);
    if (derlen <= 0) { goto done; }
    mdctx = EVP_MD_CTX_new();
    if (!mdctx) { goto done; }
    if (EVP_DigestVerifyInit(mdctx, NULL, md_for(sha_bits), NULL, pkey) <= 0) { goto done; }
    if (EVP_DigestVerifyUpdate(mdctx, signing_input.data, signing_input.length) <= 0) { goto done; }
    int v = EVP_DigestVerifyFinal(mdctx, der, (size_t)derlen);
    rc = (v == 1) ? 1 : 0;
  }

done:
  if (mdctx) EVP_MD_CTX_free(mdctx);
  if (pkey) EVP_PKEY_free(pkey);
  if (pctx) EVP_PKEY_CTX_free(pctx);
  if (params) OSSL_PARAM_free(params);
  if (bld) OSSL_PARAM_BLD_free(bld);
  if (ecsig) ECDSA_SIG_free(ecsig);
  if (r) BN_free(r);
  if (s) BN_free(s);
  if (der) OPENSSL_free(der);
  free(sig); free(xraw); free(yraw); free(pub);
  return rc;
}

/* ---- signing ------------------------------------------------------------
 *
 * WHY THIS EXISTS. Everything above verifies. Sign in with Apple cannot be
 * implemented without SIGNING: Apple issues no static client secret and
 * instead requires a short-lived JWT, ES256-signed with the .p8 key from the
 * developer portal. hey_oauth already ships a complete Apple provider and
 * punts this one value to the caller -- and until now no Hey package could
 * produce it, so the provider was unreachable one field deep.
 */

/* base64url encode, no padding (RFC 7515 §2). Writes into a caller buffer. */
static size_t b64url_encode(const unsigned char *in, size_t len, char *out) {
  static const char A[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  size_t i = 0, o = 0;
  while (i + 2 < len) {
    unsigned v = (unsigned)in[i] << 16 | (unsigned)in[i + 1] << 8 | in[i + 2];
    out[o++] = A[(v >> 18) & 63]; out[o++] = A[(v >> 12) & 63];
    out[o++] = A[(v >> 6) & 63];  out[o++] = A[v & 63];
    i += 3;
  }
  if (i + 1 == len) {
    unsigned v = (unsigned)in[i] << 16;
    out[o++] = A[(v >> 18) & 63]; out[o++] = A[(v >> 12) & 63];
  } else if (i + 2 == len) {
    unsigned v = (unsigned)in[i] << 16 | (unsigned)in[i + 1] << 8;
    out[o++] = A[(v >> 18) & 63]; out[o++] = A[(v >> 12) & 63]; out[o++] = A[(v >> 6) & 63];
  }
  out[o] = '\0';
  return o;
}

/* Raw R||S length for the curve, which is the coordinate size -- NOT the
 * digest size and NOT whatever DER happened to produce. P-521 is 66 bytes
 * (521 bits rounded up), which is the case that catches people. */
static int ec_coord_len(int32_t sha_bits) {
  if (sha_bits == 256) return 32;
  if (sha_bits == 384) return 48;
  if (sha_bits == 521) return 66;
  return 0;
}

HeyNativeUtf8View hey_jose_sign_ec(int32_t sha_bits,
                                   HeyNativeUtf8View signing_input,
                                   HeyNativeUtf8View private_key_pem) {
  /* Big enough for a P-521 signature (132 raw bytes -> 176 b64 chars). */
  static char sig_b64[256];
  HeyNativeUtf8View out = (HeyNativeUtf8View){"", 0};
  BIO *bio = NULL;
  EVP_PKEY *pkey = NULL;
  EVP_MD_CTX *mdctx = NULL;
  unsigned char *der = NULL;
  const unsigned char *derp = NULL;
  ECDSA_SIG *ecsig = NULL;
  unsigned char raw[132];
  size_t derlen = 0;
  int coord = ec_coord_len(sha_bits);
  const EVP_MD *md = md_for(sha_bits);

  if (!md || coord == 0) goto done;
  if (!private_key_pem.data || private_key_pem.length == 0) goto done;

  /* Apple's .p8 is a PKCS#8 PEM. PEM_read_bio_PrivateKey handles PKCS#8 and
   * SEC1 alike, so the caller does not have to know which they were given. */
  bio = BIO_new_mem_buf(private_key_pem.data, (int)private_key_pem.length);
  if (!bio) { goto done; }
  pkey = PEM_read_bio_PrivateKey(bio, NULL, NULL, NULL);
  if (!pkey) { goto done; }              /* unreadable / encrypted key */
  if (EVP_PKEY_base_id(pkey) != EVP_PKEY_EC) { goto done; }  /* not EC */

  mdctx = EVP_MD_CTX_new();
  if (!mdctx) { goto done; }
  if (EVP_DigestSignInit(mdctx, NULL, md, NULL, pkey) <= 0) { goto done; }
  if (EVP_DigestSign(mdctx, NULL, &derlen, (const unsigned char *)signing_input.data,
                     signing_input.length) <= 0) { goto done; }
  der = (unsigned char *)malloc(derlen);
  if (!der) { goto done; }
  if (EVP_DigestSign(mdctx, der, &derlen, (const unsigned char *)signing_input.data,
                     signing_input.length) <= 0) { goto done; }

  /* OpenSSL signs to DER; JWS wants raw R||S, each LEFT-PADDED to the
   * coordinate length. Skipping the padding is the classic bug here: a short
   * R produces a signature that verifies locally and is rejected by every
   * other implementation. */
  derp = der;
  ecsig = d2i_ECDSA_SIG(NULL, &derp, (long)derlen);
  if (!ecsig) { goto done; }
  {
    const BIGNUM *r = ECDSA_SIG_get0_r(ecsig);
    const BIGNUM *s = ECDSA_SIG_get0_s(ecsig);
    if (!r || !s) { goto done; }
    memset(raw, 0, sizeof(raw));
    if (BN_bn2binpad(r, raw, coord) != coord) { goto done; }
    if (BN_bn2binpad(s, raw + coord, coord) != coord) { goto done; }
  }

  {
    size_t n = b64url_encode(raw, (size_t)(coord * 2), sig_b64);
    out = (HeyNativeUtf8View){sig_b64, n};
  }

done:
  if (mdctx) EVP_MD_CTX_free(mdctx);
  if (ecsig) ECDSA_SIG_free(ecsig);
  if (der) free(der);
  if (pkey) EVP_PKEY_free(pkey);
  if (bio) BIO_free(bio);
  return out;
}
