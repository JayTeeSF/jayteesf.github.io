# Todo

- Phase 2, slice 2 (docs/ROADMAP.md), with no Java in any form: scrolling from native motion events; measure text entry through a focused `EditText` against `ANativeActivity_showSoftInput` and key events; measure whether back reaches the native input queue at target 36; measure TalkBack on the View tree.
- Phase 2, later: buttons and lists described by the served screen, Keystore and HTTP through JNI on an attached worker thread, and foreground-only audio.
- Toolchain (docs/ROADMAP.md): a per-call error boundary, and the LLVM-lane miscompiles found in slice 1.
- x86_64 library for x86 emulators; an AAB with `bundletool validate`.
- Run the 16 KB alignment on a 16 KB kernel (the `_ps16k` system image) instead of checking it statically only.
- Phase 3: the My Queue Android app on the served description. Android Auto is not possible under the no-Java rule.
