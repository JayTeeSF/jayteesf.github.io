#define _POSIX_C_SOURCE 200809L

/* A v2 journal is REFUSED as unsupported_format, and that is not the same
   answer as corruption.
 *
 * The distinction is the whole point and it is an operator-facing one. "Your
 * journal is corrupt" means stop writing, page a human, restore from a verified
 * snapshot. "This build cannot read that format" means run the older build, or
 * run the offline migration described in docs/FORMAT.md. Delivering both as one
 * opaque open failure would send an operator to a restore they did not need, or
 * -- far worse -- let them treat real damage as a version mismatch and keep
 * going.
 *
 * Nothing gated this. The refusal existed in hdl_open and no test distinguished
 * it from HDL_CORRUPTION, so a change that collapsed the two would have been
 * invisible. This constructs a genuine v2 segment header -- the v2 magic and a
 * valid header CRC, which is exactly what the detection requires -- rather than
 * corrupting a v3 one, because a damaged v3 header IS corruption and would
 * prove the opposite of what is wanted here.
 */

#include "hey_durable_log.h"

#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define SEGMENT_HEADER_SIZE 64u

static void fail(const char *message) {
  fprintf(stderr, "FAIL: %s\n", message);
  exit(1);
}

/* The same CRC-32 the format uses: reflected, polynomial 0xedb88320, initial
   0xffffffff, final complement. Duplicated here rather than exported, because a
   test that shared the implementation with the thing it checks would agree with
   it however wrong both were. */
static uint32_t crc32_of(const unsigned char *bytes, size_t length) {
  uint32_t crc = 0xffffffffu;
  for (size_t index = 0; index < length; index++) {
    crc ^= bytes[index];
    for (int bit = 0; bit < 8; bit++) {
      crc = (crc >> 1) ^ (0xedb88320u & (uint32_t)-(int32_t)(crc & 1u));
    }
  }
  return ~crc;
}

static void put_u32(unsigned char *out, uint32_t value) {
  out[0] = (unsigned char)(value & 0xffu);
  out[1] = (unsigned char)((value >> 8) & 0xffu);
  out[2] = (unsigned char)((value >> 16) & 0xffu);
  out[3] = (unsigned char)((value >> 24) & 0xffu);
}

/* A v2 segment header: v2 magic, the same 64-byte header size, format version
   2, and a CRC that is CORRECT. Everything about it is well-formed; it is
   simply from an older format. */
static void write_v2_segment(const char *directory) {
  char path[128];
  unsigned char header[SEGMENT_HEADER_SIZE];
  memset(header, 0, sizeof(header));
  memcpy(header, "HDLGv002", 8);
  put_u32(header + 8, SEGMENT_HEADER_SIZE);
  put_u32(header + 12, 2u);
  put_u32(header + 60, crc32_of(header, 60));

  snprintf(path, sizeof(path),
           "%s/%016" PRIx64 "-%016" PRIx64 ".seg", directory, (uint64_t)0, (uint64_t)0);
  int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd < 0) fail("create the v2 segment file");
  if (write(fd, header, sizeof(header)) != (ssize_t)sizeof(header)) fail("write the v2 segment header");
  if (close(fd) != 0) fail("close the v2 segment file");
}

int main(void) {
  /* Not mkdtemp: the two platforms disagree about which feature-test macro
     declares it, and this gate must build identically on both under -Werror
     -Wpedantic. A pid-named directory created with O_EXCL semantics is enough
     for a test that owns its own path. */
  /* Bounded deliberately, and small. GCC's -Wformat-truncation reasons about
     the WORST case: a char[4096] directory formatted into a char[4096] path
     could overflow, and under -Werror that is a build failure on Linux even
     though clang on Darwin says nothing. The path this test builds is
     "/tmp/hey-durable-log-v2-<pid>/<16 hex>-<16 hex>.seg", so 64 bytes for the
     directory and 128 for the path are provably enough and the compiler can
     see it. */
  char directory[64];
  snprintf(directory, sizeof(directory), "/tmp/hey-durable-log-v2-%ld", (long)getpid());
  (void)rmdir(directory);
  if (mkdir(directory, 0700) != 0) fail("make a journal directory");
  write_v2_segment(directory);

  hdl_log *log = NULL;
  hdl_status status = hdl_open(directory, NULL, &log);

  if (status == HDL_OK) {
    fail("a v2 journal was OPENED; an entry written before leader epochs existed "
         "has no epoch, and one cannot be invented for it");
  }
  if (status == HDL_CORRUPTION) {
    fail("a v2 journal was reported as CORRUPTION; the bytes are intact and an "
         "older build reads them perfectly, and an operator told 'corrupt' "
         "restores from a snapshot they did not need to");
  }
  if (status != HDL_UNSUPPORTED_FORMAT) {
    fprintf(stderr, "opening a v2 journal reported %s\n", hdl_status_name(status));
    fail("a v2 journal must be refused as unsupported_format, by name");
  }
  if (strcmp(hdl_status_name(status), "unsupported_format") != 0) {
    fail("the status name an operator sees must say unsupported_format");
  }

  /* Refused, and PRESERVED. docs/FORMAT.md promises old journals are left
     untouched, because the documented recovery is to run the older build or an
     offline migration -- both of which need the bytes still there. */
  char path[128];
  struct stat metadata;
  snprintf(path, sizeof(path),
           "%s/%016" PRIx64 "-%016" PRIx64 ".seg", directory, (uint64_t)0, (uint64_t)0);
  if (stat(path, &metadata) != 0) fail("the refused v2 segment was deleted");
  if (metadata.st_size != (off_t)SEGMENT_HEADER_SIZE) {
    fail("the refused v2 segment was truncated or rewritten; a refusal must not "
         "modify a journal this build has already said it cannot read");
  }

  (void)unlink(path);
  (void)rmdir(directory);
  printf("PASS: a v2 journal is refused as unsupported_format, not as corruption, and is left untouched\n");
  return 0;
}
