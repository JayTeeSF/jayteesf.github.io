# Done

- Replaced the pre-`stdlib:Web` 0.1.1 design with stdlib-first 0.1.2 modules.
- Added application/config/server/router/controller/view/jobs/client/command layers.
- Added resource routing, pure dispatch specs, curl-style argv planning, JSON bodies, status checking, and atomic download delegation.
- Added package, verification, roadmap, prompt, and continuation scripts.
- Verified the packed release through clean package install, lockfile pinning, installed-content verification, and compiled `pkg:` import.
- Kept public modules at package-root paths to preserve the verified package resolver contract.
- Added and passed `bin/check-live-http`, covering a real one-request localhost server/client exchange.
- Fixed `bin/hey-web` argument forwarding and avoided stale imported-module script caches by preferring `heyc --run --`.
- Added a regression spec for ERB-style EHY `<%= ... %>` interpolation and updated the executable package example to render an actual `.ehy` file.
- Migrated configuration and view preparation from removed `files.exists` to `files.exists?`.
- Removed `hey_packager` from runtime dependencies.
- Refreshed the vendored `bin/hey-packager` to 0.1.5 (bump verifies the
  manifest rewrite instead of trusting BSD sed's silent no-op).
- Fixed the serve defect: `HeyWebServer.serve` uses `Web.serve`; the
  0.1.x `Web.service` + `Web.start` path never invoked a registered
  handler in compiled binaries (JSON delegation destroys handler
  callables). Proven by a live body-asserting spec (port 46401) and a
  compiled serve receipt in `bin/check` (port 46402).
- Single-sourced the in-source version literal in
  `HeyWebConfig.version()` and added a VERSION-derived drift guard
  (match plus literal-count) to `bin/check`; `bin/package-check` no
  longer hardcodes any version.
- Updated for trunk 0.99.474a: `Result.error?`/`Result.ok?` (the
  `is_error`/`is_ok` spellings were removed), `stdlib:Files` in the
  spec harness (`stdlib:fs` was removed), specs run from `$HEY_ROOT`
  for the EHY cwd quirk, and router_spec excludes `log_requests`
  (which now writes an access-log line to stderr).
