# Design

The adapter returns a standard callable connection descriptor. `query` invokes `sqlite3 -json DATABASE SQL`; `execute` appends a changes/last-insert-id query and normalizes the result. Direct argv avoids shell interpolation, while SQL values must still be produced through safe builders or future prepared bindings.

The target architecture is a persistent native SQLite connection with prepared statements, typed values, busy handling, and transaction ownership once Hey exposes a stable native extension boundary.
