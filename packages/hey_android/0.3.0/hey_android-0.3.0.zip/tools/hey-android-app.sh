#!/usr/bin/env bash
# tools/hey-android-app.sh: a Hey program that uses the Hey runtime, as a signed APK
# for Android 16 (API 36) on arm64, with no Java or Kotlin anywhere.
#
#   tools/hey-android-app.sh --source APP.hey --out DIR --package-id ID --label NAME
#       [--hey-root DIR] [--emulator AVD | --device SERIAL] [--launch]
#       [--keystore FILE --key-alias ALIAS] [--version-code N] [--version-name TEXT]
#       [--wait SECONDS] [--keep-emulator] [--ui]
#
# --ui is for a program that draws Views and loops on next_event (native/ui):
# --launch then waits for the first screen to be committed instead of for the
# program to end, and leaves the app running for the caller to drive.
#
# Steps, each checked before the next (tools/hey-android-verify.sh):
#   1. bin/android-doctor: the pinned SDK, NDK, build-tools, JDK and Hey checkout.
#   2. heyc build --emit-llvm-ir, inside $HEY_HEYC_LOCK when set (a command prefix
#      such as "with-lock.sh build --"; parallel heyc builds race on its cache).
#   3. NDK clang compiles the IR for aarch64-linux-android35, with every
#      compiler-search variable cleared (tools/android-env.sh, BUILD ISOLATION).
#   4. The Hey runtime and compiler-node bundle from HEY_ROOT, unmodified, with
#      the package's Android runtime profile (native/runtime_profile), cached
#      per toolchain identity, NDK and target.
#   5. One shared library with the glue (native/glue): 16 KB pages, no
#      undefined symbol outside the allowed system libraries, no OpenSSL.
#   6. aapt2 link against android-36, the library stored uncompressed,
#      zipalign -P 16, apksigner (the debug keystore unless --keystore).
#   7. With --emulator or --device: adb install; with --launch: start the
#      activity, wait for the program to end, and collect logcat.
#   8. receipt.json in DIR.
#
# --keystore signs for release; the passwords come from
# HEY_ANDROID_KEYSTORE_PASSWORD and HEY_ANDROID_KEY_PASSWORD (default: the
# keystore password), never from the command line.
#
# HEY_ANDROID_NEGATIVE_CONTROL=unwrapped-exit links without --wrap=exit, and
# HEY_ANDROID_NEGATIVE_CONTROL=surface-taken leaves NativeActivity holding the
# window's surface, so Views are laid out but never drawn. They exist only so the
# emulator specs can show their checks fail; the receipt says so.
set -euo pipefail
HEY_ANDROID_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
. "$HEY_ANDROID_ROOT/tools/android-env.sh"

usage() { sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'; }
source_file=''
out=''
package_id=''
label=''
hey_root_arg=''
avd=''
serial=''
launch=false
keystore=''
key_alias=''
version_code=1
version_name=1.0
wait_seconds=120
keep_emulator=false
ui_mode=false
while [ "$#" -gt 0 ]; do
  case "$1" in
    --source) shift; source_file=${1:?--source needs a file} ;;
    --out) shift; out=${1:?--out needs a directory} ;;
    --package-id) shift; package_id=${1:?--package-id needs an id} ;;
    --label) shift; label=${1:?--label needs a name} ;;
    --hey-root) shift; hey_root_arg=${1:?--hey-root needs a directory} ;;
    --emulator) shift; avd=${1:?--emulator needs an AVD name} ;;
    --device) shift; serial=${1:?--device needs a serial} ;;
    --launch) launch=true ;;
    --keystore) shift; keystore=${1:?--keystore needs a file} ;;
    --key-alias) shift; key_alias=${1:?--key-alias needs an alias} ;;
    --version-code) shift; version_code=${1:?--version-code needs a number} ;;
    --version-name) shift; version_name=${1:?--version-name needs text} ;;
    --wait) shift; wait_seconds=${1:?--wait needs seconds} ;;
    --keep-emulator) keep_emulator=true ;;
    --ui) ui_mode=true ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

die() { code=$1; shift; printf 'hey-android-app: %s\n' "$*" >&2; failure="$*"; write_receipt || true; exit "$code"; }
step() { printf '== %s\n' "$*"; current_step="$*"; }

[ -n "$source_file" ] && [ -f "$source_file" ] || { echo "--source must name a Hey file (got '${source_file}')" >&2; exit 2; }
[ -n "$out" ] || { echo '--out is required' >&2; exit 2; }
printf '%s\n' "$package_id" | grep -Eq '^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$' || { echo "--package-id must look like com.example.app (got '$package_id')" >&2; exit 2; }
[ -n "$label" ] || { echo '--label is required' >&2; exit 2; }
case "$version_code" in ''|*[!0-9]*) echo '--version-code must be a whole number' >&2; exit 2 ;; esac
case "$wait_seconds" in ''|*[!0-9]*) echo '--wait must be a whole number of seconds' >&2; exit 2 ;; esac
if [ -n "$avd" ] && [ -n "$serial" ]; then echo 'use --emulator or --device, not both' >&2; exit 2; fi
if [ "$launch" = true ] && [ -z "$avd$serial" ]; then echo '--launch needs --emulator AVD or --device SERIAL' >&2; exit 2; fi
if [ -n "$keystore" ]; then
  [ -f "$keystore" ] && [ -n "$key_alias" ] || { echo '--keystore needs an existing file and --key-alias' >&2; exit 2; }
  [ -n "${HEY_ANDROID_KEYSTORE_PASSWORD:-}" ] || { echo '--keystore needs HEY_ANDROID_KEYSTORE_PASSWORD in the environment' >&2; exit 2; }
fi
negative_control=${HEY_ANDROID_NEGATIVE_CONTROL:-none}
case "$negative_control" in none|unwrapped-exit|surface-taken) ;; *) echo "unknown HEY_ANDROID_NEGATIVE_CONTROL: $negative_control" >&2; exit 2 ;; esac

source_file=$(CDPATH= cd -- "$(dirname -- "$source_file")" && pwd)/$(basename -- "$source_file")
mkdir -p "$out"
out=$(CDPATH= cd -- "$out" && pwd)
if [ -n "$(ls -A "$out")" ] && [ ! -f "$out/.hey-android-app" ]; then
  echo "refusing to clear $out: it is not empty and was not made by this tool" >&2
  exit 2
fi
find "$out" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
touch "$out/.hey-android-app"
build=$out/build
logs=$out/build/logs
mkdir -p "$logs" "$out/apk" "$out/stage/lib/$HEY_ANDROID_ABI"

# ---- the receipt: written at the end, and on any failure -------------------------------------
current_step=start
failure=''
contamination=''
include_paths=''
ir_line=''
so_line=''
apk_line=''
runtime_cache=''
runtime_cache_key=''
device_api=''
device_abi=''
device_page_size=''
booted_by_tool=false
installed=false
launched=false
launch_status=''
program_how=''
program_status=''
activity_finished=false
activity_destroyed=false
process_exited=false
crash_markers=''
hey_pid=''
ui_commits=''
ui_views=''
ui_manifest_sha=''
signing=debug
write_receipt() {
  R_OUT=$out R_FAILURE=$failure R_STEP=$current_step R_NEGATIVE=$negative_control \
  R_SOURCE=$source_file R_SOURCE_SHA=$(hey_android_sha256 "$source_file") \
  R_HEY_ROOT=${HEY_ROOT:-} R_HEY_ROOT_SOURCE=${HEY_ROOT_SOURCE:-} R_HEY_HEAD=${hey_head:-} R_HEY_VERSION=${hey_version:-} \
  R_IDENTITY=${compiler_identity:-} R_RUNTIME_SHA=${runtime_sha:-} R_NODES_SHA=${nodes_sha:-} R_PROFILE_SHA=${profile_sha:-} \
  R_RUNTIME_CACHE=$runtime_cache R_RUNTIME_CACHE_KEY=$runtime_cache_key R_PACKAGE_VERSION=$HEY_ANDROID_VERSION \
  R_NDK=${ndk_revision:-} R_CLANG=${clang_version:-} R_TARGET=$HEY_ANDROID_TARGET R_MIN_SDK=$HEY_ANDROID_MIN_SDK \
  R_TARGET_SDK=$HEY_ANDROID_TARGET_SDK R_COMPILE_SDK=$HEY_ANDROID_COMPILE_SDK R_BUILD_TOOLS=$HEY_ANDROID_BUILD_TOOLS \
  R_PAGE_SIZE=$HEY_ANDROID_PAGE_SIZE R_CLEARED="$HEY_ANDROID_CLEARED_VARIABLES" R_CONTAMINATION=$contamination \
  R_INCLUDE_PATHS=$include_paths R_IR=$ir_line R_SO=$so_line R_APK=$apk_line R_PACKAGE_ID=$package_id R_LABEL=$label \
  R_VERSION_CODE=$version_code R_VERSION_NAME=$version_name R_SIGNING=$signing R_AVD=$avd R_SERIAL=$serial \
  R_BOOTED=$booted_by_tool R_DEVICE_API=$device_api R_DEVICE_ABI=$device_abi R_DEVICE_PAGE=$device_page_size \
  R_INSTALLED=$installed R_LAUNCHED=$launched R_LAUNCH_STATUS=$launch_status R_PROGRAM_HOW=$program_how \
  R_PROGRAM_STATUS=$program_status R_FINISHED=$activity_finished R_DESTROYED=$activity_destroyed \
  R_PROCESS_EXITED=$process_exited R_CRASH=$crash_markers R_PID=$hey_pid \
  R_UI_MODE=$ui_mode R_UI_COMMITS=$ui_commits R_UI_VIEWS=$ui_views R_UI_MANIFEST_SHA=$ui_manifest_sha \
  /usr/bin/python3 - <<'PY'
import json, os
e = os.environ.get
def kv(line):
    parts = (line or "").split()
    return {k: v for k, v in (p.split("=", 1) for p in parts[2:] if "=" in p)}
def lines(path, limit=None):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            rows = [r.rstrip("\n") for r in f]
    except OSError:
        return []
    return rows[:limit] if limit else rows
def num(v):
    try: return int(v)
    except (TypeError, ValueError): return None
out = e("R_OUT")
so, apk, ir = kv(e("R_SO")), kv(e("R_APK")), kv(e("R_IR"))
receipt = {
  "kind": "hey-android-native-activity-app-v1",
  "result": "failed" if e("R_FAILURE") else "ok",
  "failure": e("R_FAILURE") or None,
  "failed_step": e("R_STEP") if e("R_FAILURE") else None,
  "negative_control": e("R_NEGATIVE"),
  "hey_android_version": e("R_PACKAGE_VERSION"),
  "hey_source": e("R_SOURCE"), "hey_source_sha256": e("R_SOURCE_SHA"),
  "toolchain": {"hey_root": e("R_HEY_ROOT"), "hey_root_source": e("R_HEY_ROOT_SOURCE"), "hey_head": e("R_HEY_HEAD"),
                "hey_version": e("R_HEY_VERSION"), "compiler_identity": e("R_IDENTITY"),
                "runtime_source_sha256": e("R_RUNTIME_SHA"), "compiler_nodes_source_sha256": e("R_NODES_SHA")},
  "runtime_profile_sha256": e("R_PROFILE_SHA"),
  "runtime_objects": {"cache": e("R_RUNTIME_CACHE"), "cache_key": e("R_RUNTIME_CACHE_KEY")},
  "ndk": {"revision": e("R_NDK"), "clang": e("R_CLANG")},
  "target_triple": e("R_TARGET"), "min_sdk": num(e("R_MIN_SDK")), "target_sdk": num(e("R_TARGET_SDK")),
  "compile_sdk": num(e("R_COMPILE_SDK")), "build_tools": e("R_BUILD_TOOLS"), "page_size": num(e("R_PAGE_SIZE")),
  "build_isolation": {"cleared_variables": e("R_CLEARED").split(),
                      "set_in_caller_environment": (e("R_CONTAMINATION") or "").split(),
                      "include_search_path": [p for p in (e("R_INCLUDE_PATHS") or "").split("\n") if p]},
  "ir": ir or None,
  "shared_library": ({"file": "stage/lib/arm64-v8a/libhey_app.so", "sha256": so.get("sha256"), "bytes": num(so.get("bytes")),
                      "load_segments": num(so.get("load_segments")), "load_alignment": num(so.get("load_align")),
                      "needed": (so.get("needed") or "").split(","), "undefined_symbols": num(so.get("undefined")),
                      "unresolved_symbols": num(so.get("unresolved")),
                      "wrap_exit": e("R_NEGATIVE") != "unwrapped-exit", "wrap_pthread_create": True} if so else None),
  "apk": ({"file": "app.apk", "sha256": apk.get("sha256"), "bytes": num(apk.get("bytes")), "package_id": e("R_PACKAGE_ID"),
           "label": e("R_LABEL"), "version_code": num(e("R_VERSION_CODE")), "version_name": e("R_VERSION_NAME"),
           "has_code": False, "dex_entries": 0, "lib_stored": apk.get("lib_stored") == "true",
           "zipalign_16k": apk.get("zipalign_16k") == "true", "signature_v2": apk.get("v2") == "true",
           "signature_v3": apk.get("v3") == "true", "signing": e("R_SIGNING"), "signer_sha256": apk.get("signer_sha256")} if apk else None),
  "device": {"avd": e("R_AVD") or None, "serial": e("R_SERIAL") or None, "booted_by_tool": e("R_BOOTED") == "true",
             "api": num(e("R_DEVICE_API")), "abi": e("R_DEVICE_ABI") or None, "kernel_page_size": num(e("R_DEVICE_PAGE"))},
  "installed": e("R_INSTALLED") == "true",
  "launched": e("R_LAUNCHED") == "true",
  "launch_status": e("R_LAUNCH_STATUS") or None,
  "pid": num(e("R_PID")),
  "program": {"ended": e("R_PROGRAM_HOW") or None, "status": num(e("R_PROGRAM_STATUS"))},
  "activity_finished": e("R_FINISHED") == "true",
  "activity_destroyed": e("R_DESTROYED") == "true",
  "process_exited": e("R_PROCESS_EXITED") == "true",
  "crash_markers": num(e("R_CRASH")),
  "ui": {"mode": e("R_UI_MODE") == "true", "extension_manifest_sha256": e("R_UI_MANIFEST_SHA") or None,
         "commits": num(e("R_UI_COMMITS")), "views_on_screen": num(e("R_UI_VIEWS"))},
  "stdout_lines": len(lines(os.path.join(out, "stdout.txt"))),
  "stderr_lines": len(lines(os.path.join(out, "stderr.txt"))),
  "logcat_first_lines": lines(os.path.join(out, "logcat-hey.txt"), 20),
}
with open(os.path.join(out, "receipt.json"), "w") as f:
    json.dump(receipt, f, indent=2)
    f.write("\n")
PY
}

hey_android_isolate
contamination=$HEY_ANDROID_CONTAMINATION_SEEN

# ---- 1. doctor and identity ------------------------------------------------------------------
step doctor
hey_android_resolve_hey_root "$hey_root_arg" || die 2 'no usable Hey checkout'
hey_head=$(hey_android_hey_head)
hey_version=$(hey_android_hey_version)
compiler_identity=$(hey_android_compiler_identity)
runtime_sha=$(hey_android_sha256 "$HEY_ROOT/runtime/hey_runtime.c")
nodes_sha=$(hey_android_sha256 "$HEY_ROOT/runtime/hey_compiler_nodes_bundle.c")
printf 'hey_root=%s (%s) head=%s version=%s compiler_identity=%s runtime_sha256=%s\n' \
  "$HEY_ROOT" "$HEY_ROOT_SOURCE" "$hey_head" "$hey_version" "$compiler_identity" "$(printf '%s' "$runtime_sha" | cut -c1-16)"
[ -z "$contamination" ] || printf 'cleared from the caller environment: %s\n' "$contamination"
"$HEY_ANDROID_ROOT/bin/android-doctor" --quiet --hey-root "$HEY_ROOT" || die 69 'bin/android-doctor found missing pieces (above)'
ndk_revision=$(hey_android_property "$HEY_ANDROID_NDK_ROOT/source.properties" Pkg.Revision)
clang_version=$("$HEY_ANDROID_CLANG" --version | sed -n 1p)
include_paths=$(hey_android_include_search_path)
host_includes=$(printf '%s\n' "$include_paths" | grep -E '/opt/homebrew|/usr/local' || true)
[ -z "$host_includes" ] || die 65 "NDK clang would search host headers: $host_includes"

# ---- 2. Hey to LLVM IR -----------------------------------------------------------------------
step 'heyc build --emit-llvm-ir'
lock_prefix=${HEY_HEYC_LOCK:-}
printf 'heyc_lock=%s\n' "${lock_prefix:-none}"
# shellcheck disable=SC2086 # the lock prefix is a command and its arguments
if ! env PATH="$HEY_ANDROID_HOST_PATH" $lock_prefix "$HEY_ROOT/bin/heyc" build --emit-llvm-ir "$source_file" -o "$build/app.ll" > "$logs/heyc.log" 2>&1; then
  grep -v '^selfhost_' "$logs/heyc.log" | tail -5 >&2
  die 65 "heyc could not emit LLVM IR for $source_file (log: $logs/heyc.log)"
fi
ir_line=$("$HEY_ANDROID_ROOT/tools/hey-android-verify.sh" ir "$build/app.ll") || die 65 'the IR cannot be built for Android (above)'
printf '%s\n' "$ir_line"
sed -E 's/^define i32 @main\(/define i32 @hey_program_main(/' "$build/app.ll" > "$build/app-android.ll"
[ "$(grep -c '^define i32 @hey_program_main(' "$build/app-android.ll")" = 1 ] || die 65 'renaming main did not produce exactly one hey_program_main'

# ---- 3. the program object -------------------------------------------------------------------
step "clang --target=$HEY_ANDROID_TARGET (program)"
"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -fPIC -O2 -Wno-override-module \
  -c "$build/app-android.ll" -o "$build/app.o" 2> "$logs/app-compile.log" || { cat "$logs/app-compile.log" >&2; die 65 'NDK clang could not compile the program IR'; }

# ---- 4. the Hey runtime, cached ------------------------------------------------------------
step 'Hey runtime objects'
profile_include=$HEY_ANDROID_ROOT/native/runtime_profile/include
vendor_sha256=$HEY_ANDROID_ROOT/native/vendor/sha256
profile_sha=$(cd "$HEY_ANDROID_ROOT" && for f in native/runtime_profile/include/hey_android_platform_crypto.h \
    native/runtime_profile/include/CommonCrypto/CommonDigest.h native/runtime_profile/include/CommonCrypto/CommonRandom.h \
    native/runtime_profile/hey_android_platform_crypto.c native/vendor/sha256/sha256.c native/vendor/sha256/sha256.h; do
    printf '%s  %s\n' "$(hey_android_sha256 "$f")" "$f"; done | shasum -a 256 | cut -c1-64)
runtime_flags=(-std=c11 -O2 -fPIC -pthread "-DHEY_VERSION=\"$hey_version\""
  -DHEY_RUNTIME_NO_TLS_CLIENT=1 -DHEY_RUNTIME_NO_TLS_SERVER=1 -DHEY_RUNTIME_NO_AEAD=1
  -DHEY_RUNTIME_NO_PASSWORD_KDF=1 -DHEY_RUNTIME_APPLE_CRYPTO=1)
cache_root=${HEY_ANDROID_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/hey_android}
runtime_cache_key=$(printf 'hey_android-runtime-cache-v1\n%s\n' "$compiler_identity" "$hey_version" "$runtime_sha" "$nodes_sha" \
  "$profile_sha" "$ndk_revision" "$clang_version" "$HEY_ANDROID_TARGET" "${runtime_flags[*]}" | shasum -a 256 | cut -c1-24)
runtime_dir=$cache_root/runtime-$runtime_cache_key
if [ -f "$runtime_dir/complete" ]; then
  runtime_cache=hit
else
  runtime_cache=miss
  mkdir -p "$cache_root"
  staging=$(mktemp -d "$cache_root/.building.XXXXXX")
  target=(--target="$HEY_ANDROID_TARGET")
  "$HEY_ANDROID_CLANG" "${target[@]}" "${runtime_flags[@]}" -I"$profile_include" -I"$HEY_ROOT/runtime" \
    -c "$HEY_ROOT/runtime/hey_runtime.c" -o "$staging/hey_runtime.o" 2> "$logs/runtime-compile.log" ||
    { tail -20 "$logs/runtime-compile.log" >&2; rm -rf "$staging"; die 65 "the Hey runtime does not compile for $HEY_ANDROID_TARGET with the Android profile"; }
  "$HEY_ANDROID_CLANG" "${target[@]}" -std=c11 -O2 -fPIC -w -I"$HEY_ROOT/runtime" -I"$HEY_ROOT/compiler/generated" \
    -c "$HEY_ROOT/runtime/hey_compiler_nodes_bundle.c" -o "$staging/hey_compiler_nodes.o" 2> "$logs/nodes-compile.log" ||
    { tail -20 "$logs/nodes-compile.log" >&2; rm -rf "$staging"; die 65 'the compiler-node bundle does not compile'; }
  "$HEY_ANDROID_CLANG" "${target[@]}" -std=c11 -O2 -fPIC -Wall -Wextra -Werror -I"$profile_include" -I"$vendor_sha256" \
    -c "$HEY_ANDROID_ROOT/native/runtime_profile/hey_android_platform_crypto.c" -o "$staging/hey_android_platform_crypto.o" 2> "$logs/profile-compile.log" ||
    { cat "$logs/profile-compile.log" >&2; rm -rf "$staging"; die 65 'the runtime profile does not compile'; }
  "$HEY_ANDROID_CLANG" "${target[@]}" -std=c11 -O2 -fPIC -w -c "$vendor_sha256/sha256.c" -o "$staging/sha256.o" 2> "$logs/sha256-compile.log" ||
    { cat "$logs/sha256-compile.log" >&2; rm -rf "$staging"; die 65 'the vendored SHA-256 does not compile'; }
  for object in hey_runtime.o hey_compiler_nodes.o hey_android_platform_crypto.o sha256.o; do
    "$HEY_ANDROID_ROOT/tools/hey-android-verify.sh" obj "$staging/$object" > /dev/null ||
      { rm -rf "$staging"; die 65 "$object failed its check (above)"; }
  done
  printf 'compiler_identity=%s\nhey_version=%s\nruntime_source_sha256=%s\ncompiler_nodes_source_sha256=%s\nruntime_profile_sha256=%s\nndk=%s\nclang=%s\ntarget=%s\nruntime_flags=%s\n' \
    "$compiler_identity" "$hey_version" "$runtime_sha" "$nodes_sha" "$profile_sha" "$ndk_revision" "$clang_version" "$HEY_ANDROID_TARGET" "${runtime_flags[*]}" > "$staging/inputs.txt"
  touch "$staging/complete"
  if [ -e "$runtime_dir" ]; then rm -rf "$staging"; else mv "$staging" "$runtime_dir"; fi
fi
printf 'runtime_cache=%s key=%s dir=%s\n' "$runtime_cache" "$runtime_cache_key" "$runtime_dir"

# ---- 5. the shared library -----------------------------------------------------------------
step 'link libhey_app.so'
# The View shims (native/ui): hey native writes the stdlib:Native descriptor and wrapper
# from native/ui/hey.native.json. It runs heyc, so it goes inside the same lock.
ui_gen=$build/ui-generated
mkdir -p "$ui_gen"
# shellcheck disable=SC2086 # the lock prefix is a command and its arguments
if ! (cd "$HEY_ROOT" && env PATH="$HEY_ANDROID_HOST_PATH" $lock_prefix ./bin/hey native --manifest "$HEY_ANDROID_ROOT/native/ui/hey.native.json" \
     --out "$ui_gen" --target "android-$HEY_ANDROID_ABI") > "$logs/hey-native.log" 2>&1; then
  tail -5 "$logs/hey-native.log" >&2
  die 65 'hey native could not generate the UI extension wrapper (native/ui/hey.native.json)'
fi
ui_manifest_sha=$(sed -n 's/^manifest_sha256=//p' "$logs/hey-native.log")
ui_flags=()
[ "$negative_control" = surface-taken ] && ui_flags=(-DHEY_ANDROID_UI_CONTROL_SURFACE_TAKEN=1)
"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -std=c11 -O2 -fPIC -Wall -Wextra -Werror -D_GNU_SOURCE \
  -I"$HEY_ANDROID_ROOT/native/ui" -I"$ui_gen" ${ui_flags[@]+"${ui_flags[@]}"} \
  -c "$HEY_ANDROID_ROOT/native/ui/hey_android_ui.c" -o "$build/ui.o" \
  2> "$logs/ui-compile.log" || { cat "$logs/ui-compile.log" >&2; die 65 'the UI shims do not compile'; }
"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -std=c11 -O2 -fPIC -Wall -Wextra -Werror \
  -I"$HEY_ANDROID_ROOT/native/ui" -I"$ui_gen" -c "$ui_gen/hey_android_ui_ffi.c" -o "$build/ui_ffi.o" \
  2> "$logs/ui-ffi-compile.log" || { cat "$logs/ui-ffi-compile.log" >&2; die 65 'the generated UI wrapper does not compile'; }
"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -std=c11 -O2 -fPIC -Wall -Wextra -Werror -D_GNU_SOURCE \
  -I"$HEY_ANDROID_ROOT/native/ui" -I"$ui_gen" \
  "-DHEY_ANDROID_VERSION=\"$HEY_ANDROID_VERSION\"" -c "$HEY_ANDROID_ROOT/native/glue/hey_android_glue.c" -o "$build/glue.o" \
  2> "$logs/glue-compile.log" || { cat "$logs/glue-compile.log" >&2; die 65 'the glue does not compile'; }
wrap_flags=(-Wl,--wrap=exit -Wl,--wrap=pthread_create)
control_objects=()
if [ "$negative_control" = surface-taken ]; then
  printf 'NEGATIVE CONTROL: the UI keeps NativeActivity'"'"'s surface taken; this APK must not be used\n'
fi
if [ "$negative_control" = unwrapped-exit ]; then
  printf 'NEGATIVE CONTROL: linking without --wrap=exit; this APK must not be used\n'
  printf '#include <stdlib.h>\nvoid __real_exit(int status) { exit(status); }\n' > "$build/control_unwrapped_exit.c"
  "$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -fPIC -O2 -c "$build/control_unwrapped_exit.c" -o "$build/control_unwrapped_exit.o"
  wrap_flags=(-Wl,--wrap=pthread_create)
  control_objects=("$build/control_unwrapped_exit.o")
fi
so=$out/stage/lib/$HEY_ANDROID_ABI/lib$HEY_ANDROID_LIB_NAME.so
"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -shared -pthread \
  -Wl,-soname,"lib$HEY_ANDROID_LIB_NAME.so" -Wl,--no-undefined -Wl,-z,max-page-size="$HEY_ANDROID_PAGE_SIZE" \
  -Wl,-z,noexecstack -Wl,--build-id=sha1 "${wrap_flags[@]}" \
  "$build/app.o" "$build/glue.o" "$build/ui.o" "$build/ui_ffi.o" "$runtime_dir/hey_runtime.o" "$runtime_dir/hey_compiler_nodes.o" \
  "$runtime_dir/hey_android_platform_crypto.o" "$runtime_dir/sha256.o" ${control_objects[@]+"${control_objects[@]}"} \
  -llog -landroid -lm -ldl -o "$so" 2> "$logs/link.log" || { tail -20 "$logs/link.log" >&2; die 65 'the shared library does not link'; }
so_line=$("$HEY_ANDROID_ROOT/tools/hey-android-verify.sh" so "$so") || die 65 'the shared library failed its check (above)'
printf '%s\n' "$so_line"

# ---- 6. the APK ------------------------------------------------------------------------------
step 'package, align and sign'
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
xml_label=$(printf '%s' "$label" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' -e 's/"/\&quot;/g' -e "s/'/\\\\'/g")
xml_version_name=$(printf '%s' "$version_name" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' -e 's/"/\&quot;/g')
sed_escape() { printf '%s' "$1" | sed -e 's/[\\|&]/\\&/g'; }
sed -e "s|@PACKAGE_ID@|$package_id|g" -e "s|@LABEL@|$(sed_escape "$xml_label")|g" \
    -e "s|@VERSION_CODE@|$version_code|g" -e "s|@VERSION_NAME@|$(sed_escape "$xml_version_name")|g" \
    -e "s|@MIN_SDK@|$HEY_ANDROID_MIN_SDK|g" -e "s|@TARGET_SDK@|$HEY_ANDROID_TARGET_SDK|g" \
    -e "s|@LIB_NAME@|$HEY_ANDROID_LIB_NAME|g" \
    "$HEY_ANDROID_ROOT/native/manifest/AndroidManifest.xml.in" > "$out/apk/AndroidManifest.xml"
"$bt/aapt2" link --manifest "$out/apk/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -o "$out/apk/base.apk" \
  > "$logs/aapt2.log" 2>&1 || { cat "$logs/aapt2.log" >&2; die 65 'aapt2 link failed'; }
cp "$out/apk/base.apk" "$out/apk/unsigned.apk"
(cd "$out/stage" && /usr/bin/zip -q -0 -X "$out/apk/unsigned.apk" "lib/$HEY_ANDROID_ABI/lib$HEY_ANDROID_LIB_NAME.so") || die 65 'could not add the library to the APK'
"$bt/zipalign" -P 16 -f 4 "$out/apk/unsigned.apk" "$out/apk/aligned.apk" > "$logs/zipalign.log" 2>&1 || { cat "$logs/zipalign.log" >&2; die 65 'zipalign failed'; }
java_home=$(hey_android_java_home)
[ -n "$java_home" ] || die 69 "JDK $HEY_ANDROID_JDK not found for apksigner"
if [ -n "$keystore" ]; then
  signing=release
  export HEY_ANDROID_KEY_PASSWORD=${HEY_ANDROID_KEY_PASSWORD:-$HEY_ANDROID_KEYSTORE_PASSWORD}
  sign_args=(--ks "$keystore" --ks-key-alias "$key_alias" --ks-pass env:HEY_ANDROID_KEYSTORE_PASSWORD --key-pass env:HEY_ANDROID_KEY_PASSWORD)
else
  sign_args=(--ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android)
fi
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" sign "${sign_args[@]}" --v4-signing-enabled false \
  --out "$out/app.apk" "$out/apk/aligned.apk" > "$logs/apksigner.log" 2>&1 || { cat "$logs/apksigner.log" >&2; die 65 'apksigner failed'; }
apk_line=$("$HEY_ANDROID_ROOT/tools/hey-android-verify.sh" apk "$out/app.apk" "$package_id") || die 65 'the APK failed its check (above)'
printf '%s\n' "$apk_line"

# ---- 7. install and launch -------------------------------------------------------------------
adb() { "$HEY_ANDROID_ADB" -s "$serial" "$@"; }
shutdown_booted() {
  if [ "$booted_by_tool" = true ] && [ "$keep_emulator" = false ]; then
    "$HEY_ANDROID_ROOT/tools/hey-android-emulator.sh" shutdown "$serial" || true
  fi
}
trap shutdown_booted EXIT

if [ -n "$avd" ]; then
  step "emulator $avd"
  for candidate in $("$HEY_ANDROID_ADB" devices | awk '$1 ~ /^emulator-/ && $2 == "device" { print $1 }'); do
    if [ "$("$HEY_ANDROID_ADB" -s "$candidate" emu avd name 2>/dev/null | sed -n 1p | tr -d '\r')" = "$avd" ]; then serial=$candidate; break; fi
  done
  if [ -z "$serial" ]; then
    [ "$avd" = "$HEY_ANDROID_AVD" ] || die 2 "the tool boots only the pinned AVD $HEY_ANDROID_AVD; start $avd yourself and pass --device"
    boot_line=$("$HEY_ANDROID_ROOT/tools/hey-android-emulator.sh" boot) || die 69 'the emulator did not boot'
    printf '%s\n' "$boot_line"
    serial=$(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^serial=//p')
    booted_by_tool=true
  fi
fi

if [ -n "$serial" ]; then
  step "install on $serial"
  [ "$(adb get-state 2>/dev/null | tr -d '\r')" = device ] || die 69 "$serial is not an attached, authorized device"
  device_api=$(adb shell getprop ro.build.version.sdk | tr -d '\r')
  device_abi=$(adb shell getprop ro.product.cpu.abi | tr -d '\r')
  device_page_size=$(adb shell getconf PAGE_SIZE | tr -d '\r')
  printf 'device serial=%s api=%s abi=%s kernel_page_size=%s\n' "$serial" "$device_api" "$device_abi" "$device_page_size"
  adb install -r "$out/app.apk" > "$logs/install.log" 2>&1 && grep -q '^Success' "$logs/install.log" ||
    { cat "$logs/install.log" >&2; die 1 "adb install failed on $serial"; }
  installed=true
fi

if [ "$launch" = true ]; then
  step "launch $package_id"
  adb logcat -c || true
  adb shell am start -W -n "$package_id/android.app.NativeActivity" > "$logs/am-start.log" 2>&1 || true
  launch_status=$(sed -n 's/^Status: //p' "$logs/am-start.log" | tr -d '\r' | sed -n 1p)
  [ "$launch_status" = ok ] || { cat "$logs/am-start.log" >&2; die 1 'am start did not report Status: ok'; }
  launched=true

  deadline=$((SECONDS + wait_seconds))
  gone=0
  while [ $SECONDS -lt $deadline ]; do
    adb logcat -d -v tag -s 'hey.app:*' > "$out/app-log.txt" 2>/dev/null || true
    # logcat -v tag pads short tags: "I/hey.app : message".
    if grep -q '^./hey\.app *: hey program .* with status' "$out/app-log.txt" && grep -q '^./hey\.app *: activity destroyed' "$out/app-log.txt"; then
      break
    fi
    if [ "$ui_mode" = true ] && adb logcat -d -v tag -s 'hey.ui:*' 2>/dev/null | grep -q '^./hey\.ui *: commit: '; then
      break
    fi
    if adb shell pidof "$package_id" > /dev/null 2>&1; then gone=0; else gone=$((gone + 1)); fi
    [ "$gone" -ge 3 ] && break
    /bin/sleep 1
  done
  if [ "$ui_mode" = false ]; then
    for _ in 1 2 3 4 5; do
      adb shell pidof "$package_id" > /dev/null 2>&1 || { process_exited=true; break; }
      /bin/sleep 1
    done
  elif ! adb shell pidof "$package_id" > /dev/null 2>&1; then
    process_exited=true
  fi

  adb logcat -d -v threadtime > "$out/logcat.txt" 2>/dev/null || true
  adb logcat -d -v tag -s 'hey.app:*' > "$out/app-log.txt" 2>/dev/null || true
  adb logcat -d -v tag -s 'hey.ui:*' > "$out/ui-log.txt" 2>/dev/null || true
  adb logcat -d -v threadtime -s 'hey.app:*' 'hey.ui:*' 'hey.out:*' 'hey.err:*' 2>/dev/null | grep -v '^--------- ' > "$out/logcat-hey.txt" || true
  ui_commits=$(grep -c 'commit: [0-9]* rows described' "$out/ui-log.txt" || true)
  ui_views=$(sed -n 's/.*commit: [0-9]* rows described, \([0-9]*\) views on screen.*/\1/p' "$out/ui-log.txt" | tail -1)
  # One logcat entry per line the program wrote; the prefix "I/hey.out : " is removed.
  adb logcat -d -v tag -s 'hey.out:*' 2>/dev/null | sed -n -e 's/^I\/hey\.out *: //p' -e 's/^I\/hey\.out *:$//p' > "$out/stdout.txt" || true
  adb logcat -d -v tag -s 'hey.err:*' 2>/dev/null | sed -n -e 's/^E\/hey\.err *: //p' -e 's/^E\/hey\.err *:$//p' > "$out/stderr.txt" || true

  hey_pid=$(sed -n 's/.*starting the Hey program (pid \([0-9]*\)).*/\1/p' "$out/app-log.txt" | sed -n 1p)
  end_line=$(grep -m1 'hey program .* with status' "$out/app-log.txt" || true)
  program_how=$(printf '%s\n' "$end_line" | sed -n 's/.*hey program \(.*\) with status.*/\1/p')
  program_status=$(printf '%s\n' "$end_line" | sed -n 's/.*with status \(-\{0,1\}[0-9]*\).*/\1/p')
  grep -q 'finishing the activity' "$out/app-log.txt" && activity_finished=true
  grep -q 'activity destroyed' "$out/app-log.txt" && activity_destroyed=true
  crash_patterns='FATAL EXCEPTION|Fatal signal [0-9]+|AndroidRuntime|am_crash|Application Error|ANR in|Tombstone written|Abort message'
  crash_markers=$(grep -E "$crash_patterns" "$out/logcat.txt" | grep -E "$package_id|${hey_pid:-no-pid}" | grep -c . || true)
  dialogs=$(adb shell dumpsys window 2>/dev/null | grep -cE "(Application Error|Application Not Responding): $package_id" || true)
  crash_markers=$((crash_markers + dialogs))

  printf 'program ended=%s status=%s activity_finished=%s activity_destroyed=%s process_exited=%s crash_markers=%s\n' \
    "${program_how:-no}" "${program_status:-none}" "$activity_finished" "$activity_destroyed" "$process_exited" "$crash_markers"
  printf -- '-- logcat (hey.*) --\n'
  head -20 "$out/logcat-hey.txt"
  if [ "$ui_mode" = true ]; then
    printf 'ui commits=%s views_on_screen=%s\n' "${ui_commits:-0}" "${ui_views:-none}"
    [ "${ui_commits:-0}" -gt 0 ] || die 1 'the program committed no screen (no "hey.ui: commit:" line in logcat)'
  else
    [ -n "$program_how" ] || die 1 'the process ended without the Hey program reporting its end (see logcat.txt)'
    [ "$activity_finished" = true ] && [ "$activity_destroyed" = true ] || die 1 'the activity was not finished and destroyed'
  fi
  [ "$crash_markers" = 0 ] || die 1 "crash markers in logcat or a crash dialog: $crash_markers"
fi

current_step=done
write_receipt
printf 'hey-android-app ok apk=%s receipt=%s installed=%s launched=%s program_status=%s\n' \
  "$out/app.apk" "$out/receipt.json" "$installed" "$launched" "${program_status:-none}"
