# PROMPT — hey_reports

The package's own brief, kept with the code (ecosystem convention).
Cross-seat conversation and status traffic live in the seat directory,
not here.

## What this package is

Reporting charts for Hey, across web, mobile and television.

## The shape it settled on

A **surface-independent chart model** plus a **thin renderer per
surface**. The model computes data, bounds, scales, ticks and pie
angles and knows nothing about markup, widgets, colours or pixels it
was not handed. Renderers are not portable and are not pretended to be.

- `ReportsSvg` — SVG. Serves web natively and mobile through a WebView.
- `ReportsScene` — `hey-tv-scene-v2` widgets, targeting the EXISTING
  hey_tv contract rather than a new one. Horizontal bars only, because
  that is all the tvOS renderer's layout can express.

## Standing constraints

1. **No floating point.** A float passed as a function parameter is
   truncated in the compiled lane. Integer arithmetic only, everywhere.
2. **No arithmetic inside a string concatenation.** Compute into a
   named local first; the compiled lane turns `+` into concatenation.
3. **Escape everything in SVG. Escape nothing in a scene.** SVG is XML;
   a scene is JSON for a native renderer.
4. **Measure text in characters, never `len()`.** `len()` returns bytes.
5. **Both lanes, always.** `bin/check` diffs interpreter against
   compiled output on every spec.
6. **Never invent a widget kind.** `Television.validate_scene` rejects
   unknown kinds.

## Not in scope

Raster encoding of any kind. Interactivity. Real font metrics.
