# In progress

The 0.1.2 package compatibility release is ready for validation and immutable publication.

- Extract VSS UIKit host adapters into reusable opaque capability entry points.
