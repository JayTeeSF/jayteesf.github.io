#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

// Hey's str ABI is a pointer to immutable NUL-terminated bytes, so a
// str-returning entry is directly callable as a C string function --
// no boxed-value shim and no runtime library needed at link time.
extern const char *HEY_ENTRY_SYMBOL(void);
extern long long hey_fn_tvos_action_code(long long action_id);

@interface HeyTVViewController : UIViewController
@end

@implementation HeyTVViewController
- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = UIColor.blackColor;
  const char *manifestBytes = HEY_ENTRY_SYMBOL();
  NSString *manifest = manifestBytes ? [NSString stringWithUTF8String:manifestBytes] : @"{}";

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  title.text = @"Hey Party TV";
  title.textColor = UIColor.whiteColor;
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1];
  [self.view addSubview:title];

  UILabel *detail = [[UILabel alloc] init];
  detail.translatesAutoresizingMaskIntoConstraints = NO;
  detail.text = manifest;
  detail.textColor = UIColor.lightGrayColor;
  detail.numberOfLines = 6;
  detail.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
  [self.view addSubview:detail];

  UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
  button.translatesAutoresizingMaskIntoConstraints = NO;
  [button setTitle:@"Start room" forState:UIControlStateNormal];
  button.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  button.accessibilityIdentifier = @"start-room";
  [button addTarget:self action:@selector(startRoom:) forControlEvents:UIControlEventPrimaryActionTriggered];
  [self.view addSubview:button];

  [NSLayoutConstraint activateConstraints:@[
    [title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:80],
    [detail.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:120],
    [detail.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-120],
    [detail.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:50],
    [button.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [button.topAnchor constraintEqualToAnchor:detail.bottomAnchor constant:70]
  ]];
}

- (void)startRoom:(id)sender {
  long long code = hey_fn_tvos_action_code(1);
  ((UIButton *)sender).accessibilityValue = [NSString stringWithFormat:@"%lld", code];
}
@end

@interface HeyTVAppDelegate : UIResponder <UIApplicationDelegate>
@property(strong, nonatomic) UIWindow *window;
@end

@implementation HeyTVAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
  self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  self.window.rootViewController = [[HeyTVViewController alloc] init];
  [self.window makeKeyAndVisible];
  return YES;
}
@end

int main(int argc, char **argv) {
  @autoreleasepool {
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(HeyTVAppDelegate.class));
  }
}
