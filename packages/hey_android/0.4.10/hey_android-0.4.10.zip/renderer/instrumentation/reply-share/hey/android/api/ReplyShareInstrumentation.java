package hey.android.api;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Drives the actual form -> HTTP save -> success -> native chooser pipeline. */
public final class ReplyShareInstrumentation extends Instrumentation {
  private static final String TEXT = "  Exact reply\nwith a second paragraph — 😀  ";
  private static final String URL = "https://example.invalid/shared/synthetic/thread/author";
  private volatile Intent sent;
  private volatile CountDownLatch shared;
  private final AtomicInteger chooserCount = new AtomicInteger();
  private Bundle arguments;
  private String origin;
  private Activity activity;
  private Method top;
  private static void require(boolean good, String message) { if (!good) throw new AssertionError(message); }
  @Override public void onCreate(Bundle args) { arguments = args; super.onCreate(args); start(); }
  private Actions.Host page() throws Exception { return (Actions.Host) top.invoke(activity); }
  private static Object field(Object owner, String name) throws Exception {
    Field f = owner.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(owner);
  }
  private static View find(View view, Class<?> kind) {
    if (kind.isInstance(view)) return view;
    if (view instanceof ViewGroup) {
      ViewGroup group = (ViewGroup) view;
      for (int i = 0; i < group.getChildCount(); i++) { View found = find(group.getChildAt(i), kind); if (found != null) return found; }
    }
    return null;
  }
  private Map<String, Object> get(String path) throws Exception {
    HttpURLConnection conn = (HttpURLConnection) new URL(origin + path).openConnection();
    conn.setConnectTimeout(2000); conn.setReadTimeout(2000);
    try (java.io.InputStream in = conn.getInputStream()) { return Json.dict(Json.parseOrNull(in.readAllBytes())); }
    finally { conn.disconnect(); }
  }
  private void saved(int count) throws Exception {
    long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
    while (Values.integer(get("/stats").get("writes")) < count && System.nanoTime() < end) Thread.sleep(25);
    require(Values.integer(get("/stats").get("writes")) == count, "synthetic reply did not save exactly once");
  }
  private void payload() throws Exception { payload(TEXT, true); }
  private void payload(String text, boolean imageExpected) throws Exception {
    require(sent != null && Intent.ACTION_SEND.equals(sent.getAction()), "missing ACTION_SEND");
    require((text + "\n\n" + URL).equals(sent.getStringExtra(Intent.EXTRA_TEXT)), "exact authored text or direct thread URL changed");
    if (!imageExpected) { require(!sent.hasExtra(Intent.EXTRA_STREAM), "timeout must retain text-only sharing"); return; }
    Uri stream = sent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
    require(stream != null && "content".equals(stream.getScheme()), "saved reply artwork missing");
    require(sent.getClipData() != null && stream.equals(sent.getClipData().getItemAt(0).getUri()), "saved reply artwork grant missing from ClipData");
    require((sent.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0, "saved reply artwork read grant missing");
    try (java.io.InputStream in = activity.getContentResolver().openInputStream(stream)) {
      byte[] bytes = in.readAllBytes(); require(bytes.length > 8 && bytes[1] == 80 && bytes[2] == 78, "saved reply stream is not PNG");
    }
  }
  interface Connections { HttpURLConnection open(String address) throws Exception; }
  private HeyAndroidPictures newPictures(Connections opener) throws Exception {
    // Reflect only new image-test hooks so the form scenarios also compile
    // against the retained SDK0.4.8 source for real negative reproductions.
    Class<?> connections = Class.forName("hey.android.api.HeyAndroidPictures$ShareConnections");
    Object proxy = java.lang.reflect.Proxy.newProxyInstance(connections.getClassLoader(), new Class<?>[] {connections},
        (object, method, args) -> opener.open((String) args[0]));
    Constructor<?> constructor = HeyAndroidPictures.class.getDeclaredConstructor(connections);
    constructor.setAccessible(true);
    return (HeyAndroidPictures) constructor.newInstance(proxy);
  }
  private void pictureMethod(HeyAndroidPictures pictures, String name) {
    try { Method method = HeyAndroidPictures.class.getDeclaredMethod(name); method.setAccessible(true); method.invoke(pictures); }
    catch (Exception error) { throw new RuntimeException(error); }
  }

  private void imageBounds() throws Exception {
    AtomicInteger opened = new AtomicInteger();
    HeyAndroidPictures pictures = newPictures(address -> {
      opened.incrementAndGet();
      return (HttpURLConnection) new URL(origin + "/image/" + address.substring(address.lastIndexOf('/') + 1)).openConnection();
    });
    try {
      for (String kind : new String[] {"drip", "oversized-header", "oversized-body", "oversized-pixels", "broken", "large"}) {
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Uri> uri = new AtomicReference<>();
        AtomicInteger completions = new AtomicInteger();
        long start = System.nanoTime();
        runOnMainSync(() -> pictures.shareImage(activity, "https://example.invalid/" + kind,
            result -> { uri.set(result); completions.incrementAndGet(); done.countDown(); }));
        require(done.await(4, TimeUnit.SECONDS), "image case did not finish: " + kind);
        long millis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);
        require(millis < 3200, "whole image deadline exceeded: " + kind + " " + millis);
        if (kind.equals("large")) {
          require(uri.get() != null, "bounded large source did not become an actual attachment");
          android.graphics.BitmapFactory.Options bounds = new android.graphics.BitmapFactory.Options();
          bounds.inJustDecodeBounds = true;
          try (java.io.InputStream input = activity.getContentResolver().openInputStream(uri.get())) {
            android.graphics.BitmapFactory.decodeStream(input, null, bounds);
          }
          require(bounds.outWidth > 0 && (long) bounds.outWidth * bounds.outHeight <= 1024 * 1024
              && Math.max(bounds.outWidth, bounds.outHeight) <= 2048, "shared decode exceeds pixel budget");
          int before = opened.get();
          CountDownLatch retry = new CountDownLatch(1);
          AtomicReference<Uri> retried = new AtomicReference<>();
          runOnMainSync(() -> pictures.shareImage(activity, "https://example.invalid/large", result -> { retried.set(result); retry.countDown(); }));
          require(retry.await(3, TimeUnit.SECONDS) && retried.get() != null && opened.get() == before,
              "bounded cached PNG retry fetched again or lost its actual attachment");
          for (int i = 0; i < 5; i++) {
            CountDownLatch more = new CountDownLatch(1);
            String address = "https://example.invalid/large?entry=" + i;
            runOnMainSync(() -> pictures.shareImage(activity, address, result -> more.countDown()));
            require(more.await(3, TimeUnit.SECONDS), "share cache image did not finish");
          }
          Map<String, Bitmap> cache = (Map<String, Bitmap>) field(pictures, "shareHeld");
          require(cache.size() <= 4 && cache.values().stream().allMatch(bitmap -> (long) bitmap.getWidth() * bitmap.getHeight() <= 1024 * 1024),
              "share bitmap cache exceeds its four-image/pixel budget");
        } else require(uri.get() == null, "unsafe/broken/slow image should allow text/link fallback: " + kind);
        ExecutorService worker = (ExecutorService) field(pictures, "shares");
        worker.submit(() -> {}).get(1, TimeUnit.SECONDS);
        Thread.sleep(100);
        require(completions.get() == 1, "image completed twice: " + kind);
      }
    } finally { pictureMethod(pictures, "close"); }
  }

  private int pixel(Uri uri) throws Exception {
    try (java.io.InputStream input = activity.getContentResolver().openInputStream(uri)) {
      Bitmap image = android.graphics.BitmapFactory.decodeStream(input);
      require(image != null, "account artwork was not decoded");
      return image.getPixel(0, 0);
    }
  }

  private void accountCache() throws Exception {
    AtomicReference<String> account = new AtomicReference<>("account-a");
    AtomicInteger requests = new AtomicInteger();
    HeyAndroidPictures pictures = newPictures(address -> {
      requests.incrementAndGet();
      return (HttpURLConnection) new URL(origin + "/image/" + account.get()).openConnection();
    });
    String same = "https://example.invalid/same-artwork";
    try {
      CountDownLatch a = new CountDownLatch(1);
      AtomicReference<Uri> attachment = new AtomicReference<>();
      runOnMainSync(() -> pictures.shareImage(activity, same, uri -> { attachment.set(uri); a.countDown(); }));
      require(a.await(3, TimeUnit.SECONDS) && attachment.get() != null && pixel(attachment.get()) == 0xffff0000, "A artwork was not red");
      Bitmap oldFull = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); oldFull.eraseColor(0xffff0000);
      ((Map<String, Bitmap>) field(pictures, "held")).put("full|" + same, oldFull);
      account.set("account-b");
      runOnMainSync(() -> pictureMethod(pictures, "sessionChanged"));
      CountDownLatch b = new CountDownLatch(1);
      runOnMainSync(() -> pictures.shareImage(activity, same, uri -> { attachment.set(uri); b.countDown(); }));
      require(b.await(3, TimeUnit.SECONDS) && attachment.get() != null && pixel(attachment.get()) == 0xff0000ff && requests.get() == 2,
          "same URL exported cached A artwork under B");
      account.set("account-slow");
      runOnMainSync(() -> pictureMethod(pictures, "sessionChanged"));
      AtomicInteger oldCallbacks = new AtomicInteger();
      runOnMainSync(() -> pictures.shareImage(activity, same, uri -> oldCallbacks.incrementAndGet()));
      long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(2);
      while (requests.get() < 3 && System.nanoTime() < end) Thread.sleep(10);
      require(requests.get() == 3, "slow A image did not start");
      account.set("account-b");
      runOnMainSync(() -> pictureMethod(pictures, "sessionChanged"));
      CountDownLatch current = new CountDownLatch(1);
      runOnMainSync(() -> pictures.shareImage(activity, same, uri -> { attachment.set(uri); current.countDown(); }));
      require(current.await(3, TimeUnit.SECONDS) && attachment.get() != null && pixel(attachment.get()) == 0xff0000ff, "old in-flight artwork repopulated B cache");
      Thread.sleep(500);
      require(oldCallbacks.get() == 0, "old identity completed a share callback");
    } finally { pictureMethod(pictures, "close"); }
  }

  @Override public void onStart() {
    Bundle result = new Bundle();
    CountDownLatch release = new CountDownLatch(1);
    try {
      addMonitor(new ActivityMonitor() {
        @Override public ActivityResult onStartActivity(Intent intent) {
          if (!Intent.ACTION_CHOOSER.equals(intent.getAction())) return null;
          chooserCount.incrementAndGet();
          sent = intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class);
          shared.countDown();
          return new ActivityResult(Activity.RESULT_CANCELED, null);
        }
      });
      activity = startActivitySync(new Intent().setClassName(getTargetContext().getPackageName(), "hey.android.api.HeyAndroidApiActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
      top = activity.getClass().getDeclaredMethod("top"); top.setAccessible(true);
      origin = ((HeyAndroidHttp) field(activity, "http")).origin;
      Object pictures = field(activity, "pictures");
      Bitmap image = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888); image.eraseColor(0xff225588);
      ((Map<String, Bitmap>) field(pictures, "held")).put("full|https://example.invalid/reply-art.png", image);
      String scenario = arguments.getString("scenario", "normal");
      require(Arrays.asList("normal", "busy-images", "busy-share", "repeat-primary", "navigate", "edit", "leave", "signout", "image-bounds", "account-cache").contains(scenario), "unknown scenario");
      if (scenario.equals("account-cache")) {
        accountCache();
        result.putString("stream", "reply_form_share=true scenario=account-cache same_url_A_to_B=true stale_image_blocked=true");
        finish(Activity.RESULT_OK, result); return;
      }
      if (scenario.equals("image-bounds")) {
        imageBounds();
        result.putString("stream", "reply_form_share=true scenario=image-bounds whole_transfer_deadline=true compressed_cap=true decode_pixel_cap=true actual_attachment=true cached_retry=true once_completion=true");
        finish(Activity.RESULT_OK, result); return;
      }
      if (scenario.equals("busy-images") || scenario.equals("busy-share") || scenario.equals("leave") || scenario.equals("signout")) {
        ExecutorService pool = (ExecutorService) field(pictures, scenario.equals("busy-images") ? "pool" : "shares");
        int workers = scenario.equals("busy-images") ? 2 : 1;
        CountDownLatch occupied = new CountDownLatch(workers);
        Runnable wait = () -> { occupied.countDown(); try { release.await(15, TimeUnit.SECONDS); } catch (InterruptedException ignored) {} };
        for (int i = 0; i < workers; i++) pool.execute(wait);
        require(occupied.await(2, TimeUnit.SECONDS), "could not occupy thumbnail workers");
      }
      if (scenario.equals("navigate")) {
        Map<String, Object> screen = (Map<String, Object>) field(page(), "screen");
        Json.dict(Json.dict(screen.get("primary")).get("on_success")).put("go", "saved");
      }
      shared = new CountDownLatch(1);
      runOnMainSync(() -> {
        EditText edit = (EditText) find(activity.getWindow().getDecorView(), EditText.class);
        edit.setText(TEXT);
        ((Button) find(activity.getWindow().getDecorView(), Button.class)).performClick();
      });
      saved(1);
      if (scenario.equals("leave") || scenario.equals("signout")) {
        Actions.Host oldPage = page();
        runOnMainSync(() -> {
          try {
            if (scenario.equals("signout")) {
              Field token = activity.getClass().getDeclaredField("token"); token.setAccessible(true); token.set(activity, "synthetic-A");
              activity.getClass().getMethod("signedOut").invoke(activity);
            } else {
              Method push = activity.getClass().getDeclaredMethod("push", String.class, Map.class); push.setAccessible(true); push.invoke(activity, "saved", null);
            }
          } catch (Exception error) { throw new RuntimeException(error); }
        });
        release.countDown();
        require(!shared.await(3, TimeUnit.SECONDS), "late image opened sharing after leave/sign-out");
        require(!oldPage.actionScope().getAsBoolean(), "old page action scope survived leave/sign-out");
        result.putString("stream", "reply_form_share=true scenario=" + scenario + " stale_share_blocked=true");
        finish(Activity.RESULT_OK, result); return;
      }

      boolean opened = shared.await(scenario.equals("busy-share") ? 4 : scenario.equals("normal") ? 8 : 2, TimeUnit.SECONDS);
      require(opened, "reply saved once but chooser did not open (" + scenario + ")");
      payload(TEXT, !scenario.equals("busy-share"));
      release.countDown();
      require(TEXT.equals(get("/saved/1").get("body")), "cancelling chooser lost the saved reply");
      long readsBeforeRetry = Values.integer(get("/stats").get("reads"));
      if (scenario.equals("busy-share")) {
        Thread.sleep(200);
        require(chooserCount.get() == 1, "late image opened a second chooser after timeout");
      }

      shared = new CountDownLatch(1);
      runOnMainSync(() -> {
        try {
          if (!scenario.equals("normal") && !scenario.equals("navigate") && !scenario.equals("busy-images")) {
            ((Button) find(activity.getWindow().getDecorView(), Button.class)).performClick();
            return;
          }
          Map<String, Object> retry = new LinkedHashMap<>();
          retry.put("request", Map.of("method", "GET", "path", "/saved/1"));
          retry.put("share_result", "url"); retry.put("then", "stay");
          Actions.run(retry, null, page(), (HeyAndroidHttp) field(activity, "http"));
        } catch (Exception error) { throw new RuntimeException(error); }
      });
      require(shared.await(4, TimeUnit.SECONDS), "saved reply retry did not open chooser"); payload();
      require(Values.integer(get("/stats").get("writes")) == 1, "share retry duplicated the authored message");
      if (!scenario.equals("normal") && !scenario.equals("navigate") && !scenario.equals("busy-images")) {
        require(Values.integer(get("/stats").get("reads")) == readsBeforeRetry, "unchanged-primary retry fetched a newer response");
      }

      if (scenario.equals("edit")) {
        shared = new CountDownLatch(1);
        runOnMainSync(() -> {
          ((EditText) find(activity.getWindow().getDecorView(), EditText.class)).setText(TEXT + "edited");
          Button button = (Button) find(activity.getWindow().getDecorView(), Button.class);
          require("Save reply".contentEquals(button.getText()), "editing did not restore submit label");
          button.performClick();
        });
        require(shared.await(5, TimeUnit.SECONDS), "edited explicit reply did not share"); saved(2); payload(TEXT + "edited", true);
      }
      result.putString("stream", "reply_form_share=true scenario=" + scenario + " exact_text=true image=true direct_thread=true retry_no_write=true cancel_preserves=true");
      finish(Activity.RESULT_OK, result);
    } catch (Throwable error) {
      result.putString("stream", "FAIL: " + error); finish(Activity.RESULT_CANCELED, result);
    } finally {
      release.countDown();
      if (activity != null) runOnMainSync(activity::finish);
    }
  }
}
