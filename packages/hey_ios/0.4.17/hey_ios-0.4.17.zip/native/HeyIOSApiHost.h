// HeyIOSApiHost: the native host for a hey_mobile api_screens description.
//
// The app's ordinary Hey exports these functions through the LLVM lane:
//   const char *hey_fn_ios_app_manifest(void)   the description, as JSON
//   int64_t hey_fn_ios_manifest_length(void)    its byte length, so a manifest
//                                               damaged in lowering is refused
//   const char *hey_fn_ios_app_origin(void)     the server origin (optional;
//                                               without it the description's
//                                               own `origin` is read)
// The generated main.m hands the first two to HeyIOSApiHostStart and runs
// UIApplicationMain with HeyIOSAppDelegate. Everything else (requests, the
// bearer token in the Keychain, lists, forms, search with polling, deep links
// and the Listen tab) is driven by the description. No product knowledge
// lives here.
//
// A RENDERER AT LEVEL 3 of hey_mobile's contract. The description is generated
// at build time and bundled with the app. No downloaded definition is read,
// fetched or installed at launch, foreground or refresh, even if a legacy
// `served` setting remains in the bundle. Store-delivered builds change UI.
// It hides every kind it does not know and never sends a request for an action
// it does not recognise.
//
// ANOTHER SCENE CAN SHOW THE SAME AUDIO. A package that adds a scene (the car
// screen in hey_carplay) is linked through the build tool's --extension, which
// declares the scene in Info.plist; the host configures any scene role other
// than the phone's window from that declaration. The scene lists what the
// Listen tab lists through HeyIOSApiHostLoadAudioFeed and re-reads it when
// HeyIOSApiHostAudioFeedDidChange is posted (sign-in, sign-out, an item
// played to its end).
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

void HeyIOSApiHostStart(const char *_Nonnull (*_Nonnull manifest)(void), int64_t (*_Nonnull manifestLength)(void));

// Posted, on any queue, when what the audio feed lists may have changed.
extern NSNotificationName const HeyIOSApiHostAudioFeedDidChange;

// sections: [{title, rows: [{id, title, subtitle, image_url, symbol, kind,
// audio_url | audio_urls, position_page, position_seconds, apple_music_id,
// requires}]}], built from the description's audio block. A row still being
// looked up carries no audio (HeyIOSAudioRowPlayable refuses it). message:
// why there is nothing to list (signed out, a failed request, an empty feed),
// else nil. The completion runs on any queue.
typedef void (^HeyIOSApiHostAudioFeedCompletion)(NSArray<NSDictionary *> *sections, NSString *_Nullable message);
void HeyIOSApiHostLoadAudioFeed(HeyIOSApiHostAudioFeedCompletion completion);

// The audio block's title (the Listen tab's name), or @"" when it has none.
NSString *HeyIOSApiHostAudioTitle(void);

@interface HeyIOSAppDelegate : UIResponder <UIApplicationDelegate>
@end

@interface HeyIOSPhoneSceneDelegate : UIResponder <UIWindowSceneDelegate>
@property(nonatomic, strong, nullable) UIWindow *window;
@end

NS_ASSUME_NONNULL_END
