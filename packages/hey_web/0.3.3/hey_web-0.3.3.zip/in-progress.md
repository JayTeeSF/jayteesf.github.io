# In progress

Staged for 0.3.0 (VERSION still 0.2.0; the release pipeline runs the
bump). 0.3.0 is BREAKING by maintainer ruling (2026-07-30): the broken
Web.service/Web.start-reaching middleware serving lane is DELETED, and
the ONE serving lane is exactly RecallCoach's --
Web.serve(routes, {host, port, workers, request_timeout_ms,
max_body_bytes}) over a flat route table. README's removal table names
every deleted public call (HeyWebServer.service,
HeyWebServer.middleware + the config middleware list, application.stack,
the backlog/read/write/idle timeout config keys) and its replacement.
The fast-lane extraction below is the supporting cast around that lane.

- FAST-LANE MODULES, extracted whole from RecallCoach and
  prefix-parameterized: `listen.hey` (HeyWebListen), `origin.hey`
  (HeyWebOrigin), `request_support.hey` (HeyWebRequest),
  `request_log.hey` (HeyWebRequestLog), `responses.hey`
  (HeyWebResponses). Stdlib-only leaves, never-nil public surfaces,
  Env.default reads, bare index_of/slice. Covered by five new specs
  plus `tools/compiled_receipt.hey` in bin/check (interpreter vs
  compiled stdout byte-identical).
- PAGES EMBEDDING: `pages_embed.hey` + `bin/pages-embed`(.hey) render
  page assets (*.html verbatim, *.html.ehy through stdlib Ehy at
  generation time) into a generated heredoc module; single-quote and
  CRLF assets refused mechanically. Round-trip proof interpreted
  (specs/pages_embed_spec.hey, scratch port 46511) and compiled
  (tools/pages_serve_receipt.hey, scratch port 46512): served bytes ==
  authored asset bytes.
- HOUSEKEEPING: src/ stale duplicates deleted (live_parallel_spec
  rewritten onto the root surface; legacy bin/client +
  tools/hey_web_client.hey removed -- bin/hey-web is the client);
  bin/heyc's ../elders_prayer_app fallback replaced with $HEY_ROOT
  resolution; README documents the two lanes honestly (the middleware
  lane is UNMEASURED against stdlib serving; the one benchmark was
  retracted in full).

RecallCoach itself does NOT adopt these modules in this slice: that is
perf-gated G-work (framework-extraction.md section 8) behind the G1
measurement.
