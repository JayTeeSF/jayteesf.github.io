#import "HeyIOSCarPlay.h"
#import "HeyIOSApiHost.h"
#import "HeyIOSAudio.h"
#import <CarPlay/CarPlay.h>
#import <UIKit/UIKit.h>

static NSHashTable *HeyIOSCarPlayDelegates = nil;

static NSString *HeyIOSCarPlayString(id value) { return [value isKindOfClass:[NSString class]] ? value : @""; }

NSArray<NSDictionary *> *HeyIOSCarPlayPlayableSections(NSArray<NSDictionary *> *sections, BOOL appleMusicAvailable) {
  NSMutableArray *kept = [NSMutableArray array];
  for (NSDictionary *section in sections) {
    if (![section isKindOfClass:[NSDictionary class]]) continue;
    NSArray *rows = [section[@"rows"] isKindOfClass:[NSArray class]] ? section[@"rows"] : @[];
    NSMutableArray *playable = [NSMutableArray array];
    for (NSDictionary *row in rows) {
      if (HeyIOSAudioRowPlayable(row, appleMusicAvailable)) [playable addObject:row];
    }
    if (playable.count > 0) [kept addObject:@{@"title": HeyIOSCarPlayString(section[@"title"]), @"rows": playable}];
  }
  return kept;
}

@interface HeyIOSCarPlaySceneDelegate : UIResponder <CPTemplateApplicationSceneDelegate>
@property(nonatomic, strong, nullable) CPInterfaceController *interfaceController;
@property(nonatomic, strong, nullable) CPListTemplate *listTemplate;
- (void)reload;
@end

void HeyIOSCarPlayReload(void) {
  dispatch_async(dispatch_get_main_queue(), ^{
    for (HeyIOSCarPlaySceneDelegate *delegate in HeyIOSCarPlayDelegates) [delegate reload];
  });
}

// Sign-in, sign-out and an item played to its end all change what the car
// lists; the host says so once and every connected screen re-reads.
static void HeyIOSCarPlayObserveFeed(void) {
  static dispatch_once_t once;
  dispatch_once(&once, ^{
    [[NSNotificationCenter defaultCenter] addObserverForName:HeyIOSApiHostAudioFeedDidChange object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
      (void)note;
      HeyIOSCarPlayReload();
    }];
  });
}

@implementation HeyIOSCarPlaySceneDelegate

- (void)templateApplicationScene:(CPTemplateApplicationScene *)templateApplicationScene
    didConnectInterfaceController:(CPInterfaceController *)interfaceController {
  (void)templateApplicationScene;
  HeyIOSCarPlayObserveFeed();
  if (HeyIOSCarPlayDelegates == nil) HeyIOSCarPlayDelegates = [NSHashTable weakObjectsHashTable];
  [HeyIOSCarPlayDelegates addObject:self];
  NSString *title = HeyIOSApiHostAudioTitle();
  if (title.length == 0) title = @"Audio";
  self.interfaceController = interfaceController;
  self.listTemplate = [[CPListTemplate alloc] initWithTitle:title sections:@[]];
  self.listTemplate.emptyViewTitleVariants = @[@"Loading"];
  self.listTemplate.tabTitle = title;
  [interfaceController setRootTemplate:self.listTemplate animated:NO completion:nil];
  [self reload];
}

- (void)templateApplicationScene:(CPTemplateApplicationScene *)templateApplicationScene
    didDisconnectInterfaceController:(CPInterfaceController *)interfaceController {
  (void)templateApplicationScene; (void)interfaceController;
  [HeyIOSCarPlayDelegates removeObject:self];
  self.interfaceController = nil;
  self.listTemplate = nil;
}

- (void)reload {
  if (self.listTemplate == nil) return;
  __weak typeof(self) weakSelf = self;
  HeyIOSApiHostLoadAudioFeed(^(NSArray<NSDictionary *> *sections, NSString *message) {
    HeyIOSAudioCheckAppleMusic(^(BOOL appleMusic) {
      [weakSelf showSections:HeyIOSCarPlayPlayableSections(sections ?: @[], appleMusic) message:message];
    });
  });
}

- (void)showSections:(NSArray<NSDictionary *> *)sections message:(NSString *)message {
  NSMutableArray<CPListSection *> *built = [NSMutableArray array];
  for (NSDictionary *section in sections) {
    NSMutableArray<CPListItem *> *items = [NSMutableArray array];
    for (NSDictionary *row in section[@"rows"]) [items addObject:[self itemForRow:row]];
    [built addObject:[[CPListSection alloc] initWithItems:items header:HeyIOSCarPlayString(section[@"title"]) sectionIndexTitle:nil]];
  }
  NSString *empty = message.length > 0 ? message : @"Nothing to play yet";
  self.listTemplate.emptyViewTitleVariants = @[empty];
  [self.listTemplate updateSections:built];
}

- (CPListItem *)itemForRow:(NSDictionary *)row {
  NSString *detail = HeyIOSCarPlayString(row[@"subtitle"]);
  CPListItem *item = [[CPListItem alloc] initWithText:HeyIOSCarPlayString(row[@"title"]) detailText:detail.length > 0 ? detail : nil];
  __weak typeof(self) weakSelf = self;
  item.handler = ^(id<CPSelectableListItem> selected, dispatch_block_t completion) {
    (void)selected;
    [[HeyIOSAudio shared] playRow:row];
    CPNowPlayingTemplate *nowPlaying = [CPNowPlayingTemplate sharedTemplate];
    if (weakSelf.interfaceController.topTemplate != nowPlaying) {
      [weakSelf.interfaceController pushTemplate:nowPlaying animated:YES completion:nil];
    }
    completion();
  };
  // The same glyph the phone draws for a row with no picture, replaced by the
  // artwork when it arrives.
  NSString *symbol = HeyIOSCarPlayString(row[@"symbol"]);
  if (symbol.length > 0) [item setImage:[UIImage systemImageNamed:symbol]];
  NSURL *art = [NSURL URLWithString:HeyIOSCarPlayString(row[@"image_url"])];
  if (art.scheme.length > 0) {
    [[[NSURLSession sharedSession] dataTaskWithURL:art completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
      (void)response;
      UIImage *image = error == nil && data.length > 0 ? [UIImage imageWithData:data] : nil;
      if (image == nil) return;
      dispatch_async(dispatch_get_main_queue(), ^{ [item setImage:image]; });
    }] resume];
  }
  return item;
}

@end
