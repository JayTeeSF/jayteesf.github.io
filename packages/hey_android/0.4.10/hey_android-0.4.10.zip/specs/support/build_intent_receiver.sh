#!/usr/bin/env bash
# Build the test-only URL receiver; it has no network permission and no browser setup.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
out=${1:?output directory required}
mkdir -p "$out/classes" "$out/dex"
java_home=$(hey_android_java_home)
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
"$java_home/bin/javac" --release 17 -classpath "$HEY_ANDROID_PLATFORM_JAR" -d "$out/classes" "$ROOT/renderer/instrumentation/hey/android/fixture/IntentReceiver.java"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/d8" --min-api 35 --lib "$HEY_ANDROID_PLATFORM_JAR" --output "$out/dex" "$out/classes/hey/android/fixture/IntentReceiver.class"
"$bt/aapt2" link --manifest "$ROOT/specs/support/intent_receiver/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -o "$out/base.apk"
(cd "$out/dex" && zip -q "$out/base.apk" classes.dex)
"$bt/zipalign" -P 16 -f 4 "$out/base.apk" "$out/aligned.apk"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" sign --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$out/app.apk" "$out/aligned.apk"
