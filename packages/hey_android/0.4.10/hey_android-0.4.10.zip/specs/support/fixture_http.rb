# fixture_http.rb: the small HTTP/1.1 server under specs/support/fake_*_server.rb.
# One thread per connection, keep-alive as HTTP/1.1 defines it, bound to 127.0.0.1.
# A handler gets a Request and answers with Request#respond exactly once.
require 'socket'
require 'uri'

module FixtureHttp
  REASONS = {
    200 => 'OK', 304 => 'Not Modified', 400 => 'Bad Request', 401 => 'Unauthorized',
    404 => 'Not Found', 500 => 'Internal Server Error', 501 => 'Not Implemented'
  }.freeze

  class Request
    attr_reader :method, :target, :path, :query, :headers, :body

    def initialize(socket, method, target, headers, body)
      @socket = socket
      @method = method
      @target = target
      @headers = headers
      @body = body
      rest = target.sub(%r{\A[A-Za-z][A-Za-z0-9+.-]*://[^/?#]*}) { '' }.sub(/#.*\z/m) { '' }
      @path, @query = rest.split('?', 2)
      @query ||= ''
    end

    # The first value of a header, or nil; names are case-insensitive.
    def header(name)
      @headers[name.downcase]
    end

    # parse_qs: name => [values], blank values and names without "=" left out.
    def query_values
      values = {}
      @query.split('&').each do |pair|
        name, value = pair.split('=', 2)
        next if value.nil? || value.empty?
        values[FixtureHttp.unquote(name)] = (values[FixtureHttp.unquote(name)] || []) << FixtureHttp.unquote(value)
      end
      values
    end

    def respond(status, body = '', headers = [])
      head = ["HTTP/1.1 #{status} #{REASONS.fetch(status, 'Unknown')}", "Date: #{Time.now.utc.strftime('%a, %d %b %Y %H:%M:%S GMT')}"]
      headers.each { |k, v| head << "#{k}: #{v}" }
      @socket.write(head.join("\r\n") + "\r\n\r\n")
      @socket.write(body) unless body.empty?
    end
  end

  def self.unquote(text)
    URI.decode_www_form_component(text)
  rescue ArgumentError
    text
  end

  def self.serve(port, banner, handler)
    server = TCPServer.new('127.0.0.1', port)
    $stdout.puts banner
    $stdout.flush
    loop do
      client = server.accept
      Thread.new(client) { |socket| connection(socket, handler) }
    end
  end

  def self.connection(socket, handler)
    loop do
      line = socket.gets("\r\n")
      break if line.nil?
      line = line.chomp
      next if line.empty?
      method, target, version = line.split(' ', 3)
      if version.nil? || !version.start_with?('HTTP/')
        socket.write("HTTP/1.1 400 Bad Request\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
        break
      end
      headers = {}
      while (h = socket.gets("\r\n"))
        h = h.chomp
        break if h.empty?
        name, value = h.split(':', 2)
        headers[name.strip.downcase] ||= value.to_s.strip
      end
      keep = version >= 'HTTP/1.1'
      connection_header = headers['connection'].to_s.downcase
      keep = false if connection_header == 'close'
      keep = true if connection_header == 'keep-alive' && version >= 'HTTP/1.1'
      socket.write("HTTP/1.1 100 Continue\r\n\r\n") if headers['expect'].to_s.downcase == '100-continue' && version >= 'HTTP/1.1'
      length = headers['content-length'].to_i
      body = length > 0 ? socket.read(length).to_s : ''
      request = Request.new(socket, method, target, headers, body)
      if %w[GET POST].include?(method)
        handler.call(request)
      else
        socket.write("HTTP/1.1 501 Not Implemented\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
        keep = false
      end
      break unless keep
    end
  rescue IOError, SystemCallError
    nil
  ensure
    socket.close unless socket.closed?
  end
end
