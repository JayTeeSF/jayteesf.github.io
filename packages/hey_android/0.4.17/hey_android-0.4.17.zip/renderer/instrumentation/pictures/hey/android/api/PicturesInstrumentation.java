package hey.android.api;

import android.app.Instrumentation;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.CRC32;
import java.util.zip.Deflater;

/**
 * The image memory budgets on a real decoder (task 006, audit R02). Pictures are served by a fake
 * connection, so nothing leaves the device: a header-only PNG declaring 20000 x 20000, a large
 * photo for a row and for a header, one picture wanted by ten rows, a hundred distinct pictures
 * behind a closed gate, and enough full-size pictures to overflow the decoded-byte budget.
 */
public final class PicturesInstrumentation extends Instrumentation {
  private static final String TAG = "hey.pictures.test";
  private final Map<String, byte[]> served = new ConcurrentHashMap<>();
  private final AtomicInteger opens = new AtomicInteger();
  private volatile CountDownLatch gate = new CountDownLatch(0);

  private static void require(boolean ok, String why) {
    if (!ok) throw new AssertionError(why);
    Log.i(TAG, "ok " + why);
  }

  @Override public void onCreate(Bundle arguments) { super.onCreate(arguments); start(); }

  /** A connection that answers from `served`, waiting at `gate` first. */
  private final class Fake extends HttpURLConnection {
    private final byte[] body;
    Fake(URL url, byte[] body) { super(url); this.body = body; }
    @Override public void connect() {}
    @Override public void disconnect() {}
    @Override public boolean usingProxy() { return false; }
    @Override public int getResponseCode() throws java.io.IOException {
      try { gate.await(30, TimeUnit.SECONDS); } catch (InterruptedException e) { throw new java.io.IOException(e); }
      return body == null ? 404 : 200;
    }
    @Override public long getContentLengthLong() { return body == null ? -1 : body.length; }
    @Override public InputStream getInputStream() { return new ByteArrayInputStream(body); }
  }

  private static byte[] chunk(String type, byte[] data) {
    ByteBuffer b = ByteBuffer.allocate(12 + data.length);
    b.putInt(data.length).put(type.getBytes()).put(data);
    CRC32 crc = new CRC32();
    crc.update(type.getBytes());
    crc.update(data);
    b.putInt((int) crc.getValue());
    return b.array();
  }

  /** A PNG whose header says width x height, with almost no pixel data behind it. */
  private static byte[] bombPng(int width, int height) throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    out.write(new byte[] {(byte) 0x89, 'P', 'N', 'G', 13, 10, 26, 10});
    out.write(chunk("IHDR", ByteBuffer.allocate(13).putInt(width).putInt(height).put((byte) 8).put((byte) 6).put((byte) 0).put((byte) 0).put((byte) 0).array()));
    Deflater deflater = new Deflater();
    deflater.setInput(new byte[64]);
    deflater.finish();
    byte[] packed = new byte[256];
    int n = deflater.deflate(packed);
    out.write(chunk("IDAT", java.util.Arrays.copyOf(packed, n)));
    out.write(chunk("IEND", new byte[0]));
    return out.toByteArray();
  }

  private static byte[] photo(int width, int height, Bitmap.CompressFormat format) {
    Bitmap b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
    b.eraseColor(0xff336699);
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    b.compress(format, 60, out);
    b.recycle();
    return out.toByteArray();
  }

  @Override public void onStart() {
    Bundle result = new Bundle();
    try {
      ClassLoader app = getTargetContext().getClassLoader();
      Class<?> picturesClass = Class.forName("hey.android.api.HeyAndroidPictures", true, app);
      Class<?> connections = Class.forName("hey.android.api.HeyAndroidPictures$ShareConnections", true, app);
      Class<?> ready = Class.forName("hey.android.api.HeyAndroidPictures$Ready", true, app);
      Object opener = Proxy.newProxyInstance(app, new Class<?>[] {connections}, (proxy, method, args) -> {
        if (!method.getName().equals("open")) return method.invoke(this, args);
        String address = (String) args[0];
        opens.incrementAndGet();
        return new Fake(new URL(address), served.get(address));
      });
      Constructor<?> make = picturesClass.getDeclaredConstructor(connections);
      make.setAccessible(true);
      Object pictures = make.newInstance(opener);
      Method want = picturesClass.getDeclaredMethod("want", String.class, boolean.class, ready);
      want.setAccessible(true);
      Method bytes = picturesClass.getDeclaredMethod("heldBytes");
      bytes.setAccessible(true);
      Method held = picturesClass.getDeclaredMethod("held", String.class, boolean.class);
      held.setAccessible(true);
      Method close = picturesClass.getDeclaredMethod("close");
      close.setAccessible(true);

      // 1. The bomb: refused from its header, never decoded, never drawn.
      served.put("https://fixture.invalid/bomb.png", bombPng(20000, 20000));
      AtomicInteger drew = new AtomicInteger();
      CountDownLatch none = new CountDownLatch(1);
      Object counter = Proxy.newProxyInstance(app, new Class<?>[] {ready}, (p, m, a) -> { if (m.getName().equals("drew")) { drew.incrementAndGet(); none.countDown(); } return null; });
      long before = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
      want.invoke(pictures, "https://fixture.invalid/bomb.png", true, counter);
      require(!none.await(3, TimeUnit.SECONDS) && drew.get() == 0, "a PNG declaring 20000x20000 is never drawn");
      long after = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
      require(after - before < 64L * 1024 * 1024, "and refusing it did not allocate its 1.6 GB (" + (after - before) + " bytes grew)");
      opens.set(0);
      want.invoke(pictures, "https://fixture.invalid/bomb.png", true, counter);
      Thread.sleep(500);
      require(opens.get() == 0, "it is remembered as barren and not fetched again");

      // 2. A 3000x2000 photo: a row gets at most 512 on its longest side, a header at most 2048.
      served.put("https://fixture.invalid/photo.jpg", photo(3000, 2000, Bitmap.CompressFormat.JPEG));
      Bitmap[] got = new Bitmap[2];
      CountDownLatch both = new CountDownLatch(2);
      want.invoke(pictures, "https://fixture.invalid/photo.jpg", false, Proxy.newProxyInstance(app, new Class<?>[] {ready}, (p, m, a) -> { if (m.getName().equals("drew")) { got[0] = (Bitmap) a[0]; both.countDown(); } return null; }));
      want.invoke(pictures, "https://fixture.invalid/photo.jpg", true, Proxy.newProxyInstance(app, new Class<?>[] {ready}, (p, m, a) -> { if (m.getName().equals("drew")) { got[1] = (Bitmap) a[0]; both.countDown(); } return null; }));
      require(both.await(20, TimeUnit.SECONDS), "both sizes of the photo arrive");
      require(Math.max(got[0].getWidth(), got[0].getHeight()) <= 512, "the row copy is " + got[0].getWidth() + "x" + got[0].getHeight() + ", within 512");
      require(Math.max(got[1].getWidth(), got[1].getHeight()) <= 2048 && got[1].getWidth() >= 1024, "the header copy is " + got[1].getWidth() + "x" + got[1].getHeight() + ", within 2048 and still sharp");

      // 3. Ten rows wanting one picture: one fetch, ten drawn.
      served.put("https://fixture.invalid/shared.png", photo(400, 600, Bitmap.CompressFormat.PNG));
      opens.set(0);
      gate = new CountDownLatch(1);
      CountDownLatch ten = new CountDownLatch(10);
      Object tenCounter = Proxy.newProxyInstance(app, new Class<?>[] {ready}, (p, m, a) -> { if (m.getName().equals("drew")) ten.countDown(); return null; });
      for (int i = 0; i < 10; i++) want.invoke(pictures, "https://fixture.invalid/shared.png", false, tenCounter);
      gate.countDown();
      require(ten.await(20, TimeUnit.SECONDS), "all ten rows are drawn");
      require(opens.get() == 1, "from one fetch (" + opens.get() + " opened)");

      // 4. A hundred distinct pictures behind a closed gate: at most 48 wait, two fetch.
      opens.set(0);
      gate = new CountDownLatch(1);
      for (int i = 0; i < 100; i++) {
        served.put("https://fixture.invalid/many/" + i + ".png", photo(64, 64, Bitmap.CompressFormat.PNG));
        want.invoke(pictures, "https://fixture.invalid/many/" + i + ".png", false, counter);
      }
      Thread.sleep(500);
      long[] state = (long[]) bytes.invoke(pictures);
      require(state[3] <= 48, "a fling past 100 rows leaves " + state[3] + " fetches waiting, not 100");
      require(opens.get() <= 2, "and only the two workers are fetching (" + opens.get() + ")");
      gate.countDown();
      Thread.sleep(1500);

      // 5. Overflow the decoded-byte budget with 1024x1024 headers (4 MiB each decoded).
      byte[] square = photo(1024, 1024, Bitmap.CompressFormat.PNG);
      long limit = ((long[]) bytes.invoke(pictures))[1];
      int count = (int) (limit / (4L * 1024 * 1024)) + 8;
      CountDownLatch filled = new CountDownLatch(count);
      Object fillCounter = Proxy.newProxyInstance(app, new Class<?>[] {ready}, (p, m, a) -> { if (m.getName().equals("drew")) filled.countDown(); return null; });
      long peak = 0;
      for (int i = 0; i < count; i++) {
        served.put("https://fixture.invalid/full/" + i + ".png", square);
        want.invoke(pictures, "https://fixture.invalid/full/" + i + ".png", true, fillCounter);
        peak = Math.max(peak, ((long[]) bytes.invoke(pictures))[0]);
      }
      require(filled.await(60, TimeUnit.SECONDS), "all " + count + " full-size pictures are drawn");
      long[] end = (long[]) bytes.invoke(pictures);
      peak = Math.max(peak, end[0]);
      require(end[0] <= limit && peak <= limit, "held bytes stay within the budget: " + end[0] + " now, " + peak + " at most, limit " + limit);
      require(held.invoke(pictures, "https://fixture.invalid/full/0.png", true) == null, "the oldest picture went first");
      require(held.invoke(pictures, "https://fixture.invalid/full/" + (count - 1) + ".png", true) != null, "the newest is still held");

      close.invoke(pictures);
      result.putString("pictures_instrumentation", "true");
      finish(0, result);
    } catch (Throwable failure) {
      Log.e(TAG, "pictures check failed", failure);
      result.putString("pictures_instrumentation", "false");
      result.putString("failure", String.valueOf(failure.getCause() != null ? failure.getCause() : failure));
      finish(1, result);
    }
  }
}
