package android.media;
public class AudioManager {}
