// HeyIOSValues: the value language of a hey_mobile description, the kinds
// this renderer draws, and whether a served description is taken. Foundation
// only, so bin/conformance compiles it for the Mac and runs hey_mobile's
// conformance vectors against exactly the code the app ships.
//
// The rules are hey_mobile's docs/RENDERERS.md; the reference evaluator is
// hey_mobile's values.hey. Where this file and the vectors disagree, this file
// is wrong.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// The highest level of the hey_mobile contract this renderer draws, its
// platform name, the schema it reads, and the largest served body it takes.
// api-renderer.json says the same for build tools; bin/package-check holds
// the two together.
extern const NSInteger HeyIOSRendererLevel;
extern NSString *const HeyIOSRendererPlatform;
extern NSString *const HeyIOSDescriptionSchema;
extern const NSUInteger HeyIOSDescriptionMaxBytes;

NSDictionary *HeyIOSDict(id _Nullable value);
NSArray *HeyIOSArray(id _Nullable value);
// Text of a value: a string as it is, a number in its shortest form, true and
// false as those words, anything else @"".
NSString *HeyIOSString(id _Nullable value);
BOOL HeyIOSIsBoolean(id _Nullable value);
NSInteger HeyIOSInteger(id _Nullable value);

id _Nullable HeyIOSAt(id _Nullable json, NSString *_Nullable path);
NSString *HeyIOSStars(NSInteger halves);
NSString *HeyIOSDuration(NSInteger seconds);
NSString *HeyIOSFormat(NSString *inner, id _Nullable obj, NSDictionary *_Nullable labels);
NSString *HeyIOSRender(id _Nullable spec, id _Nullable obj, NSDictionary *_Nullable labels);
NSString *HeyIOSLine(id _Nullable spec, id _Nullable obj, NSDictionary *_Nullable labels);
NSString *HeyIOSText(id _Nullable spec, id _Nullable obj, NSDictionary *_Nullable labels);
BOOL HeyIOSTruthyValue(id _Nullable value);
BOOL HeyIOSTruthy(id _Nullable row, NSString *_Nullable path);
BOOL HeyIOSCondition(id _Nullable spec, id _Nullable obj);
// A request body value; nil when a '?' key is left out.
id _Nullable HeyIOSValue(id _Nullable spec, NSDictionary *_Nullable vars, id _Nullable row);
NSString *HeyIOSParam(id _Nullable spec, NSDictionary *_Nullable vars, id _Nullable row, id _Nullable json);
NSString *HeyIOSFillPath(NSString *path, NSDictionary *_Nullable vars);

// Kinds. What this renderer does not know it hides; it never sends a request
// for an action it does not recognise.
NSString *HeyIOSActionKind(id _Nullable action);
NSString *HeyIOSSectionKind(id _Nullable section);
NSString *HeyIOSRowKind(id _Nullable row);
BOOL HeyIOSKnown(NSString *category, id _Nullable element, NSInteger level);
BOOL HeyIOSKnownAction(id _Nullable action);
BOOL HeyIOSKnownScreen(id _Nullable screen);
BOOL HeyIOSKnownSection(id _Nullable section);
BOOL HeyIOSKnownField(id _Nullable field);
BOOL HeyIOSKnownRow(id _Nullable row);

// LEVEL 3 (hey_mobile values.hey chosen and offers; conformance/level3.json).
// CHOOSING SEVERAL: the variables what follows a choose_many reads, {values,
// value_titles}: the picked values in the order of the options, each once, and
// their titles joined by ", ". Values compare as text.
NSDictionary *HeyIOSChosen(NSArray *_Nullable options, NSArray *_Nullable picked);
// OFFERS: [{field, value, title}] a form lookup's offers make for its answer,
// in the order of the fields (a choice field carrying its options): only where
// the field was typed in, holds text, and the found text differs.
NSArray<NSDictionary *> *HeyIOSOffers(NSDictionary *_Nullable lookup, id _Nullable answer, NSArray *_Nullable fields, NSDictionary *_Nullable values, NSArray *_Nullable touched);

// Names no platform owns: hey_mobile icons.hey and its file kinds.
NSDictionary<NSString *, NSString *> *HeyIOSIconTable(void);
NSDictionary<NSString *, NSArray<NSString *> *> *HeyIOSFileKindTable(void);
// The SF Symbol for an icon name: the table's, else the name itself (a
// level-1 description spells icons as SF Symbols), else nil.
NSString *_Nullable HeyIOSSymbolName(NSString *_Nullable name);
// Uniform Type Identifiers for a document picker: from `accept` (file kinds)
// or, at level 1, `types`.
NSArray<NSString *> *HeyIOSTypeIdentifiers(NSDictionary *action);

// Served descriptions.
NSString *HeyIOSSHA256Hex(NSData *data);
// nil when the body is taken (and *parsed is set); else why it is refused:
// too_large, etag, not_json, not_object, schema, level, platform, screens,
// tabs or sign_in.
NSString *_Nullable HeyIOSDescriptionRefusal(NSData *_Nullable body, NSString *_Nullable etagHeader, NSDictionary *_Nullable *_Nullable parsed);
// The same for a renderer at `rendererLevel`: bin/conformance runs the level-2
// vectors (descriptions.json) and the level-3 vectors (level3.json) with it.
NSString *_Nullable HeyIOSDescriptionRefusalAt(NSData *_Nullable body, NSString *_Nullable etagHeader, NSInteger rendererLevel, NSDictionary *_Nullable *_Nullable parsed);
// The served description with everything that always comes from the baked
// copy put back: keychain_service, url_scheme, served, find_fixture, and the
// session's header, prefix, check and sign_out. A served origin is dropped.
NSDictionary *HeyIOSDescriptionMerged(NSDictionary *served, NSDictionary *baked);
// WHICH COPY IS DRAWN: the served body when this renderer takes it, else the
// stored last-good copy when it takes that, else the baked copy. *source is
// @"served", @"stored" or @"baked". The host asks this at launch (no served
// body yet) and when an answer arrives; an app's own gate can ask it with its
// real baked copy and broken answers.
NSData *HeyIOSDescriptionPick(NSData *baked, NSData *_Nullable stored, NSData *_Nullable served, NSString *_Nullable servedETag, NSString *_Nullable *_Nullable source);

NS_ASSUME_NONNULL_END
