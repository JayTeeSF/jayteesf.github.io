#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
INSTALLER="$ROOT/tooling/01-install-android-toolchain-macos.sh"

bash -n "$INSTALLER"

grep -F 'ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}"' "$INSTALLER" >/dev/null
grep -F 'SDK_CMDLINE_TOOLS="$ANDROID_HOME/cmdline-tools/latest"' "$INSTALLER" >/dev/null
grep -F 'ditto "$BREW_CMDLINE_TOOLS" "$cmdline_stage"' "$INSTALLER" >/dev/null
grep -F 'SDKMANAGER="$SDK_CMDLINE_TOOLS/bin/sdkmanager"' "$INSTALLER" >/dev/null
grep -F 'AVDMANAGER="$SDK_CMDLINE_TOOLS/bin/avdmanager"' "$INSTALLER" >/dev/null
grep -F '"$SDKMANAGER" --sdk_root="$ANDROID_HOME" --list_installed' "$INSTALLER" >/dev/null
grep -F '"$AVDMANAGER" create avd' "$INSTALLER" >/dev/null

if grep -F 'AVDMANAGER="$(command -v avdmanager' "$INSTALLER" >/dev/null; then
  echo "installer must not invoke Homebrew avdmanager through PATH" >&2
  exit 1
fi

copy_line="$(grep -n 'ditto "$BREW_CMDLINE_TOOLS" "$cmdline_stage"' "$INSTALLER" | head -1 | cut -d: -f1)"
local_avd_line="$(grep -n 'AVDMANAGER="$SDK_CMDLINE_TOOLS/bin/avdmanager"' "$INSTALLER" | head -1 | cut -d: -f1)"
create_line="$(grep -n '"$AVDMANAGER" create avd' "$INSTALLER" | head -1 | cut -d: -f1)"

[ "$copy_line" -lt "$local_avd_line" ] || {
  echo "command-line tools must be copied into the SDK before avdmanager is selected" >&2
  exit 1
}

[ "$local_avd_line" -lt "$create_line" ] || {
  echo "SDK-local avdmanager must be selected before AVD creation" >&2
  exit 1
}

echo "PASS: Android installer invokes SDK-local sdkmanager and avdmanager"
