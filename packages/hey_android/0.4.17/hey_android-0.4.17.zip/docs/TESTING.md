# Focused 0.4.9 boundaries

## 0.4.10: saved-response sharing

`docs/REPLY-SHARING.md` describes the app-declared `on_success.share_retry_title` contract, native image deadline, real-device negative reproductions and focused tests. Read it before changing form success, response retention or share presentation. The form and native host share the same response protocol.


Run `bash specs/android_boundaries_spec.sh` before device work: it compiles the actual player, HTTP, playback singleton and description loader against small deterministic Android doubles. It checks parsed origins (lookalike host, userinfo, scheme, port and defaults), controlled authenticated ranges, every redirect status, late player callbacks, old-cache refusal, A/B/C car feeds, pending callbacks and stable watcher identity. Prefix matching, automatic redirects and retained-feed mutants must fail for the intended reason. The production scan also rejects reintroduced definition fetch/cache/replacement methods.

`bash specs/android_boundary_device_spec.sh` builds a test-only instrumentation APK from production classes and uses generated silent WAV data with synthetic A/B/C credentials. It checks real range I/O, redirect refusal, native player readiness, car feed and MediaSession metadata teardown, and late feed cancellation. The local fixture logs account letters only; the gate checks no redirect sink or old-track report under a new bearer. It uninstalls its fixture and shuts down only the AVD it boots. `HEY_ANDROID_BOUNDARY_EVIDENCE=DIR` retains its logs.

`bash specs/api_renderer_host_spec.sh` keeps shared value/name/description validation and action/screens/sharing contracts, with a bundled-definition mutation replacing the obsolete served-origin mutation. `bash specs/api_renderer_emulator_spec.sh` retains sign-in, offline launch, conversation rows, image/message sharing and actions, and now requires zero description requests through launch, resume, reload and sign-out, with valid/corrupt legacy caches ignored.

Run the full package check and canonical publication command before release; focused renderer results do not cover the native Hey lane.

# Testing and evidence

## 0.4.8: outgoing artwork and exact messages (2026-10-29)

The action `share_result` and form `on_success.share` paths share the same
response reader. A plain URL can be enriched by `share_presentation` only when
its URL matches exactly, preserving a usable link for older renderers. The
Activity preserves multiline message text and appends the canonical URL. HTTPS
artwork reuses the picture cache and is encoded off the UI thread into a private
PNG cache; ACTION_SEND carries its content URI, ClipData and temporary read grant.
The provider rejects writes and paths outside that cache. Missing artwork keeps
the text and link. Renderer level remains 1.

Verification: the host renderer suite passes 112 checks and mutation controls.
`specs/api_renderer_share_spec.sh` captures the real Activity's chooser payload on
a disposable API 36 emulator, opens the PNG through ContentResolver and checks
permissions, path rejection and the plain-text fallback. Its baseline failed
because EXTRA_STREAM was missing; the updated renderer passes.


`bin/check` runs three things, in order:
- `hey package verify`;
- `bin/package-check`;
- the documentation example.

`bin/package-check` runs the Hey specs, then the ordered shell and emulator specs. Every check that
can pass has a negative control: a deliberately broken input that must fail,
because a check that cannot fail proves nothing.

**Ruby, not Python.** The tools and specs run their small helpers (receipts,
JSON fields, the IR scans, the emulator driver, the fixture servers) with Ruby
and its standard library: `HEY_ANDROID_RUBY`, else the `ruby` on the caller's
PATH, else `/usr/bin/ruby` (`tools/android-env.sh`). `bin/package-check` fails
if anything in `bin/`, `specs/` or `tools/` runs Python.

**The summary line.** The last line counts specs, checks passed, controls
passed and failures. It is printed only when there are no failures.

**Parallel builds.** Set `HEY_HEYC_LOCK` when other heyc builds may run at the
same time. A caller holding the build lock around all of `bin/check` must leave
`HEY_HEYC_LOCK` unset; the lock cannot be taken twice.

## The specs

### `specs/*_spec.hey`

These cover the pins as Hey values, the receipt predicate, and the lifecycle
and UI mappings.

Negative controls:
- the old API 34 / NDK 26.1 matrix is not compatible;
- a negative-control receipt is not a clean run;
- a receipt with a dex is not a clean run.

### `specs/pins_spec.sh`

It checks that:
- `tools/android-pins.env` and `src/toolchain.hey` agree on all ten pins;
- no API 34, build-tools 34, NDK 26.1, Gradle, AGP or CMake pin remains in the
  code.

Negative control: a changed NDK pin is caught.

### `specs/sha256_host_spec.sh`

It checks that:
- the selected Hey core runtime hashes both text and files to all five NIST
  vectors in `specs/sha256_vectors.txt` using its in-tree SHA-256;
- `shasum -a 256` independently agrees with the same vector file.

Negative control: a wrong digest differs from the runtime output.

### `specs/android_doctor_spec.sh`

It checks that `bin/android-doctor` passes on this Mac's pinned SDK.

Negative controls:
- An SDK holding only the old lane's packages (platform 34, build-tools 34,
  NDK 26.1, the API 34 image) is refused. The refusal must print the
  sdkmanager line for each of the four missing pins.
- With no `HEY_ROOT`, the doctor fails rather than guessing a checkout.

### `specs/android_build_spec.sh`

This spec builds `examples/hello_runtime.hey` with no device.
`CPATH`, `C_INCLUDE_PATH`, `LIBRARY_PATH`, `CPPFLAGS` and `LDFLAGS` all point
at Homebrew during the build.

It checks that:
- **Isolation:** the variables were cleared, and NDK clang searched only NDK
  include directories.
- **The runtime:** it is HEY_ROOT's own, unmodified and not copied.
- **The IR:**
  - it is target-neutral;
  - it has one `i32 @main(i32, ptr)`;
  - every stdlib call it makes has a native facade in the runtime.
- **The library:**
  - it is aarch64, and every LOAD segment is aligned to 16384;
  - every undefined symbol is defined by libc, libm, libdl, liblog or
    libandroid at API 35;
  - `ANativeActivity_onCreate` is exported;
  - it holds no OpenSSL, Apple crypto or Homebrew trace.
- **The APK:**
  - `hasCode="false"` and `extractNativeLibs="false"`, with no dex, jar or
    class files;
  - the launcher is `android.app.NativeActivity`;
  - target 36 and min 35;
  - only `lib/arm64-v8a/libhey_app.so`, stored uncompressed;
  - `zipalign -c -P 16` passes and apksigner verifies.

Negative controls:
- **Stdlib delegation:** a program using `Files.write_text` is refused. The
  runtime hands that call to the Hey toolchain at run time.
- **Target:** IR that names a Mac target triple is refused.
- **Stdlib archive:** IR that needs `libhey_stdlib.a` is refused.
- **Contamination:** the Hey runtime is compiled the way the spike first
  compiled it, with `CPATH` at Homebrew and no profile. That compile succeeds
  quietly. The object check then names the OpenSSL symbols, and so does the
  check of a library linked from that object.
- **Page size:** a library linked with 4 KB pages is refused.
- **Dex:** an APK with a `classes.dex` added and signed again is refused.
- **hasCode:** an APK whose manifest says `hasCode="true"` is refused.

### `specs/android_emulator_spec.sh`

**Mac references.** It first builds a reference for each of the four examples:
the same IR, through heyc's `link-ll`. Each runs with no Hey toolchain in its
environment, as on a phone.

**Boot.** It creates the AVD if needed, then boots `hey_android_API_36`
headless.

**hello_runtime:**
- installs and runs on API 36 arm64-v8a;
- the program returns 0, and the activity is finished and destroyed;
- the process exits, with no crash markers;
- its logcat output equals the Mac run byte for byte, and nothing goes to
  stderr on either side;
- the program thread's stack is 8 MiB, from `pthread_getattr_np`;
- launched a second time, it starts a fresh runtime and prints the same bytes.

**sha256_vectors:**
- all five NIST vectors pass through the Hey runtime on the emulator;
- each vector is checked as text (the runtime's SHA-256) and as a file (the
  vendored SHA-256 through the profile);
- the Mac passes the same vectors.

**platform_capabilities:**
- random bytes and constant-time compare work;
- scrypt, Argon2id and AES-256-GCM return `crypto_kdf_unavailable` and
  `crypto_aead_unavailable`, matching `specs/platform_capabilities.android.txt`.

**runtime_error:**
- the runtime's `exit(70)` ends the program, not the process;
- the activity is finished and destroyed;
- there are no crash markers and no crash dialog;
- stdout and stderr equal the Mac run, which exits 70.

**Shutdown.** The spec shuts the emulator down and checks that no emulator
process for the AVD remains. An EXIT trap does the same on failure or
interrupt.

Negative controls:
- the comparison sees a real difference between platforms: the Mac's
  `derive_key ok` against Android's `crypto_kdf_unavailable`;
- a wrong expected digest fails;
- linked without `--wrap=exit`, the same runtime error kills the process. No
  end is logged, the activity is not finished, and the tool fails.

### `specs/android_ui_host_spec.sh`

The Hey side of the View shims, on the Mac, with no emulator.
- `hey native` generates the `hey_android_ui` descriptor from
  `native/ui/hey.native.json`: five functions.
- `specs/support/fake_ui.c` implements the shims with no Android and plays a
  scripted list of events. It is built as `libhey_app.so`, the name the program
  opens.
- `examples/rows.hey` and `examples/rows_error.hey` build through the LLVM lane
  and pass the Android IR check.

It checks that:
- `rows` draws 5 rows on start, redraws with "Row 3 was tapped" after a tap on
  `row-3`, and ends with status 0 on destroy;
- the shims received that second description;
- `rows_error` stops with status 70 on the tap, with the runtime's message.

Negative controls:
- a tap on the status row changes nothing, and the output comparison sees it;
- with no library to open, `rows` stops with status 70;
- without a tap, `rows_error` ends with status 0.

### `specs/android_ui_emulator_spec.sh`

The View shims on the API 36 emulator. The spec reads the screen three ways:
a raw `screencap` for pixels, uiautomator's View tree for text and bounds, and
logcat. `specs/support/screen.rb` reads the first two. With
`HEY_ANDROID_UI_EVIDENCE=DIR` it keeps the screenshots.

It checks that:
- **Views drew.** `rows` commits 5 views, read back through JNI. The
  rectangle of the 'Row 3' View is at least 70% row blue, and the status row
  is at least 70% amber.
- **A tap changes the screen.** A tap injected with `adb shell input tap` at
  the centre of row 3 is hit-tested to `row-3`. The Hey program logs
  `rows: tapped row-3, showing: Row 3 was tapped`, the View tree shows
  'Row 3 was tapped', and the status row's pixels change.
- **Rotation.** After `cmd window user-rotation lock 1`, and once the display
  reports orientation 1, the screen is landscape, the same program
  still draws with its state kept, a tap lands on row 1 against the rotated
  layout, and the program was not restarted.
- **A second launch.** After `force-stop`, `am start` gives a new process whose
  fresh program draws 'Tap a row' again.
- **A runtime error in the loop.** `rows_error` fails on a tap; the message
  is in logcat, exit(70) finishes the activity, it is destroyed and the process
  ends, with no crash marker or dialog.
- **No dex.** The rows APK has `hasCode="false"`, no dex, and a 16 KB aligned
  library, and the package has no Java or Kotlin source.

Negative controls:
- **surface taken:** built with NativeActivity still holding the surface, the
  same Views are in uiautomator's tree, but less than 5% of 'Row 3' is blue;
- a tap below the rows is hit-tested to no row, and no status pixel changes;
- the orientation check sees that the screen was portrait before rotation;
- `rows_error` linked without `--wrap=exit` kills the process: no end of
  program is logged and no activity is finished;
- the rows APK with a `classes.dex` added is refused;
- the Java/Kotlin source search finds a planted `Listener.java`.

It sets the rotation back and shuts the emulator down, including on failure.

### `specs/api_renderer_host_spec.sh`

The api_screens renderer on the Mac, with JDK 17 and no emulator.

It checks that:
- `renderer/java` and `renderer/host` compile with no `android.jar`;
- `specs/conformance/hey_mobile` is hey_mobile's `conformance/` byte for byte,
  when `HEY_MOBILE_ROOT` (default `~/dev/hey_mobile`) is present;
- every vector passes: `values.json` (117: render, line, text, when, truthy,
  value, param, path, known), `names.json` (every icon name and file kind maps to
  the same SF Symbol and Apple types, and to a Material Symbol and MIME types;
  an unknown name draws the default glyph), `descriptions.json` (21 bodies taken
  or refused), plus the sound body carried to android level 1 (taken), android
  level 2 and ios (refused), and the fixture description taken with its ETag;
- the renderer's own rules (`ModelMain`): unknown and undrawn kinds are not
  drawn and running them sends nothing; a known button beside them sends one
  request with its path and body filled; sign-out confirms, revokes and signs
  out; forms hide the button when a required field is not drawn; complete bundled definitions survive without replacement or merging;
- `renderer/api-renderer.json` and the Java constants agree;
- the renderer names no product or route;
- `tools/hey-android-api-app.sh` builds the fixture APK: one `classes.dex`,
  target 36, INTERNET, cleartext on for 10.0.2.2, backup off, 16 KB aligned and
  signed, the description baked byte for byte.

Negative controls:
- `Values.java` with an `android.util.Log` import does not compile;
- a vector file with one byte added is seen to differ;
- **eleven mutations**, each a deliberately broken copy of the renderer that
  must fail: an empty placeholder kept, an unknown action kind known, a slash
  not encoded, the ETag not checked, the level not checked, an icon dropped
  (the vectors); an undrawn kind drawn, an action run without refusing, an
  unknown section's route asked, bundled screens removed, a request sent with a
  required field hidden (the rules). A mutation whose pattern no longer matches
  fails the spec;
- an `api-renderer.json` declaring level 2 does not match;
- the product search finds routes in the fixture;
- the tool refuses a description with platform ios, and an http origin to
  `example.com`.

**The release lane (item 9 of the spec).** A throwaway PKCS12 key is made for
the run. `--release --icon --aab` must produce an APK and a bundle signed by
that key's certificate (apksigner and `keytool -printcert -jarfile`), not
debuggable, version code 7, with the icon in five densities, the dex and the
baked description, validated by the pinned bundletool; the password must be in
no receipt or log, and no path of the build directory or home directory in the
APK or bundle. Controls: the password search finds a planted copy; resources
compiled from an absolute path carry it into `resources.pb` and the path search
finds it; a release to http, `--aab` without `--release`, a wrong password, a
missing Keychain item and a non-square icon are each refused for their own
reason, and the wrong-password run leaves no APK or bundle. The prompt rules
have three mutation controls: prompts skipped, the required check removed, and
a field of an undrawn kind drawn.

### `specs/api_renderer_emulator_spec.sh`

The renderer on the API 36 emulator against `specs/support/fake_api_server.rb`
(which names no product and logs each request without its token), driven
through uiautomator's View tree by `specs/support/drive.rb`. With
`HEY_ANDROID_API_EVIDENCE=DIR` it keeps the screenshots.

`drive.rb type` taps the field, then waits until the keyboard serves THAT field
(`dumpsys input_method`: the app's focused served view is
not a view the keyboard was already up for unless that is this field, and is the
editor the IME is bound to; the View tree confirms the
field has focus), not merely `mInputShown=true`, which a keyboard still up for
the previous field also reports. It then reads the field back; on a mismatch it
clears the field and types the whole intended text once more before failing.

It checks that:
- the bundled copy is drawn at cold launch and resume with no UI-definition request;
- sign-in draws Name and Passphrase, not the unknown camera field; an empty form
  says "Name is needed." and sends nothing; a wrong passphrase shows the
  server's refusal and keeps no session file;
- the kept session file does not hold the issued token or any 16 characters of
  it, and was sealed with a Keystore key;
- the list draws the server's rows and the known button and row, and never
  Teleport, Carousel, Portal, Beam or the search tab; no request ever reaches
  their routes;
- a row opens its screen with the bearer token, and system back returns;
- a kept session opens the list on the next launch, after the session check;
- sign-out asks first, revokes, removes the session file and shows sign-in;
- valid and corrupt legacy caches never replace bundled screens; offline launch draws the bundled UI; action reloads and sign-out send no UI-definition request;
- the crash buffer names no crash of the app.

Negative controls:
- a planted valid legacy cache has a different sign-in title and retains the obsolete served key;
- after the right passphrase the same listing finds the session file;
- the token search finds the token in the server's issued list;
- the tap on the known button beside the hidden ones is sent;
- nothing was revoked before the confirmation was answered;
- the online server and legacy cache contain a different title that never appears in the app.

It stops the server and shuts the emulator down, including on failure.

## Receipts

Every `tools/hey-android-app.sh` run writes `receipt.json` into `--out`. It
records:
- **Toolchain:** the Hey root, head, version and compiler identity; the SHA-256
  of the runtime and node-bundle sources and of the profile; the runtime cache
  key.
- **Build:** the NDK revision and clang version, the target, SDK levels and
  page size; the build isolation (variables cleared, variables that were set,
  the include search path); the library facts; the APK facts, including the
  signer's certificate SHA-256.
- **Run:**
  - the device's API, ABI and kernel page size;
  - whether it installed and launched;
  - how the program ended, and with what status;
  - whether the activity was finished and destroyed, and the process exited;
  - the number of crash markers;
  - the first 20 `hey.*` logcat lines;
  - with `--ui`: the number of screens committed, the views on screen after
    the last one, and the SHA-256 of the UI extension's manifest.

`tools/hey-android-api-app.sh` writes `receipt.json` too: the description's
SHA-256, level, platform, screens and drawn tabs; the origin and whether
cleartext is allowed; the APK, dex and signing facts; install and launch.

A debug APK run on an emulator is not Play evidence. Release signing, an AAB,
Play Console validation and store review are separate gates.

## Release verification

```sh
bin/release
unzip -tq "dist/hey_android-0.4.17.zip"
unzip -tq "dist/hey_android-registry-publication-0.4.17.zip"
cat dist/SHA256SUMS.txt
```

## Sharing and header image links (0.4.5)

`ModelMain` executes a remote, filtered chooser through the real action engine,
checks the recipient and trimmed note in the request body, and asserts that
the returned nested link is shared before reload. Controls cancel the chooser
and note, fail the request, and return absent, malformed and unsafe links.
Header model checks distinguish content and poster URLs and reject invalid
content targets.

The renderer emulator spec repeats the chooser and note cancellations, sends
a note that the fake server validates, checks Android's sheet displays the
returned item and set links, and confirms reload. An invalid response leaves
the app visible. It also taps the accessible header image and inspects the
launched content URL in a tiny test-only Activity that receives HTTP(S) VIEW
intents and displays their action and URI without network access; another item
with an invalid URL has no open target. The test temporarily assigns the
emulator browser role to this receiver, restores its previous holder and
uninstalls the receiver on exit. It never configures a real browser or accepts
browser terms.
The suite shuts down the emulator on every exit.

Lifecycle regression controls defer choices and request responses, invalidate
the action scope, and require no presentation, navigation or write. Emulator
cases navigate Back while a delayed friend list or share request is pending;
when the same picker is left on its page, it appears and remains cancellable.

For a focused rerun of the same positive and negative header-image checks:
`HEY_ANDROID_API_HEADER_ONLY=1 bash specs/api_renderer_emulator_spec.sh`.
This still builds, boots, signs in, tests the native URL handoff, restores the
browser role, removes the receiver and shuts down the emulator.

### Verification on 2026-10-15

Renderer host rules, shared conformance vectors, mutation controls, debug APK
and signed release APK/AAB gates passed. The full emulator run passed sharing,
notes, cancellations, reloads and delayed-response lifecycle checks. Its header
assertion originally depended on Chrome's first-run task state; the same header
check now uses a test-only intent receiver. The focused rerun passed both the
exact ACTION_VIEW content URL and the loaded invalid-URL inert-image control,
then restored the browser role and shut down the emulator.

`bin/check` completed with 135 passing checks, 67 passing negative controls and
11 failures: that replaced header harness assertion plus these ten failures in
the native Hey lane, the same runtime family already documented for 0.4.4:

- hello_runtime did not run cleanly;
- hello_runtime logcat output differed from the Mac;
- the 8 MiB program-thread stack marker was absent;
- the second hello_runtime launch did not repeat Mac output;
- SHA-256 emulator vectors did not pass;
- Android capability answers differed;
- runtime_error did not end cleanly;
- runtime_error output differed from the Mac;
- the surface-taken negative-control build did not commit a screen;
- rows did not commit a screen.

The native programs exit before their end markers with crash_markers=2. This
slice does not change that lane. No package release or publication was made
from the red full gate; the checked renderer source is available for the app
build. The full package gate was not repeated after the isolated harness fix.

The native hello emulator gate reproduced Android rejecting initial-exec TLS before any program output on 605a. The Android build now selects HEY_NO_FAST_TLS; the complete native gates verify that the unchanged runtime starts, produces the reference bytes and shuts down cleanly.

## Standard dictation (0.4.12)

`bash specs/api_renderer_dictation_spec.sh` builds the actual renderer and a
synthetic instrumentation APK on the pinned API 36 emulator. Its transcript
results exercise form and prompt selection replacement, suffix retention,
cancellation, denied launches, concurrent typing, distinct request identities
and stale dialog/page/account results. The test checks
the standard speech intent and never supplies real audio. This proves renderer
behavior; microphone recognition and the user's recognizer availability remain
device/OS dependent. `HEY_ANDROID_DICTATION_EVIDENCE=DIR` retains device logs.

The native chooser fixture also occupies the image worker deliberately. It
requires the existing two-second text fallback, then one explicit retry must
provide a real readable PNG with the same private-provider and URI-grant checks.
A cold emulator's first fallback is accepted only after that unchanged deadline;
it cannot replace the actual attachment requirement. Evidence mode retains the
fixture emulator's logcat for diagnosing failures.

## Real optimized releases (0.4.13)

`specs/api_renderer_r8_spec.sh` builds actual signed APK/AAB artifacts: unreachable fixture code is removed, internal classes rename, three manifest components remain, AAB mapping equals the private output, APK contains no mapping, and debug stays D8. Altering the optimizer pin or dropping mapping output must fail before signing.

`specs/api_renderer_r8_emulator_spec.sh` installs the actual optimized release APK without test keep rules or production re-dexing. It walks offline form/prose/dictation/search/navigation, provider/service startup and screenshots; a deliberately renamed manifest Activity entry point is refused by Android. Synthetic fixture data only. Set `HEY_ANDROID_R8_EVIDENCE` to an ignored directory to retain logs/proof; never put bulky outputs in coordination docs.

## 0.4.14: dynamic hierarchical choices

`specs/api_renderer_choice_tree_spec.sh` exercises the production pure model:
static/remote namespaces, expandable folders, public parents, private structural
ancestors, duplicate/cycle/orphan/depth limits, 4096 remote rows beside 1000
static options (one more of either is refused), template/list labels and the
value fallback, flat `where`, the bodyless read rule (absent or `{}` body, GET
in any case) and Android text input traits, including `username` of every kind.
Its control makes private ancestors selectable and must fail.
`specs/api_renderer_choice_tree_emulator_spec.sh` uses a read-only API36 instance
on port5586 with fresh disposable data. Its localhost fixture covers retry,
exact multiline drafts, cancellation, independent parent selection, private
ancestor disclosure, stale page/account scope, preserving username case, a
source default shown by its label before the picker has ever opened (the form
reads its choices as it loads) and surviving Cancel, the current choice marked
(check, selected, "Selected" state description), Back leaving draft and folder
unchanged, and focus and cursor kept through a failed and a late source redraw.
A double-tapped Retry must send one read: the fixture fails the first two reads
of a fresh `/choices-retry/` path, the second late, so a second read would draw
the tree and the older failure would land beneath it. Signed-out launch reads
of choices are refused (401); every read after sign-in must carry the session. A choices read to `/choices-late`, answered 0.9 s after the
page leaves with every label renamed, must change neither the loaded labels nor
the shown Folder label. Its mutation controls each copy the SDK, change one
thing, rebuild, reinstall fresh and run one scenario, which must fail for the
reason it checks: without the picker reply's `active` guard, `late` fails with
both the labels and the shown label changed; with a failed source redrawn by
`render()`, `focus` fails because the Message field loses focus; with Retry
neither numbered nor held while loading, `retry` fails because a stale failure
lands beneath the tree.
Before the instrumentation runs, the spec waits until the device itself reaches
the fixture server (`nc` to `/ready`), since a freshly booted emulator can
reach the host late, and the fixture reloads the form source under the
synthetic account rather than racing the signed-out launch read.
`HEY_ANDROID_CHOICES_SCENARIO=static` runs the oversized static options (1001
entries, then one 4097-character title) alone; `late`, `focus` and `retry` run
the late reply, the failed source and the double-tapped Retry alone.
Set `HEY_ANDROID_CHOICES_EVIDENCE=DIR` to retain native frames and logs.
The fixture checks that opening/toggling/selecting never submits a write.

## 0.4.15: picture memory budget

`specs/picture_budget_host_spec.sh` proves the budget arithmetic and
bookkeeping on the host (24 checks). `specs/api_renderer_pictures_spec.sh`
runs the shipped renderer on a disposable API 36 AVD with synthetic pictures
(14 checks): a 20000 x 20000 PNG is refused without allocating its 1.6 GB and
remembered as barren; a photo arrives as 375 x 250 for a row and 1500 x 1000
for a header; ten rows share one fetch; a fling past 100 rows leaves 48
waiting with two workers; held bytes stay at the budget, oldest evicted first.
