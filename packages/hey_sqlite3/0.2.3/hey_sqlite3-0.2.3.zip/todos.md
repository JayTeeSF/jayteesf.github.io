# Todo

1. Vendor a checksum-pinned SQLite amalgamation with license/provenance metadata.
2. Produce Darwin arm64/x64 and Windows x64 native receipts.
3. Add backup, incremental blob, and connection-pool/partitioned-Job helpers.
4. Add migration integration receipts with `hey_record`.
