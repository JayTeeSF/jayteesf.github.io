#!/usr/bin/env bash
# The Android 16 (API 36) arm64 emulator, headless: the example apps built by
# tools/hey-android-app.sh, installed and launched, checked against the Mac run
# and against known answers, with negative controls.
#
# THE EMULATOR IS ALWAYS SHUT DOWN, on success, on failure and on interrupt, and
# the spec fails if an emulator process for the AVD is left behind.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
export HEY_ROOT
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-emulator-spec.XXXXXX")
serial=''
pass() { echo "PASS: $*"; }
control() { echo "PASS (control): $*"; }
bad() { echo "FAIL: $*"; failed=1; }
field() { /usr/bin/python3 -c 'import json,sys
v = json.load(open(sys.argv[1]))
for k in sys.argv[2].split("."): v = v[k] if isinstance(v, dict) else None
print(v if isinstance(v, str) else json.dumps(v))' "$1" "$2"; }
bytes() { wc -c < "$1" | tr -d ' '; }
lines() { grep -c '' "$1"; }

stop_emulator() {
  if [ -n "$serial" ]; then
    if "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" > "$work/shutdown.log" 2>&1; then
      serial=''
    else
      cat "$work/shutdown.log"
    fi
  fi
  if pgrep -f "qemu-system.*-avd $HEY_ANDROID_AVD( |$)" > /dev/null 2>&1; then
    bad "an emulator process for $HEY_ANDROID_AVD is still running after shutdown"
    return 1
  fi
  return 0
}
on_exit() {
  status=$?
  [ -n "$serial" ] && { stop_emulator || status=1; }
  rm -rf "$work"
  exit "$status"
}
trap on_exit EXIT
trap 'exit 130' INT TERM

# ---- Mac references: the same IR, linked for the Mac by heyc --------------------------------
# The Mac binary runs with no Hey toolchain in its environment, as on the phone. A
# stdlib call the LLVM lane delegates to the toolchain at run time (Files.write_text
# is one) works on a Mac with HEY_ROOT set and fails on a phone; running the Mac
# reference without HEY_ROOT makes the two runs comparable, and makes the Mac show
# such a delegation before the emulator does.
mac_run() { # NAME
  dir=$work/mac/$1
  mkdir -p "$dir/run"
  # shellcheck disable=SC2086 # the lock prefix is a command and its arguments
  ${HEY_HEYC_LOCK:-} "$HEY_ROOT/bin/heyc" build --emit-llvm-ir "$ROOT/examples/$1.hey" -o "$dir/app.ll" > "$dir/heyc.log" 2>&1 &&
  ${HEY_HEYC_LOCK:-} "$HEY_ROOT/bin/heyc" link-ll "$dir/app.ll" -o "$dir/app" >> "$dir/heyc.log" 2>&1 || return 1
  (cd "$dir/run" && env -u HEY_ROOT -u HEY_STDLIB_HEYC -u HEY_STDLIB_PATH -u HEY_PACKAGE_PATH "$dir/app" > "$dir/stdout.txt" 2> "$dir/stderr.txt"; echo $? > "$dir/status.txt")
}
for name in hello_runtime sha256_vectors platform_capabilities runtime_error; do
  mac_run "$name" || { bad "the Mac reference for $name did not build: $(tail -3 "$work/mac/$name/heyc.log")"; exit 1; }
done
pass "Mac references built from the same IR with heyc link-ll and run with no Hey toolchain in the environment: hello_runtime, sha256_vectors, platform_capabilities, runtime_error"

# ---- the emulator ------------------------------------------------------------------------------
"$ROOT/tools/hey-android-emulator.sh" create-avd > "$work/avd.log" 2>&1 || { bad "could not create the AVD: $(cat "$work/avd.log")"; exit 1; }
if ! boot_line=$("$ROOT/tools/hey-android-emulator.sh" boot 2> "$work/boot.err"); then
  bad "the emulator did not boot: $(tail -5 "$work/boot.err")"
  exit 1
fi
serial=$(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^serial=//p')
pass "booted AVD $HEY_ANDROID_AVD ('$HEY_ANDROID_AVD_DISPLAY', $HEY_ANDROID_SYSTEM_IMAGE) headless as $serial in $(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^boot_seconds=//p') s"

android_run() { # NAME PACKAGE_ID [VAR=VALUE...]
  name=$1
  package=$2
  shift 2
  env "$@" "$ROOT/tools/hey-android-app.sh" --source "$ROOT/examples/$name.hey" --out "$work/android/$name${suffix:-}" \
    --package-id "$package" --label "Hey $name" --device "$serial" --launch > "$work/$name${suffix:-}.log" 2>&1
}
clean_run() { # NAME: the receipt says installed, launched, ended, finished, destroyed, exited, no crash
  r=$work/android/$1/receipt.json
  [ "$(field "$r" result)" = ok ] && [ "$(field "$r" installed)" = true ] && [ "$(field "$r" launched)" = true ] &&
  [ "$(field "$r" activity_finished)" = true ] && [ "$(field "$r" activity_destroyed)" = true ] &&
  [ "$(field "$r" process_exited)" = true ] && [ "$(field "$r" crash_markers)" = 0 ] &&
  [ "$(field "$r" device.api)" = "$HEY_ANDROID_TARGET_SDK" ] && [ "$(field "$r" device.abi)" = "$HEY_ANDROID_ABI" ]
}

# hello_runtime: byte for byte against the Mac
if android_run hello_runtime com.jayteesf.hey.hello && clean_run hello_runtime; then
  r=$work/android/hello_runtime/receipt.json
  pass "hello_runtime installs and runs on API $(field "$r" device.api) $(field "$r" device.abi): program $(field "$r" program.ended) status $(field "$r" program.status), activity finished and destroyed, process exited, 0 crash markers"
else
  bad "hello_runtime did not run cleanly: $(tail -8 "$work/hello_runtime.log")"
fi
out=$work/android/hello_runtime/stdout.txt
if [ -s "$out" ] && cmp -s "$out" "$work/mac/hello_runtime/stdout.txt"; then
  pass "hello_runtime's logcat output equals the Mac run byte for byte ($(lines "$out") lines, $(bytes "$out") bytes, sha256 $(hey_android_sha256 "$out" | cut -c1-16))"
else
  bad "hello_runtime's logcat output differs from the Mac run:"
  diff "$work/mac/hello_runtime/stdout.txt" "$out" | sed -n 1,10p | sed 's/^/  /'
fi
[ ! -s "$work/android/hello_runtime/stderr.txt" ] && [ ! -s "$work/mac/hello_runtime/stderr.txt" ] &&
  pass 'hello_runtime wrote nothing to stderr on either platform' || bad 'hello_runtime wrote to stderr'
if grep -q 'hey program thread stack is 84[0-9]\{5\} bytes' "$work/android/hello_runtime/logcat-hey.txt"; then
  pass "the Hey program thread runs with an 8 MiB stack ($(sed -n 's/.*hey program thread stack is \([0-9]*\) bytes.*/\1/p' "$work/android/hello_runtime/logcat-hey.txt") bytes, from pthread_getattr_np)"
else
  bad 'the program thread stack size was not logged as 8 MiB'
fi

# The same app launched again: a fresh process and runtime, the same output.
"$HEY_ANDROID_ADB" -s "$serial" logcat -c
"$HEY_ANDROID_ADB" -s "$serial" shell am start -W -n com.jayteesf.hey.hello/android.app.NativeActivity > "$work/relaunch.txt" 2>&1
for _ in $(seq 1 60); do
  "$HEY_ANDROID_ADB" -s "$serial" logcat -d -v tag -s 'hey.app:*' 2>/dev/null | grep -q 'activity destroyed' && break
  /bin/sleep 1
done
"$HEY_ANDROID_ADB" -s "$serial" logcat -d -v tag -s 'hey.out:*' 2>/dev/null | sed -n -e 's/^I\/hey\.out *: //p' > "$work/relaunch-stdout.txt"
if cmp -s "$work/relaunch-stdout.txt" "$work/mac/hello_runtime/stdout.txt"; then
  pass 'launched a second time, hello_runtime starts a fresh Hey runtime and prints the same bytes again'
else
  bad 'the second launch of hello_runtime did not print the Mac output again'
fi

# control for the byte comparison: a real difference between the platforms is seen
if cmp -s "$work/mac/platform_capabilities/stdout.txt" "$ROOT/specs/platform_capabilities.android.txt"; then
  bad '(control) the Mac and Android capability answers compared equal, so the comparison cannot see a difference'
else
  control "the comparison sees a real platform difference: the Mac's '$(sed -n 5p "$work/mac/platform_capabilities/stdout.txt")' against Android's '$(sed -n 5p "$ROOT/specs/platform_capabilities.android.txt")'"
fi

# sha256_vectors: NIST answers through the runtime, as text and as files
expected=$work/sha256_expected.txt
while read -r name digest; do
  case "$name" in ''|\#*) continue ;; esac
  printf 'text %s %s\nfile %s %s\n' "$name" "$digest" "$name" "$digest"
done < "$ROOT/specs/sha256_vectors.txt" > "$expected"
if android_run sha256_vectors com.jayteesf.hey.sha256 && clean_run sha256_vectors &&
   cmp -s "$work/android/sha256_vectors/stdout.txt" "$expected"; then
  pass "all $(grep -cvE '^(#|$)' "$ROOT/specs/sha256_vectors.txt") NIST SHA-256 vectors pass through the Hey runtime on the emulator, as text (the runtime's SHA-256) and as files (the vendored SHA-256 through the profile): $(lines "$expected") digests"
else
  bad 'the SHA-256 vectors did not pass on the emulator:'
  diff "$expected" "$work/android/sha256_vectors/stdout.txt" 2>&1 | sed -n 1,10p | sed 's/^/  /'
fi
cmp -s "$work/mac/sha256_vectors/stdout.txt" "$expected" && pass 'the same vectors pass on the Mac' || bad 'the vectors do not pass on the Mac'
sed 's/^\(text abc ba7816bf\)/\1X/' "$expected" | sed 's/ba7816bfX/ba7816bE/' > "$work/sha256_wrong.txt"
if cmp -s "$work/android/sha256_vectors/stdout.txt" "$work/sha256_wrong.txt"; then
  bad '(control) a wrong expected digest compared equal'
else
  control "a wrong digest fails: $(diff "$work/sha256_wrong.txt" "$work/android/sha256_vectors/stdout.txt" | grep '^<' | sed -n 1p)"
fi

# platform_capabilities: real random and compare; named errors for what Android lacks
if android_run platform_capabilities com.jayteesf.hey.capabilities && clean_run platform_capabilities &&
   cmp -s "$work/android/platform_capabilities/stdout.txt" "$ROOT/specs/platform_capabilities.android.txt"; then
  pass "secure random (32 bytes) and constant-time compare (true, false) work on Android; scrypt and Argon2id answer crypto_kdf_unavailable and AES-256-GCM answers crypto_aead_unavailable"
else
  bad 'the capability answers on Android are not the expected ones:'
  diff "$ROOT/specs/platform_capabilities.android.txt" "$work/android/platform_capabilities/stdout.txt" 2>&1 | sed -n 1,10p | sed 's/^/  /'
fi

# runtime_error: the error in logcat, the activity finished, no crash
if android_run runtime_error com.jayteesf.hey.error && clean_run runtime_error; then
  r=$work/android/runtime_error/receipt.json
  if [ "$(field "$r" program.ended)" = exited ] && [ "$(field "$r" program.status)" = 70 ]; then
    pass "runtime_error: the runtime's exit(70) ended the program, not the process: activity finished and destroyed, 0 crash markers, no crash dialog"
  else
    bad "runtime_error ended as '$(field "$r" program.ended)' with status $(field "$r" program.status)"
  fi
else
  bad "runtime_error did not end cleanly: $(tail -8 "$work/runtime_error.log")"
fi
if cmp -s "$work/android/runtime_error/stdout.txt" "$work/mac/runtime_error/stdout.txt" &&
   cmp -s "$work/android/runtime_error/stderr.txt" "$work/mac/runtime_error/stderr.txt" &&
   [ "$(cat "$work/mac/runtime_error/status.txt")" = 70 ] &&
   grep -q 'hey error: the sample stops here on purpose' "$work/android/runtime_error/stderr.txt" &&
   ! grep -q 'after the error' "$work/android/runtime_error/stdout.txt"; then
  pass "runtime_error's stdout and stderr in logcat equal the Mac run, which exits 70: '$(cat "$work/android/runtime_error/stderr.txt")'"
else
  bad 'runtime_error output differs from the Mac run'
fi

# control: without --wrap=exit the same program kills its process, and the tool says so
suffix=-unwrapped
if android_run runtime_error com.jayteesf.hey.error HEY_ANDROID_NEGATIVE_CONTROL=unwrapped-exit; then
  bad '(control) the unwrapped-exit build was reported as a clean run'
else
  r=$work/android/runtime_error-unwrapped/receipt.json
  if [ "$(field "$r" negative_control)" = unwrapped-exit ] && [ "$(field "$r" activity_finished)" = false ] && [ "$(field "$r" program.ended)" = null ]; then
    control "linked without --wrap=exit, exit(70) kills the process: no end of program logged, activity not finished, and the tool fails ($(field "$r" failure))"
  else
    bad "(control) the unwrapped-exit build failed, but not in the expected way: $(field "$r" failure)"
  fi
fi
suffix=''

# ---- shut down ---------------------------------------------------------------------------------
if stop_emulator; then
  pass "the emulator was shut down and no emulator process for $HEY_ANDROID_AVD remains"
fi
exit $failed
