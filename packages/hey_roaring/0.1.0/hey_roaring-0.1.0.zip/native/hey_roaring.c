// Thin ABI boundary over the pinned CRoaring amalgamation (vendor/croaring). Values cross
// as little-endian uint32 arrays; serialization is CRoaring's portable format, so files
// interoperate with every Roaring implementation that reads it.
#include "hey_native_abi.h"
#include "roaring.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define HEY_ROARING_MAX_PAGE 1048576u

static void release_bytes(void *ctx, uint8_t *p, size_t n) { (void)ctx; (void)n; free(p); }
static roaring_bitmap_t *bitmap_of(HeyNativeHandle h) { return (roaring_bitmap_t *)(uintptr_t)h; }
static HeyNativeHandle handle_of(roaring_bitmap_t *b) { return (HeyNativeHandle)(uintptr_t)b; }
static uint32_t read_u32(const uint8_t *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static void write_u32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }

HeyNativeHandle hey_roaring_new(void) { return handle_of(roaring_bitmap_create()); }

int32_t hey_roaring_free(HeyNativeHandle h) {
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b) return 1;
  roaring_bitmap_free(b);
  return 0;
}

int32_t hey_roaring_add(HeyNativeHandle h, uint32_t value) {
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b) return 1;
  roaring_bitmap_add(b, value);
  return 0;
}

int32_t hey_roaring_add_many(HeyNativeHandle h, HeyNativeBytesView values) {
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b || values.length % 4 != 0) return 1;
  roaring_bulk_context_t context = {0};
  for (size_t i = 0; i < values.length; i += 4) roaring_bitmap_add_bulk(b, &context, read_u32(values.data + i));
  return 0;
}

// Adds [first, end); end may be 2^32 to include UINT32_MAX.
int32_t hey_roaring_add_range(HeyNativeHandle h, uint64_t first, uint64_t end) {
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b || first > end || end > UINT64_C(4294967296)) return 1;
  roaring_bitmap_add_range(b, first, end);
  return 0;
}

int32_t hey_roaring_remove(HeyNativeHandle h, uint32_t value) {
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b) return 1;
  roaring_bitmap_remove(b, value);
  return 0;
}

int32_t hey_roaring_contains(HeyNativeHandle h, uint32_t value) {
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b) return -1;
  return roaring_bitmap_contains(b, value) ? 1 : 0;
}

uint64_t hey_roaring_cardinality(HeyNativeHandle h) {
  roaring_bitmap_t *b = bitmap_of(h);
  return b ? roaring_bitmap_get_cardinality(b) : 0;
}

HeyNativeHandle hey_roaring_union(HeyNativeHandle l, HeyNativeHandle r) {
  if (!bitmap_of(l) || !bitmap_of(r)) return 0;
  return handle_of(roaring_bitmap_or(bitmap_of(l), bitmap_of(r)));
}

HeyNativeHandle hey_roaring_intersection(HeyNativeHandle l, HeyNativeHandle r) {
  if (!bitmap_of(l) || !bitmap_of(r)) return 0;
  return handle_of(roaring_bitmap_and(bitmap_of(l), bitmap_of(r)));
}

uint64_t hey_roaring_intersection_cardinality(HeyNativeHandle l, HeyNativeHandle r) {
  if (!bitmap_of(l) || !bitmap_of(r)) return 0;
  return roaring_bitmap_and_cardinality(bitmap_of(l), bitmap_of(r));
}

int32_t hey_roaring_optimize(HeyNativeHandle h) {
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b) return -1;
  roaring_bitmap_run_optimize(b);
  roaring_bitmap_shrink_to_fit(b);
  return 0;
}

HeyNativeOwnedBytes hey_roaring_serialize(HeyNativeHandle h, uint64_t max_bytes) {
  HeyNativeOwnedBytes none = {0};
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b) return none;
  size_t size = roaring_bitmap_portable_size_in_bytes(b);
  if (size > max_bytes) return none;
  uint8_t *data = malloc(size ? size : 1);
  if (!data) return none;
  if (roaring_bitmap_portable_serialize(b, (char *)data) != size) { free(data); return none; }
  return (HeyNativeOwnedBytes){data, size, release_bytes, NULL};
}

// Untrusted input: bounded safe parse, exact-length consumption and structural validation.
HeyNativeHandle hey_roaring_deserialize(HeyNativeBytesView data) {
  if (!data.length) return 0;
  size_t used = roaring_bitmap_portable_deserialize_size((const char *)data.data, data.length);
  if (used != data.length) return 0;
  roaring_bitmap_t *b = roaring_bitmap_portable_deserialize_safe((const char *)data.data, data.length);
  if (!b) return 0;
  const char *reason = NULL;
  if (!roaring_bitmap_internal_validate(b, &reason)) { roaring_bitmap_free(b); return 0; }
  return handle_of(b);
}

// Values in ascending order from rank `offset`, at most `limit`, as little-endian uint32.
HeyNativeOwnedBytes hey_roaring_values(HeyNativeHandle h, uint64_t offset, uint32_t limit) {
  HeyNativeOwnedBytes none = {0};
  roaring_bitmap_t *b = bitmap_of(h);
  if (!b || limit > HEY_ROARING_MAX_PAGE) return none;
  uint64_t total = roaring_bitmap_get_cardinality(b);
  uint64_t count = offset >= total ? 0 : total - offset;
  if (count > limit) count = limit;
  uint8_t *data = malloc(count ? count * 4 : 1);
  uint32_t *values = malloc(count ? count * sizeof(uint32_t) : 1);
  if (!data || !values) { free(data); free(values); return none; }
  if (count && !roaring_bitmap_range_uint32_array(b, (size_t)offset, (size_t)count, values)) { free(data); free(values); return none; }
  for (uint64_t i = 0; i < count; i++) write_u32(data + i * 4, values[i]);
  free(values);
  return (HeyNativeOwnedBytes){data, (size_t)(count * 4), release_bytes, NULL};
}
