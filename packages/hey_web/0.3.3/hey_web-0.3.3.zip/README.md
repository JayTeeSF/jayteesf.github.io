# hey_web

`hey_web` is the application layer above Hey's current `stdlib:Web`, `stdlib:Http`, `stdlib:Net`, `stdlib:Ehy`, and Jobs runtime. (The version lives in `VERSION` / `HeyWebConfig.version()`; this file deliberately does not repeat it.)

It does **not** reimplement HTTP parsing, sockets, TLS, route dispatch, or the package manager. It adds the conveniences normally supplied by tools such as curl and Puma plus a small Rails-shaped application structure, and -- since the 0.2.x line -- a documented **fast lane** of modules extracted whole from a production app (RecallCoach) for serving on `stdlib:Web` directly:

| Rails/Ruby concept | Hey equivalent |
|---|---|
| `config/puma.rb` | `config/hey_web.json` plus `HeyWebServer` |
| `config/routes.rb` | `HeyWebRouter` route declarations in Hey source |
| controller classes | modules with request functions |
| ERB views/layouts | EHY through `HeyWebView` |
| JSON actions | `Web.json`, `Web.created`, and `HeyWebController.from_result` |
| Active Job | Hey `job`/`Jobs.define` plus `HeyWebJobs` |
| Active Record / Sequel | sibling `hey_record`, `hey_sqlite3`, and `hey_mysql` packages |

Routes remain Hey source because handlers are first-class compiled callables. JSON configuration controls the serve options and nothing else: `host`, `port`, `workers`, `request_timeout_ms`, `max_body_bytes` (plus `max_requests` for one-shot receipts). There is no middleware surface -- see "One serving lane" below for what was removed and why.

## curl-style client

```sh
bin/hey-web https://example.com/
bin/hey-web -H 'accept: application/json' https://example.com/items
bin/hey-web --json '{"name":"Ada"}' https://example.com/items
bin/hey-web -X PATCH --json '{"name":"Grace"}' https://example.com/items/1
bin/hey-web -o artifact.zip https://example.com/artifact.zip
```

The client delegates URL parsing, HTTP/HTTPS, redirects, TLS validation, bounded reads, and byte-preserving downloads to `stdlib:Http`. It adds CLI parsing, JSON bodies, status checking, presentation, and output-file behavior.

## Puma-style application server

```hey
import 'pkg:hey_web@<version>/main'
import 'stdlib:Web'
import 'stdlib:Cli'

module HealthController
  fn show(request)
    return Web.json({ok: true, service: 'cards'})
  end
end

program
  let config = HeyWebServer.options(Cli.args(), HeyWebConfig.load_or_default('config/hey_web.json'))
  let routes = [Web.get('/health', HealthController.show)]
  let app = HeyWeb.application('cards', routes, config)
  says HeyWebServer.banner(app)
  let running = HeyWeb.serve(app)
end
```

The default is `workers: 4` (the RecallCoach production value; correct since v0.99.399a fixed dispatch-path cloning -- docs/PERFORMANCE.md). `workers: 0` selects Hey's automatic online-CPU count. Slow, retryable, or durable work belongs in Jobs rather than request workers.

## One serving lane

hey_web serves ONE way (maintainer ruling, 2026-07-30): exactly the
RecallCoach production pattern -- a flat route table handed straight to
`stdlib:Web`'s native serve, with NOTHING layered on the request path:

```hey
Web.serve(routes, {host: host, port: port, workers: 4, request_timeout_ms: 15000, max_body_bytes: 1048576})
```

`HeyWebServer.serve(app)` is precisely that call over
`app.routes`/`app.config`. RecallCoach serves its production traffic
this way (itself the fleet-proven elders_prayer_app pattern: measured
62-69K req/s on `/health`, p50 ~57us, stdlib lane), and the handlers
are built from the fast-lane modules below.

### Removed in 0.3.0 (breaking), and what replaces each call

The 0.1.x-0.2.x middleware serving lane reached `Web.service` +
`Web.start`. In a compiled binary `Web.service` is JSON-delegated to
the stdlib sidecar (trunk `runtime/heyc.c` `facades[]`), so the
listener and worker pool were created IN the sidecar -- which owned the
LISTEN socket and had never seen the routes. Every request produced a
well-formed EMPTY 200 (500s at 0.99.474a) and no registered handler
ever ran; the only benchmark ever built on that lane was retracted in
full on 2026-07-28 because of it. A serving API that silently stops
serving when compiled is not an API, so the lane is DELETED, not
documented around:

| removed public surface | replacement |
|---|---|
| `HeyWebServer.service(application)` | none -- deleted outright. `HeyWebServer.serve` (native `Web.serve`) is the lane. |
| `HeyWebServer.middleware(config)` + the config `middleware` list | handler-level fast-lane modules (rows below). |
| middleware `secure_headers` | `HeyWebResponses` builders (the same headers inlined in every response). |
| middleware `log_requests` | `HeyWebRequestLog.config_with` + `wrap` in the router's logged wrappers. |
| middleware `request_id` | the `request_id` field of every `HeyWebRequestLog.line`. |
| middleware `max_body` | the `max_body_bytes` serve option (enforced by the runtime server). |
| middleware `require_json` | `HeyWebResponses.body_json` + the handler's own validation. |
| middleware `recover_errors` | none -- fail-fast; receipts assert `hey error:`-free server logs instead of masking throws. |
| `application.stack` record key | `application.routes` (the flat table; `Web.serve`/`Web.dispatch` take it directly). |
| config keys `backlog`, `read_timeout_ms`, `write_timeout_ms`, `idle_timeout_ms` | `request_timeout_ms` -- the timeout `Web.serve` honors. |
| `HeyWeb.dispatch(app, request)` over the stack | same signature, now pure dispatch over `app.routes`. |

Honest performance note: the deleted lane was never validly benchmarked
against stdlib serving (the one comparison was the retraction above),
and the ~7 ms per-pure-Hey-call delegation figure the fast lane's
builtin-only discipline was tuned around dates to hey 0.99.390a (the
0.99.402a sidecar cut stdlib-call cost to ~60-80 us). The claim here is
NOT "measured faster": it is that this is the production-proven shape,
and a like-for-like number is still owed -- see RecallCoach
docs/framework-extraction.md section 7, whose G1 slice is that
measurement.

### Fast-lane modules

The supporting cast around the one lane. `main.hey` imports all five;
import them individually when you want the minimal surface:

| module | import | what it owns |
|---|---|---|
| `HeyWebListen` | `pkg:hey_web@<version>/listen` | HOST/PORT resolution: digits-only PORT parse (no silent 0), loud failure |
| `HeyWebOrigin` | `pkg:hey_web@<version>/origin` | public-origin policy: one reader, derived defaults, wildcard-bind refusal, loopback port-drift refusal, require-public posture |
| `HeyWebRequest` | `pkg:hey_web@<version>/request_support` | raw query parse (live runtime hands a raw string), never-nil param/header access, rightmost-trusted-hop `remote_ip` |
| `HeyWebRequestLog` | `pkg:hey_web@<version>/request_log` | one JSON line per request: allowlist-only header capture, authorization/cookie/set-cookie unloggable even when named, quiet poll routes |
| `HeyWebResponses` | `pkg:hey_web@<version>/responses` | builtin-only JSON/error/redirect builders with security headers inlined |

Shared discipline, learned the hard way in the source app: no nil ever
crosses these public surfaces (missing param/header answers `''`);
every env read is `Env.default` (bare `Env.get` does not lower
compiled); text scanning uses bare `index_of`/`slice` builtins
(`Text.index_of`/`Text.slice` do not lower); and `bin/check` holds a
COMPILED receipt (`tools/compiled_receipt.hey`) whose stdout must be
byte-identical between the interpreter and a real binary.

Env names are prefix-parameterized (the hey_mysql `from_env_prefix`
pattern). RecallCoach's bindings are the documented reference: listen
reads bare `HOST`/`PORT` (prefix `''`, reference default port 3748);
origin/request/log take the app prefix (`'RECALL_COACH_'` there), e.g.
`HeyWebOrigin.base_url_with('ACME_', host, port)` reads
`ACME_BASE_URL` and `ACME_REQUIRE_PUBLIC_ORIGIN`, and
`HeyWebRequestLog.config_with('ACME_', '')` reads `ACME_ACCESS_LOG`,
`ACME_LOG_HEADERS`, `ACME_LOG_QUIET_ROUTES`, `ACME_TRUSTED_PROXIES`.

Trunk overlap, stated plainly: since 0.99.474a `stdlib:Web`'s
`log_requests` middleware emits a structured access-log line -- the
trunk lifted this module's reference implementation. hey_web has no
middleware stack to hang it on (removed with the broken lane), so
`HeyWebRequestLog` is the package's access log: the app-level shape
(allowlisted extra headers, quiet routes, per-route labels, an env
prefix) wrapped per-route.

## Pages embedding (`bin/pages-embed`)

Compile-time page embedding is the only zero-read-per-request page cache
`stdlib:Web` allows (handlers are resolved by name and cannot close over
boot-time state). Hand-maintaining the heredoc twin of every HTML asset
is how RecallCoach shipped a no-op edit (asset edited, heredoc served);
this generator makes the asset the only authored copy:

```sh
bin/pages-embed --pages-dir web/pages --out web/pages_generated.hey \
  --module Pages --bindings '{"app_name":"Demo"}'
```

- `*.html` assets embed verbatim; `*.html.ehy` assets render through
  stdlib Ehy at GENERATION time with `--bindings` (never at request
  time). The wrapper absolutizes the path flags and chdirs to
  `$HEY_ROOT` first, because stdlib Ehy shells out to `./bin/heyc`
  relative to the cwd (the EHY cwd quirk, tracked upstream).
- The generated module carries `NAME_page()` per asset, `names()`,
  `page(name)` (empty string for unknown names, never nil), and
  `assets_in_sync(dir)` -- the old byte-equality spec become a
  staleness check.
- THE SINGLE-QUOTE CONSTRAINT IS ENFORCED MECHANICALLY: an asset
  containing any `'` is refused with a message naming the file and
  offset, because a literal single quote deep inside a triple-quoted
  heredoc breaks `heyc build` while every interpreter lane stays green
  (RecallCoach core report heredoc-single-quote-deep-offset-selfc.md).
  CRLF assets are refused for the same byte-identity reason.
- Proof in `bin/check`: the interpreter round-trip
  (specs/pages_embed_spec.hey + tools/pages_roundtrip_driver.hey, port
  46511) and a COMPILED receipt (tools/pages_serve_receipt.hey, port
  46512) both assert served bytes == authored asset bytes.

## Resource controllers

```hey
let users_controller = {
  index: UsersController.index,
  show: UsersController.show,
  create: UsersController.create,
  update: UsersController.update,
  destroy: UsersController.destroy
}

let routes = HeyWebRouter.resources('/users', users_controller)
```

This emits index, show, create, PATCH update, PUT update, and delete routes.

## EHY views

```hey
module PagesController
  fn index(request)
    return HeyWebView.response(
      'views/pages/index.ehy',
      {title: 'Hey Web'},
      'views/layouts/application.ehy'
    )
  end
end
```

## Verify and release

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
bin/release
bin/source-zip
./bin/reproduce-prompt
```

See `docs/GETTING_STARTED.md`, `docs/ARCHITECTURE.md`, and `docs/ROADMAP.md`.

Performance: `HeyWebClient` pays a ~7 ms interpreter-delegation boundary per call on hey 0.99.390a, and `Web.serve` currently runs fastest with `workers: 1`. Measurements, the worker-count table, and a vendorable ~0.4 ms plain-HTTP transport (`examples/fast_transport.hey`) are in `docs/PERFORMANCE.md`.

## Live localhost receipt

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check-live-http
```

This starts a one-request `stdlib:Web` server and fetches its JSON endpoint through the `hey-web` client. Set `HEY_WEB_TEST_PORT` when port 39091 is unavailable.

### EHY syntax

EHY is Hey's ERB-style template format. Interpolate with `<%= expression %>`, execute control-flow statements with `<% ... %>`, and write template comments with `<%# ... %>`.

```ehy
<section>
  <h1><%= title %></h1>
  <% if signed_in %>
    <p>Welcome back, <%= name %>.</p>
  <% end %>
</section>
```

Mustache-style `{{ title }}` is not EHY and should not be used in `.ehy` Files.

## Standard package controls

This package uses `hey_packager` 0.1.2 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_web`.
