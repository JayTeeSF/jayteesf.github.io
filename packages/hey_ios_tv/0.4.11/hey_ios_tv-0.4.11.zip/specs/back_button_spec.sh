#!/usr/bin/env sh
# Pins the 0.4.6 back-button contract in tools/hey_native_tv_runtime.m:
# Menu is delivered to the scene funnel as 'back' WHEN AND ONLY WHEN the
# currently installed scene declares top-level "handles_back": true, and
# bubbles to tvOS (suspending the app) otherwise.
#
# The press path is Objective-C, not Hey, so the Hey spec harness cannot
# exercise it; like live_data_renderer_spec.sh this spec mechanically pins
# the load-bearing decisions instead. Each grep documents the field defect
# it guards against. The compile check at the bottom builds the file with
# -DHEY_SCENE_V2 -- the scene renderer where all of this lives -- because
# live_data_renderer_spec.sh compiles only the default (v1) path and the
# whole v2 renderer is behind that #if.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
RUNTIME="$ROOT/tools/hey_native_tv_runtime.m"

fail() { echo "back button spec: $1" >&2; exit 1; }

# 1. Menu must be handled at all. Before 0.4.6 the press-type table had no
#    Menu case, so the 'back' event existed only in specs: on hardware a
#    Menu press never reached the funnel and the RecallCoach demo was
#    inescapable until back was remapped onto other buttons (field defect,
#    2026-07-30).
grep -q 'UIPressTypeMenu' "$RUNTIME" || fail "Menu press never inspected: 'back' would exist only in specs again"

# 2. When delivered, Menu must arrive as the 'back' funnel button, the name
#    the scene contract and consuming apps already spec against.
grep -q 'fireRemoteButton:@"back"' "$RUNTIME" || fail "Menu does not deliver the 'back' funnel event"

# 3. Delivery must be conditional on the scene's own declaration. A renderer
#    that swallows EVERY Menu press makes Menu-at-root stop suspending the
#    app -- against tvOS convention and an App Store rejection risk.
grep -q 'handles_back' "$RUNTIME" || fail 'handles_back scene flag missing: Menu interception would be unconditional'
grep -q 'self.menuPressOwned = self.handlesBack' "$RUNTIME" || fail 'Menu ownership not gated on handles_back at press-down'

# 4. Menu must stay OUT of the unconditional press map: when the scene does
#    not declare handles_back, the press has to remain in the unhandled set
#    and be forwarded to super so tvOS still suspends the app.
grep -q 'case UIPressTypeMenu: return' "$RUNTIME" && fail 'Menu mapped unconditionally: every press would be swallowed'
grep -q 'super pressesBegan' "$RUNTIME" || fail 'unhandled presses no longer forwarded: Menu could never bubble to tvOS'

# 5. The flag must be re-evaluated on every scene install (renderScene),
#    because scene-mode polls replace the document every few seconds: a
#    server declares handles_back on inner screens and drops it at the
#    root/lobby, restoring Menu-suspends-at-root.
grep -q '\[self syncBackHandlingWithScene:scene\]' "$RUNTIME" || fail 'handles_back not re-evaluated on scene install'

# 6. One physical press must never be split between the funnel and the
#    system when a poll swaps the scene mid-press: the press-down decision
#    is remembered and reused for the matching ended/cancelled.
grep -q 'menuPressOwned' "$RUNTIME" || fail 'press-down ownership not remembered across began/ended'

# 7. The scene-v2 renderer has to actually build for the Apple TV SDK.
#    Interpreter-green is not compiled-green, and the v2 half of this file is
#    invisible to a compile without -DHEY_SCENE_V2.
if [ "$(uname -s)" = Darwin ] && xcrun --sdk appletvos --show-sdk-path >/dev/null 2>&1; then
  clang=$(xcrun --sdk appletvos --find clang)
  sdk=$(xcrun --sdk appletvos --show-sdk-path)
  "$clang" --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -DHEY_SCENE_V2 -fsyntax-only "$RUNTIME" || fail 'scene-v2 renderer does not compile for tvOS'
else
  echo 'back button spec: no tvOS SDK here, skipped the compile check'
fi

echo 'back button spec passed'
