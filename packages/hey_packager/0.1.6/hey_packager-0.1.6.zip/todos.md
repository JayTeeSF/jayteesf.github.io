# Todo

1. Add installed-package command discovery.
2. Add reproducible two-build comparison receipts.
3. Add optional signed attestations.
