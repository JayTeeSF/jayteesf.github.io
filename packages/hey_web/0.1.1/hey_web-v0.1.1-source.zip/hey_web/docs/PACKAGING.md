# Packaging and verification

`hey_web` delegates package integrity to the Hey toolchain. It does not carry a
second package manager, source-checksum format, release-record generator, or ZIP
implementation.

The release manifest uses the current object module map:

```json
"modules": {
  "client": "client.hey",
  "server": "server.hey"
}
```

The compiler currently resolves `pkg:hey_web@VERSION/client` to
`.hey/packages/hey_web/VERSION/client.hey`, so importable modules are intentionally
stored at the package root rather than under `src/`.

Verification lifecycle:

```sh
hey package verify .
hey package pack . --out dist
hey package install \
  --release dist/hey_web-0.1.1.release.json \
  --archive dist/hey_web-0.1.1.zip \
  --root build/consumer/.hey/packages \
  --lock build/consumer/hey.lock.json
hey package verify-install build/consumer/.hey/packages/hey_web/0.1.1
```

The installer verifies archive, manifest, and declared-content SHA-256 values,
then writes `.hey-package-install.json` and atomically updates the consumer lock.
The compiler verifies each imported module against both records.
