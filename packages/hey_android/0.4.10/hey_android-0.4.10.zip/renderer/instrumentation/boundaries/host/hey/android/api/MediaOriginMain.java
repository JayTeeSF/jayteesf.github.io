package hey.android.api;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Production Android boundary classes with deterministic framework and HTTP doubles. */
public final class MediaOriginMain {
  static int failed;
  static void check(boolean good, String name) {
    System.out.println((good ? "PASS: " : "FAIL: ") + name);
    if (!good) failed++;
  }
  static Map<String, Object> obj(String text) { return Json.dict(Json.parseOrNull(text.getBytes(StandardCharsets.UTF_8))); }
  static void await(java.util.function.BooleanSupplier ready) throws Exception {
    long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
    while (!ready.getAsBoolean() && System.nanoTime() < end) Thread.sleep(5);
    if (!ready.getAsBoolean()) throw new AssertionError("fixture did not finish");
  }
  static Screens.Track track(String address) {
    return Screens.track(obj("{\"id\":\"id\",\"title\":\"title\",\"audio_url\":\"url\"}"),
        Map.of("id", "a-track", "title", "Account A", "url", address), new LinkedHashMap<>());
  }
  static final List<Connection> requests = Collections.synchronizedList(new ArrayList<>());
  static volatile CountDownLatch held;
  static volatile int responseStatus = 200;
  static final class Connection extends HttpURLConnection {
    final int status;
    final String body;
    final CountDownLatch gate;
    boolean disconnected;
    Connection(URL url, int status, String body, CountDownLatch gate) {
      super(url); this.status = status; this.body = body; this.gate = gate;
    }
    @Override public int getResponseCode() throws IOException {
      if (getInstanceFollowRedirects()) throw new AssertionError("automatic credential redirects enabled");
      requests.add(this);
      if (gate != null) try { if (!gate.await(5, TimeUnit.SECONDS)) throw new IOException("test gate timed out"); }
      catch (InterruptedException e) { throw new IOException(e); }
      return status;
    }
    @Override public String getHeaderField(String key) {
      if (key.equalsIgnoreCase("location")) return "https://attacker.invalid/steal";
      if (!key.equalsIgnoreCase("content-range")) return null;
      String range = getRequestProperty("range");
      if (range == null) return null;
      return "bytes " + range.substring(6) + "/1000000";
    }
    @Override public InputStream getInputStream() { return new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)); }
    @Override public InputStream getErrorStream() { return getInputStream(); }
    @Override public OutputStream getOutputStream() { return new ByteArrayOutputStream(); }
    @Override public long getContentLengthLong() { return body.length(); }
    @Override public void connect() {}
    @Override public void disconnect() { disconnected = true; }
    @Override public boolean usingProxy() { return false; }
  }

  public static void main(String[] args) throws Exception {
    Thread.setDefaultUncaughtExceptionHandler((thread, error) -> { error.printStackTrace(); System.exit(1); });
    URL.setURLStreamHandlerFactory(protocol -> protocol.equals("https") || protocol.equals("http") ? new URLStreamHandler() {
      @Override protected URLConnection openConnection(URL url) {
        String who = requests.size() == 0 ? "A" : "B";
        return new Connection(url, responseStatus, "{\"account\":\"" + who + "\"}", held);
      }
    } : null);
    File root = new File(args[0]);
    Context context = new Context(root);
    AtomicInteger reports = new AtomicInteger();
    HeyAndroidPlayer player = new HeyAndroidPlayer(new HeyAndroidPlayer.Watcher() {
      public void changed() {}
      public void report(String id, int seconds, int page, boolean finished) { reports.incrementAndGet(); }
    }, 15);
    Map<String, String> secret = Map.of("authorization", "Bearer synthetic-A");
    String origin = "https://api.example.test";
    String[] foreign = {"https://api.example.test.attacker.invalid/audio", "https://api.example.test@attacker.invalid/audio",
        "https://user@api.example.test/audio", "http://api.example.test/audio", "https://api.example.test:444/audio",
        "https://api.example.test./audio", "https://api.example.test%2eattacker.invalid/audio", "https://other.test/audio"};
    for (String address : foreign) {
      player.play(track(address), secret, context, origin);
      check(MediaPlayer.last.source == null && MediaPlayer.last.headers.isEmpty(), "no bearer for " + address);
    }
    for (String address : new String[] {origin + "/audio", "https://API.EXAMPLE.TEST:443/audio"}) {
      player.play(track(address), secret, context, origin);
      check(MediaPlayer.last.source != null && MediaPlayer.last.headers == null, "same-origin media uses controlled transport: " + address);
    }
    check(Origins.same("http://api.example.test:80", "http://api.example.test/audio")
        && !Origins.same(origin + "/prefix", origin + "/prefix/audio")
        && !Origins.same("", origin) && !Origins.same(origin, "//api.example.test/audio")
        && !Origins.same(origin, "https://api.example.test:0/audio") && !Origins.same(origin, "https://api.example.test:99999/audio"),
        "default ports normalize; malformed or non-origin bases are refused");
    MediaPlayer previous = MediaPlayer.last;
    previous.prepared.ready(previous);
    player.discard();
    previous.prepared.ready(previous);
    previous.completed.ready(previous);
    Handler.drain();
    check(previous.released && player.track() == null && player.state() == HeyAndroidPlayer.State.IDLE && reports.get() == 0,
        "discard cancels timers and late media callbacks without reporting the previous account");

    for (int status : new int[] {301, 302, 303, 307, 308}) {
      Connection redirect = new Connection(new URL(origin + "/redirect"), status, "", null);
      HeyAndroidMediaSource source = new HeyAndroidMediaSource(origin + "/redirect", secret, url -> redirect);
      boolean refused = false;
      try { source.readAt(0, new byte[8], 0, 8); } catch (IOException expected) { refused = true; }
      check(refused && redirect.disconnected && !redirect.getInstanceFollowRedirects()
          && "Bearer synthetic-A".equals(redirect.getRequestProperty("authorization")),
          "authenticated redirect " + status + " is refused before any second host, scheme or port is contacted");
      source.close();
    }
    Connection range = new Connection(new URL(origin + "/audio"), 206, "DATA", null);
    HeyAndroidMediaSource source = new HeyAndroidMediaSource(origin + "/audio", secret, url -> range);
    byte[] bytes = new byte[4];
    check(source.readAt(12, bytes, 0, 4) == 4 && new String(bytes, StandardCharsets.UTF_8).equals("DATA")
        && "bytes=12-15".equals(range.getRequestProperty("range")) && source.getSize() == 1000000,
        "same-origin authenticated media supports byte-range reads and size without buffering the file");
    source.close();
    boolean closed = false;
    try { source.readAt(0, bytes, 0, 4); } catch (IOException expected) { closed = true; }
    check(closed, "closed authenticated source cannot fetch more of the previous account's media");

    if (failed > 0) System.exit(1);
  }
}
