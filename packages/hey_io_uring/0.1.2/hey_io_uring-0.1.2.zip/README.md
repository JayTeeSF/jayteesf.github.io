# hey_io_uring

The io_uring backend of Hey's batched TCP event loop, for Linux. Same API and
semantics as [hey_epoll](https://www.jayteesf.com/packages/hey_epoll/)'s
`Epoll`, name for name, and the same native function table, so
[hey_poller](https://www.jayteesf.com/packages/hey_poller/) can serve on it
when asked: `Poller.open(host, port, {backend: 'io_uring'})` or
`HEY_POLLER_BACKEND=io_uring`. It is **not** hey_poller's Linux default: that
waits for measurements on real x86 Linux. On arm64 (Linux 6.8), hey_web's
readiness lane served 25-32% more requests per CPU on io_uring than on epoll.
hey_fast_web's SQLite-bound server tied. See [docs/DESIGN.md](docs/DESIGN.md#measured).

One native call per loop batch: `wait()` hands the kernel every reply the
last batch queued and waits for the next input in the same `io_uring_enter`.
The Hey program takes each connection's unconsumed input as text, parses its
protocol in Hey, and hands back a reply plus the number of bytes it consumed.

What it uses of io_uring:

- **multishot accept** into the ring's **registered (fixed) file table**
  (`IORING_FILE_INDEX_ALLOC`): accepted sockets are direct descriptors, never
  entries in the process's descriptor table;
- **multishot receive** per connection over a **provided buffer ring**: armed
  once, re-armed only when the kernel ends it (buffer ring dry, error);
- **one submit per batch**: `send()` only queues; the next `wait()` submits
  every connection's output and waits, in one system call. Short sends are
  resubmitted from where they stopped, one SEND in flight per connection;
- **CQ overflow handled**: requires `IORING_FEAT_NODROP`, and every drain
  flushes the kernel's overflow backlog before the batch is returned;
- a **single-issuer** ring with **deferred task work** where the kernel has it (6.1);
- a guard against a Linux 6.8 defect that loses a connection when a
  multishot accept is armed into a filling CQ (docs/DESIGN.md).

## Requirements

- Linux **6.0 or later** (multishot receive; the rest is 5.19 or older).
- io_uring allowed: Docker's default seccomp profile **blocks** it (run with
  `--security-opt seccomp=unconfined`, or a profile that allows
  `io_uring_setup`, `io_uring_enter`, `io_uring_register`), and the
  `kernel.io_uring_disabled` sysctl must not forbid it.
- To build: **liburing 2.4+** headers and archive (`apk add liburing-dev`;
  Alpine 3.21 ships 2.8). liburing is linked statically into the library, so
  the runtime needs nothing beyond libc. liburing rather than raw system
  calls because Alpine (the toolchain image's base) packages it: its
  ring-buffer barriers, buffer-ring and multishot helpers are the reference
  implementation, and statically linked it costs no runtime dependency.

Where any of that is missing, `open()` fails with a named error and never
crashes: `io_uring_unsupported_os`, `io_uring_native_library_missing`,
`io_uring_blocked`, `io_uring_disabled`, `io_uring_not_in_kernel`,
`io_uring_kernel_too_old`, `io_uring_missing_feature`, `io_uring_no_memory`,
`io_uring_setup_failed` (and `io_uring_bad_address`, `io_uring_listen_failed`).
`IoUring.available({})` gives the same answer without opening a listener.
hey_poller falls back to epoll on these (with the reason on stderr) unless
asked to be strict.

## Build the native library

```sh
apk add liburing-dev        # or apt-get install liburing-dev
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/build-native
```

Output: `.native-build/linux-<arch>/libhey_io_uring.so`. Applications build
it outside the immutable installed package, for example into
`.hey/native/hey_io_uring/<version>/<target>/`, or point
`HEY_IO_URING_LIBRARY` at it. Through hey_poller:
`.hey/packages/hey_poller/<v>/bin/build-native --project . --backend io_uring`
builds this library and hey_epoll's (the fallback).

## Use it

```hey
import 'pkg:hey_io_uring@0.1.2/io_uring'

program
  let loop = IoUring.open('0.0.0.0', 8080, {backlog: 4096}).value
  while true
    let ready = IoUring.wait(loop, 1000)        # writes the last batch's replies, then waits
    let id = IoUring.next(loop)
    while id >= 0
      let text = IoUring.data(loop, id)         # every unconsumed byte so far
      # ... frame one request of `used` bytes, build `reply` ...
      let sent = IoUring.send(loop, id, used, reply, false)
      set id = IoUring.next(loop)
    end
  end
end
```

| Call | What it does |
|---|---|
| `IoUring.available(options)` | Whether a loop could open here: `Result.ok({kernel, setup})` or the named error. |
| `IoUring.open(host, port, options)` | Listen (IPv4). `backlog` (4096), `reuseport` (false), `library_path`, ring sizes `sq_entries` (4096), `cq_entries` (4 x SQ, and at least twice the listen queue), `buffers` (1024), `buffer_size` (2048). Result value: `{extension, handle, port, backend, kernel, setup}`. |
| `IoUring.wait(loop, timeout_ms)` | The only blocking call. Submits the queued replies, closes and re-arms, then returns how many connections have unconsumed input (-1 if the loop is gone). Returns early only for input, not for other completions. |
| `IoUring.next(loop)` | Next connection id of the batch, or -1. Ids carry a generation. |
| `IoUring.data(loop, id)` | The connection's unconsumed input as text (non-UTF-8 or NUL input closes it and returns `''`). |
| `IoUring.send(loop, id, consumed, text, close_after)` | Drops `consumed` input bytes and **queues** `text`; the next `wait()` (or `close()`) writes it. False when the connection is gone. |
| `IoUring.drop(loop, id)` | Close now (cancels its in-flight receive and send). |
| `IoUring.stats(loop)` | hey_epoll's counters plus `accept_lost`, `submits`, `early_submits`, `sqes`, `cqes`, `cq_overflow_flushes`, `cq_overflow_seen`, `cq_dropped`, `enobufs`, `recv_rearms`, `partial_writes` (short sends), `setup`, `kernel`. |
| `IoUring.close(loop)` | Writes what is still queued (up to 1 s), closes everything, waits for the kernel to give back every buffer, unloads. |

### The one difference from Epoll

`Epoll.send` writes before it returns; `IoUring.send` queues and the next
`wait()` writes. A serving loop calls `wait()` right after its batch, so a
reply leaves no later. Code that sends and then blocks on something else
before waiting (a test reading its own reply on the same thread) must call
`wait(loop, 0)` first.

### Ownership and threads

A loop belongs to the thread that opened it (the ring is
`IORING_SETUP_SINGLE_ISSUER`; a call from another thread fails and the loop
reports -1). Open one loop per worker with `reuseport: true` to use several cores.

### Limits

Input per connection is capped at 1 MiB unconsumed (closed beyond that); a
connection is closed when its peer closes (unanswered requests are dropped);
idle connections are kept until the peer closes them and hold no buffers.
Connections are limited by the fixed-file table, sized to the descriptor hard
limit (at most 1,048,576), not by the process's descriptor table.

## Check

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check     # macOS: porcelain only (SKIP for the loop)
bin/linux-check                                              # Linux container: everything
```

See [docs/TESTING.md](docs/TESTING.md).
