#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreImage/CoreImage.h>

// Hey's str ABI is a pointer to immutable NUL-terminated bytes, so
// str-returning entries are directly callable as C string functions --
// no boxed-value shim and no runtime library needed at link time.
//
// Required app exports (the tvOS game contract, hey_ios_tv >= 0.1.4):
//   tvos_app_manifest() -> str    public-display manifest JSON
//   tvos_action_code(i64) -> i64  receipt code for a remote action
//   tvos_game_init() -> i64       opaque initial game state
//   tvos_game_step(i64,i64)->i64  pure transition: (state, action) -> state
//   tvos_game_text(i64) -> str    display text for a state
// Remote action ids: 1=select 2=up 3=down 4=left 5=right 6=play/pause.
extern const char *HEY_ENTRY_SYMBOL(void);
extern long long hey_fn_tvos_action_code(long long action_id);
extern long long hey_fn_tvos_game_init(void);
extern long long hey_fn_tvos_game_step(long long state, long long action_id);
extern const char *hey_fn_tvos_game_text(long long state);

// ---- Minimal no-runtime string shim -------------------------------------
// Scalar+string Hey apps emit calls to a small fixed set of runtime string
// helpers (string interpolation lowers to format+concat). Rather than link
// the full Hey runtime into a public-display app, this shim models a Hey
// string value as a plain NUL-terminated C string. It is complete exactly
// for the symbol set such objects reference; apps that use boxed
// collections or actors need the real runtime (future package slice).
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void hey_runtime_init(void) {}
void hey_runtime_shutdown(void) {}
void hey_runtime_set_argv(int argc, char **argv) { (void)argc; (void)argv; }

void *hey_llvm_string_value(const char *text) {
  return strdup(text ? text : "");
}

void *hey_llvm_value_clone_ptr(void *value) {
  return strdup(value ? (const char *)value : "");
}

const char *hey_llvm_value_to_raw_string_cstr(void *value) {
  return value ? (const char *)value : "";
}

void *hey_llvm_concat_string(void *left, void *right) {
  const char *a = left ? (const char *)left : "";
  const char *b = right ? (const char *)right : "";
  size_t la = strlen(a), lb = strlen(b);
  char *out = malloc(la + lb + 1);
  memcpy(out, a, la);
  memcpy(out + la, b, lb + 1);
  return out;
}

void *hey_llvm_format_fixed_string(long long value, long long scale) {
  char buffer[48];
  if (scale <= 0) {
    snprintf(buffer, sizeof buffer, "%lld", value);
  } else {
    long long divisor = 1;
    for (long long i = 0; i < scale; i++) { divisor *= 10; }
    long long whole = value / divisor;
    long long frac = value % divisor;
    if (frac < 0) { frac = -frac; }
    snprintf(buffer, sizeof buffer, "%lld.%0*lld", whole, (int)scale, frac);
  }
  return strdup(buffer);
}
// -------------------------------------------------------------------------

@interface HeyTVViewController : UIViewController
@property(nonatomic) long long gameState;
@property(strong, nonatomic) UILabel *gameLabel;
@end

@implementation HeyTVViewController

- (UIImage *)qrImageForString:(NSString *)text size:(CGFloat)side {
  CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
  [filter setValue:[text dataUsingEncoding:NSUTF8StringEncoding] forKey:@"inputMessage"];
  [filter setValue:@"M" forKey:@"inputCorrectionLevel"];
  CIImage *output = filter.outputImage;
  if (!output) { return nil; }
  CGFloat scale = side / output.extent.size.width;
  CIImage *scaled = [output imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
  CIContext *context = [CIContext context];
  CGImageRef cg = [context createCGImage:scaled fromRect:scaled.extent];
  if (!cg) { return nil; }
  UIImage *image = [UIImage imageWithCGImage:cg];
  CGImageRelease(cg);
  return image;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = UIColor.blackColor;
  const char *manifestBytes = HEY_ENTRY_SYMBOL();
  NSString *manifest = manifestBytes ? [NSString stringWithUTF8String:manifestBytes] : @"{}";
  NSDictionary *fields = @{};
  NSData *manifestData = [manifest dataUsingEncoding:NSUTF8StringEncoding];
  if (manifestData) {
    id parsed = [NSJSONSerialization JSONObjectWithData:manifestData options:0 error:NULL];
    if ([parsed isKindOfClass:NSDictionary.class]) { fields = parsed; }
  }
  NSString *titleText = [fields[@"title"] isKindOfClass:NSString.class] ? fields[@"title"] : @"Hey TV";
  NSString *joinUrl = [fields[@"join_url"] isKindOfClass:NSString.class] ? fields[@"join_url"] : @"";

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  title.text = titleText;
  title.textColor = UIColor.whiteColor;
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1];
  [self.view addSubview:title];

  UIImageView *qrView = [[UIImageView alloc] init];
  qrView.translatesAutoresizingMaskIntoConstraints = NO;
  qrView.accessibilityIdentifier = @"join-qr";
  if (joinUrl.length > 0) { qrView.image = [self qrImageForString:joinUrl size:360]; }
  [self.view addSubview:qrView];

  UILabel *joinLabel = [[UILabel alloc] init];
  joinLabel.translatesAutoresizingMaskIntoConstraints = NO;
  joinLabel.text = joinUrl;
  joinLabel.textColor = UIColor.lightGrayColor;
  joinLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
  [self.view addSubview:joinLabel];

  self.gameState = hey_fn_tvos_game_init();
  UILabel *game = [[UILabel alloc] init];
  game.translatesAutoresizingMaskIntoConstraints = NO;
  game.textColor = UIColor.whiteColor;
  game.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  game.numberOfLines = 3;
  game.textAlignment = NSTextAlignmentCenter;
  game.accessibilityIdentifier = @"game-state";
  self.gameLabel = game;
  [self refreshGameLabel];
  [self.view addSubview:game];

  [NSLayoutConstraint activateConstraints:@[
    [title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:60],
    [qrView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [qrView.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:40],
    [qrView.widthAnchor constraintEqualToConstant:360],
    [qrView.heightAnchor constraintEqualToConstant:360],
    [joinLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [joinLabel.topAnchor constraintEqualToAnchor:qrView.bottomAnchor constant:16],
    [game.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:120],
    [game.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-120],
    [game.topAnchor constraintEqualToAnchor:joinLabel.bottomAnchor constant:60]
  ]];

  NSArray<NSNumber *> *pressTypes = @[
    @(UIPressTypeSelect), @(UIPressTypeUpArrow), @(UIPressTypeDownArrow),
    @(UIPressTypeLeftArrow), @(UIPressTypeRightArrow), @(UIPressTypePlayPause)
  ];
  for (NSNumber *pressType in pressTypes) {
    UITapGestureRecognizer *tap =
        [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(remotePress:)];
    tap.allowedPressTypes = @[ pressType ];
    [self.view addGestureRecognizer:tap];
  }
}

- (void)refreshGameLabel {
  const char *text = hey_fn_tvos_game_text(self.gameState);
  self.gameLabel.text = text ? [NSString stringWithUTF8String:text] : @"";
}

- (void)remotePress:(UITapGestureRecognizer *)recognizer {
  NSNumber *pressType = recognizer.allowedPressTypes.firstObject;
  long long action = 1;
  switch ((UIPressType)pressType.integerValue) {
    case UIPressTypeSelect: action = 1; break;
    case UIPressTypeUpArrow: action = 2; break;
    case UIPressTypeDownArrow: action = 3; break;
    case UIPressTypeLeftArrow: action = 4; break;
    case UIPressTypeRightArrow: action = 5; break;
    case UIPressTypePlayPause: action = 6; break;
    default: action = 1; break;
  }
  self.gameState = hey_fn_tvos_game_step(self.gameState, action);
  self.gameLabel.accessibilityValue =
      [NSString stringWithFormat:@"%lld", hey_fn_tvos_action_code(action)];
  [self refreshGameLabel];
}
@end

@interface HeyTVAppDelegate : UIResponder <UIApplicationDelegate>
@property(strong, nonatomic) UIWindow *window;
@end

@implementation HeyTVAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
  self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  self.window.rootViewController = [[HeyTVViewController alloc] init];
  [self.window makeKeyAndVisible];
  return YES;
}
@end

int main(int argc, char **argv) {
  @autoreleasepool {
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(HeyTVAppDelegate.class));
  }
}
