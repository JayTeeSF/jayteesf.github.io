# hey_web_dev_enrollment

A development-only companion to `hey_web` and `hey_mobile`. It owns the reusable enrollment payload, unguessable path route, browser URL, and secret-bearing QR page composition. The host application still owns token issuance, authorization scope, persistence, protocol-specific health validation, TLS policy, and production enrollment.

The browser page uses `/dev/enroll/:secret`, not query parsing, so it avoids coupling to request-query implementation details.

## Standard package controls

This package uses `hey_packager` 0.1.2 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_web_dev_enrollment`.
