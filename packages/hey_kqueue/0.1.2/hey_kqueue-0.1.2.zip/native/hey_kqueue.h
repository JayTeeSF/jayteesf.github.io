#ifndef HEY_KQUEUE_H
#define HEY_KQUEUE_H

#include "hey_native_abi.h"

/* One event loop: a nonblocking TCP listener plus every connection it accepted,
   multiplexed by kqueue (macOS, FreeBSD, OpenBSD, NetBSD, DragonFly).
   A loop is owned by exactly one Hey thread. */
HeyNativeHandle hey_kqueue_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport);
int32_t hey_kqueue_close(HeyNativeHandle loop);
int32_t hey_kqueue_wait(HeyNativeHandle loop, int32_t timeout_ms);
int64_t hey_kqueue_next(HeyNativeHandle loop);
HeyNativeUtf8View hey_kqueue_data(HeyNativeHandle loop, int64_t connection);
int32_t hey_kqueue_send(HeyNativeHandle loop, int64_t connection, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after);
int32_t hey_kqueue_drop(HeyNativeHandle loop, int64_t connection);
int32_t hey_kqueue_port(HeyNativeHandle loop);
HeyNativeUtf8View hey_kqueue_stats(HeyNativeHandle loop);
HeyNativeUtf8View hey_kqueue_backend(void);

#endif
