# In progress

Staged for 0.2.0 (VERSION still 0.1.7; the release pipeline runs the
bump): the serve fix. `HeyWebServer.serve` now uses `Web.serve` -- the
0.1.x path (`Web.service` + `Web.start`) never invoked a registered
handler in a compiled binary, because `Web.service` is JSON-delegated
to the stdlib sidecar and handler callables cannot survive the
round-trip. Proof is `specs/live_serve_spec.hey` (interpreter, scratch
port 46401, asserts the handler-produced body) plus the compiled serve
receipt in `bin/check` (`tools/serve_receipt.hey`, scratch port 46402,
asserts the body and zero `hey error:` lines). The version literal is
single-sourced in `HeyWebConfig.version()` behind a VERSION-derived
drift guard. 0.2.0's second half (extracted fast-lane modules from
RecallCoach, `src/` deletion and other housekeeping) is the next
slice.
