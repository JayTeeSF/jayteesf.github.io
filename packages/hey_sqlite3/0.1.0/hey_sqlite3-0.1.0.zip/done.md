# Done

- Added shell-free direct argv command construction.
- Added JSON row parsing, normalized Result values, change count, and last insert id.
- Added package/docs/spec/handoff tooling.
- Verified the packed release through clean package install, lockfile pinning, installed-content verification, and compiled `pkg:` import.
