#!/usr/bin/env sh
# Execute production scene validation and deterministic retry policy.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT HUP INT TERM
cat > "$WORK/policy.m" <<'OBJC'
#import <Foundation/Foundation.h>
#import "hey_tv_scene_poll.h"
static void expect(BOOL ok, NSString *label) { if (!ok) { fprintf(stderr,"FAIL %s\n",label.UTF8String); exit(1); } printf("PASS %s\n",label.UTF8String); }
static NSString *json(id object) { return [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:object options:0 error:NULL] encoding:NSUTF8StringEncoding]; }
int main(int argc, char **argv) { @autoreleasepool {
  for (int i=1;i<argc;i++) { NSString *path=[NSString stringWithUTF8String:argv[i]]; NSString *body=[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:NULL]; expect(HeyTVSceneBodyValid(body),@"real synthetic My Queue scene remains compatible"); }
  NSArray *widgets=@[@{@"kind":@"text",@"text":@"Last good"},@{@"kind":@"image",@"url":@"https://example.org/art.jpg"},@{@"kind":@"image",@"symbol":@"play"},@{@"kind":@"qr",@"payload":@"https://example.org"},@{@"kind":@"rect",@"color":@"#000000"},@{@"kind":@"card",@"rank":@"A",@"suit":@"spades"},@{@"kind":@"hand",@"cards":@[@{@"rank":@"K"}]},@{@"kind":@"stack",@"cards":@[]},@{@"kind":@"grid",@"items":@[@{@"title":@"Example"}]},@{@"kind":@"chips",@"items":@[@"All",@"Books"]},@{@"kind":@"spinner"},@{@"kind":@"listrow"},@{@"kind":@"future-visible-placeholder",@"extra":@YES}];
  NSDictionary *scene=@{@"schema":@"hey-tv-scene-v2",@"widgets":widgets,@"extra":@{@"future":@YES}};
  NSString *good=json(scene);
  expect(HeyTVSceneBodyValid(good),@"all native widget families and unknown-kind placeholder remain supported");
  expect(HeyTVSceneBodyValid(@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[]}"),@"explicit empty/static/video-only scene remains valid without fetch");
  expect(HeyTVSceneBodyValid(@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[],\"tick\":{},\"fetch\":{\"url\":\"https://example.org/state\"}}"),@"legacy optional tick/fetch defaults remain valid");
  NSArray *bad=@[@"",@"{\"schema\":",@"<html>offline</html>",@"[]",@"null",@"{}",@"{\"schema\":\"unknown\",\"widgets\":[]}",@"{\"kind\":\"television_public_display\"}",@"{\"schema\":\"hey-tv-scene-v2\"}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":{}}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[null]}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[{}]}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[{\"kind\":3}]}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[{\"kind\":\"text\"}]}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[{\"kind\":\"text\",\"text\":3}]}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[],\"fetch\":null}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[],\"fetch\":{\"url\":3}}",@"{\"schema\":\"hey-tv-scene-v2\",\"widgets\":[],\"tick\":[]}"];
  HeyTVScenePoll *poll=[HeyTVScenePoll new];
  for (NSString *body in bad) {
    expect(!HeyTVSceneBodyValid(body),@"malformed JSON/schema/widget declarations refused");
    expect([poll acceptBody:body status:200 transportError:NO at:100 baseInterval:2]==nil,@"rejected HTTP200 produces no replacement scene");
  }
  for (NSDictionary *widget in @[@{@"kind":@"hand",@"cards":@"bad"},@{@"kind":@"stack",@"cards":@[@3]},@{@"kind":@"grid",@"items":@[@3]},@{@"kind":@"chips",@"items":@[@{}]},@{@"kind":@"image",@"url":@3},@{@"kind":@"qr",@"payload":@3},@{@"kind":@"rect",@"color":@3}]) { expect(!HeyTVSceneBodyValid(json(@{@"schema":@"hey-tv-scene-v2",@"widgets":@[widget]})),@"malformed nested widget content refused"); }
  for (NSDictionary *fetch in @[@{@"url":@"relative/path"},@{@"url":@"http://"},@{@"url":@"https://example.org",@"ms":@"bad"},@{@"url":@"https://example.org",@"mode":@3}]) { expect(!HeyTVSceneBodyValid(json(@{@"schema":@"hey-tv-scene-v2",@"widgets":@[],@"fetch":fetch})),@"malformed fetch declarations cannot strand the poller"); }
  [poll reset];
  double now=100;
  for (NSNumber *delay in @[@2,@4,@8,@16,@32,@60,@60]) {
    expect([poll acceptBody:@"{" status:200 transportError:NO at:now baseInterval:2]==nil,@"failed payload refused during outage");
    expect(poll.retryAt==now+delay.doubleValue && ![poll shouldAttemptAt:poll.retryAt-0.01] && [poll shouldAttemptAt:poll.retryAt],@"retry deadline doubles from cadence and stops at 60 seconds");
    now=poll.retryAt;
  }
  for (int i=0;i<100;i++) { [poll acceptBody:good status:503 transportError:NO at:now baseInterval:2]; }
  expect(poll.failures==16 && poll.retryAt==now+60,@"long outage counters and retry delay stay bounded");
  expect([poll acceptBody:good status:200 transportError:YES at:now baseInterval:2]==nil,@"transport failure cannot install an otherwise valid body");
  expect([[poll acceptBody:good status:200 transportError:NO at:now baseInterval:2] isEqual:good] && poll.failures==0 && poll.retryAt==0,@"later good payload is returned intact and resets all retry state");
  [poll acceptBody:@"{" status:200 transportError:NO at:200 baseInterval:0.25];
  expect(poll.retryAt==200.25 && poll.failures==1,@"new outage starts at normal cadence after recovery");
  [poll reset];
  expect([poll shouldAttemptAt:200] && poll.failures==0,@"explicit local navigation can reset retry deadline");
  puts("scene poll policy spec passed");
} return 0; }
OBJC
clang -fobjc-arc -framework Foundation -I "$ROOT/tools" "$WORK/policy.m" -o "$WORK/policy"
"$WORK/policy" "$@"
