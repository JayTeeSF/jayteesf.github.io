USAGE = <<'DOC'.freeze
screen.rb: read what the emulator shows, for specs/android_ui_emulator_spec.sh.

  size   RAW                         WIDTHxHEIGHT of a raw `adb exec-out screencap` (no -p)
  pixel  RAW X Y                     the pixel at (X, Y) as RRGGBB
  count  RAW X0 Y0 X1 Y1 RRGGBB      pixels in the rectangle [X0,X1) x [Y0,Y1) within 8 of the colour
  differ RAW_A RAW_B X0 Y0 X1 Y1     pixels in the rectangle that differ between two screens
  bounds XML TEXT                    "x0 y0 x1 y1" of the uiautomator node whose text is TEXT

A raw screencap is a little-endian header (width, height, format, and on newer
Android a colour space) followed by width*height RGBA bytes; the header length is
whatever is left over. Each command exits 1 when its input is unusable.
DOC

def die(message)
  warn message
  exit 1
end

Screen = Struct.new(:width, :height, :data, :header)

def load(path)
  data = File.binread(path)
  die("not a raw screencap: #{path}") if data.bytesize < 12
  width, height = data.unpack('VV')
  header = data.bytesize - width * height * 4
  unless [12, 16].include?(header)
    die("unexpected raw screencap layout in #{path}: #{data.bytesize} bytes for #{width}x#{height}")
  end
  Screen.new(width, height, data, header)
end

def rgb(screen, x, y)
  unless x >= 0 && x < screen.width && y >= 0 && y < screen.height
    die("(#{x}, #{y}) is outside the #{screen.width}x#{screen.height} screen")
  end
  offset = screen.header + (y * screen.width + x) * 4
  d = screen.data
  [d.getbyte(offset), d.getbyte(offset + 1), d.getbyte(offset + 2)]
end

def each_in_rect(screen, x0, y0, x1, y1)
  ([0, y0].max...[screen.height, y1].min).each do |y|
    ([0, x0].max...[screen.width, x1].min).each { |x| yield x, y }
  end
end

argv = ARGV
die(USAGE) if argv.empty?
case argv[0]
when 'size'
  s = load(argv.fetch(1))
  puts "#{s.width}x#{s.height}"
when 'pixel'
  r, g, b = rgb(load(argv.fetch(1)), Integer(argv.fetch(2), 10), Integer(argv.fetch(3), 10))
  puts format('%02X%02X%02X', r, g, b)
when 'count'
  s = load(argv.fetch(1))
  x0, y0, x1, y1 = argv[2, 4].map { |v| Integer(v, 10) }
  want = [0, 2, 4].map { |i| Integer(argv.fetch(6)[i, 2], 16) }
  n = 0
  each_in_rect(s, x0, y0, x1, y1) do |x, y|
    n += 1 if rgb(s, x, y).zip(want).all? { |a, b| (a - b).abs <= 8 }
  end
  puts n
when 'differ'
  a = load(argv.fetch(1))
  b = load(argv.fetch(2))
  die('the two screens differ in size') if [a.width, a.height] != [b.width, b.height]
  x0, y0, x1, y1 = argv[3, 4].map { |v| Integer(v, 10) }
  n = 0
  each_in_rect(a, x0, y0, x1, y1) { |x, y| n += 1 if rgb(a, x, y) != rgb(b, x, y) }
  puts n
when 'bounds'
  xml = File.binread(argv.fetch(1)).force_encoding('UTF-8').scrub
  text = argv.fetch(2).gsub('&') { '&amp;' }.gsub('"') { '&quot;' }.gsub('<') { '&lt;' }.gsub('>') { '&gt;' }
  xml.scan(/<node [^>]*>/) do |node|
    next unless node.include?(" text=\"#{text}\"")
    m = /bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/.match(node)
    if m
      puts m.captures.join(' ')
      exit 0
    end
  end
  die("no node with text '#{argv[2]}'")
else
  die(USAGE)
end
