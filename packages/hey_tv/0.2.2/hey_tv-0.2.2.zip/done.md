# Done

- 0.1.0: extracted target-neutral television values from Hey core.
- 0.2.2: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes.
