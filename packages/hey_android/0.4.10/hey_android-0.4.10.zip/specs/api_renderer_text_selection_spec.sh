#!/usr/bin/env bash
# Native text selection is available for displayed content, while a short tap
# on a row still runs that row's existing action.
set -euo pipefail
source_file="$(dirname "$0")/../renderer/android/hey/android/api/HeyAndroidApiActivity.java"
fixture_file="$(dirname "$0")/support/api_fixture_description.json"
driver_file="$(dirname "$0")/support/drive.rb"
server_file="$(dirname "$0")/support/fake_api_server.rb"
emulator_spec_file="$(dirname "$0")/api_renderer_emulator_spec.sh"
ruby - "$source_file" "$fixture_file" "$driver_file" "$server_file" "$emulator_spec_file" <<'RUBY'
require 'json'
s = File.read(ARGV.fetch(0))
fixture = JSON.parse(File.read(ARGV.fetch(1)))
driver = File.read(ARGV.fetch(2))
server = File.read(ARGV.fetch(3))
emulator_spec = File.read(ARGV.fetch(4))
text = s[/private TextView text\(String s, float sp, int color, boolean bold\) \{.*?^  \}/m].to_s
tappable = s[/private void tappable\(View v, Runnable r\) \{.*?^  \}/m].to_s
forward = s[/private void forwardTextClicks\(View root, Runnable action\) \{.*?^  \}/m].to_s
control_text = s[/private TextView controlText\(String s, float sp, int color, boolean bold\) \{.*?^  \}/m].to_s
chrome = s[/private void buildChrome\(\) \{.*?^  \}/m].to_s
tabs = s[/private void drawTabBar\(\) \{.*?^  \}/m].to_s
search_box = s[/private void buildSearchBox\(Page page\) \{.*?^  \}/m].to_s
checks = [
  ['the shared static-text factory enables native selection', text.include?('setTextIsSelectable(true)')],
  ['selectability is enabled after the label text is assigned', text.index('t.setText(s)') && text.index('t.setTextIsSelectable(true)') && text.index('t.setText(s)') < text.index('t.setTextIsSelectable(true)')],
  ['a long press on static text selects the whole value, so one Copy takes a full multi-word title or field', text.include?('setOnLongClickListener') && text.include?('Selection.setSelection(') && text.include?('return false;')],
  ['a tappable row forwards short taps through selectable text children', tappable.include?('forwardTextClicks(v, r)')],
  ['text click forwarding does not mistake selectable state for a row handler and leaves long-press selection alone', forward.include?('instanceof TextView') && forward.include?('setOnClickListener') && !forward.include?('hasOnClickListeners()') && !forward.include?('setOnLongClickListener')],
  ['a short stationary touch runs the row action, while a long press or selection drag stays with Android', forward.include?('setOnTouchListener') && forward.include?('MotionEvent.ACTION_UP') && forward.include?('ViewConfiguration.getLongPressTimeout()') && forward.include?('action.run()') && forward.include?('getScaledTouchSlop()')],
  ['search remains an editable native text field', s.include?('EditText field = new EditText(this);') && s.include?('field.setSingleLine(true);')],
  ['interactive chrome text opts out of selection so Back and Account still respond', control_text.include?('t.setTextIsSelectable(false)') && chrome.include?('backButton = controlText(') && chrome.include?('navButton = controlText(')],
  ['tab labels opt out of selection so a short tap changes tabs', tabs.include?('controlText(title,') && tabs.include?('t.setOnClickListener(v -> selectTab(id))')],
  ['search Cancel opts out of selection so its short tap clears the field', search_box.include?('cancel = controlText(') && search_box.include?('cancel.setOnClickListener(')],
  ['choice fields opt out of selection so their option picker still opens', s.include?('TextView shown = controlText(Screens.optionTitle(') && s.include?('shown.setOnClickListener(')],
  ['the device fixture exposes separate description, note, message and tag content', begin
    item = fixture.fetch('screens').find { |screen| screen['id'] == 'item' }
    fields = item.fetch('sections').flat_map { |section| section.fetch('fields', []) }.to_h { |field| [field['label'], field['value']] }
    { 'Description' => 'item.description', 'Private note' => 'item.note', 'Message' => 'item.message', 'Tags' => 'item.tags_text' }.all? { |label, value| fields[label] == value }
  end],
  ['the device driver can invoke Android Copy without a title-specific toolbar coordinate', driver.include?('copy-key') && driver.include?('keyevent') && driver.include?('"278"')],
  ['each device copy query exactly matches its synthetic item field', { 'description' => ['description', 'copy sentinel description'], 'note' => ['note', 'copy sentinel private note'], 'message' => ['message', 'copy sentinel message'], 'tags_text' => ['tags', 'copy sentinel tag one and tag two'] }.all? { |field, (category, value)| server.include?(%Q('#{field}' => '#{value}')) && emulator_spec.include?(%Q(check_native_copy #{category} '#{value}' key)) }],
  ['copy acceptance submits through the keyboard Search action and proves a request occurred', driver.include?("when 'search'") && emulator_spec.include?('drive search') && emulator_spec.include?('searches_before')],
]
failed = 0
checks.each do |name, ok|
  puts "#{ok ? 'PASS' : 'FAIL'}: #{name}"
  failed += 1 unless ok
end
puts "#{checks.length - failed}/#{checks.length} native text-selection contracts passed"
exit(failed.zero? ? 0 : 1)
RUBY
