# Goals

Provide a reliable MySQL adapter for Hey and `hey_record`, moving from a transparent direct-argv client to a pooled native prepared-statement driver.
