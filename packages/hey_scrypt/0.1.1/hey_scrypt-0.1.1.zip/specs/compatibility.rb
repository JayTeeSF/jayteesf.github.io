require 'scrypt';require 'open3'
root=File.expand_path('..',__dir__)
# Fixed vectors test storage compatibility, not a proposed production work factor.
secret="Pw9!日本語\tline\n";salts=['400$8$1$1234567890abcdef','400$8$1$0000000000000123','1000$8$1$0123456789abcdef0123456789abcdef']
salts.each do |salt|
 out,err,status=Open3.capture3({'SCRYPT_LIBRARY'=>ENV.fetch('SCRYPT_LIBRARY'),'SCRYPT_TEST_SECRET'=>secret,'SCRYPT_TEST_SALT'=>salt},File.join(root,'build/receipt'))
 raise 'Native hash worker failed' unless status.success?
 expected=SCrypt::Engine.hash_secret(secret,salt,32)
 raise 'Stored format mismatch' unless out.strip==expected
 raise 'Ruby verifier rejected native hash' unless SCrypt::Password.new(out.strip)==secret
 raise 'Incorrect password accepted' if SCrypt::Password.new(out.strip)=='incorrect'
end
puts 'PASS: exact modern Ruby scrypt storage and verification (including UTF-8 and leading-zero salt)'
