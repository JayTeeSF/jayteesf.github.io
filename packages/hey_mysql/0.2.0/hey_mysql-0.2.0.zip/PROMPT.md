# Continue hey_mysql

Read README.md, docs/DESIGN.md, goals.md, in-progress.md, todos.md, done.md, manifests, implementation files, and specs before editing.

This is an independent MySQL/MariaDB package. Keep Connector/C pointers opaque, separate compile/load/expected-failure evidence from a live-server receipt, and never claim prepared statements until MYSQL_STMT is implemented and tested.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

Published versions are immutable. Change the package version whenever released bytes change.

## Files the next LLM needs

For focused work, upload:

1. the latest full Hey source ZIP (`hey-lang-bootstrap-plan-v0.99.268a(1).zip` or newer);
2. this package's latest source/release ZIP (`hey_mysql-0.2.0.zip`).

For coordinated adapter/porcelain work, upload `hey_database-stack-v0.2.0.zip` instead of the individual package ZIP; it already contains all three packages, release metadata, cross-package verification, language findings, and the roadmap.
