#define _DARWIN_C_SOURCE 1
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static double ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000.0+t.tv_nsec/1e6;}
static void bench(const char*label,int op){
  char path[]="/tmp/b3-XXXXXX"; int fd=mkstemp(path); char buf[128]; memset(buf,'x',sizeof buf);
  for(int i=0;i<5;i++){ if(write(fd,buf,sizeof buf)<0){} fcntl(fd,F_FULLFSYNC,0);}
  int n=100; double t0=ms(); int failed=0;
  for(int i=0;i<n;i++){
    if(write(fd,buf,sizeof buf)<0){}
    int r = (op==0)? fsync(fd) : fcntl(fd,op,0);
    if(r!=0) failed++;
  }
  double el=ms()-t0;
  printf("%-16s %6.3f ms/op %8.0f ops/s  failures=%d\n",label,el/n,n/(el/1000.0),failed);
  close(fd); unlink(path);
}
int main(void){
  bench("fsync",0);
#ifdef F_BARRIERFSYNC
  bench("F_BARRIERFSYNC",F_BARRIERFSYNC);
#else
  printf("F_BARRIERFSYNC not defined\n");
#endif
  bench("F_FULLFSYNC",F_FULLFSYNC);
  return 0;
}
