#!/usr/bin/env python3
"""screen.py: read what the emulator shows, for specs/android_ui_emulator_spec.sh.

  size   RAW                         WIDTHxHEIGHT of a raw `adb exec-out screencap` (no -p)
  pixel  RAW X Y                     the pixel at (X, Y) as RRGGBB
  count  RAW X0 Y0 X1 Y1 RRGGBB      pixels in the rectangle [X0,X1) x [Y0,Y1) within 8 of the colour
  differ RAW_A RAW_B X0 Y0 X1 Y1     pixels in the rectangle that differ between two screens
  bounds XML TEXT                    "x0 y0 x1 y1" of the uiautomator node whose text is TEXT

A raw screencap is a little-endian header (width, height, format, and on newer
Android a colour space) followed by width*height RGBA bytes; the header length is
whatever is left over. Each command exits 1 when its input is unusable.
"""
import re
import struct
import sys


def load(path):
    data = open(path, "rb").read()
    if len(data) < 12:
        sys.exit("not a raw screencap: %s" % path)
    width, height = struct.unpack_from("<II", data, 0)
    header = len(data) - width * height * 4
    if header not in (12, 16):
        sys.exit("unexpected raw screencap layout in %s: %d bytes for %dx%d" % (path, len(data), width, height))
    return width, height, data, header


def rgb(screen, x, y):
    width, height, data, header = screen
    if not (0 <= x < width and 0 <= y < height):
        sys.exit("(%d, %d) is outside the %dx%d screen" % (x, y, width, height))
    offset = header + (y * width + x) * 4
    return data[offset], data[offset + 1], data[offset + 2]


def rect(screen, x0, y0, x1, y1):
    width, height = screen[0], screen[1]
    return range(max(0, y0), min(height, y1)), range(max(0, x0), min(width, x1))


def main(argv):
    if len(argv) < 2:
        sys.exit(__doc__)
    command = argv[1]
    if command == "size":
        width, height, _, _ = load(argv[2])
        print("%dx%d" % (width, height))
    elif command == "pixel":
        r, g, b = rgb(load(argv[2]), int(argv[3]), int(argv[4]))
        print("%02X%02X%02X" % (r, g, b))
    elif command == "count":
        screen = load(argv[2])
        x0, y0, x1, y1 = (int(v) for v in argv[3:7])
        want = tuple(int(argv[7][i:i + 2], 16) for i in (0, 2, 4))
        rows, cols = rect(screen, x0, y0, x1, y1)
        print(sum(1 for y in rows for x in cols if all(abs(a - b) <= 8 for a, b in zip(rgb(screen, x, y), want))))
    elif command == "differ":
        a, b = load(argv[2]), load(argv[3])
        if a[:2] != b[:2]:
            sys.exit("the two screens differ in size")
        x0, y0, x1, y1 = (int(v) for v in argv[4:8])
        rows, cols = rect(a, x0, y0, x1, y1)
        print(sum(1 for y in rows for x in cols if rgb(a, x, y) != rgb(b, x, y)))
    elif command == "bounds":
        xml = open(argv[2], encoding="utf-8", errors="replace").read()
        text = argv[3].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
        for node in re.findall(r"<node [^>]*>", xml):
            if ' text="%s"' % text in node:
                m = re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"', node)
                if m:
                    print(" ".join(m.groups()))
                    return
        sys.exit("no node with text %r" % argv[3])
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main(sys.argv)
