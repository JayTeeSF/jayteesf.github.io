/* hey_android_ui.c: Android Views for a Hey program, with no Java and no dex.
 *
 * THE THREADS.
 *   - The Hey program runs on its own thread (native/glue). It calls begin, text_row,
 *     commit, next_event and errors through stdlib:Native. None of them touches JNI.
 *   - The UI thread is the thread that ran ANativeActivity_onCreate. Every JNI call
 *     happens here, with the UI thread's own JNIEnv, so no thread is ever attached to
 *     the VM.
 *   - The hand-off is a pipe. commit gives the finished description to the UI thread
 *     and writes one byte; the pipe's read end is registered with ALooper_addFd on the
 *     UI thread's looper, so the looper runs on_pipe there. commit then waits for the
 *     UI thread to say it is done. The UI thread never waits on Hey: it takes the one
 *     lock only for as long as a copy or a queue push lasts.
 *   - Events go the other way through a queue under the same lock. next_event blocks
 *     the Hey thread until the UI thread pushes one. It is thread_safe in the manifest,
 *     so the runtime does not hold the extension's call lock while it waits.
 *
 * DRAWING. NativeActivity takes the window's surface for itself, and while it holds
 * it, a View tree set with setContentView is laid out but never drawn (measured
 * 2026-09-13 on the API 36 emulator: the window stays black). attach gives the
 * surface back with getWindow().takeSurface(null), and Views draw.
 *
 * TAPS, WITHOUT DEX. A click listener is a Java interface, and implementing one needs
 * a class. So this slice keeps NativeActivity's input queue and hit-tests natively: a
 * touch that goes down and up within a small distance is a tap, and the row whose
 * View contains the point (getLocationOnScreen, getWidth, getHeight) is queued as
 * {"kind":"tap","id":"row-3"}. This loses press state, the platform's touch
 * scrolling, IME composition and TalkBack activation. hey_android uses no Java in
 * any form, generated or loaded from memory included, so input stays native;
 * docs/ROADMAP.md lists what that rule costs.
 */
#include "hey_android_ui.h"

#include <android/input.h>
#include <android/log.h>
#include <android/looper.h>
#include <android/native_activity.h>
#include <jni.h>

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define HEY_TAG_UI "hey.ui"
#define HEY_UI_EVENT_MAX 64
#define HEY_UI_ROW_MAX 512
#define HEY_UI_ID_MAX 64
#define HEY_UI_ERROR_MAX 2048
#define HEY_UI_TAP_SLOP_DP 16.0f
#define HEY_UI_PAD_DP 16.0f
#define HEY_UI_TEXT_SP 22.0f
#define HEY_UI_ROOT_COLOR ((jint)0xFFFFFFFF)
#define HEY_UI_EVEN_ROW_COLOR ((jint)0xFFFFC107) /* amber: rows 0, 2, 4, ... */
#define HEY_UI_ODD_ROW_COLOR ((jint)0xFF1E88E5)  /* blue: rows 1, 3, 5, ... */
#define HEY_UI_TEXT_COLOR ((jint)0xFF000000)

typedef struct {
  char *label;
  size_t label_length;
  char *id;
} HeyUiRow;

typedef struct {
  HeyUiRow *rows;
  size_t count;
  size_t capacity;
} HeyUiDescription;

/* ---- shared between the threads, under ui_lock -------------------------- */
static pthread_mutex_t ui_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t event_cond = PTHREAD_COND_INITIALIZER;
static pthread_cond_t commit_cond = PTHREAD_COND_INITIALIZER;
static int ui_attached;
static char *event_queue[HEY_UI_EVENT_MAX];
static size_t event_head;
static size_t event_count;
static HeyUiDescription pending;
static int pending_ready;
static uint64_t commit_requested;
static uint64_t commit_done;
static int64_t commit_result;
static char last_error[HEY_UI_ERROR_MAX];
static int pipe_read = -1;
static int pipe_write = -1;

/* ---- the Hey thread only ------------------------------------------------- */
static HeyUiDescription building;
static __thread char *event_text;
static __thread char error_text[HEY_UI_ERROR_MAX];

/* ---- the UI thread only -------------------------------------------------- */
static ANativeActivity *ui_activity;
static ALooper *ui_looper;
static jobject activity_ref;
static float density = 1.0f;
static int touch_down;
static float down_x;
static float down_y;
static jobject *row_views;
static char **row_ids;
static size_t row_view_count;

static struct {
  int ready;
  jclass object, string, activity, window, resources, display_metrics, view, view_group, linear_layout, text_view;
  jmethodID object_to_string, string_from_bytes;
  jmethodID activity_get_window, activity_set_content_view, activity_get_resources;
  jmethodID window_take_surface, window_set_format;
  jmethodID resources_get_display_metrics;
  jfieldID display_metrics_density;
  jmethodID view_set_background_color, view_set_padding, view_get_location_on_screen, view_get_width, view_get_height,
            view_set_fits_system_windows;
  jmethodID view_group_add_view, view_group_get_child_count;
  jmethodID linear_layout_init, linear_layout_set_orientation;
  jmethodID text_view_init, text_view_set_text, text_view_set_text_size, text_view_set_text_color;
} J;

/* ---- small helpers ------------------------------------------------------- */

static void record_error(const char *format, ...) __attribute__((format(printf, 1, 2)));
static void record_error(const char *format, ...) {
  char text[HEY_UI_ERROR_MAX];
  va_list args;
  va_start(args, format);
  vsnprintf(text, sizeof text, format, args);
  va_end(args);
  pthread_mutex_lock(&ui_lock);
  memcpy(last_error, text, sizeof last_error);
  pthread_mutex_unlock(&ui_lock);
  __android_log_write(ANDROID_LOG_ERROR, HEY_TAG_UI, text);
}

static void description_free(HeyUiDescription *description) {
  for (size_t i = 0; i < description->count; i++) {
    free(description->rows[i].label);
    free(description->rows[i].id);
  }
  free(description->rows);
  memset(description, 0, sizeof *description);
}

static void push_event(const char *json) {
  char *copy = strdup(json);
  if (!copy) return;
  pthread_mutex_lock(&ui_lock);
  if (event_count == HEY_UI_EVENT_MAX) {
    pthread_mutex_unlock(&ui_lock);
    free(copy);
    __android_log_print(ANDROID_LOG_WARN, HEY_TAG_UI, "the event queue is full; dropped %s", json);
    return;
  }
  event_queue[(event_head + event_count) % HEY_UI_EVENT_MAX] = copy;
  event_count++;
  pthread_cond_broadcast(&event_cond);
  pthread_mutex_unlock(&ui_lock);
}

/* ---- the Hey side -------------------------------------------------------- */

int64_t hey_android_ui_begin(void) {
  description_free(&building);
  return 0;
}

static int id_valid(HeyNativeUtf8View id) {
  if (!id.data || id.length == 0 || id.length > HEY_UI_ID_MAX) return 0;
  for (size_t i = 0; i < id.length; i++) {
    char c = id.data[i];
    if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_')) return 0;
  }
  return 1;
}

int64_t hey_android_ui_text_row(HeyNativeUtf8View label, HeyNativeUtf8View id) {
  if (!id_valid(id)) {
    record_error("text_row: an id is 1 to %d letters, digits, '-' or '_'", HEY_UI_ID_MAX);
    return -1;
  }
  if (building.count == HEY_UI_ROW_MAX) {
    record_error("text_row: a screen holds at most %d rows", HEY_UI_ROW_MAX);
    return -1;
  }
  if (building.count == building.capacity) {
    size_t capacity = building.capacity ? building.capacity * 2 : 16;
    HeyUiRow *rows = realloc(building.rows, capacity * sizeof *rows);
    if (!rows) {
      record_error("text_row: out of memory");
      return -1;
    }
    building.rows = rows;
    building.capacity = capacity;
  }
  HeyUiRow row = {malloc(label.length + 1), label.length, malloc(id.length + 1)};
  if (!row.label || !row.id) {
    free(row.label);
    free(row.id);
    record_error("text_row: out of memory");
    return -1;
  }
  if (label.length) memcpy(row.label, label.data, label.length);
  row.label[label.length] = '\0';
  memcpy(row.id, id.data, id.length);
  row.id[id.length] = '\0';
  building.rows[building.count++] = row;
  return (int64_t)building.count;
}

int64_t hey_android_ui_commit(void) {
  pthread_mutex_lock(&ui_lock);
  if (!ui_attached || pipe_write < 0) {
    pthread_mutex_unlock(&ui_lock);
    description_free(&building);
    record_error("commit: no activity is attached");
    return -1;
  }
  description_free(&pending);
  pending = building;
  memset(&building, 0, sizeof building);
  pending_ready = 1;
  uint64_t sequence = ++commit_requested;
  pthread_mutex_unlock(&ui_lock);

  char byte = 'c';
  ssize_t wrote;
  do {
    wrote = write(pipe_write, &byte, 1);
  } while (wrote < 0 && errno == EINTR);
  /* EAGAIN means the pipe already holds unread bytes, and one of them will run on_pipe. */

  pthread_mutex_lock(&ui_lock);
  while (commit_done < sequence && ui_attached) pthread_cond_wait(&commit_cond, &ui_lock);
  int64_t result = commit_done >= sequence ? commit_result : -1;
  int attached = ui_attached;
  pthread_mutex_unlock(&ui_lock);
  if (result < 0 && !attached) record_error("commit: the activity was destroyed before the screen was drawn");
  return result;
}

HeyNativeUtf8View hey_android_ui_next_event(void) {
  pthread_mutex_lock(&ui_lock);
  while (event_count == 0 && ui_attached) pthread_cond_wait(&event_cond, &ui_lock);
  char *event = NULL;
  if (event_count > 0) {
    event = event_queue[event_head];
    event_queue[event_head] = NULL;
    event_head = (event_head + 1) % HEY_UI_EVENT_MAX;
    event_count--;
  }
  pthread_mutex_unlock(&ui_lock);
  /* No activity and nothing queued: the program is told the screen is gone, every time it asks. */
  if (!event) event = strdup("{\"kind\":\"destroy\"}");
  free(event_text);
  event_text = event;
  HeyNativeUtf8View view = {event_text ? event_text : "", event_text ? strlen(event_text) : 0};
  return view;
}

HeyNativeUtf8View hey_android_ui_errors(void) {
  pthread_mutex_lock(&ui_lock);
  memcpy(error_text, last_error, sizeof error_text);
  last_error[0] = '\0';
  pthread_mutex_unlock(&ui_lock);
  HeyNativeUtf8View view = {error_text, strlen(error_text)};
  return view;
}

/* ---- the UI thread: JNI -------------------------------------------------- */

/* Returns 1 and records the exception's text if a Java exception is pending. */
static int java_failed(JNIEnv *env, const char *where) {
  if (!(*env)->ExceptionCheck(env)) return 0;
  jthrowable thrown = (*env)->ExceptionOccurred(env);
  (*env)->ExceptionClear(env);
  char text[HEY_UI_ERROR_MAX - 256] = "an exception with no description";
  if (thrown && J.object_to_string) {
    jstring described = (jstring)(*env)->CallObjectMethod(env, thrown, J.object_to_string);
    if ((*env)->ExceptionCheck(env)) {
      (*env)->ExceptionClear(env);
    } else if (described) {
      const char *chars = (*env)->GetStringUTFChars(env, described, NULL);
      if (chars) {
        snprintf(text, sizeof text, "%s", chars);
        (*env)->ReleaseStringUTFChars(env, described, chars);
      }
      (*env)->DeleteLocalRef(env, described);
    }
  }
  if (thrown) (*env)->DeleteLocalRef(env, thrown);
  record_error("%s: %s", where, text);
  return 1;
}

static jclass global_class(JNIEnv *env, const char *name) {
  jclass local = (*env)->FindClass(env, name);
  if (java_failed(env, name) || !local) return NULL;
  jclass global = (jclass)(*env)->NewGlobalRef(env, local);
  (*env)->DeleteLocalRef(env, local);
  return global;
}

static jmethodID method(JNIEnv *env, jclass cls, const char *name, const char *signature) {
  if (!cls) return NULL;
  jmethodID id = (*env)->GetMethodID(env, cls, name, signature);
  if (java_failed(env, name)) return NULL;
  return id;
}

static int lookup(JNIEnv *env) {
  J.object = global_class(env, "java/lang/Object");
  J.object_to_string = method(env, J.object, "toString", "()Ljava/lang/String;");
  J.string = global_class(env, "java/lang/String");
  J.string_from_bytes = method(env, J.string, "<init>", "([BLjava/lang/String;)V");
  J.activity = global_class(env, "android/app/Activity");
  J.activity_get_window = method(env, J.activity, "getWindow", "()Landroid/view/Window;");
  J.activity_set_content_view = method(env, J.activity, "setContentView", "(Landroid/view/View;)V");
  J.activity_get_resources = method(env, J.activity, "getResources", "()Landroid/content/res/Resources;");
  J.window = global_class(env, "android/view/Window");
  J.window_take_surface = method(env, J.window, "takeSurface", "(Landroid/view/SurfaceHolder$Callback2;)V");
  J.window_set_format = method(env, J.window, "setFormat", "(I)V");
  J.resources = global_class(env, "android/content/res/Resources");
  J.resources_get_display_metrics = method(env, J.resources, "getDisplayMetrics", "()Landroid/util/DisplayMetrics;");
  J.display_metrics = global_class(env, "android/util/DisplayMetrics");
  if (J.display_metrics) {
    J.display_metrics_density = (*env)->GetFieldID(env, J.display_metrics, "density", "F");
    if (java_failed(env, "density")) J.display_metrics_density = NULL;
  }
  J.view = global_class(env, "android/view/View");
  J.view_set_background_color = method(env, J.view, "setBackgroundColor", "(I)V");
  J.view_set_padding = method(env, J.view, "setPadding", "(IIII)V");
  J.view_get_location_on_screen = method(env, J.view, "getLocationOnScreen", "([I)V");
  J.view_get_width = method(env, J.view, "getWidth", "()I");
  J.view_get_height = method(env, J.view, "getHeight", "()I");
  J.view_set_fits_system_windows = method(env, J.view, "setFitsSystemWindows", "(Z)V");
  J.view_group = global_class(env, "android/view/ViewGroup");
  J.view_group_add_view = method(env, J.view_group, "addView", "(Landroid/view/View;)V");
  J.view_group_get_child_count = method(env, J.view_group, "getChildCount", "()I");
  J.linear_layout = global_class(env, "android/widget/LinearLayout");
  J.linear_layout_init = method(env, J.linear_layout, "<init>", "(Landroid/content/Context;)V");
  J.linear_layout_set_orientation = method(env, J.linear_layout, "setOrientation", "(I)V");
  J.text_view = global_class(env, "android/widget/TextView");
  J.text_view_init = method(env, J.text_view, "<init>", "(Landroid/content/Context;)V");
  J.text_view_set_text = method(env, J.text_view, "setText", "(Ljava/lang/CharSequence;)V");
  J.text_view_set_text_size = method(env, J.text_view, "setTextSize", "(IF)V");
  J.text_view_set_text_color = method(env, J.text_view, "setTextColor", "(I)V");
  return J.object_to_string && J.string_from_bytes && J.activity_get_window && J.activity_set_content_view &&
         J.activity_get_resources && J.window_take_surface && J.window_set_format && J.resources_get_display_metrics &&
         J.display_metrics_density && J.view_set_background_color && J.view_set_padding && J.view_get_location_on_screen &&
         J.view_get_width && J.view_get_height && J.view_set_fits_system_windows && J.view_group_add_view &&
         J.view_group_get_child_count && J.linear_layout_init && J.linear_layout_set_orientation && J.text_view_init &&
         J.text_view_set_text && J.text_view_set_text_size && J.text_view_set_text_color;
}

static JNIEnv *ui_env(void) {
  if (!ui_activity) return NULL;
  JNIEnv *env = NULL;
  JavaVM *vm = ui_activity->vm;
  if ((*vm)->GetEnv(vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) return NULL;
  return env;
}

static void drop_rows(JNIEnv *env) {
  for (size_t i = 0; i < row_view_count; i++) {
    if (env && row_views[i]) (*env)->DeleteGlobalRef(env, row_views[i]);
    free(row_ids[i]);
  }
  free(row_views);
  free(row_ids);
  row_views = NULL;
  row_ids = NULL;
  row_view_count = 0;
}

/* Gives the window's surface back to the View tree, and reads the display density. */
static int release_surface(JNIEnv *env) {
  jobject window = (*env)->CallObjectMethod(env, activity_ref, J.activity_get_window);
  if (java_failed(env, "getWindow") || !window) return 0;
#ifdef HEY_ANDROID_UI_CONTROL_SURFACE_TAKEN
  __android_log_write(ANDROID_LOG_WARN, HEY_TAG_UI,
                      "NEGATIVE CONTROL: the surface stays taken by NativeActivity, so Views must not draw");
#else
  (*env)->CallVoidMethod(env, window, J.window_take_surface, NULL);
  if (java_failed(env, "takeSurface(null)")) return 0;
#endif
  (*env)->CallVoidMethod(env, window, J.window_set_format, 1 /* PixelFormat.RGBA_8888 */);
  if (java_failed(env, "setFormat")) return 0;
  (*env)->DeleteLocalRef(env, window);
  jobject resources = (*env)->CallObjectMethod(env, activity_ref, J.activity_get_resources);
  if (java_failed(env, "getResources") || !resources) return 0;
  jobject metrics = (*env)->CallObjectMethod(env, resources, J.resources_get_display_metrics);
  if (java_failed(env, "getDisplayMetrics") || !metrics) return 0;
  density = (*env)->GetFloatField(env, metrics, J.display_metrics_density);
  if (density <= 0.0f) density = 1.0f;
  (*env)->DeleteLocalRef(env, metrics);
  (*env)->DeleteLocalRef(env, resources);
  return 1;
}

static jstring java_string(JNIEnv *env, const char *bytes, size_t length, jstring charset) {
  jbyteArray array = (*env)->NewByteArray(env, (jsize)length);
  if (java_failed(env, "NewByteArray") || !array) return NULL;
  (*env)->SetByteArrayRegion(env, array, 0, (jsize)length, (const jbyte *)bytes);
  jstring text = (jstring)(*env)->NewObject(env, J.string, J.string_from_bytes, array, charset);
  (*env)->DeleteLocalRef(env, array);
  if (java_failed(env, "new String(UTF-8)")) return NULL;
  return text;
}

/* Builds the View tree for a description and puts it on screen. Returns the number of
 * child views the root reports, read back through JNI, or -1. */
static int64_t build_screen(JNIEnv *env, const HeyUiDescription *description) {
  if ((*env)->PushLocalFrame(env, 64) != 0) {
    java_failed(env, "PushLocalFrame");
    return -1;
  }
  jobject *views = calloc(description->count ? description->count : 1, sizeof *views);
  char **ids = calloc(description->count ? description->count : 1, sizeof *ids);
  int64_t result = -1;
  size_t made = 0;
  if (!views || !ids) {
    record_error("commit: out of memory");
    goto done;
  }
  jobject root = (*env)->NewObject(env, J.linear_layout, J.linear_layout_init, activity_ref);
  if (java_failed(env, "new LinearLayout") || !root) goto done;
  (*env)->CallVoidMethod(env, root, J.linear_layout_set_orientation, 1 /* VERTICAL */);
  (*env)->CallVoidMethod(env, root, J.view_set_background_color, HEY_UI_ROOT_COLOR);
  (*env)->CallVoidMethod(env, root, J.view_set_fits_system_windows, JNI_TRUE);
  if (java_failed(env, "LinearLayout setup")) goto done;
  jstring charset = (*env)->NewStringUTF(env, "UTF-8");
  if (java_failed(env, "NewStringUTF") || !charset) goto done;
  jint pad = (jint)(HEY_UI_PAD_DP * density + 0.5f);
  for (size_t i = 0; i < description->count; i++) {
    const HeyUiRow *row = &description->rows[i];
    jstring text = java_string(env, row->label, row->label_length, charset);
    if (!text) goto done;
    jobject view = (*env)->NewObject(env, J.text_view, J.text_view_init, activity_ref);
    if (java_failed(env, "new TextView") || !view) goto done;
    (*env)->CallVoidMethod(env, view, J.text_view_set_text, text);
    (*env)->CallVoidMethod(env, view, J.text_view_set_text_size, 2 /* TypedValue.COMPLEX_UNIT_SP */, HEY_UI_TEXT_SP);
    (*env)->CallVoidMethod(env, view, J.text_view_set_text_color, HEY_UI_TEXT_COLOR);
    (*env)->CallVoidMethod(env, view, J.view_set_padding, pad, pad, pad, pad);
    (*env)->CallVoidMethod(env, view, J.view_set_background_color, i % 2 ? HEY_UI_ODD_ROW_COLOR : HEY_UI_EVEN_ROW_COLOR);
    (*env)->CallVoidMethod(env, root, J.view_group_add_view, view);
    if (java_failed(env, row->id)) goto done;
    views[i] = (*env)->NewGlobalRef(env, view);
    ids[i] = strdup(row->id);
    made = i + 1;
    (*env)->DeleteLocalRef(env, view);
    (*env)->DeleteLocalRef(env, text);
  }
  (*env)->CallVoidMethod(env, activity_ref, J.activity_set_content_view, root);
  if (java_failed(env, "setContentView")) goto done;
  jint children = (*env)->CallIntMethod(env, root, J.view_group_get_child_count);
  if (java_failed(env, "getChildCount")) goto done;
  drop_rows(env);
  row_views = views;
  row_ids = ids;
  row_view_count = description->count;
  views = NULL;
  ids = NULL;
  made = 0;
  result = children;
  __android_log_print(ANDROID_LOG_INFO, HEY_TAG_UI, "commit: %zu rows described, %d views on screen", description->count, (int)children);

done:
  for (size_t i = 0; i < made; i++) {
    if (views[i]) (*env)->DeleteGlobalRef(env, views[i]);
    free(ids[i]);
  }
  free(views);
  free(ids);
  (*env)->PopLocalFrame(env, NULL);
  return result;
}

static int on_pipe(int fd, int events, void *data) {
  (void)events;
  (void)data;
  char drain[64];
  while (read(fd, drain, sizeof drain) > 0) {
  }
  pthread_mutex_lock(&ui_lock);
  HeyUiDescription description = pending;
  int ready = pending_ready;
  memset(&pending, 0, sizeof pending);
  pending_ready = 0;
  uint64_t sequence = commit_requested;
  pthread_mutex_unlock(&ui_lock);
  if (!ready) return 1;

  int64_t result = -1;
  JNIEnv *env = ui_env();
  if (env && activity_ref && J.ready) {
    result = build_screen(env, &description);
  } else {
    record_error("commit: no activity is attached on the UI thread");
  }
  description_free(&description);
  pthread_mutex_lock(&ui_lock);
  commit_done = sequence;
  commit_result = result;
  pthread_cond_broadcast(&commit_cond);
  pthread_mutex_unlock(&ui_lock);
  return 1;
}

/* ---- the UI thread: taps -------------------------------------------------- */

static void hit_test(float x, float y) {
  JNIEnv *env = ui_env();
  if (!env) return;
  jintArray location = (*env)->NewIntArray(env, 2);
  if (java_failed(env, "NewIntArray") || !location) return;
  for (size_t i = 0; i < row_view_count; i++) {
    (*env)->CallVoidMethod(env, row_views[i], J.view_get_location_on_screen, location);
    jint width = (*env)->CallIntMethod(env, row_views[i], J.view_get_width);
    jint height = (*env)->CallIntMethod(env, row_views[i], J.view_get_height);
    if (java_failed(env, "row bounds")) break;
    jint xy[2] = {0, 0};
    (*env)->GetIntArrayRegion(env, location, 0, 2, xy);
    if (x >= xy[0] && x < xy[0] + width && y >= xy[1] && y < xy[1] + height) {
      char json[HEY_UI_ID_MAX + 32];
      snprintf(json, sizeof json, "{\"kind\":\"tap\",\"id\":\"%s\"}", row_ids[i]);
      __android_log_print(ANDROID_LOG_INFO, HEY_TAG_UI, "tap at (%.0f, %.0f) on %s [%d,%d %dx%d]", x, y, row_ids[i],
                          (int)xy[0], (int)xy[1], (int)width, (int)height);
      (*env)->DeleteLocalRef(env, location);
      push_event(json);
      return;
    }
  }
  (*env)->DeleteLocalRef(env, location);
  __android_log_print(ANDROID_LOG_INFO, HEY_TAG_UI, "tap at (%.0f, %.0f) on no row", x, y);
}

static void on_motion(const AInputEvent *event) {
  int action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
  float x = AMotionEvent_getRawX(event, 0);
  float y = AMotionEvent_getRawY(event, 0);
  float slop = HEY_UI_TAP_SLOP_DP * density;
  if (action == AMOTION_EVENT_ACTION_DOWN) {
    touch_down = 1;
    down_x = x;
    down_y = y;
  } else if (action == AMOTION_EVENT_ACTION_UP) {
    if (touch_down && fabsf(x - down_x) <= slop && fabsf(y - down_y) <= slop) hit_test(x, y);
    touch_down = 0;
  } else if (action == AMOTION_EVENT_ACTION_CANCEL || action == AMOTION_EVENT_ACTION_POINTER_DOWN) {
    touch_down = 0;
  }
}

static int on_input(int fd, int events, void *data) {
  (void)fd;
  (void)events;
  AInputQueue *queue = (AInputQueue *)data;
  AInputEvent *event = NULL;
  while (AInputQueue_getEvent(queue, &event) >= 0) {
    if (AInputQueue_preDispatchEvent(queue, event)) continue;
    int handled = 0;
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
      on_motion(event);
      handled = 1;
    }
    /* Keys are not handled here, so the framework's own handling (back) still runs. */
    AInputQueue_finishEvent(queue, event, handled);
  }
  return 1;
}

void hey_android_ui_input_queue_created(ANativeActivity *activity, AInputQueue *queue) {
  (void)activity;
  ALooper *looper = ALooper_forThread();
  if (looper) AInputQueue_attachLooper(queue, looper, 1, on_input, queue);
}

void hey_android_ui_input_queue_destroyed(ANativeActivity *activity, AInputQueue *queue) {
  (void)activity;
  AInputQueue_detachLooper(queue);
  touch_down = 0;
}

/* ---- the UI thread: the activity ------------------------------------------ */

void hey_android_ui_attach(ANativeActivity *activity) {
  JNIEnv *env = activity->env;
  ui_activity = activity;
  ui_looper = ALooper_forThread();
  if (activity_ref) (*env)->DeleteGlobalRef(env, activity_ref);
  activity_ref = (*env)->NewGlobalRef(env, activity->clazz);
  if (!J.ready) J.ready = lookup(env);
  if (pipe_read < 0) {
    int ends[2];
    if (pipe2(ends, O_CLOEXEC | O_NONBLOCK) == 0) {
      pipe_read = ends[0];
      pipe_write = ends[1];
    } else {
      record_error("attach: pipe2 failed: %s", strerror(errno));
    }
  }
  int ok = J.ready && ui_looper && pipe_read >= 0;
  if (ok && ALooper_addFd(ui_looper, pipe_read, ALOOPER_POLL_CALLBACK, ALOOPER_EVENT_INPUT, on_pipe, NULL) != 1) {
    record_error("attach: ALooper_addFd failed");
    ok = 0;
  }
  if (ok && !release_surface(env)) ok = 0;
  if (!ok) {
    __android_log_write(ANDROID_LOG_ERROR, HEY_TAG_UI, "the UI could not be attached; next_event reports destroy");
    return;
  }
  pthread_mutex_lock(&ui_lock);
  ui_attached = 1;
  pthread_mutex_unlock(&ui_lock);
  __android_log_print(ANDROID_LOG_INFO, HEY_TAG_UI, "attached: surface released to the View tree, density %.2f", density);
  push_event("{\"kind\":\"start\"}");
}

void hey_android_ui_detach(ANativeActivity *activity) {
  if (activity != ui_activity) return;
  JNIEnv *env = activity->env;
  pthread_mutex_lock(&ui_lock);
  int was_attached = ui_attached;
  ui_attached = 0;
  pthread_cond_broadcast(&commit_cond);
  pthread_mutex_unlock(&ui_lock);
  if (was_attached) push_event("{\"kind\":\"destroy\"}");
  if (ui_looper && pipe_read >= 0) ALooper_removeFd(ui_looper, pipe_read);
  drop_rows(env);
  if (activity_ref) (*env)->DeleteGlobalRef(env, activity_ref);
  activity_ref = NULL;
  ui_activity = NULL;
  ui_looper = NULL;
}
