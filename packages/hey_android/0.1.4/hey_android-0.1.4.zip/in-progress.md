# In progress

The 0.1.4 package compatibility release is ready for validation and immutable publication.

- Publish `hey_mobile` so `hey_android` can declare a locked dependency.
- Move Android host renderer fixtures out of the Hey core repository without losing executable target coverage.
