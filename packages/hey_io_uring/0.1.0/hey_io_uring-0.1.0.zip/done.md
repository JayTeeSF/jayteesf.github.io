# Done

- 0.1.0: the io_uring backend of Hey's batched TCP loop: hey_epoll's API and
  native function table; multishot accept into the fixed-file table
  (`IORING_FILE_INDEX_ALLOC`); multishot receive over a provided buffer ring;
  replies queued by `send()` and submitted with the next `wait()` (one
  `io_uring_enter` per batch), one SEND in flight per connection, short sends
  resumed; NODROP required and the CQ overflow backlog flushed in every
  drain; linked cancel+close of fixed slots, stale completions recognised by
  generation, in-flight send buffers kept until their completion; single-issuer
  ring with deferred task work where available; the CQ sized to twice the listen queue and the accept armed only into an empty CQ (a Linux 6.8 issue-time multishot accept loses a connection when the CQ fills; measured); named refusals at open
  (blocked, disabled, not in kernel, kernel too old, missing feature, no
  memory) and `IoUring.available()`; liburing 2.8 linked statically.
  Specs: hey_epoll's loop contract, a 300-connection small-ring stress (SQ full,
  CQ overflow, buffer ring dry), an 8 MiB short-send reply, peer close, the
  refusals (and the seccomp one under Docker's default profile), with nine
  negative controls.
