// HeyIOSCarPlay: the CarPlay audio scene, an extension of hey_ios's api_screens host.
//
// hey_ios's build tool links it with `--extension <hey_carplay root>`, reading
// ios-extension.json: this source, the CarPlay framework, the
// com.apple.developer.carplay-audio entitlement, and the Info.plist scene that
// names HeyIOSCarPlaySceneDelegate for CPTemplateApplicationSceneSessionRoleApplication
// (carplay.hey states the same contract in Hey, and bin/package-check holds the two
// together). On connect it shows a CPListTemplate of the host's audio feed
// (HeyIOSApiHostLoadAudioFeed: what the phone's Listen tab lists), plays a chosen
// row through HeyIOSAudio and pushes the shared CPNowPlayingTemplate. It re-reads
// the feed whenever the host posts HeyIOSApiHostAudioFeedDidChange.
//
// THE MODULE DECIDES NOTHING ABOUT WHAT MAY PLAY. The feed is whatever the
// app's server already filtered; a row survives here only if it has the shape
// HeyIOSAudio can play (HeyIOSAudioRowPlayable).
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// The rows that survive the shape check, per section, empty sections dropped.
NSArray<NSDictionary *> *HeyIOSCarPlayPlayableSections(NSArray<NSDictionary *> *sections, BOOL appleMusicAvailable);

// Re-read the feed on every connected car screen. The host's
// HeyIOSApiHostAudioFeedDidChange does this already; call it for anything else.
void HeyIOSCarPlayReload(void);

NS_ASSUME_NONNULL_END
