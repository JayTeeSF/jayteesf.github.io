# Done

- v0.1.0 package boundary, modules, tests, toolchain installer, emulator/device launcher, docs, packaging, and LLM handoff.
- Fixed the macOS installer so `sdkmanager` and `avdmanager` share the same exported Android SDK root before AVD creation.
- Fixed AVD creation by installing Android command-line tools inside the selected SDK and invoking those SDK-local binaries; Homebrew's avdmanager no longer resolves packages from its separate root.

## 0.3.0 (2026-09-13): Views drawn by a Hey program, and a tap, with no Java in any form

- Measured first: on NativeActivity, Views set with `setContentView` are laid
  out but never drawn while NativeActivity holds the window's surface. After
  `getWindow().takeSurface(null)` through JNI they draw.
- Measured: `Native.open` of the app's own `libhey_app.so` works on the device,
  by soname and by the `dladdr` path.
- `native/ui`: five C shims declared in `hey.native.json` and wrapped by
  `hey native`: `begin`, `text_row`, `commit`, `next_event` (`thread_safe`)
  and `errors`. Every JNI call runs on the UI thread through an `ALooper` pipe;
  the UI thread never waits on Hey.
- Taps with no dex: NativeActivity's input queue, hit-tested against the rows'
  View bounds, queued as `{"kind":"tap","id":"row-3"}`.
- `src/android_ui.hey` (`HeyAndroidUi`) and `examples/rows.hey`: a `program`
  that loops on `next_event`, draws rows and shows "Row N was tapped".
  `examples/rows_error.hey` fails in the loop on purpose.
- The glue attaches the shims, forwards the input queue, and ends the process
  once the program and the activity are both gone, in either order. The
  manifest uses a light theme with no action bar.
- `tools/hey-android-app.sh --ui` waits for the first commit instead of the
  program's end; the receipt records commits and views on screen.
  `HEY_ANDROID_NEGATIVE_CONTROL=surface-taken` builds the drawing control.
- New specs, each check with a negative control:
  `specs/android_ui_host_spec.sh` (the Hey side on the Mac against
  `specs/support/fake_ui.c`) and `specs/android_ui_emulator_spec.sh` (pixels
  drawn, a tap changes the text, rotation, a second launch, an error in the
  loop, no dex).
- Docs: `docs/ROADMAP.md` corrects phase 2 (no library entry point or function
  pointer needed; the Proxy idea was wrong; no attach rule while JNI stays on
  the UI thread). It records the Maintainer's rule of no Java in any form, and
  what that rule costs on Android. It also lists the LLVM-lane miscompiles found
  while building the slice. `docs/PHASE2_FEASIBILITY.md` is committed with the
  withdrawn in-memory dex plan marked.

## 0.2.0 (2026-09-13): a Hey program with the runtime, on Android 16, with no Java or Kotlin

- `tools/hey-android-app.sh` builds a Hey program into a signed APK:
  - heyc's LLVM IR, compiled by NDK r28 clang for `aarch64-linux-android35`;
  - the unmodified Hey runtime from HEY_ROOT with the package's Android profile;
  - one 16 KB-aligned library;
  - aapt2, zipalign `-P 16` and apksigner.
  - The manifest has `hasCode="false"` and uses `android.app.NativeActivity`.
  - It installs and launches with adb, then writes a receipt.
- `native/glue`, the entry point:
  - the program runs on an 8 MiB thread, and so do the runtime's own threads;
  - stdout and stderr go to logcat;
  - `exit()` finishes the activity;
  - one program per process.
- `native/runtime_profile` gives the runtime real secure random, constant-time
  compare and SHA-256 (vendored from Brad Conte, public domain) through its
  platform-crypto seam. TLS, AEAD, scrypt and Argon2id report named
  unavailable errors.
- Build isolation:
  - every compiler-search variable is cleared, and `PATH` is reduced;
  - the include search path goes into the receipt, and any host directory
    fails the build.
- `bin/android-doctor` checks and prints the new pins and the Hey checkout's
  identity: platform 36, build-tools 36.0.0, NDK 28.2.13676358, the API 36
  Play image, JDK 17. It fails with the exact sdkmanager line for anything
  missing.
- `tools/hey-android-emulator.sh` owns the dedicated AVD `hey_android_API_36`:
  - it boots headless;
  - it shuts down and waits until no emulator process remains.
- `bin/check` runs the Hey specs and five shell specs: pins, SHA-256 on the
  host, the doctor, the build lane and the emulator. Every check has a
  negative control:
  - a Mac target triple is refused;
  - a Homebrew-contaminated runtime is caught;
  - a 4 KB library is refused;
  - a dex in the APK is refused;
  - `hasCode="true"` is refused;
  - a wrong digest fails;
  - an API 34 SDK is refused;
  - a build linked without `--wrap=exit` fails.
- On the emulator:
  - `hello_runtime`'s logcat output equals the Mac run byte for byte;
  - the NIST vectors pass through the runtime;
  - a runtime error ends the activity with no crash.
- Removed the Gradle lane: `tooling/01-*`, `tooling/02-*` and their spec, with
  the API 34, AGP 8.5.2 and NDK 26.1 pins.
