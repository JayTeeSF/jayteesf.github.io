# Interoperability fixtures

`bitmapwithoutruns.bin` and `bitmapwithruns.bin` are the reference files from
[RoaringFormatSpec](https://github.com/RoaringBitmap/RoaringFormatSpec) `testdata/`,
commit `e1b736158c29d077f37bd8a969bcc78995f59377`, written by the Java implementation.
They hold every multiple of 1000 in [0, 100000), `3*k` for every `k` in [100000, 200000)
and every value in [700000, 800000): 200,100 values. Apache License 2.0, see
`LICENSE-RoaringFormatSpec`.
