# PROMPT — hey_cache

## What this package is

A read-through cache chain: an ordered list of layers, first live hit wins,
a miss falls through, and the last resort is calling the application. It is
the role Redis usually plays, not the protocol.

Layer 0 is a process-local memory hash living inside the cache value.
Layers 1..N are INJECTED bindings of `{handle, fetch, write, erase}` — which
is `hey_record`'s store surface, so a file / SQLite / MySQL layer costs this
package no SQL, no schema and no connection handling.

## Rules for anyone changing it

1. **Zero dependencies.** Never import `hey_record`, `hey_sqlite3` or
   `hey_mysql`. If a layer needs a backing store, it is handed one.
   `bin/package-check` fails if `dependencies` is non-empty.
2. **Both lanes, every time.** `bin/check` gate 2b runs every spec COMPILED
   against its own `expect stdout` block (`heyc build` does NOT enforce it),
   and gate 3 builds AND interprets
   `tools/lane_receipt.hey` and diffs the stdouts. This package has measured
   the lanes disagreeing in both directions; interpreter-green is not green.
3. **Do not name a record field the same as the variable holding it.**
   `layer.layer` cannot be lowered. The discriminator is `backing`.
4. **Do not use `del(record, key)`.** It does not lower. Use
   `hey_cache_without_key_value`.
5. **Do not name a local after a builtin.** A local called `read` shadows the
   `read` builtin and crashes *stdlib Files* on the interpreter. Same family:
   `get`, `count`, `entries`, `exists?`, `values`, `keys`, `first`, `write`.
   Every private helper here is prefixed `hey_cache_`.
6. **Pass callables by bare name.** `bind()` does not lower.
6b. **Never return a bare `nil` from a callable.** In the compiled lane it
   arrives as the integer `0`. Absence is `HeyCache.no_value()`, a record.
7. **Prove invalidation with `probe`, layer by layer.** A chain read cannot
   distinguish "deleted everywhere" from "deleted at layer 0 and shadowed".
8. **A layer failure is not a miss.** Only `not_found` is a miss.
9. **Break it on purpose before trusting a green.** `docs/TESTING.md` lists
   the defects each gate has been confirmed to catch.

## The single version literal

`hey_cache_version_value()` in `cache.hey`. `bin/check` greps it against
`VERSION` and asserts there is exactly one.
