# hey_mobile

Cross-platform application primitives for ordinary Hey mobile apps. It owns lifecycle state transitions, platform-neutral screen/action/accessibility descriptions, QR/server enrollment payload validation, and development-vs-release transport policy. It does not own UIKit, Android Views/Compose, cryptographic keys, product screens, business data, signing, installation, or deployment.

`hey_mobile` is the interface layer above independently versioned `hey_ios` and future `hey_android` adapters. The CLI porcelain remains in the Hey language repository (`hey mobile ios ...`, `hey mobile android ...`).

## Screens bound to JSON routes (`api_screens`, 0.2.0)

`api_screens.hey` (module `HeyMobileApiScreens`) describes a whole app in ordinary Hey: every screen, the route that feeds it, which response fields a row shows, and exactly what each button, form and row action sends. A native host executes the description (`hey_ios` 0.2.0 ships `native/HeyIOSApiHost` for iOS); the host holds no product knowledge, so one description serves every platform.

```hey
import 'pkg:hey_mobile@0.3.0/api_screens'

let row = {title: 'title'}
let library = HeyMobileApiScreens.list_screen('library', 'Library', HeyMobileApiScreens.tab('Library', 'books.vertical'),
  [HeyMobileApiScreens.section('Recent', HeyMobileApiScreens.route('GET', '/v1/items', nil), 'items', row, nil, 'Nothing saved yet')])
let signin = HeyMobileApiScreens.form_screen('signin', 'Sign in', nil, [HeyMobileApiScreens.field('username', 'Name', 'text', true)],
  {title: 'Sign in', request: HeyMobileApiScreens.route('POST', '/v1/session', {username: '$username'})})
let session = {sign_in_screen: 'signin', check: HeyMobileApiScreens.route('GET', '/v1/session', nil), sign_out: HeyMobileApiScreens.route('POST', '/v1/session/revoke', {})}
let app = {schema: HeyMobileApiScreens.schema_version(), tabs: ['library'], session: session, screens: [library, signin]}
HeyMobileApiScreens.problems(app)   # [] when every tab, select and path is sound
HeyMobileApiScreens.routes(app)     # every route the app calls, for a server-side contract check
```

`problems` names each fault (a tab naming no screen, a relative path, a dangling select); `routes` lists every route a description can call, from sections, actions, menus, row actions, forms, audio position reports and the share extension.

## Levels, served descriptions and conformance (0.3.0)

A renderer declares a level, the highest level of the contract it draws, and a server answers `HeyMobileLevels.for_level(app, platform, level)`: the description with anything that level cannot draw removed and spelled for it. Level 2 names icons and file kinds for any platform (`icons.hey`) and requires a renderer to hide every kind it does not know, never sending a request for an action it does not recognise. `values.hey` is the reference evaluator for the value language and `conformance/` holds the vectors every renderer must pass. The rules a renderer keeps, and how a served copy, a stored copy and the baked copy take turns, are in `docs/RENDERERS.md`.

```hey
import 'pkg:hey_mobile@0.3.0/levels'

let answer = HeyMobileLevels.for_level(app, 'ios', 2)
HeyMobileLevels.problems_for_level(answer, 2)   # [] when level 2 can draw all of it
```

## Check and release

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
bin/release
```

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_mobile`.
