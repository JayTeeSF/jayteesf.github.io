# hey_windows

A Windows desktop window for a Hey web application. One Win32 window with its
own taskbar entry shows the application through Microsoft Edge WebView2. The
manifest (title, origin, size, minimum size, data folder) is validated by Hey on
the build host and compiled into the native host; the executable is cross-built
with mingw-w64 in a container and smoke-tested under Wine. No Windows machine
is needed to build it; a real PC is needed to see the browser part, because
WebView2 does not exist under Wine.

Why a window and not a tab: the owner's customers on Windows said another
browser tab is "a nightmare ... another list to have to navigate to (or forget
about)". A window on the taskbar is found again.

Why not Hey on Windows: Hey does not run on Windows yet (its runtime platform
surface is unported; the compiler can emit COFF objects but cannot yet link a
running program). So nothing inside the executable is Hey. The Hey part is the
build-host tool, the same shape as `hey_ios`, whose screens are described at
build time and drawn by a native host. When Hey targets Windows, the host can
render `hey_mobile` descriptions natively; see docs/ROADMAP.md.

To ship any Hey app on Windows (an installer, signing, a download page on your
site), describe it once and run one command. The illustrated guide, with what
is required, what is optional and the pros and cons of each step, is
docs/GETTING_STARTED.html:

```sh
bin/hey-windows-app init    path/to/app     # questionnaire: writes hey-windows-app.json
bin/hey-windows-app check   path/to/app     # build, Wine run, installer install/uninstall test
bin/hey-windows-app publish path/to/app     # sign, release, put it on your site's apps/ page
```

The commands are one Hey program (tools/hey_windows_app.hey); the files in
bin/ only start Hey programs. The package's own checks:

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
bin/check                 # specs, header currency, loader identity, the example app end to end
```

Read docs/DESIGN.md for how the pieces fit and docs/TESTING.md for what each
check proves and what only a PC can prove.

Third party: `third_party/webview2` is Microsoft's WebView2 SDK 1.0.2903.40
(header and x64 loader) under its BSD-style license, kept beside the code with
its LICENSE.txt and NOTICE.txt.
