# hey_container

Docker image generation for [`hey_web`](../hey_web) applications.

Four `HEY_ENV` values. **Three images.** `staging` and `production` share
one byte-identical artifact, because staging exists to exercise the thing
that goes to production, and an artifact built separately for staging
exercises nothing.

```sh
./bin/hey-container init --app /path/to/app --env production
docker build -f /path/to/app/Dockerfile.release \
  --build-arg HEY_IMAGE=<hey-linux-toolchain-image> \
  -t myapp:release /path/to/app
docker run -d -e HEY_ENV=production -e DATABASE_URL=... -p 3000:3000 myapp:release
```

---

## READ THIS FIRST: `bind()` handlers do not work, in either lane

**Measured 2026-07-31, hey 0.99.474a.** If your app registers routes with
`bind(Controller.action, state)`, this package will **refuse to build it**.
That is deliberate, and it is not conservatism — there is currently no
lane in which a bound handler serves a request.

| lane | what happens to a bound handler |
|---|---|
| **compiled** | `hey error: get string-key fast path expects a JSON object; got nil for key status` |
| **interpreted** | **HTTP 200 with an EMPTY BODY.** The handler never runs. |

The interpreted failure is the dangerous one. Measured, three routes in
one server:

```
GET /one    (fn one(request), unbound)        200  {"who":"one-arg-unbound"}
GET /bound  (bind(P.two, 'BOUNDSTATE'))       200  <EMPTY BODY>
GET /two    (fn two(state, request))          200  <EMPTY BODY>
```

with `web handler P.two expects one request argument` on stderr.

**Two causes, one symptom.** `Web.serve` invokes a handler only if it
declares exactly ONE parameter; it never consults how many arguments a
callable already has bound. So `/bound` (residual arity 1) and `/two`
(unbound, arity 2) are rejected *identically* — the arity guard is blind
to binding. Separately, in the compiled lane a callable passed into a
stdlib module function degrades to its name string, and for a bound
callable the recorded name is the local variable rather than the
function.

Every status check passes. Every health probe passes. Kamal would report
a clean deploy over an application serving nothing. This is why the
package refuses rather than warns.

### Why this design will not need redoing when the defect is fixed

Nothing here assumes the defect is permanent:

- both runtime stages are **always** emitted into the generated
  Dockerfile;
- the lane is one build arg, `ARG HEY_LANE`, selecting the final stage
  via `FROM runtime-${HEY_LANE} AS final`;
- the compiled lane is fully generated, and blocked only by the
  preflight.

When `bind()` works compiled, the change is: delete the refusal in
`src/lane.hey`, and flip `HeyContainer.defaults().lane` to `'compiled'`.
No stage moves. No app is re-authored.

### The escape hatch

`--allow-bind` builds anyway and prints a warning naming the failure
mode. Use it only if you know the bound routes are unreachable.

### The cost of the interpreted default

The default lane is `interpreted`, so the runtime image carries the Hey
runtime and dispatches through the interpreter rather than running native
code. **This has not been benchmarked here** — see *What is not proven*.
It is a correctness-over-speed choice that the maintainer can reverse
with one string once the compiled lane is trustworthy.

---

## The environment matrix

| `HEY_ENV` | image target | source | toolchain in runtime | database |
|---|---|---|---|---|
| `development` | `development` | **bind-mounted**, not copied | yes | yours |
| `test` | `test` | copied | yes | disposable, `/tmp` |
| `staging` | **`release`** | copied | interpreted lane only | injected |
| `production` | **`release`** | copied | interpreted lane only | injected |

`development` and `test` are structurally different images, not
`release` with a different variable:

- **development** never runs `COPY . .`. You mount your working tree, so
  an edit is live without a rebuild. It keeps the toolchain and runs one
  worker with no health check — a dev container killed by a failing probe
  while you sit in a debugger is a nuisance, and nothing schedules it.
- **test** copies the source so a CI run needs nothing but the image, and
  points `HEY_DATABASE_URL` at a path under `/tmp` that dies with the
  container. A test image able to reach a real database is a test image
  able to destroy one.

### Why staging and production cannot diverge

Not a convention — an absence of code:

```hey
fn development(options)   # takes options
fn test(options)          # takes options
fn release(options)       # takes options, and NO ENVIRONMENT
```

`release()` cannot observe whether it is being rendered for staging or
production, so its output cannot differ between them. There is no
expression anywhere in the package whose value varies between the two,
and the generated Dockerfile declares **no `ARG HEY_ENV`** — the
mechanism by which someone *would* bake an environment in.

`HEY_ENV` is set at run time only:

```sh
docker run -e HEY_ENV=staging    -e DATABASE_URL=... myapp:release
docker run -e HEY_ENV=production -e DATABASE_URL=... myapp:release
```

Proven, not asserted (`bin/check-docker`):

```
staging container body:    {"status":"ok","environment":"staging","fixture":"hey_container"}
staging image:    sha256:7af1bbfbd32629fdfc3a3200941f686c99e2b2627253df41e0ba7d1120932bea
production image: sha256:7af1bbfbd32629fdfc3a3200941f686c99e2b2627253df41e0ba7d1120932bea
same image, HEY_ENV=staging honoured at run time ok
```

---

## The CLI

```
hey-container dockerfile  --env ENV | --target TARGET  [--out FILE] [--lane LANE]
hey-container dockerignore [--out FILE]
hey-container preflight   --app DIR [--lane LANE] [--allow-bind]
hey-container plan        --env ENV
hey-container init        --app DIR --env ENV
hey-container version
```

### Every knob

| flag | default | what it does |
|---|---|---|
| `--app DIR` | `.` | application directory to scan / write into |
| `--env ENV` | — | `development`, `test`, `staging`, `production` |
| `--target T` | — | `development`, `test`, `release` (bypasses the env mapping) |
| `--lane LANE` | `interpreted` | `interpreted` or `compiled`; sets `ARG HEY_LANE` |
| `--allow-bind` | off | build despite `bind()` sites, with a warning |
| `--entry FILE` | `app.hey` | program entry point |
| `--name NAME` | `app` | compiled binary name |
| `--port N` | `3000` | listen port; also `EXPOSE` and the health probe |
| `--workers N` | `4` | `HEY_WORKERS` default |
| `--health-path P` | `/up` | the `HEALTHCHECK` path |
| `--hey-image REF` | `hey-toolchain:0.99.382a` | Hey **Linux** toolchain image |
| `--runtime-base REF` | `debian:bookworm-slim` | runtime base image |
| `--user NAME` | `hey` | non-root run user |
| `--out FILE` | stdout | write here instead of printing |

### Runtime environment variables

Read by the image, never baked in: `HEY_ENV`, `HEY_HOST` (default
`0.0.0.0`), `HEY_PORT`, `HEY_WORKERS`, `HEY_CACHE_HOME`. Everything else
your app needs — database URLs, secrets, hostnames — is your app's to
read, and must be injected at run time.

### Exit codes

**Hey has no exit-code builtin.** `fail` is the only non-zero exit and it
always yields **70**. So:

```
proceed          -> exit 0
usage error      -> exit 70, reason printed
refused (bind)   -> exit 70, reason printed
```

A script distinguishing a refusal from a usage error must read the
printed reason. `[ $? -eq 78 ]` will never be true.

---

## The `.dockerignore` is a security control

A build context is **not** a git checkout: it includes git-ignored files.
The working `.env` that never reaches a commit reaches the image, and
stays readable in a registry-pushed layer forever, whatever a later
`RUN rm` does. Shipping `.git` ships every secret the repo ever held.

Excluded: `.env*`, `*.key`, `*.pem`, `*.p12`, `id_rsa*`, `id_ed25519*`,
`.ssh/`, `.aws/`, `secrets/`, `.netrc`, `.git`, `build/`, `dist/`,
`tmp/`, `.hey/downloads/`, `.hey/native/`, `*.zip`, `*.so`, `*.dylib`,
`db/*.db`.

**Deliberately NOT excluded: `.hey/packages/`** — the resolved dependency
tree the build needs. Excluding it produces a missing-module error deep
in a build that reads like a code problem. `.hey/native/` *is* excluded
because those are host-built libraries of the wrong architecture for a
Linux image.

---

## Kamal compatibility

This package is **not** a deploy tool and does not want to be. It aims to
produce an image Kamal could drive:

- a plain multi-stage `Dockerfile`, no bespoke build wrapper;
- pushable to any registry;
- a `HEALTHCHECK` on `/up`, reaching `healthy` (verified: `healthy` after
  3s);
- configuration by environment variable only;
- **secrets injected at run time, never baked in** — no `ARG` for a
  password, no `COPY` of a `.env`;
- logs to stdout;
- `tini` as PID 1 so `SIGTERM` reaches the server (verified: `docker
  stop` returns in 0s, not the 10s kill timeout);
- runs as a non-root user.

### Your app MUST answer the health path

`hey-container preflight` warns when no source file mentions it:

```
WARNING: no source file mentions the health path /up. The generated
HEALTHCHECK probes it, so the container will never report healthy and an
orchestrator gating a rollout on health will stall with nothing to act on.
```

This is a warning and not a refusal because the scan is textual and a
route table built by a helper would be a false refusal — which blocks a
correct app, and is worse. It was added because `generic_cagents`, this
program's proving app, **has no health route at all**.

`src/health.hey` is a drop-in:

```hey
import 'pkg:hey_container@0.1.0/health'
Web.get('/up', HeyContainerHealth.up)
```

Note the shape: a plain named single-argument function, **not**
`bind(...)`. It deliberately does not touch the database — a liveness
probe that fails when a dependency is slow turns a degraded dependency
into an outage.

---

## The Hey Linux toolchain image

`--hey-image` must name an image containing a Hey **Linux** distribution
at `/opt/hey`. This package does not build one; the Hey trunk owns that
(`docker/linux/alpine/Dockerfile`). Measured requirements:

- **glibc, not musl.** Dist binaries are `dynamically linked, interpreter
  /lib64/ld-linux-x86-64.so.2`; they will not exec on Alpine.
- **`libssl3`.** Without it: `error while loading shared libraries:
  libcrypto.so.3`.
- **`libclang-cpp14` / `libllvm14`** *if you want the compiled lane*. The
  0.99.382a dist bundles a `clang` that fails with `error while loading
  shared libraries: libclang-cpp.so.14` on a bare `debian:bookworm-slim`.
  With those two packages installed, compilation **works** in-container —
  verified by compiling and running the defect repro:

  ```
  same-file fn param  =callable
  stdlib Web.route    =string
  unbound via stdlib  =string
  ```

  which is also an independent reproduction of the callable-degradation
  defect on Linux/0.99.382a. The same program interpreted in the same
  container prints `callable` three times.
- **The interpreter is `/opt/hey/libexec/hey/heyc-bootstrap`.** A dist
  tree ships `bin/hey` (a compile-and-cache runner) and `bin/hey-selfc`
  (a compiler); **neither interprets**, and a dist has no `bin/heyc`.

---

## Gates

```sh
./bin/check                                             # no daemon needed
HEY_IMAGE=<ref> ./bin/check-docker                      # real build, real container
```

`bin/check` runs every spec on the **interpreter**, then builds
`tools/compiled_receipt.hey` with `heyc build`, runs it, and **diffs the
two stdouts**. That gate earned itself immediately: `HeyContainerLane.decide`
ran fine interpreted and the LLVM backend refused to lower it —

```
heyc: llvm backend supported subset cannot lower: expression `container_override_advice(`
```

— because a function call sat inside an object-literal field. Hoisting it
to a local fixed it. An interpreter-only green would have shipped a
package that cannot be compiled.

`bin/check` also runs a **negative gate**: it builds a fixture that uses
`bind()` and asserts the preflight *refuses* it on both lanes. A
preflight that always says yes is worse than none, because it reassures.

`bin/check` also asserts the health-route warning fires **and stays
quiet** — a warning that always fires is noise people learn to skip.

`bin/check-docker` asserts the **bytes** of the response, never the
status code alone — the known failure shape is a well-formed 200 with an
empty body. Verified red on purpose: with the fixture handler returning
an empty body, the gate reports
`RED: 200 with a 0-byte body -- this is the empty-200 failure, not a pass`.

---

## What is NOT proven

Stated plainly, with the check that would settle each:

1. **The compiled lane has never produced a working image.** The
   toolchain problem is solved — with `libclang-cpp14` and `libllvm14`
   installed, `hey selfc` compiles inside the image, verified by
   compiling and running the defect repro. But a full `--lane compiled`
   image build of the fixture was still in its `compile` stage after
   **28 minutes** under x86 emulation on a 2-CPU VM and did not finish.
   So the `compile` stage is proven to *work*, not proven to *complete
   here*. *Settled by:* `docker build --build-arg HEY_LANE=compiled` on a
   native linux/amd64 host, then `bin/check-docker` against the result.

2. **`generic_cagents` has not been containerised.** The proving app was
   a fixture built on `stdlib:Web` alone. *Settled by:*
   `APP=~/dev/generic_cagents ./bin/check-docker` with a toolchain image
   new enough for its dependencies — it pins `hey_web` 0.3.0 plus
   `hey_record`, `hey_sqlite3` and `hey_mysql`, and the only Linux dist
   available here is 0.99.382a while the trunk is at 0.99.474a.

3. ~~The `development` and `test` images have never been built.~~
   **Resolved.** Both build. The development image serves:

   ```
   dev image GET /up -> status=200 bytes=69
     body={"status":"ok","environment":"development","fixture":"hey_container"}
   ```

   and `/app` inside the *image* is **empty** (`ls -A /app | wc -l` -> `0`),
   which is the structural proof that development mounts rather than
   copies. The test image does copy (`ls -A /app` -> `app.hey`). The test
   image's `./bin/check` command has not been exercised against an app
   that has one.

4. **arm64 is untested.** Every container measurement here is
   `linux/amd64` under emulation on an arm64 host, because no
   `linux-arm64` Hey dist exists in the trunk.

5. **No performance number backs the interpreted default.** The tradeoff
   is argued, not measured. *Settled by:* a request-throughput comparison
   of the same app in both lanes, once the compiled lane works.
