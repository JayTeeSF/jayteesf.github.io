# In progress

- Produce the first simulator receipt from a locked package consumer.
