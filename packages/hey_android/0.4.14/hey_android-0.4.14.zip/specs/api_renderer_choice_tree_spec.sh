#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-choices.XXXXXX")
trap 'rm -rf "$work"' EXIT
java_home=$(hey_android_java_home)
find "$ROOT/renderer/java" "$ROOT/renderer/host" -name '*.java' > "$work/sources"
"$java_home/bin/javac" --release 17 -d "$work/classes" @"$work/sources"
"$java_home/bin/java" -cp "$work/classes" hey.android.api.ChoiceTreeMain
# A broken private flag must be caught by the same model checks.
mkdir -p "$work/mutant"
cp -R "$ROOT/renderer/java" "$work/mutant/java"
ruby - "$work/mutant/java/hey/android/api/ChoiceTree.java" <<'RUBY'
p=ARGV[0];s=File.read(p);old='node.selectable=Boolean.TRUE.equals(selectable);';abort 'mutation did not match' unless s.include?(old);File.write(p,s.sub(old,'node.selectable=true;'))
RUBY
find "$work/mutant/java" "$ROOT/renderer/host" -name '*.java' > "$work/mutant/sources"
"$java_home/bin/javac" --release 17 -d "$work/mutant/classes" @"$work/mutant/sources"
if "$java_home/bin/java" -cp "$work/mutant/classes" hey.android.api.ChoiceTreeMain > "$work/mutant/result" 2>&1; then
  echo 'FAIL: private-ancestor mutation passed'; exit 1
fi
grep -q 'private structural ancestor cannot select' "$work/mutant/result"
echo 'PASS (control): making private ancestors selectable is detected'
