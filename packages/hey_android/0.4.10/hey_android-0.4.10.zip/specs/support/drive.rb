USAGE = <<'DOC'.freeze
drive.rb: drive an emulator by what its View tree says, for specs/api_renderer_emulator_spec.sh.

ADB (environment) names the adb binary.

  drive.rb SERIAL tap TEXT [--contains]        tap the centre of the first node whose text (or content-desc) is TEXT
  drive.rb SERIAL long TEXT [MILLISECONDS]       long-press the centre of the first matching node
  drive.rb SERIAL copy                          tap the API 36 Pixel 7 selection toolbar's Copy action
  drive.rb SERIAL copy-key                      invoke Android's native Copy key for the active selection
  drive.rb SERIAL search                        tap the native keyboard's Search action on the pinned display
  drive.rb SERIAL clear LABEL                    clear the labelled EditText using select-all and delete
  drive.rb SERIAL paste LABEL                    focus the labelled EditText and paste the system clipboard
  drive.rb SERIAL wait TEXT SECONDS [--contains] succeed when a node with that text appears
  drive.rb SERIAL scrollto TEXT [SWIPES]         swipe up until a node with that text is on screen
  drive.rb SERIAL gone TEXT SECONDS            succeed when no node has that text
  drive.rb SERIAL type LABEL TEXT              tap the EditText whose content-desc is LABEL, then type TEXT
  drive.rb SERIAL shot PATH                    screenshot (PNG) and the View tree next to it (PATH.xml)
  drive.rb SERIAL texts                        print every node's text
  drive.rb SERIAL logwait PATTERN SECONDS      succeed when logcat tag hey.api has a line containing PATTERN
DOC
require 'rexml/document'

ADB = ENV['ADB'] || File.expand_path('~/Library/Android/sdk/platform-tools/adb')
serial = ARGV.fetch(0)
cmd = ARGV.fetch(1)
args = ARGV[2..-1]

def die(message)
  warn message
  exit 1
end

# Quote TEXT the way the spec logs have always shown it: 'like this'.
def quoted(text)
  return "\"#{text}\"" if text.include?("'") && !text.include?('"')
  "'" + text.gsub('\\') { '\\\\' }.gsub("'") { "\\'" } + "'"
end

define_method(:adb) do |*a, binary: false|
  out = IO.popen([ADB, '-s', serial, *a], 'rb', err: File::NULL, &:read)
  binary ? out : out.force_encoding('UTF-8').scrub
end

def tree
  5.times do
    adb('shell', 'uiautomator', 'dump', '/sdcard/drive.xml')
    raw = adb('exec-out', 'cat', '/sdcard/drive.xml')
    if raw.strip.start_with?('<?xml')
      begin
        return [raw, REXML::Document.new(raw).root]
      rescue REXML::ParseException
        nil
      end
    end
    sleep 0.5
  end
  ['', nil]
end

def nodes(root)
  return [] if root.nil?
  found = []
  found << root if root.name == 'node'
  root.each_element('.//node') { |n| found << n }
  found
end

def find(root, text, contains = false, cls = nil)
  return nil if root.nil?
  nodes(root).each do |node|
    next if cls && node.attributes['class'] != cls
    %w[text content-desc].each do |key|
      v = node.attributes[key] || ''
      next unless (contains && v.include?(text)) || (!contains && v == text)
      m = /\A\[(\d+),(\d+)\]\[(\d+),(\d+)\]/.match(node.attributes['bounds'] || '')
      next unless m
      x0, y0, x1, y1 = m.captures.map(&:to_i)
      return [(x0 + x1) / 2, (y0 + y1) / 2] if x1 > x0 && y1 > y0
    end
  end
  nil
end

contains = args.include?('--contains')
args = args.reject { |a| a == '--contains' }

case cmd
when 'tap'
  _, root = tree
  at = find(root, args[0], contains)
  die("no node with text #{quoted(args[0])}") if at.nil?
  adb('shell', 'input', 'tap', at[0].to_s, at[1].to_s)
  puts "tapped #{quoted(args[0])} at #{at[0]},#{at[1]}"
when 'long'
  _, root = tree
  at = find(root, args[0], contains)
  die("no node with text #{quoted(args[0])}") if at.nil?
  duration = args.length > 1 ? args[1] : '1200'
  adb('shell', 'input', 'swipe', at[0].to_s, at[1].to_s, at[0].to_s, at[1].to_s, duration)
  sleep 1.0 # Let Android finish displaying the native selection toolbar.
  puts "long-pressed #{quoted(args[0])} at #{at[0]},#{at[1]} for #{duration}ms"
when 'copy'
  size = adb('shell', 'wm', 'size')
  die("Copy toolbar tap requires the pinned Pixel 7 API 36 display (1080x2400), got #{quoted(size.strip)}") unless size.include?('1080x2400')
  # The AOSP selection toolbar is a separate window omitted from
  # uiautomator's app hierarchy. In the pinned fixture, Stalker's selection
  # places its first action, Copy, at this measured screen coordinate.
  adb('shell', 'input', 'tap', '139', '667')
  puts 'tapped native Copy in the selection toolbar at 139,667'
when 'copy-key'
  adb('shell', 'input', 'keyevent', "278")
  puts 'sent Android KEYCODE_COPY to the active native text selection'
when 'search'
  size = adb('shell', 'wm', 'size')
  match = /(?:Physical|Override) size: (\d+)x(\d+)/.match(size)
  unless match && match.captures == %w[1080 2400]
    die("keyboard Search tap requires the pinned Pixel 7 API 36 display (1080x2400), got #{quoted(size.strip)}")
  end
  x = (1080 * 0.94).round
  y = (2400 * 0.91).round
  adb('shell', 'input', 'tap', x.to_s, y.to_s)
  puts "tapped the native keyboard Search action at #{x},#{y}"
when 'clear'
  _, root = tree
  at = find(root, args[0], false, 'android.widget.EditText')
  die("no field #{quoted(args[0])}") if at.nil?
  adb('shell', 'input', 'tap', at[0].to_s, at[1].to_s)
  sleep 0.8
  adb('shell', 'input', 'keycombination', '113', '29')
  adb('shell', 'input', 'keyevent', '67')
  puts "cleared #{quoted(args[0])}"
when 'paste'
  _, root = tree
  at = find(root, args[0], false, 'android.widget.EditText')
  die("no field #{quoted(args[0])}") if at.nil?
  adb('shell', 'input', 'tap', at[0].to_s, at[1].to_s)
  sleep 0.8
  adb('shell', 'input', 'keyevent', '279')
  puts "pasted clipboard into #{quoted(args[0])}"
when 'wait'
  deadline = Time.now.to_f + Float(args[1])
  while Time.now.to_f < deadline
    _, root = tree
    if find(root, args[0], contains)
      puts "seen #{quoted(args[0])}"
      exit 0
    end
    sleep 1
  end
  die("not seen within #{args[1]}s: #{quoted(args[0])}")
when 'scrollto'
  (args.length > 1 ? Integer(args[1], 10) : 12).times do
    _, root = tree
    at = find(root, args[0], contains)
    if at && at[1] > 300 && at[1] < 2000
      puts "scrolled to #{quoted(args[0])} at #{at[0]},#{at[1]}"
      exit 0
    end
    adb('shell', 'input', 'swipe', '540', '1700', '540', '900', '400')
    sleep 1.2
  end
  die("not reached by scrolling: #{quoted(args[0])}")
when 'gone'
  deadline = Time.now.to_f + Float(args[1])
  while Time.now.to_f < deadline
    _, root = tree
    if !root.nil? && !find(root, args[0])
      puts "gone #{quoted(args[0])}"
      exit 0
    end
    sleep 1
  end
  die("still there after #{args[1]}s: #{quoted(args[0])}")
when 'type'
  _, root = tree
  at = find(root, args[0], false, 'android.widget.EditText')
  die("no field #{quoted(args[0])}") if at.nil?
  adb('shell', 'input', 'tap', at[0].to_s, at[1].to_s)
  sleep 0.8
  adb('shell', 'input', 'text', args[1])
  puts "typed into #{quoted(args[0])}"
when 'shot'
  png = adb('exec-out', 'screencap', '-p', binary: true)
  File.binwrite(args[0], png)
  raw, = tree
  File.write(args[0] + '.xml', raw)
  puts "shot #{args[0]} (#{png.bytesize} bytes)"
when 'texts'
  _, root = tree
  nodes(root).each do |node|
    t = node.attributes['text'] || ''
    puts t unless t.empty?
  end
when 'logwait'
  deadline = Time.now.to_f + Float(args[1])
  while Time.now.to_f < deadline
    log = adb('logcat', '-d', '-v', 'tag', '-s', 'hey.api:*')
    if log.include?(args[0])
      puts "logged #{quoted(args[0])}"
      exit 0
    end
    sleep 1
  end
  die("not logged within #{args[1]}s: #{quoted(args[0])}")
else
  die(USAGE)
end
