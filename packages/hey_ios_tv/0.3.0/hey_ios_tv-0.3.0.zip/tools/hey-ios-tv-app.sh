#!/usr/bin/env sh
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
HEY_IOS_ROOT=${HEY_IOS_ROOT:-$HOME/dev/hey_ios}
out=''
source="$PACKAGE_ROOT/examples/native_tvos_app.hey"
entry='tvos_app_manifest'
bundle_id=''
bundle_id_explicit=false
display_name='Hey Party TV'
minimum='17.0'
launch=false
plan_only=false
sim_device='booted'
# mode is 'simulator' (arm64/x86_64-apple-tvos*-simulator, ad-hoc codesign) or
# 'device' (arm64-apple-tvos, real provisioning-profile signing + devicectl).
# The two tiers keep entirely separate receipts: a device run never claims a
# simulator token, and vice versa.
mode='simulator'
device_id=''

usage() {
  cat <<'HELP'
usage: hey ios-tv-app --out DIRECTORY [--source FILE.hey] [--entry FUNCTION] [--bundle-id ID] [--display-name NAME] [--minimum-tvos VERSION] [--launch] [--sim-udid booted|UDID] [--device [DEVICE-ID]] [--plan-only]

  --launch            simulator mode: install + launch on a booted Apple TV simulator
  --sim-udid U        simulator mode: target simulator (booted | a specific UDID)
  --device [ID]       physical-device mode: build for arm64-apple-tvos, sign with a
                      tvOS provisioning profile, install + launch via devicectl.
                      DEVICE-ID defaults to the sole paired Apple TV.
  --plan-only         simulator mode: structural plan only (no Xcode link)
HELP
}
while [ "$#" -gt 0 ]; do
  case "$1" in
    --out) shift; out=${1:?missing --out value} ;;
    --source) shift; source=${1:?missing --source value} ;;
    --entry) shift; entry=${1:?missing --entry value} ;;
    --bundle-id) shift; bundle_id=${1:?missing --bundle-id value}; bundle_id_explicit=true ;;
    --display-name) shift; display_name=${1:?missing --display-name value} ;;
    --minimum-tvos) shift; minimum=${1:?missing --minimum-tvos value} ;;
    --sim-udid) shift; sim_device=${1:?missing --sim-udid value} ;;
    --device)
      mode=device
      # Optional DEVICE-ID: consume the next token only when it is not a flag.
      if [ "$#" -ge 2 ]; then
        case "$2" in
          -*) ;;
          *) shift; device_id=$1 ;;
        esac
      fi
      ;;
    --launch) launch=true ;;
    --plan-only) plan_only=true ;;
    --help|-h) usage; exit 0 ;;
    *) echo "unknown tvOS native-app option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
[ -n "$out" ] || { echo '--out is required' >&2; exit 2; }

# Bundle id default depends on the tier. The device tier defaults to
# com.jayteesf.heytv so it matches the tvOS provisioning profile minted by the
# one-time Xcode bootstrap (see the missing-profile message below); the
# simulator tier keeps the historical id.
if [ -z "$bundle_id" ]; then
  if [ "$mode" = device ]; then bundle_id=${HEY_TVOS_BUNDLE_ID:-com.jayteesf.heytv}; else bundle_id='com.hey-lang.party-tv'; fi
fi

[ -f "$HEY_IOS_ROOT/hey-package.json" ] || {
  echo "hey_ios package is required: $HEY_IOS_ROOT" >&2
  echo "Install and lock hey_ios 0.1.3 before using hey_ios_tv." >&2
  exit 69
}
grep -F '"name": "hey_ios"' "$HEY_IOS_ROOT/hey-package.json" >/dev/null
grep -F '0.1.3' "$HEY_IOS_ROOT/VERSION" >/dev/null || {
  echo "hey_ios 0.1.3 is required: $HEY_IOS_ROOT" >&2
  exit 69
}
[ -f "$source" ] || { echo "Hey source not found: $source" >&2; exit 66; }
case "$entry" in *[!A-Za-z0-9_]*|'') echo "invalid Hey entry function: $entry" >&2; exit 2 ;; esac

# ---- target selection (simulator vs device) -----------------------------
# Both tiers compile the same ordinary Hey source through the same LLVM
# pipeline; only the target triple, the SDK, and the object name change.
if [ "$mode" = device ]; then
  target_arch=arm64
  sdk_name=appletvos
  triple="arm64-apple-tvos${minimum}"
  app_obj=app-device.o
else
  host_arch=$(uname -m 2>/dev/null || echo x86_64)
  case "$host_arch" in arm64|aarch64) target_arch=arm64 ;; *) target_arch=x86_64 ;; esac
  sdk_name=appletvsimulator
  triple="${target_arch}-apple-tvos${minimum}-simulator"
  app_obj=app-simulator.o
fi

clang=''
if [ -n "${HEY_TVOS_CLANG:-}" ] && [ -x "$HEY_TVOS_CLANG" ]; then
  clang=$HEY_TVOS_CLANG
elif command -v xcrun >/dev/null 2>&1; then
  clang=$(xcrun --sdk "$sdk_name" --find clang 2>/dev/null || true)
fi
[ -n "$clang" ] || clang=$(command -v clang 2>/dev/null || true)
[ -n "$clang" ] || { echo 'clang is required for tvOS Mach-O object generation' >&2; exit 69; }

rm -rf "$out"
mkdir -p "$out/src" "$out/objects" "$out/HeyPartyTV.app"
cp "$source" "$out/src/app.hey"
"$HEY_ROOT/bin/heyc" build --emit-llvm-ir "$source" -o "$out/src/app.ll" >/dev/null
sed 's/define i32 @main(/define i32 @hey_tvos_source_program_main(/' "$out/src/app.ll" > "$out/src/app-tvos.ll"

if command -v xcrun >/dev/null 2>&1; then sdk=$(xcrun --sdk "$sdk_name" --show-sdk-path 2>/dev/null || true); else sdk=''; fi
if [ -n "$sdk" ]; then
  "$clang" --target="$triple" -isysroot "$sdk" -Wno-override-module -c "$out/src/app-tvos.ll" -o "$out/objects/$app_obj"
else
  env -u SDKROOT "$clang" --target="$triple" -Wno-override-module -c "$out/src/app-tvos.ll" -o "$out/objects/$app_obj"
fi
file "$out/objects/$app_obj" > "$out/objects/app.file.txt"
grep -F 'Mach-O 64-bit' "$out/objects/app.file.txt" >/dev/null

# ---- build-time contract detection --------------------------------------
# nm-check the compiled app object: a scene-contract-v2 app exports
# _hey_fn_tv_scene_init, so the template is built with -DHEY_SCENE_V2 (the
# scene renderer); anything else stays on the v1 game contract path.
scene_v2=false
if nm "$out/objects/$app_obj" 2>/dev/null | grep -qE ' T _hey_fn_tv_scene_init$'; then
  scene_v2=true
fi
scene_cflag=''
if [ "$scene_v2" = true ]; then
  nm "$out/objects/$app_obj" 2>/dev/null | grep -qE ' T _hey_fn_tv_scene_step$' || {
    echo 'scene-v2 Hey source must also export fn tv_scene_step(scene, event)' >&2; exit 65; }
  scene_cflag='-DHEY_SCENE_V2'
  symbol='hey_fn_tv_scene_init'
else
  symbol="hey_fn_${entry}"
  grep -F "define ptr @$symbol()" "$out/src/app.ll" >/dev/null || { echo "Hey source must export fn $entry()" >&2; exit 65; }
  grep -F 'define i64 @hey_fn_tvos_action_code(i64 ' "$out/src/app.ll" >/dev/null || { echo 'Hey source must export fn tvos_action_code(action_id)' >&2; exit 65; }
fi
sed "s/HEY_ENTRY_SYMBOL/$symbol/g" "$PACKAGE_ROOT/tools/hey_native_tv_runtime.m" > "$out/src/main.m"

# ---- real Hey runtime object cache key (compiled at link time) ----------
# The v1 no-runtime string shim is gone; every app links the real Hey
# runtime compiled for the tvOS target. The object is cached keyed by the
# runtime source hash and triple so repeat builds skip the recompile. The
# triple carries the tier, so the device .o and the simulator .o never share
# a cache slot.
runtime_src="$HEY_ROOT/runtime/hey_runtime.c"
[ -f "$runtime_src" ] || { echo "Hey runtime source not found: $runtime_src" >&2; exit 69; }
runtime_sha=$(shasum -a 256 "$runtime_src" 2>/dev/null | awk '{print $1}')
cache_dir=${HEY_IOS_TV_CACHE:-$PACKAGE_ROOT/.build-cache}
runtime_obj="$cache_dir/hey_runtime-${triple}-${runtime_sha}.o"

cat > "$out/HeyPartyTV.app/Info.plist" <<EOF_PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDisplayName</key><string>$display_name</string>
<key>CFBundleExecutable</key><string>HeyPartyTV</string>
<key>CFBundleIdentifier</key><string>$bundle_id</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleName</key><string>$display_name</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>CFBundleVersion</key><string>1</string>
<key>MinimumOSVersion</key><string>$minimum</string>
<key>UIDeviceFamily</key><array><integer>3</integer></array>
<key>UILaunchScreen</key><dict/>
</dict></plist>
EOF_PLIST
source_sha=$(shasum -a 256 "$source" 2>/dev/null | awk '{print $1}')
object_sha=$(shasum -a 256 "$out/objects/$app_obj" 2>/dev/null | awk '{print $1}')

write_receipt() {
  native_link=$1; installed=$2; launched=$3; udid=$4
  contract=v1; [ "$scene_v2" = true ] && contract=scene-v2
  cat > "$out/receipt.json" <<EOF_RECEIPT
{"kind":"hey-tvos-native-app-v1","hey_source":"$source","hey_source_sha256":"$source_sha","hey_entry":"$entry","contract":"$contract","native_hey_codegen":true,"native_object":"objects/app-simulator.o","native_object_sha256":"$object_sha","target_triple":"$triple","runtime_linked":true,"runtime_object_sha256":"$runtime_sha","public_display":true,"focus_engine":true,"remote_primary_action":true,"native_link":"$native_link","simulator_install":"$installed","simulator_launch":"$launched","simulator_udid":"$udid","physical_device_signing":"pending","app_store_submission_ready":false}
EOF_RECEIPT
}

# Device-tier receipt: a distinct kind with its own token vocabulary so it can
# never be mistaken for a simulator receipt.
write_device_receipt() {
  contract=v1; [ "$scene_v2" = true ] && contract=scene-v2
  cat > "$out/receipt.json" <<EOF_DRECEIPT
{"kind":"hey-tvos-native-app-device-v1","tier":"device","hey_source":"$source","hey_source_sha256":"$source_sha","hey_entry":"$entry","contract":"$contract","native_hey_codegen":true,"native_object":"objects/app-device.o","native_object_sha256":"$object_sha","target_triple":"$triple","device_sdk":"$sdk_name","runtime_linked":true,"runtime_object_sha256":"$runtime_sha","bundle_id":"$bundle_id","device_build":"$device_build","device_sign":"$device_sign","device_install":"$device_install","device_launch":"$device_launch","provisioning_profile":"$profile_desc","signing_identity":"$identity_desc","team_identifier":"$team_desc","device_id":"$device_id_desc","profile_provisioned_udids":"$provisioned_count","profile_provisions_target":"$profile_provisions_target","target_provisioning_udid":"$prov_target_desc"}
EOF_DRECEIPT
}

if [ "$plan_only" = true ] && [ "$mode" = simulator ]; then
  write_receipt pending false false ''
  printf 'tvOS native app plan ok output=%s ordinary_hey_source=true direct_llvm=true mach_o=true focus=true remote=true native_link=pending\n' "$out"
  exit 0
fi
[ "$(uname -s)" = Darwin ] || { echo 'native tvOS linking requires macOS/Xcode; use --plan-only elsewhere' >&2; exit 69; }
[ -n "$sdk" ] || { echo "Apple TV SDK missing for $sdk_name (install the tvOS platform: xcodebuild -downloadPlatform tvOS)" >&2; exit 69; }
clang=$(xcrun --sdk "$sdk_name" --find clang)
# Compile + cache the real Hey runtime object (keyed by source sha + triple).
mkdir -p "$cache_dir"
if [ ! -f "$runtime_obj" ]; then
  "$clang" --target="$triple" -isysroot "$sdk" -DHEY_RUNTIME_NO_PROCESS_SPAWN -O1 -w \
    -c "$runtime_src" -o "$runtime_obj.tmp.$$"
  mv "$runtime_obj.tmp.$$" "$runtime_obj"
fi
cp "$runtime_obj" "$out/objects/hey_runtime.o"
# Link-time stubs for the runtime's OpenSSL (TLS + crypto) references, which
# are not in the public Apple TV SDK. A public-display / card app never opens
# a TLS socket or hashes bytes, so these paths are never reached; the stubs
# only satisfy the linker (and trap if ever actually called).
"$clang" --target="$triple" -isysroot "$sdk" -w \
  -c "$PACKAGE_ROOT/tools/hey_tvos_link_stubs.c" -o "$out/objects/link-stubs.o"
# Compile the template object (scene-v2 renderer when the app exports it).
"$clang" --target="$triple" -isysroot "$sdk" -fobjc-arc -fmodules $scene_cflag \
  -c "$out/src/main.m" -o "$out/objects/main.o"
# Duplicate-symbol guard: each runtime-provided symbol (formerly shimmed in
# the template) must have exactly one definition across the linked objects.
for guard_sym in _hey_runtime_init _hey_llvm_string_value _hey_llvm_concat_string _hey_llvm_value_to_raw_string_cstr; do
  defs=$(nm "$out/objects/main.o" "$out/objects/$app_obj" "$out/objects/hey_runtime.o" 2>/dev/null \
    | grep -cE " [TDSB] $guard_sym\$" || true)
  [ "$defs" = 1 ] || { echo "runtime symbol $guard_sym has $defs definitions (expected 1: shim not removed?)" >&2; exit 65; }
done
"$clang" --target="$triple" -isysroot "$sdk" -fobjc-arc \
  "$out/objects/main.o" "$out/objects/$app_obj" "$out/objects/hey_runtime.o" "$out/objects/link-stubs.o" \
  -framework UIKit -framework Foundation -framework CoreImage \
  -o "$out/HeyPartyTV.app/HeyPartyTV"
chmod +x "$out/HeyPartyTV.app/HeyPartyTV"

# =========================================================================
# DEVICE TIER: real signing + devicectl install/launch.
# Structural evidence (build + link for arm64-apple-tvos) is now proven; the
# remaining stages degrade honestly to `blocked` when a prerequisite is
# absent, and each hard prerequisite prints a specific, actionable message.
# =========================================================================
if [ "$mode" = device ]; then
  device_build=passed
  device_sign=blocked-no-profile
  device_install=blocked
  device_launch=blocked
  profile_desc=''
  identity_desc=''
  team_desc=''
  device_id_desc=''
  provisioned_count=''
  profile_provisions_target=''
  # HEY_TVOS_PROVISIONING_UDID (optional): a device UDID (as shown in Xcode's
  # Devices window) that the located profile is expected to provision; when
  # set, the receipt reports whether the profile actually lists it.
  prov_target_desc=${HEY_TVOS_PROVISIONING_UDID:-}

  # -- signing identity (Apple Development) -------------------------------
  sign_identity=${HEY_APPLE_SIGNING_IDENTITY:-}
  if [ -z "$sign_identity" ]; then
    sign_identity=$(security find-identity -v -p codesigning 2>/dev/null \
      | sed -n 's/.*"\(Apple Development: [^"]*\)".*/\1/p' | head -1)
  fi
  [ -n "$sign_identity" ] || {
    echo 'device signing needs an "Apple Development" identity in your login keychain.' >&2
    echo 'Add your Apple ID in Xcode > Settings > Accounts, then re-run bin/demo device.' >&2
    exit 69
  }
  identity_desc=$sign_identity

  # -- team id (env override, else derive OU from the signing cert) -------
  team=${HEY_APPLE_TEAM_ID:-}
  if [ -z "$team" ]; then
    cert_cn=${sign_identity% (*}
    team=$(security find-certificate -c "$cert_cn" -p 2>/dev/null \
      | openssl x509 -noout -subject 2>/dev/null \
      | sed -n 's/.*OU=\([A-Za-z0-9]*\).*/\1/p' | head -1)
  fi
  [ -n "$team" ] || {
    echo 'could not determine your Apple team id.' >&2
    echo 'Set HEY_APPLE_TEAM_ID to your 10-character Team ID and re-run.' >&2
    exit 69
  }
  team_desc=$team

  # -- locate a tvOS-capable provisioning profile ------------------------
  # Scan both profile stores; a match must (a) list tvOS in Platform and
  # (b) carry an application-identifier of TEAM.<bundle-id> or TEAM.* .
  profile=''
  scan_plist="$out/objects/_profile.plist"
  for pdir in \
    "$HOME/Library/MobileDevice/Provisioning Profiles" \
    "$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles"; do
    [ -d "$pdir" ] || continue
    for p in "$pdir"/*.mobileprovision "$pdir"/*.provisionprofile; do
      [ -f "$p" ] || continue
      security cms -D -i "$p" > "$scan_plist" 2>/dev/null || continue
      plutil -extract Platform xml1 -o - "$scan_plist" 2>/dev/null | grep -q '>tvOS<' || continue
      appid=$(plutil -extract Entitlements.application-identifier raw -o - "$scan_plist" 2>/dev/null) || continue
      pteam=${appid%%.*}
      pname=${appid#*.}
      [ "$pteam" = "$team" ] || continue
      case "$pname" in
        "$bundle_id"|'*') profile=$p; break ;;
      esac
    done
    [ -n "$profile" ] && break
  done
  rm -f "$scan_plist"

  if [ -z "$profile" ]; then
    # Expected today: no tvOS profile exists yet. This is a *blocked* tier,
    # not a failure — the structural device build passed. Print the one-time
    # bootstrap and emit the honest blocked receipt.
    write_device_receipt
    cat >&2 <<BOOTSTRAP
device signing is blocked: no tvOS provisioning profile for $team.$bundle_id was found.

This is expected the first time. Mint one with a single Xcode bootstrap (once):

  1. Xcode > File > New > Project > tvOS > App.
  2. Product Name: HeySigningSetup   Bundle Identifier: com.jayteesf.heytv
     Team: your personal team        Signing: Automatically manage signing.
  3. Select your paired Apple TV ("Living Room") as the run destination.
  4. Press Run once. Xcode registers the Apple TV's UDID with your account
     and mints a tvOS development provisioning profile for com.jayteesf.heytv.
  5. Re-run:  bin/demo device

That single Run is the only manual Xcode step ever required; afterward the
profile lives in ~/Library/MobileDevice/Provisioning Profiles and every future
bin/demo device signs and deploys on its own.
BOOTSTRAP
    printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
      "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
    exit 0
  fi
  profile_desc=$profile

  # -- report which UDIDs the located profile provisions -----------------
  security cms -D -i "$profile" > "$scan_plist" 2>/dev/null || true
  provisioned_count=$(plutil -extract ProvisionedDevices xml1 -o - "$scan_plist" 2>/dev/null | grep -c '<string>' || true)
  if [ -n "$prov_target_desc" ]; then
    if plutil -extract ProvisionedDevices xml1 -o - "$scan_plist" 2>/dev/null | grep -qi ">$prov_target_desc<"; then
      profile_provisions_target=yes
    else
      profile_provisions_target=no
    fi
  fi
  rm -f "$scan_plist"

  # -- embed profile, generate entitlements, codesign --------------------
  cp "$profile" "$out/HeyPartyTV.app/embedded.mobileprovision"
  cat > "$out/entitlements.plist" <<EOF_ENT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>application-identifier</key><string>$team.$bundle_id</string>
<key>get-task-allow</key><true/>
<key>com.apple.developer.team-identifier</key><string>$team</string>
</dict></plist>
EOF_ENT
  if codesign --force --sign "$sign_identity" --entitlements "$out/entitlements.plist" \
       --timestamp=none "$out/HeyPartyTV.app" 2>"$out/codesign.log" \
     && codesign --verify --strict "$out/HeyPartyTV.app" 2>>"$out/codesign.log"; then
    device_sign=passed
  else
    device_sign=failed
    write_device_receipt
    echo "device codesign failed; see $out/codesign.log" >&2
    printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
      "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
    exit 1
  fi

  # -- resolve the target device -----------------------------------------
  # Precedence: --device DEVICE-ID > $HEY_TVOS_DEVICE > the sole paired Apple TV.
  [ -n "$device_id" ] || device_id=${HEY_TVOS_DEVICE:-}
  if [ -z "$device_id" ]; then
    device_id=$(xcrun devicectl list devices 2>/dev/null \
      | awk 'tolower($0) ~ /appletv/ && tolower($0) ~ /paired/ {for(i=1;i<=NF;i++) if($i ~ /^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-/) print $i}')
    n=$(printf '%s\n' "$device_id" | grep -c . || true)
    if [ "$n" -eq 0 ]; then
      device_id=''
      write_device_receipt
      echo 'device install is blocked: no paired Apple TV found in `xcrun devicectl list devices`.' >&2
      echo 'Pair one in Xcode > Window > Devices and Simulators, or pass --device <DEVICE-ID>.' >&2
      printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
        "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
      exit 1
    elif [ "$n" -gt 1 ]; then
      echo 'multiple paired Apple TVs found; pass --device <DEVICE-ID> to choose one:' >&2
      printf '%s\n' "$device_id" >&2
      exit 2
    fi
  fi
  device_id_desc=$device_id

  # -- install + launch via devicectl ------------------------------------
  if xcrun devicectl device install app --device "$device_id" "$out/HeyPartyTV.app" \
       > "$out/devicectl-install.txt" 2>&1; then
    device_install=passed
  else
    device_install=failed
    write_device_receipt
    echo "device install failed; see $out/devicectl-install.txt" >&2
    printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
      "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
    exit 1
  fi
  if xcrun devicectl device process launch --device "$device_id" "$bundle_id" \
       > "$out/devicectl-launch.txt" 2>&1; then
    device_launch=passed
  else
    device_launch=failed
  fi
  write_device_receipt
  printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
    "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
  exit 0
fi

# =========================================================================
# SIMULATOR TIER: ad-hoc codesign + optional simctl install/launch.
# =========================================================================
codesign --force --sign - "$out/HeyPartyTV.app"
codesign --verify --strict "$out/HeyPartyTV.app"
installed=false; launched=false; udid=''
if [ "$launch" = true ]; then
  if [ "$sim_device" = booted ]; then
    udid=$(xcrun simctl list devices booted | sed -n 's/.*(\([0-9A-Fa-f-][0-9A-Fa-f-]*\)) (Booted).*/\1/p' | head -1)
    [ -n "$udid" ] || { echo 'no booted Apple TV simulator found' >&2; exit 70; }
  else
    udid=$sim_device
    xcrun simctl boot "$udid" >/dev/null 2>&1 || true
    xcrun simctl bootstatus "$udid" -b
  fi
  xcrun simctl install "$udid" "$out/HeyPartyTV.app"; installed=true
  xcrun simctl launch --terminate-running-process "$udid" "$bundle_id" > "$out/simctl-launch.txt"; launched=true
fi
write_receipt passed "$installed" "$launched" "$udid"
printf 'tvOS native app ok output=%s ordinary_hey_source=true direct_llvm=true mach_o=true focus=true remote=true native_link=passed installed=%s launched=%s\n' "$out" "$installed" "$launched"
