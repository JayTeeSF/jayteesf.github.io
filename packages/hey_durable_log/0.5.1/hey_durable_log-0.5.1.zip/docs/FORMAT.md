# Durable log format v3

The format is explicitly little-endian and never writes native C structs.
All offsets below are bytes from the start of the relevant header.

## The segment set

A journal is a **directory**. Each published segment inside it is a file named

```text
%016x-%016x.seg      (segment index, base position)
```

The two facts recovery needs are therefore in the name, and **the directory
listing is the manifest**. There is no manifest file, which is deliberate: a
manifest is a second thing that has to agree with the first, and every crash
boundary in rotation exists because two things can disagree. etcd reaches the
same conclusion by encoding (sequence, first index) in its WAL filenames --
`research/2026-09-04-etcd-raft-and-kafka-segments.md` in the coordination
repository, §4.1.

A segment is published by one `rename`, and **the cut happens between batches,
never inside one**: when the active segment has reached `segment_size_bytes`
(64 MiB by default), the next segment is published before the next batch is
written, so a batch is never split across two files and a segment that is
larger than the bound is a batch that was larger than the bound. The frame
chain does not restart at the seam -- the previous frame's CRC, the sequence
and the batch numbering carry across it -- so a segment boundary is invisible
to the record stream and visible only to the filesystem.

Segment `i` begins exactly where segment `i-1` ended:
`base[i] == base[i-1] + size(segment i-1)`. That is what makes a frame's
position unique across the whole log rather than only within its own file, and
recovery checks it rather than assuming it. Only the LAST segment may have a
tail to repair; an unfinished tail in an earlier one means something wrote to a
segment after a later one existed, which this design does not permit, and it
fails closed.

Segment 0 must be present. The set is otherwise self-describing, but the only
way to be sure the FIRST segment is not missing is to require it -- so retiring
a segment will have to record the log's new origin in a receipt. Nothing retires
anything yet.

Publication itself is etcd's `cut()` sequence. The segment is built under
`%016x-%016x.seg.tmp`, its header is written and synced, it is renamed into its
final name, and only then is the directory synced. Nothing acknowledgeable is
written into it before it is published, so a crash anywhere in the sequence
leaves either the old set or the new one, and both replay the same committed
records. A file that has not been renamed is not part of
the log: recovery matches the exact published name and walks past everything
else, so a crash between create and rename leaves debris rather than a torn log.

Anything else in the directory -- a half-built segment, an operator's copy, an
unrelated file -- is ignored for the same reason.

## Ownership

A journal has one writer. Opening it takes an exclusive advisory lock
(`flock`) on `journal.lock` inside the directory, and it is taken BEFORE
recovery, because recovery truncates an uncommitted tail: a second opener that
got past this point would destroy work the first owner is still doing.

A second open -- in the same process or another one -- is refused as
`HDL_LOCKED`. POSIX record locks would not do: they are per-process, so a second
open in the same process would be granted the lock it already holds, which is
exactly the reproduction this rule exists to stop. `flock` is also released by
the kernel when the owner dies, so a crash never leaves a journal nobody can
open, and a stale lock file is not something recovery has to reason about.

Readers are not affected: a replay cursor reads through its own descriptors and
snapshots are read-only copies.

## Segment header (64 bytes)

| Offset | Size | Field |
|---:|---:|---|
| 0 | 8 | `HDLGv003` magic |
| 8 | 4 | header size (`64`) |
| 12 | 4 | format version (`3`) |
| 16 | 8 | segment generation |
| 24 | 8 | creation time in Unix nanoseconds |
| 32 | 8 | base position: this segment's first byte, in the log as a whole |
| 40 | 20 | reserved, zero |
| 60 | 4 | CRC32 of bytes 0..59 |

The creating process writes the header, calls the platform durability barrier,
and synchronizes the parent directory before accepting mutations.

**Base position** places the segment in one log-global byte space. A frame's
log-global position is `base_position + its offset in this segment`. A segment
at the start of the log has base position 0. Rotation assigns each new segment a
strictly greater base position, and two live segments never share one.

## Frame header (64 bytes)

| Offset | Size | Field |
|---:|---:|---|
| 0 | 4 | `HDLF` magic |
| 4 | 2 | format version |
| 6 | 2 | type: DATA (`1`) or COMMIT (`2`) |
| 8 | 4 | complete frame length |
| 12 | 4 | payload length |
| 16 | 8 | sequence (COMMIT uses the batch's last sequence) |
| 24 | 8 | batch id |
| 32 | 8 | stream id (zero for COMMIT) |
| 40 | 8 | frame position: this frame's log-global byte position |
| 48 | 8 | originating leader epoch (COMMIT carries its batch's) |
| 56 | 4 | preceding frame's CRC32 |
| 60 | 4 | CRC32 of header with this field zero, then payload |

**The originating leader epoch is why this is v3.** It names the leadership era
that CREATED the entry, never the era of whoever is storing it now, and a
follower that re-stamped a replicated entry with its own would destroy the only
thing this field exists to provide.

The log does not know what a leader is. All it enforces is that the value never
decreases, that recovery re-derives it from the bytes, and that it is inside the
frame CRC. A consensus layer maps its own notion onto it: Raft's `term`, Paxos's
ballot number, Viewstamped Replication's view number, ZooKeeper's zxid epoch.
The name is Kafka's, which uses a leader epoch for exactly this and for exactly
this reason -- KIP-101 replaced high-watermark truncation with leader-epoch
truncation after the high watermark proved unable to distinguish histories. That
is the same defect this package's `repair` had. `epoch` alone was rejected: it
collides with the segment header's Unix-nanosecond timestamp eight fields away,
and `generation` was already taken by the segment generation.

An election has to rank two logs, and length cannot do it. A leader fenced
mid-write leaves a record at sequence N; the cluster then commits a *different*
record at N under a later term; the two logs are now exactly the same length and
disagree about what happened. Ranking by length calls the fenced leader as up to
date as the cluster, elects it, and its history becomes canonical -- losing a
record a caller was told was durable on a majority. Raft ranks by
(last entry's term, last index) for precisely this reason: section 5.4.1, and
Figure 2. `specs/cluster_election_safety_spec.hey` holds the reproduction, and
it was observed failing against the length-only rule before the fix.

The chain of previous-frame CRCs is kept and does a different job. It answers
"are these the same history", which is what divergence DETECTION needs, and it
ranks nothing -- a CRC has no order. Both mechanisms are load-bearing.

Leader epochs never decrease along a log. A frame whose epoch is below its
predecessor's could not have been produced by any legal sequence of leaders, so
recovery fails closed on it rather than tolerating it, and `hdl_append_batch`
refuses one before it is written. Epoch zero belongs to no leader and is
refused.

### Reading a v2 journal

A v2 journal is **refused**, as `HDL_UNSUPPORTED_FORMAT`, and deliberately not
upgraded in place. It is not corruption -- the bytes are intact and an older
build reads them perfectly -- and the distinction matters because the operator
responses are completely different: run the older build or an offline migration,
rather than stop and restore from a snapshot.

It is not converted automatically because **a leader epoch cannot be invented
for an entry written before epochs existed**. Fabricating one would manufacture exactly
the consensus history that the election restriction then trusts, which is worse
than refusing: it would produce a log that *looks* rankable and ranks wrongly.
Old journals are preserved untouched: the refusal does not truncate, rewrite or
delete anything, because both documented recoveries -- run the older build, or
run the offline migration -- need the bytes still there.

`bin/check`'s `format_migration_test` gates this, and gates the distinction
rather than only the refusal: it builds a well-formed v2 segment header (v2
magic, correct header CRC) and asserts the answer is `unsupported_format`, is
**not** `HDL_CORRUPTION`, and leaves the file byte-for-byte intact.

### Migrating a v2 journal to v3

There is exactly one legitimate conversion and one honest refusal. Nothing here
is implemented yet; this is the contract any tool that does it must meet, and
the reason no tool ships in the meantime is that the wrong conversion is worse
than none.

**The conversion is offline, from a verified agreed snapshot.** Never in place,
never against a live journal, and never against a v2 journal alone.

A v3 entry carries the leader epoch it ORIGINATED in, and the election
restriction ranks candidates by `(last entry's epoch, last index)`. That number
is not decoration and it is not derivable from a v2 journal: nothing in v2
records which leadership era wrote a given entry. So the epochs have to come
from somewhere that actually knew them, and the only such source is a snapshot
the cluster agreed on, carrying the last included index AND epoch (snapshot
receipt version 2, above).

A conversion is legitimate when, and only when, all of these hold:

1. **A verified snapshot exists**, verified the way this package verifies one --
   read back, replayed, and compared against its own receipt -- and its receipt
   is version 2, so it names both the last included index and the last included
   epoch.
2. **The v2 journal continues that snapshot exactly**: its first entry is the
   one immediately after the snapshot's last included index, and the chain of
   previous-frame CRCs from the snapshot's boundary through the journal is
   unbroken.
3. **The epoch for every converted entry is ESTABLISHED, not assumed.** For
   entries at or below the snapshot's last included index, the snapshot supplies
   it. For entries above it, the epoch must come from durable consensus records
   -- a recorded vote and term from the era that wrote them -- and where the
   cluster cannot produce those, those entries **are not convertible**.
4. **The result is a new journal directory.** The v2 one is left untouched, so a
   conversion that is later found to be wrong is recoverable by throwing away
   its output.

Conversion **must be refused**, rather than attempted, when any of these hold:

- there is no verified snapshot, or its receipt is version 1 (version 1 receipts
  carry no epoch, which is the whole problem);
- the snapshot and the journal do not join at an exact frame boundary with an
  unbroken CRC chain;
- any entry's originating epoch cannot be established from durable records;
- the journal was ever replicated and the cluster cannot agree on what was
  committed. A single node's opinion about a replicated log is not consensus
  history, and converting on it would produce a rankable-looking log that ranks
  wrongly -- exactly the failure the refusal exists to prevent.

**A single-node, never-replicated v2 journal is convertible at a synthetic
epoch, and the receipt must SAY SO.** This is the one case where inventing a
number is defensible, because there was never more than one writer and therefore
never a leadership era to get wrong: every entry belongs to the only era there
was. Such a journal is converted at epoch 1.

It is defensible only as long as the result never joins a cluster. A synthetic
epoch is not consensus history; it is a placeholder that happens to be
unambiguous because there was no competition. So the conversion receipt must
record, in these terms:

- `epochs: synthetic` and the value used;
- `replicated: never`, and the evidence for that claim, not the assumption;
- `must_not_join_a_cluster: true`.

A converted journal whose receipt says `epochs: synthetic` must be refused entry
to a cluster by whatever admits nodes to one. If that refusal cannot be
enforced, the conversion must not be offered.

**Every conversion writes a receipt naming what it did and what it could not
establish.** A tool that converts silently is not acceptable here: the operator
needs to know which entries got their epoch from a snapshot, which from consensus
records, which from a synthetic value, and which were left behind. A receipt that
lists only what succeeded is a receipt that hides the entries it dropped, and the
entries it dropped are the ones an operator most needs to know about. At minimum
it records: the source journal, the snapshot and its digest, the resulting
journal, the entry range converted, the provenance of every epoch assigned, and
an explicit list of anything not converted with the reason.

The previous-frame CRC detects deletion and reordering as well as accidental
damage. It is not a cryptographic authentication mechanism.

**Frame position is why this is v2.** The v1 chain of previous-frame CRCs is
position-independent: a frame carrying the right previous CRC validates wherever
it physically sits. That was harmless while one segment only ever grew. It stops
being harmless the moment a segment file is reused, recycled or preallocated,
because the file then holds complete, correctly-checksummed frames that belong
to an earlier place in the log, and nothing in a v1 frame says so. PostgreSQL
lives with exactly that file -- it recycles WAL segments with a bare rename and
no zeroing -- and Tom Lane put the consequence plainly on pgsql-hackers,
2018-01-12: "recognizing that the new record has an old xl_prev is our ONLY
defense against replaying stale data."

Each frame therefore names the log-global position it was written for, and the
name is inside the frame CRC, so it is as hard to forge by accident as the
payload. Recovery replays a frame only where that name matches.

Two things follow, and both were tested by observing the gate go red without
them:

- Naming the position of the PREVIOUS frame, PostgreSQL's `xl_prev`, would not
  have been enough here. A segment recycled into a new position, whose new life
  crashed before writing anything, holds its whole previous life starting at the
  first frame -- where there is no predecessor to disagree with. PostgreSQL
  catches that case with a second mechanism, the page header's own address
  (`xlp_pageaddr`); a frame that names its own position is that mechanism, and
  it subsumes the back-link.
- The position must be log-global rather than an offset within the segment. A
  recycled file reuses the same offsets, so a within-segment offset would match
  the stale frames exactly and prove nothing. The base position in the segment
  header is what makes the name global.

## Commit payload (24 bytes)

| Offset | Size | Field |
|---:|---:|---|
| 0 | 8 | first sequence |
| 8 | 8 | last sequence |
| 16 | 4 | DATA frame count |
| 20 | 4 | CRC32 over the ordered DATA-frame CRC values |

An acknowledgement is legal only after the COMMIT frame and all preceding
DATA frames have completed `fdatasync`.

## Two digests, asking two questions

`record_identity` — what `hdl_last_record_digest` reports and what a replayed
record carries — covers the **sequence, the leadership era, the stream and the
bytes**. It answers *is this the same entry*, which is what a consensus layer
needs: a leader fenced mid-write leaves `X` at sequence 3, the next leader
replays the same idempotent mutation and also writes `X` at sequence 3, and
those are **different entries** despite identical bytes. Leaving the era out
meant log matching called those histories identical while the election
restriction, which ranks by era, called the nodes different — two mechanisms
disagreeing about whether one pair of logs is one history.

The **snapshot** digest is deliberately narrower: sequence, stream and payload,
without the era. It answers *does replaying these produce the same state*, which
is what a materializer needs, and the era a record was written under does not
change what applying it does. So two snapshots of logs differing only in their
entries' epochs compare equal — correct for restore, and the reason a snapshot
digest must never decide a consensus question. `epoch` in the receipt is what
carries that, and it is compared separately.

Neither digest depends on framing. A leader group-commits many records under one
barrier while a replica applies one per request, so a framing-dependent
fingerprint would make a batching leader look divergent to every follower it
has.

## Snapshot receipt (version 2)

```text
hey_durable_log snapshot 2
segments <first index> <last index>
positions <first position> <end position>
sequences <first sequence> <last sequence>
records <count>
epoch <last included leader epoch>
digest <CRC32 over the ordered record stream>
crc <CRC32 of every line above>
```

**`epoch` is why this is version 2.** A node restarting from a snapshot has to
answer the election restriction about entries the snapshot REPLACED, and those
entries are gone -- the surviving log cannot say what leadership era they came
from. Raft keeps last included index *and* term in snapshot metadata for exactly
this reason (section 7). Without it a restored node either refuses every vote or
grants ones it should not.

A version 1 receipt is **refused** (`HDL_UNSUPPORTED_FORMAT`), not read with a
zero epoch: a zero that looks like an answer is the failure this field exists to
prevent. Version 1 receipts only accompany format v2 journals, which this build
already refuses.

The epoch is compared when a snapshot is verified, alongside the sequences,
positions and digest. A receipt that is internally consistent -- correct `crc`
-- but names an epoch its segments do not carry is refused, because a bare
checksum cannot tell that the receipt and the segments disagree.

## Recovery

The scanner validates the segment header, every complete frame, sequence and
batch monotonicity, the previous-frame chain, and the commit summary.

- A physically short final header or frame is a torn tail and is truncated to
  the last valid COMMIT boundary.
- Complete, valid DATA frames without a following COMMIT are truncated to that
  same boundary.
- A malformed or checksum-invalid complete frame is corruption and fails
  closed. Recovery does not silently discard it.
- A complete, checksum-valid frame that names a position other than the one it
  occupies is corruption and fails closed. It is a frame from somewhere else --
  a previous life of the file, or a copy spliced in -- and it is never published
  as committed data.

  This is the strict reading, and it holds because **this package does not
  recycle segment files**: a retired segment is deleted, and a preallocated
  segment is zero-filled before use, so no legitimate sequence of events puts a
  foreign frame in a live segment. If recycling is ever adopted -- and the
  Linux preallocation work is where that argument will come up -- a foreign
  frame in the tail becomes an EXPECTED condition, and this rule must change
  with it: a mismatch at or after the last committed boundary would then be
  end-of-log rather than corruption, which is what PostgreSQL does and is safe
  only because nothing acknowledged can lie beyond that boundary. Changing the
  strictness without changing the recycling decision, in either direction, is
  the error to avoid.
- Scan callbacks receive records only after their COMMIT validates.
- A replay cursor snapshots the last validated COMMIT offset when it opens.
  Later appends are intentionally invisible to that cursor, so a materializer
  can apply a finite, committed prefix and then open another cursor -- and the
  next cursor RESUMES, at a position every record carries, so catching up does
  not mean re-reading. A position that is not a frame boundary is refused rather
  than resynchronised: guessing where a record starts is how a reader invents
  one. A position below the log's origin is reported as retired, because those
  records are in a snapshot rather than gone.
- A complete batch found after a crash before the caller received its receipt
  is retained. The caller must retry with an application idempotency key; an
  error or lost response is not proof that the mutation was absent.

Sequence numbers are segment-global. `stream_id` lets an upper layer maintain
one ordered reducer per cagents workspace while fixed journal partitions
provide parallelism between workspaces.

## Snapshots and retirement

A snapshot is a journal: the same segment files under the same names, in a
directory of its own, plus `snapshot.receipt`. That is deliberate -- it means a
snapshot is validated by exactly the code that validates a journal, rather than
by a second reader written for the occasion, which is where a divergence would
hide. Only COMPLETE segments are snapshotted; the segment still being appended
to is not one, and can never be retired.

```text
hey_durable_log snapshot 1
segments <first index> <last index>
positions <first base> <end position>
sequences <first sequence> <last sequence>
records <count>
digest <CRC32 over the ordered record stream>
crc <CRC32 of the lines above>
```

Fixed-width hex, no timestamp and no paths, so the same committed prefix
produces the same receipt bytes every time: two operators can compare receipts
instead of journals, and a receipt that changed means the prefix changed. The
digest covers sequence, stream id and payload of every record -- a statement
about the record stream a consumer replays, not about how it was batched.

**Verified means restored and compared.** `hdl_snapshot_verify` reads the
snapshot back as a journal and checks what it actually replays against what the
receipt claims. A snapshot whose bytes are damaged fails earlier than that -- it
cannot be opened at all -- so the case that decides whether the comparison is
load-bearing is a readable snapshot whose receipt lies, and that is the one the
gate uses.

Retirement is the only operation here that deliberately destroys data. It
verifies the snapshot, proves the snapshot is a prefix of THIS log (ending
exactly where the surviving segments begin, and chaining into the first
surviving frame), records the retirement, and only then deletes:

```text
hey_durable_log retirement 1
next <first surviving index> <its base position>
chain <last sequence> <last batch id> <previous frame CRC>
snapshot <digest of the snapshot that justified this>
crc <CRC32 of the lines above>
```

Once segment 0 can be absent, "the set begins at 0" stops being the rule that
proves nothing was lost, so `retired.receipt` carries the whole recovery state at
the seam. Without the chain it holds, the first surviving frame refers to a
frame nobody has and a perfectly good journal reads as corruption. Recovery
ignores any segment below `next` even if a crash between recording and deleting
left it on disk, which is why the receipt is written first.

## Compatibility

v2 is a byte-format break, taken deliberately while the only released version is
0.2.0 and no v1 journal exists outside this repository's own test runs. The v1
frame header had no spare room, and taking the break after segment rotation had
written v1 segments in the field would have been far more expensive. A v1
segment header does not carry the v2 magic, so a v2 build refuses to open it
rather than misreading it; there is no conversion path and none is owed.

## Not yet in v2

- segment retirement, and the receipt that would have to record the log's new
  origin when segment 0 stops existing;
- preallocated segments (a v3 field: recovery would have to tell reserved space
  from a damaged frame, which the zero-detection heuristic this project refuses
  etcd for is the cheap way to do);
- SHA-256/BLAKE3 authentication for hostile-corruption detection;
- quorum replication and replica catch-up;
- encryption at rest;
- adaptive microbatch timing (the current broker has a bounded queue and a
  fixed configurable window);
- a Hey-visible segment size (rotation is transparent through the Hey surface
  and uses the default bound; the knob is C-level only).
