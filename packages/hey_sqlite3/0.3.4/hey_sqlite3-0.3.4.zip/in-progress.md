# In progress

Staged for the next release (unbumped; framework-extraction slice S3):

- The in-source version-literal defect is fixed: sources reported `0.2.2` at package version 0.2.6 (and the native library search path was pinned to `0.2.5`). The version now has a single source, `hey_sqlite3_version_value()` in `adapter.hey`, and `bin/package-check` guards it against `VERSION` with a grep plus a compiled version receipt.
- `Sqlite3.connect_options(options)` added (additively) as the config-record connect surface mirroring `Mysql.connect(options)`; the positional `connect(database, options)` is unchanged. Q4 (signature unification) stays open.
- `specs/store_conformance_spec.hey` proves the `hey_record_connection` store contract (store/fetch/delete/list, delete-absent -> `not_found` via `changes`) over a real file database, using a hand-copied shim of hey_record 0.3.0's sqlite3 store SQL.
- PostgreSQL-compatible `greatest()` and `least()` are registered natively on every connection `hey_sqlite3_open` returns (`native/hey_sqlite3_functions.c`, via `sqlite3_create_function_v2`). They are variadic, IGNORE NULL arguments, and return NULL only when every argument is NULL -- SQLite ships neither function, and its multi-argument `max()`/`min()` return NULL if ANY argument is NULL, so SQL written for PostgreSQL and rewritten `GREATEST(` -> `max(` silently changed answers on nullable arguments. Comparison uses SQLite's own value ordering (NULL < INTEGER/REAL < TEXT < BLOB, BINARY for TEXT/BLOB). Contract: `specs/greatest_least_spec.hey`. Consumers must rebuild the native library to pick this up.

Native Windows loading remains gated by Hey's Windows extension-loader milestone.
