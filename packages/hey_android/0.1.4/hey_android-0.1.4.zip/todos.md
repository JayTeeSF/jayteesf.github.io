# Todo

- Keystore capability.
- BiometricPrompt capability.
- WorkManager-backed Jobs.
- notifications and deep links.
- AAB generation and Play validation.
- second-application API proof.
