# Done

- 0.1.0: Poller (version/backend_for/backend/open/wait/next/data/send/drop/
  stats/close) over hey_epoll 0.1.1, hey_kqueue 0.1.0 and hey_iocp 0.0.1;
  selection at open() from Env.os() (override: HEY_POLLER_BACKEND or
  options.backend); serving calls go straight to the loaded extension (shared
  native function table); bin/build-native builds only the selected backend.
  Specs: the selection rule per OS with negative controls, hey_epoll's loop
  contract through Poller on this Mac (kqueue) and in a Linux container (epoll).
- 0.2.0: io_uring (hey_io_uring 0.1.0) as a fourth backend, selected only by
  name (`options.backend` or `HEY_POLLER_BACKEND`); Linux's default stays
  epoll until x86 numbers. An io_uring refusal falls back to this OS's
  backend with a stderr line (`warn: false` silences it) and the reason on
  the loop (`requested`, `fallback`); `strict: true` / `HEY_POLLER_STRICT=1`
  returns the error. `bin/build-native --backend io_uring` builds hey_io_uring
  and hey_epoll. Specs: the selection rule plus io_uring by name, strict,
  strict by environment and the fallback serving a request (three new
  negative controls); in Linux containers, the fallback under Docker's
  default seccomp profile and the loop contract on io_uring with
  seccomp=unconfined.
- 0.2.2: the backends move to their current releases: hey_epoll 0.1.2,
  hey_kqueue 0.1.2, hey_iocp 0.0.2 and hey_io_uring 0.1.3 (no public API
  change in any of them); hey_packager 0.1.11 in the lock. Poller's API is
  unchanged.
- 0.2.3: hey.lock.json names its paths relative to the project (0.2.2's packaged lock named /Users/... archive paths); hey_packager 0.1.13 controls. 0.2.2 was WITHDRAWN before it was ever pushed: local site commit feb99da published it and the new site commit b40d497 removes packages/hey_poller/0.2.2 and its registry-v1.json entry (history is not rewritten). Use 0.2.3; the API is unchanged.
