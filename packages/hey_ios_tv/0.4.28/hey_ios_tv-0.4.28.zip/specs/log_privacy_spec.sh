#!/usr/bin/env sh
# Execute every production NSLog call with hostile diagnostic inputs. This
# catches leaks in legacy scenes too; no network, app state or device is used.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
RUNTIME="${1:-$ROOT/tools/hey_native_tv_runtime.m}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT HUP INT TERM
ruby - "$RUNTIME" "$WORK/logs.m" <<'RUBY'
source=File.read(ARGV.fetch(0))
calls=source.scan(/NSLog\(.*?\);/m)
abort 'no native log statements found' if calls.length < 40
header=<<~'OBJC'
#import <Foundation/Foundation.h>
static NSString *HeyScreenModeName(NSInteger mode) { (void)mode; return @"auto"; }
@interface PrivacyMedia : NSObject
@property(nonatomic) double volume;
@end
@implementation PrivacyMedia
@end
@interface PrivacyHost : NSObject
@property(nonatomic) BOOL fetchInFlight;
@property(nonatomic) NSInteger consecutiveFetchFailures;
@property(copy,nonatomic) NSString *installedSchemesCache;
@property(copy,nonatomic) NSString *currentRadio;
@property(nonatomic) BOOL soundtrackMuted;
@property(nonatomic) BOOL effectsMuted;
@property(nonatomic) NSInteger screenMode;
@property(nonatomic) NSInteger settingsIndex;
@property(nonatomic) BOOL sceneKeepAwake;
@property(strong,nonatomic) PrivacyMedia *radioPlayer;
@property(strong,nonatomic) PrivacyMedia *videoPlayer;
- (void)exercise;
@end
@implementation PrivacyHost
- (void)exercise {
  NSString *secret = @"tv-aaaaaaaaaaaaaaaaaaaaaaaa";
  NSString *address = [@"https://private.example.org/tv/" stringByAppendingString:secret];
  NSString *wanted=address, *name=address, *current=address, *bootstrap=address;
  NSString *url=address, *reference=address, *urlString=address, *path=address, *submit=address, *finishedKey=address;
  NSString *hex=secret, *fileName=address, *subsystem=@"sound";
  NSString *text=@"PRIVATE QUERY TEXT", *q=text;
  NSString *eventJson=[NSString stringWithFormat:@"{\"kind\":\"remote\",\"value\":\"%@\",\"credential\":\"Bearer synthetic-api-secret\"}",address];
  NSError *error=[NSError errorWithDomain:@"privacy-test" code:7 userInfo:@{NSLocalizedDescriptionKey:address}];
  NSError *sessionError=error, *startError=error;
  NSArray *items=@[], *found=@[];
  BOOL remote=YES, loops=YES, loop=YES, success=YES, playing=YES;
  double pressAt=CFAbsoluteTimeGetCurrent(), volume=0.5;
  self.installedSchemesCache=@"nflx,youtube";
  self.currentRadio=address;
  self.radioPlayer=[PrivacyMedia new]; self.videoPlayer=[PrivacyMedia new];
OBJC
footer=<<~'OBJC'
}
@end
int main(void) { @autoreleasepool { [[PrivacyHost new] exercise]; } return 0; }
OBJC
File.write(ARGV.fetch(1),header+calls.join("\n")+"\n"+footer)
puts "exercising #{calls.length} production native log statements"
RUBY
clang -fobjc-arc -Wno-unused-variable -framework Foundation "$WORK/logs.m" -o "$WORK/logs"
"$WORK/logs" >"$WORK/output" 2>&1
if rg -n 'tv-aaaaaaaaaaaaaaaaaaaaaaaa|://|synthetic-api-secret|PRIVATE QUERY TEXT' "$WORK/output"; then
  echo 'FAIL native diagnostics exposed a device credential, URL, event or query' >&2
  exit 1
fi
# Controls ensure the test actually emitted diagnostics, including legacy
# recovery, search, playback and identity paths, instead of compiling no-ops.
for label in 'step:' 'bootstrap' 'keyboard:' 'open_url:' 'audio' 'video' 'identity'; do
  rg -F "$label" "$WORK/output" >/dev/null || { echo "FAIL missing exercised log category $label" >&2; exit 1; }
done
echo 'PASS all native diagnostic output excludes credentials, URLs, event bodies and search text'
# Compile the scene-v2 branch that ships in apps (the older live-data check
# also compiles the v1 branch). These are host evidence, not device acceptance.
if xcrun --sdk appletvos --show-sdk-path >/dev/null 2>&1; then
  sdk="$(xcrun --sdk appletvos --show-sdk-path)"
  CLANG_MODULE_CACHE_PATH="$WORK/modules" xcrun --sdk appletvos clang \
    --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -DHEY_SCENE_V2 -fsyntax-only "$RUNTIME"
  echo 'PASS actual scene-v2 runtime compiles for tvOS'
fi
