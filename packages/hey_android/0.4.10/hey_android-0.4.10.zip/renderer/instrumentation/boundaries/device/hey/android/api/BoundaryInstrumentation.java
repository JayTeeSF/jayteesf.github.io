package hey.android.api;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.browse.MediaBrowser;
import android.media.session.MediaController;
import android.os.Bundle;
import android.util.Log;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Uses the real player, MediaBrowserService, HTTP stack and main looper on the device. */
public final class BoundaryInstrumentation extends Instrumentation {
  private HeyAndroidPlayback playback;
  private MediaBrowser browser;
  private MediaController controller;
  private final AtomicInteger checks = new AtomicInteger();
  private void check(boolean good, String message) {
    if (!good) throw new AssertionError(message);
    checks.incrementAndGet();
    Log.i("hey.boundary", "PASS: " + message);
    Bundle report = new Bundle(); report.putString("stream", "PASS: " + message + "\n"); sendStatus(0, report);
  }
  private void main(Runnable action) { runOnMainSync(action); }
  private void waitFor(java.util.function.BooleanSupplier condition) throws Exception {
    long until = System.nanoTime() + TimeUnit.SECONDS.toNanos(15);
    while (!condition.getAsBoolean() && System.nanoTime() < until) Thread.sleep(50);
    if (!condition.getAsBoolean()) throw new AssertionError("device condition timed out");
  }
  private boolean idle() {
    AtomicBoolean idle = new AtomicBoolean();
    main(() -> idle.set(playback.player.track() == null && playback.player.state() == HeyAndroidPlayer.State.IDLE));
    return idle.get();
  }
  private boolean playing() {
    AtomicBoolean playing = new AtomicBoolean();
    main(() -> playing.set(playback.player.state() == HeyAndroidPlayer.State.PLAYING));
    return playing.get();
  }
  @Override public void onCreate(Bundle arguments) { super.onCreate(arguments); start(); }
  @Override public void onStart() {
    Bundle result = new Bundle();
    try {
      runChecks();
      result.putString("stream", "PASS: " + checks.get() + " Android boundary device checks\n");
      finish(Activity.RESULT_OK, result);
    } catch (Throwable error) {
      Log.e("hey.boundary", "FAIL: " + error, error);
      result.putString("stream", "FAIL: " + error + "\n");
      finish(Activity.RESULT_CANCELED, result);
    } finally {
      main(() -> {
        if (playback != null) { playback.changeSession(null); playback.http.close(); }
        if (browser != null) browser.disconnect();
        getTargetContext().stopService(new Intent(getTargetContext(), HeyAndroidAudioService.class));
      });
    }
  }
  private void runChecks() throws Exception {
    Context context = getTargetContext();
    main(() -> {
      try {
        HeyAndroidDescription description = new HeyAndroidDescription(context);
        new HeyAndroidSecureStore(context, description.storeName()).write("synthetic-A");
        playback = HeyAndroidPlayback.of(context);
        playback.changeSession("synthetic-A");
      } catch (Exception error) { throw new RuntimeException(error); }
    });
    String origin = playback.http.origin;
    check(!Origins.same(origin, origin.replace("10.0.2.2", "10.0.2.2.attacker.invalid") + "/audio")
        && !Origins.same(origin, origin.replace("10.0.2.2", "u@10.0.2.2") + "/audio")
        && !Origins.same(origin, origin.replace("http:", "https:") + "/audio")
        && !Origins.same(origin, "http://10.0.2.2:1/audio"), "parsed origin rejects lookalike, userinfo, scheme and port on Android");
    HeyAndroidMediaSource source = new HeyAndroidMediaSource(origin + "/audio.wav", playback.headers());
    byte[] head = new byte[4];
    check(source.getSize() == 192044 && source.readAt(0, head, 0, 4) == 4
        && new String(head, java.nio.charset.StandardCharsets.US_ASCII).equals("RIFF"), "real authenticated HTTP range reads preserve media size and bytes");
    source.close();
    for (String redirect : new String[] {"host", "scheme", "port"}) {
      HeyAndroidMediaSource refused = new HeyAndroidMediaSource(origin + "/redirect/" + redirect, playback.headers());
      boolean blocked = false;
      try { refused.getSize(); } catch (IOException expected) { blocked = true; }
      finally { refused.close(); }
      check(blocked, "real HTTP " + redirect + " redirect refuses credential forwarding");
    }
    CountDownLatch connected = new CountDownLatch(1), feed = new CountDownLatch(1);
    main(() -> {
      browser = new MediaBrowser(context, new ComponentName(context, HeyAndroidAudioService.class), new MediaBrowser.ConnectionCallback() {
        @Override public void onConnected() {
          controller = new MediaController(context, browser.getSessionToken());
          browser.subscribe("root", new MediaBrowser.SubscriptionCallback() {
            @Override public void onChildrenLoaded(String id, List<MediaBrowser.MediaItem> children) { feed.countDown(); }
          });
          connected.countDown();
        }
      }, null);
      browser.connect();
    });
    check(connected.await(15, TimeUnit.SECONDS) && feed.await(15, TimeUnit.SECONDS), "real car browser connects and loads the authenticated A feed");
    main(() -> controller.getTransportControls().playFromMediaId("a-track", null));
    waitFor(this::playing);
    waitFor(() -> controller.getMetadata() != null);
    check(controller.getMetadata().getString(MediaMetadata.METADATA_KEY_TITLE).equals("Account A"), "real MediaPlayer plays authenticated ranges and publishes account A car metadata");
    main(() -> {
      new HeyAndroidSecureStore(context, playback.description.storeName()).write("synthetic-B");
      playback.changeSession("synthetic-B");
    });
    waitFor(() -> idle() && controller.getMetadata() == null);
    AtomicBoolean oldFeed = new AtomicBoolean();
    main(() -> oldFeed.set(playback.feed() != null && Json.encode(playback.feed()).contains("Account A")));
    check(!oldFeed.get(), "A to B stops the native player and removes A feed/lock-screen/car metadata");
    CountDownLatch bfeed = new CountDownLatch(1);
    main(() -> playback.withFeed(bfeed::countDown, () -> {}));
    check(bfeed.await(15, TimeUnit.SECONDS), "B obtains a new car feed");
    AtomicBoolean hasB = new AtomicBoolean();
    main(() -> hasB.set(Json.encode(playback.feed()).contains("Account B")));
    check(hasB.get(), "new car feed contains B content only");
    AtomicInteger ready = new AtomicInteger(), cancelled = new AtomicInteger();
    main(() -> {
      playback.changeSession("synthetic-C");
      Json.dict(playback.audio().get("source")).put("path", "/feed/slow");
      playback.withFeed(ready::incrementAndGet, cancelled::incrementAndGet);
    });
    Thread.sleep(200);
    main(() -> playback.changeSession(null));
    Thread.sleep(2400);
    check(ready.get() == 0 && cancelled.get() == 1 && idle() && controller.getMetadata() == null,
        "logout cancels an in-flight real car feed and leaves native playback/metadata empty");
  }
}
