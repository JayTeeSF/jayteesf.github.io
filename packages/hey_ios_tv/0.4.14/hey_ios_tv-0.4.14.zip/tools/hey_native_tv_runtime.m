#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreImage/CoreImage.h>
#import <AVFoundation/AVFoundation.h>
#include <math.h>   // sin/exp/M_PI for the synthesised sound cues (0.4.9)
#include <stdint.h>

// hey_ios_tv native tvOS app template.
//
// The real Hey runtime (claude_01 runtime/hey_runtime.c, compiled for the
// Apple TV target) is linked into every app, so the v1 no-runtime string
// shim is GONE -- the runtime provides hey_runtime_init/shutdown, the
// hey_llvm_* string helpers, and the boxed-value ABI. The build script
// (hey-ios-tv-app.sh) calls hey_runtime_init() before the first scene is
// built and hey_runtime_shutdown() on termination.
//
// One template, two contracts, selected at build time by -DHEY_SCENE_V2:
//   * HEY_SCENE_V2 defined  -> scene-contract-v2 JSON renderer (below).
//   * otherwise             -> the v1 opaque-i64 game contract (unchanged).
// The build script nm-checks the compiled app object for
// _hey_fn_tv_scene_init and defines HEY_SCENE_V2 when it is present.

// ---- runtime (provided by hey_runtime.c, linked in) ---------------------
extern void hey_runtime_init(void);
extern void hey_runtime_shutdown(void);
extern void hey_runtime_set_argv(int argc, char **argv);
// Extract a C string from a Hey str return. Hey str-returning entries come
// back either as a raw NUL-terminated C string (single-expression returns)
// or as a boxed HeyValue* (control-flow returns). A boxed value's first
// word is its kind enum (0..13); scene JSON always starts with '{' (123) or
// '[' (91), so the first word disambiguates the two representations safely.
extern char *hey_llvm_value_to_raw_string_cstr(void *value);

static NSString *HeyStringFromReturn(const void *ret) {
  if (!ret) { return @""; }
  uint32_t tag = *(const uint32_t *)ret;         // HeyKind for a boxed value
  if (tag <= 13) {                               // HEY_ACTOR_DEFINITION == 13
    char *owned = hey_llvm_value_to_raw_string_cstr((void *)ret);
    NSString *s = owned ? [NSString stringWithUTF8String:owned] : @"";
    if (owned) { free(owned); }                  // owned copy from the runtime
    return s;                                     // boxed HeyValue* leaks (bounded, per-step)
  }
  return [NSString stringWithUTF8String:(const char *)ret];  // raw runtime cstr; do not free
}

#if defined(HEY_SCENE_V2)
// =========================================================================
// scene-contract-v2 renderer (hey-tv-scene-v2)
// =========================================================================
extern const char *hey_fn_tv_scene_init(void);
extern const char *hey_fn_tv_scene_step(const char *scene_json, const char *event_json);

static UIColor *HeyColorFromHex(NSString *hex, UIColor *fallback) {
  if (![hex isKindOfClass:NSString.class]) { return fallback; }
  NSString *s = [[hex stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet]
                    stringByReplacingOccurrencesOfString:@"#" withString:@""];
  if (s.length != 6 && s.length != 8) { return fallback; }
  unsigned int rgb = 0;
  NSScanner *scan = [NSScanner scannerWithString:s.length == 8 ? [s substringFromIndex:2] : s];
  if (![scan scanHexInt:&rgb]) { return fallback; }
  return [UIColor colorWithRed:((rgb >> 16) & 0xFF) / 255.0
                         green:((rgb >> 8) & 0xFF) / 255.0
                          blue:(rgb & 0xFF) / 255.0
                         alpha:1.0];
}

// --- inline markdown ---------------------------------------------------
//
// A DELIBERATELY SMALL SUBSET: **bold**, *italic*, and `code`. Nothing else.
//
// UNDERSCORE IS NOT A MARKER, and that is not an oversight. This app writes
// fill-in-the-blank stems as runs of underscores -- "Plant cells use the ____
// to turn sunlight into sugar" -- and there are nine such stems in the sample
// decks alone. Treating _ as italic would mangle every cloze question on the
// wall. Caught by testing the parser against real content, not by reading it.
//
// The subset is small because this renders a question on a wall for a whole
// room, so the only formatting worth having is the kind that survives being
// read from the back: emphasis on the word that carries the question, and a
// monospace run for a term or a formula that must be read literally.
// Headings are already the widget style; links and images mean nothing on a
// screen nobody touches.
//
// BACKWARD COMPATIBILITY IS THE FIRST REQUIREMENT. Text containing no marker
// must render EXACTLY as it did before this existed -- every pack already in
// the field, and every scene the server renders today, is unmarked text. So
// HeyAttributedFromMarkdown returns a plain attributed string in that case,
// and an unmatched or stray marker is emitted LITERALLY rather than eating
// the rest of the line. A student reading "2 * 3 * 4" must see asterisks, not
// an italic 3. For the same reason the backslash escape covers ONLY the
// markers and itself: a backslash in unmarked text is not an escape and is
// emitted as itself, so "C:\Users" does not quietly lose a character.
//
// Traits are derived from the label's own font via its descriptor, so bold
// and italic follow whatever size and weight the widget style chose -- a bold
// run inside a 76pt title is a bold 76pt title, not a hardcoded size.
static UIFont *HeyFontWithTraits(UIFont *base, UIFontDescriptorSymbolicTraits add) {
  UIFontDescriptor *d = base.fontDescriptor;
  UIFontDescriptorSymbolicTraits want = d.symbolicTraits | add;
  UIFontDescriptor *nd = [d fontDescriptorWithSymbolicTraits:want];
  if (!nd) { return base; }
  return [UIFont fontWithDescriptor:nd size:base.pointSize];
}

static NSAttributedString *HeyAttributedFromMarkdown(NSString *src, UIFont *base, UIColor *color) {
  NSMutableAttributedString *out = [[NSMutableAttributedString alloc] init];
  NSUInteger n = src.length;
  NSUInteger i = 0;
  NSMutableString *run = [NSMutableString string];

  // Flush the plain run collected so far with the current base attributes.
  void (^flush)(void) = ^{
    if (run.length == 0) { return; }
    [out appendAttributedString:[[NSAttributedString alloc] initWithString:run
        attributes:@{NSFontAttributeName: base, NSForegroundColorAttributeName: color}]];
    [run setString:@""];
  };

  while (i < n) {
    unichar c = [src characterAtIndex:i];

    // A backslash escapes a MARKER, or another backslash, so a literal
    // asterisk or backtick can always be written. It escapes NOTHING ELSE,
    // and that restriction is the backward-compatibility rule again rather
    // than a stylistic choice. An escape that swallowed whatever followed it
    // would silently DELETE the backslash from every unmarked string that
    // happens to contain one -- "C:\Users", "\alpha", "a\b" -- none of which
    // opted into markdown and all of which rendered literally before this
    // existed. In front of an ordinary character the backslash falls through
    // to the literal-text path below and is emitted as itself.
    if (c == '\\' && i + 1 < n) {
      unichar next = [src characterAtIndex:i + 1];
      if (next == '*' || next == '`' || next == '\\') {
        [run appendFormat:@"%C", next];
        i += 2;
        continue;
      }
    }

    NSString *marker = nil;
    UIFontDescriptorSymbolicTraits traits = 0;
    BOOL mono = NO;
    if (c == '*' && i + 1 < n && [src characterAtIndex:i + 1] == '*') {
      marker = @"**"; traits = UIFontDescriptorTraitBold;
    } else if (c == '*') {
      marker = @"*"; traits = UIFontDescriptorTraitItalic;
    } else if (c == '`') {
      marker = @"`"; mono = YES;
    }

    if (marker) {
      NSRange rest = NSMakeRange(i + marker.length, n - i - marker.length);
      // THE FLANKING RULE, and it is what makes arithmetic safe. An emphasis
      // marker only opens when the character after it is NOT whitespace, and
      // only closes when the character before it is NOT whitespace. Without
      // it "2 * 3 * 4 equals 24" renders as "2  3  4" with an italic 3 --
      // measured, not imagined, before this rule existed. Code spans are
      // exempt: `  ` is a legitimate literal.
      BOOL emphasis = !mono;
      BOOL opens = rest.length > 0 &&
          (!emphasis || ![[NSCharacterSet whitespaceCharacterSet]
                            characterIsMember:[src characterAtIndex:rest.location]]);
      if (!opens) {
        [run appendString:marker];
        i += marker.length;
        continue;
      }
      NSRange close = [src rangeOfString:marker options:0 range:rest];
      // A closer preceded by whitespace does not close. Walk on to the next
      // candidate rather than giving up, so "*a * b*" still emphasises.
      while (emphasis && close.location != NSNotFound && close.location > rest.location &&
             [[NSCharacterSet whitespaceCharacterSet]
                characterIsMember:[src characterAtIndex:close.location - 1]]) {
        NSUInteger from = close.location + marker.length;
        if (from >= n) { close = NSMakeRange(NSNotFound, 0); break; }
        close = [src rangeOfString:marker options:0 range:NSMakeRange(from, n - from)];
      }
      NSUInteger inner = (close.location == NSNotFound) ? 0 : close.location - rest.location;
      // An unmatched marker, or an empty span, is literal text -- never a
      // swallowed rest-of-line.
      if (close.location == NSNotFound || inner == 0) {
        [run appendString:marker];
        i += marker.length;
        continue;
      }
      flush();
      NSString *span = [src substringWithRange:NSMakeRange(rest.location, inner)];
      UIFont *font = mono
          ? [UIFont monospacedSystemFontOfSize:base.pointSize weight:UIFontWeightRegular]
          : HeyFontWithTraits(base, traits);
      [out appendAttributedString:[[NSAttributedString alloc] initWithString:span
          attributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color}]];
      i = close.location + marker.length;
      continue;
    }

    [run appendFormat:@"%C", c];
    i += 1;
  }
  flush();
  return out;
}

static UIColor *HeyScaleColor(UIColor *base, CGFloat factor) {
  CGFloat r = 0, g = 0, b = 0, a = 1;
  [base getRed:&r green:&g blue:&b alpha:&a];
  return [UIColor colorWithRed:MIN(1, r * factor) green:MIN(1, g * factor) blue:MIN(1, b * factor) alpha:a];
}

// ---- a single playing card (renderer-owned geometry + style) ------------
// 2.5:3.5 proportions, white face with corner rank+suit indices and a large
// center pip, hearts/diamonds red and spades/clubs near-black, soft drop
// shadow; a face-down card is a deep-blue patterned back with a border.
@interface HeyCardView : UIView
@property(copy, nonatomic) NSString *rank;
@property(copy, nonatomic) NSString *suit;
@property(nonatomic) BOOL faceUp;
@end

@implementation HeyCardView

+ (CGFloat)widthForHeight:(CGFloat)h { return h / 1.4; }   // 2.5 : 3.5

- (instancetype)initWithHeight:(CGFloat)h {
  CGFloat w = [HeyCardView widthForHeight:h];
  self = [super initWithFrame:CGRectMake(0, 0, w, h)];
  if (self) {
    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.layer.shadowColor = UIColor.blackColor.CGColor;
    self.layer.shadowOpacity = 0.35;
    self.layer.shadowRadius = 10.0;
    self.layer.shadowOffset = CGSizeMake(0, 7);
    [NSLayoutConstraint activateConstraints:@[
      [self.widthAnchor constraintEqualToConstant:w],
      [self.heightAnchor constraintEqualToConstant:h],
    ]];
    self.translatesAutoresizingMaskIntoConstraints = NO;
  }
  return self;
}

- (NSString *)pipGlyph {
  NSString *s = self.suit.lowercaseString;
  if ([s hasPrefix:@"spade"]) { return @"♠"; }
  if ([s hasPrefix:@"heart"]) { return @"♥"; }
  if ([s hasPrefix:@"diamond"]) { return @"♦"; }
  if ([s hasPrefix:@"club"]) { return @"♣"; }
  return @"?";
}

- (UIColor *)suitColor {
  NSString *s = self.suit.lowercaseString;
  if ([s hasPrefix:@"heart"] || [s hasPrefix:@"diamond"]) {
    return [UIColor colorWithRed:0xC0 / 255.0 green:0x39 / 255.0 blue:0x2B / 255.0 alpha:1.0]; // #C0392B
  }
  return [UIColor colorWithWhite:0.10 alpha:1.0]; // near-black
}

- (void)layoutSubviews {
  [super layoutSubviews];
  CGFloat radius = self.bounds.size.width * 0.09;
  self.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:radius].CGPath;
}

- (void)drawRect:(CGRect)rect {
  CGRect b = self.bounds;
  CGFloat w = b.size.width, h = b.size.height;
  CGFloat radius = w * 0.09;
  UIBezierPath *card = [UIBezierPath bezierPathWithRoundedRect:b cornerRadius:radius];

  if (!self.faceUp) {
    // deep-blue patterned back with border
    UIColor *back = [UIColor colorWithRed:0x16 / 255.0 green:0x30 / 255.0 blue:0x5C / 255.0 alpha:1.0]; // #16305C
    [back setFill];
    [card fill];
    CGRect inner = CGRectInset(b, w * 0.07, w * 0.07);
    UIBezierPath *innerPath = [UIBezierPath bezierPathWithRoundedRect:inner cornerRadius:radius * 0.7];
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSaveGState(ctx);
    [innerPath addClip];
    UIColor *hatch = [UIColor colorWithRed:0x3A / 255.0 green:0x5B / 255.0 blue:0x9C / 255.0 alpha:0.9];
    [hatch setStroke];
    UIBezierPath *lines = [UIBezierPath bezierPath];
    lines.lineWidth = 2.0;
    CGFloat step = w * 0.17;
    for (CGFloat x = -h; x < w + h; x += step) {
      [lines moveToPoint:CGPointMake(x, 0)];
      [lines addLineToPoint:CGPointMake(x + h, h)];
      [lines moveToPoint:CGPointMake(x + h, 0)];
      [lines addLineToPoint:CGPointMake(x, h)];
    }
    [lines stroke];
    CGContextRestoreGState(ctx);
    [[UIColor colorWithRed:0x8F / 255.0 green:0xAB / 255.0 blue:0xE0 / 255.0 alpha:1.0] setStroke];
    innerPath.lineWidth = 3.0;
    [innerPath stroke];
    return;
  }

  // white face
  [[UIColor colorWithRed:0.99 green:0.99 blue:0.97 alpha:1.0] setFill];
  [card fill];
  [[UIColor colorWithWhite:0.86 alpha:1.0] setStroke];
  card.lineWidth = 1.5;
  [card stroke];

  UIColor *color = [self suitColor];
  NSString *pip = [self pipGlyph];
  NSString *rk = self.rank.length ? self.rank.uppercaseString : @"?";

  // large center pip
  UIFont *centerFont = [UIFont systemFontOfSize:h * 0.42 weight:UIFontWeightMedium];
  NSDictionary *centerAttrs = @{ NSFontAttributeName: centerFont, NSForegroundColorAttributeName: color };
  CGSize cs = [pip sizeWithAttributes:centerAttrs];
  [pip drawAtPoint:CGPointMake((w - cs.width) / 2.0, (h - cs.height) / 2.0) withAttributes:centerAttrs];

  // corner index: rank over suit pip, top-left and (rotated) bottom-right
  UIFont *rankFont = [UIFont systemFontOfSize:h * 0.15 weight:UIFontWeightSemibold];
  UIFont *smallPipFont = [UIFont systemFontOfSize:h * 0.13 weight:UIFontWeightRegular];
  NSDictionary *rankAttrs = @{ NSFontAttributeName: rankFont, NSForegroundColorAttributeName: color };
  NSDictionary *smallPipAttrs = @{ NSFontAttributeName: smallPipFont, NSForegroundColorAttributeName: color };
  CGFloat inset = w * 0.09;

  [rk drawAtPoint:CGPointMake(inset, inset * 0.7) withAttributes:rankAttrs];
  [pip drawAtPoint:CGPointMake(inset, inset * 0.7 + rankFont.lineHeight * 0.85) withAttributes:smallPipAttrs];

  CGContextRef ctx = UIGraphicsGetCurrentContext();
  CGContextSaveGState(ctx);
  CGContextTranslateCTM(ctx, w, h);
  CGContextRotateCTM(ctx, M_PI);
  [rk drawAtPoint:CGPointMake(inset, inset * 0.7) withAttributes:rankAttrs];
  [pip drawAtPoint:CGPointMake(inset, inset * 0.7 + rankFont.lineHeight * 0.85) withAttributes:smallPipAttrs];
  CGContextRestoreGState(ctx);
}
@end

// ---- an empty stack slot: a dashed rounded outline ----------------------
@interface HeyCardSlotView : UIView
@end
@implementation HeyCardSlotView
- (instancetype)initWithHeight:(CGFloat)h {
  CGFloat w = [HeyCardView widthForHeight:h];
  self = [super initWithFrame:CGRectMake(0, 0, w, h)];
  if (self) {
    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
      [self.widthAnchor constraintEqualToConstant:w],
      [self.heightAnchor constraintEqualToConstant:h],
    ]];
  }
  return self;
}
- (void)drawRect:(CGRect)rect {
  CGRect b = CGRectInset(self.bounds, 3, 3);
  UIBezierPath *p = [UIBezierPath bezierPathWithRoundedRect:b cornerRadius:b.size.width * 0.09];
  CGFloat dashes[] = {12, 9};
  [p setLineDash:dashes count:2 phase:0];
  p.lineWidth = 3.0;
  [[UIColor colorWithWhite:1.0 alpha:0.35] setStroke];
  [p stroke];
}
@end

@interface HeySceneViewController : UIViewController
@property(copy, nonatomic) NSString *sceneJson;
@property(strong, nonatomic) UIView *contentView;
@property(strong, nonatomic) CAGradientLayer *feltLayer;
@property(nonatomic) BOOL seeded;
// Live-data support (0.4.0). A scene may declare "tick" and/or "fetch"; the
// renderer owns the clock and the socket so the Hey app stays pure.
@property(strong, nonatomic) NSTimer *pollTimer;
@property(copy, nonatomic) NSString *pollSignature;
@property(nonatomic) BOOL fetchInFlight;
// Bootstrap fallback: the fetch url baked into the app's OWN first scene
// (tv_scene_init), kept separately from whatever url the poll has since been
// re-armed onto, plus a count of consecutive failed scene-mode polls.
@property(copy, nonatomic) NSString *bootstrapFetchUrl;
@property(nonatomic) NSInteger consecutiveFetchFailures;
// Back-button support (0.4.6). YES only while the CURRENTLY INSTALLED scene
// declares top-level "handles_back": true; re-evaluated on every scene
// install (renderScene), because scenes change every poll.
@property(nonatomic) BOOL handlesBack;
// What the CURRENTLY INSTALLED scene declared in "keep_awake" -- kept, not just
// applied, because it is only half of the answer: the reel below overrides it
// while a film is actually playing, and the override has to survive the next
// poll re-declaring the scene's own value.
@property(nonatomic) BOOL sceneKeepAwake;
// Whether WE consumed the in-flight Menu press at press-down. The decision
// is captured once in -pressesBegan: and reused for the matching
// ended/cancelled, so a poll that swaps the scene mid-press can never split
// one physical press between the funnel and the system.
@property(nonatomic) BOOL menuPressOwned;
// Sound (0.4.9). The engine is built lazily on the first scene that actually
// asks for a cue, so an app that never declares "sound" allocates no audio
// objects and behaves byte-identically to 0.4.8.
@property(strong, nonatomic) AVAudioEngine *audioEngine;
@property(strong, nonatomic) AVAudioPlayerNode *audioPlayer;
// The cue CURRENTLY sounding. This is the whole idempotence mechanism: a
// scene-mode poll re-installs the document every couple of seconds, so
// starting playback per install would retrigger the cue endlessly. Playback
// changes only when the resolved cue name actually differs from this.
@property(copy, nonatomic) NSString *currentCue;
// Graphics (0.4.9). Remote images are fetched once and reused, keyed by url.
// NSCache so tvOS can evict under pressure rather than growing without bound.
@property(strong, nonatomic) NSCache *imageCache;
// Video (0.4.13). The ATTRACT REEL: a display nobody is using plays the demo
// with sound until someone touches the remote.
@property(strong, nonatomic) AVPlayer *videoPlayer;
@property(strong, nonatomic) AVPlayerLayer *videoLayer;
// The end-of-item observer TOKEN. It has to be kept, because the block form of
// addObserverForName: registers an opaque observer object -- NOT self -- and
// `removeObserver:self` therefore removes nothing. Without the token each
// install leaks a registration.
@property(strong, nonatomic) id videoEndObserver;
// The KEY currently playing -- "file:<name>" for a bundled reel, otherwise the
// url. The same idempotence mechanism the cue uses, and for the same reason:
// the scene is re-installed every couple of seconds, so starting playback per
// install would restart the reel ~30x a minute. It is the resolved key rather
// than the url because a bundled reel has no url at all, and comparing on a
// nil field never matches.
@property(copy, nonatomic) NSString *currentVideo;
// The key that MUST NOT START AGAIN while the scene keeps asking for it. Two
// things put a key here, and both need the identical treatment because the
// server goes on emitting the same scene until it notices something changed:
//   - the VIEWER dismissed it (any remote press stops the reel; without this
//     the next poll restarts it two seconds later and the remote appears dead)
//   - it PLAYED TO THE END with loop:false (the film is over; without this the
//     next poll plays it again, forever)
// A resource that could not be resolved lands here too, so a missing bundle
// file is one log line rather than one every two seconds.
// Cleared when the key changes or video goes away, so a later reel still plays.
@property(copy, nonatomic) NSString *suppressedVideo;
// The reel's REQUESTED volume, kept apart from the volume actually applied to
// the player. Muting writes 0 to the player and never to this, so unmuting
// restores the volume the scene asked for -- not 1.0, which would blast a room
// the maintainer deliberately keeps quiet.
@property(nonatomic) double videoRequestedVolume;
// ---- per-television sound settings (0.4.13) ------------------------------
// A mute belongs to ONE television in ONE room, so it lives here and in
// NSUserDefaults, never on the server: server-held state would either follow
// every display on the account or need per-display storage that does not
// exist. Both default to NOT muted, which is why the stored fact is "muted"
// rather than "enabled" -- an absent key reads as NO, so a TV that never opens
// the menu sounds exactly as it does today.
@property(nonatomic) BOOL soundtrackMuted;   // sound.file + the attract reel
@property(nonatomic) BOOL effectsMuted;      // sound.cue, the synthesised palette
// THE SCREEN ROW IS NOT A MUTE, and it is the one setting the SERVER acts on.
// 0 auto (the server's own clock decides), 1 dark, 2 light. It is sent as a
// request header on every scene poll rather than stored server-side, for the
// same reason the mutes are not sent at all: this is a property of one
// television in one room, and per-display storage does not exist. Auto is 0 so
// an absent key -- a TV that has never opened the menu -- keeps the automatic
// behaviour it shipped with.
@property(nonatomic) NSInteger screenMode;
// Whether the INSTALLED scene invites the settings menu ("allow_settings").
// Checked, never assumed, exactly like handles_back: a live classroom screen
// must not be openable by a stray press.
@property(nonatomic) BOOL sceneAllowsSettings;
// The overlay: nil whenever it is closed. It is the whole open/closed state,
// so there is no second flag to disagree with it.
@property(strong, nonatomic) UIView *settingsView;
@property(strong, nonatomic) NSArray<UIView *> *settingsRowViews;
@property(strong, nonatomic) NSArray<UILabel *> *settingsStateLabels;
@property(nonatomic) NSInteger settingsIndex;
@end

// ---- bootstrap fallback threshold ---------------------------------------
// A scene-mode poll may re-arm the renderer onto a NEW url: that is how the
// Jackbox-style room handoff works -- a pack bakes ONE generic bootstrap url,
// the server answers with a scene whose own fetch.url is room-specific, and
// the renderer follows it. If that room later disappears (expiry, restart,
// deploy) every poll fails, nothing is ever installed, and the screen is stuck
// on its last frame forever. The server cannot fix it, because the TV is no
// longer asking the server anything it can answer. So the renderer counts
// CONSECUTIVE failed scene polls and, at the limit, re-points the poll at the
// baked url, which re-bootstraps the display with nobody touching the TV.
//
// 5 is chosen against the documented 2000ms default cadence: ~10s of a dead
// screen before recovery is attempted. Fewer (1-2) would throw away a healthy
// room over one Wi-Fi hiccup or a single slow response; many more would leave
// a visibly frozen TV long enough for someone to get up and restart the app,
// which is exactly the failure this removes. It is a COUNT, not a duration, so
// a pack that polls more slowly waits proportionally longer before giving up
// on its room -- the right trade, since a slow cadence implies a slow game.
//
// There is deliberately NO back-off: the cadence is already the app's declared
// fetch.ms, requests never stack (fetchInFlight), and a bounded retry against
// one bootstrap url every few seconds is cheaper than the alternative of a
// screen that stays dead until a human intervenes.
static const NSInteger kHeySceneFetchFailureLimit = 5;

@implementation HeySceneViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = [UIColor colorWithRed:0x10 / 255.0 green:0x18 / 255.0 blue:0x20 / 255.0 alpha:1.0];

  self.contentView = [[UIView alloc] init];
  self.contentView.translatesAutoresizingMaskIntoConstraints = NO;
  [self.view addSubview:self.contentView];
  [NSLayoutConstraint activateConstraints:@[
    [self.contentView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [self.contentView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [self.contentView.topAnchor constraintEqualToAnchor:self.view.topAnchor],
    [self.contentView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
  ]];

  // The per-television mutes, BEFORE the first render: renderScene syncs sound,
  // and a TV booting muted must not make the noise once on its way up.
  [self loadSoundSettings];

  const char *initBytes = hey_fn_tv_scene_init();
  self.sceneJson = HeyStringFromReturn(initBytes);
  // Capture the BAKED fetch url before any server document can replace it.
  // This is the address the pack was built with and the only one still
  // guaranteed to exist after a room-specific url goes away.
  self.bootstrapFetchUrl = [self fetchUrlInScene:[self parsedScene]];
  [self renderScene];

  // ---- input: ONE mechanism per input class, no double-fires ------------
  // Directional + Select + Play/Pause arrive as UIPress events and are
  // handled in -pressesBegan: below (simulator arrow keys and hardware
  // edge-clicks both deliver these as presses). The Siri Remote clickpad
  // ALSO reports directional gestures as touch swipes, which never surface
  // as presses -- those are covered by the swipe recognizers here. A given
  // physical input reaches exactly one path, so nothing double-fires. The
  // per-pressType UITapGestureRecognizers are intentionally GONE: they were
  // unreliable for arrow presses on real hardware.
  NSArray<NSNumber *> *swipeDirs = @[
    @(UISwipeGestureRecognizerDirectionUp), @(UISwipeGestureRecognizerDirectionDown),
    @(UISwipeGestureRecognizerDirectionLeft), @(UISwipeGestureRecognizerDirectionRight)
  ];
  for (NSNumber *dir in swipeDirs) {
    UISwipeGestureRecognizer *swipe =
        [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(remoteSwipe:)];
    swipe.direction = (UISwipeGestureRecognizerDirection)dir.unsignedIntegerValue;
    [self.view addGestureRecognizer:swipe];
  }
}

- (BOOL)canBecomeFocused { return YES; }

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
  if (self.seeded) { return; }
  self.seeded = YES;
  long long ms = (long long)([NSDate date].timeIntervalSince1970 * 1000.0);
  NSString *event = [NSString stringWithFormat:@"{\"kind\":\"seed\",\"value\":%lld}", ms];
  [self stepWithEvent:event];
}

- (NSDictionary *)parsedScene {
  NSData *data = [self.sceneJson dataUsingEncoding:NSUTF8StringEncoding];
  if (!data) { return @{}; }
  id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
  return [parsed isKindOfClass:NSDictionary.class] ? parsed : @{};
}

- (void)stepWithEvent:(NSString *)eventJson {
  const char *next = hey_fn_tv_scene_step(self.sceneJson.UTF8String, eventJson.UTF8String);
  NSString *nextScene = HeyStringFromReturn(next);
  if ([nextScene isEqualToString:self.sceneJson]) { return; } // unchanged: skip re-render
  self.sceneJson = nextScene;
  [self renderScene];
}

// ---- live data: tick + fetch (0.4.0) -----------------------------------
//
// A scene opts in by carrying either of:
//   "tick":  {"ms": 1000}
//   "fetch": {"url": "http://host/path", "ms": 2000, "mode": "scene", "id": "room"}
//
// The timer period comes from tick.ms, else fetch.ms, else 2000, floored at
// 250ms. With mode "scene" the fetched document IS the next scene and the
// renderer installs it directly -- that is what lets a display app project
// server-rendered state without asking the Hey app to parse JSON (the tvOS
// LLVM subset builds documents by string concatenation and cannot decode
// them). Any other mode delivers {"kind":"data",...} through the normal
// event funnel instead.
//
// Networking is NSURLSession on purpose: hey_tvos_link_stubs.c replaces the
// whole OpenSSL surface with abort() traps, so an HTTPS request issued from
// Hey's own stdlib would kill the app.
//
// Because a fetched scene carries its own fetch declaration, a scene-mode poll
// can move the renderer onto a different url. -noteFailedScenePoll below is the
// way back: see kHeySceneFetchFailureLimit.
- (void)syncLiveDataWithScene:(NSDictionary *)scene {
  NSDictionary *tick = [scene[@"tick"] isKindOfClass:NSDictionary.class] ? scene[@"tick"] : nil;
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;

  double ms = 0.0;
  if ([tick[@"ms"] isKindOfClass:NSNumber.class]) { ms = [tick[@"ms"] doubleValue]; }
  if (ms <= 0.0 && [fetch[@"ms"] isKindOfClass:NSNumber.class]) { ms = [fetch[@"ms"] doubleValue]; }
  if (ms <= 0.0) { ms = 2000.0; }
  if (ms < 250.0) { ms = 250.0; }

  NSString *url = [fetch[@"url"] isKindOfClass:NSString.class] ? fetch[@"url"] : @"";
  NSString *signature = [NSString stringWithFormat:@"%.0f|%@|%@|%@",
                         ms, tick ? @"t" : @"-", url,
                         [fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @""];
  if ([signature isEqualToString:self.pollSignature]) { return; }  // nothing changed
  self.pollSignature = signature;

  [self.pollTimer invalidate];
  self.pollTimer = nil;
  if (!tick && !fetch) { return; }

  __weak __typeof__(self) weakSelf = self;
  self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:(ms / 1000.0)
                                                   repeats:YES
                                                     block:^(NSTimer *timer) {
    (void)timer;
    [weakSelf onLiveDataTimer];
  }];
}

- (void)onLiveDataTimer {
  NSDictionary *scene = [self parsedScene];
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  if ([fetch[@"url"] isKindOfClass:NSString.class]) { [self startFetch:fetch]; }
  if ([scene[@"tick"] isKindOfClass:NSDictionary.class]) {
    long long ms = (long long)([NSDate date].timeIntervalSince1970 * 1000.0);
    [self stepWithEvent:[NSString stringWithFormat:@"{\"kind\":\"tick\",\"ms\":%lld}", ms]];
  }
}

- (void)startFetch:(NSDictionary *)fetch {
  if (self.fetchInFlight) { return; }              // never stack requests
  NSURL *url = [NSURL URLWithString:fetch[@"url"]];
  if (!url) { return; }
  BOOL sceneMode = [[fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @""
                    isEqualToString:@"scene"];
  NSString *fetchId = [fetch[@"id"] isKindOfClass:NSString.class] ? fetch[@"id"] : @"";
  self.fetchInFlight = YES;

  // THE SCREEN PREFERENCE RIDES THE POLL, as a header rather than a query
  // parameter. The URL is what the renderer re-arms on and what it compares to
  // decide it has moved rooms, so mangling it here would make every preference
  // change look like a new room. A header changes nothing the renderer keys on
  // and nothing a server that ignores it has to cope with -- an older server
  // simply keeps deciding on its own clock, which is exactly `auto`.
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
  [request setValue:HeyScreenModeName(self.screenMode) forHTTPHeaderField:@"X-Hey-TV-Screen"];

  __weak __typeof__(self) weakSelf = self;
  NSURLSessionDataTask *task =
      [NSURLSession.sharedSession dataTaskWithRequest:request
                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    (void)error;
    long long status = [response isKindOfClass:NSHTTPURLResponse.class]
                           ? (long long)((NSHTTPURLResponse *)response).statusCode : 0;
    NSString *body = data.length ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
    dispatch_async(dispatch_get_main_queue(), ^{
      __typeof__(self) strongSelf = weakSelf;
      if (!strongSelf) { return; }
      strongSelf.fetchInFlight = NO;
      if (sceneMode) {
        // Only a successful, non-empty document may replace the scene; a
        // failed poll must leave whatever is on screen untouched.
        if (status == 200 && body.length) {
          strongSelf.consecutiveFetchFailures = 0;   // the streak is broken
          if (![body isEqualToString:strongSelf.sceneJson]) {
            strongSelf.sceneJson = body;
            [strongSelf renderScene];
          }
        } else {
          // Transport error, timeout, non-2xx, or an empty body: everything
          // that did NOT yield an installable document counts against the
          // bootstrap-fallback streak. `error` is folded in here rather than
          // inspected -- a failed transport reports status 0 and no body.
          [strongSelf noteFailedScenePoll];
        }
        return;
      }
      NSDictionary *event = @{ @"kind": @"data", @"id": fetchId,
                               @"status": @(status), @"body": body ?: @"" };
      NSData *json = [NSJSONSerialization dataWithJSONObject:event options:0 error:NULL];
      if (!json) { return; }
      [strongSelf stepWithEvent:[[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding]];
    });
  }];
  [task resume];
}

// The fetch url a scene document declares, or nil when it declares none.
- (NSString *)fetchUrlInScene:(NSDictionary *)scene {
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  NSString *url = [fetch[@"url"] isKindOfClass:NSString.class] ? fetch[@"url"] : nil;
  return url.length ? url : nil;
}

// One failed scene-mode poll. At kHeySceneFetchFailureLimit consecutive
// failures, re-point the poll at the baked bootstrap url so the screen can
// re-bootstrap itself onto a fresh room with no human involved.
//
// Recovery rewrites ONLY fetch.url in the scene currently on screen; the
// widgets are left exactly as they are, so the display keeps showing its last
// good frame until the bootstrap url answers with a real document. Re-render
// is what re-arms the timer, via the usual syncLiveDataWithScene signature.
//
// This applies to scene mode only. In any other mode the Hey app owns the
// scene and already sees the failure as a {"kind":"data","status":...} event,
// so the renderer must not overrule it.
- (void)noteFailedScenePoll {
  NSString *bootstrap = self.bootstrapFetchUrl;
  if (!bootstrap.length) { return; }   // nothing was baked in: nowhere to go

  if (self.consecutiveFetchFailures < kHeySceneFetchFailureLimit) {
    self.consecutiveFetchFailures++;   // clamped: a long outage cannot overflow
  }
  if (self.consecutiveFetchFailures < kHeySceneFetchFailureLimit) { return; }

  NSDictionary *scene = [self parsedScene];
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  NSString *mode = [fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @"";
  if (![mode isEqualToString:@"scene"]) { return; }  // scene swapped out under us
  NSString *current = [self fetchUrlInScene:scene];
  // Already home: keep hammering the bootstrap url on its normal cadence
  // rather than re-installing the same document over and over.
  if (current && [current isEqualToString:bootstrap]) { return; }

  NSMutableDictionary *nextScene = [scene mutableCopy];
  NSMutableDictionary *nextFetch = [fetch mutableCopy];
  nextFetch[@"url"] = bootstrap;
  nextScene[@"fetch"] = nextFetch;
  NSData *json = [NSJSONSerialization dataWithJSONObject:nextScene options:0 error:NULL];
  if (!json) { return; }
  NSString *doc = [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding];
  if (!doc.length) { return; }

  NSLog(@"[hey_ios_tv] %ld consecutive failed scene polls of %@; returning to bootstrap url %@",
        (long)self.consecutiveFetchFailures, current ?: @"(none)", bootstrap);
  self.consecutiveFetchFailures = 0;   // give the bootstrap url a full budget
  self.sceneJson = doc;
  [self renderScene];
}

- (void)viewWillDisappear:(BOOL)animated {
  [super viewWillDisappear:animated];
  [self.pollTimer invalidate];
  self.pollTimer = nil;
  self.pollSignature = nil;   // so returning to the view reschedules
  self.consecutiveFetchFailures = 0;   // and starts its failure budget fresh
}

- (void)dealloc {
  [_pollTimer invalidate];
}

// Maps a UIPress type to the scene "button" name, or nil for types we do
// NOT own unconditionally. Menu is deliberately ABSENT from this table: it
// is owned per-scene (see -ownsMenuPress:), because a renderer that always
// swallows Menu makes the app inescapable at its root -- Menu-at-root must
// keep suspending the app (tvOS convention and an App Store requirement).
static NSString *HeyButtonForPressType(UIPressType type) {
  switch (type) {
    case UIPressTypeSelect: return @"select";
    case UIPressTypeUpArrow: return @"up";
    case UIPressTypeDownArrow: return @"down";
    case UIPressTypeLeftArrow: return @"left";
    case UIPressTypeRightArrow: return @"right";
    case UIPressTypePlayPause: return @"playpause";
    default: return nil;   // anything else: never swallowed
  }
}

// ---- the back button: Menu, per-scene (0.4.6) ---------------------------
//
// The 'back' event existed only in specs before 0.4.6: HeyButtonForPressType
// had no Menu case, so on hardware a Menu press never reached the scene
// funnel and a multi-screen app was inescapable without remapping back onto
// other buttons (field defect, RecallCoach demo, 2026-07-30).
//
// A scene now claims the press by declaring, at the top level of the scene
// document, "handles_back": true. While the installed scene declares it,
// press-down delivers {"kind":"remote","button":"back"} through the normal
// event funnel. When the field is absent or false the press is forwarded to
// super exactly as before, so tvOS still suspends the app -- absent means
// false, and every pre-0.4.6 scene behaves byte-identically.
//
// The flag is cached at install time (syncBackHandlingWithScene, called from
// renderScene like keep_awake) rather than parsed per press, and re-evaluated
// on EVERY install because scene-mode polls replace the document every few
// seconds: a server can hand out "handles_back": true on a question screen
// and drop it on the lobby screen, restoring Menu-suspends at the root.
- (void)syncBackHandlingWithScene:(NSDictionary *)scene {
  BOOL wanted = NO;
  id declared = scene[@"handles_back"];
  if ([declared isKindOfClass:NSNumber.class]) { wanted = [declared boolValue]; }
  if (self.handlesBack == wanted) { return; }
  self.handlesBack = wanted;
  NSLog(@"[hey_ios_tv] handles_back=%@ (Menu %@)",
        wanted ? @"true" : @"false",
        wanted ? @"delivered to the scene as 'back'" : @"bubbles to tvOS");
}

// ---- sound (0.4.9) -------------------------------------------------------
//
// A scene declares, at the top level:
//
//   {"sound": {"cue": "think", "volume": 0.35}}
//
// WHY THE CUES ARE SYNTHESISED AND NOT SHIPPED AS AUDIO FILES. The exported
// pack stays a pure code artifact -- no asset bundle, no loader, no path
// resolution on the device -- and a cue is a few hundred bytes of coefficients
// instead of a megabyte of PCM. It is also far easier to TUNE: changing the
// mood is editing a note table, not re-recording and re-exporting audio.
//
// The palette takes its INSPIRATION from the game-show era -- that warm,
// slightly nostalgic "the room is thinking" feel. It is composed here, in note
// tables, rather than sampled from anything.
//
// THE PALETTE IS DELIBERATELY NOT A CLOCK (maintainer, 2026-08-07: "We do NOT
// want a ticking clock that is obnoxious and pressures students. We want light
// & fun"). `think` is a four-note figure on a MAJOR PENTATONIC scale, whose
// defining property is that no two notes in it can beat against each other --
// there is no semitone and no tritone, so it cannot build tension however long
// it loops. A tick would do the opposite: a metronome is a deadline you can
// hear, and it hurts precisely the students who are already anxious.
typedef struct {
  double at;    // seconds from the start of the buffer
  double hz;
  double dur;   // seconds; the envelope decays across this
  double amp;   // 0..1 before the master volume is applied
} HeyCueNote;

// THE THINKING BED. A two-bar phrase at a relaxed ~100bpm: a soft WALKING BASS
// under a sparse pentatonic melody. The bass is what makes it read as
// game-show nostalgia rather than a ringtone -- that era's thinking music is
// always a gentle walking figure, and without it the melody alone sounds like
// a notification chime.
//
// It is a real phrase, not a one-bar fragment on repeat: it steps up, turns
// around, and RESOLVES to C before the loop, with a rest in the last half
// second so the repeat breathes instead of nagging. Everything is on the C
// major pentatonic (C D E G A) -- no semitone, no tritone -- so however many
// times it comes round it cannot sour or build tension.
//
// THE STRUCTURAL FACTS ARE BORROWED; THE TUNE IS NOT. The quiz-show thinking
// bed everyone remembers is in C MAJOR, 4/4, at ROUGHLY 132bpm. Those are
// facts about a genre -- a key, a meter, a tempo -- and they are what actually
// carry the nostalgia. The MELODY below is our own: a I-vi-IV-V turnaround
// with a pentatonic line over it, which is the most ordinary progression in
// popular music and belongs to nobody.
//
// The earlier draft sat at ~100bpm and that was the single biggest thing
// wrong with it -- too slow to feel like a game show, it read as lounge music.
//
// 132bpm -> beat 0.4545s, bar 1.8182s, four bars 7.2727s.
//
// A2 110.00 / C3 130.81 / E3 164.81 / F3 174.61 / G3 196.00
// C5 523.25 / D5 587.33 / E5 659.25 / G5 783.99 / A5 880.00
static const HeyCueNote kHeyCueThink[] = {
    // Walking bass on the half note, I - vi - IV - V. Low, quiet, long decay:
    // felt more than heard, and it is what stops the melody reading as a
    // notification chime.
    {0.0000, 130.81, 0.85, 0.10}, {0.4545 * 2, 196.00, 0.85, 0.09},
    {1.8182, 110.00, 0.85, 0.10}, {1.8182 + 0.9091, 164.81, 0.85, 0.09},
    {3.6364, 174.61, 0.85, 0.10}, {3.6364 + 0.9091, 130.81, 0.85, 0.09},
    {5.4545, 196.00, 0.85, 0.10}, {5.4545 + 0.9091, 196.00, 0.85, 0.09},
    // Our melody: up through bar 2, turn at bar 3, and leave it UNRESOLVED on
    // D so the loop pulls forward into the next repeat instead of stopping.
    {0.0000, 659.25, 0.80, 0.12}, {0.9091, 783.99, 0.80, 0.11},
    {1.8182, 880.00, 0.80, 0.12}, {2.7273, 783.99, 0.80, 0.11},
    {3.6364, 659.25, 0.80, 0.12}, {4.5455, 587.33, 0.80, 0.11},
    {5.4545, 659.25, 0.80, 0.12}, {6.3636, 587.33, 0.60, 0.10},
};
// A quick major triad: "here comes the answer", not "you were wrong".
static const HeyCueNote kHeyCueReveal[] = {
    {0.00, 523.25, 0.50, 0.15}, {0.08, 659.25, 0.55, 0.14},
    {0.16, 783.99, 0.70, 0.13},
};
// One short blip for a joiner. Quiet on purpose: in a class of thirty this
// fires thirty times in a minute, and anything louder becomes a nuisance.
static const HeyCueNote kHeyCueJoin[] = {{0.00, 783.99, 0.22, 0.10}};
// The finish. Brighter and an octave taller, but still pentatonic.
static const HeyCueNote kHeyCueCelebrate[] = {
    {0.00, 523.25, 0.45, 0.15}, {0.10, 659.25, 0.45, 0.15},
    {0.20, 783.99, 0.50, 0.15}, {0.30, 1046.50, 0.90, 0.16},
};

// Returns nil for an unknown or silent cue -- the caller treats that as "stop",
// so a typo silences rather than crashing, matching how an unknown widget kind
// renders a placeholder instead of trapping.
static AVAudioPCMBuffer *HeyCueBuffer(NSString *cue, AVAudioFormat *format, BOOL *outLoops) {
  const HeyCueNote *notes = NULL;
  size_t count = 0;
  double seconds = 0.0;
  BOOL loops = NO;

  if ([cue isEqualToString:@"think"]) {
    notes = kHeyCueThink; count = sizeof(kHeyCueThink) / sizeof(kHeyCueThink[0]);
    seconds = 7.2727; loops = YES;        // four bars at 132bpm, 4/4
  } else if ([cue isEqualToString:@"reveal"]) {
    notes = kHeyCueReveal; count = sizeof(kHeyCueReveal) / sizeof(kHeyCueReveal[0]);
    seconds = 1.00;
  } else if ([cue isEqualToString:@"join"]) {
    notes = kHeyCueJoin; count = sizeof(kHeyCueJoin) / sizeof(kHeyCueJoin[0]);
    seconds = 0.30;
  } else if ([cue isEqualToString:@"celebrate"]) {
    notes = kHeyCueCelebrate; count = sizeof(kHeyCueCelebrate) / sizeof(kHeyCueCelebrate[0]);
    seconds = 1.50;
  } else {
    return nil;
  }
  if (outLoops) { *outLoops = loops; }

  double sr = format.sampleRate;
  AVAudioFrameCount frames = (AVAudioFrameCount)(seconds * sr);
  AVAudioPCMBuffer *buffer = [[AVAudioPCMBuffer alloc] initWithPCMFormat:format frameCapacity:frames];
  if (!buffer || !buffer.floatChannelData) { return nil; }
  buffer.frameLength = frames;

  float *left = buffer.floatChannelData[0];
  memset(left, 0, (size_t)frames * sizeof(float));
  for (size_t n = 0; n < count; n++) {
    HeyCueNote note = notes[n];
    AVAudioFrameCount start = (AVAudioFrameCount)(note.at * sr);
    AVAudioFrameCount len = (AVAudioFrameCount)(note.dur * sr);
    for (AVAudioFrameCount i = 0; i < len && (start + i) < frames; i++) {
      double t = (double)i / sr;
      // A PIANO-SHAPED TONE. Three things separate a piano from the plain
      // sine-plus-two-harmonics this used to be, and all three matter more to
      // "does it sound nostalgic" than the notes do:
      //
      // 1. MANY PARTIALS, falling off about 1/n. A piano is bright at the
      //    attack because the upper partials are genuinely loud for a moment.
      // 2. HIGHER PARTIALS DIE FIRST. The decay rate grows with the partial
      //    number, so the tone gets progressively darker as it rings -- that
      //    darkening IS the piano character. A fixed envelope across all
      //    partials sounds like an organ.
      // 3. A SHORT ATTACK RAMP. Not for realism, for hygiene: starting a
      //    partial at full amplitude puts a step discontinuity in the buffer,
      //    which is an audible click on every note.
      double attack = t < 0.004 ? (t / 0.004) : 1.0;
      double w = 0.0;
      for (int p = 1; p <= 8; p++) {
        double partial_amp = 1.0 / (double)p;
        double partial_env = exp(-(2.4 + 0.75 * (double)p) * t / note.dur);
        w += partial_amp * partial_env * sin(2.0 * M_PI * note.hz * (double)p * t);
      }
      double env = attack;
      // MASTER GAIN, MEASURED RATHER THAN GUESSED. The note amplitudes set the
      // BALANCE between voices; this sets the absolute level. The first draft
      // used 0.55 and the loudest cue peaked at 0.132 -- which the default
      // volume then scaled to ~0.046, i.e. inaudible across a classroom. That
      // is a bug you cannot hear in code review; it was found by rendering the
      // samples to a file and measuring the peak.
      //
      // 2.19 puts the piano timbre's peak at ~0.75, so the 0.6 default volume
      // lands near 0.45: carries to the back of a room, still under speech,
      // and well clear of clipping. RE-MEASURE THIS IF THE TIMBRE CHANGES --
      // the old sine-plus-two-harmonics needed 3.0 for the same peak, so the
      // constant is a property of the waveform, not a taste setting.
      left[start + i] += (float)(note.amp * env * w * 2.19);
    }
  }
  // Identical in both ears: a cue that moves across the room would draw
  // attention to itself, which is the opposite of a background bed.
  if (format.channelCount > 1 && buffer.floatChannelData[1]) {
    memcpy(buffer.floatChannelData[1], left, (size_t)frames * sizeof(float));
  }
  return buffer;
}

- (BOOL)ensureAudioEngine {
  if (self.audioEngine.isRunning) { return YES; }
  if (!self.audioEngine) {
    NSError *sessionError = nil;
    // AMBIENT, not Playback: it mixes with whatever else is playing and never
    // claims the system audio route. A quiz screen has no business stopping
    // the music someone already had on in the room.
    [AVAudioSession.sharedInstance setCategory:AVAudioSessionCategoryAmbient error:&sessionError];
    [AVAudioSession.sharedInstance setActive:YES error:&sessionError];
    if (sessionError) { NSLog(@"[hey_ios_tv] audio session: %@", sessionError.localizedDescription); }

    AVAudioEngine *engine = [[AVAudioEngine alloc] init];
    AVAudioPlayerNode *player = [[AVAudioPlayerNode alloc] init];
    [engine attachNode:player];
    AVAudioFormat *format = [[AVAudioFormat alloc] initStandardFormatWithSampleRate:44100.0 channels:2];
    [engine connect:player to:engine.mainMixerNode format:format];
    self.audioEngine = engine;
    self.audioPlayer = player;
  }
  NSError *startError = nil;
  if (![self.audioEngine startAndReturnError:&startError]) {
    // Audio is a garnish. If the engine will not start we log it and the app
    // carries on silently -- a quiz that refuses to run because a chime failed
    // would be a far worse bug than no chime.
    NSLog(@"[hey_ios_tv] audio engine did not start: %@", startError.localizedDescription);
    return NO;
  }
  return YES;
}

// Called from renderScene on EVERY install, exactly like handles_back. The
// guard below is what makes that safe: a scene-mode poll replaces the document
// every couple of seconds, and restarting the cue each time would machine-gun
// it. Playback changes ONLY when the resolved cue name differs.
//
// ABSENT MEANS SILENCE, not "unchanged". That is the additive-compatible
// reading -- every pre-0.4.9 scene declares no "sound" and therefore plays
// none, byte-identically to 0.4.8 -- and it is also the only reading that
// cannot get stuck: were absence to mean "carry on", a server that stopped
// emitting the field could never turn the sound off again.
// A BUNDLED AUDIO FILE, decoded once into a buffer. `name` is a bundle
// resource name with extension, e.g. "question-to-answer.m4a" -- never a path,
// because the caller is a server-rendered scene document and must not be able
// to name an arbitrary location on the device.
// THE CONTRACT ABOVE, IN ONE PLACE, because video now names bundled files the
// same way audio does and two copies of a security check drift. `subsystem` is
// only the log prefix, so each caller's lines read as they always did.
- (NSString *)bundlePathForResourceName:(NSString *)name subsystem:(NSString *)subsystem {
  NSString *stem = name.stringByDeletingPathExtension;
  NSString *ext = name.pathExtension;
  if (!stem.length || !ext.length) { return nil; }
  // Reject anything that tries to escape the bundle. A scene comes off the
  // network; treating its strings as trusted paths would be the bug.
  if ([name containsString:@"/"] || [name containsString:@".."]) {
    NSLog(@"[hey_ios_tv] %@: refusing path-like file name %@", subsystem, name);
    return nil;
  }
  NSString *path = [NSBundle.mainBundle pathForResource:stem ofType:ext];
  if (!path) {
    NSLog(@"[hey_ios_tv] %@: %@ is not in the app bundle", subsystem, name);
    return nil;
  }
  return path;
}

- (AVAudioPCMBuffer *)bufferForBundledFile:(NSString *)name {
  NSString *path = [self bundlePathForResourceName:name subsystem:@"sound"];
  if (!path) { return nil; }
  NSError *error = nil;
  AVAudioFile *file = [[AVAudioFile alloc] initForReading:[NSURL fileURLWithPath:path] error:&error];
  if (!file) {
    NSLog(@"[hey_ios_tv] sound: could not open %@: %@", name, error.localizedDescription);
    return nil;
  }
  // Decode into the PLAYER's format, not the file's: the mixer connection is
  // 44.1k stereo float and scheduling a 48k buffer onto it plays at the wrong
  // speed. AVAudioFile converts on read when the buffer format differs.
  AVAudioFormat *format = [self.audioPlayer outputFormatForBus:0];
  AVAudioFrameCount frames =
      (AVAudioFrameCount)(file.length * format.sampleRate / file.fileFormat.sampleRate) + 1024;
  AVAudioPCMBuffer *buffer = [[AVAudioPCMBuffer alloc] initWithPCMFormat:format frameCapacity:frames];
  if (!buffer) { return nil; }
  if (![file readIntoBuffer:buffer error:&error]) {
    NSLog(@"[hey_ios_tv] sound: could not decode %@: %@", name, error.localizedDescription);
    return nil;
  }
  return buffer;
}

- (void)syncSoundWithScene:(NSDictionary *)scene {
  NSDictionary *sound = [scene[@"sound"] isKindOfClass:NSDictionary.class] ? scene[@"sound"] : nil;
  NSString *cue = [sound[@"cue"] isKindOfClass:NSString.class] ? sound[@"cue"] : @"silence";
  NSString *fileName = [sound[@"file"] isKindOfClass:NSString.class] ? sound[@"file"] : nil;

  // ONE IDENTITY FOR "WHAT IS SOUNDING", whether it came from a file or the
  // synthesiser. Everything downstream compares this, so a file cue gets the
  // same across-poll idempotence a synthesised one does.
  NSString *wanted = fileName.length ? [@"file:" stringByAppendingString:fileName] : cue;
  NSString *playing = self.currentCue ?: @"silence";
  if ([wanted isEqualToString:playing]) { return; }   // already sounding; leave it alone

  [self.audioPlayer stop];
  self.currentCue = wanted;
  if (!fileName.length && [cue isEqualToString:@"silence"]) {
    NSLog(@"[hey_ios_tv] sound=silence");
    return;
  }
  // THE PER-TELEVISION MUTE, applied to the shape of the audio rather than to
  // the audio itself: a bundled file is the SOUNDTRACK, a synthesised cue is a
  // SOUND EFFECT, and the two are muted independently. currentCue keeps the
  // value it would have had, so a muted TV is idempotent across polls exactly
  // like an audible one and does not re-decide every couple of seconds.
  if (fileName.length ? self.soundtrackMuted : self.effectsMuted) {
    NSLog(@"[hey_ios_tv] sound=%@ suppressed (%@ muted on this television)",
          wanted, fileName.length ? @"soundtrack" : @"sound effects");
    return;
  }
  if (![self ensureAudioEngine]) { return; }

  AVAudioFormat *format = [self.audioPlayer outputFormatForBus:0];
  BOOL loops = NO;
  AVAudioPCMBuffer *buffer = nil;
  if (fileName.length) {
    buffer = [self bufferForBundledFile:fileName];
    // A file cue declares its own repeat behaviour: unlike the synthesised
    // palette, whether a recording should repeat is a property of the
    // RECORDING, not of the cue name.
    loops = [sound[@"loop"] isKindOfClass:NSNumber.class] ? [sound[@"loop"] boolValue] : NO;
  } else {
    buffer = HeyCueBuffer(cue, format, &loops);
  }
  if (!buffer) {
    NSLog(@"[hey_ios_tv] sound: nothing to play for %@ (treated as silence)", wanted);
    self.currentCue = @"silence";
    return;
  }
  // 0.6 against the measured peaks above gives an effective peak near 0.45 --
  // clearly audible at the back of a room, still sitting under speech.
  double volume = [sound[@"volume"] isKindOfClass:NSNumber.class]
                      ? [sound[@"volume"] doubleValue] : 0.6;
  if (volume < 0.0) { volume = 0.0; }
  if (volume > 1.0) { volume = 1.0; }
  self.audioPlayer.volume = (float)volume;

  [self.audioPlayer scheduleBuffer:buffer
                            atTime:nil
                           options:loops ? AVAudioPlayerNodeBufferLoops : 0
                 completionHandler:nil];
  [self.audioPlayer play];
  NSLog(@"[hey_ios_tv] sound=%@ (%@, volume %.2f)", wanted, loops ? @"looping" : @"once", volume);
}

// ---- the sound settings, as stored facts ---------------------------------
// Stored as "muted", never as "enabled". -boolForKey: answers NO for a key
// that was never written, so the default falls out of the storage instead of
// being remembered somewhere: a television that has never opened the menu is
// audible, which is the compatibility contract.
static NSString *const kHeySoundtrackMutedKey = @"hey_ios_tv.soundtrack_muted";
static NSString *const kHeyEffectsMutedKey = @"hey_ios_tv.effects_muted";
static NSString *const kHeyScreenModeKey = @"hey_ios_tv.screen_mode";

// auto | dark | light -- the wire vocabulary, and the ONLY place it is spelled.
static NSString *HeyScreenModeName(NSInteger mode) {
  if (mode == 1) { return @"dark"; }
  if (mode == 2) { return @"light"; }
  return @"auto";
}

- (void)loadSoundSettings {
  NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
  self.soundtrackMuted = [defaults boolForKey:kHeySoundtrackMutedKey];
  self.effectsMuted = [defaults boolForKey:kHeyEffectsMutedKey];
  // integerForKey answers 0 for an absent key, which IS auto -- so a TV that
  // has never opened the menu keeps the server's clock, unchanged.
  self.screenMode = [defaults integerForKey:kHeyScreenModeKey];
  if (self.screenMode < 0 || self.screenMode > 2) { self.screenMode = 0; }
  if (self.soundtrackMuted || self.effectsMuted || self.screenMode != 0) {
    NSLog(@"[hey_ios_tv] settings: soundtrack %@, effects %@, screen %@",
          self.soundtrackMuted ? @"muted" : @"on", self.effectsMuted ? @"muted" : @"on",
          HeyScreenModeName(self.screenMode));
  }
}

// ONE path for every mute change, so nothing can be muted in storage and still
// sounding. Called after either flag is flipped.
- (void)applySoundSettings {
  NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
  [defaults setBool:self.soundtrackMuted forKey:kHeySoundtrackMutedKey];
  [defaults setBool:self.effectsMuted forKey:kHeyEffectsMutedKey];
  [defaults setInteger:self.screenMode forKey:kHeyScreenModeKey];

  // A film ALREADY PLAYING goes quiet now, not at the next reel: the whole
  // point of the menu is the noise happening in the room while you stand there.
  [self applyVideoVolume];

  // Re-decide the scene's own audio from scratch. currentCue has to be cleared
  // first or the idempotence guard would see "already sounding" and skip the
  // re-evaluation that unmuting exists to cause.
  [self.audioPlayer stop];
  self.currentCue = nil;
  [self syncSoundWithScene:[self parsedScene]];
}

- (void)fireRemoteButton:(NSString *)button {
  NSString *event = [NSString stringWithFormat:@"{\"kind\":\"remote\",\"button\":\"%@\"}", button];
  [self stepWithEvent:event];
}

// The action fires exactly once, on press-down. Any press we do not own --
// including Menu whenever the installed scene does not declare
// "handles_back": true -- is forwarded to super so the system default
// (suspend/exit) still runs.

// ---- the attract reel (0.4.13) -------------------------------------------
//
//   {"video": {"file": "attract-reel.mp4", "loop": false, "volume": 0.2}}
//   {"video": {"url": "https://...", "loop": true, "volume": 0.2}}
//
// A display that has been sitting idle plays this full-bleed with sound. It is
// the one screen in the product nobody is looking at, which is exactly why it
// is worth something: a classroom TV waiting for a lesson can be selling the
// product instead of showing a code.
//
// NOT the tvOS top shelf, which was tried first and abandoned: top-shelf
// preview video is played MUTED with no way to change it, and this film is cut
// around its soundtrack.
//
// The reel SHIPS IN THE APP (maintainer, 2026-08-08): "file" names a bundle
// resource, resolved exactly the way {"sound": {"file": ...}} resolves one --
// a name with extension, never a path, because a scene document comes off the
// network and must not be able to name a location on the device. "url" remains
// for a remote film; when both are present the bundled one wins, since it is
// the one guaranteed to be there.
//
// ABSENT MEANS STOP, so a scene that stops emitting video tears the player down
// and every older scene keeps behaving exactly as it did.
- (void)applyVideo:(NSDictionary *)scene {
  NSDictionary *video = [scene[@"video"] isKindOfClass:NSDictionary.class] ? scene[@"video"] : nil;
  NSString *url = [video[@"url"] isKindOfClass:NSString.class] ? video[@"url"] : nil;
  NSString *fileName = [video[@"file"] isKindOfClass:NSString.class] ? video[@"file"] : nil;

  if (fileName.length == 0 && url.length == 0) {
    [self stopVideoKeepingSuppression:NO];
    return;
  }
  // ONE IDENTITY FOR "WHICH FILM", bundled or remote, exactly as the sound path
  // does it. Everything below compares this and never the url: a bundled reel
  // has no url, so a url comparison would never match itself and every poll
  // would restart the film.
  NSString *wanted = fileName.length ? [@"file:" stringByAppendingString:fileName] : url;

  // Dismissed by the viewer, or already played to the end, and the server has
  // not moved on yet.
  if (self.suppressedVideo.length && [self.suppressedVideo isEqualToString:wanted]) { return; }
  if (self.currentVideo.length && [self.currentVideo isEqualToString:wanted]) { return; }

  [self stopVideoKeepingSuppression:NO];

  // RESOLVE BEFORE ANYTHING IS BUILT, so a film that cannot be played leaves no
  // player and no layer over the scene underneath.
  NSURL *parsed = nil;
  if (fileName.length) {
    NSString *path = [self bundlePathForResourceName:fileName subsystem:@"video"];
    if (path.length) { parsed = [NSURL fileURLWithPath:path]; }
  } else {
    parsed = [NSURL URLWithString:url];
    if (parsed == nil) { NSLog(@"[hey_ios_tv] video: unusable url %@", url); }
  }
  if (parsed == nil) {
    // Nothing about a missing resource or a malformed url gets better on the
    // next poll, and the scene will keep asking every two seconds. Suppress it
    // so the failure is one log line, not thirty a minute.
    self.suppressedVideo = wanted;
    return;
  }

  self.videoPlayer = [AVPlayer playerWithURL:parsed];
  // LOW BY DEFAULT (maintainer, 2026-08-08). This starts by itself in a room
  // nobody asked, so it must not be the loudest thing in there.
  double volume = [video[@"volume"] isKindOfClass:NSNumber.class] ? [video[@"volume"] doubleValue] : 0.2;
  // REMEMBERED, then applied. The mute writes the player's volume and nothing
  // else, so this is what unmuting comes back to.
  self.videoRequestedVolume = MAX(0.0, MIN(1.0, volume));
  [self applyVideoVolume];
  self.videoPlayer.actionAtItemEnd = AVPlayerActionAtItemEndNone;

  self.videoLayer = [AVPlayerLayer playerLayerWithPlayer:self.videoPlayer];
  self.videoLayer.frame = self.view.bounds;
  self.videoLayer.videoGravity = AVLayerVideoGravityResizeAspect;
  [self.view.layer addSublayer:self.videoLayer];
  // A new sublayer goes on TOP of everything, including an open settings
  // overlay. Put the overlay back in front so a film that starts while the
  // menu is up cannot swallow it.
  if (self.settingsView) { [self.view bringSubviewToFront:self.settingsView]; }

  BOOL loop = [video[@"loop"] isKindOfClass:NSNumber.class] ? [video[@"loop"] boolValue] : YES;
  // BOTH cases need the end-of-item notification. A looping reel re-seeks; a
  // one-shot reel must TEAR DOWN -- with actionAtItemEnd None and no observer
  // the player simply stops, and the layer stays up over the last frame,
  // covering the waiting scene until someone restarts the app.
  __weak typeof(self) weakSelf = self;
  NSString *finishedKey = wanted;
  self.videoEndObserver =
      [[NSNotificationCenter defaultCenter]
          addObserverForName:AVPlayerItemDidPlayToEndTimeNotification
                      object:self.videoPlayer.currentItem
                       queue:[NSOperationQueue mainQueue]
                  usingBlock:^(NSNotification *note) {
                    if (loop) {
                      [weakSelf.videoPlayer seekToTime:kCMTimeZero];
                      [weakSelf.videoPlayer play];
                      return;
                    }
                    // Tearing down removes THIS observer, which releases the
                    // block that is running. Hop to the next main-queue turn so
                    // the block has returned before that happens.
                    dispatch_async(dispatch_get_main_queue(), ^{
                      __strong __typeof(weakSelf) strongSelf = weakSelf;
                      if (strongSelf == nil) { return; }
                      // The film is over. It must not come back: the server
                      // keeps emitting the same key for as long as the display
                      // is idle, so without this the next poll replays it.
                      strongSelf.suppressedVideo = finishedKey;
                      [strongSelf stopVideoKeepingSuppression:YES];
                      NSLog(@"[hey_ios_tv] video finished: %@", finishedKey);
                    });
                  }];
  self.currentVideo = wanted;
  [self.videoPlayer play];
  // A film is now playing, so the screensaver must not come up over it however
  // the scene declared keep_awake. Recomputed, never poked: see applyIdleTimer.
  [self applyIdleTimer];
  NSLog(@"[hey_ios_tv] video=%@ loop=%d volume=%.2f", wanted, loop, self.videoPlayer.volume);
}

// THE ONE PLACE the player's volume is written, from the requested volume and
// the soundtrack mute -- the same single-writer shape the idle timer uses, and
// for the same reason: the mute must not be able to overwrite what the scene
// asked for, or unmuting has nothing to restore.
// It is deliberately SILENT: it runs on every film install, and a log line
// there would be a new line in the ordinary unmuted case. The mute itself is
// logged once, where it is chosen.
- (void)applyVideoVolume {
  if (self.videoPlayer == nil) { return; }
  self.videoPlayer.volume = self.soundtrackMuted ? 0.0f : (float)self.videoRequestedVolume;
}

- (void)stopVideoKeepingSuppression:(BOOL)keep {
  if (self.videoPlayer == nil && self.videoLayer == nil) {
    if (!keep) { self.suppressedVideo = nil; }
    return;
  }
  // By TOKEN. removeObserver:self would remove nothing here -- the block form
  // of addObserverForName: registers an object of its own, not self.
  if (self.videoEndObserver) {
    [[NSNotificationCenter defaultCenter] removeObserver:self.videoEndObserver];
    self.videoEndObserver = nil;
  }
  [self.videoPlayer pause];
  [self.videoLayer removeFromSuperlayer];
  self.videoPlayer = nil;
  self.videoLayer = nil;
  self.currentVideo = nil;
  if (!keep) { self.suppressedVideo = nil; }
  // Nothing is playing now -- dismissed, finished, or the scene stopped asking
  // for it -- so the scene's own keep_awake takes effect again. This is the
  // whole reason the override is computed rather than latched: a display parked
  // on an unclaimed code goes back to being allowed to sleep.
  [self applyIdleTimer];
}

// ANY press stops the reel and is SWALLOWED -- it does not also fire a scene
// button. Someone walking up to a playing screen is dismissing it, not choosing
// something, and the alternative is that their first press silently does
// whatever the underlying screen had focused.
- (BOOL)dismissVideoIfPlaying {
  if (self.videoPlayer == nil) { return NO; }
  self.suppressedVideo = self.currentVideo;
  [self stopVideoKeepingSuppression:YES];
  NSLog(@"[hey_ios_tv] video dismissed by remote");
  return YES;
}

// ---- the sound settings menu (0.4.13) ------------------------------------
//
// UP opens it, and ONLY on a scene that asks for it with top-level
// "allow_settings": true -- checked and never assumed, the same shape and the
// same reason as handles_back and allow_demo. Every document that wants the
// binding declares it, including the app's own boot splash; nothing here
// infers the binding from what a document happens to look like. A renderer
// that recognised a screen by its bytes would be reasoning about a document
// this package does not own, and the app would break it by editing a screen it
// had every right to edit.
//
// An app that never emits the marker simply has no settings entry, exactly as
// one that never emits allow_demo has no demo. That is the contract, not a gap.
//
// PRE-QUIZ SCREENS ONLY -- see docs/SCENE_CONTRACT.md. On a live question
// screen every button is inert on purpose, so a classroom display cannot be
// clobbered by a stray press, and a scene that opened a menu over the question
// would be throwing that away.
- (BOOL)settingsEntryAllowed {
  return self.sceneAllowsSettings;
}

// Cached at install like handles_back, because scene-mode polls replace the
// document every couple of seconds and a per-press parse would re-read it.
- (void)syncSettingsEntryWithScene:(NSDictionary *)scene {
  BOOL wanted = NO;
  id declared = scene[@"allow_settings"];
  if ([declared isKindOfClass:NSNumber.class]) { wanted = [declared boolValue]; }
  if (self.sceneAllowsSettings == wanted) { return; }
  self.sceneAllowsSettings = wanted;
  NSLog(@"[hey_ios_tv] allow_settings=%@ (Up %@)",
        wanted ? @"true" : @"false",
        wanted ? @"opens the sound menu" : @"goes to the scene");
}

// The overlay is a SIBLING of contentView, not a child: renderScene empties
// contentView every poll, and the menu has to survive that. It adds nothing to
// the scene and removes nothing from it, so closing it leaves the screen
// exactly as it was.
- (void)openSettings {
  if (self.settingsView) { return; }

  UIView *scrim = [[UIView alloc] init];
  scrim.translatesAutoresizingMaskIntoConstraints = NO;
  // Dark enough to read against a bright quiz screen or a playing film, sheer
  // enough that the room can see the menu is ON TOP of something, not a
  // navigation away from it.
  scrim.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.82];
  [self.view addSubview:scrim];
  [NSLayoutConstraint activateConstraints:@[
    [scrim.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [scrim.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [scrim.topAnchor constraintEqualToAnchor:self.view.topAnchor],
    [scrim.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
  ]];

  UIView *card = [[UIView alloc] init];
  card.translatesAutoresizingMaskIntoConstraints = NO;
  // One shade up from the renderer's own background (0x101820), so the card
  // reads as a panel rather than a second application.
  card.backgroundColor = [UIColor colorWithRed:0x18 / 255.0 green:0x24 / 255.0 blue:0x30 / 255.0 alpha:1.0];
  card.layer.cornerRadius = 28;
  card.layer.borderWidth = 1;
  card.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.12].CGColor;
  [scrim addSubview:card];

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  // "Settings", not "Sound": the screen row is not about noise.
  title.text = @"Settings";
  // The file's own type scale: headline.
  title.font = [UIFont systemFontOfSize:48 weight:UIFontWeightSemibold];
  title.textColor = UIColor.whiteColor;

  NSMutableArray<UIView *> *rows = [NSMutableArray array];
  NSMutableArray<UILabel *> *states = [NSMutableArray array];
  for (NSString *name in @[ @"Soundtrack", @"Sound effects", @"Screen" ]) {
    UIView *row = [[UIView alloc] init];
    row.translatesAutoresizingMaskIntoConstraints = NO;
    row.layer.cornerRadius = 16;
    [row.heightAnchor constraintEqualToConstant:96].active = YES;

    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = name;
    label.font = [UIFont systemFontOfSize:36 weight:UIFontWeightRegular];   // body
    [row addSubview:label];

    UILabel *state = [[UILabel alloc] init];
    state.translatesAutoresizingMaskIntoConstraints = NO;
    state.font = [UIFont systemFontOfSize:36 weight:UIFontWeightSemibold];
    state.textAlignment = NSTextAlignmentRight;
    [row addSubview:state];

    [NSLayoutConstraint activateConstraints:@[
      [label.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:28],
      [label.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
      [state.trailingAnchor constraintEqualToAnchor:row.trailingAnchor constant:-28],
      [state.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
    ]];
    [rows addObject:row];
    [states addObject:state];
  }

  UILabel *footer = [[UILabel alloc] init];
  footer.translatesAutoresizingMaskIntoConstraints = NO;
  // "change", not "toggle": one of the three rows cycles rather than flips.
  footer.text = @"Up / Down to choose     Select to change     Menu to close";
  footer.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular];    // caption
  footer.textColor = [UIColor colorWithWhite:1.0 alpha:0.45];

  UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:
                            [@[ title ] arrayByAddingObjectsFromArray:
                                 [rows arrayByAddingObject:footer]]];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.alignment = UIStackViewAlignmentFill;
  stack.spacing = 24;
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  [card addSubview:stack];
  // A little more air under the title and above the footer than between the
  // two rows, so the rows read as one group.
  [stack setCustomSpacing:36 afterView:title];
  [stack setCustomSpacing:36 afterView:rows.lastObject];

  [NSLayoutConstraint activateConstraints:@[
    [card.centerXAnchor constraintEqualToAnchor:scrim.centerXAnchor],
    [card.centerYAnchor constraintEqualToAnchor:scrim.centerYAnchor],
    [card.widthAnchor constraintEqualToConstant:900],
    [stack.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:56],
    [stack.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-56],
    [stack.topAnchor constraintEqualToAnchor:card.topAnchor constant:48],
    [stack.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-48],
  ]];

  self.settingsView = scrim;
  self.settingsRowViews = rows;
  self.settingsStateLabels = states;
  self.settingsIndex = 0;
  [self refreshSettingsRows];
  NSLog(@"[hey_ios_tv] settings opened");
}

- (void)closeSettings {
  if (self.settingsView == nil) { return; }
  [self.settingsView removeFromSuperview];
  self.settingsView = nil;
  self.settingsRowViews = nil;
  self.settingsStateLabels = nil;
  NSLog(@"[hey_ios_tv] settings closed (soundtrack %@, effects %@, screen %@)",
        self.soundtrackMuted ? @"muted" : @"on", self.effectsMuted ? @"muted" : @"on",
        HeyScreenModeName(self.screenMode));
}

// There is no UIKit focus here -- the whole renderer is driven by raw presses,
// and a focus engine would fight the scene underneath. So the selected row is
// drawn, not focused: a lit panel and full-brightness text, dim otherwise,
// which is what reads from the back of a classroom.
- (void)refreshSettingsRows {
  BOOL muted[2] = { self.soundtrackMuted, self.effectsMuted };
  for (NSUInteger i = 0; i < self.settingsRowViews.count; i++) {
    BOOL selected = ((NSInteger)i == self.settingsIndex);
    UIView *row = self.settingsRowViews[i];
    row.backgroundColor = selected ? [UIColor colorWithWhite:1.0 alpha:0.16] : UIColor.clearColor;
    for (UIView *sub in row.subviews) {
      if ([sub isKindOfClass:UILabel.class]) {
        ((UILabel *)sub).textColor =
            selected ? UIColor.whiteColor : [UIColor colorWithWhite:1.0 alpha:0.6];
      }
    }
    UILabel *state = self.settingsStateLabels[i];
    // The screen row is not a mute, so it reads its own three-state vocabulary
    // rather than On/Off -- "Auto" has to be nameable, or nobody can tell the
    // difference between "the server decided" and "I chose light".
    BOOL isScreen = (i == 2);
    BOOL quiet = isScreen ? (self.screenMode == 0) : muted[i];
    state.text = isScreen ? [HeyScreenModeName(self.screenMode) capitalizedString]
                          : (muted[i] ? @"Off" : @"On");
    // The state stays legible even when its row is not the selected one: it is
    // the fact somebody walked over to check.
    if (!selected) {
      state.textColor = quiet ? [UIColor colorWithWhite:1.0 alpha:0.45]
                              : [UIColor colorWithWhite:1.0 alpha:0.8];
    }
  }
}

- (void)settingsMoveBy:(NSInteger)delta {
  NSInteger count = (NSInteger)self.settingsRowViews.count;
  if (count == 0) { return; }
  NSInteger next = self.settingsIndex + delta;
  if (next < 0) { next = 0; }                 // stops at the ends rather than
  if (next > count - 1) { next = count - 1; } // wrapping: two rows, no surprise
  if (next == self.settingsIndex) { return; }
  self.settingsIndex = next;
  [self refreshSettingsRows];
}

- (void)settingsToggleSelected {
  if (self.settingsIndex == 0) { self.soundtrackMuted = !self.soundtrackMuted; }
  else if (self.settingsIndex == 1) { self.effectsMuted = !self.effectsMuted; }
  else {
    // Three states, so Select CYCLES rather than toggles: auto -> dark ->
    // light -> auto. One button, and every state is reachable without a second
    // one to explain.
    self.screenMode = (self.screenMode + 1) % 3;
    NSLog(@"[hey_ios_tv] settings: screen %@", HeyScreenModeName(self.screenMode));
    // Nothing local to apply -- the SERVER paints the scene. The next poll
    // carries the new value and the screen follows within one poll interval,
    // which is why the row does not pretend to have changed anything yet.
    [self applySoundSettings];
    [self refreshSettingsRows];
    return;
  }
  NSLog(@"[hey_ios_tv] sound settings: %@ %@",
        self.settingsIndex == 0 ? @"soundtrack" : @"sound effects",
        (self.settingsIndex == 0 ? self.soundtrackMuted : self.effectsMuted) ? @"muted" : @"on");
  [self applySoundSettings];
  [self refreshSettingsRows];
}

// EVERY press belongs to the overlay while it is open -- the same discipline
// the reel's dismissing press follows. A press that fell through would reach a
// scene the viewer cannot even see.
- (void)settingsHandlePressType:(UIPressType)type {
  switch (type) {
    case UIPressTypeUpArrow: [self settingsMoveBy:-1]; break;
    case UIPressTypeDownArrow: [self settingsMoveBy:1]; break;
    case UIPressTypeSelect: [self settingsToggleSelected]; break;
    case UIPressTypeMenu:
    case UIPressTypePlayPause: [self closeSettings]; break;
    default: break;   // swallowed, and deliberately does nothing
  }
}

- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  // THE MENU IS CHECKED BEFORE THE REEL, and the order is load-bearing. A film
  // can start while the menu is open (the poll that installs it does not know
  // the menu is up), and if the dismissing press ran first, every press meant
  // for the menu the viewer is looking at would go to dismissing a film behind
  // it instead. With no menu open the reel still takes the first press, so the
  // documented behaviour is unchanged: Up during a film dismisses it, and the
  // Up after that opens the menu.
  //
  // The menu owns the remote while it is up, INCLUDING Menu itself: the press
  // that closes it is recorded as ours (menuPressOwned) so the matching
  // press-ended is swallowed too and tvOS does not also suspend the app.
  if (self.settingsView) {
    for (UIPress *press in presses) {
      if (press.type == UIPressTypeMenu) { self.menuPressOwned = YES; }
      [self settingsHandlePressType:press.type];
    }
    return;
  }
  if ([self dismissVideoIfPlaying]) { return; }
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      self.menuPressOwned = self.handlesBack;   // decide once, at press-down
      if (self.menuPressOwned) {
        [self fireRemoteButton:@"back"];
        [unhandled removeObject:press];
      }
      continue;
    }
    // UP OPENS THE SOUND MENU where the screen allows it, and is not also
    // delivered to the scene -- one press, one meaning.
    if (press.type == UIPressTypeUpArrow && [self settingsEntryAllowed]) {
      [self openSettings];
      [unhandled removeObject:press];
      continue;
    }
    NSString *button = HeyButtonForPressType(press.type);
    if (button) {
      [self fireRemoteButton:button];
      [unhandled removeObject:press];
    }
  }
  if (unhandled.count) { [super pressesBegan:unhandled withEvent:event]; }
}

// We already acted on press-down; on end/cancel just swallow the presses we
// own (so they do not fire twice) and forward the rest up the chain. Menu is
// swallowed here iff WE consumed its press-down (menuPressOwned), never by
// re-reading handlesBack -- the scene may have changed mid-press.
- (void)pressesEnded:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      if (self.menuPressOwned) { [unhandled removeObject:press]; }
      self.menuPressOwned = NO;
      continue;
    }
    if (HeyButtonForPressType(press.type)) { [unhandled removeObject:press]; }
  }
  if (unhandled.count) { [super pressesEnded:unhandled withEvent:event]; }
}

- (void)pressesCancelled:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      if (self.menuPressOwned) { [unhandled removeObject:press]; }
      self.menuPressOwned = NO;
      continue;
    }
    if (HeyButtonForPressType(press.type)) { [unhandled removeObject:press]; }
  }
  if (unhandled.count) { [super pressesCancelled:unhandled withEvent:event]; }
}

// Clickpad touch swipes -> the same directional actions. These fire only for
// touch gestures, which never arrive as presses, so there is no double-fire.
- (void)remoteSwipe:(UISwipeGestureRecognizer *)recognizer {
  // The clickpad reaches the menu on the same terms the buttons do: while it is
  // open every swipe belongs to it, and a swipe up opens it where a press up
  // would. Otherwise a Siri Remote user could scroll the scene underneath a
  // menu they are looking at.
  if (self.settingsView) {
    if (recognizer.direction == UISwipeGestureRecognizerDirectionUp) { [self settingsMoveBy:-1]; }
    else if (recognizer.direction == UISwipeGestureRecognizerDirectionDown) { [self settingsMoveBy:1]; }
    return;
  }
  if (recognizer.direction == UISwipeGestureRecognizerDirectionUp && [self settingsEntryAllowed]) {
    [self openSettings];
    return;
  }
  NSString *button = @"up";
  switch (recognizer.direction) {
    case UISwipeGestureRecognizerDirectionUp: button = @"up"; break;
    case UISwipeGestureRecognizerDirectionDown: button = @"down"; break;
    case UISwipeGestureRecognizerDirectionLeft: button = @"left"; break;
    case UISwipeGestureRecognizerDirectionRight: button = @"right"; break;
    default: return;
  }
  [self fireRemoteButton:button];
}

// ---- rendering (diff-lite: rebuild the widget tree each step) ------------
// The tvOS screensaver is a BUG during a live quiz: the whole room is looking
// at the screen, nobody is touching a remote, and tvOS has no idea the display
// is doing anything. A scene asks to stay awake with "keep_awake": true.
//
// Scene-DECLARED rather than always-on, deliberately. A display parked on an
// unclaimed code could sit for hours, and holding the screen awake forever
// wastes power and risks burn-in for no one's benefit. The server knows which
// it is -- a claimed room keeps the TV awake, an unclaimed one lets it sleep.
//
// Absent means false, so every pack built before this behaves exactly as it
// did. idleTimerDisabled must be touched on the main thread; renderScene is
// already there.
//
// A PLAYING FILM OVERRIDES THE DECLARATION. The scene that carries the attract
// reel is the unclaimed waiting screen, which declares keep_awake:false on
// purpose -- it may sit for hours. But tvOS "Start After" can be set to two
// minutes, and the reel runs longer than that, so with the idle timer live the
// screensaver comes up over a playing film. The RENDERER is the only side that
// knows a film is actually playing (the server goes on emitting the identical
// idle scene either way, so asking it for keep_awake:true would hold the TV
// awake forever and throw away the burn-in reasoning that put false there).
- (void)syncIdleTimerWithScene:(NSDictionary *)scene {
  id declared = scene[@"keep_awake"];
  self.sceneKeepAwake = [declared isKindOfClass:NSNumber.class] ? [declared boolValue] : NO;
  [self applyIdleTimer];
}

// THE ONE PLACE idleTimerDisabled is written, from BOTH of its inputs. Nothing
// pokes it behind this method's back, so the order of syncIdleTimerWithScene:
// and applyVideo: within renderScene cannot matter: whichever runs second
// recomputes from the same two facts and lands on the same answer. Were the
// video path to set the flag directly instead, the very next poll -- two
// seconds later, mid-film -- would recompute from the scene alone and hand the
// screensaver back its opening.
- (void)applyIdleTimer {
  BOOL playing = (self.videoPlayer != nil);
  BOOL wanted = self.sceneKeepAwake || playing;

  UIApplication *app = UIApplication.sharedApplication;
  if (app.idleTimerDisabled == wanted) { return; }
  app.idleTimerDisabled = wanted;
  // Report what was APPLIED and why, not what the scene asked for: during a
  // film those two disagree, and a log that only ever echoed the declaration
  // would be the first thing to mislead anyone debugging a screensaver.
  NSLog(@"[hey_ios_tv] keep_awake=%@ (scene declared %@, video %@; tvOS screensaver %@)",
        wanted ? @"true" : @"false",
        self.sceneKeepAwake ? @"true" : @"false",
        playing ? @"playing" : @"stopped",
        wanted ? @"suppressed" : @"allowed");
}

- (void)renderScene {
  NSDictionary *scene = [self parsedScene];
  // Re-arm the clock/socket whenever the scene's tick/fetch declaration
  // changes. renderScene only runs when the scene actually changed, so an
  // idle app never reschedules.
  [self syncLiveDataWithScene:scene];
  [self syncIdleTimerWithScene:scene];
  [self syncBackHandlingWithScene:scene];
  [self syncSettingsEntryWithScene:scene];
  [self syncSoundWithScene:scene];
  // The attract reel sits ALONGSIDE the sound sync, on the same per-poll,
  // idempotent-by-url contract. It is applied after the scene body is built so
  // its layer lands on top of whatever the screen was showing.
  [self applyVideo:scene];

  // background: top-level background_color, felt gradient, or flat color.
  //
  // "background_color" (0.4.7) is a top-level hex string: one flat fill for
  // the whole scene background, added so a SERVER-rendered scene can dim the
  // screen (maintainer report 2026-07-31: the white quiz screen is too bright
  // at night) with a single field. When present and parseable it wins over
  // the background object's felt/color; when ABSENT -- or not a string, or
  // not a parseable hex value (HeyColorFromHex returns the nil fallback) --
  // the branches below run exactly as they did in 0.4.6, so every existing
  // scene renders pixel-identically. Same additive rule as handles_back and
  // keep_awake: absent means today's behavior; same guard pattern as
  // caption_color: isKindOfClass check + HeyColorFromHex with a fallback.
  [self.feltLayer removeFromSuperlayer];
  self.feltLayer = nil;
  UIColor *flat = [scene[@"background_color"] isKindOfClass:NSString.class]
                      ? HeyColorFromHex(scene[@"background_color"], nil) : nil;
  NSDictionary *bg = [scene[@"background"] isKindOfClass:NSDictionary.class] ? scene[@"background"] : @{};
  if (flat) {
    self.view.backgroundColor = flat;
  } else if ([bg[@"felt"] isKindOfClass:NSString.class]) {
    UIColor *base = HeyColorFromHex(bg[@"felt"], [UIColor colorWithRed:0x1E / 255.0 green:0x4D / 255.0 blue:0x3B / 255.0 alpha:1.0]);
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = self.view.bounds;
    g.colors = @[ (id)HeyScaleColor(base, 1.35).CGColor, (id)HeyScaleColor(base, 0.6).CGColor ];
    g.startPoint = CGPointMake(0.5, 0.0);
    g.endPoint = CGPointMake(0.5, 1.0);
    [self.view.layer insertSublayer:g atIndex:0];
    self.feltLayer = g;
    self.view.backgroundColor = base;
  } else if ([bg[@"color"] isKindOfClass:NSString.class]) {
    self.view.backgroundColor = HeyColorFromHex(bg[@"color"], UIColor.blackColor);
  }

  for (UIView *sub in self.contentView.subviews.copy) { [sub removeFromSuperview]; }

  // three slot columns: top / center / bottom, each a vertical stack
  UIStackView *(^makeColumn)(void) = ^UIStackView *(void) {
    UIStackView *s = [[UIStackView alloc] init];
    s.axis = UILayoutConstraintAxisVertical;
    s.alignment = UIStackViewAlignmentCenter;
    s.spacing = 28;
    s.translatesAutoresizingMaskIntoConstraints = NO;
    return s;
  };
  UIStackView *top = makeColumn(), *center = makeColumn(), *bottom = makeColumn();

  NSArray *widgets = [scene[@"widgets"] isKindOfClass:NSArray.class] ? scene[@"widgets"] : @[];
  for (id item in widgets) {
    if (![item isKindOfClass:NSDictionary.class]) { continue; }
    NSDictionary *w = item;
    UIView *view = [self viewForWidget:w];
    if (!view) { continue; }
    NSString *slot = [w[@"slot"] isKindOfClass:NSString.class] ? w[@"slot"] : @"center";
    if ([slot isEqualToString:@"top"]) { [top addArrangedSubview:view]; }
    else if ([slot isEqualToString:@"bottom"]) { [bottom addArrangedSubview:view]; }
    else { [center addArrangedSubview:view]; }
  }

  // Assemble the three slot columns into ONE top-to-bottom flow that can never
  // overlap: a vertical stack view never lays its arranged subviews on top of
  // one another. Two flexible spacers keep `top` pinned to the top, `bottom`
  // pinned to the bottom, and `center` in the middle when there is slack; when
  // a scene is tall (two dealt hands, or a wide card fan above a status line
  // and a QR) the spacers simply shrink, so text never overprints text.
  UIView *(^makeSpacer)(void) = ^UIView *(void) {
    UIView *v = [[UIView alloc] init];
    v.translatesAutoresizingMaskIntoConstraints = NO;
    [v setContentHuggingPriority:1 forAxis:UILayoutConstraintAxisVertical];  // stretch me first
    [v.widthAnchor constraintEqualToConstant:0].active = YES;
    return v;
  };
  UIView *spacerTop = makeSpacer(), *spacerBottom = makeSpacer();

  UIStackView *flow = [[UIStackView alloc] init];
  flow.axis = UILayoutConstraintAxisVertical;
  flow.alignment = UIStackViewAlignmentCenter;
  flow.distribution = UIStackViewDistributionFill;
  flow.translatesAutoresizingMaskIntoConstraints = NO;
  [flow addArrangedSubview:top];
  [flow addArrangedSubview:spacerTop];
  [flow addArrangedSubview:center];
  [flow addArrangedSubview:spacerBottom];
  [flow addArrangedSubview:bottom];
  [self.contentView addSubview:flow];

  UILayoutGuide *safe = self.contentView.safeAreaLayoutGuide;
  // The bottom pin yields (only) if a scene is too tall to fit, letting the
  // flow overflow downward rather than forcing an unsatisfiable layout.
  NSLayoutConstraint *bottomPin =
      [flow.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor constant:-40];
  bottomPin.priority = UILayoutPriorityRequired - 1;
  // Equal spacers keep the center column visually centered when there is slack.
  NSLayoutConstraint *equalSpacers =
      [spacerTop.heightAnchor constraintEqualToAnchor:spacerBottom.heightAnchor];
  equalSpacers.priority = UILayoutPriorityDefaultHigh;
  [NSLayoutConstraint activateConstraints:@[
    [flow.centerXAnchor constraintEqualToAnchor:self.contentView.centerXAnchor],
    [flow.topAnchor constraintEqualToAnchor:safe.topAnchor constant:40],
    bottomPin,
    [spacerTop.heightAnchor constraintGreaterThanOrEqualToConstant:16],
    [spacerBottom.heightAnchor constraintGreaterThanOrEqualToConstant:16],
    equalSpacers,
  ]];
}

- (UIView *)viewForWidget:(NSDictionary *)w {
  NSString *kind = [w[@"kind"] isKindOfClass:NSString.class] ? w[@"kind"] : @"";
  if ([kind isEqualToString:@"text"]) { return [self textViewForWidget:w]; }
  if ([kind isEqualToString:@"image"]) { return [self imageViewForWidget:w]; }
  if ([kind isEqualToString:@"qr"]) { return [self qrViewForWidget:w]; }
  if ([kind isEqualToString:@"rect"]) { return [self rectViewForWidget:w]; }
  if ([kind isEqualToString:@"card"]) { return [self cardViewForWidget:w height:230]; }
  if ([kind isEqualToString:@"stack"]) { return [self stackViewForWidget:w]; }
  if ([kind isEqualToString:@"hand"]) { return [self handViewForWidget:w]; }
  return [self placeholderForKind:kind];   // unknown kind: visible, never a crash
}

- (UILabel *)textViewForWidget:(NSDictionary *)w {
  UILabel *label = [[UILabel alloc] init];
  label.translatesAutoresizingMaskIntoConstraints = NO;
  label.text = [w[@"text"] isKindOfClass:NSString.class] ? w[@"text"] : @"";
  label.numberOfLines = 0;
  // numberOfLines=0 alone never wraps here: the widget columns are centered
  // with no width constraint, so a long single label's INTRINSIC width wins
  // and the line runs off both screen edges (seen on-device with a long
  // question stem). tvOS UIKit is logically 1920x1080, so cap every label at
  // 1760pt (80pt margins) and tell the intrinsic-size machinery to wrap at
  // the same width.
  label.preferredMaxLayoutWidth = 1760;
  [label.widthAnchor constraintLessThanOrEqualToConstant:1760].active = YES;
  NSString *style = [w[@"style"] isKindOfClass:NSString.class] ? w[@"style"] : @"body";
  if ([style isEqualToString:@"title"]) { label.font = [UIFont systemFontOfSize:76 weight:UIFontWeightBold]; }
  else if ([style isEqualToString:@"headline"]) { label.font = [UIFont systemFontOfSize:48 weight:UIFontWeightSemibold]; }
  else if ([style isEqualToString:@"caption"]) { label.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular]; }
  else { label.font = [UIFont systemFontOfSize:36 weight:UIFontWeightRegular]; }
  label.textColor = HeyColorFromHex(w[@"color"], UIColor.whiteColor);
  // INLINE MARKDOWN, applied AFTER the font and colour are settled, because
  // bold and italic runs are derived from whatever font the style above
  // chose. Set only when a marker is actually present: an unmarked string
  // keeps the plain label.text path it has always used, so every scene and
  // every shipped pack renders byte-identically to before.
  NSString *raw = label.text;
  if (raw.length && ([raw containsString:@"*"] || [raw containsString:@"`"] || [raw containsString:@"\\"])) {
    label.attributedText = HeyAttributedFromMarkdown(raw, label.font, label.textColor);
  }
  NSString *align = [w[@"align"] isKindOfClass:NSString.class] ? w[@"align"] : @"center";
  label.textAlignment = [align isEqualToString:@"left"] ? NSTextAlignmentLeft
      : [align isEqualToString:@"right"] ? NSTextAlignmentRight : NSTextAlignmentCenter;
  return label;
}

- (UIImageView *)imageViewForWidget:(NSDictionary *)w {
  UIImageView *iv = [[UIImageView alloc] init];
  iv.translatesAutoresizingMaskIntoConstraints = NO;
  iv.contentMode = UIViewContentModeScaleAspectFit;
  NSString *symbol = [w[@"symbol"] isKindOfClass:NSString.class] ? w[@"symbol"] : @"";
  UIImage *img = symbol.length ? [UIImage systemImageNamed:symbol] : nil;
  UIColor *tint = HeyColorFromHex(w[@"tint"], nil);
  if (img && tint) { img = [img imageWithTintColor:tint renderingMode:UIImageRenderingModeAlwaysOriginal]; }
  iv.image = img;

  // 0.4.9: a real picture, not just an SF Symbol. "url" is fetched once and
  // cached; "symbol" still works exactly as before and acts as the placeholder
  // while the download is in flight. A widget with no "url" takes no new code
  // path at all, so every 0.4.8 scene renders identically.
  NSString *url = [w[@"url"] isKindOfClass:NSString.class] ? w[@"url"] : @"";
  if (url.length) { [self loadRemoteImage:url into:iv]; }

  // The 140x140 box was hardcoded through 0.4.8. It stays the default so
  // existing scenes are unmoved, but artwork needs to be bigger than an icon.
  CGFloat width = [w[@"width"] isKindOfClass:NSNumber.class] ? (CGFloat)[w[@"width"] doubleValue] : 140;
  CGFloat height = [w[@"height"] isKindOfClass:NSNumber.class] ? (CGFloat)[w[@"height"] doubleValue] : 140;
  if (width <= 0) { width = 140; }
  if (height <= 0) { height = 140; }
  [NSLayoutConstraint activateConstraints:@[
    [iv.widthAnchor constraintEqualToConstant:width],
    [iv.heightAnchor constraintEqualToConstant:height],
  ]];
  return iv;
}

// THE CACHE IS NOT AN OPTIMISATION, IT IS WHAT MAKES REMOTE IMAGES WORK AT
// ALL. A scene-mode poll rebuilds every widget view every couple of seconds,
// so a download that takes longer than one poll would land on a view that has
// already been thrown away -- and the replacement would start the download
// again, forever, showing nothing. Caching by url means the SECOND render
// (two seconds later) has the image synchronously. The image view is held
// weakly so a late arrival for a discarded view is simply dropped.
- (void)loadRemoteImage:(NSString *)urlString into:(UIImageView *)imageView {
  if (!self.imageCache) { self.imageCache = [[NSCache alloc] init]; }
  UIImage *cached = [self.imageCache objectForKey:urlString];
  if (cached) { imageView.image = cached; return; }

  NSURL *url = [NSURL URLWithString:urlString];
  if (!url) { return; }
  __weak UIImageView *weakImageView = imageView;
  __weak __typeof__(self) weakSelf = self;
  NSURLSessionDataTask *task =
      [NSURLSession.sharedSession dataTaskWithURL:url
                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    (void)response; (void)error;
    if (!data.length) { return; }
    UIImage *image = [UIImage imageWithData:data];
    if (!image) { return; }              // not an image; leave the symbol showing
    dispatch_async(dispatch_get_main_queue(), ^{
      __typeof__(self) strongSelf = weakSelf;
      if (strongSelf) { [strongSelf.imageCache setObject:image forKey:urlString]; }
      UIImageView *strongImageView = weakImageView;
      if (strongImageView) { strongImageView.image = image; }
    });
  }];
  [task resume];
}

- (UIImage *)qrImageForString:(NSString *)text size:(CGFloat)side {
  CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
  [filter setValue:[text dataUsingEncoding:NSUTF8StringEncoding] forKey:@"inputMessage"];
  [filter setValue:@"M" forKey:@"inputCorrectionLevel"];
  CIImage *output = filter.outputImage;
  if (!output) { return nil; }
  CGFloat scale = side / output.extent.size.width;
  CIImage *scaled = [output imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
  CIContext *context = [CIContext context];
  CGImageRef cg = [context createCGImage:scaled fromRect:scaled.extent];
  if (!cg) { return nil; }
  UIImage *image = [UIImage imageWithCGImage:cg];
  CGImageRelease(cg);
  return image;
}

- (UIView *)qrViewForWidget:(NSDictionary *)w {
  UIStackView *col = [[UIStackView alloc] init];
  col.axis = UILayoutConstraintAxisVertical;
  col.alignment = UIStackViewAlignmentCenter;
  col.spacing = 14;
  col.translatesAutoresizingMaskIntoConstraints = NO;

  NSString *payload = [w[@"payload"] isKindOfClass:NSString.class] ? w[@"payload"] : @"";
  UIImageView *qr = [[UIImageView alloc] init];
  qr.translatesAutoresizingMaskIntoConstraints = NO;
  qr.accessibilityIdentifier = @"scene-qr";
  qr.layer.magnificationFilter = kCAFilterNearest;
  if (payload.length) { qr.image = [self qrImageForString:payload size:260]; }
  [NSLayoutConstraint activateConstraints:@[
    [qr.widthAnchor constraintEqualToConstant:260],
    [qr.heightAnchor constraintEqualToConstant:260],
  ]];
  [col addArrangedSubview:qr];

  if ([w[@"caption"] isKindOfClass:NSString.class]) {
    UILabel *cap = [[UILabel alloc] init];
    cap.text = w[@"caption"];
    cap.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular];
    // caption_color lets a light-background scene use a readable caption;
    // the near-white default predates light scenes and stays for backward
    // compatibility (dark scenes rely on it).
    cap.textColor = HeyColorFromHex(w[@"caption_color"], [UIColor colorWithWhite:0.9 alpha:1.0]);
    cap.textAlignment = NSTextAlignmentCenter;
    cap.numberOfLines = 0;
    cap.preferredMaxLayoutWidth = 1760;
    [cap.widthAnchor constraintLessThanOrEqualToConstant:1760].active = YES;
    [col addArrangedSubview:cap];
  }
  return col;
}

- (UIView *)rectViewForWidget:(NSDictionary *)w {
  UIView *v = [[UIView alloc] init];
  v.translatesAutoresizingMaskIntoConstraints = NO;
  v.backgroundColor = HeyColorFromHex(w[@"color"], UIColor.grayColor);
  v.layer.cornerRadius = 12;
  CGFloat width = [w[@"width"] respondsToSelector:@selector(doubleValue)] ? [w[@"width"] doubleValue] : 240;
  CGFloat height = [w[@"height"] respondsToSelector:@selector(doubleValue)] ? [w[@"height"] doubleValue] : 140;
  [NSLayoutConstraint activateConstraints:@[
    [v.widthAnchor constraintEqualToConstant:width],
    [v.heightAnchor constraintEqualToConstant:height],
  ]];
  return v;
}

- (HeyCardView *)cardFromDict:(NSDictionary *)c height:(CGFloat)h {
  HeyCardView *card = [[HeyCardView alloc] initWithHeight:h];
  card.rank = [c[@"rank"] isKindOfClass:NSString.class] ? c[@"rank"] : @"";
  card.suit = [c[@"suit"] isKindOfClass:NSString.class] ? c[@"suit"] : @"";
  NSString *face = [c[@"face"] isKindOfClass:NSString.class] ? c[@"face"] : @"up";
  card.faceUp = ![face isEqualToString:@"down"];
  [card setNeedsDisplay];
  return card;
}

- (UIView *)cardViewForWidget:(NSDictionary *)w height:(CGFloat)h {
  return [self cardFromDict:w height:h];
}

// A hand: a row of cards with an optional caption beneath it. Built as an
// explicit-constraint container (not a bare UIStackView) so its height ALWAYS
// includes the caption -- the caption is pinned inside the container and the
// container's bottom is pinned to it. That guarantees the hand contributes its
// full height to the enclosing slot column, so the next widget in the flow is
// laid out below the caption instead of overprinting it.
- (UIView *)handViewForWidget:(NSDictionary *)w {
  CGFloat cardH = 210;
  UIView *container = [[UIView alloc] init];
  container.translatesAutoresizingMaskIntoConstraints = NO;

  UIStackView *row = [[UIStackView alloc] init];
  row.axis = UILayoutConstraintAxisHorizontal;
  row.alignment = UIStackViewAlignmentCenter;
  row.spacing = 22;
  row.translatesAutoresizingMaskIntoConstraints = NO;
  NSArray *cards = [w[@"cards"] isKindOfClass:NSArray.class] ? w[@"cards"] : @[];
  for (id c in cards) {
    if (![c isKindOfClass:NSDictionary.class]) { continue; }
    [row addArrangedSubview:[self cardFromDict:c height:cardH]];
  }
  [container addSubview:row];

  NSMutableArray<NSLayoutConstraint *> *cons = [@[
    [row.topAnchor constraintEqualToAnchor:container.topAnchor],
    [row.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
    [row.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor],
    [row.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor],
    [row.heightAnchor constraintEqualToConstant:cardH],
    [container.widthAnchor constraintGreaterThanOrEqualToAnchor:row.widthAnchor],
  ] mutableCopy];

  UIView *lastView = row;   // the view whose bottom defines the container height
  if ([w[@"label"] isKindOfClass:NSString.class]) {
    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = w[@"label"];
    label.font = [UIFont systemFontOfSize:40 weight:UIFontWeightSemibold];
    label.textColor = UIColor.whiteColor;
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 1;
    [container addSubview:label];
    [cons addObjectsFromArray:@[
      [label.topAnchor constraintEqualToAnchor:row.bottomAnchor constant:16],
      [label.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
      [label.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor],
      [label.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor],
      [container.widthAnchor constraintGreaterThanOrEqualToAnchor:label.widthAnchor],
    ]];
    lastView = label;
  }
  // Pin the container bottom to the caption (or the card row when captionless):
  // this is what makes the caption count toward the container's height.
  [cons addObject:[container.bottomAnchor constraintEqualToAnchor:lastView.bottomAnchor]];
  // Hug content horizontally: minimise width subject to the >= guards above,
  // so the container settles at max(rowWidth, labelWidth).
  NSLayoutConstraint *hug = [container.widthAnchor constraintEqualToConstant:0];
  hug.priority = UILayoutPriorityDefaultLow;
  [cons addObject:hug];
  [NSLayoutConstraint activateConstraints:cons];
  return container;
}

- (UIView *)stackViewForWidget:(NSDictionary *)w {
  CGFloat h = 210;
  CGFloat cardW = [HeyCardView widthForHeight:h];
  NSArray *cards = [w[@"cards"] isKindOfClass:NSArray.class] ? w[@"cards"] : @[];
  NSString *fan = [w[@"fan"] isKindOfClass:NSString.class] ? w[@"fan"] : @"none";
  double overlap = [w[@"overlap"] respondsToSelector:@selector(doubleValue)] ? [w[@"overlap"] doubleValue] : 0.22;

  UIView *container = [[UIView alloc] init];
  container.translatesAutoresizingMaskIntoConstraints = NO;

  if (cards.count == 0) {
    HeyCardSlotView *slot = [[HeyCardSlotView alloc] initWithHeight:h];
    [container addSubview:slot];
    [NSLayoutConstraint activateConstraints:@[
      [container.widthAnchor constraintEqualToConstant:cardW],
      [container.heightAnchor constraintEqualToConstant:h],
      [slot.leadingAnchor constraintEqualToAnchor:container.leadingAnchor],
      [slot.topAnchor constraintEqualToAnchor:container.topAnchor],
    ]];
    return container;
  }

  CGFloat dx = [fan isEqualToString:@"right"] ? cardW * (1.0 - overlap) : 0;
  CGFloat dy = [fan isEqualToString:@"down"] ? h * (1.0 - overlap) : 0;
  NSUInteger i = 0;
  CGFloat maxX = 0, maxY = 0;
  for (id c in cards) {
    if (![c isKindOfClass:NSDictionary.class]) { continue; }
    HeyCardView *card = [self cardFromDict:c height:h];
    card.translatesAutoresizingMaskIntoConstraints = YES;
    card.frame = CGRectMake(dx * i, dy * i, cardW, h);
    [container addSubview:card];
    maxX = MAX(maxX, dx * i + cardW);
    maxY = MAX(maxY, dy * i + h);
    i++;
  }
  [NSLayoutConstraint activateConstraints:@[
    [container.widthAnchor constraintEqualToConstant:maxX],
    [container.heightAnchor constraintEqualToConstant:maxY],
  ]];
  return container;
}

- (UIView *)placeholderForKind:(NSString *)kind {
  UILabel *label = [[UILabel alloc] init];
  label.text = [NSString stringWithFormat:@"[%@?]", kind.length ? kind : @"widget"];
  label.font = [UIFont monospacedSystemFontOfSize:30 weight:UIFontWeightRegular];
  label.textColor = [UIColor colorWithRed:1.0 green:0.6 blue:0.2 alpha:1.0];
  label.textAlignment = NSTextAlignmentCenter;
  label.layer.borderColor = [UIColor colorWithRed:1.0 green:0.6 blue:0.2 alpha:1.0].CGColor;
  label.layer.borderWidth = 2;
  return label;
}

- (void)viewDidLayoutSubviews {
  [super viewDidLayoutSubviews];
  self.feltLayer.frame = self.view.bounds;
}
@end

#define HEY_ROOT_VIEW_CONTROLLER HeySceneViewController

#else
// =========================================================================
// v1 game contract (opaque i64 + manifest); unchanged behavior.
// =========================================================================
extern const char *HEY_ENTRY_SYMBOL(void);
extern long long hey_fn_tvos_action_code(long long action_id);
extern long long hey_fn_tvos_game_init(void);
extern long long hey_fn_tvos_game_step(long long state, long long action_id);
extern const char *hey_fn_tvos_game_text(long long state);

@interface HeyTVViewController : UIViewController
@property(nonatomic) long long gameState;
@property(strong, nonatomic) UILabel *gameLabel;
@end

@implementation HeyTVViewController

- (UIImage *)qrImageForString:(NSString *)text size:(CGFloat)side {
  CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
  [filter setValue:[text dataUsingEncoding:NSUTF8StringEncoding] forKey:@"inputMessage"];
  [filter setValue:@"M" forKey:@"inputCorrectionLevel"];
  CIImage *output = filter.outputImage;
  if (!output) { return nil; }
  CGFloat scale = side / output.extent.size.width;
  CIImage *scaled = [output imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
  CIContext *context = [CIContext context];
  CGImageRef cg = [context createCGImage:scaled fromRect:scaled.extent];
  if (!cg) { return nil; }
  UIImage *image = [UIImage imageWithCGImage:cg];
  CGImageRelease(cg);
  return image;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = UIColor.blackColor;
  const char *manifestBytes = HEY_ENTRY_SYMBOL();
  NSString *manifest = manifestBytes ? [NSString stringWithUTF8String:manifestBytes] : @"{}";
  NSDictionary *fields = @{};
  NSData *manifestData = [manifest dataUsingEncoding:NSUTF8StringEncoding];
  if (manifestData) {
    id parsed = [NSJSONSerialization JSONObjectWithData:manifestData options:0 error:NULL];
    if ([parsed isKindOfClass:NSDictionary.class]) { fields = parsed; }
  }
  NSString *titleText = [fields[@"title"] isKindOfClass:NSString.class] ? fields[@"title"] : @"Hey TV";
  NSString *joinUrl = [fields[@"join_url"] isKindOfClass:NSString.class] ? fields[@"join_url"] : @"";

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  title.text = titleText;
  title.textColor = UIColor.whiteColor;
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1];
  [self.view addSubview:title];

  UIImageView *qrView = [[UIImageView alloc] init];
  qrView.translatesAutoresizingMaskIntoConstraints = NO;
  qrView.accessibilityIdentifier = @"join-qr";
  if (joinUrl.length > 0) { qrView.image = [self qrImageForString:joinUrl size:360]; }
  [self.view addSubview:qrView];

  UILabel *joinLabel = [[UILabel alloc] init];
  joinLabel.translatesAutoresizingMaskIntoConstraints = NO;
  joinLabel.text = joinUrl;
  joinLabel.textColor = UIColor.lightGrayColor;
  joinLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
  [self.view addSubview:joinLabel];

  self.gameState = hey_fn_tvos_game_init();
  UILabel *game = [[UILabel alloc] init];
  game.translatesAutoresizingMaskIntoConstraints = NO;
  game.textColor = UIColor.whiteColor;
  game.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  game.numberOfLines = 3;
  game.textAlignment = NSTextAlignmentCenter;
  game.accessibilityIdentifier = @"game-state";
  self.gameLabel = game;
  [self refreshGameLabel];
  [self.view addSubview:game];

  [NSLayoutConstraint activateConstraints:@[
    [title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:60],
    [qrView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [qrView.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:40],
    [qrView.widthAnchor constraintEqualToConstant:360],
    [qrView.heightAnchor constraintEqualToConstant:360],
    [joinLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [joinLabel.topAnchor constraintEqualToAnchor:qrView.bottomAnchor constant:16],
    [game.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:120],
    [game.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-120],
    [game.topAnchor constraintEqualToAnchor:joinLabel.bottomAnchor constant:60]
  ]];

  NSArray<NSNumber *> *pressTypes = @[
    @(UIPressTypeSelect), @(UIPressTypeUpArrow), @(UIPressTypeDownArrow),
    @(UIPressTypeLeftArrow), @(UIPressTypeRightArrow), @(UIPressTypePlayPause)
  ];
  for (NSNumber *pressType in pressTypes) {
    UITapGestureRecognizer *tap =
        [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(remotePress:)];
    tap.allowedPressTypes = @[ pressType ];
    [self.view addGestureRecognizer:tap];
  }
}

- (void)refreshGameLabel {
  const char *text = hey_fn_tvos_game_text(self.gameState);
  self.gameLabel.text = text ? [NSString stringWithUTF8String:text] : @"";
}

- (void)remotePress:(UITapGestureRecognizer *)recognizer {
  NSNumber *pressType = recognizer.allowedPressTypes.firstObject;
  long long action = 1;
  switch ((UIPressType)pressType.integerValue) {
    case UIPressTypeSelect: action = 1; break;
    case UIPressTypeUpArrow: action = 2; break;
    case UIPressTypeDownArrow: action = 3; break;
    case UIPressTypeLeftArrow: action = 4; break;
    case UIPressTypeRightArrow: action = 5; break;
    case UIPressTypePlayPause: action = 6; break;
    default: action = 1; break;
  }
  self.gameState = hey_fn_tvos_game_step(self.gameState, action);
  self.gameLabel.accessibilityValue =
      [NSString stringWithFormat:@"%lld", hey_fn_tvos_action_code(action)];
  [self refreshGameLabel];
}
@end

#define HEY_ROOT_VIEW_CONTROLLER HeyTVViewController

#endif

// ---- shared app delegate + entry point ----------------------------------
@interface HeyTVAppDelegate : UIResponder <UIApplicationDelegate>
@property(strong, nonatomic) UIWindow *window;
@end

@implementation HeyTVAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
  self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  self.window.rootViewController = [[HEY_ROOT_VIEW_CONTROLLER alloc] init];
  [self.window makeKeyAndVisible];
  return YES;
}
- (void)applicationWillTerminate:(UIApplication *)application {
  hey_runtime_shutdown();
}
@end

int main(int argc, char **argv) {
  @autoreleasepool {
    hey_runtime_init();
    hey_runtime_set_argv(argc, argv);
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(HeyTVAppDelegate.class));
  }
}
