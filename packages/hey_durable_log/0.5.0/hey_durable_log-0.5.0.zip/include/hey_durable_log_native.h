#ifndef HEY_DURABLE_LOG_NATIVE_H
#define HEY_DURABLE_LOG_NATIVE_H

#include "hey_native_abi.h"

HeyNativeHandle hey_durable_log_native_open(HeyNativeUtf8View path,
                                            int32_t queue_capacity,
                                            int32_t max_batch_records,
                                            int32_t batch_window_microseconds,
                                            int64_t segment_size_bytes);
int32_t hey_durable_log_native_close(HeyNativeHandle connection);
/* Classify a failed open. `open` can only answer "a handle or nothing", which
   collapses corruption, a bad path and ENOMEM into one indistinguishable
   failure -- and an operator's response to a CORRUPT journal (stop, restore
   from a verified snapshot) is nothing like the response to a typo. This
   re-runs the open and reports the hdl_status it reached, closing anything it
   managed to open. It is called only on the failure path. */
int32_t hey_durable_log_native_open_status(HeyNativeUtf8View path,
                                           int32_t queue_capacity,
                                           int32_t max_batch_records,
                                           int32_t batch_window_microseconds,
                                           int64_t segment_size_bytes);

/* A caller asked to share a journal this process holds under bounds it was not
   opened under. Deliberately NOT an hdl_status: nothing about the journal on
   disk went wrong, so it must not be reported as a journal condition. It is
   numbered clear of the hdl_status range so the two can travel down the one
   int32 the ABI gives us without ever being confused for each other. */
#define HEY_DURABLE_LOG_RETAINED_CONFLICT 100

/* Open the journal at `path`, or take another reference on the one this process
   already holds there -- one recovery scan and one unbroken writer lock for the
   life of the process, however many callers reach it.

   This exists for a caller that cannot be HANDED a journal. A Distributed Hey
   call handler is a plain function of the request body: Hey has no top-level
   mutable state, no closures, and no synchronous ask an actor could answer, so
   a handler cannot capture what `program` opened. It can name the path, and
   that is enough -- the process state lives here instead.

   Separate from `open` on purpose: sharing is opt-in, because a shared handle
   carries bounds its second caller did not choose. Asking for different bounds
   is refused with HEY_DURABLE_LOG_RETAINED_CONFLICT rather than answered with
   the first caller's broker. `close` drops one reference and closes the journal
   only at zero. */
HeyNativeHandle hey_durable_log_native_open_retained(HeyNativeUtf8View path,
                                                     int32_t queue_capacity,
                                                     int32_t max_batch_records,
                                                     int32_t batch_window_microseconds,
                                                     int64_t segment_size_bytes);
int32_t hey_durable_log_native_open_retained_status(HeyNativeUtf8View path,
                                                    int32_t queue_capacity,
                                                    int32_t max_batch_records,
                                                    int32_t batch_window_microseconds,
                                                    int64_t segment_size_bytes);
/* Real opens -- and so recovery scans -- this process performed on the journal
   behind this handle. Retention has to be measured rather than claimed: every
   correctness assertion passes whether it happened or not. -1 for a plain
   handle. */
int64_t hey_durable_log_native_retained_opens(HeyNativeHandle connection);
HeyNativeHandle hey_durable_log_native_submit(HeyNativeHandle connection,
                                               int64_t stream_id,
                                               HeyNativeBytesView payload,
                                               int64_t term);
int32_t hey_durable_log_native_receipt_status(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_sequence(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_batch_id(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_durable_offset(HeyNativeHandle receipt);
void hey_durable_log_native_receipt_close(HeyNativeHandle receipt);
HeyNativeHandle hey_durable_log_native_submit_within(HeyNativeHandle connection,
                                                    int64_t stream_id,
                                                    HeyNativeBytesView payload,
                                                    int64_t admission_timeout_microseconds,
                                                    int64_t term);
HeyNativeHandle hey_durable_log_native_snapshot_create(HeyNativeHandle connection,
                                                      HeyNativeUtf8View directory);
HeyNativeHandle hey_durable_log_native_snapshot_verify(HeyNativeUtf8View directory);
int32_t hey_durable_log_native_snapshot_restore(HeyNativeUtf8View snapshot_directory,
                                                HeyNativeUtf8View journal_directory);
int32_t hey_durable_log_native_retire(HeyNativeHandle connection, HeyNativeUtf8View directory);
int32_t hey_durable_log_native_snapshot_status(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_records(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_first_sequence(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_last_sequence(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_digest(HeyNativeHandle snapshot);
void hey_durable_log_native_snapshot_close(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_last_sequence(HeyNativeHandle connection);
int64_t hey_durable_log_native_last_record_digest(HeyNativeHandle connection);
int64_t hey_durable_log_native_last_leader_epoch(HeyNativeHandle connection);
int64_t hey_durable_log_native_record_leader_epoch(HeyNativeHandle record);
int32_t hey_durable_log_native_discard_after(HeyNativeHandle connection, int64_t sequence);
HeyNativeHandle hey_durable_log_native_stats_open(HeyNativeHandle connection);
int32_t hey_durable_log_native_stats_status(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_records(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_durable_batches(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_largest_batch(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_max_queue_depth(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_window_waits(HeyNativeHandle stats);
void hey_durable_log_native_stats_close(HeyNativeHandle stats);
HeyNativeHandle hey_durable_log_native_cursor_open(HeyNativeHandle connection);
HeyNativeHandle hey_durable_log_native_cursor_open_at(HeyNativeHandle connection, int64_t position);
int64_t hey_durable_log_native_record_position(HeyNativeHandle record);
int64_t hey_durable_log_native_record_next_position(HeyNativeHandle record);
int64_t hey_durable_log_native_record_digest(HeyNativeHandle record);
HeyNativeHandle hey_durable_log_native_cursor_next(HeyNativeHandle cursor);
int32_t hey_durable_log_native_cursor_close(HeyNativeHandle cursor);
int32_t hey_durable_log_native_record_status(HeyNativeHandle record);
int64_t hey_durable_log_native_record_sequence(HeyNativeHandle record);
int64_t hey_durable_log_native_record_batch_id(HeyNativeHandle record);
int64_t hey_durable_log_native_record_stream_id(HeyNativeHandle record);
HeyNativeBytesView hey_durable_log_native_record_payload(HeyNativeHandle record);
void hey_durable_log_native_record_close(HeyNativeHandle record);

#endif
