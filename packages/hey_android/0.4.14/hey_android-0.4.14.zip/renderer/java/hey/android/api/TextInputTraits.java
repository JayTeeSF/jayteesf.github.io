package hey.android.api;
/** Android InputType constants, independent of Android classes for host verification. */
public final class TextInputTraits {
  private TextInputTraits() {}
  static final int CLASS_MASK = 0xf, CLASS_TEXT = 0x1;
  /** CAP_CHARACTERS, CAP_WORDS, CAP_SENTENCES, AUTO_CORRECT and AUTO_COMPLETE. */
  static final int CHANGES_TEXT = 0x1f000;
  static final int NO_SUGGESTIONS = 0x80000;
  /**
   * A username is typed exactly as the person means it: correction could
   * silently change a name, and only the server folds its case. That holds
   * whatever kind the field declares (code, multiline, prose or one this build
   * does not know): every text-class trait that capitalizes, corrects or
   * completes is removed and suggestions are off. A number class has no such
   * flags (its 0x1000/0x2000 bits mean signed/decimal), so it is unchanged.
   */
  public static int forField(String kind, String id) {
    int traits = forKind(kind);
    if (!"username".equals(id) || (traits & CLASS_MASK) != CLASS_TEXT) return traits;
    return (traits & ~CHANGES_TEXT) | NO_SUGGESTIONS;
  }
  public static int forKind(String kind) {
    switch(kind == null ? "" : kind) {
      case "secure": case "new_secure": return 0x81;
      case "url": return 0x11;
      case "number": return 0x3002;
      case "code": return 0x81001;
      case "multiline": return 0x2c001;
      default: return 0xc001;
    }
  }
}
