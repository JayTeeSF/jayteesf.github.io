#!/usr/bin/env sh
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
# THE HEY CHECKOUT IS CHOSEN EXPLICITLY OR NOT AT ALL -- see hey_root_resolve() below. There is
# deliberately no `HEY_ROOT=${HEY_ROOT:-$HOME/dev/...}` default here any more.
hey_root_arg=''
# hey_ios: HEY_IOS_ROOT, else the hey_ios installed beside this package (a
# locked install is .hey/packages/hey_ios_tv/<v>, so .hey/packages/hey_ios/<v>),
# else ~/dev/hey_ios. The sibling comes first so a locked consumer gets its
# locked hey_ios, not whatever a development checkout happens to hold.
if [ -z "${HEY_IOS_ROOT:-}" ]; then
  for hey_ios_candidate in "$PACKAGE_ROOT"/../../hey_ios/*/; do
    [ -f "${hey_ios_candidate}hey-package.json" ] && HEY_IOS_ROOT="${hey_ios_candidate%/}"
  done
  HEY_IOS_ROOT=${HEY_IOS_ROOT:-$HOME/dev/hey_ios}
fi
out=''
source="$PACKAGE_ROOT/examples/native_tvos_app.hey"
entry='tvos_app_manifest'
bundle_id=''
# THE VERSION AND THE BUILD NUMBER, settable. App Store Connect refuses an
# upload whose CFBundleVersion has been used before, so a hardcoded "1" means
# exactly one submission is ever possible and every later one is rejected after
# the archive has already been built and signed. Defaults are unchanged, so a
# caller that sets neither gets what it always got.
short_version="${HEY_IOS_TV_SHORT_VERSION:-1.0}"
build_number="${HEY_IOS_TV_BUILD:-1}"
bundle_id_explicit=false
display_name='Hey Party TV'
minimum='17.0'
launch=false
plan_only=false
sim_device='booted'
# mode is 'simulator' (arm64/x86_64-apple-tvos*-simulator, ad-hoc codesign) or
# 'device' (arm64-apple-tvos, real provisioning-profile signing + devicectl).
# The two tiers keep entirely separate receipts: a device run never claims a
# simulator token, and vice versa.
mode='simulator'
# development = Apple Development + a device profile (install on YOUR Apple TV)
# distribution = Apple Distribution + an App Store profile (produces an .ipa
# for TestFlight). A paid Apple Developer Program membership is what makes the
# distribution certificate available at all.
signing='development'
device_id=''
icon_dir=''
export_compliance=''
# WHICH APPS THIS APP MAY ASK ABOUT is the app's list, not the renderer's
# (0.4.18). The renderer probes every declared scheme with canOpenURL and sends
# the ones that answer yes as X-Hey-TV-Apps; which services exist is product
# knowledge, so the list arrives from the caller. None by default.
query_schemes="${HEY_IOS_TV_QUERY_SCHEMES:-}"

usage() {
  cat <<'HELP'
usage: hey ios-tv-app --out DIRECTORY [--hey-root CHECKOUT] [--source FILE.hey] [--entry FUNCTION] [--bundle-id ID] [--display-name NAME] [--minimum-tvos VERSION] [--launch] [--sim-udid booted|UDID] [--device [DEVICE-ID]] [--plan-only]

  --hey-root DIR      the Hey checkout whose runtime is compiled INTO the app. Required (or set
                      HEY_ROOT). There is no default: this tool will not guess which compiler you
                      are shipping. The resolved root, its HEAD and its compiler identity are
                      printed before anything is built.
  --launch            simulator mode: install + launch on a booted Apple TV simulator
  --sim-udid U        simulator mode: target simulator (booted | a specific UDID)
  --device [ID]       physical-device mode: build for arm64-apple-tvos, sign with a
                      tvOS provisioning profile, install + launch via devicectl.
                      DEVICE-ID defaults to the sole paired Apple TV.
  --plan-only         simulator mode: structural plan only (no Xcode link)
  --icon DIR          app icon + top shelf, from layered PNGs in DIR. Without
                      it the app carries the DEFAULT icon and cannot be
                      submitted. See README for the required filenames.
  --distribution      device mode: sign with Apple Distribution + an App Store
                      profile and emit HeyPartyTV.ipa for TestFlight instead of
                      installing. Needs a paid Apple Developer Program account.
  --export-compliance exempt|nonexempt
                      declare whether the app uses non-exempt encryption.
                      'exempt' emits ITSAppUsesNonExemptEncryption=false;
                      'nonexempt' emits true. Omit when the app has not declared.
  --query-schemes LIST
                      comma-separated URL schemes the app may ask canOpenURL about
                      (LSApplicationQueriesSchemes, e.g. youtube,music). The renderer
                      reports the ones that answer yes in the X-Hey-TV-Apps header.
                      Also HEY_IOS_TV_QUERY_SCHEMES. Default: none.

  HEY_IOS_TV_SHORT_VERSION / HEY_IOS_TV_BUILD set CFBundleShortVersionString and
  CFBundleVersion (default 1.0 and 1; App Store Connect refuses a reused build number).
  HEY_IOS_ROOT names the hey_ios package; default: the hey_ios installed beside this
  package, else ~/dev/hey_ios.
HELP
}
while [ "$#" -gt 0 ]; do
  case "$1" in
    --out) shift; out=${1:?missing --out value} ;;
    --source) shift; source=${1:?missing --source value} ;;
    --entry) shift; entry=${1:?missing --entry value} ;;
    --bundle-id) shift; bundle_id=${1:?missing --bundle-id value}; bundle_id_explicit=true ;;
    --display-name) shift; display_name=${1:?missing --display-name value} ;;
    --minimum-tvos) shift; minimum=${1:?missing --minimum-tvos value} ;;
    --sim-udid) shift; sim_device=${1:?missing --sim-udid value} ;;
    --device)
      mode=device
      # Optional DEVICE-ID: consume the next token only when it is not a flag.
      if [ "$#" -ge 2 ]; then
        case "$2" in
          -*) ;;
          *) shift; device_id=$1 ;;
        esac
      fi
      ;;
    --distribution) signing=distribution ;;
    --export-compliance)
      shift
      export_compliance=${1:?missing --export-compliance value}
      case "$export_compliance" in exempt|nonexempt) ;; *) echo "--export-compliance must be exempt or nonexempt" >&2; exit 2 ;; esac
      ;;
    --launch) launch=true ;;
    --plan-only) plan_only=true ;;
    --icon) shift; icon_dir=${1:?missing --icon value} ;;
    --query-schemes) shift; query_schemes=${1:?missing --query-schemes value} ;;
    --hey-root) shift; hey_root_arg=${1:?missing --hey-root value} ;;
    --help|-h) usage; exit 0 ;;
    *) echo "unknown tvOS native-app option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done
[ -n "$out" ] || { echo '--out is required' >&2; exit 2; }

# ---- WHICH HEY COMPILER IS THIS? ----------------------------------------------------------------
#
# This tool compiles $HEY_ROOT/runtime/hey_runtime.c straight into the shipped app binary, so the
# checkout it picks IS the product. It used to pick one silently:
#
#     HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
#
# and the device environment layered a second personal default on top
# (hey-tv-device-env.sh: HEY_ROOT=${HEY_ROOT:-$HOME/dev/claude_01}). So a developer testing "current
# Hey" on real hardware could be shipping an unrelated months-old runtime, with nothing in the output
# saying which one. That is evidence corruption, not a convenience: the same class of defect as the
# ambient-HEY_ROOT problem hardened in Hey core's bin/hey-hermetic-run.
#
# THE CONTRACT NOW: the root is named explicitly (--hey-root, or HEY_ROOT), it is VERIFIED to be a
# Hey checkout, and its identity is PRINTED before anything is compiled. If no root is named, this
# FAILS. It never falls back to a $HOME/dev/... path, because a wrong-but-plausible answer here is
# worse than no answer.
hey_root_resolve() {
  _src=''
  _dir=''
  if [ -n "$hey_root_arg" ]; then _dir=$hey_root_arg; _src='--hey-root'
  elif [ -n "${HEY_ROOT:-}" ]; then _dir=$HEY_ROOT; _src='HEY_ROOT'
  else
    echo 'no Hey checkout was named, and this tool will not guess one.' >&2
    echo 'Pass --hey-root <checkout>, or export HEY_ROOT, e.g.:' >&2
    echo '  hey ios-tv-app --hey-root "$PWD" ...      # from inside a Hey checkout' >&2
    exit 2
  fi
  [ -d "$_dir" ] || { echo "the named Hey checkout does not exist ($_src): $_dir" >&2; exit 2; }
  _dir="$(CDPATH= cd -- "$_dir" && pwd)"
  # VERIFY, do not assume. Every one of these is compiled or executed below, so a directory missing
  # any of them is not a usable checkout and must fail here rather than mid-link.
  for _need in runtime/hey_runtime.c runtime/hey_compiler_nodes_bundle.c bin/heyc; do
    [ -e "$_dir/$_need" ] || {
      echo "$_dir is not a Hey checkout ($_src): missing $_need" >&2
      exit 2
    }
  done
  HEY_ROOT=$_dir
  HEY_ROOT_SOURCE=$_src
}
hey_root_resolve

# Content, not just a path: a receipt saying only "root=/some/path" cannot tell two different
# compilers apart at the same path -- which is the confusion this whole guard exists for. Same
# computation as Hey core's bin/hey-hermetic-run, so the two receipts are directly comparable.
hey_compiler_identity() {
  _h=''
  for _f in "$HEY_ROOT/build/hey-selfc" "$HEY_ROOT/build/heyc"; do
    [ -f "$_f" ] && _h="$_h$(shasum -a 256 "$_f" 2>/dev/null | cut -c1-64)"
  done
  [ -n "$_h" ] || { printf 'unbuilt\n'; return; }
  printf '%s\n' "$_h" | shasum -a 256 | cut -c1-16
}
hey_head_describe() {
  if [ -d "$HEY_ROOT/.git" ] && command -v git >/dev/null 2>&1; then
    git -C "$HEY_ROOT" rev-parse --short HEAD 2>/dev/null || printf 'unknown\n'
  else
    printf 'not-a-git-checkout\n'
  fi
}
# Printed BEFORE anything is compiled, so the provenance is on record even if the build then fails.
printf 'hey_root=%s\n' "$HEY_ROOT"
printf 'hey_root_source=%s\n' "$HEY_ROOT_SOURCE"
printf 'hey_head=%s\n' "$(hey_head_describe)"
printf 'compiler_identity=%s\n' "$(hey_compiler_identity)"
printf 'runtime_source_sha256=%s\n' "$(shasum -a 256 "$HEY_ROOT/runtime/hey_runtime.c" | cut -c1-16)"
printf 'hey_ios_tv_version=%s\n' "$(cat "$PACKAGE_ROOT/VERSION" 2>/dev/null || echo unknown)"

# Bundle id default depends on the tier. The device tier defaults to
# com.jayteesf.heytv so it matches the tvOS provisioning profile minted by the
# one-time Xcode bootstrap (see the missing-profile message below); the
# simulator tier keeps the historical id.
if [ -z "$bundle_id" ]; then
  if [ "$mode" = device ]; then bundle_id=${HEY_TVOS_BUNDLE_ID:-com.jayteesf.heytv}; else bundle_id='com.hey-lang.party-tv'; fi
fi

[ -f "$HEY_IOS_ROOT/hey-package.json" ] || {
  echo "hey_ios package is required: $HEY_IOS_ROOT" >&2
  echo "Install and lock hey_ios 0.2.0 before using hey_ios_tv (or set HEY_IOS_ROOT)." >&2
  exit 69
}
grep -F '"name": "hey_ios"' "$HEY_IOS_ROOT/hey-package.json" >/dev/null
# Nothing from hey_ios is compiled into a television app; this proves the
# dependency is present. 0.2.0 added the iPhone host and changed nothing this
# tool reads, so a 0.1.3 checkout still passes.
case "$(tr -d '[:space:]' < "$HEY_IOS_ROOT/VERSION")" in
  0.1.3|0.2.*) ;;
  *) echo "hey_ios 0.2.x (or 0.1.3) is required: $HEY_IOS_ROOT" >&2; exit 69 ;;
esac

query_schemes_plist=''
if [ -n "$query_schemes" ]; then
  case "$query_schemes" in
    *[!a-z0-9.+,-]*) echo "--query-schemes takes lowercase URL schemes separated by commas (got: $query_schemes)" >&2; exit 2 ;;
  esac
  query_schemes_plist='<key>LSApplicationQueriesSchemes</key><array>'
  saved_ifs=$IFS; IFS=,
  for query_scheme in $query_schemes; do
    [ -n "$query_scheme" ] && query_schemes_plist="$query_schemes_plist<string>$query_scheme</string>"
  done
  IFS=$saved_ifs
  query_schemes_plist="$query_schemes_plist</array>"
fi
[ -f "$source" ] || { echo "Hey source not found: $source" >&2; exit 66; }
case "$entry" in *[!A-Za-z0-9_]*|'') echo "invalid Hey entry function: $entry" >&2; exit 2 ;; esac

# ---- target selection (simulator vs device) -----------------------------
# Both tiers compile the same ordinary Hey source through the same LLVM
# pipeline; only the target triple, the SDK, and the object name change.
if [ "$mode" = device ]; then
  target_arch=arm64
  sdk_name=appletvos
  triple="arm64-apple-tvos${minimum}"
  app_obj=app-device.o
else
  host_arch=$(uname -m 2>/dev/null || echo x86_64)
  case "$host_arch" in arm64|aarch64) target_arch=arm64 ;; *) target_arch=x86_64 ;; esac
  sdk_name=appletvsimulator
  triple="${target_arch}-apple-tvos${minimum}-simulator"
  app_obj=app-simulator.o
fi

clang=''
if [ -n "${HEY_TVOS_CLANG:-}" ] && [ -x "$HEY_TVOS_CLANG" ]; then
  clang=$HEY_TVOS_CLANG
elif command -v xcrun >/dev/null 2>&1; then
  clang=$(xcrun --sdk "$sdk_name" --find clang 2>/dev/null || true)
fi
[ -n "$clang" ] || clang=$(command -v clang 2>/dev/null || true)
[ -n "$clang" ] || { echo 'clang is required for tvOS Mach-O object generation' >&2; exit 69; }

rm -rf "$out"
mkdir -p "$out/src" "$out/objects" "$out/HeyPartyTV.app"
cp "$source" "$out/src/app.hey"
"$HEY_ROOT/bin/heyc" build --emit-llvm-ir "$source" -o "$out/src/app.ll" >/dev/null
sed 's/define i32 @main(/define i32 @hey_tvos_source_program_main(/' "$out/src/app.ll" > "$out/src/app-tvos.ll"

if command -v xcrun >/dev/null 2>&1; then sdk=$(xcrun --sdk "$sdk_name" --show-sdk-path 2>/dev/null || true); else sdk=''; fi
if [ -n "$sdk" ]; then
  "$clang" --target="$triple" -isysroot "$sdk" -Wno-override-module -c "$out/src/app-tvos.ll" -o "$out/objects/$app_obj"
else
  env -u SDKROOT "$clang" --target="$triple" -Wno-override-module -c "$out/src/app-tvos.ll" -o "$out/objects/$app_obj"
fi
file "$out/objects/$app_obj" > "$out/objects/app.file.txt"
grep -F 'Mach-O 64-bit' "$out/objects/app.file.txt" >/dev/null

# ---- build-time contract detection --------------------------------------
# nm-check the compiled app object: a scene-contract-v2 app exports
# _hey_fn_tv_scene_init, so the template is built with -DHEY_SCENE_V2 (the
# scene renderer); anything else stays on the v1 game contract path.
scene_v2=false
if nm "$out/objects/$app_obj" 2>/dev/null | grep -qE ' T _hey_fn_tv_scene_init$'; then
  scene_v2=true
fi
scene_cflag=''
if [ "$scene_v2" = true ]; then
  nm "$out/objects/$app_obj" 2>/dev/null | grep -qE ' T _hey_fn_tv_scene_step$' || {
    echo 'scene-v2 Hey source must also export fn tv_scene_step(scene, event)' >&2; exit 65; }
  scene_cflag='-DHEY_SCENE_V2'
  symbol='hey_fn_tv_scene_init'
else
  symbol="hey_fn_${entry}"
  grep -F "define ptr @$symbol()" "$out/src/app.ll" >/dev/null || { echo "Hey source must export fn $entry()" >&2; exit 65; }
  grep -F 'define i64 @hey_fn_tvos_action_code(i64 ' "$out/src/app.ll" >/dev/null || { echo 'Hey source must export fn tvos_action_code(action_id)' >&2; exit 65; }
fi
sed "s/HEY_ENTRY_SYMBOL/$symbol/g" "$PACKAGE_ROOT/tools/hey_native_tv_runtime.m" > "$out/src/main.m"

# ---- real Hey runtime object cache key (compiled at link time) ----------
# The v1 no-runtime string shim is gone; every app links the real Hey
# runtime compiled for the tvOS target. The object is cached keyed by the
# runtime source hash and triple so repeat builds skip the recompile. The
# triple carries the tier, so the device .o and the simulator .o never share
# a cache slot.
runtime_src="$HEY_ROOT/runtime/hey_runtime.c"
[ -f "$runtime_src" ] || { echo "Hey runtime source not found: $runtime_src" >&2; exit 69; }
runtime_sha=$(shasum -a 256 "$runtime_src" 2>/dev/null | awk '{print $1}')
# The runtime-object cache must live OUTSIDE the package: when this script runs
# from a locked install (.hey/packages/hey_ios_tv/<v>/tools/...), writing under
# PACKAGE_ROOT would drop an undeclared file into the immutable install and trip
# `hey`'s installed_content_tampered integrity check on the next command. Default
# to a user cache dir; callers may override with HEY_IOS_TV_CACHE.
cache_dir=${HEY_IOS_TV_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/hey_ios_tv}
runtime_obj="$cache_dir/hey_runtime-${triple}-${runtime_sha}.o"

cat > "$out/HeyPartyTV.app/Info.plist" <<EOF_PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDisplayName</key><string>$display_name</string>
<key>CFBundleExecutable</key><string>HeyPartyTV</string>
<key>CFBundleIdentifier</key><string>$bundle_id</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleName</key><string>$display_name</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>$short_version</string>
<key>CFBundleVersion</key><string>$build_number</string>
<key>MinimumOSVersion</key><string>$minimum</string>
<key>UIDeviceFamily</key><array><integer>3</integer></array>
<key>UILaunchScreen</key><dict/>
<key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/></dict>
$query_schemes_plist
</dict></plist>
EOF_PLIST

case "$export_compliance" in
  exempt) /usr/libexec/PlistBuddy -c 'Add :ITSAppUsesNonExemptEncryption bool false' "$out/HeyPartyTV.app/Info.plist" >/dev/null ;;
  nonexempt) /usr/libexec/PlistBuddy -c 'Add :ITSAppUsesNonExemptEncryption bool true' "$out/HeyPartyTV.app/Info.plist" >/dev/null ;;
esac

# ---- app icon and top shelf (0.4.12) ------------------------------------
#
# WITHOUT THIS THE APP HAS NO ICON AT ALL. tvOS shows a blank tile, and an App
# Store build is rejected outright. Before 0.4.12 this packager wrote an
# Info.plist with no icon keys and shipped no catalog, so there was no way to
# give it one short of hand-editing the bundle.
#
# tvOS WILL NOT TAKE LOOSE PNGs, which is the whole reason this is more than a
# `cp`. The icon has to be a COMPILED asset catalog: a brand-assets group whose
# app icon is an IMAGE STACK of layers (that is what parallax is -- the layers
# are real, and the system slides them against each other on focus). actool
# compiles it to Assets.car and emits the Info.plist keys that point at it,
# which is why the partial plist below is merged rather than hand-written.
#
# THE BACK LAYER MUST BE A FULL RECTANGLE WITH SQUARE CORNERS. tvOS applies its
# own rounded mask; baking corners in gets a double-rounded icon.
#
# The static TOP SHELF images ride along here for free -- they are part of the
# same brand-assets group. A top shelf that plays VIDEO is a different feature
# and needs an extension target, which this packager cannot express yet.
if [ -n "$icon_dir" ]; then
  [ -d "$icon_dir" ] || { echo "--icon: not a directory: $icon_dir" >&2; exit 66; }
  for f in appicon-1x-back.png appicon-1x-middle.png appicon-1x-front.png \
           appicon-2x-back.png appicon-2x-middle.png appicon-2x-front.png \
           appstore-back.png appstore-middle.png appstore-front.png \
           topshelf.png topshelf-wide.png; do
    [ -f "$icon_dir/$f" ] || { echo "--icon: $icon_dir is missing $f" >&2; exit 66; }
  done

  cat_dir="$out/Assets.xcassets"
  rm -rf "$cat_dir"
  brand="$cat_dir/App Icon & Top Shelf Image.brandassets"
  mkdir -p "$brand"
  info='"info":{"author":"hey_ios_tv","version":1}'
  printf '{%s}\n' "$info" > "$cat_dir/Contents.json"

  # one .imagestacklayer, holding a Content.imageset of 1 or 2 scales
  emit_layer() { # dir file1x file2x idiom
    mkdir -p "$1/Content.imageset"
    printf '{%s}\n' "$info" > "$1/Contents.json"
    cp "$icon_dir/$2" "$1/Content.imageset/img.png"
    if [ -n "$3" ]; then
      cp "$icon_dir/$3" "$1/Content.imageset/img@2x.png"
      printf '{"images":[{"filename":"img.png","idiom":"%s","scale":"1x"},{"filename":"img@2x.png","idiom":"%s","scale":"2x"}],%s}\n' \
        "$4" "$4" "$info" > "$1/Content.imageset/Contents.json"
    else
      printf '{"images":[{"filename":"img.png","idiom":"%s","scale":"1x"}],%s}\n' \
        "$4" "$info" > "$1/Content.imageset/Contents.json"
    fi
  }
  # FRONT FIRST: the list is topmost-to-backmost, and getting it backwards
  # silently inverts the parallax -- the room would slide over the people.
  emit_stack() { printf '{"layers":[{"filename":"Front.imagestacklayer"},{"filename":"Middle.imagestacklayer"},{"filename":"Back.imagestacklayer"}],%s}\n' "$info" > "$1/Contents.json"; }

  stack="$brand/App Icon.imagestack"; mkdir -p "$stack"; emit_stack "$stack"
  emit_layer "$stack/Back.imagestacklayer"   appicon-1x-back.png   appicon-2x-back.png   tv
  emit_layer "$stack/Middle.imagestacklayer" appicon-1x-middle.png appicon-2x-middle.png tv
  emit_layer "$stack/Front.imagestacklayer"  appicon-1x-front.png  appicon-2x-front.png  tv

  mstack="$brand/App Icon - App Store.imagestack"; mkdir -p "$mstack"; emit_stack "$mstack"
  emit_layer "$mstack/Back.imagestacklayer"   appstore-back.png   '' tv
  emit_layer "$mstack/Middle.imagestacklayer" appstore-middle.png '' tv
  emit_layer "$mstack/Front.imagestacklayer"  appstore-front.png  '' tv

  emit_imageset() { # dir file
    mkdir -p "$1"; cp "$icon_dir/$2" "$1/img.png"
    printf '{"images":[{"filename":"img.png","idiom":"tv","scale":"1x"}],%s}\n' "$info" > "$1/Contents.json"
  }
  emit_imageset "$brand/Top Shelf Image.imageset"      topshelf.png
  emit_imageset "$brand/Top Shelf Image Wide.imageset" topshelf-wide.png

  printf '{"assets":[{"filename":"App Icon.imagestack","idiom":"tv","role":"primary-app-icon","size":"400x240"},{"filename":"App Icon - App Store.imagestack","idiom":"tv","role":"primary-app-icon","size":"1280x768"},{"filename":"Top Shelf Image.imageset","idiom":"tv","role":"top-shelf-image","size":"1920x720"},{"filename":"Top Shelf Image Wide.imageset","idiom":"tv","role":"top-shelf-image-wide","size":"2320x720"}],%s}\n' \
    "$info" > "$brand/Contents.json"

  case "$mode" in device) ac_platform=appletvos ;; *) ac_platform=appletvsimulator ;; esac
  # --target-device tv IS NOT OPTIONAL, and leaving it out fails SILENTLY:
  # actool filters every asset out as not applying to any requested device,
  # exits 0, writes an EMPTY partial plist and no Assets.car at all. It looks
  # exactly like a successful run that had nothing to do.
  if ! xcrun actool "$cat_dir" \
        --compile "$out/HeyPartyTV.app" \
        --platform "$ac_platform" \
        --minimum-deployment-target "$minimum" \
        --target-device tv \
        --app-icon 'App Icon & Top Shelf Image' \
        --output-partial-info-plist "$out/icon-partial.plist" \
        --errors --warnings --notices > "$out/actool.log" 2>&1; then
    echo "--icon: actool failed; see $out/actool.log" >&2
    tail -20 "$out/actool.log" >&2
    exit 65
  fi
  # actool NAMES THE ICON IN THE PLIST; the catalog alone is not enough. Merged
  # rather than hand-written because the key set is actool's contract, not ours,
  # and it has changed across Xcode versions.
  /usr/libexec/PlistBuddy -c "Merge $out/icon-partial.plist" "$out/HeyPartyTV.app/Info.plist" >/dev/null
  [ -f "$out/HeyPartyTV.app/Assets.car" ] || { echo "--icon: actool wrote no Assets.car" >&2; exit 65; }
  echo "app icon: Assets.car $(wc -c < "$out/HeyPartyTV.app/Assets.car" | tr -d ' ') bytes, layered parallax + top shelf"
fi
source_sha=$(shasum -a 256 "$source" 2>/dev/null | awk '{print $1}')
object_sha=$(shasum -a 256 "$out/objects/$app_obj" 2>/dev/null | awk '{print $1}')

write_receipt() {
  native_link=$1; installed=$2; launched=$3; udid=$4
  contract=v1; [ "$scene_v2" = true ] && contract=scene-v2
  cat > "$out/receipt.json" <<EOF_RECEIPT
{"kind":"hey-tvos-native-app-v1","hey_source":"$source","hey_source_sha256":"$source_sha","hey_entry":"$entry","contract":"$contract","native_hey_codegen":true,"native_object":"objects/app-simulator.o","native_object_sha256":"$object_sha","target_triple":"$triple","runtime_linked":true,"runtime_object_sha256":"$runtime_sha","public_display":true,"focus_engine":true,"remote_primary_action":true,"native_link":"$native_link","simulator_install":"$installed","simulator_launch":"$launched","simulator_udid":"$udid","physical_device_signing":"pending","app_store_submission_ready":false}
EOF_RECEIPT
}

# Device-tier receipt: a distinct kind with its own token vocabulary so it can
# never be mistaken for a simulator receipt.
write_device_receipt() {
  contract=v1; [ "$scene_v2" = true ] && contract=scene-v2
  cat > "$out/receipt.json" <<EOF_DRECEIPT
{"kind":"hey-tvos-native-app-device-v1","tier":"device","hey_source":"$source","hey_source_sha256":"$source_sha","hey_entry":"$entry","contract":"$contract","native_hey_codegen":true,"native_object":"objects/app-device.o","native_object_sha256":"$object_sha","target_triple":"$triple","device_sdk":"$sdk_name","runtime_linked":true,"runtime_object_sha256":"$runtime_sha","bundle_id":"$bundle_id","device_build":"$device_build","device_sign":"$device_sign","device_install":"$device_install","device_launch":"$device_launch","provisioning_profile":"$profile_desc","signing_identity":"$identity_desc","team_identifier":"$team_desc","device_id":"$device_id_desc","profile_provisioned_udids":"$provisioned_count","profile_provisions_target":"$profile_provisions_target","target_provisioning_udid":"$prov_target_desc"}
EOF_DRECEIPT
}

if [ "$plan_only" = true ] && [ "$mode" = simulator ]; then
  write_receipt pending false false ''
  printf 'tvOS native app plan ok output=%s ordinary_hey_source=true direct_llvm=true mach_o=true focus=true remote=true native_link=pending\n' "$out"
  exit 0
fi
[ "$(uname -s)" = Darwin ] || { echo 'native tvOS linking requires macOS/Xcode; use --plan-only elsewhere' >&2; exit 69; }
[ -n "$sdk" ] || { echo "Apple TV SDK missing for $sdk_name (install the tvOS platform: xcodebuild -downloadPlatform tvOS)" >&2; exit 69; }

# App Store Connect validates the Xcode/SDK provenance keys that Xcode normally
# injects during a target build. Because this packager links the native Hey app
# directly, stamp the same values from the active Xcode/SDK instead of leaving
# the bundle looking like it was produced by an unknown/obsolete toolchain.
sdk_version=$(xcrun --sdk "$sdk_name" --show-sdk-version)
sdk_build=$(xcrun --sdk "$sdk_name" --show-sdk-build-version)
xcode_version=$(xcodebuild -version | awk 'NR==1 {print $2}')
xcode_build=$(xcodebuild -version | awk 'NR==2 {print $3}')
xcode_numeric=$(printf '%s\n' "$xcode_version" | awk -F. '{printf "%d%02d", $1, ($2 * 10) + ($3 + 0)}')
os_build=$(sw_vers -buildVersion)
/usr/libexec/PlistBuddy -c "Add :BuildMachineOSBuild string $os_build" "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Add :CFBundleDevelopmentRegion string en' "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Add :CFBundleSupportedPlatforms array' -c 'Add :CFBundleSupportedPlatforms:0 string AppleTVOS' "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Add :DTCompiler string com.apple.compilers.llvm.clang.1_0' "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Add :DTPlatformBuild string $sdk_build" "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Add :DTPlatformName string appletvos' "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Add :DTPlatformVersion string $sdk_version" "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Add :DTSDKBuild string $sdk_build" "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Add :DTSDKName string appletvos$sdk_version" "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Add :DTXcode string $xcode_numeric" "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Add :DTXcodeBuild string $xcode_build" "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Add :LSRequiresIPhoneOS bool true' "$out/HeyPartyTV.app/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Add :UIRequiredDeviceCapabilities array' -c 'Add :UIRequiredDeviceCapabilities:0 string arm64' "$out/HeyPartyTV.app/Info.plist" >/dev/null

clang=$(xcrun --sdk "$sdk_name" --find clang)
# Compile + cache the real Hey runtime object (keyed by source sha + triple).
mkdir -p "$cache_dir"
if [ ! -f "$runtime_obj" ]; then
  "$clang" --target="$triple" -isysroot "$sdk" -DHEY_RUNTIME_NO_PROCESS_SPAWN -O1 -w \
    -c "$runtime_src" -o "$runtime_obj.tmp.$$"
  mv "$runtime_obj.tmp.$$" "$runtime_obj"
fi
cp "$runtime_obj" "$out/objects/hey_runtime.o"
# THE COMPILER-NODE BUNDLE. hey_runtime.c calls three functions that live in a
# GENERATED translation unit rather than in the runtime itself:
#
#   hey_compiler_node_logical_field_id_cstr   (stable-ID registry)
#   hey_generated_node_pair_for_field_id      (kind/field dispatch)
#   hey_compiler_node_from_legacy_builtin
#
# The desktop build compiles runtime/hey_compiler_nodes_bundle.c for exactly
# this reason (see the Makefile's hey_compiler_nodes.o). The tvOS lane never
# did, so the device link failed with those three undefined -- and it failed
# SILENTLY as far as the gates were concerned, because `--plan-only` reports
# native_link=pending and never links at all.
#
# WHY THE REAL UNIT AND NOT A STUB. The obvious fix is to add three more
# entries to hey_tvos_link_stubs.c, but that file's stubs all abort(), and
# these three are NOT abort-safe: hey_json_has_key reaches
# hey_generated_node_pair_for_field_id on an ordinary record lookup, which a
# TV scene does constantly. Aborting would trade a link error for a crash on
# screen. Inventing "not found" return values instead would mean guessing the
# sentinel each caller expects, and a wrong guess corrupts field lookups
# quietly. Linking the real implementation removes the guess entirely.
#
# THE OPENSSL STUBS ARE GONE (0.4.16). They were never the right shape either.
# "Genuinely unreachable, so trapping is honest" was true of the CODE PATH and
# false of the BOUNDARY: the runtime was compiled against /opt/homebrew's
# OpenSSL headers -- a library with no tvOS build at all, found by accidental
# host default-path discovery -- and the resulting references were satisfied by
# 50 hand-written abort() fakes. That shipped a TLS client and a crypto surface
# into an app that opens no socket. The Hey runtime now excludes those
# capabilities for this target (HEY_RUNTIME_NO_TLS_CLIENT / _NO_AEAD /
# _NO_PASSWORD_KDF) and uses real Apple primitives where Apple has them, so
# there is nothing left to stub. The guard below keeps it that way.
nodes_src="$HEY_ROOT/runtime/hey_compiler_nodes_bundle.c"
[ -f "$nodes_src" ] || { echo "Hey compiler-node bundle not found: $nodes_src" >&2; exit 69; }
nodes_sha=$(shasum -a 256 "$nodes_src" 2>/dev/null | awk '{print $1}')
nodes_obj="$cache_dir/hey_compiler_nodes-${triple}-${nodes_sha}.o"
if [ ! -f "$nodes_obj" ]; then
  "$clang" --target="$triple" -isysroot "$sdk" -O1 -w \
    -I"$HEY_ROOT/runtime" -I"$HEY_ROOT/compiler/generated" \
    -c "$nodes_src" -o "$nodes_obj.tmp.$$"
  mv "$nodes_obj.tmp.$$" "$nodes_obj"
fi
cp "$nodes_obj" "$out/objects/hey_compiler_nodes.o"
# BUILD-PROVENANCE GUARD, in place of the deleted stub bank. If a future
# runtime change reintroduces an OpenSSL dependency on this target, the honest
# outcomes are a capability guard or a real target implementation -- never a
# fake symbol. Catch it here, by name, before the link turns it into a puzzle.
# Do NOT "fix" a failure by recreating hey_tvos_link_stubs.c or by adding -I or
# -lssl: there is no OpenSSL for tvOS to point at.
openssl_undef=$(nm -u "$out/objects/hey_runtime.o" 2>/dev/null | sed 's/^ *//' \
  | grep -E '^_(BIO|CRYPTO|ERR|EVP|OPENSSL|OpenSSL|PEM|RAND|SSL|TLS_client_method|TLS_server_method|X509|d2i|i2d|ASN1)' \
  | sort -u | tr '\n' ' ')
if [ -n "$(printf '%s' "$openssl_undef" | tr -d ' ')" ]; then
  echo "the tvOS runtime object requires OpenSSL, which does not exist for this target: $openssl_undef" >&2
  echo "guard the capability out of the target, or link a real target implementation -- do not add abort() stubs" >&2
  exit 65
fi
# Compile the template object (scene-v2 renderer when the app exports it).
"$clang" --target="$triple" -isysroot "$sdk" -fobjc-arc -fmodules $scene_cflag \
  -c "$out/src/main.m" -o "$out/objects/main.o"
# Duplicate-symbol guard: each runtime-provided symbol (formerly shimmed in
# the template) must have exactly one definition across the linked objects.
for guard_sym in _hey_runtime_init _hey_llvm_string_value _hey_llvm_concat_string _hey_llvm_value_to_raw_string_cstr; do
  defs=$(nm "$out/objects/main.o" "$out/objects/$app_obj" "$out/objects/hey_runtime.o" 2>/dev/null \
    | grep -cE " [TDSB] $guard_sym\$" || true)
  [ "$defs" = 1 ] || { echo "runtime symbol $guard_sym has $defs definitions (expected 1: shim not removed?)" >&2; exit 65; }
done
"$clang" --target="$triple" -isysroot "$sdk" -fobjc-arc \
  "$out/objects/main.o" "$out/objects/$app_obj" "$out/objects/hey_runtime.o" \
  "$out/objects/hey_compiler_nodes.o" \
  -framework UIKit -framework Foundation -framework CoreImage -framework AVFoundation \
  -o "$out/HeyPartyTV.app/HeyPartyTV"
chmod +x "$out/HeyPartyTV.app/HeyPartyTV"

# ---- bundled assets (0.4.9) ---------------------------------------------
# Copy each file in $HEY_IOS_TV_ASSETS into the .app so a scene can name it in
# {"sound": {"file": "..."}}. Flat, by design: the renderer resolves names with
# -[NSBundle pathForResource:ofType:] and refuses anything path-like, so a
# subdirectory here would simply never be found.
#
# THIS MUST HAPPEN BEFORE CODESIGN. A signature seals the bundle; adding a
# resource afterwards invalidates it, and the failure appears at INSTALL time
# on the device as a vague signature error rather than here as a missing file.
if [ -n "${HEY_IOS_TV_ASSETS:-}" ]; then
  if [ ! -d "$HEY_IOS_TV_ASSETS" ]; then
    echo "HEY_IOS_TV_ASSETS is not a directory: $HEY_IOS_TV_ASSETS" >&2
    exit 69
  fi
  asset_count=0
  for asset in "$HEY_IOS_TV_ASSETS"/*; do
    [ -f "$asset" ] || continue
    cp "$asset" "$out/HeyPartyTV.app/$(basename "$asset")"
    asset_count=$((asset_count + 1))
    echo "bundled asset: $(basename "$asset") ($(wc -c < "$asset" | tr -d ' ') bytes)"
  done
  # An assets directory that contributed nothing is a typo'd path or an empty
  # export, and silently shipping a TV whose sound never plays is worse than
  # stopping here.
  if [ "$asset_count" -eq 0 ]; then
    echo "HEY_IOS_TV_ASSETS contained no files: $HEY_IOS_TV_ASSETS" >&2
    exit 69
  fi
fi

# =========================================================================
# DEVICE TIER: real signing + devicectl install/launch.
# Structural evidence (build + link for arm64-apple-tvos) is now proven; the
# remaining stages degrade honestly to `blocked` when a prerequisite is
# absent, and each hard prerequisite prints a specific, actionable message.
# =========================================================================
if [ "$mode" = device ]; then
  device_build=passed
  device_sign=blocked-no-profile
  device_install=blocked
  device_launch=blocked
  profile_desc=''
  identity_desc=''
  team_desc=''
  device_id_desc=''
  provisioned_count=''
  profile_provisions_target=''
  # HEY_TVOS_PROVISIONING_UDID (optional): a device UDID (as shown in Xcode's
  # Devices window) that the located profile is expected to provision; when
  # set, the receipt reports whether the profile actually lists it.
  prov_target_desc=${HEY_TVOS_PROVISIONING_UDID:-}

  # -- signing identity --------------------------------------------------
  # The certificate CLASS is what separates the two lanes: Apple Development
  # signs builds for devices you own, Apple Distribution signs builds for
  # TestFlight/the App Store. TestFlight rejects a Development signature
  # outright, which is why this is a flag and not a guess.
  cert_class='Apple Development'
  [ "$signing" = distribution ] && cert_class='Apple Distribution'
  sign_identity=${HEY_APPLE_SIGNING_IDENTITY:-}
  # An explicit identity must still be the RIGHT CLASS. The device-env file
  # people source for the device lane exports an Apple Development identity,
  # so without this check --distribution would quietly sign with it and the
  # rejection would arrive at upload, after a full build -- or worse, on a
  # tester's TV. Overriding is fine; overriding into the wrong lane is not.
  if [ -n "$sign_identity" ]; then
    case "$sign_identity" in
      "$cert_class"*) ;;
      *)
        echo "HEY_APPLE_SIGNING_IDENTITY is '$sign_identity', but this build needs an \"$cert_class\" certificate." >&2
        if [ "$signing" = distribution ]; then
          echo 'TestFlight rejects a Development signature. Unset it, or set a distribution identity.' >&2
        fi
        exit 69
        ;;
    esac
  fi
  if [ -z "$sign_identity" ]; then
    sign_identity=$(security find-identity -v -p codesigning 2>/dev/null \
      | sed -n "s/.*\"\($cert_class: [^\"]*\)\".*/\\1/p" | head -1)
  fi
  [ -n "$sign_identity" ] || {
    echo "device signing needs an \"$cert_class\" identity in your login keychain." >&2
    if [ "$signing" = distribution ]; then
      echo 'Xcode > Settings > Accounts > Manage Certificates > + > Apple Distribution.' >&2
      echo 'That option only appears with a PAID Apple Developer Program membership.' >&2
    else
      echo 'Add your Apple ID in Xcode > Settings > Accounts, then re-run.' >&2
    fi
    exit 69
  }
  identity_desc=$sign_identity

  # -- team id (env override, else derive OU from the signing cert) -------
  team=${HEY_APPLE_TEAM_ID:-}
  if [ -z "$team" ]; then
    cert_cn=${sign_identity% (*}
    team=$(security find-certificate -c "$cert_cn" -p 2>/dev/null \
      | openssl x509 -noout -subject 2>/dev/null \
      | sed -n 's/.*OU=\([A-Za-z0-9]*\).*/\1/p' | head -1)
  fi
  [ -n "$team" ] || {
    echo 'could not determine your Apple team id.' >&2
    echo 'Set HEY_APPLE_TEAM_ID to your 10-character Team ID and re-run.' >&2
    exit 69
  }
  team_desc=$team

  # -- locate a tvOS-capable provisioning profile ------------------------
  # Scan both profile stores; a match must (a) list tvOS in Platform and
  # (b) carry an application-identifier of TEAM.<bundle-id> or TEAM.* .
  profile=''
  scan_plist="$out/objects/_profile.plist"
  for pdir in \
    "$HOME/Library/MobileDevice/Provisioning Profiles" \
    "$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles"; do
    [ -d "$pdir" ] || continue
    for p in "$pdir"/*.mobileprovision "$pdir"/*.provisionprofile; do
      [ -f "$p" ] || continue
      security cms -D -i "$p" > "$scan_plist" 2>/dev/null || continue
      plutil -extract Platform xml1 -o - "$scan_plist" 2>/dev/null | grep -q '>tvOS<' || continue
      appid=$(plutil -extract Entitlements.application-identifier raw -o - "$scan_plist" 2>/dev/null) || continue
      pteam=${appid%%.*}
      pname=${appid#*.}
      [ "$pteam" = "$team" ] || continue
      # An App Store profile has NO ProvisionedDevices key; a development or
      # ad-hoc one lists the devices it covers. Matching on that keeps the two
      # lanes from silently picking each other's profile, which fails much
      # later and much less clearly (at upload, or on the tester's TV).
      if [ "$signing" = distribution ]; then
        plutil -extract ProvisionedDevices xml1 -o - "$scan_plist" >/dev/null 2>&1 && continue
      else
        plutil -extract ProvisionedDevices xml1 -o - "$scan_plist" >/dev/null 2>&1 || continue
      fi
      case "$pname" in
        "$bundle_id"|'*') profile=$p; break ;;
      esac
    done
    [ -n "$profile" ] && break
  done
  rm -f "$scan_plist"

  if [ -z "$profile" ]; then
    # Expected today: no tvOS profile exists yet. This is a *blocked* tier,
    # not a failure — the structural device build passed. Print the one-time
    # bootstrap and emit the honest blocked receipt.
    write_device_receipt
    cat >&2 <<BOOTSTRAP
device signing is blocked: no tvOS provisioning profile for $team.$bundle_id was found.

This is expected the first time. Mint one with a single Xcode bootstrap (once):

  1. Xcode > File > New > Project > tvOS > App.
  2. Product Name: HeySigningSetup   Bundle Identifier: com.jayteesf.heytv
     Team: your personal team        Signing: Automatically manage signing.
  3. Select your paired Apple TV ("Living Room") as the run destination.
  4. Press Run once. Xcode registers the Apple TV's UDID with your account
     and mints a tvOS development provisioning profile for com.jayteesf.heytv.
  5. Re-run:  bin/demo device

That single Run is the only manual Xcode step ever required; afterward the
profile lives in ~/Library/MobileDevice/Provisioning Profiles and every future
bin/demo device signs and deploys on its own.
BOOTSTRAP
    printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
      "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
    exit 0
  fi
  profile_desc=$profile

  # -- report which UDIDs the located profile provisions -----------------
  security cms -D -i "$profile" > "$scan_plist" 2>/dev/null || true
  provisioned_count=$(plutil -extract ProvisionedDevices xml1 -o - "$scan_plist" 2>/dev/null | grep -c '<string>' || true)
  if [ -n "$prov_target_desc" ]; then
    if plutil -extract ProvisionedDevices xml1 -o - "$scan_plist" 2>/dev/null | grep -qi ">$prov_target_desc<"; then
      profile_provisions_target=yes
    else
      profile_provisions_target=no
    fi
  fi
  rm -f "$scan_plist"

  # -- embed profile, generate entitlements, codesign --------------------
  # get-task-allow lets a debugger attach. True is required to run from Xcode
  # on your own device; App Store Connect REJECTS a build that carries it.
  gta=true
  [ "$signing" = distribution ] && gta=false
  cp "$profile" "$out/HeyPartyTV.app/embedded.mobileprovision"
  cat > "$out/entitlements.plist" <<EOF_ENT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>application-identifier</key><string>$team.$bundle_id</string>
<key>get-task-allow</key><${gta}/>
<key>com.apple.developer.team-identifier</key><string>$team</string>
</dict></plist>
EOF_ENT
  stamp='--timestamp=none'
  [ "$signing" = distribution ] && stamp='--timestamp'
  if codesign --force --sign "$sign_identity" --entitlements "$out/entitlements.plist" \
       $stamp "$out/HeyPartyTV.app" 2>"$out/codesign.log" \
     && codesign --verify --strict "$out/HeyPartyTV.app" 2>>"$out/codesign.log"; then
    device_sign=passed
  else
    device_sign=failed
    write_device_receipt
    echo "device codesign failed; see $out/codesign.log" >&2
    printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
      "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
    exit 1
  fi

  # -- distribution stops here: package the .ipa -------------------------
  # No device is involved in this lane, so install/launch are not "blocked"
  # by a missing prerequisite -- they are not part of the job. The receipt
  # says so rather than reporting a failure that did not happen.
  if [ "$signing" = distribution ]; then
    rm -rf "$out/Payload" "$out/HeyPartyTV.ipa"
    mkdir -p "$out/Payload"
    cp -R "$out/HeyPartyTV.app" "$out/Payload/"
    (cd "$out" && zip -qry HeyPartyTV.ipa Payload) || {
      echo 'could not package the .ipa' >&2
      exit 1
    }
    rm -rf "$out/Payload"
    device_install=not-applicable
    device_launch=not-applicable
    write_device_receipt
    printf 'tvOS native app (distribution) output=%s ipa=%s device_build=%s device_sign=%s signing=%s team=%s target_triple=%s bundle_id=%s\n' \
      "$out" "$out/HeyPartyTV.ipa" "$device_build" "$device_sign" "$signing" "$team" "$triple" "$bundle_id"
    echo 'Upload it with: xcrun altool --upload-app -f <ipa> -t tvos --apiKey ... --apiIssuer ...'
    exit 0
  fi

  # -- resolve the target device -----------------------------------------
  # Precedence: --device DEVICE-ID > $HEY_TVOS_DEVICE > the sole paired Apple TV.
  [ -n "$device_id" ] || device_id=${HEY_TVOS_DEVICE:-}
  if [ -z "$device_id" ]; then
    device_id=$(xcrun devicectl list devices 2>/dev/null \
      | awk 'tolower($0) ~ /appletv/ && tolower($0) ~ /paired/ {for(i=1;i<=NF;i++) if($i ~ /^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-/) print $i}')
    n=$(printf '%s\n' "$device_id" | grep -c . || true)
    if [ "$n" -eq 0 ]; then
      device_id=''
      write_device_receipt
      echo 'device install is blocked: no paired Apple TV found in `xcrun devicectl list devices`.' >&2
      echo 'Pair one in Xcode > Window > Devices and Simulators, or pass --device <DEVICE-ID>.' >&2
      printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
        "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
      exit 1
    elif [ "$n" -gt 1 ]; then
      echo 'multiple paired Apple TVs found; pass --device <DEVICE-ID> to choose one:' >&2
      printf '%s\n' "$device_id" >&2
      exit 2
    fi
  fi
  device_id_desc=$device_id

  # -- install + launch via devicectl ------------------------------------
  if xcrun devicectl device install app --device "$device_id" "$out/HeyPartyTV.app" \
       > "$out/devicectl-install.txt" 2>&1; then
    device_install=passed
  else
    device_install=failed
    write_device_receipt
    echo "device install failed; see $out/devicectl-install.txt" >&2
    printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
      "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
    exit 1
  fi
  if xcrun devicectl device process launch --device "$device_id" "$bundle_id" \
       > "$out/devicectl-launch.txt" 2>&1; then
    device_launch=passed
  else
    device_launch=failed
  fi
  write_device_receipt
  printf 'tvOS native app (device) output=%s device_build=%s device_sign=%s device_install=%s device_launch=%s target_triple=%s bundle_id=%s\n' \
    "$out" "$device_build" "$device_sign" "$device_install" "$device_launch" "$triple" "$bundle_id"
  exit 0
fi

# =========================================================================
# SIMULATOR TIER: ad-hoc codesign + optional simctl install/launch.
# =========================================================================
codesign --force --sign - "$out/HeyPartyTV.app"
codesign --verify --strict "$out/HeyPartyTV.app"
installed=false; launched=false; udid=''
if [ "$launch" = true ]; then
  if [ "$sim_device" = booted ]; then
    udid=$(xcrun simctl list devices booted | sed -n 's/.*(\([0-9A-Fa-f-][0-9A-Fa-f-]*\)) (Booted).*/\1/p' | head -1)
    [ -n "$udid" ] || { echo 'no booted Apple TV simulator found' >&2; exit 70; }
  else
    udid=$sim_device
    xcrun simctl boot "$udid" >/dev/null 2>&1 || true
    xcrun simctl bootstatus "$udid" -b
  fi
  xcrun simctl install "$udid" "$out/HeyPartyTV.app"; installed=true
  xcrun simctl launch --terminate-running-process "$udid" "$bundle_id" > "$out/simctl-launch.txt"; launched=true
fi
write_receipt passed "$installed" "$launched" "$udid"
printf 'tvOS native app ok output=%s ordinary_hey_source=true direct_llvm=true mach_o=true focus=true remote=true native_link=passed installed=%s launched=%s\n' "$out" "$installed" "$launched"
