# hey_tsv

Bounded lossless UTF-8 TSV encoding from driver-neutral HYR1 row batches.

Version 0.1.0, implementation in progress. Hey module over a native ABI-v2 kernel; no compiler/runtime source modifications. Build with `bin/build-native`. Supported build targets are Linux x86-64 and Darwin arm64.

Native codec receipt passes exact null/empty/escaping/Unicode and bounded/truncated-input cases. Complete package and LLVM composition gates are still being assembled; do not claim production readiness.
