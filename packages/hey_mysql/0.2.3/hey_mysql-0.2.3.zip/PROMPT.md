# Continue hey_mysql

Read README.md, docs/DESIGN.md, goals.md, in-progress.md, todos.md, done.md, manifests, implementation files, and specs before editing.

This is an independent MySQL/MariaDB package. Keep Connector/C pointers opaque. Keep provider detection and TLS/authentication policy here. Separate deterministic compile/load/refusal evidence from configured live-server evidence. Never claim prepared statements until `MYSQL_STMT` is implemented and tested. Do not move driver behavior into Hey runtime, stdlib, compiler, or language documentation.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

Run a configured server receipt with `./bin/check-live`. Published versions are immutable; change the package version whenever released bytes change.

## Files the next LLM needs

Upload the latest full Hey source ZIP and this package's latest source/release ZIP. For coordinated database-stack work, also upload the database-stack handoff containing the independently released SQLite and record-layer packages.
