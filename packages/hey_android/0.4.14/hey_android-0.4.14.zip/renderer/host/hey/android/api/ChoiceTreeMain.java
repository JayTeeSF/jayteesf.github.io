package hey.android.api;
import java.util.*;
public final class ChoiceTreeMain {
  static void check(boolean ok, String name) { if (!ok) throw new AssertionError(name); System.out.println("PASS: " + name); }
  static Map<String,Object> node(String id, String parent, boolean selectable) { return Json.dict(Json.parseOrNull(("{\"path\":\""+id+"\",\"parent\":\""+parent+"\",\"label\":\""+id.substring(id.lastIndexOf('/')+1)+"\",\"slug\":\"s-"+id+"\",\"selectable\":"+selectable+"}").getBytes())); }
  public static void main(String[] args) {
    Map<String,Object> field = Json.dict(Json.parseOrNull("{\"options\":[{\"title\":\"Only this item\",\"value\":\"\"}],\"choices\":{\"method\":\"GET\",\"path\":\"/choices\",\"list\":\"nodes\",\"value\":\"slug\",\"label\":\"label\",\"tree\":{\"id\":\"path\",\"parent\":\"parent\",\"selectable\":\"selectable\"}}}".getBytes()));
    Map<String,Object> sourceScreen=Json.dict(Json.parseOrNull("{\"fields\":[{\"id\":\"body\",\"kind\":\"multiline\"},{\"id\":\"folder\",\"kind\":\"choice\"},{\"id\":\"hidden\",\"kind\":\"unsupported\"}],\"values\":{\"request_key\":\"key\",\"folder\":\"default\",\"hidden\":\"secret\"}}".getBytes()));
    Map<String,Object> source=Json.dict(Json.parseOrNull("{\"key\":\"synthetic-key\",\"default\":\"default-slug\",\"secret\":\"never-send\"}".getBytes()));
    Map<String,String> prefill=Screens.prefilled(sourceScreen,source);
    check("synthetic-key".equals(prefill.get("request_key")),"source-mapped metadata without visual field survives");
    check(!prefill.containsKey("hidden"),"unknown field still excluded from source");
    Map<String,Object> withBody=new LinkedHashMap<>(field);Map<String,Object> bodyChoices=new LinkedHashMap<>(Json.dict(field.get("choices")));bodyChoices.put("body",Collections.emptyMap());withBody.put("choices",bodyChoices);
    Map<String,Object> read=ChoiceTree.readRoute(withBody);
    check("GET".equals(read.get("method")) && !read.containsKey("body"),"choice reads explicitly omit even an empty body");
    bodyChoices.put("method","get");check("GET".equals(ChoiceTree.readRoute(withBody).get("method")),"choice read method is case-insensitive");
    bodyChoices.remove("body");check(!ChoiceTree.readRoute(withBody).containsKey("body"),"choice reads accept an absent body");
    bodyChoices.put("body",Collections.singletonMap("q","x"));refusesRoute(withBody,"choice reads refuse a non-empty body");
    bodyChoices.put("body","");refusesRoute(withBody,"choice reads refuse a body that is not an object");
    bodyChoices.put("body",Collections.emptyMap());
    bodyChoices.put("method","POST");refusesRoute(withBody,"choice reads refuse POST");
    List<Object> nodes = Arrays.asList(node("work", "", true),node("work/science","work",true),node("private","",false),node("private/public","private",true));
    ChoiceTree tree = ChoiceTree.parse(field, Collections.singletonMap("nodes",nodes));
    check(tree.rows().size()==3, "static choice and collapsed folder roots");
    check(tree.rows().get(0).value.equals("") && tree.rows().get(0).selectable, "static empty value remains selectable");
    ChoiceTree.Row work=tree.rows().get(1); check(work.selectable && work.children, "public parent independently selectable");
    tree.toggle(work.key); check(tree.rows().size()==4 && tree.rows().get(2).label.equals("science"), "expand short child label");
    tree.toggle(work.key); check(tree.rows().size()==3,"collapse folder");
    check(!tree.rows().get(2).selectable,"private structural ancestor cannot select");
    tree.toggle(tree.rows().get(2).key); check(tree.rows().get(3).selectable,"private ancestor expands to public leaf");
    Map<String,Object> flat=new LinkedHashMap<>(field); Map<String,Object> flatChoices=new LinkedHashMap<>(Json.dict(field.get("choices")));flatChoices.remove("tree");flat.put("choices",flatChoices);
    check(ChoiceTree.parse(flat,Collections.singletonMap("nodes",nodes)).rows().size()==5,"dynamic flat choices retain compatibility");
    check(!tree.rows().get(0).key.equals(tree.rows().get(1).key),"static and remote namespaces remain separate");
    List<Object> deep=new ArrayList<>();String parent="";for(int i=0;i<66;i++){String id="depth"+i;deep.add(node(id,parent,true));parent=id;}rejects(field,deep,"bounded tree depth");
    List<Object> duplicate=Arrays.asList(node("x","",true),node("x","",true));
    rejects(field,duplicate,"duplicate IDs"); rejects(field,Arrays.asList(node("x","y",true),node("y","x",true)),"cycles");
    rejects(field,Arrays.asList(node("x","missing",true)),"orphans");
    List<Object> most=new ArrayList<>(); for(int i=0;i<4096;i++) most.add(node("x"+i,"",true));
    Map<String,Object> fullStatic=new LinkedHashMap<>(field);List<Object> statics=new ArrayList<>();for(int i=0;i<1000;i++)statics.add(Json.dict(Json.parseOrNull(("{\"title\":\"entry "+i+"\",\"value\":\"v"+i+"\"}").getBytes())));fullStatic.put("options",statics);
    check(ChoiceTree.parse(fullStatic,Collections.singletonMap("nodes",most)).rows().size()==5096,"4096 remote rows beside 1000 static options, each under its own limit (as iOS allows 4096 remote)");
    List<Object> excessive=new ArrayList<>(most); excessive.add(node("x4096","",true)); rejects(field,excessive,"bounded remote node count (4097 refused)");
    Map<String,Object> tooManyStatic=new LinkedHashMap<>(fullStatic);List<Object> oneMore=new ArrayList<>(statics);oneMore.add(Json.dict(Json.parseOrNull("{\"title\":\"entry\",\"value\":\"v\"}".getBytes())));tooManyStatic.put("options",oneMore);
    rejects(tooManyStatic,Arrays.asList(node("x","",true)),"bounded static option count (1001 refused)");
    Map<String,Object> templated=new LinkedHashMap<>(field);Map<String,Object> templatedChoices=new LinkedHashMap<>(Json.dict(field.get("choices")));templated.put("choices",templatedChoices);
    templatedChoices.put("label","{label} ({slug})");
    check("work (s-work)".equals(ChoiceTree.parse(templated,Collections.singletonMap("nodes",nodes)).rows().get(1).label),"a template label renders as for action choices");
    templatedChoices.put("label",Arrays.asList("label","missing","slug"));
    check("work · s-work".equals(ChoiceTree.parse(templated,Collections.singletonMap("nodes",nodes)).rows().get(1).label),"a list label joins its non-empty parts");
    templatedChoices.put("label","{label:kind}");
    check("Folder".equals(ChoiceTree.parse(templated,Collections.singletonMap("nodes",Arrays.asList(withKind(node("work","",true)))),Collections.singletonMap("folder","Folder")).rows().get(1).label),"a label modifier reads the description labels");
    templatedChoices.put("label","nothing");
    ChoiceTree unlabelled=ChoiceTree.parse(templated,Collections.singletonMap("nodes",Arrays.asList(node("work","",true),node("work/science","work",true))));
    unlabelled.toggle(unlabelled.rows().get(1).key);
    check("s-work".equals(unlabelled.rows().get(1).label) && "science".equals(unlabelled.rows().get(2).label),"a tree row without a label is named by its value's last path component, not refused");
    Map<String,Object> flatUnlabelled=new LinkedHashMap<>(templated);Map<String,Object> flatUnlabelledChoices=new LinkedHashMap<>(templatedChoices);flatUnlabelledChoices.remove("tree");flatUnlabelled.put("choices",flatUnlabelledChoices);
    check("s-work/science".equals(ChoiceTree.parse(flatUnlabelled,Collections.singletonMap("nodes",nodes)).rows().get(2).label),"a flat row without a label is named by its value");
    Map<String,Object> filtered=new LinkedHashMap<>(flat);Map<String,Object> filteredChoices=new LinkedHashMap<>(flatChoices);filtered.put("choices",filteredChoices);
    filteredChoices.put("where","selectable");
    List<ChoiceTree.Row> kept=ChoiceTree.parse(filtered,Collections.singletonMap("nodes",nodes)).rows();
    check(kept.size()==4 && kept.stream().noneMatch(r->r.label.equals("private")),"flat choices apply choices.where as iOS does");
    filteredChoices.put("where",Json.dict(Json.parseOrNull("{\"field\":\"parent\",\"equals\":\"work\"}".getBytes())));
    kept=ChoiceTree.parse(filtered,Collections.singletonMap("nodes",nodes)).rows();
    check(kept.size()==2 && kept.get(1).label.equals("science"),"flat choices.where compares a field");
Map<String,Object> blank=node("blank","",true); blank.put("slug","");
rejects(field,Arrays.asList(blank),"a selectable remote row cannot take the static empty value");
Map<String,Object> folder=node("folder","",false); folder.put("slug","");
boolean structural=true; try { ChoiceTree.parse(field,Collections.singletonMap("nodes",Arrays.asList(folder,node("folder/x","folder",true)))); } catch(IllegalArgumentException e) { structural=false; }
check(structural,"an unselectable folder with no value is accepted");
Map<String,String> labels=ChoiceTree.parse(field,Collections.singletonMap("nodes",nodes)).labels();
check("science".equals(labels.get("s-work/science")) && "Only this item".equals(labels.get("")) && !labels.containsKey("s-private"),"loaded labels name every selectable value, never a private folder");
for(String kind:new String[]{null,"","text","prose","multiline","code","url","secure","new_secure","unknown-kind"}){int t=TextInputTraits.forField(kind,"username");check((t&0xf)==1 && (t&0x1f000)==0 && (t&0x80000)!=0,"a username of kind "+kind+" is typed exactly: no capitalization, correction or completion, and no suggestions");}
check(TextInputTraits.forField("number","username")==TextInputTraits.forKind("number"),"a numeric username keeps number traits (no text flags exist there)");
check((TextInputTraits.forField("multiline","username")&0x20000)!=0,"a multiline username stays multiline");
check(TextInputTraits.forField("text","title")==TextInputTraits.forKind("text"),"other text fields keep ordinary traits");
    check((TextInputTraits.forKind("text") & 0xc000)==0xc000,"ordinary text sentence capitalization and correction");
    check((TextInputTraits.forKind("multiline") & 0x2c000)==0x2c000,"multiline capitalization and correction");
    check((TextInputTraits.forKind("url") & 0xc000)==0,"URL excludes prose traits");
    check((TextInputTraits.forKind("secure") & 0xc000)==0,"password excludes prose traits");
  }
  static Map<String,Object> withKind(Map<String,Object> node) { node.put("kind","folder"); return node; }
  static void refusesRoute(Map<String,Object> field,String name) { boolean refused=false; try {ChoiceTree.readRoute(field);} catch(IllegalArgumentException e) {refused=true;} check(refused,name); }
  static void rejects(Map<String,Object> field,List<Object> nodes,String name) { boolean rejected=false; try {ChoiceTree.parse(field,Collections.singletonMap("nodes",nodes));} catch(IllegalArgumentException e) {rejected=true;} check(rejected,name); }
}
