#!/usr/bin/env sh
# The compose-managed probe and the loud-skip discipline of the root-side
# commands. Probe-only: these cases assert the NOT-managed verdicts, which
# need no docker daemon (a remote host needs no docker at all, and a dead
# daemon IS one of the real not-managed topologies). The managed verdict and
# the full configure-auth path need a live daemon and are exercised there,
# not here.
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
PROBE="$PACKAGE_ROOT/tools/dev/compose-managed"
CONFIGURE_AUTH="$PACKAGE_ROOT/tools/dev/mysql-configure-auth"

tmp="$(mktemp -d "${TMPDIR:-/tmp}/hey-mysql-probe-spec.XXXXXX")"
listener_pid=''
cleanup() {
  if test -n "$listener_pid"; then kill "$listener_pid" 2>/dev/null || true; fi
  rm -rf "$tmp"
}
trap cleanup EXIT HUP INT TERM

fail() {
  echo "FAIL: compose_probe_spec: $1" >&2
  exit 1
}

run_hermetic() {
  env -u APP_ENV -u MYSQL_DATABASE -u MYSQL_HOST -u MYSQL_PORT \
      -u HEY_MYSQL_BASE_DATABASE -u HEY_MYSQL_ENV_VAR -u HEY_MYSQL_APP_NAME \
      -u COMPOSE_PROJECT_NAME \
      HEY_MYSQL_PROJECT_ROOT="$tmp" "$@"
}

# 1. A REMOTE resolved host can never be this machine's compose container:
#    not-managed (exit 3), loudly, before docker is even consulted.
printf 'MYSQL_HOST=db.internal.example\nMYSQL_PORT=3999\n' > "$tmp/.env"
rc=0
run_hermetic "$PROBE" > "$tmp/probe.out" 2> "$tmp/probe.err" || rc=$?
test "$rc" -eq 3 || fail "remote host: expected exit 3, got $rc"
grep -q 'NOT compose-managed' "$tmp/probe.err" || fail 'remote host: verdict must be loud'
grep -q 'not local' "$tmp/probe.err" || fail 'remote host: reason must name the non-local host'

# 2. A local endpoint with no running compose service (daemon down, no
#    compose project, or container stopped): not-managed (exit 3), loudly.
#    On this box the docker daemon is down, so this asserts exactly the
#    topology the 2026-07-30 lesson came from.
printf 'MYSQL_HOST=127.0.0.1\nMYSQL_PORT=3999\n' > "$tmp/.env"
rc=0
run_hermetic "$PROBE" > "$tmp/probe2.out" 2> "$tmp/probe2.err" || rc=$?
test "$rc" -eq 3 || fail "no running service: expected exit 3, got $rc"
grep -q 'NOT compose-managed' "$tmp/probe2.err" || fail 'no running service: verdict must be loud'

# 3. mysql-configure-auth on a not-managed endpoint: SKIPS loudly, touches
#    nothing, exits 0 (skipping is the correct outcome, not a failure).
rc=0
run_hermetic "$CONFIGURE_AUTH" > "$tmp/auth.out" 2> "$tmp/auth.err" || rc=$?
test "$rc" -eq 0 || fail "configure-auth skip: expected exit 0, got $rc"
grep -q 'SKIPPED' "$tmp/auth.err" || fail 'configure-auth: the skip must be loud'
grep -qi 'DROP USER' "$tmp/auth.err" || fail 'configure-auth: the skip must say what it refused to run'

# 4. External mode skips account configuration outright, loudly.
rc=0
run_hermetic env HEY_MYSQL_EXTERNAL=1 "$CONFIGURE_AUTH" > "$tmp/auth2.out" 2> "$tmp/auth2.err" || rc=$?
test "$rc" -eq 0 || fail "configure-auth external: expected exit 0, got $rc"
grep -q 'HEY_MYSQL_EXTERNAL=1' "$tmp/auth2.err" || fail 'configure-auth external: the skip must be loud'

# 5. mysql-up is a NO-OP when the resolved endpoint is already serving --
#    whatever the provider (here: a plain scratch listener standing in for a
#    tunnel or external server). Destruction stays behind --force. This is
#    the idempotency doctrine, provable without a docker daemon.
MYSQL_UP="$PACKAGE_ROOT/tools/dev/mysql-up"
if command -v nc >/dev/null 2>&1 && command -v python3 >/dev/null 2>&1; then
  port=46411
  while lsof -nP -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1; do
    port=$((port + 1))
    test "$port" -lt 46500 || fail 'no free scratch port for the idempotency case'
  done
  python3 -c '
import socket, sys, time
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("127.0.0.1", int(sys.argv[1])))
s.listen(1)
sys.stdout.write("ready\n")
sys.stdout.flush()
time.sleep(20)
' "$port" > "$tmp/up-listener.out" &
  listener_pid=$!
  waited=0
  while ! grep -q ready "$tmp/up-listener.out" 2>/dev/null; do
    waited=$((waited + 1))
    test "$waited" -le 50 || fail 'idempotency listener never came up'
    sleep 0.1 2>/dev/null || sleep 1
  done
  printf 'MYSQL_HOST=127.0.0.1\nMYSQL_PORT=%s\n' "$port" > "$tmp/.env"
  rc=0
  run_hermetic "$MYSQL_UP" > "$tmp/up.out" 2> "$tmp/up.err" || rc=$?
  kill "$listener_pid" 2>/dev/null || true
  wait "$listener_pid" 2>/dev/null || true
  listener_pid=''
  test "$rc" -eq 0 || fail "mysql-up over a serving endpoint: expected no-op exit 0, got $rc"
  grep -q 'already reachable' "$tmp/up.out" || fail 'mysql-up no-op must say the endpoint is already reachable'
  grep -q -- '--force' "$tmp/up.out" || fail 'mysql-up no-op must name --force as the only recreation path'
else
  echo 'note: nc/python3 missing; mysql-up idempotency case not exercised' >&2
fi

echo 'PASS: hey_mysql compose-managed probe not-managed verdicts and loud skips'
