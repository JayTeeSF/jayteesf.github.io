# Todo

- Add second unrelated consumer.
- Add generic QR encoder capability selection.
- Add expiry and one-shot page policy hooks.
- Keep production enrollment outside this development package.
