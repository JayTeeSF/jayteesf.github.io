#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT="$ROOT"
. "$ROOT/tools/android-env.sh"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
export HEY_ROOT
hey_android_resolve_hey_root ""
hey_android_isolate

work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-runtime-profile.XXXXXX")
trap 'rm -rf "$work"' EXIT

for obsolete in \
  native/runtime_profile/include/CommonCrypto/CommonDigest.h \
  native/runtime_profile/include/CommonCrypto/CommonRandom.h \
  native/vendor/sha256/sha256.c \
  native/vendor/sha256/sha256.h; do
  if [ -e "$ROOT/$obsolete" ]; then
    echo "FAIL: obsolete Android crypto impersonation artifact still ships: $obsolete" >&2
    exit 1
  fi
done
if grep -Eq 'CommonCrypto/|native/vendor/sha256/' "$ROOT/hey-package.json"; then
  echo 'FAIL: hey-package.json still publishes obsolete CommonCrypto/vendored-SHA files' >&2
  exit 1
fi

profile_include="$ROOT/native/runtime_profile/include"
flags=(
  -std=c11 -O2 -fPIC -pthread -Wall -Wextra -Werror -DHEY_NO_FAST_TLS=1
  "-DHEY_VERSION=\"android-runtime-profile-spec\""
  -DHEY_RUNTIME_NO_TLS_CLIENT=1
  -DHEY_RUNTIME_NO_TLS_SERVER=1
  -DHEY_RUNTIME_NO_AEAD=1
  -DHEY_RUNTIME_NO_PASSWORD_KDF=1
  -DHEY_RUNTIME_PLATFORM_CRYPTO=1
  '-DHEY_RUNTIME_PLATFORM_CRYPTO_HEADER="hey_android_platform_crypto.h"'
)

"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" "${flags[@]}"   -I"$profile_include" -I"$HEY_ROOT/runtime" -I"$HEY_ROOT/compiler/generated"   -MMD -MF "$work/runtime.d"   -c "$HEY_ROOT/runtime/hey_runtime.c" -o "$work/hey_runtime.o"

"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -std=c11 -O2 -fPIC   -Wall -Wextra -Werror -I"$profile_include"   -c "$ROOT/native/runtime_profile/hey_android_platform_crypto.c"   -o "$work/platform_crypto.o"

"$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -r   "$work/hey_runtime.o" "$work/platform_crypto.o" -o "$work/runtime_profile.o"

foreign_headers=$(tr ' \' '\n\n' < "$work/runtime.d" |
  grep -Ei 'CommonCrypto|openssl' || true)
if [ -n "$foreign_headers" ]; then
  echo "FAIL: Android runtime profile consumed foreign crypto headers:" >&2
  printf '%s\n' "$foreign_headers" >&2
  exit 1
fi

bad_symbols=$("$HEY_ANDROID_NM" --no-sort "$work/runtime_profile.o" 2>/dev/null |
  awk 'NF {print $NF}' |
  grep -E '^(CC_|CCRandom|timingsafe_bcmp$|BIO_|CRYPTO_|ERR_|EVP_|OPENSSL|OSSL_|RAND_|SSL_|TLS_)' || true)
if [ -n "$bad_symbols" ]; then
  echo "FAIL: Android runtime profile carries Apple/OpenSSL symbols:" >&2
  printf '%s\n' "$bad_symbols" >&2
  exit 1
fi

for sym in hey_runtime_platform_random_bytes hey_runtime_platform_constant_time_bcmp; do
  "$HEY_ANDROID_NM" "$work/platform_crypto.o" | grep -q " T $sym$" ||
    { echo "FAIL: Android profile does not define $sym" >&2; exit 1; }
done

if "$HEY_ANDROID_NM" "$work/runtime_profile.o" | grep -Eq ' (T|U) (hey_android_sha256_|CC_SHA256_)'; then
  echo "FAIL: Android profile still carries its own SHA-256 implementation" >&2
  exit 1
fi

echo "PASS: Android runtime uses the platform-neutral crypto seam with in-tree SHA-256"
