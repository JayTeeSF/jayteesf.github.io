#!/usr/bin/env bash
# The api_screens renderer on the Android 16 (API 36) emulator, headless, against
# specs/support/fake_api_server.rb on the Mac (the emulator reaches it at 10.0.2.2).
#
#   1. Launch and resume draw the bundled UI without fetching a definition.
#   2. Sign-in: the form draws its known fields, not the unknown one. An empty
#      form says what is needed and sends nothing; a wrong passphrase shows the
#      server's refusal and keeps no session. Control: the right one does.
#   3. The session is sealed: the token the server issued is not in the kept
#      file. Control: the same search finds it in the server's own list.
#   4. The list: rows from the server; the unknown section, button, row kinds and
#      the undrawn tab are not drawn, and nothing ever asks for their routes.
#      Control: tapping the known button beside them is asked for.
#   5. A row opens its screen with the bearer token; back returns to the list.
#   6. A kept session opens the list on the next launch with no sign-in.
#   7. A search tab (Later): the keyboard can always be put away -- Cancel with the
#      box empty, the search key, a tap below the box, a drag, system Back (which
#      then does not navigate) -- and leaving for Account takes it away; Back from
#      Account, or Account then another tab then the search tab, shows the search
#      tab's root with no keyboard. While a request is out it says it is searching;
#      answered with nothing it says so with the query; a failure says it did not
#      finish; a search cleared while its request was out stays cleared.
#      Control: with the box tapped, the same probe reads the keyboard as up.
#   8. Sign-out asks first, revokes, removes the kept session and shows sign-in.
#   9. Valid and corrupt legacy caches cannot override the bundle online or offline.
#  10. No crash of the app in logcat.
#
# HEY_ANDROID_API_EVIDENCE=DIR keeps the screenshots in DIR.
# THE EMULATOR AND THE SERVER ARE ALWAYS STOPPED, on success, failure and interrupt.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-api-emulator-spec.XXXXXX")
mkdir -p "$work/shots"
serial=''
server_pid=''
intent_installed=false
browser_before=''
evidence=${HEY_ANDROID_API_EVIDENCE:-}
package=com.jayteesf.hey.api.fixture
activity=hey.android.api.HeyAndroidApiActivity
pass() { echo "PASS: $*"; }
control() { echo "PASS (control): $*"; }
bad() { echo "FAIL: $*"; failed=1; }
export ADB=$HEY_ANDROID_ADB

stop_server() {
  if [ -n "$server_pid" ]; then
    kill "$server_pid" 2> /dev/null
    wait "$server_pid" 2> /dev/null
    server_pid=''
  fi
}
on_exit() {
  status=$?
  stop_server
  if [ -n "$serial" ]; then
    if [ "$intent_installed" = true ]; then
      adbs shell cmd role remove-role-holder --user 0 android.app.role.BROWSER hey.android.fixture > /dev/null 2>&1 || true
      for previous in $browser_before; do
        adbs shell cmd role add-role-holder --user 0 android.app.role.BROWSER "$previous" > /dev/null 2>&1 || status=1
      done
      adbs uninstall hey.android.fixture > /dev/null 2>&1 || true
    fi
    "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" > "$work/shutdown.log" 2>&1 || { cat "$work/shutdown.log"; status=1; }
  fi
  if pgrep -f "qemu-system.*-avd $HEY_ANDROID_AVD( |$)" > /dev/null 2>&1; then
    echo "FAIL: an emulator process for $HEY_ANDROID_AVD is still running after shutdown"
    status=1
  fi
  if [ -n "$evidence" ]; then mkdir -p "$evidence" && cp "$work"/shots/* "$evidence"/ 2> /dev/null || true; fi
  rm -rf "$work"
  exit "$status"
}
trap on_exit EXIT
trap 'exit 130' INT TERM

adbs() { "$HEY_ANDROID_ADB" -s "$serial" "$@"; }
drive() { "$HEY_ANDROID_RUBY" "$ROOT/specs/support/drive.rb" "$serial" "$@" > "$work/drive.last" 2>&1; }
texts() { "$HEY_ANDROID_RUBY" "$ROOT/specs/support/drive.rb" "$serial" texts 2> /dev/null; }
shot() { "$HEY_ANDROID_RUBY" "$ROOT/specs/support/drive.rb" "$serial" shot "$work/shots/$1.png" > /dev/null 2>&1; }
logged() { adbs logcat -d -v tag -s 'hey.api:*' 2> /dev/null | grep -c -- "$1"; }
requests() { # METHOD PATH: how many the server has seen
  "$HEY_ANDROID_RUBY" -rjson -e 'n = 0
File.foreach(ARGV[0]) do |line|
  r = JSON.parse(line)
  n += 1 if r["method"] == ARGV[1] && r["path"].start_with?(ARGV[2])
end
puts n' "$work/requests.jsonl" "$1" "$2"
}
last_request() { # METHOD PATH FIELD
  "$HEY_ANDROID_RUBY" -rjson -e 'hit = nil
File.foreach(ARGV[0]) do |line|
  r = JSON.parse(line)
  hit = r if r["method"] == ARGV[1] && r["path"].start_with?(ARGV[2])
end
puts(hit ? JSON.generate(hit[ARGV[3]]) : "none")' "$work/requests.jsonl" "$1" "$2" "$3"
}
session_files() { adbs shell run-as "$package" ls no_backup 2> /dev/null | tr -d '\r' | grep -c '^hey-session-' ; }
launch() {
  adbs shell am force-stop "$package"
  adbs logcat -c
  adbs shell am start -W -n "$package/$activity" > "$work/launch.txt" 2>&1
}

header_links() {
# The HTTPS image view is the accessible target, independent of its poster
# address and bitmap download; the placeholder is usable offline too.
launch
drive wait '3 kept' 20
drive tap Stalker
if drive wait 'Open Stalker' 20 && drive tap 'Open Stalker'; then
  if drive wait 'android.intent.action.VIEW' 15 && drive wait 'https://example.test/watch' 10; then
    shot 19-content-url
    pass "the accessible header picture sends ACTION_VIEW with the exact bound content URL to the isolated receiver"
  else bad "header picture did not launch the content URL"; fi
else bad "header picture lacks its accessible link target"; fi
# Return through the receiver's calling task, as a user does. Force-stopping
# the caller while its child Activity is on top can race task cleanup/relaunch.
adbs shell input keyevent 4
drive wait 'Made by' 20
adbs shell input keyevent 4
drive wait '3 kept' 20
drive tap 'The Left Hand of Darkness'
if ! drive logwait 'request: GET /v1/items/i1 -> 200' 20 || ! drive wait 'The Left Hand of Darkness' 20; then
  shot 20-invalid-load-failed
  adbs logcat -d -v tag -s 'hey.api:*' > "$work/shots/20-invalid-load.log"
  bad "the invalid-target item did not load"
elif drive wait 'Open The Left Hand of Darkness' 2; then
  bad "invalid header URL remained actionable"
else
  shot 20-inert-image
  control "a loaded header with an invalid content URL has no accessible open target"
fi
adbs shell input keyevent 4
drive wait '3 kept' 20
drive tap Stalker
drive wait 'Made by' 20
}

return_to_item() {
  drive tap Shelf && drive wait '3 kept' 20 && drive tap Stalker && drive wait 'Made by' 20
}

check_native_copy() {
  category=$1
  sample=$2
  method=$3
  result=$4
  if [ "$category" = title ]; then
    drive tap Shelf && drive wait '3 kept' 20 || { bad "could not return to Shelf before title copy"; return_to_item || true; return 1; }
    target=Stalker
  else
    target=$sample
  fi
  if ! drive scrollto "$target" 8; then
    bad "could not scroll to the synthetic $category"
    return_to_item || true
    return 1
  fi
  if ! drive long "$target" 1200; then
    bad "could not long-press the synthetic $category"
    return_to_item || true
    return 1
  fi
  shot "native-copy-$category-menu"
  if [ "$method" = toolbar ]; then
    if ! drive copy; then
      bad "could not invoke native Copy for $category"
      return_to_item || true
      return 1
    fi
  elif ! drive copy-key; then
    bad "could not invoke native Copy for $category"
    return_to_item || true
    return 1
  fi
  if ! drive tap Later || ! drive clear Later; then
    bad "could not open and clear Later search before pasting $category"
    return_to_item || true
    return 1
  fi
  if ! drive paste Later || ! drive wait "$sample" 20; then
    # Android's system selection toolbar can lose the clipboard during an
    # activity/tab transition. Make one fresh *native* selection and paste,
    # rather than declaring a permanently broken Copy flow on a transient.
    # A repeat failure still fails the release gate.
    if ! return_to_item || ! drive scrollto "$target" 8 ||
       ! drive long "$target" 1200 ||
       { [ "$method" = toolbar ] && ! drive copy; } ||
       { [ "$method" != toolbar ] && ! drive copy-key; } ||
       ! drive tap Later || ! drive clear Later ||
       ! drive paste Later || ! drive wait "$sample" 20; then
      shot "native-copy-$category-paste-failed"
      bad "pasting the copied $category into the Later search field lost its text after a fresh native selection: $(texts | tr '\n' '|' | cut -c1-220)"
      return_to_item || true
      return 1
    fi
  fi
  shot "native-copy-$category-query"
  searches_before=$(requests POST /v1/search)
  if ! drive search; then
    bad "could not activate the keyboard Search action for $category"
  else
    searches_after=$searches_before
    for _ in $(seq 1 20); do
      searches_after=$(requests POST /v1/search)
      [ "$searches_after" -gt "$searches_before" ] && break
      /bin/sleep 0.25
    done
    if [ "$searches_after" -eq "$((searches_before + 1))" ] && drive wait "$result" 20; then
      shot "native-copy-$category-result"
      pass "native Copy selected and pasted the synthetic $category into Later search; one search request and the expected state appeared"
    else
      shot "native-copy-$category-result-failed"
      bad "the pasted $category did not produce exactly one search request and expected state '$result' (requests $searches_before -> $searches_after): $(texts | tr '\n' '|' | cut -c1-220)"
    fi
  fi
  return_to_item || { bad "could not restore Stalker detail after testing $category"; return 1; }
}

native_copy_checks() {
  check_native_copy title Stalker toolbar 'Andrei Tarkovsky' || true
  check_native_copy description 'copy sentinel description' key 'Nothing on the shelf matches.' || true
  check_native_copy note 'copy sentinel private note' key 'Nothing on the shelf matches.' || true
  check_native_copy message 'copy sentinel message' key 'Nothing on the shelf matches.' || true
  check_native_copy tags 'copy sentinel tag one and tag two' key 'Nothing on the shelf matches.' || true
}

port=$("$HEY_ANDROID_RUBY" -rsocket -e 's = TCPServer.new("127.0.0.1", 0); puts s.addr[1]; s.close')
served=$work/served.json
cp "$ROOT/specs/support/api_fixture_description.json" "$served"
: > "$work/requests.jsonl"
: > "$work/tokens.txt"
start_server() {
  "$HEY_ANDROID_RUBY" "$ROOT/specs/support/fake_api_server.rb" --port "$port" --description "$served" --log "$work/requests.jsonl" --tokens "$work/tokens.txt" > "$work/server.log" 2>&1 &
  server_pid=$!
  for _ in $(seq 1 50); do
    curl -s -o /dev/null "http://127.0.0.1:$port/v1/session" && return 0
    /bin/sleep 0.2
  done
  return 1
}
start_server || { bad "the fake server did not start on port $port: $(cat "$work/server.log")"; exit 1; }
baked_sha=$(hey_android_sha256 "$ROOT/specs/support/api_fixture_description.json")

# ---- build and boot --------------------------------------------------------------------------------
if ! "$ROOT/tools/hey-android-api-app.sh" --description "$ROOT/specs/support/api_fixture_description.json" --origin "http://10.0.2.2:$port" \
  --package-id "$package" --label 'Hey api fixture' --out "$work/apk" > "$work/build.log" 2>&1; then
  bad "the fixture APK did not build: $(tail -5 "$work/build.log")"
  exit 1
fi
"$ROOT/tools/hey-android-emulator.sh" create-avd > "$work/avd.log" 2>&1 || { bad "could not create the AVD: $(cat "$work/avd.log")"; exit 1; }
if ! boot_line=$("$ROOT/tools/hey-android-emulator.sh" boot 2> "$work/boot.err"); then
  bad "the emulator did not boot: $(tail -5 "$work/boot.err")"
  exit 1
fi
serial=$(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^serial=//p')
pass "booted AVD $HEY_ANDROID_AVD headless as $serial; fake server on port $port"
adbs shell settings put system accelerometer_rotation 0 > /dev/null 2>&1
adbs shell svc power stayon true > /dev/null 2>&1 || true
adbs uninstall "$package" > /dev/null 2>&1
adbs install -r "$work/apk/app.apk" > "$work/install.log" 2>&1 || { bad "install failed: $(cat "$work/install.log")"; exit 1; }

# Receive actual implicit VIEW intents without browser setup, network or terms.
browser_before=$(adbs shell cmd role get-role-holders --user 0 android.app.role.BROWSER | tr -d '\r')
if ! bash "$ROOT/specs/support/build_intent_receiver.sh" "$work/intent" > "$work/intent-build.log" 2>&1 \
  || ! adbs install -r "$work/intent/app.apk" > "$work/intent-install.log" 2>&1; then
  bad "could not build/install the isolated intent receiver"; exit 1
fi
intent_installed=true
adbs shell cmd role add-role-holder --user 0 android.app.role.BROWSER hey.android.fixture > "$work/intent-role.log" 2>&1
if ! adbs shell cmd role get-role-holders --user 0 android.app.role.BROWSER | tr -d '\r' | grep -qx hey.android.fixture; then
  bad "the isolated receiver did not become the test emulator's temporary browser handler"; exit 1
fi
if [ "${HEY_ANDROID_API_HEADER_ONLY:-0}" = 1 ]; then
  launch
  drive wait Name 30
  drive type Name ann
  drive type Passphrase fixture-pass-1
  adbs shell input keyevent 111
  drive tap 'Sign in'
  drive wait '3 kept' 30
  header_links
  exit "$failed"
fi
if [ "${HEY_ANDROID_API_COPY_ONLY:-0}" = 1 ]; then
  launch
  drive wait Name 30
  drive type Name ann
  drive type Passphrase fixture-pass-1
  adbs shell input keyevent 111
  drive tap 'Sign in'
  drive wait '3 kept' 30
  native_copy_checks
  exit "$failed"
fi

# ---- 1. bundled launch and resume -----------------------------------------------------------------------
launch
if drive logwait 'screen ready: signin' 60 && drive logwait "drawing the baked copy ${baked_sha:0:12}" 20 \
  && [ "$(requests GET /v1/app/description)" = 0 ]; then
  pass "cold launch draws the bundled sign-in screen without requesting a UI definition"
else
  bad "cold launch did not stay bundled"
fi
adbs shell input keyevent 3
/bin/sleep 1
adbs shell am start -W -f 0x10200000 -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n "$package/$activity" > /dev/null
if drive wait 'Fixture sign-in' 30 && [ "$(requests GET /v1/app/description)" = 0 ]; then
  pass "foreground resume keeps the bundled UI without requesting a definition"
else bad "resume did not return to bundled sign-in: $(texts | tr '\n' '|')"; exit 1; fi

# ---- 2. sign-in -------------------------------------------------------------------------------------------
shot 1-signin
screen=$(texts)
if printf '%s\n' "$screen" | grep -qx 'Name' && printf '%s\n' "$screen" | grep -qx 'Passphrase' && ! printf '%s\n' "$screen" | grep -q 'Face scan'; then
  pass "the sign-in form draws Name and Passphrase and not the camera field it does not know"
  control "the known fields beside the hidden one are on screen"
else
  bad "sign-in shows: $(printf '%s' "$screen" | tr '\n' '|')"
fi
before=$(requests POST /v1/session)
drive tap 'Sign in'
if drive wait 'Name is needed.' 20 && [ "$(requests POST /v1/session)" = "$before" ]; then
  pass "an empty form says 'Name is needed.' and sends no request"
else
  bad "the empty form: $(cat "$work/drive.last"), $(requests POST /v1/session) sign-in requests"
fi
drive type Name ann
drive type Passphrase wrong-pass
adbs shell input keyevent 111
drive tap 'Sign in'
if drive wait 'wrong name or passphrase' 30 && [ "$(session_files)" = 0 ]; then
  shot 2-refused
  pass "a wrong passphrase shows the server's refusal and no session is kept"
else
  bad "the wrong passphrase: $(cat "$work/drive.last"), session files $(session_files)"
fi
drive type Passphrase ''
adbs shell input keycombination 113 29 > /dev/null 2>&1
adbs shell input keyevent 67
adbs shell input text fixture-pass-1
adbs shell input keyevent 111
drive tap 'Sign in'
if drive logwait 'screen ready: library' 40 && drive wait '3 kept' 30; then
  shot 3-library
  if [ "$(session_files)" = 1 ]; then
    control "after the right passphrase the same listing finds one kept session file"
  else
    bad "(control) no session file after signing in"
  fi
else
  bad "signing in did not show the list: $(adbs logcat -d -v tag -s 'hey.api:*' | tail -4)"
fi
if drive logwait 'request: POST /v1/events -> 200' 20 \
  && [ "$(requests POST /v1/events)" = 1 ] \
  && [ "$(last_request POST /v1/events surface)" = '"android"' ] \
  && [ "$(last_request GET /v1/items surface)" = '"android"' ]; then
  pass "the signed-in library view emits one manifest-declared semantic event, and ordinary API requests identify the android surface"
else
  bad "telemetry after sign-in: events $(requests POST /v1/events), event surface $(last_request POST /v1/events surface), items surface $(last_request GET /v1/items surface)"
fi

# ---- 3. sealed --------------------------------------------------------------------------------------------
token=$(tail -1 "$work/tokens.txt")
name=$(adbs shell run-as "$package" ls no_backup 2> /dev/null | tr -d '\r' | grep '^hey-session-' | head -1)
adbs exec-out run-as "$package" cat "no_backup/$name" > "$work/sealed.bin" 2> /dev/null
sealed_bytes=$(wc -c < "$work/sealed.bin" | tr -d ' ')
if [ "${#token}" = 64 ] && [ "$sealed_bytes" -gt 64 ] && ! grep -q "$token" "$work/sealed.bin" && ! LC_ALL=C grep -qa "${token:0:16}" "$work/sealed.bin" \
  && [ "$(logged 'sealed with Keystore key')" -ge 1 ]; then
  pass "the kept session no_backup/$name ($sealed_bytes bytes) does not hold the issued token or any 16 characters of it; it was sealed with an Android Keystore key"
else
  bad "the kept session: token ${#token} chars, file $sealed_bytes bytes"
fi
grep -q "$token" "$work/tokens.txt" && control "the same search finds the token in the server's list of issued tokens" || bad "(control) the token search found nothing"

# ---- 4. hidden kinds --------------------------------------------------------------------------------------
drive scrollto 'Your account' 6
shot 4-library-bottom
screen=$(texts; drive scrollto 'Kept' 0; texts)
hidden_seen=''
for word in Teleport Carousel CAROUSEL Portal Beam; do printf '%s\n' "$screen" | grep -qx "$word" && hidden_seen="$hidden_seen $word"; done
if [ -z "$hidden_seen" ] && printf '%s\n' "$screen" | grep -qx 'Stalker' && printf '%s\n' "$screen" | grep -qx 'Mark all read' \
  && printf '%s\n' "$screen" | grep -qx 'Your account' && printf '%s\n' "$screen" | grep -qx 'Later'; then
  pass "the list draws the server's rows, 'Mark all read', 'Your account' and the supported search tab Later, while hiding Teleport, Carousel, Portal and Beam"
else
  bad "hidden/required kinds on screen:$hidden_seen; screen: $(printf '%s' "$screen" | tr '\n' '|' | cut -c1-300)"
fi
drive scrollto 'Mark all read' 6
drive tap 'Mark all read'
/bin/sleep 3
never=$(requests GET /v1/never)$(requests POST /v1/never)
if [ "$never" = 00 ] && [ "$(requests POST /v1/mark)" = 1 ]; then
  pass "nothing ever asked for a hidden kind's route (/v1/never: 0 requests)"
  control "the tap on the known button beside them was sent (POST /v1/mark: 1)"
else
  bad "hidden routes asked: $never; POST /v1/mark: $(requests POST /v1/mark)"
fi

# ---- 5. a row, and back ------------------------------------------------------------------------------------
drive scrollto 'Stalker' 6
drive tap 'Stalker'
if drive wait 'Andrei Tarkovsky' 30 && drive wait 'Made by' 10; then
  shot 5-item
  if drive scrollto 'FINAL SENTENCE: I am glad you enjoyed the video.' 10 --contains; then
    shot 5-long-conversation-message
    pass "the item screen contains Ron's synthetic long message and its distinctive ending (5-long-conversation-message screenshot)"
  else
    bad "the item screen did not expose the full synthetic conversation text"
  fi
  on_item=$(texts)
  if [ "$(last_request GET /v1/items/i2 bearer)" = true ] && ! printf '%s\n' "$on_item" | grep -qx '3 kept'; then
    pass "tapping 'Stalker' opens its screen: GET /v1/items/i2 with the bearer token, 'Made by Andrei Tarkovsky'"
  else
    bad "the item screen: bearer $(last_request GET /v1/items/i2 bearer)"
  fi
else
  bad "tapping the row did not open the item: $(cat "$work/drive.last")"
fi
# Delayed callbacks cannot present dialogs or share after navigation away.
drive scrollto 'Slow friend picker' 6
drive tap 'Slow friend picker'
adbs shell input keyevent 4
/bin/sleep 5
if drive wait '3 kept' 15 && ! drive wait 'Alex Fixture' 2 && [ "$(requests POST /v1/never/stale)" = 0 ]; then
  pass "a delayed friend list after Back does not present its old picker or send a write"
else bad "a stale friend picker survived Back"; fi
drive tap Stalker
drive scrollto 'Slow friend picker' 6
drive tap 'Slow friend picker'
if drive wait 'Alex Fixture' 20; then
  control "the same delayed picker appears when its page remains current"
  drive tap Cancel
else bad "current delayed friend picker never appeared"; fi
drive scrollto 'Slow link request' 6
drive tap 'Slow link request'
adbs shell input keyevent 4
/bin/sleep 5
if drive wait '3 kept' 15 && ! drive wait 'https://example.test/late' 2 --contains; then
  pass "a delayed link response after Back cannot launch the native share sheet"
else bad "a stale link response launched sharing after Back"; fi
drive tap Stalker
# Generic chooser cancellation, note preservation, response sharing and reload.
drive scrollto 'Send to a friend' 6
drive tap 'Send to a friend'
drive wait 'Alex Fixture' 20
drive tap Cancel
if [ "$(requests POST /v1/items/i2/share)" = 0 ]; then
  control "cancelling the friend picker sends no share"
else bad "cancelled picker sent a share"; fi
drive tap 'Send to a friend'
drive wait 'Alex Fixture' 20
drive tap 'Alex Fixture'
drive wait 'A note' 15
drive tap Cancel
if [ "$(requests POST /v1/items/i2/share)" = 0 ]; then
  control "cancelling the optional note sends no share"
else bad "cancelled note sent a share"; fi
drive tap 'Send to a friend'
drive wait 'Alex Fixture' 20
drive tap 'Alex Fixture'
drive type Note 'For%syou'
adbs shell input keyevent 111
before=$(requests GET /v1/items/i2)
drive tap Send
if drive wait 'https://example.test/item/shared' 25 --contains \
  && [ "$(last_request POST /v1/items/i2/share status)" = 200 ] \
  && [ "$(requests GET /v1/items/i2)" -gt "$before" ]; then
  shot 17-item-share
  pass "selected friend and note reach the server once; Android's share sheet displays the returned item link, with reload completed"
else bad "item share did not preserve recipient/note, present its link, and reload: $(texts | tr '\n' '|')"; fi
adbs shell input keyevent 4
drive scrollto 'Share a set link' 6
drive tap 'Share a set link'
if drive wait 'https://example.test/set/shared' 20 --contains; then
  shot 18-set-share
  pass "a request share_result also opens Android's sheet with a set link"
else bad "set share sheet did not display the returned link"; fi
adbs shell input keyevent 4
drive scrollto 'Invalid link' 6
drive tap 'Invalid link'
if drive wait 'Invalid link' 10 && ! adbs shell dumpsys activity activities | grep 'mResumedActivity' | grep -q ChooserActivity; then
  control "an invalid returned link leaves the app visible and opens no share sheet"
else bad "invalid link opened a share sheet"; fi
header_links

adbs shell input keyevent 4
if drive logwait 'back to: library' 20 && drive wait '3 kept' 20; then
  shot 6-back
  pass "system back returns to the list ('3 kept' again; it was not on the item screen)"
else
  bad "back did not return to the list"
fi
i=0
while [ "$(requests POST /v1/events)" -lt 3 ] && [ "$i" -lt 20 ]; do i=$((i + 1)); sleep 0.25; done
if [ "$(requests POST /v1/events)" -ge 3 ] && [ "$(last_request POST /v1/events status)" = 200 ]; then
  pass "opening the item and returning to Library each emit a screen view; telemetry follows presentation rather than redraws"
else
  bad "screen-view sequence emitted $(requests POST /v1/events) events"
fi

# ---- 6. kept session ---------------------------------------------------------------------------------------
checks=$(requests GET /v1/session)
launch
if drive logwait 'screen ready: library' 40 && [ "$(logged 'screen ready: signin')" = 0 ] && [ "$(requests GET /v1/session)" -gt "$checks" ]; then
  pass "launched again with a kept session, the app checks it (GET /v1/session) and opens the list with no sign-in"
else
  bad "the kept session did not open the list"
fi

# ---- 7. a search screen: the keyboard, the tabs, and where a search stands -----------------------------------
ime() { adbs shell dumpsys input_method 2> /dev/null | grep -m1 -o 'mInputShown=[a-z]*' | cut -d= -f2; }
ime_settles() { # WANT: the keyboard reaches WANT within a few seconds
  for _ in $(seq 1 12); do [ "$(ime)" = "$1" ] && return 0; /bin/sleep 0.5; done
  return 1
}
focus_search() { drive type Later "${1:-}" && ime_settles true; }
drive tap Later
if drive wait 'Find on the shelf' 20 && ime_settles false; then
  pass "the search tab opens with its box and no keyboard"
else
  bad "the search tab: $(texts | tr '\n' '|' | cut -c1-200), keyboard $(ime)"
fi
if focus_search; then
  control "with the box tapped, the same probe reads the keyboard as up (mInputShown=true)"
else
  bad "(control) tapping the box did not raise a keyboard the probe can see ($(ime))"
fi
# THE REPORTED BUG: emptied, the box left the keyboard up and nothing on the screen put it away.
adbs shell input keycombination 113 29 > /dev/null 2>&1
adbs shell input keyevent 67
if drive wait Cancel 10 && [ "$(ime)" = true ] && drive tap Cancel && ime_settles false && [ "$(logged 'keyboard: put away (cancel)')" -ge 1 ]; then
  shot 10-search-cancel-empty
  pass "with the box EMPTY, Cancel is offered and puts the keyboard away"
else
  bad "the empty box: Cancel $(texts | grep -c '^Cancel$'), keyboard $(ime)"
fi
focus_search sta
adbs shell input keyevent 66
if drive wait Stalker 20 && ime_settles false && [ "$(logged 'keyboard: put away (search)')" -ge 1 ]; then
  shot 11-search-found
  pass "the search key asks (POST /v1/search with body keys $(last_request POST /v1/search body_keys)), shows 'Stalker' and puts the keyboard away"
else
  shot 11-search-key-failed
  bad "the search key: keyboard $(ime), searches sent $(requests POST /v1/search), screen: $(texts | tr '\n' '|' | cut -c1-200), $(cat "$work/drive.last")"
fi
focus_search
# Above the keyboard and below the one row: a touch on the keyboard never reaches the app.
adbs shell input tap 540 900
if ime_settles false && [ "$(logged 'keyboard: put away (touch outside)')" -ge 1 ]; then
  pass "a tap below the box puts the keyboard away"
else
  bad "a tap below the box left the keyboard $(ime)"
fi
focus_search
adbs shell input swipe 540 1100 540 700 300
if ime_settles false; then
  pass "a drag through the results puts the keyboard away"
else
  bad "a drag left the keyboard $(ime)"
fi
focus_search
backs=$(logged 'back to:')
adbs shell input keyevent 4
if ime_settles false && [ "$(logged 'back to:')" = "$backs" ] && drive wait Cancel 5; then
  pass "system Back with the keyboard up puts the keyboard away and does not navigate"
else
  bad "system Back: keyboard $(ime), back-to lines $backs -> $(logged 'back to:')"
fi
focus_search
drive tap Account
if drive wait 'Signed in as' 20 && ime_settles false; then
  pass "opening Account from the search tab with the keyboard up leaves the keyboard behind"
else
  bad "Account from the search tab: keyboard $(ime)"
fi
adbs shell input keyevent 4
if drive logwait 'back to: later' 20 && drive wait sta 10 && /bin/sleep 1.5 && [ "$(ime)" = false ]; then
  shot 12-search-back
  pass "Back from Account returns to the search tab and does not raise the keyboard"
else
  bad "Back to the search tab: keyboard $(ime)"
fi
drive tap Account
drive wait 'Signed in as' 20
drive tap Shelf
drive wait '3 kept' 20
drive tap Later
if drive wait 'Find on the shelf' 20 && ! texts | grep -qx 'Signed in as' && /bin/sleep 1.5 && [ "$(ime)" = false ]; then
  shot 13-search-tab-again
  pass "Account, another tab, then the search tab again shows the search tab's root, not Account, and no keyboard"
else
  bad "the search tab again: $(texts | tr '\n' '|' | cut -c1-200), keyboard $(ime)"
fi
focus_search slow
adbs shell input keyevent 66
if drive wait 'Searching for “slow”…' 4; then
  shot 14-search-running
  pass "while the request is out the screen says 'Searching for “slow”…'"
else
  bad "no in-progress state: $(texts | tr '\n' '|' | cut -c1-200)"
fi
# The shelf section says its own empty text, so the screen adds no third
# "nothing" under it (0.4.4).
if drive wait 'Nothing on the shelf matches.' 20 && drive gone 'Searching for “slow”…' 5 && ! texts | grep -qF 'No results for “slow”.'; then
  shot 15-search-empty
  pass "answered with nothing, the section says 'Nothing on the shelf matches.', the in-progress line is gone, and no 'No results for' repeats it"
  control "the slow answer, left alone, is drawn when it lands"
else
  bad "no empty state: $(texts | tr '\n' '|' | cut -c1-200)"
fi
focus_search
adbs shell input keycombination 113 29 > /dev/null 2>&1
adbs shell input text slowstale
adbs shell input keyevent 66
drive tap Cancel
/bin/sleep 12
screen=$(texts)
if ! printf '%s\n' "$screen" | grep -q 'slowstale' && ! printf '%s\n' "$screen" | grep -q '^Searching for' \
  && printf '%s\n' "$screen" | grep -qx 'Type part of a title, then search.' && [ "$(last_request POST /v1/search status)" = 200 ]; then
  pass "a search cleared while its request was out ends idle: its late answer (200) is dropped, with no spinner and no 'No results' for it"
else
  bad "a cleared search: $(printf '%s' "$screen" | tr '\n' '|' | cut -c1-200)"
fi
focus_search broken
adbs shell input keyevent 66
if drive wait 'The search did not finish.' 20 && drive wait 'Try again' 5 && drive wait 'the search broke' 5; then
  shot 16-search-failed
  pass "a failed request shows 'The search did not finish.', the server's error and Try again, not an empty list"
else
  bad "no failed state: $(texts | tr '\n' '|' | cut -c1-200)"
fi
drive tap Shelf
drive wait '3 kept' 20

# ---- 7b. native text copy/paste -----------------------------------------------------------------------------
native_copy_checks
# The copy checks finish on Stalker's screen; sign-out starts from the list,
# whose Account button the item screen does not have.
adbs shell input keyevent 4
drive wait '3 kept' 20 || bad "could not return to the list after the copy checks"

# ---- 8. sign-out --------------------------------------------------------------------------------------------
drive tap Account
drive wait 'Signed in as' 30
drive scrollto 'Sign out of this phone' 6
drive tap 'Sign out of this phone'
if drive wait 'Sign out of this phone?' 20; then
  shot 7-confirm
  revokes=$(requests POST /v1/session/revoke)
  drive tap 'Sign out'
  if drive logwait 'signed out' 30 && drive logwait 'screen ready: signin' 30 && [ "$(requests POST /v1/session/revoke)" = $((revokes + 1)) ] && [ "$(session_files)" = 0 ]; then
    shot 8-signed-out
    pass "sign-out asked first, then POST /v1/session/revoke, removed the kept session and showed sign-in"
    [ "$revokes" = 0 ] && control "nothing was revoked before the confirmation was answered" || bad "(control) a revoke was sent before confirming"
  else
    bad "sign-out: revokes $(requests POST /v1/session/revoke), session files $(session_files)"
  fi
else
  bad "sign-out did not ask first"
fi

# ---- 9. hostile legacy UI cache, online and offline -------------------------------------------------------
sed 's/"title":"Fixture sign-in"/"title":"Remote-only sign-in"/' "$ROOT/specs/support/api_fixture_description.json" > "$served.new" && mv "$served.new" "$served"
adbs shell "run-as $package mkdir -p files/hey-description"
adbs shell "run-as $package sh -c 'cat > files/hey-description/$baked_sha.json'" < "$served"
if adbs shell "run-as $package cat files/hey-description/$baked_sha.json" | grep -q 'Remote-only sign-in'; then
  control "a valid legacy cache really contains a different sign-in screen and the obsolete served key"
else bad "could not install the legacy-cache negative control"; fi
launch
if drive wait 'Fixture sign-in' 30 && ! texts | grep -q 'Remote-only sign-in' \
  && [ "$(requests GET /v1/app/description)" = 0 ]; then
  pass "the online client ignores both changed server definitions and the matching-hash legacy cache"
else bad "a legacy cache or remote definition changed the UI"; fi
stop_server
launch
if drive logwait "drawing the baked copy ${baked_sha:0:12}" 30 && drive wait 'Fixture sign-in' 20 \
  && ! texts | grep -q 'Remote-only sign-in'; then
  pass "offline cold launch draws the complete bundled sign-in UI despite a valid remote cache"
else bad "offline launch did not stay bundled"; fi
adbs shell "run-as $package sh -c 'echo damaged > files/hey-description/$baked_sha.json'" 2> /dev/null
launch
if drive logwait "drawing the baked copy ${baked_sha:0:12}" 30 && drive wait 'Fixture sign-in' 20; then
  pass "a corrupt legacy cache is never loaded and cannot block the bundled UI"
else bad "a corrupt legacy cache affected startup"; fi
if [ "$(requests GET /v1/app/description)" = 0 ]; then
  pass "sign-in, actions with reload, navigation, sign-out and resume sent zero UI-definition requests"
else bad "some lifecycle or manual reload path requested a UI definition"; fi

# ---- 10. no crash -------------------------------------------------------------------------------------------
adbs logcat -d -b crash > "$work/crash.txt" 2>&1
if ! grep -q "$package" "$work/crash.txt"; then
  pass "the crash buffer names no crash of $package"
else
  bad "the app crashed: $(grep -m3 -A3 "$package" "$work/crash.txt")"
fi

exit "$failed"
