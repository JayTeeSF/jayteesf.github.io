#!/usr/bin/env bash
# The Android pins are written twice: tools/android-pins.env for the tools and
# src/toolchain.hey for Hey callers. They must agree, and no pin from the old
# Gradle lane (API 34, build-tools 34, NDK 26.1, AGP, Gradle, CMake) may remain
# in the code.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
. "$ROOT/tools/android-pins.env"
failed=0

hey_value() { # FILE NAME
  sed -n "s/^[[:space:]]*$2: '\{0,1\}\([^',]*\)'\{0,1\},\{0,1\}[[:space:]]*\$/\1/p" "$1" | sed -n 1p
}
compare_pins() { # FILE; prints mismatches, returns 1 if any
  bad=0
  for pair in compile_sdk=$HEY_ANDROID_COMPILE_SDK target_sdk=$HEY_ANDROID_TARGET_SDK min_sdk=$HEY_ANDROID_MIN_SDK \
      build_tools=$HEY_ANDROID_BUILD_TOOLS ndk=$HEY_ANDROID_NDK target=$HEY_ANDROID_TARGET abi=$HEY_ANDROID_ABI \
      page_size=$HEY_ANDROID_PAGE_SIZE jdk=$HEY_ANDROID_JDK system_image=$HEY_ANDROID_SYSTEM_IMAGE; do
    name=${pair%%=*}
    want=${pair#*=}
    got=$(hey_value "$1" "$name")
    if [ "$got" != "$want" ]; then
      echo "  $name: src/toolchain.hey says '$got', tools/android-pins.env says '$want'"
      bad=1
    fi
  done
  return $bad
}

if compare_pins "$ROOT/src/toolchain.hey"; then
  echo "PASS: src/toolchain.hey and tools/android-pins.env agree on all 10 pins (API $HEY_ANDROID_TARGET_SDK, NDK $HEY_ANDROID_NDK)"
else
  echo 'FAIL: the two pin files disagree'
  failed=1
fi

work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-pins.XXXXXX")
trap 'rm -rf "$work"' EXIT
sed "s/ndk: '$HEY_ANDROID_NDK'/ndk: '26.1.10909125'/" "$ROOT/src/toolchain.hey" > "$work/toolchain.hey"
if compare_pins "$work/toolchain.hey" > "$work/control.txt"; then
  echo 'FAIL (control): a changed NDK pin in src/toolchain.hey was not caught'
  failed=1
else
  echo "PASS (control): a changed pin is caught ($(tr -s ' ' < "$work/control.txt" | sed -n 1p | sed 's/^ //'))"
fi

old=$(cd "$ROOT" && grep -rnE "26\.1\.10909125|34\.0\.0|android-34|Hey_API_34|android_gradle_plugin|gradle|cmake|compileSdk 34" \
  src tools bin/android-doctor native examples 2>/dev/null)
if [ -z "$old" ]; then
  echo 'PASS: no API 34, build-tools 34, NDK 26.1, Gradle, AGP or CMake pin remains in src, tools, bin/android-doctor, native or examples'
else
  echo "FAIL: old pins remain:"
  printf '%s\n' "$old" | sed 's/^/  /'
  failed=1
fi
exit $failed
