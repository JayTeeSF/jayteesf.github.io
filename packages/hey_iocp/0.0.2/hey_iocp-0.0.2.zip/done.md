# Done

- 0.0.1 (EXPERIMENTAL / UNVERIFIED): the I/O completion port loop behind
  hey_epoll's API (zero-byte WSARecv readiness, AcceptEx, overlapped WSASend
  only for what does not fit, GetQueuedCompletionStatusEx batches, zombie
  connections until cancelled operations return). Cross-compiled to a
  windows-x64 DLL from macOS with LLVM and inspected; never run on Windows.
