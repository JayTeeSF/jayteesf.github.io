#include "hey_mysql.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
static HeyNativeUtf8View s(const char *v){return (HeyNativeUtf8View){v,strlen(v)};}
static uint32_t u32(const uint8_t *v){return (uint32_t)v[0]|((uint32_t)v[1]<<8)|((uint32_t)v[2]<<16)|((uint32_t)v[3]<<24);}
int main(void){
const char *host=getenv("HEY_MYSQL_TEST_HOST");
const char *user=getenv("HEY_MYSQL_TEST_USER");
const char *pw=getenv("HEY_MYSQL_TEST_PASSWORD");
const char *database=getenv("HEY_MYSQL_TEST_DATABASE");
const char *port_text=getenv("HEY_MYSQL_TEST_PORT");
if(!host||!user||!pw||!database||!port_text){fputs("Configure HEY_MYSQL_TEST_HOST/PORT/USER/PASSWORD/DATABASE\n",stderr);return 77;}
char *end=NULL;unsigned long port=strtoul(port_text,&end,10);
if(!*port_text||*end||port<1||port>65535)return 77;
HeyNativeHandle c=hey_mysql_init();assert(c);
  assert(hey_mysql_set_ssl_mode(c,s("disabled"))==0);
  assert(hey_mysql_connect(c,s(host),s(user),s(pw),s(database),(uint32_t)port,s(""),0)==0);
  assert(hey_mysql_set_charset(c,s("utf8mb4"))==0);
  assert(hey_mysql_query(c,s("SET SESSION TRANSACTION READ ONLY"))==0);
  assert(hey_mysql_query(c,s("START TRANSACTION READ ONLY"))==0);
  assert(hey_mysql_query(c,s("SELECT NULL, '', CONCAT('a',CHAR(0),'b'), '日本語', 2147483647 UNION ALL SELECT NULL, '', CONCAT('a',CHAR(0),'b'), '日本語', 2147483647"))==0);
  HeyNativeHandle r=hey_mysql_use_result(c);assert(r);
  for(int i=0;i<2;i++){
    HeyNativeOwnedBytes b=hey_mysql_read_batch(r,1,4096,1024);assert(b.data && b.length>12);
    assert(memcmp(b.data,"HYR1",4)==0 && u32(b.data+4)==1 && u32(b.data+8)==5);
    assert(u32(b.data+12)==UINT32_MAX && u32(b.data+16)==0);
    assert(u32(b.data+20)==3 && memcmp(b.data+24,"a\0b",3)==0);
    assert(u32(b.data+27)==9 && memcmp(b.data+31,"日本語",9)==0);
    b.release(b.context,b.data,b.length);
  }
  HeyNativeOwnedBytes end=hey_mysql_read_batch(r,1,4096,1024);assert(end.data && u32(end.data+4)==0);end.release(end.context,end.data,end.length);
  assert(hey_mysql_batch_error(r)==0);assert(hey_mysql_free_result(r)==0);
  assert(hey_mysql_query(c,s("SELECT REPEAT('x',2000)"))==0);r=hey_mysql_use_result(c);assert(r);
  HeyNativeOwnedBytes big=hey_mysql_read_batch(r,1,4096,1024);assert(!big.data && hey_mysql_batch_error(r)==2);assert(hey_mysql_free_result(r)==0);
  assert(hey_mysql_query(c,s("SELECT 1"))==0);r=hey_mysql_use_result(c);assert(r);
  HeyNativeOwnedBytes bad=hey_mysql_read_batch(r,0,4096,1024);assert(!bad.data && hey_mysql_batch_error(r)==1);assert(hey_mysql_free_result(r)==0);
  assert(hey_mysql_rollback(c)==0);assert(hey_mysql_close(c)==0);
  puts("PASS: local read-only stream batches preserve null/empty/NUL/UTF-8, EOF and bounds");return 0;
}
