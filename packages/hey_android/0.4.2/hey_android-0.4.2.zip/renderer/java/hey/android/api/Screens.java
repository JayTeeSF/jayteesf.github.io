package hey.android.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * What a screen draws, as a flat list of elements, with no Android class in
 * it. The Activity turns elements into Views; the host tests read the same
 * list, so "an unknown kind is not drawn" is proved where it is decided.
 *
 * WHAT THIS BUILD DRAWS is a subset of level 1, and everything outside it is
 * treated exactly like an unknown kind: not drawn, and never sent. Level 1's
 * search and audio screens, and its rating, choose, share, copy, video,
 * web_sign_in, document and set_var actions, and choice and rating
 * fields are the next slices (docs/ROADMAP.md).
 */
public final class Screens {
  private Screens() {}

  public static final List<String> DRAWN_SCREEN_TYPES = Arrays.asList("list", "form", "search", "audio");
  public static final List<String> DRAWN_ACTION_KINDS = Arrays.asList("request", "open_screen", "open_url", "video");
  /**
   * The field kinds this build draws: all ten of hey_mobile level 1.
   *
   * <p>"choice" was missing too, and cost far more than itself: the item edit
   * screen marks its Kind field REQUIRED, and a required field that is not
   * drawn sets requiredHidden, which withholds the primary button. So the whole
   * screen had no Save -- typing into the fields that did draw achieved
   * nothing. Reported from a phone as "doesn't even expose the fields I'm
   * supposed to be able to edit".
   */
  public static final List<String> DRAWN_FIELD_KINDS = Arrays.asList("text", "secure", "new_secure", "url", "prose", "multiline", "code", "number", "choice", "rating");

  /** A choice field's options, each {title, value}; empty when it has none to offer. */
  public static List<Map<String, Object>> options(Map<String, Object> field) {
    List<Map<String, Object>> out = new ArrayList<>();
    for (Object o : Json.list(field.get("options"))) {
      Map<String, Object> option = Json.dict(o);
      if (option.isEmpty()) continue;
      out.add(option);
    }
    return out;
  }

  /** What to show for a choice field's current value: its option title, else the value. */
  public static String optionTitle(Map<String, Object> field, String value) {
    for (Map<String, Object> option : options(field)) {
      if (Values.string(option.get("value")).equals(value)) return Values.string(option.get("title"));
    }
    if (value.isEmpty()) return Values.string(field.get("none_title"));
    return value;
  }

  static int level() { return Values.RENDERER_LEVEL; }

  public static boolean drawsScreen(Object screen) {
    return Values.known("screen", screen, level()) && DRAWN_SCREEN_TYPES.contains(Values.string(Json.dict(screen).get("type")));
  }

  public static boolean drawsAction(Object action) {
    if (!Values.known("action", action, level())) return false;
    Map<String, Object> d = Json.dict(action);
    if (!DRAWN_ACTION_KINDS.contains(Values.actionKind(d))) return false;
    if (!Json.dict(d.get("prompt")).isEmpty() && !drawsPrompt(d)) return false;
    if (d.get("then_action") != null && d.get("then_action") != Json.NULL) return drawsAction(d.get("then_action"));
    return true;
  }

  /** A prompt is drawn on a request whose fields all have an id and a kind this build draws; it asks before the request is sent. */
  static boolean drawsPrompt(Map<String, Object> action) {
    if (!Values.actionKind(action).equals("request")) return false;
    List<?> fields = Json.list(Json.dict(action.get("prompt")).get("fields"));
    if (fields.isEmpty()) return false;
    for (Object f : fields) {
      Map<String, Object> field = Json.dict(f);
      String kind = Values.string(field.get("kind"));
      if (Values.string(field.get("id")).isEmpty()) return false;
      if (kind.isEmpty()) continue;
      if (!DRAWN_FIELD_KINDS.contains(kind) || !Values.known("field", field, level())) return false;
    }
    return true;
  }

  public static boolean drawsField(Object field) {
    return Values.known("field", field, level()) && DRAWN_FIELD_KINDS.contains(Values.string(Json.dict(field).get("kind")));
  }

  public static boolean drawsRow(Object row) {
    if (!Values.known("row", row, level())) return false;
    Map<String, Object> d = Json.dict(row);
    if (Values.rowKind(d).equals("action")) return drawsAction(d.get("action"));
    return true;
  }

  public static boolean drawsSection(Object section) {
    return Values.known("section", section, level());
  }

  public enum Kind { HEADER, SECTION_TITLE, ROW, FIELD, BUTTON, NOTE, MESSAGE }

  public static final class Element {
    public final Kind kind;
    public String title = "";
    public String subtitle = "";
    public String body = "";
    public String icon = "";
    /** BUTTON, or a ROW that runs an action. */
    public Map<String, Object> action;
    /** The data row an action or a tap reads (@name, params). */
    public Object row;
    /** A ROW or LINK that opens a screen, with its parameters already read. */
    public String screen;
    public Map<String, Object> params;
    /** A ROW or FIELD that opens an address. */
    public String url;
    /** A ROW that plays a film rather than opening one: see Screens.Kind and the host's playVideo. */
    public String video = "";
    /**
     * A ROW's picture, as an address to fetch; empty when it has none.
     *
     * <p>Fourteen sections of this app's description carry {@code image} on
     * their row, and the build read past every one of them, so a library of
     * videos and shows drew as a wall of words. Reported from a phone as "on my
     * android app I do not see ANY images/videos".
     *
     * <p>It is an ADDRESS and not a picture: whether one is fetched, cached or
     * shown at all is the Activity's business, and the host tests can read this
     * without a network.
     */
    public String image = "";
    public boolean destructive;

    Element(Kind kind) { this.kind = kind; }

    public boolean tappable() { return action != null || screen != null || url != null || !video.isEmpty(); }

    @Override public String toString() { return kind + ":" + title; }
  }

  /** The rows a route section answered with, and what to say under them. */
  public static final class RouteRows {
    public final List<Object> rows;
    public final String footer;
    /**
     * True while the answer says it is STILL LOOKING. A find asks several
     * services at once and answers immediately with what it has, so the first
     * answer is usually empty and correct; a build that treated it as the final
     * word would show "No service this app knows has that title" about a search
     * that had not finished.
     */
    public final boolean pending;
    /** True when the request failed: the footer is the error, and is drawn as one. */
    public final boolean failed;

    public RouteRows(List<Object> rows, String footer) {
      this(rows, footer, false);
    }

    public RouteRows(List<Object> rows, String footer, boolean pending) {
      this(rows, footer, pending, false);
    }

    public RouteRows(List<Object> rows, String footer, boolean pending, boolean failed) {
      this.rows = rows;
      this.footer = footer;
      this.pending = pending;
      this.failed = failed;
    }
  }

  /**
   * A pending section whose polls have run out: what it found so far, said to
   * be unfinished in the section's own gave_up_note.
   *
   * <p>Without this the last pending answer stood for ever, so the screen said
   * it was still looking about a search nobody was asking any more.
   */
  public static RouteRows gaveUp(Map<String, Object> section, RouteRows last) {
    List<Object> rows = last == null ? new ArrayList<>() : last.rows;
    return new RouteRows(rows, Values.string(section.get("gave_up_note")), false);
  }

  /** Where a search screen's query stands: nothing asked, asking, or answered with rows, nothing or an error. */
  public enum SearchState { IDLE, SEARCHING, FOUND, EMPTY, FAILED }

  /**
   * One word for a whole search, from its sections' answers.
   *
   * <p>SEARCHING while any section that asks has no answer yet, or says it is
   * still looking: a section that has not answered is not an empty one, and
   * the first answer of a find is usually empty AND unfinished. FOUND with any
   * row. Otherwise FAILED when any section failed -- an error is never shown as
   * an empty list -- and EMPTY only when every section answered with nothing.
   */
  public static SearchState searchState(Map<String, Object> screen, Object json, String query, Map<Integer, RouteRows> routes) {
    if (query == null || query.isEmpty()) return SearchState.IDLE;
    List<Map<String, Object>> sections = sections(screen);
    boolean rows = false;
    boolean failed = false;
    for (int i = 0; i < sections.size(); i++) {
      if (routeFor(sections.get(i), json) == null) continue;
      RouteRows answered = routes == null ? null : routes.get(i);
      if (answered == null || answered.pending) return SearchState.SEARCHING;
      if (!answered.rows.isEmpty()) rows = true;
      if (answered.failed) failed = true;
    }
    if (rows) return SearchState.FOUND;
    return failed ? SearchState.FAILED : SearchState.EMPTY;
  }

  /** What an empty search says: the screen's own empty text when it has one, else the query named. */
  public static String noResults(Map<String, Object> screen, String query) {
    String said = Values.string(screen.get("empty"));
    return said.isEmpty() ? "No results for “" + query + "”." : said;
  }

  /** Parameters for the screen a tap opens: '$name', '=word', or a path read from the row, then the screen's answer. */
  public static Map<String, Object> params(Object spec, Map<String, Object> vars, Object row, Object json) {
    Map<String, Object> out = new LinkedHashMap<>();
    for (Map.Entry<String, Object> e : Json.dict(spec).entrySet()) out.put(e.getKey(), Values.param(e.getValue(), vars, row, json));
    return out;
  }

  public static List<Map<String, Object>> sections(Map<String, Object> screen) {
    List<Map<String, Object>> out = new ArrayList<>();
    for (Object s : Json.list(screen.get("sections"))) out.add(Json.dict(s));
    return out;
  }

  /** The route to ask for a route section, or null when it asks for nothing (not drawn, or its condition fails). */
  public static Map<String, Object> routeFor(Map<String, Object> section, Object json) {
    if (!drawsSection(section) || !Values.sectionKind(section).equals("route")) return null;
    if (!Values.when(section.get("when"), json)) return null;
    Map<String, Object> route = Json.dict(section.get("source"));
    if (route.isEmpty()) route = Json.dict(section.get("request"));
    return route.isEmpty() ? null : route;
  }

  /** A route section's rows from its answer: the section's list, filtered by where, then grouped. */
  public static RouteRows routeRows(Map<String, Object> section, Object answer, String error) {
    if (error != null) return new RouteRows(new ArrayList<>(), error, false, true);
    List<Object> rows = new ArrayList<>();
    for (Object candidate : Json.list(Values.at(answer, Values.string(section.get("list"))))) {
      if (Values.when(section.get("where"), candidate)) rows.add(candidate);
    }
    rows = group(rows, section);
    boolean pending = pending(section, answer);
    String footer;
    if (pending) {
      footer = Values.string(section.get("pending_note"));
    } else if (rows.isEmpty()) {
      footer = Values.string(section.get("empty"));
    } else {
      footer = Values.string(section.get("note"));
    }
    String incompleteKey = Values.string(section.get("incomplete_key"));
    if (!pending && !incompleteKey.isEmpty() && Values.truthy(Values.at(answer, incompleteKey))) {
      String said = Values.string(section.get("incomplete_note"));
      if (!said.isEmpty()) footer = footer.isEmpty() ? said : footer + " " + said;
    }
    return new RouteRows(rows, footer, pending);
  }

  /** Whether a section's answer says it is still being worked on. */
  public static boolean pending(Map<String, Object> section, Object answer) {
    Map<String, Object> poll = Json.dict(section.get("poll"));
    if (poll.isEmpty()) return false;
    String key = Values.string(poll.get("key"));
    if (key.isEmpty()) return false;
    return Values.string(Values.at(answer, key)).equals(Values.string(poll.get("pending")));
  }

  /** How long to wait before asking a pending section again, and how many times at most. */
  public static int pollEvery(Map<String, Object> section) {
    long ms = Values.integer(Json.dict(section.get("poll")).get("every_ms"));
    return ms > 0 ? (int) ms : 1500;
  }

  public static int pollMax(Map<String, Object> section) {
    long max = Values.integer(Json.dict(section.get("poll")).get("max"));
    return max > 0 ? (int) max : 20;
  }

  /**
   * Rows sharing the section's group_by value become ONE row.
   *
   * <p>A find asks every service it knows and answers one row per service, so
   * a single film comes back four times. The first member is kept (a server
   * that groups orders the best link first) and gains three made-up fields the
   * row spec reads by name:
   *
   * <ul>
   *   <li>{@code _also} -- the other members' labels.
   *   <li>{@code _sources} -- every member, reshaped by group_sources
   *       ({out_key: row_path}), so a body can save them all.
   *   <li>{@code _watch} and {@code _one_label} -- for kinds named by
   *       group_list_when, _watch names EVERY service (with group_notes after
   *       each, "for free" / "to rent or buy") and _one_label is empty; for the
   *       rest it is the other way round.
   * </ul>
   *
   * <p>This knows no field names of its own: every one of them is a path out of
   * the description. Ported from the iOS host, which is where these names are
   * defined -- this app's "Where to find it" is written against that behaviour
   * and a second guess at it would be a different screen wearing the same name.
   */
  public static List<Object> group(List<Object> rows, Map<String, Object> spec) {
    String key = Values.string(spec.get("group_by"));
    if (key.isEmpty()) return rows;
    String labelPath = Values.string(spec.get("group_label"));
    Map<String, Object> sourceMap = Json.dict(spec.get("group_sources"));
    Map<String, Object> listWhen = Json.dict(spec.get("group_list_when"));
    Map<String, Object> notes = Json.dict(spec.get("group_notes"));
    String noteField = Values.string(spec.get("group_note_field"));
    String anyTrue = Values.string(spec.get("group_any_true"));
    List<Object> carry = Json.list(spec.get("group_any_carry"));

    List<String> order = new ArrayList<>();
    Map<String, List<Map<String, Object>>> groups = new LinkedHashMap<>();
    for (Object candidate : rows) {
      Map<String, Object> row = Json.dict(candidate);
      String value = Values.string(Values.at(row, key));
      if (value.isEmpty()) value = "row-" + order.size();
      if (!groups.containsKey(value)) {
        groups.put(value, new ArrayList<>());
        order.add(value);
      }
      groups.get(value).add(row);
    }

    List<Object> out = new ArrayList<>();
    for (String value : order) {
      List<Map<String, Object>> members = groups.get(value);
      Map<String, Object> first = new LinkedHashMap<>(members.get(0));
      List<String> also = new ArrayList<>();
      List<Object> sources = new ArrayList<>();
      for (int i = 0; i < members.size(); i++) {
        Map<String, Object> member = members.get(i);
        if (!sourceMap.isEmpty()) {
          Map<String, Object> source = new LinkedHashMap<>();
          for (Map.Entry<String, Object> e : sourceMap.entrySet()) {
            String v = Values.string(Values.at(member, Values.string(e.getValue())));
            if (!v.isEmpty()) source.put(e.getKey(), v);
          }
          // All of them or none: half a source is a link with no service on it.
          if (source.size() == sourceMap.size()) sources.add(source);
        }
        String label = Values.string(Values.at(member, labelPath));
        if (i > 0 && !label.isEmpty() && !also.contains(label)) also.add(label);
      }
      first.put("_also", String.join(", ", also));
      first.put("_sources", sources);
      boolean listed = !listWhen.isEmpty()
          && Json.list(listWhen.get("values")).contains(Values.string(Values.at(first, Values.string(listWhen.get("field")))));
      if (listed) {
        List<String> watch = new ArrayList<>();
        for (Map<String, Object> member : members) {
          String label = Values.string(Values.at(member, labelPath));
          if (label.isEmpty()) continue;
          String note = Values.string(notes.get(Values.string(Values.at(member, noteField))));
          String entry = note.isEmpty() ? label : label + " " + note;
          if (!watch.contains(entry)) watch.add(entry);
        }
        first.put("_watch", String.join(", ", watch));
        first.put("_one_label", "");
      } else {
        first.put("_watch", "");
        first.put("_one_label", Values.string(Values.at(first, labelPath)));
      }
      if (!anyTrue.isEmpty()) {
        for (Map<String, Object> member : members) {
          if (Values.truthy(member.get(anyTrue))) {
            first.put(anyTrue, Boolean.TRUE);
            for (Object field : carry) {
              String name = Values.string(field);
              Object held = member.get(name);
              first.put(name, held == null ? "" : held);
            }
            break;
          }
        }
      }
      out.add(first);
    }
    return out;
  }

  /** The header of a list screen with a source, and the error it answered with. */
  static Element header(Map<String, Object> screen, Object json, String message, Map<String, Object> labels) {
    Map<String, Object> header = Json.dict(screen.get("header"));
    Element e = new Element(Kind.HEADER);
    e.title = json != null ? Values.line(header.get("title"), json, labels) : (message == null ? "" : message);
    if (e.title.isEmpty() && !Values.string(header.get("title_text")).isEmpty()) e.title = Values.text(header.get("title_text"), json, labels);
    e.subtitle = Values.line(header.get("subtitle"), json, labels);
    e.body = Values.line(header.get("body"), json, labels);
    if (e.body.isEmpty() && !Values.string(header.get("body_text")).isEmpty()) e.body = Values.text(header.get("body_text"), json, labels);
    // THE PICTURE AT THE TOP OF A THING'S OWN SCREEN. Read past until now, so
    // an item screen showed the words and dropped the poster -- reported from a
    // phone: "why doesn't the android app show the image of the media on the
    // screen where I dig into the link? On the apple ios app it does".
    e.image = Values.line(header.get("image"), json, labels);
    return e;
  }

  /**
   * A list screen: its header, then each section that is drawn and whose
   * condition holds, with rows, fields, buttons and notes. `routes` holds the
   * rows each route section answered with, by section index.
   */
  public static List<Element> list(Map<String, Object> screen, Object json, String message, Map<Integer, RouteRows> routes,
                                   Map<String, Object> vars, Map<String, Object> labels) {
    List<Element> out = new ArrayList<>();
    if (!Json.dict(screen.get("header")).isEmpty() || message != null) {
      Element h = header(screen, json, message, labels);
      if (!h.title.isEmpty() || !h.subtitle.isEmpty() || !h.body.isEmpty()) out.add(h);
    }
    if (message != null && json != null) {
      Element m = new Element(Kind.MESSAGE);
      m.title = message;
      out.add(m);
    }
    List<Map<String, Object>> sections = sections(screen);
    for (int index = 0; index < sections.size(); index++) {
      Map<String, Object> spec = sections.get(index);
      if (!drawsSection(spec)) continue;
      if (!Values.when(spec.get("when"), json)) continue;
      String kind = Values.sectionKind(spec);
      List<Element> rows = new ArrayList<>();
      String footer;
      boolean failed = false;
      switch (kind) {
        case "fields":
          for (Object f : Json.list(spec.get("fields"))) {
            Map<String, Object> field = Json.dict(f);
            if (!Values.when(field.get("when"), json)) continue;
            String value = Values.line(field.get("value"), json, labels);
            if (value.isEmpty()) continue;
            Element e = new Element(Kind.FIELD);
            e.title = Values.string(field.get("label"));
            e.subtitle = value;
            if (Values.truthy(field.get("open_url"))) e.url = value;
            rows.add(e);
          }
          footer = rows.isEmpty() ? Values.string(spec.get("empty")) : Values.string(spec.get("note"));
          break;
        case "actions":
          for (Object a : Json.list(spec.get("actions"))) {
            Map<String, Object> action = Json.dict(a);
            if (!drawsAction(action) || !Values.when(action.get("when"), json)) continue;
            Element e = new Element(Kind.BUTTON);
            e.title = Values.text(action.get("title"), json, labels);
            e.subtitle = Values.text(action.get("subtitle"), json, labels);
            e.icon = Names.materialSymbol(firstIcon(action));
            e.destructive = "destructive".equals(action.get("style"));
            e.action = action;
            rows.add(e);
          }
          footer = rows.isEmpty() ? Values.string(spec.get("empty")) : Values.string(spec.get("note"));
          break;
        case "rows":
          for (Object r : Json.list(spec.get("rows"))) {
            Map<String, Object> row = Json.dict(r);
            if (!drawsRow(row) || !Values.when(row.get("when"), json)) continue;
            Element e = new Element(Kind.ROW);
            e.title = Values.text(row.get("title"), json, labels);
            e.subtitle = Values.text(row.get("subtitle"), json, labels);
            e.icon = Names.materialSymbol(firstIcon(row));
            if (!Json.dict(row.get("action")).isEmpty()) {
              e.action = Json.dict(row.get("action"));
            } else if (!Values.string(row.get("screen")).isEmpty()) {
              e.screen = Values.string(row.get("screen"));
              e.params = params(row.get("params"), vars, null, json);
            }
            rows.add(e);
          }
          footer = rows.isEmpty() ? Values.string(spec.get("empty")) : Values.string(spec.get("note"));
          break;
        default: {
          List<Object> data;
          if (kind.equals("from")) {
            data = new ArrayList<>();
            for (Object candidate : Json.list(Values.at(json, Values.string(spec.get("from"))))) {
              if (Values.when(spec.get("where"), candidate)) data.add(candidate);
            }
            footer = data.isEmpty() ? Values.string(spec.get("empty")) : Values.string(spec.get("note"));
          } else {
            RouteRows answered = routes == null ? null : routes.get(index);
            if (answered == null) {
              data = new ArrayList<>();
              footer = "";
            } else {
              data = answered.rows;
              footer = answered.footer;
              failed = answered.failed;
            }
          }
          Map<String, Object> rowSpec = Json.dict(spec.get("row"));
          Map<String, Object> select = Json.dict(spec.get("select"));
          for (Object item : data) {
            Element e = new Element(Kind.ROW);
            e.row = item;
            e.title = Values.line(rowSpec.get("title"), item, labels);
            String subtitle = Values.line(rowSpec.get("subtitle"), item, labels);
            String detail = Values.line(rowSpec.get("detail"), item, labels);
            e.subtitle = subtitle;
            e.body = detail;
            e.icon = Names.materialSymbol(symbolFor(rowSpec, item));
            e.image = Values.line(rowSpec.get("image"), item, labels);
            if (!select.isEmpty() && Values.when(select.get("when"), item)) {
              Map<String, Object> selectAction = Json.dict(select.get("action"));
              if (!selectAction.isEmpty()) {
                if (drawsAction(selectAction)) e.action = selectAction;
              } else if (!Values.string(select.get("video")).isEmpty()) {
                e.video = Values.line(select.get("video"), item, labels);
              } else if (!Values.string(select.get("open_url")).isEmpty()) {
                e.url = Values.line(select.get("open_url"), item, labels);
              } else if (!Values.string(select.get("screen")).isEmpty()) {
                e.screen = Values.string(select.get("screen"));
                e.params = params(select.get("params"), vars, item, json);
              }
            }
            rows.add(e);
          }
          break;
        }
      }
      if (rows.isEmpty() && Values.truthy(spec.get("hide_when_empty"))) continue;
      String title = Values.text(spec.get("title"), json, labels);
      if (!title.isEmpty()) {
        Element t = new Element(Kind.SECTION_TITLE);
        t.title = title;
        out.add(t);
      }
      out.addAll(rows);
      if (!footer.isEmpty()) {
        Element n = new Element(Kind.NOTE);
        n.title = footer;
        // A failed request's note is its error, drawn as one, not as small print.
        n.destructive = failed;
        out.add(n);
      }
    }
    return out;
  }

  // ---- the audio feed (the Listen tab, and what a car would be handed) ---------
  //
  // AN AUDIO SCREEN HAS NO SECTIONS OF ITS OWN. The screen in the description
  // carries only a title and a tab; everything it shows comes from the
  // description's top-level `audio` block, which names one source and the
  // lists inside that one answer. The server decides what may be on it -- one
  // place, shared with whatever a car is handed -- so this never asks what is
  // worth playing, only what it is able to play.
  //
  // WHAT "PLAYABLE" MEANS HERE, and why it is narrower than on the iPhone: a
  // row plays if its audio_url is an ordinary web address. The iPhone can also
  // play an Apple Music id through a subscription; this build cannot, so a row
  // that REQUIRES one is drawn and not offered rather than quietly dropped --
  // it is in the listener's queue either way, and a row that vanishes is a bug
  // report waiting to happen.

  /** One thing to play: its addresses, where the listener stopped, and what to say about it. */
  public static final class Track {
    public String id = "";
    public String title = "";
    public String subtitle = "";
    public String image = "";
    public String kind = "";
    public String requires = "";
    public String appleMusicId = "";
    /** The audio addresses in order. A narrated article has one per page; everything else has one. */
    public final List<String> pages = new ArrayList<>();
    public int positionSeconds;
    public int positionPage;
    /** False for a row this build cannot play, and for a row that is only waiting to exist. */
    public boolean playable;
    /** True for a row that is not a thing to play but a note that one is coming. */
    public boolean waiting;

    public String address() { return pages.isEmpty() ? "" : pages.get(0); }
  }

  public static final class AudioSection {
    public String title = "";
    public String note = "";
    public final List<Track> tracks = new ArrayList<>();
  }

  static boolean webAddress(String url) {
    return url.startsWith("https://") || url.startsWith("http://");
  }

  /**
   * One row of the audio feed.
   *
   * <p>subtitle_when names a field: when the row has it, subtitle is used (an
   * episode reads its show, date and length), and when it does not,
   * subtitle_else is (anything else reads what it is).
   */
  public static Track track(Map<String, Object> spec, Object raw, Map<String, Object> labels) {
    Track t = new Track();
    t.id = Values.line(spec.get("id"), raw, labels);
    t.title = Values.line(spec.get("title"), raw, labels);
    Object subtitle = spec.get("subtitle");
    String when = Values.string(spec.get("subtitle_when"));
    if (!when.isEmpty() && Values.string(Values.at(raw, when)).isEmpty()) subtitle = spec.get("subtitle_else");
    t.subtitle = Values.line(subtitle, raw, labels);
    t.image = Values.line(spec.get("image_url"), raw, labels);
    t.kind = Values.line(spec.get("kind"), raw, labels);
    t.requires = Values.line(spec.get("requires"), raw, labels);
    t.appleMusicId = Values.line(spec.get("apple_music_id"), raw, labels);
    for (Object url : Json.list(Values.at(raw, Values.string(spec.get("audio_urls"))))) {
      String one = Values.string(url);
      if (!one.isEmpty()) t.pages.add(one);
    }
    String single = Values.line(spec.get("audio_url"), raw, labels);
    if (t.pages.isEmpty() && !single.isEmpty()) t.pages.add(single);
    t.positionSeconds = (int) Values.integer(Values.at(raw, Values.string(spec.get("position_seconds"))));
    t.positionPage = (int) Values.integer(Values.at(raw, Values.string(spec.get("position_page"))));
    t.playable = !t.requires.equals("apple_music_subscription") && webAddress(t.address());
    return t;
  }

  /** The feed, section by section, from the one answer its source gave. */
  public static List<AudioSection> audio(Map<String, Object> spec, Object json, Map<String, Object> labels) {
    List<AudioSection> out = new ArrayList<>();
    Map<String, Object> rowSpec = Json.dict(spec.get("row"));
    for (Object o : Json.list(spec.get("sections"))) {
      Map<String, Object> section = Json.dict(o);
      List<?> rows = Json.list(Values.at(json, Values.string(section.get("list"))));
      if (rows.isEmpty() && Values.truthy(section.get("hide_when_empty"))) continue;
      AudioSection out_section = new AudioSection();
      out_section.title = Values.string(section.get("title"));
      out_section.note = rows.isEmpty() ? Values.string(section.get("empty_note")) : Values.string(section.get("note"));
      boolean waiting = Values.truthy(section.get("waiting"));
      for (Object r : rows) {
        Track t;
        if (waiting) {
          // NOT A THING TO PLAY: a podcast whose episodes are still being
          // found. It has no address and never will under this id.
          t = new Track();
          t.title = Values.line(section.get("waiting_title"), r, labels);
          t.subtitle = Values.line(section.get("waiting_subtitle"), r, labels);
          t.waiting = true;
        } else {
          t = track(rowSpec, r, labels);
        }
        out_section.tracks.add(t);
      }
      out.add(out_section);
    }
    return out;
  }

  /** True when the whole feed has nothing in it, which is a different screen. */
  public static boolean audioEmpty(List<AudioSection> sections) {
    for (AudioSection s : sections) {
      if (!s.tracks.isEmpty()) return false;
    }
    return true;
  }

  /** How often to tell the server where the listener got to, in seconds. */
  public static int reportEvery(Map<String, Object> spec) {
    long n = Values.integer(spec.get("report_every_seconds"));
    return n > 0 ? (int) n : 15;
  }

  /**
   * A length of time said the way a listener reads one: 4:05, or 1:37:12 once
   * it runs past an hour. Seconds always two digits, minutes two digits only
   * when there are hours in front of them, so the numbers line up as they
   * climb.
   */
  public static String clock(int seconds) {
    int left = Math.max(0, seconds);
    int hours = left / 3600;
    int minutes = (left % 3600) / 60;
    int secs = left % 60;
    if (hours > 0) return hours + ":" + two(minutes) + ":" + two(secs);
    return minutes + ":" + two(secs);
  }

  private static String two(int n) {
    return n < 10 ? "0" + n : "" + n;
  }

  /** "4:05 of 1:37:12", or just the elapsed time when the end is not known. */
  public static String elapsed(int seconds, int duration) {
    if (duration <= 0) return clock(seconds);
    return clock(seconds) + " of " + clock(duration);
  }

  /**
   * How far a skip moves, in seconds: back a little, forward rather more.
   *
   * <p>These are the only two numbers in this renderer that the description
   * does not supply, and they are here rather than in the drawing code so both
   * a screen and a car use the same jump. Fifteen back and thirty on is what a
   * listener already expects of anything that plays spoken audio -- back to
   * catch a sentence, on to clear a break.
   */
  public static int skipBack() { return -15; }

  public static int skipOn() { return 30; }

  public static String says(Map<String, Object> spec, String key) {
    return Values.string(Json.dict(spec.get("strings")).get(key));
  }

  // ---- a rating, in half stars ------------------------------------------------
  //
  // ZERO TO TEN, five stars, and a tap on the left half of one is worth a half.
  // The scale is the description's, not this file's: every list already shows a
  // saved rating through {stars:...} (Values.stars), and this is the same five
  // glyphs made answerable.

  /**
   * How full star `index` (1..5) is at this many halves: 2 whole, 1 half, 0 empty.
   *
   * <p>A NUMBER RATHER THAN A GLYPH, because there is no half-star character
   * that every device has -- U+2BEA draws as a tofu box on a Nexus 5X. The
   * screen shows a half by drawing a whole star faintly, which needs no font at
   * all, and the host tests can still read the state as a number.
   */
  public static int starState(int index, long halves) {
    if (index * 2 <= halves) return 2;
    if (index * 2 == halves + 1) return 1;
    return 0;
  }

  /**
   * What a tap on star `index` means, in halves.
   *
   * <p>TAPPING WHAT IS ALREADY THERE CLEARS IT, which is the only way to take a
   * rating off from a screen made of five stars -- without it, nothing below
   * one half can ever be said again.
   */
  public static long ratingFromTap(int index, boolean leftHalf, long current) {
    long asked = leftHalf ? (index * 2L - 1) : (index * 2L);
    return asked == current ? 0 : asked;
  }

  static String firstIcon(Map<String, Object> spec) {
    for (String key : new String[] {"icon", "system_image", "symbol"}) {
      String v = Values.string(spec.get(key));
      if (!v.isEmpty()) return v;
    }
    return "";
  }

  static String symbolFor(Map<String, Object> rowSpec, Object row) {
    String by = Values.string(rowSpec.get("icon_by"));
    Map<String, Object> table = Json.dict(rowSpec.get("icons"));
    if (by.isEmpty()) {
      by = Values.string(rowSpec.get("symbol_by"));
      table = Json.dict(rowSpec.get("symbols"));
    }
    if (!by.isEmpty()) {
      String named = Values.string(table.get(Values.string(Values.at(row, by))));
      if (!named.isEmpty()) return named;
    }
    return firstIcon(rowSpec);
  }

  // ---- forms --------------------------------------------------------------------------------

  public static final class Form {
    public final List<Map<String, Object>> fields = new ArrayList<>();
    public final List<Element> links = new ArrayList<>();
    /** False when a required field is not drawn: a request missing it is never sent. */
    public boolean primaryDrawn;
    public String primaryTitle = "";
    public String busyTitle = "";
    public String header = "";
    public String footer = "";
    public String linksFooter = "";
  }

  /**
   * Where a form's starting values come from, and which field each one fills.
   *
   * <p>A form screen that EDITS something has to arrive carrying what is already
   * there. Two shapes are in use and both are answered here: {@code source} and
   * {@code values} at the screen's top level (the item edit screen), and a
   * {@code prefill} object holding the same two keys (the scout's terms screen).
   * Neither was read at all, so every edit screen on Android opened blank and
   * offered to replace a title with nothing.
   */
  public static Map<String, Object> prefillSource(Map<String, Object> screen) {
    Map<String, Object> nested = Json.dict(Json.dict(screen.get("prefill")).get("source"));
    if (!nested.isEmpty()) return nested;
    return Json.dict(screen.get("source"));
  }

  /** field id -> the path in the answer that fills it. */
  public static Map<String, Object> prefillPaths(Map<String, Object> screen) {
    Map<String, Object> nested = Json.dict(Json.dict(screen.get("prefill")).get("values"));
    if (!nested.isEmpty()) return nested;
    return Json.dict(screen.get("values"));
  }

  /**
   * The starting text for each drawn field, read out of the answer.
   *
   * <p>Only fields this build DRAWS are filled: a value collected for a field
   * nobody can see would be posted back silently, which is the one thing the
   * hidden-kind rule exists to prevent.
   */
  public static Map<String, String> prefilled(Map<String, Object> screen, Object json) {
    Map<String, String> out = new LinkedHashMap<>();
    if (json == null) return out;
    Map<String, Object> paths = prefillPaths(screen);
    if (paths.isEmpty()) return out;
    for (Object o : Json.list(screen.get("fields"))) {
      Map<String, Object> field = Json.dict(o);
      String id = Values.string(field.get("id"));
      if (id.isEmpty() || !drawsField(field)) continue;
      Object path = paths.get(id);
      if (path == null) continue;
      String text = Values.string(Values.value("@" + Values.string(path), null, json));
      if (!text.isEmpty()) out.put(id, text);
    }
    return out;
  }

  public static Form form(Map<String, Object> screen, Map<String, Object> vars) {
    Form f = new Form();
    boolean requiredHidden = false;
    for (Object o : Json.list(screen.get("fields"))) {
      Map<String, Object> field = Json.dict(o);
      if (drawsField(field)) f.fields.add(field);
      else if (Values.truthy(field.get("required"))) requiredHidden = true;
    }
    Map<String, Object> primary = Json.dict(screen.get("primary"));
    boolean routes = !Json.dict(primary.get("request")).isEmpty() || !Json.list(primary.get("requests")).isEmpty();
    f.primaryDrawn = routes && !requiredHidden;
    f.primaryTitle = Values.string(primary.get("title"));
    f.busyTitle = Values.string(primary.get("busy_title"));
    f.header = Values.string(screen.get("header"));
    f.footer = Values.string(screen.get("footer"));
    f.linksFooter = Values.string(screen.get("links_footer"));
    for (Object o : Json.list(screen.get("links"))) {
      Map<String, Object> link = Json.dict(o);
      if (!drawsRow(link)) continue;
      Element e = new Element(Kind.ROW);
      e.title = Values.string(link.get("title"));
      e.icon = Names.materialSymbol(firstIcon(link));
      if (!Json.dict(link.get("action")).isEmpty()) {
        e.action = Json.dict(link.get("action"));
      } else if (!Values.string(link.get("screen")).isEmpty()) {
        e.screen = Values.string(link.get("screen"));
        e.params = params(link.get("params"), vars, null, null);
      } else {
        continue;
      }
      f.links.add(e);
    }
    return f;
  }

  /** What stops a form being sent: a required field left empty, or two that must match and differ. null when none. */
  public static String problem(Map<String, Object> screen, Form form, Map<String, Object> values) {
    for (Map<String, Object> field : form.fields) {
      if (Values.truthy(field.get("required")) && Values.string(values.get(Values.string(field.get("id")))).isEmpty()) {
        // {label} is the field's label (level 1 wrote %@). Never a format string.
        String said = Values.string(screen.get("missing"));
        if (said.isEmpty()) said = "{label} is needed.";
        String label = Values.string(field.get("label"));
        return said.replace("{label}", label).replace("%@", label);
      }
    }
    for (Map<String, Object> field : form.fields) {
      String same = Values.string(field.get("same_as"));
      if (!same.isEmpty() && !Values.string(values.get(Values.string(field.get("id")))).equals(Values.string(values.get(same)))) {
        String differs = Values.string(field.get("differs"));
        return differs.isEmpty() ? "The two entries differ." : differs;
      }
    }
    return null;
  }

  /** The requests a form's primary button sends, in order; one with skip_empty is left out when that field is empty. */
  public static List<Map<String, Object>> requests(Map<String, Object> screen, Map<String, Object> values) {
    Map<String, Object> primary = Json.dict(screen.get("primary"));
    List<Object> listed = Json.list(primary.get("requests"));
    if (listed.isEmpty()) listed = Arrays.<Object>asList(Json.dict(primary.get("request")));
    List<Map<String, Object>> out = new ArrayList<>();
    for (Object o : listed) {
      Map<String, Object> route = Json.dict(o);
      String skip = Values.string(route.get("skip_empty"));
      if (!skip.isEmpty() && Values.string(values.get(skip)).isEmpty()) continue;
      out.add(route);
    }
    return out;
  }
}
