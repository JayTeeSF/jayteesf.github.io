#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log.h"
#include "test_barrier.h"
#include "test_hooks.h"

#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
  int count;
  uint64_t expected_sequence;
  int invalid;
} scan_state;

/* nanosleep rather than usleep: usleep is not declared under _POSIX_C_SOURCE
   200809L on glibc, and this gate must build identically on both platforms. */
static void pause_microseconds(long long microseconds) {
  struct timespec pause;
  pause.tv_sec = (time_t)(microseconds / 1000000);
  pause.tv_nsec = (long)((microseconds % 1000000) * 1000);
  (void)nanosleep(&pause, NULL);
}

static void fail(const char *message) {
  fprintf(stderr, "FAIL: %s\n", message);
  exit(1);
}

static void require_status(hdl_status actual, hdl_status expected, const char *context) {
  if (actual != expected) {
    fprintf(stderr, "FAIL: %s: expected %s, got %s\n", context,
            hdl_status_name(expected), hdl_status_name(actual));
    exit(1);
  }
}

static int collect(void *opaque, uint64_t sequence, uint64_t batch_id,
                   uint64_t stream_id, const void *payload, uint32_t payload_length) {
  scan_state *state = opaque;
  if (sequence != state->expected_sequence || batch_id == 0 || stream_id == 0 ||
      payload == NULL || payload_length == 0) state->invalid = 1;
  state->expected_sequence++;
  state->count++;
  return 0;
}

static char *temporary_path(const char *label) {
  size_t length = strlen(label) + 32;
  char *path = malloc(length);
  if (path == NULL) fail("allocate temporary path");
  snprintf(path, length, "/tmp/hdl-%s-XXXXXX", label);
  int fd = mkstemp(path);
  if (fd < 0) fail("mkstemp");
  close(fd);
  unlink(path);
  return path;
}

static off_t file_size(const char *path) {
  struct stat value;
  if (stat(path, &value) != 0) fail("stat");
  return value.st_size;
}

static void copy_prefix(const char *source, const char *target, off_t length) {
  int input = open(source, O_RDONLY);
  int output = open(target, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (input < 0 || output < 0) fail("open copy");
  unsigned char buffer[4096];
  off_t copied = 0;
  while (copied < length) {
    size_t wanted = (size_t)(length - copied);
    if (wanted > sizeof(buffer)) wanted = sizeof(buffer);
    ssize_t got = read(input, buffer, wanted);
    if (got <= 0) fail("read copy");
    size_t written = 0;
    while (written < (size_t)got) {
      ssize_t count = write(output, buffer + written, (size_t)got - written);
      if (count <= 0) fail("write copy");
      written += (size_t)count;
    }
    copied += got;
  }
  close(input);
  close(output);
}


typedef struct {
  uint64_t index;
  uint64_t base_position;
  off_t size;
} hdl_segment_view;

/* The published set, in index order, read the way recovery reads it: only names
   of the exact published form count. */
static size_t published_segments(const char *directory, hdl_segment_view *out, size_t limit) {
  DIR *handle = opendir(directory);
  if (handle == NULL) fail("open journal directory");
  size_t count = 0;
  struct dirent *entry;
  while ((entry = readdir(handle)) != NULL) {
    unsigned long long index = 0;
    unsigned long long base = 0;
    char suffix[8] = {0};
    if (strlen(entry->d_name) != 37) continue;
    if (sscanf(entry->d_name, "%16llx-%16llx%4s", &index, &base, suffix) != 3) continue;
    if (strcmp(suffix, ".seg") != 0) continue;
    if (count == limit) fail("too many segments for this gate");
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", directory, entry->d_name);
    out[count++] = (hdl_segment_view){index, base, file_size(path)};
  }
  closedir(handle);
  for (size_t outer = 1; outer < count; outer++) {
    hdl_segment_view moving = out[outer];
    size_t inner = outer;
    while (inner > 0 && out[inner - 1].index > moving.index) {
      out[inner] = out[inner - 1];
      inner--;
    }
    out[inner] = moving;
  }
  return count;
}

static void journal_segment_path_at(const char *directory, uint64_t index,
                                    uint64_t base_position, char *out, size_t size) {
  snprintf(out, size, "%s/%016llx-%016llx.seg", directory,
           (unsigned long long)index, (unsigned long long)base_position);
}

static void journal_segment_path(const char *directory, char *out, size_t size) {
  journal_segment_path_at(directory, 0, 0, out, size);
}

static void make_journal_directory(const char *directory) {
  if (mkdir(directory, 0700) != 0) fail("create journal directory");
}

static void remove_journal(const char *directory) {
  DIR *handle = opendir(directory);
  if (handle == NULL) return;
  struct dirent *entry;
  while ((entry = readdir(handle)) != NULL) {
    if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", directory, entry->d_name);
    unlink(path);
  }
  closedir(handle);
  rmdir(directory);
}

static void append_range(const char *source, const char *target, off_t from, off_t to) {
  int input = open(source, O_RDONLY);
  int output = open(target, O_WRONLY | O_APPEND);
  if (input < 0 || output < 0) fail("open append range");
  unsigned char buffer[4096];
  off_t position = from;
  while (position < to) {
    size_t wanted = (size_t)(to - position);
    if (wanted > sizeof(buffer)) wanted = sizeof(buffer);
    ssize_t got = pread(input, buffer, wanted, position);
    if (got <= 0) fail("read append range");
    size_t written = 0;
    while (written < (size_t)got) {
      ssize_t count = write(output, buffer + written, (size_t)got - written);
      if (count <= 0) fail("write append range");
      written += (size_t)count;
    }
    position += got;
  }
  close(input);
  close(output);
}

static void basic_and_torn_tail_test(void) {
  char *source = temporary_path("source");
  hdl_log *log = NULL;
  require_status(hdl_open(source, NULL, &log), HDL_OK, "open source");
  const char *first_payloads[] = {"one", "two", "three"};
  hdl_record first[3];
  for (int index = 0; index < 3; index++) {
    first[index] = (hdl_record){11, first_payloads[index], (uint32_t)strlen(first_payloads[index])};
  }
  hdl_receipt first_receipt;
  require_status(hdl_append_batch(log, first, 3, &first_receipt), HDL_OK, "first batch");
  const char *second_payloads[] = {"four", "five"};
  hdl_record second[2];
  for (int index = 0; index < 2; index++) {
    second[index] = (hdl_record){22, second_payloads[index], (uint32_t)strlen(second_payloads[index])};
  }
  hdl_receipt second_receipt;
  require_status(hdl_append_batch(log, second, 2, &second_receipt), HDL_OK, "second batch");
  if (first_receipt.last_sequence != 3 || second_receipt.last_sequence != 5) fail("receipt sequences");

  hdl_cursor *cursor = NULL;
  require_status(hdl_cursor_open(log, &cursor), HDL_OK, "open replay cursor");
  for (uint64_t expected = 1; expected <= 5; expected++) {
    hdl_cursor_record replayed;
    require_status(hdl_cursor_next(cursor, &replayed), HDL_OK, "read replay cursor");
    if (replayed.sequence != expected || replayed.batch_id != (expected <= 3 ? 1 : 2) ||
        replayed.stream_id != (expected <= 3 ? 11 : 22) || replayed.payload_length == 0) {
      fail("replay cursor record");
    }
  }
  hdl_cursor_record finished;
  require_status(hdl_cursor_next(cursor, &finished), HDL_DONE, "finish replay cursor");
  require_status(hdl_cursor_close(cursor), HDL_OK, "close replay cursor");
  require_status(hdl_close(log), HDL_OK, "close source");

  char source_segment[1024];
  journal_segment_path(source, source_segment, sizeof(source_segment));
  off_t total = file_size(source_segment);
  for (off_t cut = 64; cut <= total; cut++) {
    char *candidate = temporary_path("cut");
    char candidate_segment[1024];
    make_journal_directory(candidate);
    journal_segment_path(candidate, candidate_segment, sizeof(candidate_segment));
    copy_prefix(source_segment, candidate_segment, cut);
    require_status(hdl_open(candidate, NULL, &log), HDL_OK, "recover truncated tail");
    scan_state state = {0, 1, 0};
    require_status(hdl_scan(log, collect, &state), HDL_OK, "scan recovered tail");
    int expected = cut >= (off_t)second_receipt.durable_offset ? 5
                 : cut >= (off_t)first_receipt.durable_offset ? 3 : 0;
    if (state.invalid || state.count != expected) fail("torn-tail committed prefix");
    require_status(hdl_close(log), HDL_OK, "close recovered tail");
    remove_journal(candidate);
    free(candidate);
  }
  remove_journal(source);
  free(source);
}

/* A recycled segment file still holds the frames of its previous life.
 *
 * Segment rotation is about to make that the normal case: a segment is renamed
 * and reused rather than zeroed, exactly as PostgreSQL recycles WAL files, so
 * the file legitimately contains complete, correctly-checksummed frames that
 * belong to an EARLIER position in the log. The v1 frame header chains the
 * previous frame's CRC, which is position-INDEPENDENT: a frame carrying the
 * right previous-CRC validates wherever it physically sits. Tom Lane, on
 * pgsql-hackers 2018-01-12: "recognizing that the new record has an old
 * xl_prev is our ONLY defense against replaying stale data."
 *
 * The scenario below is the one that actually happens, not a contrived splice.
 * A crash truncates the log to its last commit; the workload retries the same
 * mutations; the re-written bytes are therefore IDENTICAL, so the CRC chain
 * runs straight off the end of the new writes and into the stale frames of the
 * previous life -- whose sequence and batch numbering continue perfectly,
 * because the previous life numbered them the same way. Nothing in a v1 frame
 * says which life it belongs to.
 *
 * The invariant: recovery replays a frame only at the log position that frame
 * was written for. Stale frames are corruption, and corruption fails closed --
 * they are never silently published as committed data. */
static void stale_frames_from_a_recycled_segment_test(void) {
  const char *payloads[] = {"alpha", "beta"};
  hdl_record batch[2];
  for (int index = 0; index < 2; index++) {
    batch[index] = (hdl_record){5, payloads[index], (uint32_t)strlen(payloads[index])};
  }
  const char *stale_payloads[] = {"gamma", "delta"};
  hdl_record stale[2];
  for (int index = 0; index < 2; index++) {
    stale[index] = (hdl_record){6, stale_payloads[index], (uint32_t)strlen(stale_payloads[index])};
  }

  /* The file's first life: a segment at the very start of the log. */
  char *first_life = temporary_path("recycled-first-life");
  hdl_log *log = NULL;
  hdl_options first_options = {1, 0, 0, 0, 0};
  require_status(hdl_open(first_life, &first_options, &log), HDL_OK, "open first life");
  hdl_receipt first_receipt;
  require_status(hdl_append_batch(log, batch, 2, &first_receipt), HDL_OK, "first life batch one");
  require_status(hdl_append_batch(log, stale, 2, NULL), HDL_OK, "first life batch two");
  require_status(hdl_close(log), HDL_OK, "close first life");

  /* The file's second life: the same bytes recycled into a LATER position in
     the log, which is what rotation will do. It re-writes batch one -- the
     retry after a crash -- and then stops. */
  char *second_life = temporary_path("recycled-second-life");
  hdl_options second_options = {2, 1u << 20, 0, 0, 0};
  require_status(hdl_open(second_life, &second_options, &log), HDL_OK, "open second life");
  require_status(hdl_append_batch(log, batch, 2, NULL), HDL_OK, "second life batch one");
  require_status(hdl_close(log), HDL_OK, "close second life");

  /* Recycling leaves the previous life's tail in place beyond the new writes. */
  char first_life_segment[1024];
  char second_life_segment[1024];
  char recycled_segment[1024];
  journal_segment_path(first_life, first_life_segment, sizeof(first_life_segment));
  journal_segment_path_at(second_life, 0, 1u << 20, second_life_segment, sizeof(second_life_segment));
  char *recycled = temporary_path("recycled");
  make_journal_directory(recycled);
  journal_segment_path_at(recycled, 0, 1u << 20, recycled_segment, sizeof(recycled_segment));
  copy_prefix(second_life_segment, recycled_segment, file_size(second_life_segment));
  append_range(first_life_segment, recycled_segment,
               (off_t)first_receipt.durable_offset, file_size(first_life_segment));

  /* If these two do not line up the file is not a recycled segment and this
     test is proving nothing, so say so rather than passing quietly. */
  if (file_size(second_life_segment) != (off_t)first_receipt.durable_offset) {
    fail("recycled-segment test did not reproduce a byte-continuous file");
  }
  if (file_size(recycled_segment) <= file_size(second_life_segment)) {
    fail("recycled segment has no stale tail");
  }

  require_status(hdl_open(recycled, NULL, &log),
                 HDL_CORRUPTION,
                 "stale frames from a recycled segment must never be replayed as committed data");

  remove_journal(recycled);
  remove_journal(second_life);
  remove_journal(first_life);
  free(recycled);
  free(second_life);
  free(first_life);
}

/* The harsher form of the same hazard, and the one rotation will actually
 * produce: a segment file is recycled into a new position and the process dies
 * BEFORE it writes anything into it. The file then holds a fresh segment header
 * and, immediately after it, the complete previous life -- valid frames, valid
 * checksums, a valid previous-frame chain from the very first frame, sequences
 * starting at 1. There is no earlier frame for those stale frames to disagree
 * with, so nothing about their content betrays them. Only the position they
 * name does.
 *
 * Same invariant, isolated: a frame is replayed only at the log position it was
 * written for. */
static void an_empty_recycled_segment_replays_nothing_test(void) {
  const char *payloads[] = {"alpha", "beta"};
  const char *later[] = {"gamma", "delta"};
  hdl_record batch[2];
  hdl_record second[2];
  for (int index = 0; index < 2; index++) {
    batch[index] = (hdl_record){5, payloads[index], (uint32_t)strlen(payloads[index])};
    second[index] = (hdl_record){6, later[index], (uint32_t)strlen(later[index])};
  }

  char *previous_life = temporary_path("empty-recycled-previous");
  hdl_log *log = NULL;
  hdl_options previous_options = {1, 0, 0, 0, 0};
  require_status(hdl_open(previous_life, &previous_options, &log), HDL_OK, "open previous life");
  require_status(hdl_append_batch(log, batch, 2, NULL), HDL_OK, "previous life batch one");
  require_status(hdl_append_batch(log, second, 2, NULL), HDL_OK, "previous life batch two");
  require_status(hdl_close(log), HDL_OK, "close previous life");

  /* The new life: a segment header for a later position in the log, and not one
     byte written after it before the crash. */
  char *recycled = temporary_path("empty-recycled");
  hdl_options recycled_options = {2, 1u << 20, 0, 0, 0};
  require_status(hdl_open(recycled, &recycled_options, &log), HDL_OK, "open recycled segment");
  require_status(hdl_close(log), HDL_OK, "close recycled segment");
  char previous_life_segment[1024];
  char recycled_segment[1024];
  journal_segment_path(previous_life, previous_life_segment, sizeof(previous_life_segment));
  journal_segment_path_at(recycled, 0, 1u << 20, recycled_segment, sizeof(recycled_segment));
  if (file_size(recycled_segment) != 64) fail("a fresh segment is not just its header");
  append_range(previous_life_segment, recycled_segment, 64, file_size(previous_life_segment));

  require_status(hdl_open(recycled, NULL, &log),
                 HDL_CORRUPTION,
                 "an unwritten recycled segment must replay nothing, not its previous life");

  remove_journal(recycled);
  remove_journal(previous_life);
  free(recycled);
  free(previous_life);
}

/* A journal is a DIRECTORY of segments, and a segment exists only once it has
 * been renamed into its published name.
 *
 * Rotation needs somewhere to put the next segment, and it needs publication to
 * be one atomic step. etcd gets both from the filesystem: a WAL file is named
 * for the facts recovery needs, so the directory listing IS the manifest, and a
 * file that has not been renamed into that name is not part of the log. A
 * manifest file would be a second thing that has to agree with the first, and
 * every crash boundary in rotation exists because two things can disagree.
 *
 * A segment is named for its index and its base position in the log-global byte
 * space -- the position format v2 binds every frame to. Anything else in the
 * directory, including a half-built segment still under its temporary name, is
 * invisible to recovery. */
static void a_journal_is_a_directory_of_segments_test(void) {
  char *directory = temporary_path("layout");
  hdl_log *log = NULL;
  require_status(hdl_open(directory, NULL, &log), HDL_OK, "open journal directory");
  const char payload[] = "published";
  hdl_record record = {3, payload, sizeof(payload) - 1};
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append to first segment");
  require_status(hdl_close(log), HDL_OK, "close journal directory");

  struct stat directory_metadata;
  if (stat(directory, &directory_metadata) != 0 || !S_ISDIR(directory_metadata.st_mode)) {
    fail("a journal must be a directory of segments");
  }

  /* The first segment is index 0 at base position 0, and it is named for both. */
  char first[512];
  snprintf(first, sizeof(first), "%s/%016llx-%016llx.seg", directory, 0ull, 0ull);
  if (access(first, F_OK) != 0) fail("the first segment is not published under its own name");

  /* A half-built segment under its temporary name is not part of the log. It is
     what a crash between "create" and "rename" leaves behind, and recovery must
     walk past it rather than replay it or refuse the journal. */
  char partial[512];
  snprintf(partial, sizeof(partial), "%s/%016llx-%016llx.seg.tmp", directory, 1ull, 4096ull);
  int partial_fd = open(partial, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (partial_fd < 0) fail("create a partial segment");
  if (write(partial_fd, "not a segment", 13) != 13) fail("write a partial segment");
  close(partial_fd);

  require_status(hdl_open(directory, NULL, &log), HDL_OK, "reopen past a partial segment");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan past a partial segment");
  if (state.invalid || state.count != 1) fail("a partial segment changed what the log replays");
  require_status(hdl_close(log), HDL_OK, "close reopened journal");

  unlink(partial);
  unlink(first);
  rmdir(directory);
  free(directory);
}

/* Rotation must not be able to lose or reorder a single committed record, and
 * the seam between two segments is where that would happen.
 *
 * The cut follows etcd's: the new segment is published with nothing in it but
 * its header, and no acknowledgeable payload is written into it until it is
 * part of the log. The frame chain does not restart at the seam -- the
 * previous-frame CRC and the sequence and batch numbering carry across it, so a
 * segment boundary is invisible to the record stream and visible only to the
 * filesystem.
 *
 * The base positions are the load-bearing part. Segment i begins exactly where
 * segment i-1 ended, in one log-global byte space, which is what makes every
 * frame's position unique across the whole log rather than only within its own
 * file. If they ever failed to chain, a frame could be valid in two places. */
static void rotation_preserves_the_log_test(void) {
  enum { BATCHES = 40 };
  char *directory = temporary_path("rotate");
  hdl_log *log = NULL;
  /* Small enough that this workload crosses several segments; a rotation gate
     that never rotates proves nothing, so the count is asserted below. */
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open rotating journal");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "rotation record %d", index);
    hdl_record record = {7, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append across rotation");
  }
  require_status(hdl_close(log), HDL_OK, "close rotating journal");

  /* The set is contiguous, and each segment begins exactly where the previous
     one ended. */
  hdl_segment_view segments[64];
  size_t count = published_segments(directory, segments, 64);
  if (count < 2) fail("the workload did not rotate; this gate is not exercising rotation");
  if (segments[0].index != 0 || segments[0].base_position != 0) fail("the first segment is not the start of the log");
  for (size_t index = 1; index < count; index++) {
    if (segments[index].index != segments[index - 1].index + 1) fail("segment indices are not contiguous");
    if (segments[index].base_position !=
        segments[index - 1].base_position + (uint64_t)segments[index - 1].size) {
      fail("segment base positions do not chain");
    }
  }

  /* Every committed record comes back, in order, exactly once. */
  require_status(hdl_open(directory, &options, &log), HDL_OK, "reopen rotated journal");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan rotated journal");
  if (state.invalid || state.count != BATCHES) fail("rotation changed the committed record stream");

  /* And the replay cursor crosses the seam without noticing it. */
  hdl_cursor *cursor = NULL;
  require_status(hdl_cursor_open(log, &cursor), HDL_OK, "open cursor over a rotated journal");
  for (uint64_t expected = 1; expected <= BATCHES; expected++) {
    hdl_cursor_record replayed;
    require_status(hdl_cursor_next(cursor, &replayed), HDL_OK, "replay across a segment boundary");
    if (replayed.sequence != expected) fail("replay order broke at a segment boundary");
  }
  hdl_cursor_record finished;
  require_status(hdl_cursor_next(cursor, &finished), HDL_DONE, "finish replaying a rotated journal");
  require_status(hdl_cursor_close(cursor), HDL_OK, "close cursor over a rotated journal");

  /* Appending after a reopen continues the same log, not a new one. */
  const char payload[] = "after the reopen";
  hdl_record record = {7, payload, sizeof(payload) - 1};
  hdl_receipt receipt;
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_OK, "append after reopening a rotated journal");
  if (receipt.first_sequence != BATCHES + 1) fail("rotation lost the sequence across a reopen");
  require_status(hdl_close(log), HDL_OK, "close reopened rotated journal");

  remove_journal(directory);
  free(directory);
}

/* SIGKILL at every step of the cut, enumerated rather than sampled.
 *
 * The promise being tested is the one the sequence exists for: after a crash
 * anywhere inside a rotation, recovery sees either the old segment set or the
 * new one, never a torn set, and every record that was acknowledged before the
 * crash is still there. The child dies mid-cut; the parent then opens the
 * journal and checks exactly that.
 *
 * What a SIGKILL gate can and cannot prove is worth being precise about. Killing
 * the process leaves written bytes in the page cache, so this matrix proves that
 * recovery handles every intermediate FILESYSTEM state -- a stray temporary
 * file, a renamed but undescribed segment, an empty published segment. It cannot
 * prove that the bytes were synced before publication, because the OS keeps them
 * either way. That half is proved separately, by making the barrier FAIL:
 * see a_failed_barrier_during_the_cut_publishes_nothing_test. */
static int run_rotation_kill_point(int point, int batches_before_crash) {
  char *directory = temporary_path("rotate-kill");
  hdl_log *log = NULL;
  /* A segment size of one byte means every batch after the first cuts a new
     segment. Guessing a threshold that happens to land the cut on the batch
     being killed is how a crash matrix silently stops testing the crash: the
     first version of this gate used 512 bytes, the rotation landed one append
     early, and the child exited normally instead of dying. */
  hdl_options options = {1, 0, 0, 0, 1};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "initialize rotating journal");
  require_status(hdl_close(log), HDL_OK, "close initialized rotating journal");

  pid_t child = fork();
  if (child < 0) fail("fork rotation kill test");
  if (child == 0) {
    if (hdl_open(directory, &options, &log) != HDL_OK) _exit(70);
    for (int index = 0; index < batches_before_crash; index++) {
      char payload[64];
      int length = snprintf(payload, sizeof(payload), "before the crash %d", index);
      hdl_record record = {9, payload, (uint32_t)length};
      if (hdl_append_batch(log, &record, 1, NULL) != HDL_OK) _exit(71);
    }
    /* The next append is the one that must cut. */
    hdl_test_kill_at_rotation(point);
    const char payload[] = "the batch that needed a new segment";
    hdl_record record = {9, payload, sizeof(payload) - 1};
    (void)hdl_append_batch(log, &record, 1, NULL);
    _exit(72);
  }
  int child_status = 0;
  if (waitpid(child, &child_status, 0) != child) fail("wait for killed rotation");
  if (!WIFSIGNALED(child_status) || WTERMSIG(child_status) != SIGKILL) {
    fail("the rotation writer did not die by SIGKILL at the requested point");
  }

  /* The set as the crash left it, read before recovery touches it: reopening
     appends, and an append with this segment size cuts, which would count a
     segment the crash did not produce. */
  hdl_segment_view segments[64];
  size_t count = published_segments(directory, segments, 64);

  /* Recovery must succeed, and every acknowledged record must still be there. */
  require_status(hdl_open(directory, &options, &log), HDL_OK, "recover after a crash mid-cut");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after a crash mid-cut");
  if (state.invalid) fail("recovery after a crash mid-cut produced an invalid record stream");
  if (state.count != batches_before_crash) {
    fail("a crash during rotation lost or invented an acknowledged record");
  }
  /* And the journal is usable again: the log continues, it does not restart. */
  const char payload[] = "after the crash";
  hdl_record record = {9, payload, sizeof(payload) - 1};
  hdl_receipt receipt;
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_OK, "append after a crash mid-cut");
  if (receipt.first_sequence != (uint64_t)batches_before_crash + 1) {
    fail("a crash during rotation broke the sequence");
  }
  require_status(hdl_close(log), HDL_OK, "close journal recovered from a crash mid-cut");

  remove_journal(directory);
  free(directory);
  return (int)count;
}

static void rotation_crash_matrix_test(void) {
  /* Four batches means four segments before the crash: the first goes into the
     segment the journal opened with, and every batch after it cuts one. The
     batch that dies is the fifth, and it dies inside its cut. */
  enum { BATCHES_BEFORE_CRASH = 4, SEGMENTS_BEFORE_CRASH = 4 };
  int reached_the_rename = 0;
  for (int point = HDL_ROTATION_POINT_AFTER_CREATE;
       point <= HDL_ROTATION_POINT_AFTER_DIRECTORY_SYNC; point++) {
    int count = run_rotation_kill_point(point, BATCHES_BEFORE_CRASH);
    /* Either the old set or the new one -- never something in between. */
    if (count != SEGMENTS_BEFORE_CRASH && count != SEGMENTS_BEFORE_CRASH + 1) {
      fail("a crash during rotation left a set that is neither the old one nor the new one");
    }
    if (point <= HDL_ROTATION_POINT_AFTER_HEADER_SYNC && count != SEGMENTS_BEFORE_CRASH) {
      fail("a segment became visible before it was renamed into the log");
    }
    if (point >= HDL_ROTATION_POINT_AFTER_RENAME) {
      if (count != SEGMENTS_BEFORE_CRASH + 1) fail("a renamed segment did not become part of the log");
      reached_the_rename++;
    }
  }
  if (reached_the_rename != 2) fail("the rotation crash matrix did not reach the rename");
}

/* The half a SIGKILL cannot reach: a segment must never be published unless its
 * bytes are already durable.
 *
 * Killing the process proves nothing here, because the OS holds the written
 * bytes whether or not they were synced. A failed barrier is what separates the
 * two: if the header sync fails, the rename must not happen, nothing may appear
 * in the directory, and the append that needed the new segment must not be
 * acknowledged. Moving the rename before the sync -- publishing first and
 * syncing afterwards -- turns this gate red, which is how it was proved. */
static void a_failed_barrier_during_the_cut_publishes_nothing_test(void) {
  enum { BATCHES_BEFORE_CUT = 4 };
  char *directory = temporary_path("rotate-barrier");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 1};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open journal for a failed cut");
  for (int index = 0; index < BATCHES_BEFORE_CUT; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "before the failed cut %d", index);
    hdl_record record = {4, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append before a failed cut");
  }

  hdl_test_fail_rotation_sync();
  const char payload[] = "the batch that needed a new segment";
  hdl_record record = {4, payload, sizeof(payload) - 1};
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_IO,
                 "a batch whose segment could not be made durable must not be acknowledged");
  hdl_test_clear_failures();

  hdl_segment_view segments[64];
  size_t count = published_segments(directory, segments, 64);
  if (count != BATCHES_BEFORE_CUT) fail("a segment was published although its bytes were never synced");

  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after a failed cut");
  if (state.invalid || state.count != BATCHES_BEFORE_CUT) fail("a failed cut changed the committed log");
  require_status(hdl_close(log), HDL_OK, "close journal after a failed cut");

  remove_journal(directory);
  free(directory);
}

/* Retirement is the only operation in this package that deliberately destroys
 * data, so the promise it has to keep is the strictest one here: no committed
 * record ever becomes unreachable.
 *
 * "Verified" therefore has to mean restored and compared, not written and
 * assumed. This gate takes a snapshot, restores it into a fresh directory, and
 * compares the two record streams RECORD BY RECORD -- sequence, stream id and
 * payload bytes -- rather than counting them and hoping. A count matches for a
 * snapshot that dropped one record and duplicated another. */
static size_t published_segments_count(const char *directory) {
  hdl_segment_view segments[64];
  return published_segments(directory, segments, 64);
}

/* Retirement, and the only invariant that matters about it: no committed record
 * ever becomes unreachable.
 *
 * After retiring the segments a snapshot covers, the snapshot and the surviving
 * journal must together replay the original stream exactly -- no gap where the
 * seam was, no record replayed twice, and the sequence unbroken across the join.
 * The stream is captured BEFORE the retirement and compared record by record
 * afterwards, because a count would match a retirement that dropped one record
 * and duplicated another. */
typedef struct {
  uint64_t sequence;
  uint64_t stream_id;
  uint32_t payload_length;
  char payload[64];
} remembered_record;

typedef struct {
  remembered_record *records;
  size_t count;
  size_t capacity;
} remembered_stream;

static int remember(void *opaque, uint64_t sequence, uint64_t batch_id,
                    uint64_t stream_id, const void *payload, uint32_t payload_length) {
  remembered_stream *stream = opaque;
  (void)batch_id;
  if (stream->count == stream->capacity) fail("remembered stream is full");
  if (payload_length > sizeof(stream->records[0].payload)) fail("remembered payload is too long");
  remembered_record *record = &stream->records[stream->count++];
  record->sequence = sequence;
  record->stream_id = stream_id;
  record->payload_length = payload_length;
  memcpy(record->payload, payload, payload_length);
  return 0;
}

static void retirement_keeps_every_record_reachable_test(void) {
  enum { BATCHES = 30 };
  char *directory = temporary_path("retire-source");
  char *snapshot = temporary_path("retire-snapshot");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open the journal to retire from");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "retirement record %d", index);
    hdl_record record = {(uint64_t)(index % 3) + 1, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append before retirement");
  }

  remembered_record storage[BATCHES];
  remembered_stream before = {storage, 0, BATCHES};
  require_status(hdl_scan(log, remember, &before), HDL_OK, "remember the stream before retirement");
  if (before.count != BATCHES) fail("the stream before retirement is not what was appended");

  hdl_snapshot receipt;
  require_status(hdl_snapshot_create(log, snapshot, &receipt), HDL_OK, "snapshot before retiring");
  size_t segments_before = published_segments_count(directory);
  require_status(hdl_retire_snapshotted(log, snapshot), HDL_OK, "retire the snapshotted segments");
  size_t segments_after = published_segments_count(directory);
  if (segments_after >= segments_before) fail("retirement did not actually retire a segment");

  /* The journal replays only what was not retired -- and still opens, which it
     would not if the surviving set were judged by the rule that segment 0 must
     be present. */
  require_status(hdl_close(log), HDL_OK, "close the retired-from journal");
  require_status(hdl_open(directory, &options, &log), HDL_OK, "reopen a journal whose prefix was retired");
  remembered_record survived_storage[BATCHES];
  remembered_stream survived = {survived_storage, 0, BATCHES};
  require_status(hdl_scan(log, remember, &survived), HDL_OK, "replay the surviving journal");

  /* And the snapshot replays exactly the part that is gone. */
  hdl_log *snapshot_log = NULL;
  require_status(hdl_open(snapshot, &options, &snapshot_log), HDL_OK, "open the snapshot as a journal");
  remembered_record retired_storage[BATCHES];
  remembered_stream retired = {retired_storage, 0, BATCHES};
  require_status(hdl_scan(snapshot_log, remember, &retired), HDL_OK, "replay the snapshot");
  require_status(hdl_close(snapshot_log), HDL_OK, "close the snapshot");

  if (retired.count + survived.count != before.count) {
    fail("retirement made a committed record unreachable, or reachable twice");
  }
  for (size_t index = 0; index < before.count; index++) {
    const remembered_record *expected = &before.records[index];
    const remembered_record *actual = index < retired.count
                                        ? &retired.records[index]
                                        : &survived.records[index - retired.count];
    if (expected->sequence != actual->sequence || expected->stream_id != actual->stream_id ||
        expected->payload_length != actual->payload_length ||
        memcmp(expected->payload, actual->payload, expected->payload_length) != 0) {
      fail("snapshot plus surviving journal is not the original stream, record for record");
    }
  }

  /* The log continues from where it was, not from where the survivors start. */
  const char payload[] = "after the retirement";
  hdl_record record = {1, payload, sizeof(payload) - 1};
  hdl_receipt appended;
  require_status(hdl_append_batch(log, &record, 1, &appended), HDL_OK, "append after retirement");
  if (appended.first_sequence != (uint64_t)BATCHES + 1) fail("retirement broke the sequence");
  require_status(hdl_close(log), HDL_OK, "close the journal after retirement");

  remove_journal(snapshot);
  remove_journal(directory);
  free(snapshot);
  free(directory);
}

/* A snapshot that does not verify must not satisfy a retirement, and must not
 * cost the journal a single segment on the way to being refused. */
static void an_unverified_snapshot_retires_nothing_test(void) {
  enum { BATCHES = 30 };
  char *directory = temporary_path("unverified-source");
  char *snapshot = temporary_path("unverified-snapshot");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open the journal");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "unverified record %d", index);
    hdl_record record = {2, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append");
  }
  hdl_snapshot receipt;
  require_status(hdl_snapshot_create(log, snapshot, &receipt), HDL_OK, "take a snapshot");

  /* Damage one payload byte inside the snapshot's first segment: complete frame,
     broken checksum -- the case a journal fails closed on. */
  char damaged[1024];
  journal_segment_path(snapshot, damaged, sizeof(damaged));
  int fd = open(damaged, O_RDWR);
  if (fd < 0) fail("open the snapshot segment to damage it");
  unsigned char value;
  if (pread(fd, &value, 1, 120) != 1) fail("read the byte to damage");
  value ^= 0x40;
  if (pwrite(fd, &value, 1, 120) != 1) fail("damage the snapshot");
  close(fd);

  require_status(hdl_snapshot_verify(snapshot, NULL), HDL_CORRUPTION, "a damaged snapshot must not verify");
  size_t before = published_segments_count(directory);
  hdl_status retirement = hdl_retire_snapshotted(log, snapshot);
  if (retirement == HDL_OK) fail("a snapshot that does not verify satisfied a retirement");
  if (published_segments_count(directory) != before) {
    fail("a refused retirement destroyed a segment anyway");
  }

  /* And the journal is untouched: every record still there, in order. */
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after a refused retirement");
  if (state.invalid || state.count != BATCHES) fail("a refused retirement changed the log");
  require_status(hdl_close(log), HDL_OK, "close the journal");
  remove_journal(snapshot);
  remove_journal(directory);
  free(snapshot);
  free(directory);
}

/* The snapshot bytes are intact; the RECEIPT is what does not match.
 *
 * This is the case that decides whether verification is load-bearing at all.
 * A damaged snapshot is refused several times over -- it cannot even be opened
 * as a journal -- so it cannot tell you whether the check you wrote is doing
 * anything. A readable snapshot whose receipt describes a different record
 * stream can only be caught by comparing the two, which is what "verified means
 * restored and compared" means. */
static void a_snapshot_whose_receipt_does_not_match_retires_nothing_test(void) {
  enum { BATCHES = 30 };
  char *directory = temporary_path("lying-source");
  char *snapshot = temporary_path("lying-snapshot");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open the journal");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "receipt record %d", index);
    hdl_record record = {2, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append");
  }
  hdl_snapshot receipt;
  require_status(hdl_snapshot_create(log, snapshot, &receipt), HDL_OK, "take a snapshot");

  /* Change what the receipt CLAIMS the snapshot holds, leaving every segment
     byte exactly as it was. */
  char receipt_path[1024];
  snprintf(receipt_path, sizeof(receipt_path), "%s/snapshot.receipt", snapshot);
  int fd = open(receipt_path, O_RDWR);
  if (fd < 0) fail("open the snapshot receipt");
  char text[1024];
  ssize_t got = pread(fd, text, sizeof(text) - 1, 0);
  if (got <= 0) fail("read the snapshot receipt");
  text[got] = '\0';
  char *records_line = strstr(text, "\nrecords ");
  if (records_line == NULL) fail("the receipt does not say what it holds");
  /* The last hex digit of the record count: one record more than there are. */
  char *digit = records_line + 9 + 15;
  *digit = (*digit == '9') ? '8' : '9';
  if (pwrite(fd, text, (size_t)got, 0) != got) fail("rewrite the snapshot receipt");
  close(fd);

  require_status(hdl_snapshot_verify(snapshot, NULL), HDL_CORRUPTION,
                 "a receipt that does not describe the snapshot must not verify");
  size_t before = published_segments_count(directory);
  if (hdl_retire_snapshotted(log, snapshot) == HDL_OK) {
    fail("a snapshot whose receipt does not match satisfied a retirement");
  }
  if (published_segments_count(directory) != before) fail("a refused retirement destroyed a segment anyway");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after a refused retirement");
  if (state.invalid || state.count != BATCHES) fail("a refused retirement changed the log");
  require_status(hdl_close(log), HDL_OK, "close the journal");

  remove_journal(snapshot);
  remove_journal(directory);
  free(snapshot);
  free(directory);
}

/* A snapshot that was never finished -- the process died while writing it -- has
 * no receipt, cannot verify, and therefore cannot retire anything. The segments
 * it was copying are still where they were. */
static void an_unfinished_snapshot_retires_nothing_test(void) {
  enum { BATCHES = 30 };
  char *directory = temporary_path("unfinished-source");
  char *snapshot = temporary_path("unfinished-snapshot");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open the journal");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "unfinished record %d", index);
    hdl_record record = {2, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append");
  }

  pid_t child = fork();
  if (child < 0) fail("fork the snapshot writer");
  if (child == 0) {
    /* The child snapshots through the INHERITED handle rather than opening the
       journal again: one writer owns a journal, and a forked child asking for
       its parent's journal is exactly the second writer that ownership refuses. */
    hdl_snapshot ignored;
    /* Die after one segment has been copied and published, which is before the
       receipt exists -- the state a crash mid-snapshot actually leaves. */
    hdl_test_kill_during_snapshot_after_segments(1);
    (void)hdl_snapshot_create(log, snapshot, &ignored);
    _exit(71);
  }
  int child_status = 0;
  if (waitpid(child, &child_status, 0) != child) fail("wait for the snapshot writer");
  if (!WIFSIGNALED(child_status) || WTERMSIG(child_status) != SIGKILL) {
    fail("the snapshot writer did not die partway through writing the snapshot");
  }

  size_t before = published_segments_count(directory);
  if (hdl_snapshot_verify(snapshot, NULL) == HDL_OK) fail("an unfinished snapshot verified");
  if (hdl_retire_snapshotted(log, snapshot) == HDL_OK) fail("an unfinished snapshot satisfied a retirement");
  if (published_segments_count(directory) != before) fail("a refused retirement destroyed a segment anyway");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after an unfinished snapshot");
  if (state.invalid || state.count != BATCHES) fail("an unfinished snapshot changed the log");
  require_status(hdl_close(log), HDL_OK, "close the journal");

  remove_journal(snapshot);
  remove_journal(directory);
  free(snapshot);
  free(directory);
}

static void a_snapshot_restores_the_identical_prefix_test(void) {
  enum { BATCHES = 30 };
  char *directory = temporary_path("snapshot-source");
  char *snapshot = temporary_path("snapshot");
  char *restored = temporary_path("snapshot-restored");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open the journal to snapshot");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "snapshot record %d", index);
    hdl_record record = {(uint64_t)(index % 3) + 1, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append before snapshot");
  }

  hdl_snapshot receipt;
  require_status(hdl_snapshot_create(log, snapshot, &receipt), HDL_OK, "take a snapshot");
  if (receipt.records == 0) fail("the snapshot covered nothing; this gate is not testing a snapshot");
  if (receipt.last_index + 1 >= (uint64_t)BATCHES) fail("the snapshot covered the active segment");

  /* A restore is a journal, and it replays exactly what the snapshot said. */
  require_status(hdl_snapshot_restore(snapshot, restored), HDL_OK, "restore the snapshot");
  hdl_log *restored_log = NULL;
  require_status(hdl_open(restored, &options, &restored_log), HDL_OK, "open the restored journal");

  hdl_cursor *original = NULL;
  hdl_cursor *copy = NULL;
  require_status(hdl_cursor_open(log, &original), HDL_OK, "replay the original");
  require_status(hdl_cursor_open(restored_log, &copy), HDL_OK, "replay the restore");
  for (uint64_t index = 0; index < receipt.records; index++) {
    hdl_cursor_record left;
    hdl_cursor_record right;
    require_status(hdl_cursor_next(original, &left), HDL_OK, "read the original");
    require_status(hdl_cursor_next(copy, &right), HDL_OK, "read the restore");
    if (left.sequence != right.sequence || left.stream_id != right.stream_id ||
        left.payload_length != right.payload_length ||
        memcmp(left.payload, right.payload, left.payload_length) != 0) {
      fail("the restored journal is not the identical committed prefix, record for record");
    }
  }
  hdl_cursor_record finished;
  require_status(hdl_cursor_next(copy, &finished), HDL_DONE, "the restore ends where the snapshot does");
  require_status(hdl_cursor_close(copy), HDL_OK, "close the restore cursor");
  require_status(hdl_cursor_close(original), HDL_OK, "close the original cursor");
  require_status(hdl_close(restored_log), HDL_OK, "close the restored journal");

  /* And the receipt is reproducible: the same committed prefix produces the
     same bytes, so two operators can compare receipts instead of journals. */
  char *again = temporary_path("snapshot-again");
  hdl_snapshot repeated;
  require_status(hdl_snapshot_create(log, again, &repeated), HDL_OK, "take the snapshot again");
  if (repeated.records != receipt.records || repeated.digest != receipt.digest ||
      repeated.first_sequence != receipt.first_sequence ||
      repeated.last_sequence != receipt.last_sequence ||
      repeated.first_index != receipt.first_index || repeated.last_index != receipt.last_index) {
    fail("two snapshots of the same committed prefix produced different receipts");
  }

  require_status(hdl_close(log), HDL_OK, "close the snapshotted journal");
  remove_journal(again);
  remove_journal(restored);
  remove_journal(snapshot);
  remove_journal(directory);
  free(again);
  free(restored);
  free(snapshot);
  free(directory);
}

/* Two writers, one journal, and both told their mutation was durable.
 *
 * Reported by chatgpt against v0.2.0 at 358a543 and reproduced unchanged here:
 *
 *     open_a=ok open_b=ok append_a=ok append_b=ok
 *     sequence_a=1 sequence_b=1 reopen=corruption
 *
 * The per-handle mutex serializes callers WITHIN a handle and does nothing
 * across handles. Each handle derives its append offset, sequence, batch id and
 * previous-frame CRC from recovery at open time, so two handles both believe
 * they own the tail; O_APPEND stops the bytes from overlapping but not the two
 * owners from disagreeing about what those bytes mean. Two acknowledgements
 * that cannot both be true is the worst thing this package can do, and it ends
 * with a journal that will not open at all.
 *
 * Ownership is taken BEFORE recovery, not before the first write, because
 * recovery TRUNCATES an uncommitted tail -- a second opener would otherwise
 * destroy work the first owner is still doing before anyone noticed it was not
 * alone. */
static void one_writer_owns_a_journal_test(void) {
  char *directory = temporary_path("exclusive");
  hdl_log *first = NULL;
  hdl_log *second = NULL;
  require_status(hdl_open(directory, NULL, &first), HDL_OK, "open the journal");

  /* Same process, second handle: refused, and refused by NAME. "Someone else
     owns this journal" and "the disk failed" call for opposite responses from a
     caller, so they must not arrive as the same status. */
  require_status(hdl_open(directory, NULL, &second), HDL_LOCKED,
                 "a second writer must be refused while the first still owns the journal");
  if (second != NULL) fail("a refused open handed back a handle anyway");

  /* The owner is unharmed by the attempt. */
  const char payload[] = "the owner's mutation";
  hdl_record record = {1, payload, sizeof(payload) - 1};
  hdl_receipt receipt;
  require_status(hdl_append_batch(first, &record, 1, &receipt), HDL_OK, "the owner still appends");
  if (receipt.first_sequence != 1) fail("the refused open disturbed the owner's sequence");

  /* Another process is refused too, which is the case a mutex could never
     cover and the one that actually happens in production. */
  pid_t child = fork();
  if (child < 0) fail("fork the second writer");
  if (child == 0) {
    hdl_log *theirs = NULL;
    hdl_status status = hdl_open(directory, NULL, &theirs);
    if (theirs != NULL) hdl_close(theirs);
    _exit(status == HDL_LOCKED ? 0 : 1);
  }
  int child_status = 0;
  if (waitpid(child, &child_status, 0) != child) fail("wait for the second writer");
  if (!WIFEXITED(child_status) || WEXITSTATUS(child_status) != 0) {
    fail("a second writer in another process was not refused");
  }

  /* Ownership ends with the handle. */
  require_status(hdl_close(first), HDL_OK, "close the owner");
  require_status(hdl_open(directory, NULL, &second), HDL_OK, "the journal is available once released");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(second, collect, &state), HDL_OK, "scan the reopened journal");
  if (state.invalid || state.count != 1) fail("exclusive ownership cost a committed record");
  require_status(hdl_close(second), HDL_OK, "close the new owner");

  /* And ownership ends with a CRASH. A lock that outlives the process that took
     it would leave a journal nobody can open, which is a worse outage than the
     bug it prevents -- so the mechanism has to be one the kernel releases. */
  pid_t crasher = fork();
  if (crasher < 0) fail("fork the crashing owner");
  if (crasher == 0) {
    hdl_log *theirs = NULL;
    if (hdl_open(directory, NULL, &theirs) != HDL_OK) _exit(70);
    raise(SIGKILL);
    _exit(71);
  }
  if (waitpid(crasher, &child_status, 0) != crasher) fail("wait for the crashing owner");
  if (!WIFSIGNALED(child_status) || WTERMSIG(child_status) != SIGKILL) {
    fail("the crashing owner did not die by SIGKILL");
  }
  require_status(hdl_open(directory, NULL, &first), HDL_OK,
                 "a journal whose owner crashed must not stay locked");
  require_status(hdl_close(first), HDL_OK, "close after the crash");

  remove_journal(directory);
  free(directory);
}

/* A replay cursor that cannot resume makes every catching-up reader re-walk the
 * whole log.
 *
 * That is not a theoretical cost: it is what
 * docs/BENCHMARK-2026-09-04-replay-lag.md measured. Replay lag grew 2.15x across
 * a run at 32 writers and 2.47x when the same configuration wrote twice as many
 * records, because the model FORMAT.md recommends -- apply a finite committed
 * prefix, then open another cursor -- re-reads everything already applied on
 * every pass.
 *
 * The invariant: resuming at a position yields exactly the records after it, in
 * order, with no gap and no repeat -- including across a segment boundary, where
 * "the next record" is in a different file. */
static void a_cursor_resumes_where_it_stopped_test(void) {
  enum { BATCHES = 30 };
  char *directory = temporary_path("resume");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open the journal to resume in");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "resume record %d", index);
    hdl_record record = {4, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append before resuming");
  }
  if (published_segments_count(directory) < 2) fail("this gate needs a rotated journal");

  /* Drain once, remembering where each record said the next one starts. */
  uint64_t resume_after[BATCHES];
  hdl_cursor *cursor = NULL;
  require_status(hdl_cursor_open(log, &cursor), HDL_OK, "open the first cursor");
  for (int index = 0; index < BATCHES; index++) {
    hdl_cursor_record replayed;
    require_status(hdl_cursor_next(cursor, &replayed), HDL_OK, "read the whole log once");
    if (replayed.position == 0 || replayed.next_position <= replayed.position) {
      fail("a replayed record does not say where it is or where the next one starts");
    }
    resume_after[index] = replayed.next_position;
  }
  hdl_cursor_record finished;
  require_status(hdl_cursor_next(cursor, &finished), HDL_DONE, "finish the first cursor");
  require_status(hdl_cursor_close(cursor), HDL_OK, "close the first cursor");

  /* Resume from every point, including across the seam, and demand exactly the
     records after it. Testing one resume point would not notice a cursor that
     works only inside the segment it started in. */
  for (int start = 0; start < BATCHES; start++) {
    require_status(hdl_cursor_open_at(log, resume_after[start], &cursor), HDL_OK, "resume");
    for (int index = start + 1; index < BATCHES; index++) {
      hdl_cursor_record replayed;
      require_status(hdl_cursor_next(cursor, &replayed), HDL_OK, "read a resumed record");
      if (replayed.sequence != (uint64_t)index + 1) fail("resuming skipped or repeated a record");
      char expected[64];
      int length = snprintf(expected, sizeof(expected), "resume record %d", index);
      if (replayed.payload_length != (uint32_t)length ||
          memcmp(replayed.payload, expected, replayed.payload_length) != 0) {
        fail("a resumed record is not the record that was written");
      }
    }
    require_status(hdl_cursor_next(cursor, &finished), HDL_DONE, "a resumed cursor ends with the log");
    require_status(hdl_cursor_close(cursor), HDL_OK, "close a resumed cursor");
  }

  /* A reader that is caught up is not an error; it is a reader with nothing to
     do, and it must be able to say so without opening a cursor over the whole
     log to find out. */
  require_status(hdl_cursor_open_at(log, resume_after[BATCHES - 1], &cursor), HDL_OK,
                 "resume at the committed end");
  require_status(hdl_cursor_next(cursor, &finished), HDL_DONE, "a caught-up reader has nothing to read");
  require_status(hdl_cursor_close(cursor), HDL_OK, "close the caught-up cursor");

  /* A position that is not a frame boundary is refused. Scanning forward to the
     next plausible frame is how a reader silently invents a record. */
  hdl_cursor *refused = NULL;
  require_status(hdl_cursor_open_at(log, resume_after[0] + 1, &refused), HDL_INVALID,
                 "a position that is not a frame boundary must be refused, not resynchronised");
  if (refused != NULL) fail("a refused resume handed back a cursor");
  require_status(hdl_cursor_open_at(log, resume_after[BATCHES - 1] + 1, &refused), HDL_INVALID,
                 "a position past the committed end must be refused");

  require_status(hdl_close(log), HDL_OK, "close the resumed journal");
  remove_journal(directory);
  free(directory);
}

/* After retirement the early positions are not in this journal any more. The
 * records still exist -- in the snapshot that justified the retirement -- so a
 * reader asking for them is behind, not broken, and must be told which. */
static void resuming_before_the_origin_says_retired_test(void) {
  enum { BATCHES = 30 };
  char *directory = temporary_path("retired-resume");
  char *snapshot = temporary_path("retired-resume-snapshot");
  hdl_log *log = NULL;
  hdl_options options = {1, 0, 0, 0, 512};
  require_status(hdl_open(directory, &options, &log), HDL_OK, "open the journal");
  for (int index = 0; index < BATCHES; index++) {
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "retired record %d", index);
    hdl_record record = {4, payload, (uint32_t)length};
    require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append");
  }
  hdl_cursor *cursor = NULL;
  hdl_cursor_record first;
  require_status(hdl_cursor_open(log, &cursor), HDL_OK, "open a cursor");
  require_status(hdl_cursor_next(cursor, &first), HDL_OK, "read the first record");
  uint64_t early = first.next_position;
  require_status(hdl_cursor_close(cursor), HDL_OK, "close the cursor");

  hdl_snapshot receipt;
  require_status(hdl_snapshot_create(log, snapshot, &receipt), HDL_OK, "snapshot");
  require_status(hdl_retire_snapshotted(log, snapshot), HDL_OK, "retire");

  require_status(hdl_cursor_open_at(log, early, &cursor), HDL_RETIRED,
                 "a position below the origin is retired, not corrupt and not missing");

  require_status(hdl_close(log), HDL_OK, "close the journal");
  remove_journal(snapshot);
  remove_journal(directory);
  free(snapshot);
  free(directory);
}

static void corruption_test(void) {
  char *path = temporary_path("corrupt");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open corruption log");
  const char payload[] = "committed";
  hdl_record record = {9, payload, sizeof(payload) - 1};
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append corruption record");
  require_status(hdl_close(log), HDL_OK, "close corruption log");
  char segment[1024];
  journal_segment_path(path, segment, sizeof(segment));
  int fd = open(segment, O_RDWR);
  if (fd < 0) fail("open for corruption");
  unsigned char value;
  if (pread(fd, &value, 1, 64 + 48) != 1) fail("read corruption byte");
  value ^= 0x40;
  if (pwrite(fd, &value, 1, 64 + 48) != 1) fail("write corruption byte");
  close(fd);
  require_status(hdl_open(path, NULL, &log), HDL_CORRUPTION, "fail closed corruption");
  remove_journal(path);
  free(path);
}

/* Each injected fault gets its OWN log handle.
 *
 * That is forced by the semantics, not by tidiness: a failed durability
 * barrier poisons the handle, so a second fault injected into the same handle
 * would be answered by the poison rather than exercising the fault. Sharing one
 * handle would have quietly stopped testing the second failure mode. */
static void injected_short_write_test(void) {
  char *path = temporary_path("failure-write");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open short-write log");
  const char payload[] = "must not acknowledge";
  hdl_record record = {7, payload, sizeof(payload) - 1};

  hdl_test_fail_write_after_bytes(17);
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_IO, "short write refusal");
  hdl_test_clear_failures();
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after short write");
  if (state.count != 0) fail("short write became visible");

  /* A failed WRITE must NOT poison. The bytes did not all reach the file and
     the rollback returned it to a state we still know, so the handle can still
     tell the truth about durability. Only a failed BARRIER destroys that
     knowledge. Conflating the two would make every transient write error cost a
     reopen for no gain in safety. */
  hdl_receipt receipt;
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_OK, "a short write must not poison the handle");
  if (receipt.first_sequence != 1) fail("short write consumed a sequence");
  require_status(hdl_close(log), HDL_OK, "close short-write log");
  remove_journal(path);
  free(path);
}

static void failed_barrier_poisons_test(void) {
  char *path = temporary_path("failure-sync");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open sync-failure log");
  const char payload[] = "must not acknowledge";
  hdl_record record = {7, payload, sizeof(payload) - 1};

  hdl_test_fail_next_sync();
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_IO, "sync failure refusal");
  hdl_test_clear_failures();
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after sync failure");
  if (state.count != 0) fail("failed sync became visible");

  /* Once a durability barrier has FAILED, this handle can no longer tell the
   * truth about what is durable, so it must never issue another
   * acknowledgement. The kernel reports a writeback error once and then clears
   * it: a later fsync on the same descriptor can return success while the
   * earlier data is permanently gone. Rebello et al. (USENIX ATC '20) measured
   * ext4 data=journal reporting the error one fsync LATE, so "we rolled back the
   * batch that failed" does not restore ground truth either.
   *
   * This assertion was inverted deliberately -- it used to require HDL_OK here,
   * i.e. it used to require the journal to issue exactly the acknowledgement it
   * is no longer entitled to make. See the cagents decision
   * poison-the-log-after-a-failed-durability-barrier. */
  hdl_receipt receipt;
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_POISONED, "append after a failed barrier must not be acknowledged");

  /* Reading still works: inspecting the log is how an operator investigates. */
  state = (scan_state){0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan a poisoned log");
  require_status(hdl_close(log), HDL_OK, "close poisoned log");

  /* Reopening re-runs recovery, which re-derives what is committed from the
   * bytes on disk -- the knowledge the failed barrier destroyed. That, and only
   * that, clears the poison. The sequence still starts at 1, proving the failed
   * batch never consumed an identity. */
  require_status(hdl_open(path, NULL, &log), HDL_OK, "reopen after poisoning");
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_OK, "reopened log accepts appends");
  if (receipt.first_sequence != 1 || receipt.last_sequence != 1) fail("failed batch consumed sequence");
  require_status(hdl_close(log), HDL_OK, "close reopened log");
  remove_journal(path);
  free(path);
}

typedef enum {
  KILL_DURING_WRITE,
  KILL_BEFORE_SYNC,
  KILL_AFTER_SYNC
} kill_point;

static int recovered_count(const char *path) {
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open killed log");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan killed log");
  if (state.invalid) fail("invalid record after kill");
  require_status(hdl_close(log), HDL_OK, "close killed log");
  return state.count;
}

static int run_kill_point(kill_point point) {
  char *path = temporary_path("kill");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "initialize killed log");
  require_status(hdl_close(log), HDL_OK, "close initialized killed log");

  pid_t child = fork();
  if (child < 0) fail("fork kill test");
  if (child == 0) {
    if (hdl_open(path, NULL, &log) != HDL_OK) _exit(70);
    if (point == KILL_DURING_WRITE) hdl_test_kill_during_write_after_bytes(17);
    if (point == KILL_BEFORE_SYNC) hdl_test_kill_before_next_sync();
    if (point == KILL_AFTER_SYNC) hdl_test_kill_after_next_sync();
    const char payload[] = "kill-point mutation";
    hdl_record record = {31, payload, sizeof(payload) - 1};
    (void)hdl_append_batch(log, &record, 1, NULL);
    _exit(71);
  }
  int child_status = 0;
  if (waitpid(child, &child_status, 0) != child) fail("wait for killed writer");
  if (!WIFSIGNALED(child_status) || WTERMSIG(child_status) != SIGKILL) fail("writer did not die by SIGKILL");
  int count = recovered_count(path);
  remove_journal(path);
  free(path);
  return count;
}

static void process_kill_test(void) {
  if (run_kill_point(KILL_DURING_WRITE) != 0) fail("partial frame survived SIGKILL");
  int before_sync = run_kill_point(KILL_BEFORE_SYNC);
  if (before_sync != 0 && before_sync != 1) fail("invalid pre-sync recovery count");
  if (run_kill_point(KILL_AFTER_SYNC) != 1) fail("synced batch lost after SIGKILL");
}

typedef struct {
  hdl_log *log;
  hdl_broker *broker;
  int thread_id;
  int operations;
  int failures;
  hdl_test_barrier *barrier;
} writer_args;

static void *writer(void *opaque) {
  writer_args *args = opaque;
  for (int index = 0; index < args->operations; index++) {
    if (args->barrier != NULL) hdl_test_barrier_wait(args->barrier);
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "thread=%d operation=%d", args->thread_id, index);
    hdl_record record = {(uint64_t)args->thread_id + 1, payload, (uint32_t)length};
    hdl_status status = args->broker == NULL
                          ? hdl_append_batch(args->log, &record, 1, NULL)
                          : hdl_broker_submit(args->broker, &record, NULL);
    if (status != HDL_OK) args->failures++;
  }
  return NULL;
}

static void durability_barrier_test(void) {
  /* The headline promise is that acknowledgement follows DATA + COMMIT + a
   * durability barrier. On Darwin that promise is only true if the barrier is
   * F_FULLFSYNC: fsync(2) there states plainly that after fsync "the drive
   * itself may not physically write the data to the platters for quite some
   * time", that on power loss "the application may find that only some or none
   * of their data was written", and that this "is not a theoretical edge case".
   * A journal that acknowledged on fdatasync alone on that platform would be
   * acknowledging the DRIVE's volatile cache -- the same defect as
   * acknowledging RAM, one layer down, and invisible until a power cut.
   *
   * So the gate asserts which barrier this build uses, per platform. */
  const char *barrier = hdl_sync_barrier_name();
  if (barrier == NULL) fail("build reports no durability barrier");
#if defined(__APPLE__)
  if (strcmp(barrier, "F_FULLFSYNC") != 0) fail("Darwin build must flush the device cache with F_FULLFSYNC");
#else
  if (strcmp(barrier, "fdatasync") != 0) fail("expected fdatasync durability barrier");
#endif
}

static void concurrency_test(void) {
  enum { THREADS = 8, OPERATIONS = 40 };
  char *path = temporary_path("concurrent");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open concurrent log");
  pthread_t threads[THREADS];
  writer_args args[THREADS];
  for (int index = 0; index < THREADS; index++) {
    args[index] = (writer_args){log, NULL, index, OPERATIONS, 0, NULL};
    if (pthread_create(&threads[index], NULL, writer, &args[index]) != 0) fail("create writer");
  }
  for (int index = 0; index < THREADS; index++) {
    pthread_join(threads[index], NULL);
    if (args[index].failures != 0) fail("concurrent append failure");
  }
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan concurrent log");
  if (state.invalid || state.count != THREADS * OPERATIONS) fail("concurrent sequence integrity");
  require_status(hdl_close(log), HDL_OK, "close concurrent log");

  require_status(hdl_open(path, NULL, &log), HDL_OK, "reopen concurrent log");
  state = (scan_state){0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan reopened concurrent log");
  if (state.invalid || state.count != THREADS * OPERATIONS) fail("reopen sequence integrity");
  require_status(hdl_close(log), HDL_OK, "close reopened concurrent log");
  remove_journal(path);
  free(path);
}

static void backpressure_bounds_the_queue_test(void) {
  /* "Keep queues bounded" is only a promise if the bound is reached and holds.
   *
   * The queue here is deliberately much SMALLER than the writer count. An
   * earlier version of this test used a queue of 64 with 16 writers, where the
   * depth can never exceed 16 no matter what the code does -- the assertion was
   * vacuously true and stayed green even with the backpressure wait deleted.
   * With 32 writers against a queue of 4, the bound is genuinely contended, and
   * removing the wait on not_full drives the depth past 4 immediately. */
  enum { THREADS = 32, OPERATIONS = 8, CAPACITY = 4 };
  char *path = temporary_path("backpressure");
  hdl_log *log = NULL;
  hdl_broker *broker = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open backpressure log");
  hdl_broker_options options = {CAPACITY, 64, 250};
  require_status(hdl_broker_open(log, &options, &broker), HDL_OK, "open backpressure broker");
  pthread_t threads[THREADS];
  writer_args args[THREADS];
  for (int index = 0; index < THREADS; index++) {
    args[index] = (writer_args){log, broker, index, OPERATIONS, 0, NULL};
    if (pthread_create(&threads[index], NULL, writer, &args[index]) != 0) fail("create backpressure writer");
  }
  for (int index = 0; index < THREADS; index++) {
    pthread_join(threads[index], NULL);
    if (args[index].failures != 0) fail("backpressure refused a submission outright");
  }
  hdl_broker_stats stats;
  require_status(hdl_broker_get_stats(broker, &stats), HDL_OK, "backpressure stats");
  /* Every record still landed: backpressure throttles callers, it never drops. */
  if (stats.records != THREADS * OPERATIONS) fail("backpressure lost records");
  /* And the queue never exceeded the bound the caller configured. */
  if (stats.max_queue_depth > CAPACITY) fail("queue grew past its capacity");
  if (stats.max_queue_depth < CAPACITY) fail("queue never reached its bound; this test is not exercising backpressure");
  require_status(hdl_broker_close(broker), HDL_OK, "close backpressure broker");
  require_status(hdl_close(log), HDL_OK, "close backpressure log");
  remove_journal(path);
  free(path);
}

/* Sustained overload, rather than a burst.
 *
 * The short backpressure gate proves the bound is reached and held for eight
 * operations per writer. This one holds the queue at its bound for thousands of
 * records and then checks the log itself: every record that a submitter was told
 * was durable is on disk, in order, and group commit still combined under the
 * overload rather than degrading to one barrier per record.
 *
 * What this gate deliberately does NOT assert is a resident-memory bound. A
 * request is allocated on the SUBMITTER's stack, so memory here is bounded by
 * the number of threads whatever the queue does -- deleting the bound makes the
 * queue grow without making the process grow, and an RSS assertion would stay
 * green through exactly the defect it appears to be watching. The queue depth is
 * the observable that can actually go red, and it is the one asserted. */
static void backpressure_soak_test(void) {
  enum { THREADS = 16, OPERATIONS = 120, CAPACITY = 8 };
  char *directory = temporary_path("soak");
  hdl_log *log = NULL;
  hdl_broker *broker = NULL;
  require_status(hdl_open(directory, NULL, &log), HDL_OK, "open soak log");
  hdl_broker_options options = {CAPACITY, 64, 250};
  require_status(hdl_broker_open(log, &options, &broker), HDL_OK, "open soak broker");
  pthread_t threads[THREADS];
  writer_args args[THREADS];
  for (int index = 0; index < THREADS; index++) {
    args[index] = (writer_args){log, broker, index, OPERATIONS, 0, NULL};
    if (pthread_create(&threads[index], NULL, writer, &args[index]) != 0) fail("create soak writer");
  }
  for (int index = 0; index < THREADS; index++) {
    pthread_join(threads[index], NULL);
    if (args[index].failures != 0) fail("sustained overload refused a submission outright");
  }

  hdl_broker_stats stats;
  require_status(hdl_broker_get_stats(broker, &stats), HDL_OK, "soak stats");
  if (stats.records != THREADS * OPERATIONS) fail("sustained overload lost records");
  if (stats.max_queue_depth > CAPACITY) fail("the queue grew past its capacity under sustained load");
  if (stats.max_queue_depth < CAPACITY) fail("the queue never reached its bound; this soak is not overloading it");
  /* Group commit must survive the overload: if backpressure degraded it to one
     barrier per record, the queue would be bounded and the journal useless. */
  if (stats.durable_batches * 2 > stats.records) fail("group commit collapsed under sustained overload");
  require_status(hdl_broker_close(broker), HDL_OK, "close soak broker");

  /* And every acknowledged record is actually in the log, in order. */
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan soak log");
  if (state.invalid || state.count != THREADS * OPERATIONS) fail("sustained overload did not make every acknowledged record durable");
  require_status(hdl_close(log), HDL_OK, "close soak log");
  remove_journal(directory);
  free(directory);
}

typedef struct {
  hdl_broker *broker;
  const char *payload;
  hdl_status status;
} admission_args;

static void *occupying_writer(void *opaque) {
  admission_args *args = opaque;
  hdl_record record = {8, args->payload, (uint32_t)strlen(args->payload)};
  args->status = hdl_broker_submit(args->broker, &record, NULL);
  return NULL;
}

/* Backpressure has to be a refusal a caller can act on, not a hang.
 *
 * Raised in review against 0.2.0 and true until now: hdl_broker_submit waits on
 * queue space with no deadline, so an application that wants to shed load has no
 * way to give up -- and cannot cancel a native call that is already blocked
 * inside the extension. "The queue is bounded" and "the caller can stop waiting"
 * are different promises, and the soak only proved the first.
 *
 * The bound covers ADMISSION only, and the second assertion here is the one that
 * makes that safe to offer: a submission that was refused must NOT be in the log
 * afterwards. A deadline that left the record queued would be worse than
 * blocking, because the caller would have been told it was refused. */
static void admission_can_be_bounded_test(void) {
  char *directory = temporary_path("admission");
  hdl_log *log = NULL;
  hdl_broker *broker = NULL;
  require_status(hdl_open(directory, NULL, &log), HDL_OK, "open the admission log");
  /* One queue slot. The batch window is irrelevant here -- max_batch_records is
     clamped to the queue capacity, so the writer never waits for records the
     queue cannot hold, which is why an earlier version of this test could not
     fill the queue at all and refused nothing. What fills it is a SLOW BARRIER:
     one submission is in the writer's hands with the disk stalled, the next
     occupies the only queue slot, and the third has nowhere to go. */
  hdl_broker_options options = {1, 1, 250};
  require_status(hdl_broker_open(log, &options, &broker), HDL_OK, "open the admission broker");

  hdl_test_stall_next_sync_microseconds(500000);
  pthread_t occupiers[2];
  admission_args args = {broker, "the record that got in", HDL_OK};
  admission_args queued_args = {broker, "the record that waited", HDL_OK};
  if (pthread_create(&occupiers[0], NULL, occupying_writer, &args) != 0) fail("create the stalled writer");
  pause_microseconds(20000);
  if (pthread_create(&occupiers[1], NULL, occupying_writer, &queued_args) != 0) fail("create the queued writer");
  pause_microseconds(30000);

  const char refused_payload[] = "the record that was refused";
  hdl_record refused = {9, refused_payload, sizeof(refused_payload) - 1};
  hdl_receipt receipt;
  memset(&receipt, 0, sizeof(receipt));
  require_status(hdl_broker_submit_within(broker, &refused, 20000, &receipt), HDL_BUSY,
                 "a submission that cannot be admitted within its deadline must be refused, not blocked");
  if (receipt.first_sequence != 0) fail("a refused submission handed back a receipt");

  pthread_join(occupiers[0], NULL);
  pthread_join(occupiers[1], NULL);
  hdl_test_clear_failures();
  if (args.status != HDL_OK || queued_args.status != HDL_OK) {
    fail("a submission that was admitted was not accepted");
  }

  /* A caller told "refused" must be able to act on that, so the record has to be
     absent -- not merely late. */
  require_status(hdl_broker_close(broker), HDL_OK, "close the admission broker");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan the admission log");
  if (state.count != 2) fail("a refused submission reached the log anyway");

  hdl_cursor *cursor = NULL;
  require_status(hdl_cursor_open(log, &cursor), HDL_OK, "replay the admission log");
  hdl_cursor_record replayed;
  while (hdl_cursor_next(cursor, &replayed) == HDL_OK) {
    if (replayed.payload_length == sizeof(refused_payload) - 1 &&
        memcmp(replayed.payload, refused_payload, replayed.payload_length) == 0) {
      fail("the log holds the record that was refused");
    }
  }
  require_status(hdl_cursor_close(cursor), HDL_OK, "close the admission cursor");

  /* And an unbounded submission still behaves exactly as it did. */
  hdl_broker *patient = NULL;
  require_status(hdl_broker_open(log, &options, &patient), HDL_OK, "reopen the broker");
  hdl_record another = {9, "after the refusal", 17};
  require_status(hdl_broker_submit(patient, &another, NULL), HDL_OK, "an unbounded submission still waits");
  require_status(hdl_broker_close(patient), HDL_OK, "close the patient broker");

  require_status(hdl_close(log), HDL_OK, "close the admission log");
  remove_journal(directory);
  free(directory);
}

static void broker_group_commit_test(void) {
  enum { THREADS = 16, OPERATIONS = 20 };
  char *path = temporary_path("broker");
  hdl_log *log = NULL;
  hdl_broker *broker = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open broker log");
  hdl_broker_options options = {64, 64, 5000};
  require_status(hdl_broker_open(log, &options, &broker), HDL_OK, "open broker");
  hdl_test_barrier barrier;
  if (hdl_test_barrier_init(&barrier, THREADS) != 0) fail("create broker barrier");
  pthread_t threads[THREADS];
  writer_args args[THREADS];
  for (int index = 0; index < THREADS; index++) {
    args[index] = (writer_args){log, broker, index, OPERATIONS, 0, &barrier};
    if (pthread_create(&threads[index], NULL, writer, &args[index]) != 0) fail("create broker writer");
  }
  for (int index = 0; index < THREADS; index++) {
    pthread_join(threads[index], NULL);
    if (args[index].failures != 0) fail("broker append failure");
  }
  hdl_test_barrier_destroy(&barrier);
  hdl_broker_stats stats;
  require_status(hdl_broker_get_stats(broker, &stats), HDL_OK, "broker stats");
  if (stats.records != THREADS * OPERATIONS ||
      stats.durable_batches >= stats.records || stats.largest_batch < 2) {
    fail("broker did not group commits");
  }
  require_status(hdl_broker_close(broker), HDL_OK, "close broker");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan broker log");
  if (state.invalid || state.count != THREADS * OPERATIONS) fail("broker sequence integrity");
  require_status(hdl_close(log), HDL_OK, "close broker log");
  remove_journal(path);
  free(path);
}

int main(void) {
  one_writer_owns_a_journal_test();
  a_journal_is_a_directory_of_segments_test();
  rotation_preserves_the_log_test();
  a_failed_barrier_during_the_cut_publishes_nothing_test();
  a_cursor_resumes_where_it_stopped_test();
  resuming_before_the_origin_says_retired_test();
  a_snapshot_restores_the_identical_prefix_test();
  retirement_keeps_every_record_reachable_test();
  an_unverified_snapshot_retires_nothing_test();
  a_snapshot_whose_receipt_does_not_match_retires_nothing_test();
  an_unfinished_snapshot_retires_nothing_test();
  rotation_crash_matrix_test();
  basic_and_torn_tail_test();
  corruption_test();
  stale_frames_from_a_recycled_segment_test();
  an_empty_recycled_segment_replays_nothing_test();
  injected_short_write_test();
  failed_barrier_poisons_test();
  process_kill_test();
  durability_barrier_test();
  concurrency_test();
  backpressure_soak_test();
  admission_can_be_bounded_test();
  backpressure_bounds_the_queue_test();
  broker_group_commit_test();
  puts("PASS: durable log recovery and concurrency");
  return 0;
}
