/* Wrapper SQL for Sqlite3.query_rows_json / query_row_json (adapter.hey).
 *
 * Given the caller's prepared SELECT, builds
 *
 *   WITH hey_sqlite3_json_rows(c0,c1,...) AS (
 *   <caller SQL>
 *   ) SELECT json_group_array(json_object('name0',hey_sqlite3_json_value(c0,'name0'),...))
 *     FROM hey_sqlite3_json_rows
 *
 * (shape 1: rows) or `SELECT json_object(...) FROM hey_sqlite3_json_rows LIMIT 1`
 * (shape 2: one row). The CTE column list renames the caller's columns to
 * c0..cN, so a column name is never used as an identifier: it appears only as
 * a single-quoted key literal, with every ' doubled. Names with quotes,
 * spaces, backslashes or that are expressions such as count(*) need nothing
 * else. Columns listed in json_columns are wrapped in json() so their text
 * nests as JSON.
 *
 * This was Hey code first; building the text here is one FFI call instead of
 * one per column plus Hey string work, which measured 17 us of a 57 us
 * 20-row feed (tools/json_bench.hey).
 *
 * The result is a borrowed UTF-8 view into a thread-local buffer. The function
 * is declared non-blocking in hey.native.json, so it runs on the calling
 * thread and the runtime copies the view before that thread can call it again.
 *
 * The first byte is a status:
 *   '0' the wrapper SQL follows
 *   '1' the statement returns no columns
 *   '2' two columns share a name; the name follows
 *   '3' a json_columns entry is not a column; the entry follows
 *   '4' out of memory, or a malformed json_columns argument
 *
 * json_columns is a list of length-prefixed names, "<bytes>:<name>" repeated
 * (e.g. "4:meta3:tag"), so any name, whatever it contains, survives intact. */
#include "hey_sqlite3.h"
#include <sqlite3.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct HeySqlite3Text {
  char *data;
  size_t length;
  size_t capacity;
  int failed;
} HeySqlite3Text;

static _Thread_local HeySqlite3Text hey_sqlite3_json_out;

static void hey_sqlite3_text_append(HeySqlite3Text *text, const char *data, size_t length) {
  if (text->failed) return;
  if (text->length + length + 1 > text->capacity) {
    size_t capacity = text->capacity ? text->capacity : 1024;
    while (capacity < text->length + length + 1) capacity *= 2;
    char *grown = (char *)realloc(text->data, capacity);
    if (!grown) {
      text->failed = 1;
      return;
    }
    text->data = grown;
    text->capacity = capacity;
  }
  if (length) memcpy(text->data + text->length, data, length);
  text->length += length;
  text->data[text->length] = '\0';
}

static void hey_sqlite3_text_append_c(HeySqlite3Text *text, const char *data) {
  hey_sqlite3_text_append(text, data, strlen(data));
}

/* 'name' with every ' doubled: an SQL string literal. */
static void hey_sqlite3_text_append_literal(HeySqlite3Text *text, const char *name) {
  hey_sqlite3_text_append(text, "'", 1);
  const char *start = name;
#ifdef HEY_SQLITE3_NEGATIVE_CONTROL_JSON_QUOTES
  /* Negative control for specs/json_spec.hey: quotes are not doubled. */
  hey_sqlite3_text_append_c(text, name);
  hey_sqlite3_text_append(text, "'", 1);
  return;
#endif
  for (const char *p = name; *p; p++) {
    if (*p == '\'') {
      hey_sqlite3_text_append(text, start, (size_t)(p - start) + 1);
      hey_sqlite3_text_append(text, "'", 1);
      start = p + 1;
    }
  }
  hey_sqlite3_text_append_c(text, start);
  hey_sqlite3_text_append(text, "'", 1);
}

static void hey_sqlite3_text_append_index(HeySqlite3Text *text, int index) {
  char digits[16];
  int n = 0;
  unsigned value = (unsigned)index;
  do {
    digits[n++] = (char)('0' + value % 10);
    value /= 10;
  } while (value && n < (int)sizeof(digits));
  while (n > 0) hey_sqlite3_text_append(text, &digits[--n], 1);
}

static HeyNativeUtf8View hey_sqlite3_json_status(char status, const char *detail, size_t detail_length) {
  HeySqlite3Text *out = &hey_sqlite3_json_out;
  out->length = 0;
  out->failed = 0;
  hey_sqlite3_text_append(out, &status, 1);
  if (detail) hey_sqlite3_text_append(out, detail, detail_length);
  if (out->failed) {
    static const char oom[] = "4";
    HeyNativeUtf8View view = {oom, 1};
    return view;
  }
  HeyNativeUtf8View view = {out->data, out->length};
  return view;
}

/* Is name (NUL-terminated) one of the length-prefixed json_columns? -1 when
   json_columns is malformed. */
static int hey_sqlite3_json_listed(HeyNativeUtf8View list, const char *name) {
  size_t name_length = strlen(name);
  size_t i = 0;
  while (i < list.length) {
    size_t length = 0;
    int digits = 0;
    while (i < list.length && list.data[i] >= '0' && list.data[i] <= '9') {
      length = length * 10 + (size_t)(list.data[i] - '0');
      i++;
      digits++;
    }
    if (!digits || i >= list.length || list.data[i] != ':') return -1;
    i++;
    if (length > list.length - i) return -1;
    if (length == name_length && memcmp(list.data + i, name, length) == 0) return 1;
    i += length;
  }
  return 0;
}

static int hey_sqlite3_json_is_space(char c) {
  return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v';
}

HeyNativeUtf8View hey_sqlite3_json_wrapper(HeyNativeHandle statement, HeyNativeUtf8View sql, int32_t shape, HeyNativeUtf8View json_columns) {
  sqlite3_stmt *stmt = (sqlite3_stmt *)(uintptr_t)statement;
  int count = stmt ? sqlite3_column_count(stmt) : 0;
  if (count <= 0) return hey_sqlite3_json_status('1', NULL, 0);

  const char **names = (const char **)malloc(sizeof(char *) * (size_t)count);
  if (!names) return hey_sqlite3_json_status('4', NULL, 0);
  for (int i = 0; i < count; i++) {
    names[i] = sqlite3_column_name(stmt, i);
    if (!names[i]) {
      free(names);
      return hey_sqlite3_json_status('4', NULL, 0);
    }
    for (int j = 0; j < i; j++) {
      if (strcmp(names[i], names[j]) == 0) {
        HeyNativeUtf8View dup = hey_sqlite3_json_status('2', names[i], strlen(names[i]));
        free(names);
        return dup;
      }
    }
  }

  /* Every json_columns entry must name a column (catches typos). */
  size_t i = 0;
  while (i < json_columns.length) {
    size_t length = 0;
    int digits = 0;
    while (i < json_columns.length && json_columns.data[i] >= '0' && json_columns.data[i] <= '9') {
      length = length * 10 + (size_t)(json_columns.data[i] - '0');
      i++;
      digits++;
    }
    if (!digits || i >= json_columns.length || json_columns.data[i] != ':' || length > json_columns.length - i - 1) {
      free(names);
      return hey_sqlite3_json_status('4', NULL, 0);
    }
    i++;
    int found = 0;
    for (int c = 0; c < count && !found; c++) {
      found = strlen(names[c]) == length && memcmp(names[c], json_columns.data + i, length) == 0;
    }
    if (!found) {
      free(names);
      return hey_sqlite3_json_status('3', json_columns.data + i, length);
    }
    i += length;
  }

  /* The caller's SQL without trailing whitespace and semicolons: a ';' inside
     the CTE body would end the statement. A second statement after the first
     is left in place, so the wrapper fails to prepare and nothing runs. */
  size_t sql_length = sql.length;
  while (sql_length > 0 && (hey_sqlite3_json_is_space(sql.data[sql_length - 1]) || sql.data[sql_length - 1] == ';')) sql_length--;

  HeySqlite3Text *out = &hey_sqlite3_json_out;
  out->length = 0;
  out->failed = 0;
  hey_sqlite3_text_append(out, "0", 1);
  hey_sqlite3_text_append_c(out, "WITH hey_sqlite3_json_rows(");
  for (int c = 0; c < count; c++) {
    if (c) hey_sqlite3_text_append(out, ",", 1);
    hey_sqlite3_text_append(out, "c", 1);
    hey_sqlite3_text_append_index(out, c);
  }
  /* newline before ')': a trailing -- comment in the caller's SQL ends there */
  hey_sqlite3_text_append_c(out, ") AS (\n");
  hey_sqlite3_text_append(out, sql.data, sql_length);
  hey_sqlite3_text_append_c(out, "\n) SELECT ");
  if (shape == 1) hey_sqlite3_text_append_c(out, "json_group_array(");
  hey_sqlite3_text_append_c(out, "json_object(");
  for (int c = 0; c < count; c++) {
    int nested = hey_sqlite3_json_listed(json_columns, names[c]) == 1;
    if (c) hey_sqlite3_text_append(out, ",", 1);
    hey_sqlite3_text_append_literal(out, names[c]);
    hey_sqlite3_text_append(out, ",", 1);
    if (nested) hey_sqlite3_text_append_c(out, "json(");
    hey_sqlite3_text_append_c(out, "hey_sqlite3_json_value(c");
    hey_sqlite3_text_append_index(out, c);
    hey_sqlite3_text_append(out, ",", 1);
    hey_sqlite3_text_append_literal(out, names[c]);
    hey_sqlite3_text_append(out, ")", 1);
    if (nested) hey_sqlite3_text_append(out, ")", 1);
  }
  hey_sqlite3_text_append(out, ")", 1);
#ifdef HEY_SQLITE3_NEGATIVE_CONTROL_JSON_ORDER
  /* Negative control for specs/json_spec.hey: the rows are re-sorted by
     their first column, so the caller's ORDER BY is lost. */
  if (shape == 1) hey_sqlite3_text_append_c(out, ") FROM (SELECT * FROM hey_sqlite3_json_rows ORDER BY 1)");
#else
  if (shape == 1) hey_sqlite3_text_append_c(out, ") FROM hey_sqlite3_json_rows");
#endif
  else hey_sqlite3_text_append_c(out, " FROM hey_sqlite3_json_rows LIMIT 1");
  free(names);

  if (out->failed) return hey_sqlite3_json_status('4', NULL, 0);
  HeyNativeUtf8View view = {out->data, out->length};
  return view;
}
