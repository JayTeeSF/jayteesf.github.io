/* hey_android runtime profile: resolves the Hey runtime's <CommonCrypto/CommonDigest.h>
 * on Android. See ../hey_android_platform_crypto.h. */
#include "../hey_android_platform_crypto.h"
