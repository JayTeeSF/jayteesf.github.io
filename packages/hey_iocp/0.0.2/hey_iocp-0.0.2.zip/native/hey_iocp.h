#ifndef HEY_IOCP_H
#define HEY_IOCP_H

#include "hey_native_abi.h"

/* One event loop: a nonblocking TCP listener plus every connection it accepted,
   multiplexed by an I/O completion port (Windows x64).
   A loop is owned by exactly one Hey thread. */
HeyNativeHandle hey_iocp_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport);
int32_t hey_iocp_close(HeyNativeHandle loop);
int32_t hey_iocp_wait(HeyNativeHandle loop, int32_t timeout_ms);
int64_t hey_iocp_next(HeyNativeHandle loop);
HeyNativeUtf8View hey_iocp_data(HeyNativeHandle loop, int64_t connection);
int32_t hey_iocp_send(HeyNativeHandle loop, int64_t connection, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after);
int32_t hey_iocp_drop(HeyNativeHandle loop, int64_t connection);
int32_t hey_iocp_port(HeyNativeHandle loop);
HeyNativeUtf8View hey_iocp_stats(HeyNativeHandle loop);
HeyNativeUtf8View hey_iocp_backend(void);

#endif
