# hey_reports 0.1.1

Charts for Hey applications — bar, line and pie, with axes, tick
labels, axis titles and legends — rendered as **SVG** for the web and
as a **`hey-tv-scene-v2` widget document** for television.

```hey
import 'pkg:hey_reports@0.1.1/main'

let chart = Reports.labelled(
  Reports.chart('bar', 'Signups by day',
    ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    [Reports.series('Web',    [120, 305, 210, 380, 260]),
     Reports.series('Mobile', [ 90, 150, 260, 210, 340]),
     Reports.series('TV',     [ 20,  40,  35,  60,  55])]),
  'Weekday', 'Signups')

let svg = ReportsSvg.render(chart, ReportsTheme.web())
```

That produces a 4947-byte SVG document that `rsvg-convert` — a renderer
with no knowledge of Hey — rasterises to a 16980-byte PNG. Both numbers
are asserted by `bin/check`.

---

## The chart model

The model is the portable part, and it is deliberately small.

| function | what it does |
|---|---|
| `Reports.series(label, points)` | one named run of values, positional against the categories |
| `Reports.chart(kind, title, categories, series)` | `kind` is `'bar'`, `'line'` or `'pie'` |
| `Reports.labelled(chart, x_label, y_label)` | axis titles |
| `Reports.validate(chart)` | `{ok, error}` — a reason, not a crash |
| `Reports.bounds(chart)` | data extent; **always includes 0 for bar charts** |
| `Reports.ticks(lo, hi, target)` | "nice" tick values, snapped outward to round numbers |
| `Reports.project(value, dmin, dmax, p0, p1)` | a data value → a whole pixel |
| `Reports.band_centre(i, n, p0, p1)` | evenly spaced category positions |
| `Reports.pie_angles(values)` | slice angles in tenths of a degree; the last slice absorbs the remainder so the pie always closes |

The model contains **no markup, no widget, no colour, and no pixel it
did not compute from a range it was handed**. Surface facts — canvas
size, safe area, fonts, palette — live entirely in a *theme*.

`Reports.bounds` forcing zero onto a bar chart's axis is a judgement,
not an oversight: a bar chart with a non-zero baseline exaggerates
differences, which is a lie told with a chart. Line charts do not force
zero, because a trend between 5 and 9 would be a flat smear against a
0–9 axis.

## The renderer split

```
              Reports (model)  +  ReportsTheme (surface facts)
                        |                 |
            +-----------+-----------------+-----------+
            |                                         |
      ReportsSvg                               ReportsScene
      SVG document                             hey-tv-scene-v2 doc
      web, mobile                              television
```

**What is portable is the model. Renderers are not portable, and this
package does not pretend otherwise.** `specs/main_spec.hey` hands one
chart object to three renderers and then prints the object, to prove no
renderer reached in and changed it.

### Why SVG

It is text, so Hey emits it with no binary encoder, no DEFLATE, no font
rasteriser and no image library — none of which exist in this language.
It is vector, so one document is correct at 360px and at 1920px, which
matters here because the same report has to work on a phone and across
a room.

### Themes

```hey
ReportsTheme.web()     # 800x480,   light surface
ReportsTheme.mobile()  # 360x280,   light surface
ReportsTheme.tv()      # 1920x1080, dark surface, overscan-safe, 28px font floor
```

The TV theme is not the web theme scaled up. Television is a different
optical problem: consumer sets crop the edge of the signal, so the plot
is inset 5% on all four sides (96 × 54 px); 10-foot viewing puts a hard
floor under glyph size, so `clamp_font` refuses to go below 28px even
when a label would fit better small; and a dim room wants a dark
surface with the palette's dark steps, not the light steps on a dark
background.

---

## Surfaces: what is PROVED and what is DESIGNED FOR

This is in the API, not just this file — `HeyReports.surfaces()` returns
it, so a caller does not have to trust a README.

| surface | renderer | status | chart kinds |
|---|---|---|---|
| **web** | SVG | **proved** | bar, line, pie |
| mobile | SVG | designed | bar, line, pie |
| tv | `hey-tv-scene-v2` | designed | **bar only** |

**Proved** means a chart was rendered from real data and the output was
verified by an INDEPENDENT renderer — not by this package's assertions
about its own strings. `bin/check` runs `rsvg-convert` (librsvg 2.62.3 /
cairo) over five documents and asserts a byte-length floor on every
PNG.

**Designed** means the output matches a contract that was read, and no
device ran it here.

- **Mobile** is served by the same SVG in a WebView. `hey_mobile`'s
  `ui.hey` is 13 lines of screen/action metadata with no drawing
  vocabulary, so there is nothing native to target yet. The SVG is
  valid and the theme is right; no phone displayed it.
- **Television** emits `text` and `rect` widgets and is validated by
  **hey_tv's own `Television.validate_scene`, running hey_tv's own
  source**, with a negative control asserting that an invented widget
  kind is rejected. No Apple TV rendered it.

### The honest answer to "can one package serve all three surfaces?"

**The same chart MODEL can. The renderer cannot, and two of the three
surfaces are limited by their own packages rather than by this one.**

Specifically:

- **SVG cannot reach a television.** `SCENE_CONTRACT.md` says an
  `image` widget's symbol may be "an SF symbol name, bundled asset
  name, or data URI". The renderer behind it,
  `hey_ios_tv/tools/hey_native_tv_runtime.m:826`, is
  `[UIImage systemImageNamed:symbol]` and nothing else — SF symbols
  only, no data URI, no SVG decoder anywhere in the file.
- **Television gets bars and only bars.** scene-v2 lays widgets out in
  three vertical slot columns with no absolute x/y
  (`:714-733`), and `rect` reads only `width`/`height` (`:889-899`).
  A horizontal bar chart maps onto that exactly. A line chart needs
  arbitrary points and a pie needs arcs, so **both are refused with a
  reason** rather than degraded into bars — a line chart silently drawn
  as bars would be a lie about the data.

`hey_ui_contract` was read first, as instructed, and **it cannot carry a
chart**: 32 lines whose entire vocabulary is `capability(id, label,
action, resource)`, `screen(...)` and `surface(name, capabilities)`.
No geometry, no coordinate, no colour, no length. Targeting it would
have been ceremony, not reuse. The abstraction that IS worth targeting
is hey_tv's scene-v2, because it has a real 1198-line native renderer
behind it — and this package renders into it rather than inventing a
third widget vocabulary.

---

## Two traps this package exists partly to handle

**`len()` on a string returns BYTES.** `len('a—b')` is 5 for a
3-character string. Every axis label is text layout, so a byte-based
gutter is silently too wide for any label with an accent, a dash or a
currency symbol. `ReportsText.char_count` walks the UTF-8 with
`bytes()`/`byte_at()`. And the width it produces is only used for
gutters and legend boxes — **actual centring is `text-anchor`**, which
uses the rendering engine's real font metrics, so the package's
weakest number can never mis-centre a label.

**SVG is XML.** Every label and every value goes through
`ReportsText.escape_xml`, ampersand first so `<` does not become
`&amp;lt;`. `specs/svg_spec.hey` puts `<script>alert('pwn')</script>`
in a series label, a category and a title and asserts the string
`<script` does not appear in the output. The scene renderer
deliberately does **not** escape — a scene is JSON for a native UIKit
renderer, and escaping there would put a literal `&amp;` on a
television screen.

---

## What is NOT built

**No raster output of any kind.** No PNG, no JPEG. A pure-Hey PNG
encoder needs a polygon rasteriser, a TrueType font engine, DEFLATE and
a colour pipeline — a multi-week research project in a language with no
mutable buffers, and it would be the least-tested code in the ecosystem
on the day it landed. `src/raster.hey` costs it out and implements none
of it. `ReportsRaster.argv` builds a command line for `rsvg-convert` or
`resvg` and **runs nothing**; conversion is the caller's dependency and
the caller's failure. (`ReportsSvg.data_uri` covers the common case
with no conversion at all — browsers and WebViews rasterise SVG
natively.)

**No line or pie charts on television.** Blocked on scene-v2, not on
effort. See above.

**No native mobile renderer.** Blocked on `hey_mobile` having no
drawing vocabulary.

**No floating point.** The package is integer-only, deliberately: in
the compiled lane a float passed as a function parameter is truncated
to an integer, which made the first version of the scale one pixel
wrong in the binary and correct in the interpreter. `ReportsGeometry`
carries a whole-degree sine table (×10⁶, interpolated across tenths)
instead of a Taylor series. Accuracy is 0.008px at a 500px radius, and
identical in both lanes — which is the trade that matters.

**No fractional axis ticks.** `nice_step` returns an integer, so a
domain narrower than the tick target collapses to step 1. Pass cents,
not dollars.

**No interactivity, no real font metrics, no visual regression
baseline, no performance measurement.** No device ran anything.

---

## Testing

```sh
bin/check
```

Runs every spec in **both lanes** — interpreter and compiled binary —
and **diffs their stdout**. This is not ceremony: during construction
the two lanes disagreed four separate times, silently, exit 0 in both.
A green in one lane is not a green. Every gate in the suite has been
seen RED on purpose; `docs/TESTING.md` records what each failure looked
like, including one gate that turned out to be unable to fail at all.

## Layout

```
src/model.hey      the chart model      — no surface, no markup
src/theme.hey      surface presets      — web / mobile / tv
src/svg.hey        SVG renderer
src/scene.hey      hey-tv-scene-v2 renderer
src/text.hey       XML escaping + UTF-8 measurement
src/geometry.hey   integer-angle trigonometry (pie only)
src/raster.hey     the raster refusal, costed
src/main.hey       entry point
```

Dependencies: none. `hey_packager` conventions are followed for
`bin/check`, the manifest shape and the docs layout.

Release-READY and unpublished: local commits only, no remote.
