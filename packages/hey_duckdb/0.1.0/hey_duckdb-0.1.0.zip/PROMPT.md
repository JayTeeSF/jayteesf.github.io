# hey_duckdb

Native DuckDB adapter for Hey over the DuckDB C API. Public API in `adapter.hey`
(`DuckDB`); low-level ownership in `Native.hey` (`DuckdbNative`); C shim in
`native/`. Build with `bin/build-native`; verify with `bin/check`. See
`PACKAGE_SPEC.md` for the authoritative contract.
