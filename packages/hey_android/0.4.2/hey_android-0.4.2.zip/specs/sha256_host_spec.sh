#!/usr/bin/env bash
# The selected Hey runtime's in-tree SHA-256 against the same NIST vectors used
# by the Android emulator lane. Both text and file hashing must agree.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-sha256.XXXXXX")
trap 'rm -rf "$work"' EXIT

[ -x "$HEY_ROOT/bin/heyc" ] || { echo "FAIL: no heyc at $HEY_ROOT/bin/heyc"; exit 1; }

vectors=$ROOT/specs/sha256_vectors.txt
expected=$work/expected.txt
awk 'NF == 2 && $1 !~ /^#/ { print "text " $1 " " $2; print "file " $1 " " $2 }' "$vectors" > "$expected"

(
  cd "$work" || exit 1
  env HEY_ROOT="$HEY_ROOT" HEY_STDLIB_PATH="$HEY_ROOT/stdlib" HEY_COMPILER_BUILD_DIR="$HEY_ROOT/build" \
    "$HEY_ROOT/bin/heyc" "$ROOT/examples/sha256_vectors.hey" --run
) > "$work/runtime.txt" 2> "$work/runtime.err" || {
  cat "$work/runtime.err" >&2
  echo 'FAIL: the selected Hey runtime could not run the SHA-256 vectors'
  exit 1
}

if cmp -s "$expected" "$work/runtime.txt"; then
  total=$(grep -cvE '^(#|$)' "$vectors")
  echo "PASS: the selected Hey runtime matches all $total NIST SHA-256 vectors for text and files"
else
  echo 'FAIL: the selected Hey runtime disagrees with the NIST SHA-256 vectors'
  diff -u "$expected" "$work/runtime.txt" | sed -n '1,24p'
  failed=1
fi

vector_input() {
  case "$1" in
    empty) printf '' ;;
    abc) printf 'abc' ;;
    nist448) printf '%s' 'abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq' ;;
    nist896) printf '%s' 'abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu' ;;
    million_a) head -c 1000000 /dev/zero | tr '\0' a ;;
    *) return 1 ;;
  esac
}

bad=0
while read -r name digest; do
  case "$name" in ''|\#*) continue ;; esac
  got=$(vector_input "$name" | shasum -a 256 | cut -c1-64)
  [ "$got" = "$digest" ] || { echo "FAIL: shasum vector $name got $got want $digest"; bad=1; }
done < "$vectors"
if [ "$bad" = 0 ]; then
  echo 'PASS: host shasum independently agrees with the vector file'
else
  failed=1
fi

cp "$expected" "$work/wrong.txt"
sed -i.bak 's/^text abc ba7816bf/text abc ba7816bE/' "$work/wrong.txt"
if cmp -s "$work/wrong.txt" "$work/runtime.txt"; then
  echo 'FAIL (control): a wrong digest was accepted'
  failed=1
else
  echo 'PASS (control): a wrong digest differs from runtime output'
fi

exit $failed
