package hey.android.api;

import java.util.ArrayList;
import java.util.List;

/** Host proof of HeyAndroidPictureBudget: no device, no android.* classes. */
public final class PictureBudgetCheck {
  private static int failures;

  private static void check(boolean ok, String what) {
    System.out.println((ok ? "  ok   " : "  FAIL ") + what);
    if (!ok) failures++;
  }

  public static void main(String[] args) {
    // SOURCE: refused from declared bounds alone.
    check(HeyAndroidPictureBudget.acceptable(6000, 4000), "a 24-megapixel photo may be decoded");
    check(!HeyAndroidPictureBudget.acceptable(20000, 20000), "a 400-megapixel bomb is refused before decoding");
    check(!HeyAndroidPictureBudget.acceptable(12001, 10), "a side over 12000 is refused even when thin");
    check(!HeyAndroidPictureBudget.acceptable(8000, 6000), "48 megapixels is over the 40-megapixel source budget");
    check(!HeyAndroidPictureBudget.acceptable(0, 100) && !HeyAndroidPictureBudget.acceptable(-1, -1), "an unreadable header is refused");

    // DECODE: sampled to where it is drawn.
    check(HeyAndroidPictureBudget.sampleSize(300, 450, HeyAndroidPictureBudget.ROW_SIDE) == 1, "a small poster is decoded whole");
    int rowSample = HeyAndroidPictureBudget.sampleSize(6000, 4000, HeyAndroidPictureBudget.ROW_SIDE);
    check(6000 / rowSample <= HeyAndroidPictureBudget.ROW_SIDE && 6000 / (rowSample / 2) > HeyAndroidPictureBudget.ROW_SIDE,
        "a 6000-pixel photo in a row is sampled by the smallest power of two that fits 512 (" + rowSample + ")");
    int fullSample = HeyAndroidPictureBudget.sampleSize(6000, 4000, HeyAndroidPictureBudget.FULL_SIDE);
    check(fullSample == 4, "the same photo at the top of a screen is sampled by 4 (1500 x 1000)");
    long worstRow = 4L * (HeyAndroidPictureBudget.MAX_SOURCE_SIDE / HeyAndroidPictureBudget.sampleSize(12000, 3333, 512)) * (3333 / HeyAndroidPictureBudget.sampleSize(12000, 3333, 512));
    check(worstRow < 1024 * 1024, "the largest accepted source costs a row under 1 MiB decoded (" + worstRow + " bytes)");

    // HELD: bounded by bytes, oldest first, nothing over a quarter.
    check(HeyAndroidPictureBudget.heldBudget(64L << 20) == 8L << 20, "a 64 MiB heap holds 8 MiB of pictures");
    check(HeyAndroidPictureBudget.heldBudget(512L << 20) == 48L << 20, "a 512 MiB heap is capped at 48 MiB");
    HeyAndroidPictureBudget.Held<long[]> held = new HeyAndroidPictureBudget.Held<>(1000, v -> v[0]);
    for (int i = 0; i < 50; i++) held.put("p" + i, new long[] {100});
    check(held.total() <= 1000 && held.size() == 10, "fifty 100-byte pictures in a 1000-byte budget keep the newest ten");
    check(held.get("p0") == null && held.get("p49") != null, "the oldest went first");
    held.get("p40");
    held.put("p50", new long[] {100});
    check(held.get("p40") != null && held.get("p41") == null, "drawing one again keeps it; the least recently drawn goes");
    check(!held.put("huge", new long[] {251}) && held.get("huge") == null, "one picture over a quarter of the budget is drawn but not kept");
    held.put("p50", new long[] {200});
    check(held.total() <= 1000, "replacing a picture counts its new size, not both");
    held.clear();
    check(held.total() == 0 && held.size() == 0, "clearing empties the budget");

    // WAITING: one fetch per picture, and a cap.
    HeyAndroidPictureBudget.Waiting<String> waiting = new HeyAndroidPictureBudget.Waiting<>(3);
    check(waiting.join("a", "row1") == HeyAndroidPictureBudget.Waiting.Joined.FETCH, "the first row asking starts the fetch");
    check(waiting.join("a", "row2") == HeyAndroidPictureBudget.Waiting.Joined.JOINED, "a second row asking for it joins that fetch");
    waiting.join("b", "row3");
    waiting.join("c", "row4");
    check(waiting.join("d", "row5") == HeyAndroidPictureBudget.Waiting.Joined.FULL, "past the cap a new picture is not queued");
    check(waiting.join("c", "row6") == HeyAndroidPictureBudget.Waiting.Joined.JOINED, "but joining one already under way still works");
    List<String> told = waiting.finish("a");
    check(told.equals(List.of("row1", "row2")), "when it lands, every row that waited is told, in order");
    check(waiting.join("d", "row5") == HeyAndroidPictureBudget.Waiting.Joined.FETCH, "a finished fetch frees a place");
    waiting.clear();
    check(waiting.finish("b").isEmpty(), "after a session change nobody is told about an old fetch");

    if (failures > 0) {
      System.out.println("picture budget: " + failures + " failure(s)");
      System.exit(1);
    }
    System.out.println("picture budget: all passed");
  }
}
