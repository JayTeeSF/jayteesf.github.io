#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log.h"
#include "test_barrier.h"
#include "test_hooks.h"

#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
  int count;
  uint64_t expected_sequence;
  int invalid;
} scan_state;

static void fail(const char *message) {
  fprintf(stderr, "FAIL: %s\n", message);
  exit(1);
}

static void require_status(hdl_status actual, hdl_status expected, const char *context) {
  if (actual != expected) {
    fprintf(stderr, "FAIL: %s: expected %s, got %s\n", context,
            hdl_status_name(expected), hdl_status_name(actual));
    exit(1);
  }
}

static int collect(void *opaque, uint64_t sequence, uint64_t batch_id,
                   uint64_t stream_id, const void *payload, uint32_t payload_length) {
  scan_state *state = opaque;
  if (sequence != state->expected_sequence || batch_id == 0 || stream_id == 0 ||
      payload == NULL || payload_length == 0) state->invalid = 1;
  state->expected_sequence++;
  state->count++;
  return 0;
}

static char *temporary_path(const char *label) {
  size_t length = strlen(label) + 32;
  char *path = malloc(length);
  if (path == NULL) fail("allocate temporary path");
  snprintf(path, length, "/tmp/hdl-%s-XXXXXX", label);
  int fd = mkstemp(path);
  if (fd < 0) fail("mkstemp");
  close(fd);
  unlink(path);
  return path;
}

static off_t file_size(const char *path) {
  struct stat value;
  if (stat(path, &value) != 0) fail("stat");
  return value.st_size;
}

static void copy_prefix(const char *source, const char *target, off_t length) {
  int input = open(source, O_RDONLY);
  int output = open(target, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (input < 0 || output < 0) fail("open copy");
  unsigned char buffer[4096];
  off_t copied = 0;
  while (copied < length) {
    size_t wanted = (size_t)(length - copied);
    if (wanted > sizeof(buffer)) wanted = sizeof(buffer);
    ssize_t got = read(input, buffer, wanted);
    if (got <= 0) fail("read copy");
    size_t written = 0;
    while (written < (size_t)got) {
      ssize_t count = write(output, buffer + written, (size_t)got - written);
      if (count <= 0) fail("write copy");
      written += (size_t)count;
    }
    copied += got;
  }
  close(input);
  close(output);
}

static void basic_and_torn_tail_test(void) {
  char *source = temporary_path("source");
  hdl_log *log = NULL;
  require_status(hdl_open(source, NULL, &log), HDL_OK, "open source");
  const char *first_payloads[] = {"one", "two", "three"};
  hdl_record first[3];
  for (int index = 0; index < 3; index++) {
    first[index] = (hdl_record){11, first_payloads[index], (uint32_t)strlen(first_payloads[index])};
  }
  hdl_receipt first_receipt;
  require_status(hdl_append_batch(log, first, 3, &first_receipt), HDL_OK, "first batch");
  const char *second_payloads[] = {"four", "five"};
  hdl_record second[2];
  for (int index = 0; index < 2; index++) {
    second[index] = (hdl_record){22, second_payloads[index], (uint32_t)strlen(second_payloads[index])};
  }
  hdl_receipt second_receipt;
  require_status(hdl_append_batch(log, second, 2, &second_receipt), HDL_OK, "second batch");
  if (first_receipt.last_sequence != 3 || second_receipt.last_sequence != 5) fail("receipt sequences");

  hdl_cursor *cursor = NULL;
  require_status(hdl_cursor_open(log, &cursor), HDL_OK, "open replay cursor");
  for (uint64_t expected = 1; expected <= 5; expected++) {
    hdl_cursor_record replayed;
    require_status(hdl_cursor_next(cursor, &replayed), HDL_OK, "read replay cursor");
    if (replayed.sequence != expected || replayed.batch_id != (expected <= 3 ? 1 : 2) ||
        replayed.stream_id != (expected <= 3 ? 11 : 22) || replayed.payload_length == 0) {
      fail("replay cursor record");
    }
  }
  hdl_cursor_record finished;
  require_status(hdl_cursor_next(cursor, &finished), HDL_DONE, "finish replay cursor");
  require_status(hdl_cursor_close(cursor), HDL_OK, "close replay cursor");
  require_status(hdl_close(log), HDL_OK, "close source");

  off_t total = file_size(source);
  for (off_t cut = 64; cut <= total; cut++) {
    char *candidate = temporary_path("cut");
    copy_prefix(source, candidate, cut);
    require_status(hdl_open(candidate, NULL, &log), HDL_OK, "recover truncated tail");
    scan_state state = {0, 1, 0};
    require_status(hdl_scan(log, collect, &state), HDL_OK, "scan recovered tail");
    int expected = cut >= (off_t)second_receipt.durable_offset ? 5
                 : cut >= (off_t)first_receipt.durable_offset ? 3 : 0;
    if (state.invalid || state.count != expected) fail("torn-tail committed prefix");
    require_status(hdl_close(log), HDL_OK, "close recovered tail");
    unlink(candidate);
    free(candidate);
  }
  unlink(source);
  free(source);
}

static void corruption_test(void) {
  char *path = temporary_path("corrupt");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open corruption log");
  const char payload[] = "committed";
  hdl_record record = {9, payload, sizeof(payload) - 1};
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_OK, "append corruption record");
  require_status(hdl_close(log), HDL_OK, "close corruption log");
  int fd = open(path, O_RDWR);
  if (fd < 0) fail("open for corruption");
  unsigned char value;
  if (pread(fd, &value, 1, 64 + 48) != 1) fail("read corruption byte");
  value ^= 0x40;
  if (pwrite(fd, &value, 1, 64 + 48) != 1) fail("write corruption byte");
  close(fd);
  require_status(hdl_open(path, NULL, &log), HDL_CORRUPTION, "fail closed corruption");
  unlink(path);
  free(path);
}

/* Each injected fault gets its OWN log handle.
 *
 * That is forced by the semantics, not by tidiness: a failed durability
 * barrier poisons the handle, so a second fault injected into the same handle
 * would be answered by the poison rather than exercising the fault. Sharing one
 * handle would have quietly stopped testing the second failure mode. */
static void injected_short_write_test(void) {
  char *path = temporary_path("failure-write");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open short-write log");
  const char payload[] = "must not acknowledge";
  hdl_record record = {7, payload, sizeof(payload) - 1};

  hdl_test_fail_write_after_bytes(17);
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_IO, "short write refusal");
  hdl_test_clear_failures();
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after short write");
  if (state.count != 0) fail("short write became visible");

  /* A failed WRITE must NOT poison. The bytes did not all reach the file and
     the rollback returned it to a state we still know, so the handle can still
     tell the truth about durability. Only a failed BARRIER destroys that
     knowledge. Conflating the two would make every transient write error cost a
     reopen for no gain in safety. */
  hdl_receipt receipt;
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_OK, "a short write must not poison the handle");
  if (receipt.first_sequence != 1) fail("short write consumed a sequence");
  require_status(hdl_close(log), HDL_OK, "close short-write log");
  unlink(path);
  free(path);
}

static void failed_barrier_poisons_test(void) {
  char *path = temporary_path("failure-sync");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open sync-failure log");
  const char payload[] = "must not acknowledge";
  hdl_record record = {7, payload, sizeof(payload) - 1};

  hdl_test_fail_next_sync();
  require_status(hdl_append_batch(log, &record, 1, NULL), HDL_IO, "sync failure refusal");
  hdl_test_clear_failures();
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan after sync failure");
  if (state.count != 0) fail("failed sync became visible");

  /* Once a durability barrier has FAILED, this handle can no longer tell the
   * truth about what is durable, so it must never issue another
   * acknowledgement. The kernel reports a writeback error once and then clears
   * it: a later fsync on the same descriptor can return success while the
   * earlier data is permanently gone. Rebello et al. (USENIX ATC '20) measured
   * ext4 data=journal reporting the error one fsync LATE, so "we rolled back the
   * batch that failed" does not restore ground truth either.
   *
   * This assertion was inverted deliberately -- it used to require HDL_OK here,
   * i.e. it used to require the journal to issue exactly the acknowledgement it
   * is no longer entitled to make. See the cagents decision
   * poison-the-log-after-a-failed-durability-barrier. */
  hdl_receipt receipt;
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_POISONED, "append after a failed barrier must not be acknowledged");

  /* Reading still works: inspecting the log is how an operator investigates. */
  state = (scan_state){0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan a poisoned log");
  require_status(hdl_close(log), HDL_OK, "close poisoned log");

  /* Reopening re-runs recovery, which re-derives what is committed from the
   * bytes on disk -- the knowledge the failed barrier destroyed. That, and only
   * that, clears the poison. The sequence still starts at 1, proving the failed
   * batch never consumed an identity. */
  require_status(hdl_open(path, NULL, &log), HDL_OK, "reopen after poisoning");
  require_status(hdl_append_batch(log, &record, 1, &receipt), HDL_OK, "reopened log accepts appends");
  if (receipt.first_sequence != 1 || receipt.last_sequence != 1) fail("failed batch consumed sequence");
  require_status(hdl_close(log), HDL_OK, "close reopened log");
  unlink(path);
  free(path);
}

typedef enum {
  KILL_DURING_WRITE,
  KILL_BEFORE_SYNC,
  KILL_AFTER_SYNC
} kill_point;

static int recovered_count(const char *path) {
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open killed log");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan killed log");
  if (state.invalid) fail("invalid record after kill");
  require_status(hdl_close(log), HDL_OK, "close killed log");
  return state.count;
}

static int run_kill_point(kill_point point) {
  char *path = temporary_path("kill");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "initialize killed log");
  require_status(hdl_close(log), HDL_OK, "close initialized killed log");

  pid_t child = fork();
  if (child < 0) fail("fork kill test");
  if (child == 0) {
    if (hdl_open(path, NULL, &log) != HDL_OK) _exit(70);
    if (point == KILL_DURING_WRITE) hdl_test_kill_during_write_after_bytes(17);
    if (point == KILL_BEFORE_SYNC) hdl_test_kill_before_next_sync();
    if (point == KILL_AFTER_SYNC) hdl_test_kill_after_next_sync();
    const char payload[] = "kill-point mutation";
    hdl_record record = {31, payload, sizeof(payload) - 1};
    (void)hdl_append_batch(log, &record, 1, NULL);
    _exit(71);
  }
  int child_status = 0;
  if (waitpid(child, &child_status, 0) != child) fail("wait for killed writer");
  if (!WIFSIGNALED(child_status) || WTERMSIG(child_status) != SIGKILL) fail("writer did not die by SIGKILL");
  int count = recovered_count(path);
  unlink(path);
  free(path);
  return count;
}

static void process_kill_test(void) {
  if (run_kill_point(KILL_DURING_WRITE) != 0) fail("partial frame survived SIGKILL");
  int before_sync = run_kill_point(KILL_BEFORE_SYNC);
  if (before_sync != 0 && before_sync != 1) fail("invalid pre-sync recovery count");
  if (run_kill_point(KILL_AFTER_SYNC) != 1) fail("synced batch lost after SIGKILL");
}

typedef struct {
  hdl_log *log;
  hdl_broker *broker;
  int thread_id;
  int operations;
  int failures;
  hdl_test_barrier *barrier;
} writer_args;

static void *writer(void *opaque) {
  writer_args *args = opaque;
  for (int index = 0; index < args->operations; index++) {
    if (args->barrier != NULL) hdl_test_barrier_wait(args->barrier);
    char payload[64];
    int length = snprintf(payload, sizeof(payload), "thread=%d operation=%d", args->thread_id, index);
    hdl_record record = {(uint64_t)args->thread_id + 1, payload, (uint32_t)length};
    hdl_status status = args->broker == NULL
                          ? hdl_append_batch(args->log, &record, 1, NULL)
                          : hdl_broker_submit(args->broker, &record, NULL);
    if (status != HDL_OK) args->failures++;
  }
  return NULL;
}

static void durability_barrier_test(void) {
  /* The headline promise is that acknowledgement follows DATA + COMMIT + a
   * durability barrier. On Darwin that promise is only true if the barrier is
   * F_FULLFSYNC: fsync(2) there states plainly that after fsync "the drive
   * itself may not physically write the data to the platters for quite some
   * time", that on power loss "the application may find that only some or none
   * of their data was written", and that this "is not a theoretical edge case".
   * A journal that acknowledged on fdatasync alone on that platform would be
   * acknowledging the DRIVE's volatile cache -- the same defect as
   * acknowledging RAM, one layer down, and invisible until a power cut.
   *
   * So the gate asserts which barrier this build uses, per platform. */
  const char *barrier = hdl_sync_barrier_name();
  if (barrier == NULL) fail("build reports no durability barrier");
#if defined(__APPLE__)
  if (strcmp(barrier, "F_FULLFSYNC") != 0) fail("Darwin build must flush the device cache with F_FULLFSYNC");
#else
  if (strcmp(barrier, "fdatasync") != 0) fail("expected fdatasync durability barrier");
#endif
}

static void concurrency_test(void) {
  enum { THREADS = 8, OPERATIONS = 40 };
  char *path = temporary_path("concurrent");
  hdl_log *log = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open concurrent log");
  pthread_t threads[THREADS];
  writer_args args[THREADS];
  for (int index = 0; index < THREADS; index++) {
    args[index] = (writer_args){log, NULL, index, OPERATIONS, 0, NULL};
    if (pthread_create(&threads[index], NULL, writer, &args[index]) != 0) fail("create writer");
  }
  for (int index = 0; index < THREADS; index++) {
    pthread_join(threads[index], NULL);
    if (args[index].failures != 0) fail("concurrent append failure");
  }
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan concurrent log");
  if (state.invalid || state.count != THREADS * OPERATIONS) fail("concurrent sequence integrity");
  require_status(hdl_close(log), HDL_OK, "close concurrent log");

  require_status(hdl_open(path, NULL, &log), HDL_OK, "reopen concurrent log");
  state = (scan_state){0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan reopened concurrent log");
  if (state.invalid || state.count != THREADS * OPERATIONS) fail("reopen sequence integrity");
  require_status(hdl_close(log), HDL_OK, "close reopened concurrent log");
  unlink(path);
  free(path);
}

static void broker_group_commit_test(void) {
  enum { THREADS = 16, OPERATIONS = 20 };
  char *path = temporary_path("broker");
  hdl_log *log = NULL;
  hdl_broker *broker = NULL;
  require_status(hdl_open(path, NULL, &log), HDL_OK, "open broker log");
  hdl_broker_options options = {64, 64, 5000};
  require_status(hdl_broker_open(log, &options, &broker), HDL_OK, "open broker");
  hdl_test_barrier barrier;
  if (hdl_test_barrier_init(&barrier, THREADS) != 0) fail("create broker barrier");
  pthread_t threads[THREADS];
  writer_args args[THREADS];
  for (int index = 0; index < THREADS; index++) {
    args[index] = (writer_args){log, broker, index, OPERATIONS, 0, &barrier};
    if (pthread_create(&threads[index], NULL, writer, &args[index]) != 0) fail("create broker writer");
  }
  for (int index = 0; index < THREADS; index++) {
    pthread_join(threads[index], NULL);
    if (args[index].failures != 0) fail("broker append failure");
  }
  hdl_test_barrier_destroy(&barrier);
  hdl_broker_stats stats;
  require_status(hdl_broker_get_stats(broker, &stats), HDL_OK, "broker stats");
  if (stats.records != THREADS * OPERATIONS ||
      stats.durable_batches >= stats.records || stats.largest_batch < 2) {
    fail("broker did not group commits");
  }
  require_status(hdl_broker_close(broker), HDL_OK, "close broker");
  scan_state state = {0, 1, 0};
  require_status(hdl_scan(log, collect, &state), HDL_OK, "scan broker log");
  if (state.invalid || state.count != THREADS * OPERATIONS) fail("broker sequence integrity");
  require_status(hdl_close(log), HDL_OK, "close broker log");
  unlink(path);
  free(path);
}

int main(void) {
  basic_and_torn_tail_test();
  corruption_test();
  injected_short_write_test();
  failed_barrier_poisons_test();
  process_kill_test();
  durability_barrier_test();
  concurrency_test();
  broker_group_commit_test();
  puts("PASS: durable log recovery and concurrency");
  return 0;
}
