package hey.android.api;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The renderer's own rules on the Mac, beyond the shared vectors:
 *
 *   java hey.android.api.ModelMain
 *
 * 1. hidden: a screen with an unknown section kind, an unknown action kind, an
 *    action leading to an unknown kind, a known kind this build does not draw
 *    yet, and an unknown row kind draws none of them, and draws the known ones
 *    beside them; a route section of an unknown kind asks for nothing.
 * 2. never sent: running each hidden action sends no request; running a drawn
 *    one sends exactly one, with its path and body filled.
 * 3. sign-out: an action whose then is sign_out signs out after its request.
 * 4. forms: a required field this build does not draw hides the primary
 *    button; missing text says the label; skip_empty leaves a request out.
 * 5. baked keys: a served description cannot change the origin or where the
 *    session token is sent.
 * 6. prompts: asked after the confirm; the typed text, trimmed, becomes $id; a
 *    required field left empty, or a cancelled prompt, sends nothing; a prompt
 *    with a field kind this build does not draw is hidden.
 * 7. a search's state: idle with no query; searching while a section has not
 *    answered or says it is still looking; out of polls, the gave_up_note and
 *    no longer searching; empty only when every section answered with nothing
 *    (said with the query, or the screen's own empty text); failed, never
 *    empty, when a section failed and nothing was found, its error drawn as one.
 * Prints PASS or FAIL lines; exits 1 when any fails.
 */
public final class ModelMain {
  static int failures = 0;

  static void check(boolean ok, String what) {
    if (ok) System.out.println("PASS: " + what);
    else {
      failures++;
      System.out.println("FAIL: " + what);
    }
  }

  static Map<String, Object> obj(String json) {
    try {
      return Json.dict(Json.parse(json));
    } catch (Json.ParseError e) {
      throw new IllegalArgumentException(json, e);
    }
  }

  static final class Sent {
    final String path;
    final Map<String, Object> body;

    Sent(String path, Map<String, Object> body) {
      this.path = path;
      this.body = body;
    }
  }

  static final class Recorder implements Actions.Transport {
    final List<Sent> sent = new ArrayList<>();

    @Override public void send(Map<String, Object> route, Map<String, Object> vars, Object row, Actions.Reply reply) {
      sent.add(new Sent(Values.fillPath(Values.string(route.get("path")), vars), Actions.body(route, vars, row)));
      reply.done(200, obj("{\"ok\":true}"), null);
    }
  }

  static final class FakeHost implements Actions.Host {
    final Map<String, Object> vars = new LinkedHashMap<>();
    Object json;
    final List<String> events = new ArrayList<>();
    Map<String, Object> typed;

    @Override public Map<String, Object> vars() { return vars; }
    @Override public Object screenJson() { return json; }
    @Override public Map<String, Object> labels() { return new LinkedHashMap<>(); }
    @Override public void confirm(String title, String message, String button, boolean destructive, Runnable then) { events.add("confirm:" + title); then.run(); }
    @Override public void prompt(Map<String, Object> action, Object row, Map<String, Object> vars, java.util.function.Consumer<Map<String, Object>> then) {
      events.add("prompt:" + Values.string(Json.dict(action.get("prompt")).get("title")));
      if (typed == null) return;
      Actions.Prompted p = Actions.prompted(action, vars, typed);
      if (p.problem != null) events.add("alert:" + p.problem);
      else then.accept(p.vars);
    }
    @Override public void openScreen(String id, Map<String, Object> params) { events.add("open:" + id + Json.encode(params)); }
    @Override public void openUrl(String address) { events.add("url:" + address); }
    @Override public void playVideo(String address) { events.add("video:" + address); }
    @Override public void toast(String text) { events.add("toast:" + text); }
    @Override public void alert(String title, String message) { events.add("alert:" + title); }
    @Override public void signOut() { events.add("sign_out"); }
    @Override public void pop() { events.add("pop"); }
    @Override public void reload() { events.add("reload"); }
  }

  static final String SCREEN = "{\"id\":\"library\",\"type\":\"list\",\"title\":\"Library\","
      + "\"sections\":["
      + "{\"title\":\"Things\",\"actions\":["
      + "  {\"title\":\"Save\",\"request\":{\"method\":\"POST\",\"path\":\"/v1/items/{id}/save\",\"body\":{\"note\":\"$note?\",\"who\":\"@owner\"}},\"done\":\"Saved\",\"then\":\"stay\"},"
      + "  {\"kind\":\"teleport\",\"title\":\"Teleport\",\"request\":{\"method\":\"POST\",\"path\":\"/v1/never/teleport\"}},"
      + "  {\"kind\":\"open_screen\",\"title\":\"Then teleport\",\"screen\":\"x\",\"then_action\":{\"kind\":\"teleport\",\"request\":{\"method\":\"POST\",\"path\":\"/v1/never/then\"}}},"
      + "  {\"kind\":\"rating\",\"title\":\"Rate it\",\"request\":{\"method\":\"POST\",\"path\":\"/v1/never/rating\"}},"
      + "  {\"title\":\"Ask first\",\"prompt\":{\"fields\":[{\"id\":\"path\"}]},\"request\":{\"method\":\"POST\",\"path\":\"/v1/asked\"}},"
      + "  {\"title\":\"Sign out\",\"style\":\"destructive\",\"confirm\":{\"title\":\"Sign out?\",\"button\":\"Sign out\"},\"request\":{\"method\":\"POST\",\"path\":\"/v1/session/revoke\",\"body\":{}},\"then\":\"sign_out\"},"
      + "  {\"title\":\"Ask oddly\",\"prompt\":{\"fields\":[{\"id\":\"face\",\"kind\":\"camera\"}]},\"request\":{\"method\":\"POST\",\"path\":\"/v1/never/prompt\"}},"
      + "  {\"title\":\"Delete account\",\"style\":\"destructive\",\"confirm\":{\"title\":\"Delete your account?\",\"button\":\"Continue\"},\"prompt\":{\"title\":\"Enter your passphrase\",\"fields\":[{\"id\":\"passphrase\",\"label\":\"Passphrase\",\"kind\":\"secure\",\"required\":true}],\"button\":\"Delete account\"},\"request\":{\"method\":\"POST\",\"path\":\"/v1/account/delete\",\"body\":{\"passphrase\":\"$passphrase\"}},\"done\":\"Deleted\",\"then\":\"sign_out\"}"
      + "]},"
      + "{\"kind\":\"carousel\",\"title\":\"Spinning\",\"source\":{\"method\":\"GET\",\"path\":\"/v1/never/carousel\"},\"list\":\"items\"},"
      + "{\"title\":\"Recent\",\"source\":{\"method\":\"GET\",\"path\":\"/v1/items\"},\"list\":\"items\",\"row\":{\"title\":\"title\"},\"select\":{\"screen\":\"item\",\"params\":{\"id\":\"id\"}}},"
      + "{\"title\":\"More\",\"rows\":["
      + "  {\"title\":\"Account\",\"screen\":\"account\"},"
      + "  {\"kind\":\"portal\",\"title\":\"Portal\",\"screen\":\"account\"},"
      + "  {\"title\":\"Beam\",\"action\":{\"kind\":\"teleport\",\"request\":{\"method\":\"POST\",\"path\":\"/v1/never/row\"}}}"
      + "]}"
      + "]}";

  public static void main(String[] args) {
    Map<String, Object> screen = obj(SCREEN);
    Object json = obj("{\"id\":\"a1\",\"owner\":\"ann\"}");
    List<Screens.Element> first = Screens.list(screen, json, null, null, new LinkedHashMap<>(), new LinkedHashMap<>());
    List<String> titles = new ArrayList<>();
    for (Screens.Element e : first) titles.add(e.title);

    // 1. hidden, and the known ones beside them drawn
    check(titles.contains("Save") && titles.contains("Sign out") && titles.contains("Account") && titles.contains("Things") && titles.contains("More")
        && titles.contains("Ask first") && titles.contains("Delete account"),
        "hidden: the known button, row and section titles beside the unknown ones are drawn (" + titles + ")");
    for (String hidden : new String[] {"Teleport", "Then teleport", "Rate it", "Ask oddly", "Spinning", "Portal", "Beam"}) {
      check(!titles.contains(hidden), "hidden: '" + hidden + "' is not drawn");
    }
    List<Map<String, Object>> sections = Screens.sections(screen);
    check(Screens.routeFor(sections.get(1), json) == null, "hidden: the carousel section's route is never asked for");
    Map<String, Object> recent = Screens.routeFor(sections.get(2), json);
    check(recent != null && "/v1/items".equals(recent.get("path")), "control: the known route section beside it is asked for (" + (recent == null ? null : recent.get("path")) + ")");

    Map<Integer, Screens.RouteRows> routes = new LinkedHashMap<>();
    routes.put(2, Screens.routeRows(sections.get(2), obj("{\"items\":[{\"id\":\"i9\",\"title\":\"Dune\"}]}"), null));
    Screens.Element dune = null;
    for (Screens.Element e : Screens.list(screen, json, null, routes, new LinkedHashMap<>(), new LinkedHashMap<>())) if ("Dune".equals(e.title)) dune = e;
    check(dune != null && "item".equals(dune.screen) && "i9".equals(dune.params.get("id")), "a route row opens its select screen with params read from the row (" + (dune == null ? null : dune.screen + Json.encode(dune.params)) + ")");

    // 2. never sent
    for (Object a : Json.list(Json.dict(sections.get(0)).get("actions"))) {
      Map<String, Object> action = Json.dict(a);
      String title = Values.string(action.get("title"));
      if (title.equals("Save") || title.equals("Sign out") || title.equals("Ask first") || title.equals("Delete account")) continue;
      Recorder r = new Recorder();
      FakeHost h = new FakeHost();
      h.json = json;
      boolean ran = Actions.run(action, null, h, r);
      check(!ran && r.sent.isEmpty() && h.events.isEmpty(), "never sent: running '" + title + "' sends nothing and does nothing (" + r.sent.size() + " requests, events " + h.events + ")");
    }
    Recorder beam = new Recorder();
    FakeHost beamHost = new FakeHost();
    check(!Actions.run(Json.dict(Json.dict(Json.list(Json.dict(sections.get(3)).get("rows")).get(2)).get("action")), null, beamHost, beam) && beam.sent.isEmpty(),
        "never sent: the unknown action on the 'Beam' row sends nothing");
    Recorder save = new Recorder();
    FakeHost saveHost = new FakeHost();
    saveHost.json = json;
    saveHost.vars.put("id", "a/1");
    // '@name' in a body reads the row acted on (HeyIOSValue); '$@name' would read the screen's answer.
    boolean saved = Actions.run(Json.dict(Json.list(Json.dict(sections.get(0)).get("actions")).get(0)), obj("{\"owner\":\"ann\"}"), saveHost, save);
    check(saved && save.sent.size() == 1 && "/v1/items/a%2F1/save".equals(save.sent.get(0).path)
        && Json.same(save.sent.get(0).body, obj("{\"who\":\"ann\"}")) && saveHost.events.equals(java.util.Arrays.asList("toast:Saved")),
        "control: running 'Save' sends one request, path and body filled (" + (save.sent.isEmpty() ? "none" : save.sent.get(0).path + " " + Json.encode(save.sent.get(0).body)) + ", events " + saveHost.events + ")");

    // 3. sign-out
    Recorder out = new Recorder();
    FakeHost outHost = new FakeHost();
    Actions.run(Json.dict(Json.list(Json.dict(sections.get(0)).get("actions")).get(5)), null, outHost, out);
    check(out.sent.size() == 1 && "/v1/session/revoke".equals(out.sent.get(0).path) && outHost.events.equals(java.util.Arrays.asList("confirm:Sign out?", "sign_out")),
        "sign-out: asks first, revokes, then signs out (" + outHost.events + ")");

    // 4. forms
    Map<String, Object> signin = obj("{\"id\":\"signin\",\"type\":\"form\",\"missing\":\"%@ is needed.\",\"fields\":["
        + "{\"id\":\"username\",\"label\":\"Name\",\"kind\":\"text\",\"required\":true},"
        + "{\"id\":\"passphrase\",\"label\":\"Passphrase\",\"kind\":\"secure\",\"required\":true},"
        + "{\"id\":\"face\",\"label\":\"Face\",\"kind\":\"camera\"}],"
        + "\"primary\":{\"title\":\"Sign in\",\"requests\":[{\"method\":\"POST\",\"path\":\"/v1/session\"},{\"method\":\"POST\",\"path\":\"/v1/extra\",\"skip_empty\":\"code\"}]}}");
    Screens.Form form = Screens.form(signin, new LinkedHashMap<>());
    Map<String, Object> values = new LinkedHashMap<>();
    values.put("username", "ann");
    check(form.primaryDrawn && form.fields.size() == 2, "forms: an optional field of an unknown kind is hidden and the button stays (" + form.fields.size() + " fields)");
    check("Passphrase is needed.".equals(Screens.problem(signin, form, values)), "forms: level 1's '%@ is needed.' names the empty required field (" + Screens.problem(signin, form, values) + ")");
    check(Screens.requests(signin, values).size() == 1, "forms: a request with skip_empty on an empty field is left out");
    Map<String, Object> cameraRequired = obj(Json.encode(signin).replace("\"kind\":\"camera\"", "\"kind\":\"camera\",\"required\":true"));
    check(!Screens.form(cameraRequired, new LinkedHashMap<>()).primaryDrawn, "forms: a REQUIRED field of an unknown kind hides the button, so an incomplete request is never sent");

    // 5. baked keys
    Map<String, Object> baked = obj("{\"keychain_service\":\"baked.store\",\"served\":{\"path\":\"/v1/app/description\"},\"session\":{\"sign_in_screen\":\"signin\",\"header\":\"authorization\",\"prefix\":\"Bearer \",\"check\":{\"path\":\"/v1/session\"}}}");
    Map<String, Object> served = obj("{\"origin\":\"https://evil.example\",\"keychain_service\":\"other\",\"served\":{\"path\":\"/steal\"},\"session\":{\"sign_in_screen\":\"welcome\",\"header\":\"x-token\",\"prefix\":\"\",\"check\":{\"path\":\"/steal\"}},\"title\":\"New\"}");
    Map<String, Object> merged = Descriptions.merged(served, baked);
    Map<String, Object> session = Json.dict(merged.get("session"));
    check(!merged.containsKey("origin") && "baked.store".equals(merged.get("keychain_service")) && "authorization".equals(session.get("header"))
        && "Bearer ".equals(session.get("prefix")) && "/v1/session".equals(Json.dict(session.get("check")).get("path"))
        && "/v1/app/description".equals(Json.dict(merged.get("served")).get("path")),
        "baked keys: the served origin, store name, served route and session header, prefix and check are replaced by the baked ones (" + Json.encode(merged) + ")");
    check("welcome".equals(session.get("sign_in_screen")) && "New".equals(merged.get("title")), "control: the served screens and sign-in screen are kept");

    // 6. prompts
    Map<String, Object> deleteAccount = Json.dict(Json.list(Json.dict(sections.get(0)).get("actions")).get(7));
    Recorder del = new Recorder();
    FakeHost delHost = new FakeHost();
    delHost.typed = new LinkedHashMap<>();
    delHost.typed.put("passphrase", "  correct horse ");
    Actions.run(deleteAccount, null, delHost, del);
    check(del.sent.size() == 1 && "/v1/account/delete".equals(del.sent.get(0).path) && Json.same(del.sent.get(0).body, obj("{\"passphrase\":\"correct horse\"}"))
        && delHost.events.equals(java.util.Arrays.asList("confirm:Delete your account?", "prompt:Enter your passphrase", "toast:Deleted", "sign_out")),
        "prompts: the confirm, then the prompt, then one request with the typed text trimmed as $passphrase, then sign-out ("
        + (del.sent.isEmpty() ? "none" : Json.encode(del.sent.get(0).body)) + ", events " + delHost.events + ")");
    Recorder empty = new Recorder();
    FakeHost emptyHost = new FakeHost();
    emptyHost.typed = new LinkedHashMap<>();
    emptyHost.typed.put("passphrase", "   ");
    Actions.run(deleteAccount, null, emptyHost, empty);
    check(empty.sent.isEmpty() && emptyHost.events.contains("alert:Passphrase is needed.") && !emptyHost.events.contains("sign_out"),
        "prompts: a required field left empty sends nothing and says what is needed (" + emptyHost.events + ")");
    Recorder cancelled = new Recorder();
    FakeHost cancelHost = new FakeHost();
    Actions.run(deleteAccount, null, cancelHost, cancelled);
    check(cancelled.sent.isEmpty() && cancelHost.events.equals(java.util.Arrays.asList("confirm:Delete your account?", "prompt:Enter your passphrase")),
        "prompts: a cancelled prompt sends nothing (" + cancelHost.events + ")");
    check("Dune".equals(Actions.prefill(obj("{\"id\":\"t\",\"value\":\"title\"}"), obj("{\"title\":\"Dune\"}"), null))
        && "Arrival".equals(Actions.prefill(obj("{\"id\":\"t\",\"value\":\"title\"}"), null, obj("{\"title\":\"Arrival\"}"))),
        "prompts: a field's starting text is read from the row, else from the screen's answer");

    // 7. a search's state
    Map<String, Object> search = obj("{\"id\":\"find\",\"type\":\"search\",\"title\":\"Find\",\"sections\":["
        + "{\"title\":\"Mine\",\"request\":{\"method\":\"POST\",\"path\":\"/v1/search\",\"body\":{\"q\":\"$query\"}},\"list\":\"items\",\"row\":{\"title\":\"title\"},\"empty\":\"Nothing of yours.\"},"
        + "{\"title\":\"Found\",\"request\":{\"method\":\"POST\",\"path\":\"/v1/discover\",\"body\":{\"input\":\"$query\"}},\"list\":\"results\",\"row\":{\"title\":\"title\"},"
        + "\"poll\":{\"key\":\"status\",\"pending\":\"pending\",\"every_ms\":10,\"max\":2},\"pending_note\":\"Still looking.\",\"gave_up_note\":\"Gave up.\",\"empty\":\"Nothing found.\"}]}");
    List<Map<String, Object>> parts = Screens.sections(search);
    Map<Integer, Screens.RouteRows> answers = new LinkedHashMap<>();
    check(Screens.searchState(search, null, "", answers) == Screens.SearchState.IDLE, "search: an empty query is idle, not searching");
    check(Screens.searchState(search, null, "dune", answers) == Screens.SearchState.SEARCHING, "search: asked and unanswered is searching");
    answers.put(0, Screens.routeRows(parts.get(0), obj("{\"items\":[]}"), null));
    check(Screens.searchState(search, null, "dune", answers) == Screens.SearchState.SEARCHING,
        "search: one section empty while the other has not answered is still searching, not empty");
    Screens.RouteRows still = Screens.routeRows(parts.get(1), obj("{\"status\":\"pending\",\"results\":[]}"), null);
    answers.put(1, still);
    check(still.pending && Screens.searchState(search, null, "dune", answers) == Screens.SearchState.SEARCHING,
        "search: a section that says it is still looking keeps the search running");
    Screens.RouteRows gave = Screens.gaveUp(parts.get(1), still);
    answers.put(1, gave);
    check(!gave.pending && "Gave up.".equals(gave.footer) && Screens.searchState(search, null, "dune", answers) == Screens.SearchState.EMPTY,
        "search: out of polls, the section says its gave_up_note and the search ends (" + gave.footer + ")");
    answers.put(1, Screens.routeRows(parts.get(1), obj("{\"status\":\"done\",\"results\":[]}"), null));
    check(Screens.searchState(search, null, "dune", answers) == Screens.SearchState.EMPTY
        && Screens.noResults(search, "dune").equals("No results for “dune”.")
        && Screens.noResults(obj("{\"empty\":\"Nothing at all.\"}"), "dune").equals("Nothing at all."),
        "search: every section answered with nothing is empty, said with the query, or with the screen's own empty text");
    answers.put(1, Screens.routeRows(parts.get(1), obj("{\"status\":\"done\",\"results\":[{\"title\":\"Dune\"}]}"), null));
    check(Screens.searchState(search, null, "dune", answers) == Screens.SearchState.FOUND, "search: a row anywhere is found");
    Screens.RouteRows broke = Screens.routeRows(parts.get(1), null, "The server did not answer.");
    answers.put(1, broke);
    boolean errorDrawn = false;
    for (Screens.Element e : Screens.list(search, null, null, answers, new LinkedHashMap<>(), new LinkedHashMap<>())) {
      if (e.kind == Screens.Kind.NOTE && e.title.equals("The server did not answer.") && e.destructive) errorDrawn = true;
    }
    check(broke.failed && Screens.searchState(search, null, "dune", answers) == Screens.SearchState.FAILED && errorDrawn,
        "search: a failed section with no rows anywhere is failed, never empty, and its error is drawn as one");

    System.exit(failures == 0 ? 0 : 1);
  }
}
