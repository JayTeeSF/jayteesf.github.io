#include "hey_tsv.h"
#include "hey_zstd.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static void put32(uint8_t *p,uint32_t n){p[0]=n;p[1]=n>>8;p[2]=n>>16;p[3]=n>>24;}
static HeyNativeUtf8View text(const char *s){return (HeyNativeUtf8View){s,strlen(s)};}
int main(void){
 uint8_t b[256]={0};memcpy(b,"HYR1",4);put32(b+4,1);put32(b+8,4);size_t n=12;
 put32(b+n,UINT32_MAX);n+=4;put32(b+n,0);n+=4;
 const char payload[]="a\t\n\r\0\x1a\\N日本語";size_t size=sizeof(payload)-1;
 put32(b+n,size);n+=4;memcpy(b+n,payload,size);n+=size;put32(b+n,3);n+=4;memcpy(b+n,"123",3);n+=3;
 HeyNativeBytesView input={b,n};HeyNativeOwnedBytes encoded=tsv_encode(input);assert(encoded.data);
 const char expected[]="\\N\t\ta\\t\\n\\r\\0\\Z\\\\N日本語\t123\n";
 assert(encoded.length==sizeof(expected)-1 && !memcmp(encoded.data,expected,sizeof(expected)-1));
 assert(tsv_rows(input)==1 && tsv_last_u64(input,3)==123);
 assert(!tsv_encode((HeyNativeBytesView){b,n-1}).data);
 uint8_t saved=b[24];b[24]=255;assert(!tsv_encode(input).data);b[24]=saved;
 const char *dir=getenv("CODEC_TEST_DIR");if(!dir)dir=".";assert(strlen(dir)<4000);
 char path[4096];snprintf(path,sizeof(path),"%s/codec-test-%ld.zst",dir,(long)getpid());
 HeyNativeHandle w=zstd_writer_open(text(path),3);assert(w);assert(!zstd_writer_open(text(path),3));
 assert(zstd_writer_write(w,(HeyNativeBytesView){encoded.data,encoded.length})==0);assert(zstd_writer_close(w)==0);
 HeyNativeHandle r=zstd_reader_open(text(path),4096);assert(r);size_t seen=0;
 for(;;){HeyNativeOwnedBytes out=zstd_reader_read(r,3);assert(out.data);if(!out.length){out.release(out.context,out.data,out.length);break;}
 assert(seen+out.length<=encoded.length && !memcmp(out.data,encoded.data+seen,out.length));seen+=out.length;out.release(out.context,out.data,out.length);}
 assert(seen==encoded.length && zstd_reader_close(r)==0);
 FILE *f=fopen(path,"ab");assert(f);fputc(1,f);fclose(f);r=zstd_reader_open(text(path),4096);assert(r);
 HeyNativeOwnedBytes out=zstd_reader_read(r,4096);assert(!out.data && zstd_reader_error(r)==4);assert(zstd_reader_close(r)!=0);
 assert(truncate(path,10)==0);r=zstd_reader_open(text(path),4096);assert(r);out=zstd_reader_read(r,4096);assert(!out.data);assert(zstd_reader_close(r)!=0);
 unlink(path);encoded.release(encoded.context,encoded.data,encoded.length);
 puts("PASS: exact TSV bytes, null/empty/Unicode/escapes, malformed frames, exclusive files, bounded zstd, trailing/truncated refusal");
}
