# IN PROGRESS — hey_cache

Nothing in flight. 0.1.0 is complete and release-READY (not released: no
remote, no publication).

## The open question a reader should not have to rediscover

`bin/check` gate 5 proves the SQL layer against SQLite only. The MySQL claim
in README.md's layer table rests on it being the *same* `HeyRecordStore.sql`
code path with `hey_record`'s mysql dialect — which is a good argument and
not a measurement. No MySQL server was available. See `todos.md` #1.
