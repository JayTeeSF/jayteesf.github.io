#!/usr/bin/env bash
# The build lane without a device: tools/hey-android-app.sh builds
# examples/hello_runtime.hey with the Maintainer's Homebrew compiler variables
# exported, and every check between the steps passes. Then each check is shown
# to fail on a deliberately broken input.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
export HEY_ROOT
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-build-spec.XXXXXX")
trap 'rm -rf "$work"' EXIT
verify=$ROOT/tools/hey-android-verify.sh
pass() { echo "PASS: $*"; }
control() { echo "PASS (control): $*"; }
bad() { echo "FAIL: $*"; failed=1; }
field() { /usr/bin/python3 -c 'import json,sys
v = json.load(open(sys.argv[1]))
for k in sys.argv[2].split("."): v = v[k] if isinstance(v, dict) else None
print(v if isinstance(v, str) else json.dumps(v))' "$1" "$2"; }

# ---- the build, with host compiler variables set ---------------------------------------------
app=$work/hello
if env CPATH=:/usr/local/include:/opt/homebrew/include/ C_INCLUDE_PATH=/opt/homebrew/include LIBRARY_PATH=:/usr/local/lib:/opt/homebrew/lib/ \
     CPPFLAGS=-I/opt/homebrew/opt/openssl@3/include LDFLAGS=-L/opt/homebrew/opt/openssl@3/lib \
     "$ROOT/tools/hey-android-app.sh" --source "$ROOT/examples/hello_runtime.hey" --out "$app" \
     --package-id com.jayteesf.hey.hello --label 'Hey Hello' > "$work/hello.log" 2>&1; then
  pass "tools/hey-android-app.sh builds examples/hello_runtime.hey into a signed APK ($(field "$app/receipt.json" apk.bytes) bytes, runtime objects: cache $(field "$app/receipt.json" runtime_objects.cache))"
else
  bad 'tools/hey-android-app.sh could not build examples/hello_runtime.hey:'
  tail -20 "$work/hello.log" | sed 's/^/  /'
  exit 1
fi
receipt=$app/receipt.json

cleared=$(field "$receipt" build_isolation.set_in_caller_environment)
includes=$(field "$receipt" build_isolation.include_search_path)
if printf '%s' "$cleared" | grep -q CPATH && printf '%s' "$cleared" | grep -q LDFLAGS && ! printf '%s' "$includes" | grep -Eq '/opt/homebrew|/usr/local'; then
  pass "build isolation: CPATH, C_INCLUDE_PATH, LIBRARY_PATH, CPPFLAGS and LDFLAGS pointed at Homebrew and were cleared; NDK clang searched only $(printf '%s' "$includes" | tr ',' '\n' | grep -c ndk/) NDK include directories"
else
  bad "build isolation: cleared=$cleared includes=$includes"
fi

if git -C "$HEY_ROOT" diff --quiet -- runtime/hey_runtime.c runtime/hey_compiler_nodes_bundle.c 2>/dev/null &&
   [ -z "$(find "$ROOT" -name 'hey_runtime.c' -o -name 'hey_compiler_nodes_bundle.c' | grep -v '/dist/')" ]; then
  pass "the runtime is HEY_ROOT's own, unmodified (hey_runtime.c sha256 $(field "$receipt" toolchain.runtime_source_sha256 | cut -c1-16), no copy in the package)"
else
  bad 'the Hey runtime sources are modified in HEY_ROOT, or copied into the package'
fi

ir_ok=$("$verify" ir "$app/build/app.ll" 2>&1) && pass "IR: $ir_ok" || bad "IR check: $ir_ok"
so=$app/stage/lib/arm64-v8a/libhey_app.so
so_ok=$("$verify" so "$so" 2>&1) && pass "shared library: $so_ok" || bad "shared library check: $so_ok"
apk_ok=$("$verify" apk "$app/app.apk" com.jayteesf.hey.hello 2>&1) && pass "APK: $apk_ok" || bad "APK check: $apk_ok"

# ---- negative controls -------------------------------------------------------------------------
expect_failure() { # LABEL PATTERN COMMAND...
  label=$1
  pattern=$2
  shift 2
  if output=$("$@" 2>&1); then
    bad "(control) $label was accepted: $output"
  elif printf '%s\n' "$output" | grep -Eq "$pattern"; then
    control "$label: $(printf '%s\n' "$output" | grep -E "$pattern" | sed -n 1p | cut -c1-220)"
  else
    bad "(control) $label failed, but not for the expected reason: $(printf '%s\n' "$output" | sed -n 1,3p)"
  fi
}

cat > "$work/delegates.hey" <<'EOF'
program
  let path = Files.write_text('delegated.txt', 'written by the Hey toolchain, not the runtime')
  says path
end
EOF
# shellcheck disable=SC2086 # the lock prefix is a command and its arguments
if ${HEY_HEYC_LOCK:-} "$HEY_ROOT/bin/heyc" build --emit-llvm-ir "$work/delegates.hey" -o "$work/delegates.ll" > "$work/delegates.log" 2>&1; then
  expect_failure 'a program whose Files.write_text the runtime hands to the Hey toolchain at run time is refused' \
    'hands Files.write_text/2 to the Hey toolchain' "$verify" ir "$work/delegates.ll"
else
  bad "(control) heyc could not emit the delegation control: $(tail -3 "$work/delegates.log")"
fi

{ printf 'target triple = "arm64-apple-macosx14.0.0"\n'; cat "$app/build/app.ll"; } > "$work/triple.ll"
expect_failure 'IR that names a Mac target triple is refused' 'names a target' "$verify" ir "$work/triple.ll"

sed '1a\
; hey-stdlib-archive-required: true' "$app/build/app.ll" > "$work/archive.ll"
expect_failure 'IR that needs libhey_stdlib.a is refused' 'libhey_stdlib.a' "$verify" ir "$work/archive.ll"

runtime_dir=${HEY_ANDROID_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/hey_android}/runtime-$(field "$receipt" runtime_objects.cache_key)
link_so() { # OUTPUT RUNTIME_OBJECT EXTRA_FLAGS...
  output=$1
  runtime_object=$2
  shift 2
  env -u CPATH -u LIBRARY_PATH -u CPPFLAGS -u LDFLAGS "$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -shared -pthread \
    -Wl,-soname,libhey_app.so -Wl,-z,noexecstack -Wl,--wrap=exit -Wl,--wrap=pthread_create "$@" \
    "$app/build/app.o" "$app/build/glue.o" "$runtime_object" "$runtime_dir/hey_compiler_nodes.o" \
    "$runtime_dir/hey_android_platform_crypto.o" "$runtime_dir/sha256.o" -llog -landroid -lm -ldl -o "$output"
}

openssl_header=''
for candidate in /opt/homebrew/include/openssl/ssl.h /usr/local/include/openssl/ssl.h; do
  [ -f "$candidate" ] && { openssl_header=$candidate; break; }
done
if [ -n "$openssl_header" ]; then
  host_include=$(dirname "$(dirname "$openssl_header")")
  # The spike's first attempt, exactly: host CPATH, no Android profile. It compiles without an error.
  if env CPATH="$host_include" "$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -std=c11 -pthread -O1 -w -fPIC \
       "-DHEY_VERSION=\"$(field "$receipt" toolchain.hey_version)\"" -I"$HEY_ROOT/runtime" \
       -c "$HEY_ROOT/runtime/hey_runtime.c" -o "$work/contaminated_runtime.o" 2> "$work/contaminated.log"; then
    expect_failure "a runtime object compiled against $host_include's OpenSSL (CPATH set, no profile) is caught" 'OpenSSL or Apple crypto symbols' \
      "$verify" obj "$work/contaminated_runtime.o"
    if link_so "$work/contaminated.so" "$work/contaminated_runtime.o" -Wl,-z,max-page-size=16384 -Wl,--unresolved-symbols=ignore-all 2> "$work/contaminated-link.log"; then
      expect_failure 'a shared library linked from that object is caught' 'OpenSSL or Apple crypto symbols|undefined symbols no allowed' "$verify" so "$work/contaminated.so"
    else
      bad "(control) could not link the contaminated library: $(sed -n 1,3p "$work/contaminated-link.log")"
    fi
  else
    bad "(control) the contaminated runtime did not compile: $(sed -n 1,3p "$work/contaminated.log")"
  fi
else
  printf 'extern int SSL_library_init(void);\nconst char *hey_host_trace = "/opt/homebrew/include/openssl/ssl.h";\nint hey_contaminated(void) { return SSL_library_init(); }\n' > "$work/contaminated.c"
  "$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -fPIC -c "$work/contaminated.c" -o "$work/contaminated_runtime.o"
  expect_failure 'an object carrying an OpenSSL reference and a Homebrew path is caught (no Homebrew OpenSSL on this host, so a synthetic one)' \
    'OpenSSL or Apple crypto symbols' "$verify" obj "$work/contaminated_runtime.o"
fi

if link_so "$work/align4k.so" "$runtime_dir/hey_runtime.o" -Wl,--no-undefined -Wl,-z,max-page-size=4096 2> "$work/align-link.log"; then
  expect_failure 'a library linked with 4 KB pages is refused' 'not 16384' "$verify" so "$work/align4k.so"
else
  bad "(control) could not link the 4 KB library: $(sed -n 1,3p "$work/align-link.log")"
fi

cp "$app/app.apk" "$work/with-dex.apk"
printf 'dex\n035\0' > "$work/classes.dex"
(cd "$work" && /usr/bin/zip -q -X with-dex.apk classes.dex)
"$HEY_ANDROID_BUILD_TOOLS_DIR/zipalign" -P 16 -f 4 "$work/with-dex.apk" "$work/with-dex-aligned.apk" > /dev/null
java_home=$(hey_android_java_home)
env JAVA_HOME="$java_home" PATH="$java_home/bin:/usr/bin:/bin" "$HEY_ANDROID_BUILD_TOOLS_DIR/apksigner" sign \
  --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android \
  --v4-signing-enabled false --out "$work/with-dex-signed.apk" "$work/with-dex-aligned.apk" > /dev/null 2>&1
expect_failure 'a re-signed APK with a classes.dex added is refused' 'contains dex code' "$verify" apk "$work/with-dex-signed.apk" com.jayteesf.hey.hello

sed 's/android:hasCode="false"/android:hasCode="true"/' "$app/apk/AndroidManifest.xml" > "$work/AndroidManifest.xml"
"$HEY_ANDROID_BUILD_TOOLS_DIR/aapt2" link --manifest "$work/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -o "$work/hascode.apk" > /dev/null 2>&1
(cd "$app/stage" && /usr/bin/zip -q -0 -X "$work/hascode.apk" lib/arm64-v8a/libhey_app.so)
"$HEY_ANDROID_BUILD_TOOLS_DIR/zipalign" -P 16 -f 4 "$work/hascode.apk" "$work/hascode-aligned.apk" > /dev/null
env JAVA_HOME="$java_home" PATH="$java_home/bin:/usr/bin:/bin" "$HEY_ANDROID_BUILD_TOOLS_DIR/apksigner" sign \
  --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android \
  --v4-signing-enabled false --out "$work/hascode-signed.apk" "$work/hascode-aligned.apk" > /dev/null 2>&1
expect_failure 'an APK whose manifest says hasCode="true" is refused' 'hasCode' "$verify" apk "$work/hascode-signed.apk" com.jayteesf.hey.hello

exit $failed
