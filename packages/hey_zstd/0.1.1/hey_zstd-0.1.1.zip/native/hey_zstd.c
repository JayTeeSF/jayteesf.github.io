#define _DARWIN_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "hey_native_abi.h"
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
static void release_bytes(void *ctx,uint8_t *p,size_t n){(void)ctx;(void)n;free(p);}
#include <zstd.h>
typedef struct {FILE *file;ZSTD_CCtx *ctx;uint8_t *out;size_t cap;int error;} Writer;
typedef struct {FILE *file;ZSTD_DCtx *ctx;uint8_t *input;size_t cap;ZSTD_inBuffer in;uint64_t total,limit;int error,done;} Reader;
static char *path_copy(HeyNativeUtf8View p){if(!p.length||p.length>4096||memchr(p.data,0,p.length))return NULL;char *s=malloc(p.length+1);if(s){memcpy(s,p.data,p.length);s[p.length]=0;}return s;}
HeyNativeHandle zstd_writer_open(HeyNativeUtf8View path,int32_t level){
  if(level<1||level>19)return 0;char *p=path_copy(path);if(!p)return 0;
  int fd=open(p,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW,0600);free(p);if(fd<0)return 0;
  FILE *file=fdopen(fd,"wb");if(!file){close(fd);return 0;}
  Writer *w=calloc(1,sizeof(*w));if(!w){fclose(file);return 0;}
  w->file=file;w->ctx=ZSTD_createCCtx();w->cap=ZSTD_CStreamOutSize();w->out=malloc(w->cap);
  if(!w->ctx||!w->out){if(w->ctx)ZSTD_freeCCtx(w->ctx);free(w->out);fclose(file);free(w);return 0;}
  if(ZSTD_isError(ZSTD_CCtx_setParameter(w->ctx,ZSTD_c_compressionLevel,level))||ZSTD_isError(ZSTD_CCtx_setParameter(w->ctx,ZSTD_c_checksumFlag,1))){ZSTD_freeCCtx(w->ctx);free(w->out);fclose(file);free(w);return 0;}
  return (HeyNativeHandle)(uintptr_t)w;
}
int32_t zstd_writer_write(HeyNativeHandle h,HeyNativeBytesView data){
  Writer *w=(Writer *)(uintptr_t)h;if(!w||w->error)return 1;ZSTD_inBuffer in={data.data,data.length,0};
  while(in.pos<in.size){ZSTD_outBuffer out={w->out,w->cap,0};size_t r=ZSTD_compressStream2(w->ctx,&out,&in,ZSTD_e_continue);
    if(ZSTD_isError(r)||fwrite(w->out,1,out.pos,w->file)!=out.pos){w->error=1;return 1;}}
  return 0;
}
int32_t zstd_writer_close(HeyNativeHandle h){
  Writer *w=(Writer *)(uintptr_t)h;if(!w)return 1;int error=w->error;
  if(!error){ZSTD_inBuffer in={NULL,0,0};size_t left=1;while(left){ZSTD_outBuffer out={w->out,w->cap,0};left=ZSTD_compressStream2(w->ctx,&out,&in,ZSTD_e_end);if(ZSTD_isError(left)||fwrite(w->out,1,out.pos,w->file)!=out.pos){error=1;break;}}}
  if(fflush(w->file)!=0||fsync(fileno(w->file))!=0)error=1;if(fclose(w->file)!=0)error=1;
  ZSTD_freeCCtx(w->ctx);free(w->out);free(w);return error;
}
HeyNativeHandle zstd_reader_open(HeyNativeUtf8View path,uint64_t limit){
  if(!limit)return 0;char *p=path_copy(path);if(!p)return 0;int fd=open(p,O_RDONLY|O_NOFOLLOW);free(p);if(fd<0)return 0;
  FILE *file=fdopen(fd,"rb");if(!file){close(fd);return 0;}Reader *r=calloc(1,sizeof(*r));if(!r){fclose(file);return 0;}
  r->file=file;r->limit=limit;r->cap=ZSTD_DStreamInSize();r->ctx=ZSTD_createDCtx();r->input=malloc(r->cap);
  if(!r->ctx||!r->input||ZSTD_isError(ZSTD_DCtx_setParameter(r->ctx,ZSTD_d_windowLogMax,27))){if(r->ctx)ZSTD_freeDCtx(r->ctx);free(r->input);fclose(file);free(r);return 0;}
  r->in=(ZSTD_inBuffer){r->input,0,0};return (HeyNativeHandle)(uintptr_t)r;
}
HeyNativeOwnedBytes zstd_reader_read(HeyNativeHandle h,uint32_t max_bytes){
  HeyNativeOwnedBytes no={0};Reader *r=(Reader *)(uintptr_t)h;if(!r||r->error)return no;
  if(!max_bytes||max_bytes>16777216){r->error=1;return no;}uint8_t *data=malloc(max_bytes);if(!data){r->error=1;return no;}
  ZSTD_outBuffer out={data,max_bytes,0};
  while(out.pos<out.size&&!r->done){
    if(r->in.pos==r->in.size){size_t n=fread(r->input,1,r->cap,r->file);if(!n){r->error=2;free(data);return no;}r->in=(ZSTD_inBuffer){r->input,n,0};}
    size_t remaining=ZSTD_decompressStream(r->ctx,&out,&r->in);
    if(ZSTD_isError(remaining)){r->error=3;free(data);return no;}
    if(remaining==0){if(r->in.pos!=r->in.size||fgetc(r->file)!=EOF||ferror(r->file)){r->error=4;free(data);return no;}r->done=1;}
  }
  if(out.pos>r->limit-r->total){r->error=5;free(data);return no;}r->total+=out.pos;
  return (HeyNativeOwnedBytes){data,out.pos,release_bytes,NULL};
}
uint32_t zstd_reader_error(HeyNativeHandle h){Reader *r=(Reader *)(uintptr_t)h;return r?(uint32_t)r->error:1;}
int32_t zstd_reader_close(HeyNativeHandle h){Reader *r=(Reader *)(uintptr_t)h;if(!r)return 1;int e=r->error;if(fclose(r->file)!=0)e=1;ZSTD_freeDCtx(r->ctx);free(r->input);free(r);return e;}
