#define _DARWIN_C_SOURCE 1
#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static double ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000.0+t.tv_nsec/1e6;}
static void run(const char*jm,const char*sync,const char*ff){
  char path[]="/tmp/mx-XXXXXX"; int fd=mkstemp(path); if(fd>=0)close(fd); unlink(path);
  sqlite3*db; sqlite3_open(path,&db); char q[128],*e=NULL;
  snprintf(q,sizeof q,"PRAGMA journal_mode=%s;",jm); sqlite3_exec(db,q,0,0,&e);
  snprintf(q,sizeof q,"PRAGMA synchronous=%s;",sync); sqlite3_exec(db,q,0,0,&e);
  snprintf(q,sizeof q,"PRAGMA fullfsync=%s;",ff); sqlite3_exec(db,q,0,0,&e);
  sqlite3_exec(db,"CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT);",0,0,&e);
  sqlite3_stmt*st; sqlite3_prepare_v2(db,"INSERT INTO t(v) VALUES('payload-of-some-size')",-1,&st,0);
  for(int i=0;i<5;i++){sqlite3_reset(st);sqlite3_step(st);}       /* warm */
  int n=60; double t0=ms();
  for(int i=0;i<n;i++){sqlite3_reset(st);sqlite3_step(st);}
  double el=ms()-t0;
  printf("journal=%-6s synchronous=%-6s fullfsync=%-3s  %6.3f ms/commit  %8.0f commits/s\n",jm,sync,ff,el/n,n/(el/1000.0));
  sqlite3_finalize(st); sqlite3_close(db); unlink(path);
}
int main(void){
  printf("reference: bare F_FULLFSYNC on this host = ~4.0 ms\n\n");
  run("WAL","NORMAL","OFF"); run("WAL","FULL","OFF");
  run("WAL","NORMAL","ON");  run("WAL","FULL","ON");
  run("DELETE","FULL","ON"); run("WAL","EXTRA","ON");
  return 0;
}
