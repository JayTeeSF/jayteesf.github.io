# Done

- 0.1.0: the io_uring backend of Hey's batched TCP loop: hey_epoll's API and
  native function table; multishot accept into the fixed-file table
  (`IORING_FILE_INDEX_ALLOC`); multishot receive over a provided buffer ring;
  replies queued by `send()` and submitted with the next `wait()` (one
  `io_uring_enter` per batch), one SEND in flight per connection, short sends
  resumed; NODROP required and the CQ overflow backlog flushed in every
  drain; linked cancel+close of fixed slots, stale completions recognised by
  generation, in-flight send buffers kept until their completion; single-issuer
  ring with deferred task work where available; the CQ sized to twice the listen queue and the accept armed only into an empty CQ (a Linux 6.8 issue-time multishot accept loses a connection when the CQ fills; measured); named refusals at open
  (blocked, disabled, not in kernel, kernel too old, missing feature, no
  memory) and `IoUring.available()`; liburing 2.8 linked statically.
  Specs: hey_epoll's loop contract, a 300-connection small-ring stress (SQ full,
  CQ overflow, buffer ring dry), an 8 MiB short-send reply, peer close, the
  refusals (and the seccomp one under Docker's default profile), with nine
  negative controls.
- 0.1.1 (docs only): the arm64 measurements against epoll (hey_web's readiness
  lane +25-32% req/s per CPU; hey_fast_web `single` a tie at 64,000 users),
  with their caveats, in docs/DESIGN.md.
- 0.1.2: `stats` gains `cq_overflow_seen` (drains that found the CQ
  overflowed), separate from `cq_overflow_flushes`; the stress spec requires
  an overflow to be flushed, not to happen (on kernels after 6.8, deferred
  task work fills only free CQ space, so it never overflows). bin/linux-check
  takes a named HEY_TOOLCHAIN_IMAGE with no local Hey. linux-check passes on
  kernel 6.8.0-47 (arm64) and 7.1.9 (x86). docs/DESIGN.md adds the x86
  measurements (an i5-7500, kernel 6.18).
