require 'json';require 'open3';require 'fileutils';require 'time';require 'rbconfig'
root=File.expand_path('..',__dir__);work=File.join(root,'build','benchmark');FileUtils.mkdir_p(work)
# Generic public fixtures only. No application or consumer-specific configuration.
def scalar(value)
 case value
 when String then JSON.generate(value)
 when Integer,TrueClass,FalseClass then value.to_s
 when Array then '['+value.map{|v|scalar(v)}.join(', ')+']'
 else raise 'Unsupported fixture value'
 end
end
def emit(hash,path=[],lines=[],header:nil)
 lines<<header if header
 hash.each{|k,v|lines<<"#{JSON.generate(k)} = #{scalar(v)}" unless v.is_a?(Hash)||(v.is_a?(Array)&&v.first.is_a?(Hash))}
 hash.each do |k,v|
  key=(path+[k]).map{|part|JSON.generate(part)}.join('.')
  if v.is_a?(Hash);lines<<'';emit(v,path+[k],lines,header:"[#{key}]")
  elsif v.is_a?(Array)&&v.first.is_a?(Hash)
   v.each{|item|lines<<'';emit(item,path+[k],lines,header:"[[#{key}]]")}
  end
 end
 lines
end
results=[];fixtures=[]
[[1,2000],[8,500],[64,80]].each do |count,iterations|
 value={'schema_version'=>1,'server'=>{'host'=>'127.0.0.1','port'=>3307,'tls'=>true},'storage'=>{'bucket'=>'example-backups','prefix'=>'exports/'},'limits'=>{'memory_bytes'=>268435456,'chunk_rows'=>20000},'tables'=>Array.new(count){|i|{'source'=>"table_#{i}",'destination'=>"restored_#{i}",'key'=>'id','columns'=>%w[id text owner_id],'fields'=>{'id'=>{'action'=>'keep'},'text'=>{'action'=>'literal','value'=>'Lorem Ipsum 日本語'},'owner_id'=>{'action'=>'keep'}}}}}
 paths={};%w[json toml].each do |format|
  path=File.join(work,"#{count}-tables.#{format}");File.write(path,format=='json' ? JSON.pretty_generate(value)+"\n" : "# Public synthetic parser benchmark\n"+emit(value).join("\n")+"\n");paths[format]=path
 end
 fixtures<<{tables:count,json_bytes:File.size(paths['json']),toml_bytes:File.size(paths['toml'])}
 7.times do |rep|
  (rep.odd? ? %w[toml json] : %w[json toml]).each do |format|
   env={'CONFIG_BENCH_FORMAT'=>format,'CONFIG_BENCH_INPUT'=>paths.fetch(format),'CONFIG_BENCH_ITERATIONS'=>iterations.to_s,'TOML_LIBRARY'=>File.join(root,'build/native/libhey_toml.dylib')}
   out,err,status=Open3.capture3(env,File.join(root,'build/benchmark-worker'))
   raise 'Parser benchmark failed' unless status.success?
   result=JSON.parse(out);raise 'Fixture mismatch' unless result.fetch('checksum')==count*iterations
   results<<result.merge('tables'=>count,'repetition'=>rep+1,'ns_per_parse'=>result.fetch('elapsed_ns').to_f/iterations)
  end
 end
end
# Fresh process RSS sampling, excluding this harness and the database server.
memory=[]
%w[json toml].each do |format|
 path=File.join(work,"memory-#{format}.json")
 env={'CONFIG_BENCH_FORMAT'=>format,'CONFIG_BENCH_INPUT'=>File.join(work,"64-tables.#{format}"),'CONFIG_BENCH_ITERATIONS'=>'1000','TOML_LIBRARY'=>File.join(root,'build/native/libhey_toml.dylib')}
 pid=Process.spawn(env,File.join(root,'build/benchmark-worker'),out:path,err:File.join(work,"memory-#{format}.stderr"));peak=0;samples=0
 loop do
  text,status=Open3.capture2('ps','-axo','pid=,rss=');raise 'RSS sampling failed' unless status.success?
  row=text.lines.map{|line|line.split.map(&:to_i)}.find{|p,rss|p==pid};peak=[peak,row&.last.to_i].max;samples+=1
  exited=Process.waitpid2(pid,Process::WNOHANG);if exited;raise 'Profile worker failed' unless exited.last.success?;break;end
  sleep 0.05
 end
 memory<<{format:format,sampled_peak_rss_kib:peak,samples:samples}
end
receipt={observed_at:Time.now.utc.iso8601,platform:'darwin-arm64',measurement:'Compiled in-memory decoding into ordinary values, including the package native boundary and JSON tree conversion; excludes disk I/O, library loading, compilation, validation and process startup',fixtures:fixtures,timing_runs:results,memory:memory,binary_bytes:File.size(File.join(root,'build/benchmark-worker')),native_library_bytes:File.size(File.join(root,'build/native/libhey_toml.dylib')),limitations:['Local synthetic configuration, not database rows','JSON and TOML compare these exact implementations, not an inherent ranking of every parser','Seven alternating warm repetitions; RSS from separate fresh workers sampled about every 50ms, an observed lower bound','No YAML performance ranking measured; no production/staging access']}
File.write(File.join(work,'results.json'),JSON.pretty_generate(receipt)+"\n")
results.group_by{|r|[r['tables'],r['format']]}.each{|key,rows|puts JSON.generate(tables:key[0],format:key[1],median_us_per_parse:rows.map{|r|r['ns_per_parse']}.sort[3]/1000)}
puts JSON.generate(memory:memory)
