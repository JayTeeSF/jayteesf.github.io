# fake_inbox_server.rb: a small, synthetic conversation fixture for the Android inbox
# renderer test, specs/api_renderer_inbox_emulator_spec.sh.
#
#   fake_inbox_server.rb --port N --description FILE
require 'digest'
require 'json'
require 'optparse'
require 'securerandom'
require_relative 'fixture_http'

opts = {}
OptionParser.new do |o|
  o.on('--port N', Integer) { |v| opts[:port] = v }
  o.on('--description FILE') { |v| opts[:description] = v }
end.parse!
%i[port description].each { |k| abort("--#{k} is required") unless opts[k] }

tokens = {}
lock = Mutex.new
paragraph = 'Your note about keeping my shoulders relaxed helped. I paused after each set, checked the form, and followed the next movement at a comfortable pace. I replayed the instructions so I could compare how it felt with the explanation.'
body_text = "Thanks for sharing this video, Jay. I watched it all the way through and it helped me understand the movement.\n\n" +
            ([paragraph] * 18).join("\n\n") + "\n\nFINAL MESSAGE MARKER."
threads = {
  'threads' => [{
    'title' => 'A shared video', 'item_id' => 'share-1', 'friend' => 'Ron',
    'friend_initials' => 'R', 'unread_label' => "\u{1F534} 1 new"
  }],
  'sets' => [], 'items' => [], 'unread' => 1
}
thread = {
  'title' => 'A shared video', 'friend' => 'Ron', 'friend_initials' => 'R',
  'sharer' => 'Jay', 'sharer_initials' => 'J', 'recipient' => 'Ron',
  'recipient_initials' => 'R', 'events' => [{
    'actor' => 'Ron', 'actor_initials' => 'R', 'body' => body_text,
    'created_at' => '2026-10-19T12:00:00Z'
  }]
}

reply = lambda do |req, status, payload|
  body = JSON.generate(payload)
  req.respond(status, body, [['content-type', 'application/json; charset=utf-8'], ['content-length', body.bytesize.to_s]])
end

authorized = lambda do |req|
  header = req.header('authorization') || ''
  header.start_with?('Bearer ') && lock.synchronize { tokens.key?(header[7..-1]) }
end

get = lambda do |req|
  path = req.path
  if path == '/v1/app/description'
    data = File.binread(opts[:description])
    etag = "\"#{Digest::SHA256.hexdigest(data)}\""
    if (req.header('if-none-match') || '').gsub('W/') { '' } == etag
      next req.respond(304, '', [['etag', etag], ['content-length', '0']])
    end
    next req.respond(200, data, [['content-type', 'application/json'], ['content-length', data.bytesize.to_s], ['etag', etag]])
  end
  next reply.call(req, 401, 'ok' => false, 'error' => 'sign in first') unless authorized.call(req)
  case path
  when '/v1/session' then reply.call(req, 200, 'ok' => true, 'username' => 'ann')
  when '/v1/shared' then reply.call(req, 200, threads)
  when '/v1/shares/share-1/thread/Ron'
    threads['unread'] = 0
    threads['threads'][0]['unread_label'] = ''
    reply.call(req, 200, thread)
  else reply.call(req, 404, 'ok' => false, 'error' => 'not found')
  end
end

post = lambda do |req|
  path = req.path
  body = begin
    JSON.parse(req.body.empty? ? '{}' : req.body)
  rescue JSON::ParserError
    {}
  end
  if path == '/v1/session'
    if body['username'] != 'ann' || body['passphrase'] != 'fixture-pass-1'
      next reply.call(req, 401, 'ok' => false, 'error' => 'wrong name or passphrase')
    end
    token = SecureRandom.hex(24)
    lock.synchronize { tokens[token] = true }
    next reply.call(req, 200, 'ok' => true, 'username' => 'ann', 'token' => token)
  end
  next reply.call(req, 401, 'ok' => false, 'error' => 'sign in first') unless authorized.call(req)
  if path == '/v1/session/revoke'
    reply.call(req, 200, 'ok' => true)
  else
    reply.call(req, 404, 'ok' => false, 'error' => 'not found')
  end
end

FixtureHttp.serve(opts[:port], 'synthetic inbox fixture ready',
                  ->(req) { req.method == 'GET' ? get.call(req) : post.call(req) })
