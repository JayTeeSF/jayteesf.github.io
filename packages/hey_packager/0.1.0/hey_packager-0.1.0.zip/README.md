# hey_packager

`hey_packager` is package-owned porcelain for releasing and publishing Hey
packages. It keeps website-specific policy out of `stdlib:packages` while giving
every package the same verified ZIP, release metadata, checksums, documentation,
source handoff, and immutable registry workflow.

```sh
bin/hey-packager --help
bin/check
bin/release
bin/publish
```

The default website registry is:

```text
$HOME/dev/jayteesf.github.io/packages
```

Override it with `--registry-root` or `HEY_PACKAGE_REGISTRY_ROOT`.
