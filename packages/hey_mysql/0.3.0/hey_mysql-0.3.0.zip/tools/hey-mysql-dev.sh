#!/usr/bin/env sh
# Dispatcher for hey_mysql's dev-provisioning command set, run either as the
# locked package command (`hey mysql-dev SUBCOMMAND`, via bin/mysql-dev.hey)
# or directly from an installed package
# (.hey/packages/hey_mysql/<version>/tools/hey-mysql-dev.sh).
#
# All subcommands operate on the CONSUMER project: the current directory (or
# HEY_MYSQL_PROJECT_ROOT / HEY_PROJECT_ROOT). See docs: the provisioning
# contract is idempotent-by-default, destruction-is-a-flag, and every
# root-over-container-socket operation is gated on the compose-managed
# probe.
set -eu
SELF_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEV="$SELF_DIR/dev"

usage() {
  cat <<'HELP'
usage: hey mysql-dev SUBCOMMAND [args...]

Subcommands:
  up [--force]        Start the dev MySQL service. NO-OP when MySQL is
                      already serving; --force is the only recreation path.
  down                Stop containers and network (data volume preserved).
  clean-containers    down --remove-orphans (data volume preserved).
  configure-auth      Recreate the app account (TLS-required), grant every
                      environment's database, prove a TLS TCP login. Skips
                      loudly when the endpoint is not compose-managed.
  db-create           Create per-environment databases + grants for all.
  select-port [...]   Pick and persist a free MYSQL_PORT (see --help).
  probe               Is the resolved endpoint compose-managed? (exit 3: no)
  compose [args...]   Run docker compose (docker-compose fallback) for this
                      project.
  build-native        Build the native library into the project's .hey tree
                      and persist HEY_MYSQL_LIBRARY to .env.local.
  install-system-deps Install Connector/C + pkg-config via brew/apt.
  env-file-path       Print the sourceable env-layering helper's path.

Configuration (environment):
  HEY_MYSQL_PROJECT_ROOT   Consumer project root (default: $PWD).
  HEY_MYSQL_APP_NAME       Default identity for database/user/password
                           (default: app).
  HEY_MYSQL_ENV_VAR        Name of the environment-selector variable
                           (default: APP_ENV).
  HEY_MYSQL_SERVICE        Compose service name (default: mysql).
  HEY_MYSQL_PORT_DEFAULT   Preferred host port (default: 3307).
  HEY_MYSQL_EXTERNAL=1     Any external provider; never touch containers.
HELP
}

subcommand="${1:-help}"
test "$#" -gt 0 && shift

case "$subcommand" in
  up)                  exec "$DEV/mysql-up" "$@" ;;
  down)                exec "$DEV/mysql-down" "$@" ;;
  clean-containers)    exec "$DEV/mysql-clean-project-containers" "$@" ;;
  configure-auth)      exec "$DEV/mysql-configure-auth" "$@" ;;
  db-create)           exec "$DEV/db-create" "$@" ;;
  select-port)         exec "$DEV/select-mysql-port" "$@" ;;
  probe)               exec "$DEV/compose-managed" "$@" ;;
  compose)             exec "$DEV/compose" "$@" ;;
  build-native)        exec "$DEV/build-native-lib" "$@" ;;
  install-system-deps) exec "$DEV/install-system-deps" "$@" ;;
  env-file-path)       printf '%s\n' "$DEV/load-env" ;;
  help|-h|--help)      usage ;;
  *)
    echo "Unknown subcommand: $subcommand" >&2
    usage >&2
    exit 64
    ;;
esac
