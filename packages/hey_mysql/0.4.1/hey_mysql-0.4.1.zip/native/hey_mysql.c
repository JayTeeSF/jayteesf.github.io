#define _POSIX_C_SOURCE 200809L
#define _DARWIN_C_SOURCE
#include "hey_mysql.h"
#include <mysql.h>
#include "hey_mysql_tls.h"
#include <stdint.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

typedef struct HeyMysqlResult {
  MYSQL_RES *result;
  MYSQL *connection;
  uint32_t batch_error;
  int pending;
  int exhausted;
  MYSQL_ROW current;
  unsigned long *lengths;
} HeyMysqlResult;

static MYSQL *hey_mysql_connection(HeyNativeHandle value) {
  return (MYSQL *)(uintptr_t)value;
}

static HeyMysqlResult *hey_mysql_result(HeyNativeHandle value) {
  return (HeyMysqlResult *)(uintptr_t)value;
}

static char *hey_mysql_c_string(HeyNativeUtf8View value, int nullable) {
  if (nullable && value.data == NULL && value.length == 0) return NULL;
  char *out = (char *)malloc(value.length + 1);
  if (!out) return NULL;
  if (value.length && value.data) memcpy(out, value.data, value.length);
  out[value.length] = '\0';
  return out;
}

static void hey_mysql_release_bytes(void *context, uint8_t *data, size_t length) {
  (void)context;
  (void)length;
  free(data);
}

HeyNativeUtf8View hey_mysql_client_info(void) {
  const char *value = mysql_get_client_info();
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeHandle hey_mysql_init(void) {
  return (HeyNativeHandle)(uintptr_t)mysql_init(NULL);
}

int32_t hey_mysql_close(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  mysql_close(mysql);
  return 0;
}

int32_t hey_mysql_set_connect_timeout(HeyNativeHandle connection, uint32_t seconds) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_options(mysql, MYSQL_OPT_CONNECT_TIMEOUT, &seconds) : 1;
}

int32_t hey_mysql_set_read_timeout(HeyNativeHandle connection, uint32_t seconds) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_options(mysql, MYSQL_OPT_READ_TIMEOUT, &seconds) : 1;
}

int32_t hey_mysql_set_write_timeout(HeyNativeHandle connection, uint32_t seconds) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_options(mysql, MYSQL_OPT_WRITE_TIMEOUT, &seconds) : 1;
}

int32_t hey_mysql_set_ssl(HeyNativeHandle connection, HeyNativeUtf8View key, HeyNativeUtf8View certificate, HeyNativeUtf8View ca, HeyNativeUtf8View ca_path, HeyNativeUtf8View cipher) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *key_c = hey_mysql_c_string(key, 1);
  char *cert_c = hey_mysql_c_string(certificate, 1);
  char *ca_c = hey_mysql_c_string(ca, 1);
  char *path_c = hey_mysql_c_string(ca_path, 1);
  char *cipher_c = hey_mysql_c_string(cipher, 1);
  int rc = mysql_ssl_set(mysql, key_c, cert_c, ca_c, path_c, cipher_c);
  free(key_c);
  free(cert_c);
  free(ca_c);
  free(path_c);
  free(cipher_c);
  return rc;
}

HeyNativeUtf8View hey_mysql_tls_api(void) {
  const char *value = hey_mysql_tls_api_name();
  return (HeyNativeUtf8View){value, strlen(value)};
}

int32_t hey_mysql_set_ssl_mode(HeyNativeHandle connection, HeyNativeUtf8View mode) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *mode_c = hey_mysql_c_string(mode, 0);
  if (!mode_c) return 1;
  int rc = hey_mysql_apply_tls_mode(mysql, mode_c);
  free(mode_c);
  return rc;
}

int32_t hey_mysql_set_ssl_verify(HeyNativeHandle connection, HeyNativeBool verify) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  return hey_mysql_apply_tls_mode(mysql, verify ? "verify_server_cert" : "preferred");
}

HeyNativeBool hey_mysql_tls_active(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 0;
  const char *cipher = mysql_get_ssl_cipher(mysql);
  return cipher && *cipher ? 1 : 0;
}

int32_t hey_mysql_connect(HeyNativeHandle connection, HeyNativeUtf8View host, HeyNativeUtf8View username, HeyNativeUtf8View password, HeyNativeUtf8View database, uint32_t port, HeyNativeUtf8View socket, uint64_t flags) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *host_c = hey_mysql_c_string(host, 0);
  char *user_c = hey_mysql_c_string(username, 0);
  char *password_c = hey_mysql_c_string(password, 0);
  char *database_c = hey_mysql_c_string(database, 1);
  char *socket_c = hey_mysql_c_string(socket, 1);
  if (!host_c || !user_c || !password_c) {
    free(host_c);
    free(user_c);
    free(password_c);
    free(database_c);
    free(socket_c);
    return 1;
  }
  MYSQL *connected = mysql_real_connect(mysql, host_c, user_c, password_c, database_c, port, socket_c, (unsigned long)flags);
  free(host_c);
  free(user_c);
  free(password_c);
  free(database_c);
  free(socket_c);
  return connected ? 0 : (int32_t)mysql_errno(mysql);
}

int32_t hey_mysql_set_charset(HeyNativeHandle connection, HeyNativeUtf8View charset) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *charset_c = hey_mysql_c_string(charset, 0);
  if (!charset_c) return 1;
  int rc = mysql_set_character_set(mysql, charset_c);
  free(charset_c);
  return rc;
}

int32_t hey_mysql_select_db(HeyNativeHandle connection, HeyNativeUtf8View database) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *database_c = hey_mysql_c_string(database, 0);
  if (!database_c) return 1;
  int rc = mysql_select_db(mysql, database_c);
  free(database_c);
  return rc;
}

uint32_t hey_mysql_errcode(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint32_t)mysql_errno(mysql) : 0;
}

HeyNativeUtf8View hey_mysql_errmsg(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  const char *value = mysql ? mysql_error(mysql) : "invalid MySQL connection handle";
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeUtf8View hey_mysql_sqlstate(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  const char *value = mysql ? mysql_sqlstate(mysql) : "HY000";
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeUtf8View hey_mysql_server_info(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  const char *value = mysql ? mysql_get_server_info(mysql) : "";
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

uint64_t hey_mysql_thread_id(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint64_t)mysql_thread_id(mysql) : 0;
}

int32_t hey_mysql_query(HeyNativeHandle connection, HeyNativeUtf8View sql) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  return mysql_real_query(mysql, sql.data, (unsigned long)sql.length);
}

uint32_t hey_mysql_field_count(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint32_t)mysql_field_count(mysql) : 0;
}

HeyNativeHandle hey_mysql_store_result(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return (HeyNativeHandle)0;
  MYSQL_RES *stored = mysql_store_result(mysql);
  if (!stored) return (HeyNativeHandle)0;
  HeyMysqlResult *out = (HeyMysqlResult *)calloc(1, sizeof(HeyMysqlResult));
  if (!out) {
    mysql_free_result(stored);
    return (HeyNativeHandle)0;
  }
  out->result = stored;
  out->connection = mysql;
  return (HeyNativeHandle)(uintptr_t)out;
}

int32_t hey_mysql_free_result(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped) return 1;
  if (wrapped->result) mysql_free_result(wrapped->result);
  free(wrapped);
  return 0;
}

uint64_t hey_mysql_num_rows(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  return wrapped && wrapped->result ? (uint64_t)mysql_num_rows(wrapped->result) : 0;
}

uint32_t hey_mysql_num_fields(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  return wrapped && wrapped->result ? (uint32_t)mysql_num_fields(wrapped->result) : 0;
}

HeyNativeUtf8View hey_mysql_field_name(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || index >= mysql_num_fields(wrapped->result)) return (HeyNativeUtf8View){"", 0};
  MYSQL_FIELD *fields = mysql_fetch_fields(wrapped->result);
  const char *value = fields[index].name ? fields[index].name : "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeBool hey_mysql_fetch_row(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result) return 0;
  wrapped->current = mysql_fetch_row(wrapped->result);
  wrapped->lengths = wrapped->current ? mysql_fetch_lengths(wrapped->result) : NULL;
  return wrapped->current ? 1 : 0;
}

HeyNativeBool hey_mysql_column_is_null(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || index >= mysql_num_fields(wrapped->result)) return 1;
  return wrapped->current[index] == NULL ? 1 : 0;
}

HeyNativeUtf8View hey_mysql_column_text(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || !wrapped->lengths || index >= mysql_num_fields(wrapped->result) || wrapped->current[index] == NULL) return (HeyNativeUtf8View){"", 0};
  return (HeyNativeUtf8View){wrapped->current[index], (size_t)wrapped->lengths[index]};
}

HeyNativeBytesView hey_mysql_column_bytes(HeyNativeHandle result_set, uint32_t index) {
  static const uint8_t empty = 0;
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || !wrapped->lengths || index >= mysql_num_fields(wrapped->result) || wrapped->current[index] == NULL) return (HeyNativeBytesView){&empty, 0};
  return (HeyNativeBytesView){(const uint8_t *)wrapped->current[index], (size_t)wrapped->lengths[index]};
}

uint64_t hey_mysql_column_length(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || !wrapped->lengths || index >= mysql_num_fields(wrapped->result)) return 0;
  return (uint64_t)wrapped->lengths[index];
}

uint64_t hey_mysql_affected_rows(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint64_t)mysql_affected_rows(mysql) : 0;
}

uint64_t hey_mysql_insert_id(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint64_t)mysql_insert_id(mysql) : 0;
}

int32_t hey_mysql_autocommit(HeyNativeHandle connection, HeyNativeBool enabled) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_autocommit(mysql, enabled ? 1 : 0) : 1;
}

int32_t hey_mysql_commit(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_commit(mysql) : 1;
}

int32_t hey_mysql_rollback(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_rollback(mysql) : 1;
}

int32_t hey_mysql_ping(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_ping(mysql) : 1;
}

HeyNativeOwnedBytes hey_mysql_escape(HeyNativeHandle connection, HeyNativeUtf8View value) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return (HeyNativeOwnedBytes){0, 0, 0, 0};
  if (value.length > (SIZE_MAX - 1) / 2) return (HeyNativeOwnedBytes){0, 0, 0, 0};
  size_t capacity = value.length * 2 + 1;
  uint8_t *buffer = (uint8_t *)malloc(capacity);
  if (!buffer) return (HeyNativeOwnedBytes){0, 0, 0, 0};
  unsigned long length = mysql_real_escape_string(mysql, (char *)buffer, value.data, (unsigned long)value.length);
  return (HeyNativeOwnedBytes){buffer, (size_t)length, hey_mysql_release_bytes, NULL};
}

/* HYR1 bounded row batches. Column bytes remain opaque; no TSV or app policy here. */
HeyNativeHandle hey_mysql_use_result(HeyNativeHandle connection) {
  MYSQL *mysql=hey_mysql_connection(connection); if(!mysql)return 0;
  MYSQL_RES *res=mysql_use_result(mysql); if(!res)return 0;
  HeyMysqlResult *out=calloc(1,sizeof(*out));
  if(!out){mysql_free_result(res);return 0;}
  out->result=res;out->connection=mysql;return (HeyNativeHandle)(uintptr_t)out;
}
static void hey_mysql_put_u32(uint8_t *p,uint32_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);}
uint32_t hey_mysql_batch_error(HeyNativeHandle result_set){HeyMysqlResult *r=hey_mysql_result(result_set);return r?r->batch_error:1;}
HeyNativeOwnedBytes hey_mysql_read_batch(HeyNativeHandle result_set,uint32_t max_rows,uint32_t max_bytes,uint32_t max_record_bytes){
  HeyNativeOwnedBytes no={0};HeyMysqlResult *r=hey_mysql_result(result_set);if(!r)return no;
  if(r->batch_error)return no;
  if(!max_rows || max_rows>1000000 || max_bytes<64 || max_bytes>67108864 || !max_record_bytes || max_record_bytes>max_bytes-12){r->batch_error=1;return no;}
  uint32_t cols=mysql_num_fields(r->result),rows=0;size_t used=12;
  if(cols>max_record_bytes/4){r->batch_error=2;return no;}
  uint8_t *out=malloc(max_bytes);if(!out){r->batch_error=4;return no;}
  memcpy(out,"HYR1",4);hey_mysql_put_u32(out+8,cols);
  while(rows<max_rows && !r->exhausted){
    if(!r->pending){
      r->current=mysql_fetch_row(r->result);
      if(!r->current){r->exhausted=1;if(mysql_errno(r->connection)){r->batch_error=3;free(out);return no;}break;}
      r->lengths=mysql_fetch_lengths(r->result);
      if(!r->lengths){r->batch_error=3;free(out);return no;}
    }
    r->pending=0;size_t need=(size_t)cols*4;
    for(uint32_t i=0;i<cols;i++)if(r->current[i]){
      if(r->lengths[i]>=UINT32_MAX || r->lengths[i]>max_record_bytes || need>max_record_bytes-r->lengths[i]){r->batch_error=2;free(out);return no;}
      need+=r->lengths[i];
    }
    if(need>max_record_bytes){r->batch_error=2;free(out);return no;}
    if(need>max_bytes-used){r->pending=1;break;}
    for(uint32_t i=0;i<cols;i++){
      uint32_t n=r->current[i]?(uint32_t)r->lengths[i]:UINT32_MAX;
      hey_mysql_put_u32(out+used,n);used+=4;
      if(n!=UINT32_MAX && n){memcpy(out+used,r->current[i],n);used+=n;}
    }
    rows++;
  }
  hey_mysql_put_u32(out+4,rows);
  return (HeyNativeOwnedBytes){out,used,hey_mysql_release_bytes,NULL};
}

int32_t hey_mysql_set_local_infile(HeyNativeHandle connection,HeyNativeBool enabled){MYSQL *c=hey_mysql_connection(connection);unsigned int on=enabled?1:0;return c?mysql_options(c,MYSQL_OPT_LOCAL_INFILE,&on):1;}
uint32_t hey_mysql_warning_count(HeyNativeHandle connection){MYSQL *c=hey_mysql_connection(connection);return c?mysql_warning_count(c):UINT32_MAX;}
typedef struct {char *path;FILE *file;int error;} LocalInput;
static int local_init(void **data,const char *filename,void *userdata){
  LocalInput *in=userdata;*data=in;if(!in)return 1;
  if(!filename || strcmp(in->path,filename)){in->error=1;return 1;}
  int fd=open(in->path,O_RDONLY|O_NOFOLLOW);if(fd<0){in->error=1;return 1;}
  in->file=fdopen(fd,"rb");if(!in->file){close(fd);in->error=1;return 1;}return 0;
}
static int local_read(void *data,char *buf,unsigned int size){LocalInput *in=data;if(!in||!in->file)return -1;size_t n=fread(buf,1,size,in->file);if(ferror(in->file)){in->error=1;return -1;}return (int)n;}
static void local_end(void *data){LocalInput *in=data;if(in&&in->file){if(fclose(in->file))in->error=1;in->file=NULL;}}
static int local_error(void *data,char *buf,unsigned int len){(void)data;if(len){const char *message="approved bulk input failed";snprintf(buf,len,"%s",message);}return 1;}
int32_t hey_mysql_load_file(HeyNativeHandle connection,HeyNativeUtf8View sql,HeyNativeUtf8View path){
  MYSQL *c=hey_mysql_connection(connection);if(!c || !path.length || memchr(path.data,0,path.length))return 1;
  char *p=hey_mysql_c_string(path,0);if(!p)return 1;LocalInput input={p,NULL,0};
  mysql_set_local_infile_handler(c,local_init,local_read,local_end,local_error,&input);
  int rc=mysql_real_query(c,sql.data,(unsigned long)sql.length);
  mysql_set_local_infile_handler(c,local_init,local_read,local_end,local_error,NULL);if(input.file)fclose(input.file);free(p);return rc?rc:input.error;
}
