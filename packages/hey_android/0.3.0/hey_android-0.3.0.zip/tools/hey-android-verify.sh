#!/usr/bin/env bash
# tools/hey-android-verify.sh: the checks between the steps of the Android lane.
#
#   ir  APP.ll            the program's LLVM IR is something this lane can build
#   obj OBJECT.o          an aarch64 object with no OpenSSL, CommonCrypto or host-path trace
#   so  LIB.so            the shared library the APK loads
#   apk APP.apk [PKG_ID]  the signed APK
#
# Prints one "ok KIND key=value ..." line on success. On failure prints
# "FAIL KIND: reason" lines on stderr and exits 1. specs/android_build_spec.sh
# proves each check fails on a deliberately broken input.
#
# No pipefail here, on purpose: "llvm-nm ... | grep -q NAME" stops reading at the
# first match, llvm-nm dies of SIGPIPE, and pipefail would report a symbol that
# is present as missing. Every check below judges the content, not the exit
# status of the program producing it.
set -u
HEY_ANDROID_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
. "$HEY_ANDROID_ROOT/tools/android-env.sh"
hey_android_isolate

kind=${1:-}
target=${2:-}
failures=0
fail() { printf 'FAIL %s: %s\n' "$kind" "$*" >&2; failures=$((failures + 1)); }
finish() {
  if [ "$failures" -gt 0 ]; then
    printf 'FAIL %s: %d problem(s) in %s\n' "$kind" "$failures" "$target" >&2
    exit 1
  fi
}
case "$kind" in ir|obj|so|apk) ;; *) echo 'usage: hey-android-verify.sh ir|obj|so|apk FILE [PACKAGE_ID]' >&2; exit 2 ;; esac
[ -s "$target" ] || { fail "not found or empty: $target"; finish; }

# Symbols that mean a TLS library or Apple's crypto was compiled in. The profile
# renames the platform seam to hey_android_*, so none of these may appear.
FORBIDDEN_SYMBOLS='^(SSL_|BIO_|EVP_|RAND_|CRYPTO_|ERR_|X509|PEM_|OPENSSL|OpenSSL|OSSL_|TLS_client_method|TLS_server_method|d2i_|i2d_|ASN1_|CC_SHA|CC_MD|CCRandom|SecRandom|timingsafe_bcmp$)'
ALLOWED_NEEDED='libc.so libm.so libdl.so liblog.so libandroid.so'

first_lines() { head -n "${2:-3}" | tr '\n' ';' | sed 's/;$//'; }

check_elf_header() { # expected type: REL or DYN
  header=$("$HEY_ANDROID_READELF" -h "$target" 2>&1) || { fail "not an ELF file: $(printf '%s' "$header" | first_lines 1)"; return; }
  printf '%s\n' "$header" | grep -Eq 'Class:[[:space:]]+ELF64' || fail 'not a 64-bit ELF file'
  printf '%s\n' "$header" | grep -Eq 'Machine:[[:space:]]+AArch64' || fail "not built for aarch64: $(printf '%s\n' "$header" | grep Machine: | first_lines 1)"
  printf '%s\n' "$header" | grep -Eq "Type:[[:space:]]+$1" || fail "ELF type is not $1"
}

check_forbidden_symbols() {
  bad=$( { "$HEY_ANDROID_NM" --no-sort "$target" 2>/dev/null; "$HEY_ANDROID_NM" -D --no-sort "$target" 2>/dev/null; } |
    awk 'NF { print $NF }' | sed 's/@.*//' | grep -E "$FORBIDDEN_SYMBOLS" | sort -u)
  [ -z "$bad" ] || fail "OpenSSL or Apple crypto symbols: $(printf '%s\n' "$bad" | first_lines 8) ($(printf '%s\n' "$bad" | wc -l | tr -d ' ') in all)"
}

check_host_traces() {
  traces=$("$HEY_ANDROID_STRINGS" -a "$target" 2>/dev/null | grep -E "$HEY_ANDROID_HOST_TRACES" | sort -u)
  [ -z "$traces" ] || fail "host build paths inside: $(printf '%s\n' "$traces" | first_lines 3)"
}

verify_ir() {
  if grep -q '^; hey-stdlib-archive-required: true' "$target"; then
    fail 'the program needs libhey_stdlib.a, which this lane does not build for Android yet'
  fi
  lines=$(grep -nE '^target (triple|datalayout)' "$target")
  [ -z "$lines" ] || fail "the IR names a target, and this lane needs target-neutral IR: $(printf '%s\n' "$lines" | first_lines 2)"
  lines=$(grep -nE 'x86_fp80|ppc_fp128|x86_mmx|x86_amx|@llvm\.(x86|arm|aarch64|wasm|riscv)\.|"target-cpu"|"target-features"|dllimport|dllexport|section "__[A-Z]' "$target")
  [ -z "$lines" ] || fail "target-specific constructs: $(printf '%s\n' "$lines" | cut -c1-120 | first_lines 3)"
  defines=$(grep -cE '^define [^@]*@main\(' "$target")
  [ "$defines" = 1 ] || fail "expected exactly one define of @main, found $defines"
  grep -qE '^define i32 @main\(i32 %[^,]+, ptr %[^)]+\)' "$target" || fail 'main is not "i32 @main(i32, ptr)", the shape the glue calls'
  refs=$(grep -cE '@main([^A-Za-z0-9_.$]|$)' "$target")
  [ "$refs" = 1 ] || fail "@main is referenced $refs times; renaming it would break the other references"
  lines=$(grep -nE '@(hey_program_main|ANativeActivity_onCreate|__wrap_[A-Za-z_]+|__real_[A-Za-z_]+)([^A-Za-z0-9_.$]|$)' "$target")
  [ -z "$lines" ] || fail "the IR uses a name the glue owns: $(printf '%s\n' "$lines" | cut -c1-120 | first_lines 2)"

  # STDLIB CALLS HANDED TO THE TOOLCHAIN. The LLVM lane lowers many stdlib calls to
  # hey_llvm_stdlib_json_call(file, name, args, argc). The runtime answers the name
  # natively when its direct facade table has it (with that arity); otherwise it asks
  # a Hey toolchain found through HEY_ROOT. A phone has no toolchain, so such a call
  # fails at run time ("stdlib delegation refused", exit 70), while the same program
  # works on a Mac that has HEY_ROOT set. Measured with Files.write_text, 2026-09-13.
  # So every call is checked against the facade tables of the runtime being linked.
  stdlib=$(HEY_ANDROID_RUNTIME_SOURCE="${HEY_ROOT:-}/runtime/hey_runtime.c" /usr/bin/python3 - "$target" <<'PY'
import os, re, sys
ir = open(sys.argv[1], encoding="utf-8", errors="replace").read()
try:
    runtime = open(os.environ["HEY_ANDROID_RUNTIME_SOURCE"], encoding="utf-8", errors="replace").read()
except OSError:
    print("unreadable-runtime")
    sys.exit(0)
facades = {}
for m in re.finditer(r'\{"([A-Za-z][A-Za-z0-9_]*\.[A-Za-z0-9_?!]+)",\s*(-?\d+),\s*[A-Za-z_][A-Za-z0-9_]*\s*\}', runtime):
    facades.setdefault(m.group(1), set()).add(int(m.group(2)))
strings = dict(re.findall(r'^(@\.str(?:\.\d+)?) = [^\n]*?c"([^"]*?)\\00"', ir, re.M))
calls, delegated = 0, set()
for m in re.finditer(r'@hey_llvm_stdlib_json_call\(ptr (@\.str(?:\.\d+)?), ptr (@\.str(?:\.\d+)?), ptr [^,]+, i64 (-?\d+)\)', ir):
    calls += 1
    name, argc = strings.get(m.group(2), m.group(2)), int(m.group(3))
    if not (facades.get(name, set()) & {argc, -1}):
        delegated.add(f"{name}/{argc}")
print(f"calls={calls} facades={len(facades)}")
for d in sorted(delegated):
    print(d)
PY
)
  case "$stdlib" in
    unreadable-runtime) fail 'cannot read $HEY_ROOT/runtime/hey_runtime.c to check which stdlib calls are native; set HEY_ROOT' ;;
    *)
      delegated=$(printf '%s\n' "$stdlib" | sed 1d)
      [ -z "$delegated" ] || fail "the program hands $(printf '%s\n' "$delegated" | first_lines 6) to the Hey toolchain at run time (no native facade in this runtime), and a phone has no toolchain"
      ;;
  esac
  finish
  runtime_required=false
  grep -q '^; hey-runtime-required: true' "$target" && runtime_required=true
  printf 'ok ir runtime_required=%s defines=%s declares=%s stdlib_%s delegated=0 sha256=%s\n' "$runtime_required" \
    "$(grep -c '^define ' "$target")" "$(grep -c '^declare ' "$target")" "$(printf '%s\n' "$stdlib" | sed -n 1p | cut -d' ' -f1)" "$(hey_android_sha256 "$target")"
}

verify_obj() {
  check_elf_header REL
  check_forbidden_symbols
  check_host_traces
  finish
  printf 'ok obj undefined=%s sha256=%s\n' "$("$HEY_ANDROID_NM" -u "$target" | grep -c .)" "$(hey_android_sha256 "$target")"
}

verify_so() {
  check_elf_header DYN
  aligns=$("$HEY_ANDROID_READELF" -lW "$target" | awk '$1 == "LOAD" { print $NF }')
  load_count=$(printf '%s\n' "$aligns" | grep -c .)
  [ "$load_count" -gt 0 ] || fail 'no LOAD segments'
  for align in $aligns; do
    [ $((align)) -eq "$HEY_ANDROID_PAGE_SIZE" ] || fail "a LOAD segment is aligned to $align, not $HEY_ANDROID_PAGE_SIZE (16 KB pages)"
  done
  if "$HEY_ANDROID_READELF" -lW "$target" | awk '$1 == "GNU_STACK"' | grep -q 'RWE'; then fail 'the stack is executable'; fi

  needed=$("$HEY_ANDROID_READELF" -d "$target" | sed -n 's/.*(NEEDED).*\[\(.*\)\].*/\1/p')
  provided=''
  for lib in $needed; do
    case " $ALLOWED_NEEDED " in
      *" $lib "*) provided="$provided$("$HEY_ANDROID_NM" -D --defined-only "$HEY_ANDROID_SYSROOT_LIB/$lib" 2>/dev/null | awk 'NF { print $NF }' | sed 's/@.*//')
" ;;
      *) fail "needs $lib, which is not an allowed Android system library ($ALLOWED_NEEDED)" ;;
    esac
  done
  undefined=$("$HEY_ANDROID_NM" -D --undefined-only "$target" | awk '$1 == "U" { print $NF }' | sed 's/@.*//' | sort -u)
  undefined_count=$(printf '%s\n' "$undefined" | grep -c .)
  unresolved=$(comm -23 <(printf '%s\n' "$undefined" | grep .) <(printf '%s' "$provided" | grep . | sort -u))
  unresolved_count=$(printf '%s\n' "$unresolved" | grep -c .)
  [ "$unresolved_count" = 0 ] || fail "$unresolved_count undefined symbols no allowed system library at API $HEY_ANDROID_MIN_SDK provides: $(printf '%s\n' "$unresolved" | first_lines 8)"
  "$HEY_ANDROID_NM" -D --defined-only "$target" | awk '{ print $NF }' | grep -qx ANativeActivity_onCreate ||
    fail 'ANativeActivity_onCreate is not exported, so NativeActivity cannot start the app'
  check_forbidden_symbols
  check_host_traces
  finish
  printf 'ok so machine=aarch64 load_segments=%s load_align=%s needed=%s undefined=%s unresolved=0 bytes=%s sha256=%s\n' \
    "$load_count" "$HEY_ANDROID_PAGE_SIZE" "$(printf '%s\n' "$needed" | paste -sd, -)" "$undefined_count" \
    "$(wc -c < "$target" | tr -d ' ')" "$(hey_android_sha256 "$target")"
}

verify_apk() {
  package=${3:-}
  bt=$HEY_ANDROID_BUILD_TOOLS_DIR
  java_home=$(hey_android_java_home)
  lib_entry="lib/$HEY_ANDROID_ABI/lib$HEY_ANDROID_LIB_NAME.so"

  badging=$("$bt/aapt2" dump badging "$target" 2>&1) || { fail "aapt2 cannot read the APK: $(printf '%s\n' "$badging" | first_lines 2)"; finish; }
  if [ -n "$package" ]; then
    printf '%s\n' "$badging" | grep -q "^package: name='$package'" || fail "package id is not $package"
  fi
  printf '%s\n' "$badging" | grep -q "^targetSdkVersion:'$HEY_ANDROID_TARGET_SDK'" || fail "targetSdkVersion is not $HEY_ANDROID_TARGET_SDK"
  printf '%s\n' "$badging" | grep -q "^minSdkVersion:'$HEY_ANDROID_MIN_SDK'" || fail "minSdkVersion is not $HEY_ANDROID_MIN_SDK"
  printf '%s\n' "$badging" | grep -q "^launchable-activity: name='android.app.NativeActivity'" || fail 'the launcher activity is not android.app.NativeActivity'
  printf '%s\n' "$badging" | grep -qx "native-code: '$HEY_ANDROID_ABI'" || fail "native code is not exactly '$HEY_ANDROID_ABI'"

  xml=$("$bt/aapt2" dump xmltree --file AndroidManifest.xml "$target" 2>&1)
  has_code=$(printf '%s\n' "$xml" | sed -n 's/.*:hasCode([^)]*)=\([a-z]*\).*/\1/p' | head -1)
  [ "$has_code" = false ] || fail "application hasCode is '${has_code:-unset, which means true}', not false"
  extract=$(printf '%s\n' "$xml" | sed -n 's/.*:extractNativeLibs([^)]*)=\([a-z]*\).*/\1/p' | head -1)
  [ "$extract" = false ] || fail "extractNativeLibs is '${extract:-unset}', not false"

  entries=$(/usr/bin/unzip -Z1 "$target" 2>/dev/null)
  dex=$(printf '%s\n' "$entries" | grep -E '\.dex$')
  dex_count=$(printf '%s\n' "$dex" | grep -c .)
  [ "$dex_count" = 0 ] || fail "the APK contains dex code, and a hey_android APK has none: $(printf '%s\n' "$dex" | first_lines 3)"
  jvm=$(printf '%s\n' "$entries" | grep -E '\.(jar|kotlin_module|class)$|^kotlin/')
  [ -z "$jvm" ] || fail "the APK contains JVM files: $(printf '%s\n' "$jvm" | first_lines 3)"
  libs=$(printf '%s\n' "$entries" | grep -E '^lib/')
  [ "$libs" = "$lib_entry" ] || fail "native libraries are '$(printf '%s\n' "$libs" | first_lines 4)', expected only $lib_entry"
  /usr/bin/zipinfo -v "$target" "$lib_entry" 2>/dev/null | grep -Eq 'compression method:[[:space:]]+none \(stored\)' ||
    fail "$lib_entry is compressed; it must be stored so it loads in place"

  align=$("$bt/zipalign" -c -P 16 -v 4 "$target" 2>&1)
  zipalign_ok=true
  if ! printf '%s\n' "$align" | grep -q 'Verification successful' || ! printf '%s\n' "$align" | grep -F "$lib_entry" | grep -q '(OK'; then
    zipalign_ok=false
    fail "zipalign -c -P 16 does not pass: $(printf '%s\n' "$align" | grep -v '(OK' | first_lines 3)"
  fi

  signer_sha=''
  v2=false; v3=false
  if [ -z "$java_home" ]; then
    fail "JDK $HEY_ANDROID_JDK not found, so the signature cannot be verified"
  else
    sig=$(env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" verify --verbose --print-certs "$target" 2>&1)
    printf '%s\n' "$sig" | grep -q '^Verifies' || fail "the signature does not verify: $(printf '%s\n' "$sig" | first_lines 2)"
    printf '%s\n' "$sig" | grep -q 'v2 scheme (APK Signature Scheme v2): true' && v2=true
    printf '%s\n' "$sig" | grep -q 'v3 scheme (APK Signature Scheme v3): true' && v3=true
    [ "$v2" = true ] || [ "$v3" = true ] || fail 'neither a v2 nor a v3 signature is present'
    signer_sha=$(printf '%s\n' "$sig" | sed -n 's/^Signer #1 certificate SHA-256 digest: //p' | head -1)
  fi

  if printf '%s\n' "$entries" | grep -qx "$lib_entry"; then
    scratch=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-verify.XXXXXX")
    /usr/bin/unzip -q -o "$target" "$lib_entry" -d "$scratch"
    if ! so_line=$("$0" so "$scratch/$lib_entry" 2>&1); then
      fail "the packaged library: $(printf '%s\n' "$so_line" | grep '^FAIL' | first_lines 4)"
    fi
    rm -rf "$scratch"
  fi
  finish
  printf 'ok apk package=%s target_sdk=%s min_sdk=%s has_code=false dex=0 lib=%s lib_stored=true zipalign_16k=%s v2=%s v3=%s signer_sha256=%s bytes=%s sha256=%s\n' \
    "$(printf '%s\n' "$badging" | sed -n "s/^package: name='\([^']*\)'.*/\1/p")" "$HEY_ANDROID_TARGET_SDK" "$HEY_ANDROID_MIN_SDK" \
    "$lib_entry" "$zipalign_ok" "$v2" "$v3" "$signer_sha" "$(wc -c < "$target" | tr -d ' ')" "$(hey_android_sha256 "$target")"
}

case "$kind" in
  ir) verify_ir ;;
  obj) verify_obj ;;
  so) verify_so ;;
  apk) verify_apk "$@" ;;
esac
