# Todos

- Recognize the Secret value kind once the Hey team ships it (docs/ROADMAP.md).
