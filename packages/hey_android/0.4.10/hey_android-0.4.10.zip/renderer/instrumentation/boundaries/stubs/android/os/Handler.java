package android.os;
import java.util.ArrayList;
import java.util.List;
public class Handler {
  public static final List<Runnable> pending = new ArrayList<>();
  private static class Posted implements Runnable {
    final Handler owner;
    final Runnable action;
    Posted(Handler owner, Runnable action) { this.owner = owner; this.action = action; }
    public void run() { action.run(); }
  }
  public Handler(Looper looper) {}
  public boolean post(Runnable r) { synchronized (pending) { pending.add(new Posted(this, r)); } return true; }
  public boolean postDelayed(Runnable r, long delay) { return post(r); }
  public void removeCallbacksAndMessages(Object token) { synchronized (pending) { pending.removeIf(r -> ((Posted) r).owner == this); } }
  public static void drain() {
    List<Runnable> copy;
    synchronized (pending) { copy = new ArrayList<>(pending); pending.clear(); }
    for (Runnable r : copy) r.run();
  }
}
