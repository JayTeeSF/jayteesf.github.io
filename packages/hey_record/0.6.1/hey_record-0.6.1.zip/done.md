# Done

- Added SQLite and MySQL dialect descriptors.
- Added parameterized select/insert/update/delete plans.
- Added immutable datasets, safe order helpers, transactions, model descriptors, and adapter-aware migration DDL.
- Preserved explicit connection injection and independent driver releases.
- Removed release tooling from runtime dependencies and refreshed adapter-version guidance.
- Added HeyRecordStore (store.hey): JSON record store over collection + id, file and injected-connection SQL backends, extracted from RecallCoach's RecallStorage; delete reports absent records as typed not_found; no nil across the API.
- Added HeyRecordMigrate (migrate.hey): schema_migrations-style migration ledger with idempotent ensure over SQL and file targets.
- Made HeyRecordDialect.named refuse unknown dialect names instead of silently defaulting to sqlite3, with a negative probe in bin/package-check.
- Added the compiled-lane receipt to bin/package-check: interpreter and heyc-built binary output byte-identical for store/ledger/dialect/sql/dataset.
- Added HeyRecordReader (reader.hey): Web.serve worker_resource hooks for one long-lived reader per serving worker, with setup and statement warming, and a nil fallback for runtimes and callers without a reader.
- Restored hey_record's tree after the 0.5.3 release commit replaced it with hey_sqlite3's.
- 0.6.1: Web.serve readers come from plain module functions; HeyRecordReader.hooks (bind over the spec) is for single-threaded callers, after bound specs were corrupted across Web.serve worker threads on the 611a candidate.
