# Done

- 0.1.0: batched edge-triggered TCP loop over Hey's native ABI v2: epoll on Linux, kqueue on Darwin for development; accept-time read; per-connection input buffers with consumed-byte hand-back (partial and pipelined requests need no Hey-side state); write-through with EPOLLOUT backpressure; UTF-8/NUL refusal; stale-id generations; SO_REUSEPORT for one loop per worker; spec with a negative control.
- 0.1.1: an idle connection keeps no input or output buffer (0.1.0 kept the first 1 KiB input buffer for the life of the connection: 64 MB of RSS at 64,000 keep-alive connections).
