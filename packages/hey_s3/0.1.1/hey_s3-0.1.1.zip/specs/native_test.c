#include "hey_s3.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static HeyNativeUtf8View v(const char *s){return (HeyNativeUtf8View){s,strlen(s)};}
int main(int argc,char **argv){assert(argc==5);const char *endpoint=argv[1],*input=argv[2],*out=argv[3],*sha=argv[4];
 HeyNativeHandle c=s3_open(v(endpoint),v("us-east-1"),v("fixture-bucket"),v("fixture-access"),v("fixture-secret"),v("fixture-token"),1);assert(c);
 assert(s3_request(c,2,v("a/./b"),v(input),v(sha),v("*"),1048576)==200);
 assert(s3_request(c,2,v("a/./b"),v(input),v(sha),v("*"),1048576)==412);
 assert(s3_request(c,0,v("a/./b"),v(""),v(""),v(""),1048576)==200);
 HeyNativeOwnedBytes e=s3_header(c,v("etag"));assert(e.length>2);char etag[256];assert(e.length<sizeof(etag));memcpy(etag,e.data,e.length);etag[e.length]=0;e.release(e.context,e.data,e.length);
 assert(s3_request(c,2,v("a/./b"),v(input),v(sha),v("\"wrong\""),1048576)==412);
 assert(s3_request(c,2,v("a/./b"),v(input),v(sha),v(etag),1048576)==200);
 assert(s3_request(c,1,v("a/./b"),v(out),v("0000000000000000000000000000000000000000000000000000000000000000"),v(""),1048576)<0);assert(access(out,F_OK));
 assert(s3_request(c,1,v("a/./b"),v(out),v(sha),v(""),1048576)==200);assert(!access(out,F_OK));
 assert(s3_request(c,1,v("a/./b"),v(out),v(sha),v(""),1048576)<0);assert(!access(out,F_OK));unlink(out);
 assert(s3_request(c,1,v("a/./b"),v(out),v(sha),v(""),1)<0);assert(access(out,F_OK));
 assert(s3_request(c,1,v("missing"),v(out),v(""),v(""),1048576)==404);assert(access(out,F_OK));
 assert(s3_request(c,1,v("truncated"),v(out),v(""),v(""),1048576)<0);assert(access(out,F_OK));
 assert(s3_request(c,1,v("redirect"),v(out),v(""),v(""),1048576)==301);assert(access(out,F_OK));
 assert(s3_request(c,0,v("../escape"),v(""),v(""),v(""),1048576)<0);
 assert(s3_close(c)==0);puts("PASS: signed streaming, exact keys, CAS, integrity, bounds, truncation, file safety");return 0;
}
