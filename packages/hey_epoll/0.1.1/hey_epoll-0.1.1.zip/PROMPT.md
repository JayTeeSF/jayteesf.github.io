# Continue hey_epoll

Read README.md, docs/README.md, todos.md, done.md, hey.native.json, the
native source and the specs before editing.

hey_epoll is an independent package. Hey owns the generic native ABI, loader
and package plumbing; this package owns the event loop. Keep handles opaque,
blocking calls honest (`wait` is the only blocking function), and one loop per
thread.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

Published versions are immutable. Change the version whenever released bytes change.
