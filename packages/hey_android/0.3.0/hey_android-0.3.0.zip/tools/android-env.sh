# shellcheck shell=bash
# tools/android-env.sh: shared by bin/android-doctor and tools/*.sh. Sourced, never run.
# The caller sets HEY_ANDROID_ROOT to the package root first.

. "$HEY_ANDROID_ROOT/tools/android-pins.env"
HEY_ANDROID_VERSION=$(tr -d '[:space:]' < "$HEY_ANDROID_ROOT/VERSION")

ANDROID_HOME=${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Library/Android/sdk}}
case "$(uname -s)" in
  Darwin) HEY_ANDROID_HOST_TAG=darwin-x86_64 ;; # a universal binary; runs natively on arm64
  Linux) HEY_ANDROID_HOST_TAG=linux-x86_64 ;;
  *) HEY_ANDROID_HOST_TAG=unsupported ;;
esac
HEY_ANDROID_NDK_ROOT=$ANDROID_HOME/ndk/$HEY_ANDROID_NDK
HEY_ANDROID_NDK_BIN=$HEY_ANDROID_NDK_ROOT/toolchains/llvm/prebuilt/$HEY_ANDROID_HOST_TAG/bin
HEY_ANDROID_SYSROOT=$HEY_ANDROID_NDK_ROOT/toolchains/llvm/prebuilt/$HEY_ANDROID_HOST_TAG/sysroot
HEY_ANDROID_SYSROOT_LIB=$HEY_ANDROID_SYSROOT/usr/lib/aarch64-linux-android/$HEY_ANDROID_MIN_SDK
HEY_ANDROID_CLANG=$HEY_ANDROID_NDK_BIN/clang
HEY_ANDROID_NM=$HEY_ANDROID_NDK_BIN/llvm-nm
HEY_ANDROID_READELF=$HEY_ANDROID_NDK_BIN/llvm-readelf
HEY_ANDROID_STRINGS=$HEY_ANDROID_NDK_BIN/llvm-strings
HEY_ANDROID_BUILD_TOOLS_DIR=$ANDROID_HOME/build-tools/$HEY_ANDROID_BUILD_TOOLS
HEY_ANDROID_PLATFORM_JAR=$ANDROID_HOME/platforms/android-$HEY_ANDROID_COMPILE_SDK/android.jar
HEY_ANDROID_ADB=$ANDROID_HOME/platform-tools/adb
HEY_ANDROID_EMULATOR_BIN=$ANDROID_HOME/emulator/emulator
HEY_ANDROID_SDKMANAGER=$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager
HEY_ANDROID_AVDMANAGER=$ANDROID_HOME/cmdline-tools/latest/bin/avdmanager
HEY_ANDROID_LIB_NAME=hey_app

hey_android_sha256() {
  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | cut -c1-64; else sha256sum "$1" | cut -c1-64; fi
}

# property FILE KEY: the value of KEY= in a source.properties file
hey_android_property() {
  # NDK files write "key = value", SDK files "key=value".
  awk -v key="$2" '{ k = $0; sub(/[ \t]*=.*/, "", k) } k == key { sub(/^[^=]*=[ \t]*/, ""); sub(/[ \t\r]+$/, ""); print; exit }' "$1" 2>/dev/null
}

# The JDK 17 home, or nothing. JAVA_HOME wins when it is a 17.
hey_android_java_home() {
  _jh=''
  if [ -n "${JAVA_HOME:-}" ] && "$JAVA_HOME/bin/java" -version 2>&1 | grep -q "version \"$HEY_ANDROID_JDK\."; then
    _jh=$JAVA_HOME
  elif [ -x /usr/libexec/java_home ]; then
    _jh=$(/usr/libexec/java_home -v "$HEY_ANDROID_JDK" 2>/dev/null || true)
  fi
  if [ -n "$_jh" ] && "$_jh/bin/java" -version 2>&1 | grep -q "version \"$HEY_ANDROID_JDK\."; then
    printf '%s\n' "$_jh"
  fi
}

# BUILD ISOLATION. The Maintainer's shell exports CPATH=/opt/homebrew/include,
# LIBRARY_PATH, CPPFLAGS and LDFLAGS. NDK clang honours all of them, and in the
# 2026-09-13 spike it compiled Homebrew's macOS OpenSSL headers into an
# "Android" runtime object without a single error. So every variable a C
# compiler or linker reads is removed, and PATH is reduced to the system
# directories, before any Android build step. Tools are called by absolute
# path. The host PATH is kept in HEY_ANDROID_HOST_PATH for heyc, which is a
# host program.
HEY_ANDROID_CLEARED_VARIABLES="CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH CPPFLAGS CFLAGS CXXFLAGS LDFLAGS SDKROOT PKG_CONFIG_PATH DYLD_LIBRARY_PATH DYLD_FALLBACK_LIBRARY_PATH LD_LIBRARY_PATH"
hey_android_isolate() {
  HEY_ANDROID_HOST_PATH=${HEY_ANDROID_HOST_PATH:-$PATH}
  export HEY_ANDROID_HOST_PATH
  HEY_ANDROID_CONTAMINATION_SEEN=''
  for _v in $HEY_ANDROID_CLEARED_VARIABLES; do
    if [ -n "${!_v:-}" ]; then HEY_ANDROID_CONTAMINATION_SEEN="$HEY_ANDROID_CONTAMINATION_SEEN $_v"; fi
    unset "$_v"
  done
  HEY_ANDROID_CONTAMINATION_SEEN=${HEY_ANDROID_CONTAMINATION_SEEN# }
  PATH=/usr/bin:/bin:/usr/sbin:/sbin
  export PATH
}

# The directories NDK clang searches for #include <...>, one per line.
hey_android_include_search_path() {
  "$HEY_ANDROID_CLANG" --target="$HEY_ANDROID_TARGET" -E -v -x c /dev/null -o /dev/null 2>&1 |
    awk '/#include <...> search starts here:/ { on = 1; next } /End of search list/ { on = 0 } on { sub(/^ +/, ""); print }'
}

HEY_ANDROID_HOST_TRACES='/opt/homebrew|/usr/local/(include|lib|opt|Cellar)|/Cellar/|openssl@[0-9]|libssl\.(so|dylib|a)|libcrypto\.(so|dylib|a)|MacOSX[0-9.]*\.sdk'

# ---- which Hey checkout -------------------------------------------------------------------
# The runtime compiled into the app comes from this checkout, so it is named explicitly
# (--hey-root or HEY_ROOT) and never guessed, as in hey_ios_tv's tool.
hey_android_resolve_hey_root() {
  _arg=${1:-}
  if [ -n "$_arg" ]; then _dir=$_arg; HEY_ROOT_SOURCE=--hey-root
  elif [ -n "${HEY_ROOT:-}" ]; then _dir=$HEY_ROOT; HEY_ROOT_SOURCE=HEY_ROOT
  else
    echo 'no Hey checkout was named; pass --hey-root DIR or export HEY_ROOT' >&2
    return 2
  fi
  [ -d "$_dir" ] || { echo "the named Hey checkout does not exist ($HEY_ROOT_SOURCE): $_dir" >&2; return 2; }
  _dir=$(CDPATH= cd -- "$_dir" && pwd)
  for _need in bin/heyc runtime/hey_runtime.c runtime/hey_compiler_nodes_bundle.c; do
    [ -e "$_dir/$_need" ] || { echo "$_dir is not a Hey checkout ($HEY_ROOT_SOURCE): missing $_need" >&2; return 2; }
  done
  HEY_ROOT=$_dir
  export HEY_ROOT
}

# Same computation as hey_ios_tv and Hey core's bin/hey-hermetic-run, so receipts compare.
hey_android_compiler_identity() {
  _h=''
  for _f in "$HEY_ROOT/build/hey-selfc" "$HEY_ROOT/build/heyc"; do
    [ -f "$_f" ] && _h="$_h$(hey_android_sha256 "$_f")"
  done
  if [ -z "$_h" ]; then printf 'unbuilt\n'; return; fi
  printf '%s\n' "$_h" | shasum -a 256 | cut -c1-16
}

hey_android_hey_head() {
  if [ -d "$HEY_ROOT/.git" ]; then git -C "$HEY_ROOT" rev-parse --short HEAD 2>/dev/null || echo unknown; else echo not-a-git-checkout; fi
}

# The Makefile's own source of HEY_VERSION, so the runtime reports the same version on Android.
hey_android_hey_version() {
  _v=''
  if [ -x "$HEY_ROOT/bin/subcmds/hey-version" ]; then
    _v=$(cd "$HEY_ROOT" && env PATH="${HEY_ANDROID_HOST_PATH:-$PATH}" ./bin/subcmds/hey-version current 2>/dev/null | sed -n 1p | tr -d '[:space:]')
  fi
  printf '%s\n' "${_v:-unknown}"
}
