// Real UIKit reply form, synthetic transport and session. Presentation stays real.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wnullability-completeness"
#import "HeyIOSApiHost.m"
#pragma clang diagnostic pop
#import <objc/runtime.h>

static NSData *manifestData;
static NSData *artwork;
static NSArray *activityItems;
static id<UIActivityItemsConfigurationReading> activityConfiguration;
static BOOL receivedText, receivedLink, attachmentAvailable;
static NSInteger imageProviderCount, richPreviewImageCount, separateURLCount;
static NSString *const message = @"Thanks — this exact reply\nhas a second line. 🎬";
static NSString *const conversationURL = @"https://share-flow.example.test/shared/film-17/thread/alice";
static NSInteger posts, reads, failures;
static BOOL holdImage, popAfterSave, testRetry, failImage;
static NSMutableArray *heldImages;
static UIImage *loadedImage;
static NSError *imageLoadError;
static NSString *scopeTest;
static NSString *currentSession;
static NSString *expectedText;
static NSString *savedText;
static NSString *imageMode;
static NSInteger imageRequests;
static NSInteger imageCompletions;
static BOOL holdPost, missingShare;
static id pendingPost;
static NSData *pendingPostBody;
static BOOL sawArtworkFailure;
static HeyIOSFormController *composer;
static HeyIOSListController *thread;

const char *HeyIOSBakedOrigin(void) { return "https://share-flow.example.test"; }
static const char *manifest(void) { return manifestData.bytes; }
static int64_t manifestLength(void) { return manifestData.length - 1; }
static void check(BOOL ok, NSString *why) {
  if (!ok) { fprintf(stderr, "share-flow: FAIL %s\n", why.UTF8String); failures++; }
}
static void after(double seconds, void (^run)(void)) {
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(seconds * NSEC_PER_SEC)), dispatch_get_main_queue(), run);
}
static NSDictionary *presentation(void) {
  return @{@"title": @"Original synthetic film", @"text": savedText ?: message,
    @"url": conversationURL, @"image_url": @"https://share-flow.example.test/artwork.png"};
}
static UIViewController *presented(void) {
  UIViewController *vc = [HeyIOSHost shared].window.rootViewController;
  while (YES) {
    if (vc.presentedViewController) { vc = vc.presentedViewController; continue; }
    if ([vc isKindOfClass:UITabBarController.class]) { vc = ((UITabBarController *)vc).selectedViewController; continue; }
    if ([vc isKindOfClass:UINavigationController.class]) { vc = ((UINavigationController *)vc).topViewController; continue; }
    break;
  }
  return vc;
}
static NSArray *descendants(UIView *view) {
  NSMutableArray *out = [NSMutableArray array];
  for (UIView *child in view.subviews) { [out addObject:child]; [out addObjectsFromArray:descendants(child)]; }
  return out;
}
static void observeArtworkFailure(void) {
  for (UIView *view in descendants([HeyIOSHost shared].window)) {
    if ([view isKindOfClass:UILabel.class] && [view.accessibilityIdentifier isEqual:@"toast"] &&
        !view.hidden && view.alpha > 0.05 && [((UILabel *)view).text containsString:@"Artwork"]) sawArtworkFailure = YES;
  }
  after(0.1, ^{ observeArtworkFailure(); });
}

@interface ShareTransport : NSURLProtocol
@property(nonatomic, strong) dispatch_source_t drip;
@property(nonatomic, assign) BOOL stopped;
- (void)answerImage;
@end
@implementation ShareTransport
+ (BOOL)canInitWithRequest:(NSURLRequest *)request { return YES; }
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }
- (void)reply:(NSData *)data type:(NSString *)type {
  NSHTTPURLResponse *response = [[NSHTTPURLResponse alloc] initWithURL:self.request.URL statusCode:200 HTTPVersion:@"HTTP/1.1" headerFields:@{@"Content-Type": type}];
  [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
  [self.client URLProtocol:self didLoadData:data];
  [self.client URLProtocolDidFinishLoading:self];
}
- (void)answerImage {
  if (self.stopped) return;
  if ([imageMode isEqual:@"drip"]) {
    NSHTTPURLResponse *response = [[NSHTTPURLResponse alloc] initWithURL:self.request.URL statusCode:200 HTTPVersion:@"HTTP/1.1" headerFields:@{@"Content-Type": @"image/png"}];
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
    self.drip = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(self.drip, dispatch_time(DISPATCH_TIME_NOW, 0), NSEC_PER_SEC / 10, NSEC_PER_SEC / 100);
    dispatch_source_set_event_handler(self.drip, ^{ if (!self.stopped) [self.client URLProtocol:self didLoadData:[NSData dataWithBytes:"x" length:1]]; });
    dispatch_resume(self.drip); return;
  }
  NSData *data = artwork;
  if ([imageMode isEqual:@"oversize"]) {
    NSMutableData *large = [artwork mutableCopy]; [large appendData:[NSMutableData dataWithLength:5 * 1024 * 1024]]; data = large;
  } else if ([imageMode isEqual:@"malformed"]) data = [@"not an image" dataUsingEncoding:NSUTF8StringEncoding];
  [self reply:data type:@"image/png"];
}
- (void)startLoading {
  check([self.request.URL.host isEqual:@"share-flow.example.test"], @"request escaped synthetic server");
  if ([self.request.URL.path isEqual:@"/artwork.png"]) {
    imageRequests++;
    check([self.request valueForHTTPHeaderField:@"authorization"] == nil, @"artwork fetch leaked the account token");
    if (holdImage) { @synchronized (heldImages) { [heldImages addObject:self]; } return; }
    if (failImage) { [self.client URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorTimedOut userInfo:nil]]; return; }
    [self answerImage];
    return;
  }
  check([[self.request valueForHTTPHeaderField:@"authorization"] isEqual:@"Bearer synthetic-account-alice"], @"API request lost account token");
  if ([self.request.HTTPMethod isEqual:@"POST"]) {
    posts++;
    NSData *body = self.request.HTTPBody;
    if (!body && self.request.HTTPBodyStream) {
      NSMutableData *read = [NSMutableData data];
      NSInputStream *stream = self.request.HTTPBodyStream;
      [stream open]; uint8_t bytes[4096]; NSInteger count;
      while ((count = [stream read:bytes maxLength:sizeof(bytes)]) > 0) [read appendBytes:bytes length:count];
      [stream close]; body = read;
    }
    NSDictionary *json = body ? [NSJSONSerialization JSONObjectWithData:body options:0 error:nil] : nil;
    check([json[@"body"] isEqual:expectedText], @"saved body differs from exact typed reply");
    savedText = json[@"body"];
    check([self.request.URL.path isEqual:@"/v1/shares/film-17/thread/bob/message"], @"reply saved to wrong thread");
  } else { reads++; }
  NSMutableDictionary *result = [@{@"ok": @YES, @"reply": @YES, @"id": @"synthetic-message-1",
    @"url": conversationURL, @"share_presentation": presentation(), @"events": @[@{@"actor": @"alice", @"body": message}]} mutableCopy];
  if (missingShare) [result removeObjectForKey:@"share_presentation"];
  NSData *body = [NSJSONSerialization dataWithJSONObject:result options:0 error:nil];
  if (holdPost && [self.request.HTTPMethod isEqual:@"POST"]) { pendingPost = self; pendingPostBody = body; return; }
  [self reply:body type:@"application/json"];
}
- (void)stopLoading { self.stopped = YES; if (self.drip) { dispatch_source_cancel(self.drip); self.drip = nil; } }
@end

static void verifyItems(void) {
  check(activityConfiguration != nil, @"share exports only a link preview instead of target-facing image/text/link providers");
  if (activityConfiguration) {
    check(receivedText, @"target-facing text provider lost exact typed message");
    check(receivedLink, @"target-facing text lost canonical direct thread link");
    check(imageProviderCount == 1, @"share must export exactly one original image attachment");
    check(richPreviewImageCount == 0 && separateURLCount == 0, @"share exported a second rich-link image alongside the original attachment");
    check(attachmentAvailable, @"target-facing payload has no actual image attachment provider");
    return;
  }
  check([activityItems containsObject:expectedText], @"system share items lost exact typed message");
  BOOL found = NO;
  for (id item in activityItems) {
    if (![item conformsToProtocol:@protocol(UIActivityItemSource)]) continue;
    id value = [item activityViewController:(UIActivityViewController *)presented() itemForActivityType:UIActivityTypeMessage];
    if ([value isKindOfClass:NSURL.class] && [[value absoluteString] isEqual:conversationURL]) {
      found = YES;
      LPLinkMetadata *metadata = [item activityViewControllerLinkMetadata:(UIActivityViewController *)presented()];
      check([metadata.title isEqual:@"Original synthetic film"], @"system preview lost original title");
      check(metadata.imageProvider != nil && [metadata.imageProvider canLoadObjectOfClass:UIImage.class], @"actual artwork provider is missing or cannot supply an image");
      [metadata.imageProvider loadObjectOfClass:UIImage.class completionHandler:^(id<NSItemProviderReading> image, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{ loadedImage = (UIImage *)image; imageLoadError = error; });
      }];
    }
  }
  check(found, @"system share items lost canonical direct conversation link");
}

static void loadTargetPayload(id<UIActivityItemsConfigurationReading> configuration) {
  receivedText = receivedLink = attachmentAvailable = NO;
  loadedImage = nil; imageLoadError = nil;
  imageCompletions = 0;
  imageProviderCount = richPreviewImageCount = separateURLCount = 0;
  NSInteger index = 0;
  NSString *expected = [expectedText copy];
  for (NSItemProvider *provider in configuration.itemProvidersForActivityItemsConfiguration) {
    id metadata = [configuration activityItemsConfigurationMetadataForItemAtIndex:index++ key:UIActivityItemsConfigurationMetadataKeyLinkPresentationMetadata];
    if ([metadata isKindOfClass:LPLinkMetadata.class] && ((LPLinkMetadata *)metadata).imageProvider != nil) richPreviewImageCount++;
    if ([provider canLoadObjectOfClass:UIImage.class]) {
      imageProviderCount++;
      attachmentAvailable = YES;
      [provider loadObjectOfClass:UIImage.class completionHandler:^(id<NSItemProviderReading> image, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{ loadedImage = (UIImage *)image; imageLoadError = error; imageCompletions++; });
      }];
    } else if ([provider canLoadObjectOfClass:NSURL.class]) {
      separateURLCount++;
      [provider loadObjectOfClass:NSURL.class completionHandler:^(id<NSItemProviderReading> value, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{ receivedLink = error == nil && [[(NSURL *)value absoluteString] isEqual:conversationURL]; });
      }];
    } else if ([provider canLoadObjectOfClass:NSString.class]) {
      [provider loadObjectOfClass:NSString.class completionHandler:^(id<NSItemProviderReading> value, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
          NSString *payload = (NSString *)value;
          receivedText = error == nil && [payload isEqual:[expected stringByAppendingFormat:@"\n%@", conversationURL]];
          receivedLink = error == nil && [payload componentsSeparatedByString:conversationURL].count == 2;
        });
      }];
    }
  }
}

static void finish(void) {
  if (!failures) puts("hey_ios_reply_share_flow=true");
  fflush(stdout); exit(failures ? 1 : 0);
}
static void retrySavedReply(void) {
  UIActivityViewController *sheet = (UIActivityViewController *)presented();
  [sheet dismissViewControllerAnimated:NO completion:^{
    after(0.2, ^{
      UITableViewCell *primary = [composer tableView:composer.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
      check([((UIListContentConfiguration *)primary.contentConfiguration).text isEqual:@"Share saved reply"], @"saved form still offers Send reply instead of share-only retry");
      if (scopeTest.length > 0) {
        if ([scopeTest isEqual:@"session"]) {
          currentSession = @"synthetic-account-carol";
          primary = [composer tableView:composer.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
          check([((UIListContentConfiguration *)primary.contentConfiguration).text isEqual:@"Send reply"], @"session change retained another account's saved share");
          currentSession = @"synthetic-account-alice";
        } else if ([scopeTest isEqual:@"edited"]) {
          UITextView *editor = nil;
          for (UIView *view in descendants(composer.view)) if ([view isKindOfClass:UITextView.class]) editor = (UITextView *)view;
          expectedText = @"An explicitly edited new reply. 🎥";
          editor.text = expectedText;
          [composer textViewDidChange:editor];
          primary = [composer tableView:composer.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
          check([((UIListContentConfiguration *)primary.contentConfiguration).text isEqual:@"Send reply"], @"editing did not restore explicit new-message submission");
          [composer submit];
          after(1, ^{
            check(posts == 2, @"explicit edited message was not saved exactly once");
            check([presented() isKindOfClass:UIActivityViewController.class], @"edited message did not open actual sharing");
            verifyItems();
            check(![activityItems containsObject:message], @"edited message reused an earlier reply's share text");
            finish();
          });
          return;
        } else {
          UINavigationController *nav = composer.navigationController;
          [nav popViewControllerAnimated:NO];
          [nav pushViewController:composer animated:NO];
        }
        primary = [composer tableView:composer.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
        check([((UIListContentConfiguration *)primary.contentConfiguration).text isEqual:@"Send reply"], @"leaving the form or changing session did not purge the saved share");
        check(posts == 1 && ![presented() isKindOfClass:UIActivityViewController.class], @"scope cleanup replayed or reposted the saved message");
        finish(); return;
      }
      NSInteger beforeReads = reads;
      NSInteger beforeImages = imageRequests;
      [composer submit];
      after(1, ^{
        check(posts == 1, @"share retry reposted the authored message");
        check(reads == beforeReads, @"share retry fetched a different/latest message instead of exact saved response");
        check(imageRequests > beforeImages, @"share retry did not retry the original image attachment provider");
        check([presented() isKindOfClass:UIActivityViewController.class], @"share-only retry did not present actual UIActivityViewController");
        verifyItems();
        check([composer.values[@"body"] isEqual:message], @"cancelling external sharing lost saved reply text");
        finish();
      });
    });
  }];
}

@interface ShareTestDelegate : HeyIOSAppDelegate
@end
@implementation ShareTestDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)options {
  BOOL result = [super application:app didFinishLaunchingWithOptions:options];
  after(1, ^{
    UITabBarController *tabs = (UITabBarController *)[HeyIOSHost shared].window.rootViewController;
    UINavigationController *nav = tabs.viewControllers.firstObject;
    thread = (HeyIOSListController *)nav.topViewController;
    [thread applyVars:@{@"id": @"film-17", @"friend": @"bob"}];
    HeyIOSOpenScreen(thread, @"share_reply", @{@"id": @"film-17", @"friend": @"bob"});
    // Wait for the actual navigation animation to settle on a busy simulator;
    // still assert that the destination is a form with a real text editor.
    after(1.5, ^{
      UIViewController *destination = nav.topViewController;
      if (![destination isKindOfClass:HeyIOSFormController.class]) {
        check(NO, @"reply navigation did not open the actual form");
        finish();
        return;
      }
      composer = (HeyIOSFormController *)destination;
      [composer.view layoutIfNeeded];
      UITextView *editor = nil;
      for (UIView *view in descendants(composer.view)) if ([view isKindOfClass:UITextView.class]) editor = (UITextView *)view;
      check(editor != nil, @"real multiline reply editor missing");
      UIButton *mic = nil;
      for (UIView *child in descendants(composer.view)) {
        if ([child isKindOfClass:UIButton.class] && [child.accessibilityIdentifier isEqualToString:@"form_microphone_body"]) {
          mic = (UIButton *)child;
          break;
        }
      }
      check(mic != nil && mic.isEnabled, @"reply form has no accessible microphone");
      check(posts == 0, @"microphone or opening reply sent a message without Send");
      editor.text = message;
      [composer textViewDidChange:editor];
      observeArtworkFailure();
      [composer submit];
      // On heavily loaded simulators UIKit can defer sheet presentation beyond
      // two wall-clock seconds. Artwork remains held throughout this bounded
      // grace period, so we still catch sharing that waits for image bytes.
      after(4, ^{
        check(posts == 1, @"reply was not saved exactly once");
        if (holdPost) {
          check(![presented() isKindOfClass:UIActivityViewController.class], @"share appeared before the saved response");
          currentSession = @"synthetic-account-carol";
          [(ShareTransport *)pendingPost reply:pendingPostBody type:@"application/json"];
          pendingPost = nil; pendingPostBody = nil;
          after(1, ^{
            check(![presented() isKindOfClass:UIActivityViewController.class], @"late old-account response opened a share sheet");
            check(imageRequests == 0, @"late old-account response fetched share artwork");
            finish();
          });
          return;
        }
        if (missingShare) {
          check(![presented() isKindOfClass:UIActivityViewController.class], @"missing share payload opened a sheet");
          check(composer.message.length > 0, @"missing share payload failed silently");
          [composer submit];
          after(0.5, ^{
            check(posts == 1, @"missing share payload retry duplicated the saved message");
            check(composer.message.length > 0, @"invalid saved share retry lost its visible failure");
            finish();
          });
          return;
        }
        BOOL visible = [presented() isKindOfClass:UIActivityViewController.class];
        printf("share-flow: saved=%ld image_waiting=%d actual_activity_presented=%d\n", (long)posts, heldImages.count > 0, visible);
        check(visible, @"reply saved but actual UIActivityViewController did not appear before artwork completed");
        if (visible) verifyItems();
        if (popAfterSave) check(nav.topViewController == thread, @"saved reply did not return to the exact original thread");
        check([thread.vars[@"id"] isEqual:@"film-17"] && [thread.vars[@"friend"] isEqual:@"bob"], @"external sharing lost the exact original conversation");
        if ([scopeTest isEqual:@"pending_account"]) currentSession = @"synthetic-account-carol";
        holdImage = NO;
        NSArray *pending;
        @synchronized (heldImages) { pending = [heldImages copy]; [heldImages removeAllObjects]; }
        for (ShareTransport *image in pending) {
          if (failImage) [image.client URLProtocol:image didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorTimedOut userInfo:nil]];
          else [image answerImage];
        }
        after([imageMode isEqual:@"drip"] ? 9 : 1, ^{
          printf("share-flow: after_artwork_release actual_activity_presented=%d captured_items=%lu visible=%s composer_window=%d\n", [presented() isKindOfClass:UIActivityViewController.class], (unsigned long)activityItems.count, NSStringFromClass(presented().class).UTF8String, composer.view.window != nil);
          check([presented() isKindOfClass:UIActivityViewController.class], @"share sheet never appeared even after artwork completed");
          check(imageCompletions == 1, @"actual image attachment provider did not complete exactly once");
          if ([scopeTest isEqual:@"pending_account"]) {
            check(loadedImage == nil && imageLoadError != nil, @"late image pixels crossed an account change");
            finish(); return;
          } else if (failImage || (imageMode.length > 0 && ![imageMode isEqual:@"downsample"])) {
            check(imageLoadError != nil, @"failed artwork did not complete the actual image provider with an error");
            check(sawArtworkFailure, @"artwork failure was silent instead of visibly retryable");
          } else {
            check(loadedImage != nil && imageLoadError == nil, @"actual provider did not deliver original artwork bytes");
            if (loadedImage) {
              size_t expectedWidth = [imageMode isEqual:@"downsample"] ? 1024 : 8;
              size_t expectedHeight = [imageMode isEqual:@"downsample"] ? 512 : 8;
              check(CGImageGetWidth(loadedImage.CGImage) == expectedWidth && CGImageGetHeight(loadedImage.CGImage) == expectedHeight, @"actual image provider did not preserve or safely downsample original artwork dimensions");
              unsigned char pixel[4] = {0};
              CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
              CGContextRef context = CGBitmapContextCreate(pixel, 1, 1, 8, 4, space, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
              CGContextDrawImage(context, CGRectMake(0, 0, 1, 1), loadedImage.CGImage);
              CGContextRelease(context); CGColorSpaceRelease(space);
              check(pixel[0] == 255 && pixel[1] == 0 && pixel[2] == 0 && pixel[3] == 255, @"actual image provider returned different artwork pixels");
            }
          }
          if (testRetry && [presented() isKindOfClass:UIActivityViewController.class]) retrySavedReply();
          else finish();
        });
      });
    });
  });
  return result;
}
@end

int main(int argc, char **argv) {
  @autoreleasepool {
    holdImage = [[NSUserDefaults standardUserDefaults] boolForKey:@"HoldImage"];
    popAfterSave = [[NSUserDefaults standardUserDefaults] boolForKey:@"PopAfterSave"];
    testRetry = [[NSUserDefaults standardUserDefaults] boolForKey:@"TestRetry"];
    failImage = [[NSUserDefaults standardUserDefaults] boolForKey:@"FailImage"];
    scopeTest = [[NSUserDefaults standardUserDefaults] stringForKey:@"ScopeTest"];
    heldImages = [NSMutableArray array];
    currentSession = @"synthetic-account-alice";
    expectedText = message;
    imageMode = [[NSUserDefaults standardUserDefaults] stringForKey:@"ImageMode"];
    holdPost = [[NSUserDefaults standardUserDefaults] boolForKey:@"HoldPost"];
    missingShare = [[NSUserDefaults standardUserDefaults] boolForKey:@"MissingShare"];
    NSDictionary *fixture = @{@"schema": @"hey-mobile-api-app-v1", @"level": @3, @"platform": @"ios", @"tabs": @[@"share_thread"],
      @"session": @{@"header": @"authorization", @"prefix": @"Bearer ", @"sign_in_screen": @"share_reply", @"check": @{@"path": @"/session"}},
      @"screens": @[@{@"id": @"share_thread", @"type": @"list", @"title": @"Original synthetic film", @"sections": @[]},
        @{@"id": @"share_reply", @"type": @"form", @"title": @"Reply", @"fields": @[@{@"id": @"body", @"label": @"Reply", @"kind": @"multiline", @"speech_input": @YES, @"required": @YES}],
          @"primary": @{@"title": @"Send reply", @"request": @{@"method": @"POST", @"path": @"/v1/shares/{id}/thread/{friend}/message", @"body": @{@"body": @"$body"}},
            @"on_success": @{@"share": @"share_presentation", @"share_retry_title": @"Share saved reply", @"message": @"Reply saved.", @"then": popAfterSave ? @"pop" : @"stay"}}}]};
    NSMutableData *bytes = [[NSJSONSerialization dataWithJSONObject:fixture options:0 error:nil] mutableCopy];
    [bytes appendBytes:"\0" length:1]; manifestData = bytes;
    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.scale = 1;
    CGSize size = [imageMode isEqual:@"pixels"] ? CGSizeMake(4200, 3200) : ([imageMode isEqual:@"downsample"] ? CGSizeMake(2048, 1024) : CGSizeMake(8, 8));
    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:size format:format];
    UIImage *fixtureImage = [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) { [[UIColor redColor] setFill]; UIRectFill((CGRect){CGPointZero, size}); }];
    artwork = UIImagePNGRepresentation(fixtureImage);
    HeyIOSApiHostStart(manifest, manifestLength);
    method_setImplementation(class_getInstanceMethod(HeyIOSApi.class, @selector(token)), imp_implementationWithBlock(^NSString *(id self) { return currentSession; }));
    Method initializer = class_getInstanceMethod(UIActivityViewController.class, @selector(initWithActivityItems:applicationActivities:));
    IMP original = method_getImplementation(initializer);
    method_setImplementation(initializer, imp_implementationWithBlock(^id(id self, NSArray *items, NSArray *activities) {
      activityItems = [items copy];
      return ((id (*)(id, SEL, id, id))original)(self, @selector(initWithActivityItems:applicationActivities:), items, activities);
    }));
    Method configuredInitializer = class_getInstanceMethod(UIActivityViewController.class, @selector(initWithActivityItemsConfiguration:));
    IMP originalConfigured = method_getImplementation(configuredInitializer);
    method_setImplementation(configuredInitializer, imp_implementationWithBlock(^id(id self, id<UIActivityItemsConfigurationReading> configuration) {
      activityConfiguration = configuration;
      id controller = ((id (*)(id, SEL, id))originalConfigured)(self, @selector(initWithActivityItemsConfiguration:), configuration);
      loadTargetPayload(configuration);
      return controller;
    }));
    [NSURLProtocol registerClass:ShareTransport.class];
    Method ephemeral = class_getClassMethod(NSURLSessionConfiguration.class, @selector(ephemeralSessionConfiguration));
    IMP originalEphemeral = method_getImplementation(ephemeral);
    method_setImplementation(ephemeral, imp_implementationWithBlock(^NSURLSessionConfiguration *(id cls) {
      NSURLSessionConfiguration *configuration = ((id (*)(id, SEL))originalEphemeral)(cls, @selector(ephemeralSessionConfiguration));
      configuration.protocolClasses = @[ShareTransport.class];
      return configuration;
    }));
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(ShareTestDelegate.class));
  }
}
