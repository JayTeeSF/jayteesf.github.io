# Todo

1. Compile-time selection, if Hey grows a per-target constant or per-OS
   dependencies (asked of the Hey team 2026-10-13): then a Linux binary would
   not carry the kqueue/iocp porcelain at all.
2. Windows: hey_iocp has never run; Env.os() reports 'Unknown' on Windows in
   Hey 0.99.601a, so Poller.open there fails with poller_unsupported_os today.
3. io_uring as Linux's default if real x86 Linux measures it faster than
   epoll (hey_fast_web `single`, hey_web's readiness lane); 0.2.0 selects it
   by name only.
