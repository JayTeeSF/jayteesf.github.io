# Continue hey_mysql

Continue the MySQL adapter for Hey. Preserve the callable `hey_record` connection contract, shell-free argv execution, Result errors, and explicit capability reporting. Prioritize typed prepared statements and a persistent native connection/pool. Update all tracking documents with every slice.

Keep exported modules at package-root paths while targeting Hey 0.99.259a because its current `pkg:` resolver does not follow non-root manifest module mappings.
