# Done

- Replaced the sqlite3 CLI subprocess adapter with Hey native ABI v2.
- Added explicit extension/database/statement ownership.
- Added prepared statements, typed scalar/blob bindings, typed rows, busy timeout, transactions, changes, insert IDs, and interruption.
- Added adapter callbacks compatible with `hey_record@0.2.0`.
- Promoted interpreter and ordinary self-hosted LLVM receipts to the mandatory package gate; private Stage-0 compilation is rejected rather than used as package evidence.
- Kept hey_sqlite3 independent of journal packages and added a fail-closed guard against a `hey_durable_log` manifest/runtime dependency.
- Made loadable-extension capability resolution portable to Apple's SQLite headers by resolving the two optional symbols at runtime and refusing cleanly when absent.
- Made connection close fail while statements remain open, preventing extension unload before deterministic statement finalization.
- Updated native generation to the stable `hey native` command and removed `hey_packager` from runtime dependencies.
