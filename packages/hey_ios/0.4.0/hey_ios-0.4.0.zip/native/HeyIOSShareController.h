// HeyIOSShareViewController: the share extension of a hey_mobile api_screens app.
//
// Saving a link from inside any other app in two taps: Share, then this app.
// The extension links the app's own Hey shell, so it reads the same
// baked description (origin, keychain service, and its `share` block: the
// request to send and every word it shows). It reads the session the app stored
// through the keychain group both binaries carry; it never signs in and never
// holds an identity of its own.
//
// Built with -fapplication-extension: nothing here uses an API an extension may
// not call.
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HeyIOSShareViewController : UIViewController
@end

NS_ASSUME_NONNULL_END
