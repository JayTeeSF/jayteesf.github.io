# hey_durable_log

`hey_durable_log` is the crash-safe mutation journal being built for the
cagents v2 server. It keeps accepted mutations hot in memory at the service
layer while making acknowledgement depend on a small append-only durable
record, not on SQLite page updates.

`main` carries the implementation. It was landed from `main_v2` once the
readiness gates below were green on both platforms — not because it compiled —
and the gaps that remain are named in "Where this stands" rather than left to be
discovered.

The intended write path, which is what every guarantee below is about:

```text
authenticated Cagents mutations
        |
bounded in-memory queue (fast admission + backpressure)
        |
one ordered reducer per journal partition
        |
checksummed DATA frames + batch COMMIT
        |
durability barrier, then the receipt returned to the caller
        |
optional quorum replication before the caller is told yes
```

**Two breaking changes landed on `main`**, taken while 0.2.0 was the only
released version and nothing existed in the field:

- **Format v3.** Frame headers are 64 bytes; every frame names the log-global
  position it was written for AND the term it originated in. A v2 journal is
  refused as `unsupported_format` rather than misread or silently upgraded: an
  entry written before terms existed has no term, and inventing one would
  manufacture the consensus history the election restriction goes on to trust.
- **A journal is a DIRECTORY**, not a file. An existing regular file at the
  journal path is refused rather than reinterpreted.

There is no conversion path from v1 and none is owed; see
[docs/FORMAT.md](docs/FORMAT.md).

## Current guarantees

- `hdl_append_batch` serializes concurrent callers and returns only after the
  DATA frames, the COMMIT frame, and a durability barrier that flushes the
  storage device's cache all complete. The barrier is `fdatasync` on Linux and
  `fcntl(F_FULLFSYNC)` on Darwin, where `fdatasync` only reaches the drive and
  not the platters; `hdl_sync_barrier_name()` reports which one this build
  issues, and the gate asserts it per platform. There is no silent fallback to
  a weaker barrier.
- `hdl_broker_submit` feeds a bounded in-memory queue whose single writer
  combines concurrent requests into one durable batch and applies
  backpressure when the queue is full. A submitter can bound how long it waits to
  be **admitted** -- `hdl_broker_submit_within`, `DurableLog.append_within` --
  and a submission refused that way was never accepted and is not in the log.
  The bound covers admission only: once a record is in a batch on its way to a
  barrier it may already be durable, so reporting it as refused would be a lie.
  `DurableLog.stats` reports what that actually cost -- records, durable batches, largest batch, the queue's
  high-water mark, and how many batches waited out the batch window -- as one
  snapshot, so "the queue is bounded" is a claim a Hey consumer can check rather
  than take on faith. A caller that is the only one in flight never waits that
  window, because a caller blocked in `append` cannot append again, so the wait
  would be for company that provably is not coming.
- Recovery publishes only batches with a complete, checksummed COMMIT frame.
- A physically short final frame or an uncommitted valid tail is truncated to
  the last committed boundary.
- A checksum failure in a complete frame fails closed as corruption.
- **One writer owns a journal.** `hdl_open` takes an exclusive advisory lock
  before recovery -- before it can truncate anything -- and a second opener is
  refused as `HDL_LOCKED` (`durable_log_open_locked` from Hey) rather than being
  handed a handle that would acknowledge the same sequence twice. The kernel
  releases the lock when the owner closes or dies, so a crash never leaves a
  journal nobody can open.
- A journal is a directory of segments, each named for its index and its base
  position in the log. A segment is published by a single `rename` after its
  bytes are synced, so a segment that recovery can see is a segment whose
  contents are already durable.
- Snapshots, restores and retirement are reachable from Hey, on the connection
  itself, because the exclusive writer lock means the owning process is the only
  one that can do them to a live journal.
- A snapshot is a journal, so it is verified by the code that validates a
  journal: read back, replayed, and compared against its own receipt. Segments
  are retired only against a snapshot that verified, and the retirement is
  recorded durably before anything is deleted.
- The active segment is cut when it reaches its size bound, always between two
  batches. The frame chain, the sequence and the batch numbering carry across
  the seam, each segment begins exactly where the last one ended, and recovery
  checks that rather than assuming it.
- A newly created segment is synchronized before it can accept a batch.
- Every frame names the log-global position it was written for, inside its own
  checksum, and recovery replays a frame only where that name matches. A
  complete, correctly-checksummed frame that belongs to another place in the
  log -- the previous life of a reused file, or a copy spliced in -- is
  corruption and fails closed, rather than being replayed as committed data.
- Each replay cursor snapshots the last validated COMMIT boundary, streams one
  record at a time, and never observes a half-written concurrent batch. It can
  resume from a position it was given -- every record says where the next one
  starts -- so a materializer catching up does not re-read what it has already
  applied, and a position that is not a frame boundary is refused rather than
  resynchronised.

These are local-disk guarantees: they hold across process crash, OS crash and
power loss on this host. Surviving loss of the host or the disk itself requires
quorum replication before acknowledgement. `cluster.hey` provides that as an
opt-in layer over Distributed Hey — a receipt then reads `quorum_durable` rather
than `local_durable`. A follower accepts only the record that CONTINUES its own
log, reports what it is missing when it cannot, and treats a retried record as
already applied rather than appending it twice; a leader can then send exactly
the gap.

Replication now runs against **real peers**: `bin/check-cluster` starts three
separate processes in three containers with real sockets between them, and then
reads each follower's own bytes rather than believing the leader's report. It
asserts that a reachable majority confirms, that two of three is still a
majority, that a minority is refused by name, that each follower holds exactly
the records it acknowledged, that a follower which fell behind is HEALED from
the position it reported, and that all three nodes then replay the identical
committed prefix — record for record, not by length.

A node whose history parted from the cluster's — a leader that was fenced after
writing a record locally — is detected rather than spliced: a replica compares
the identity of the previous record (sequence, stream and payload, never the
framing, because a leader batches and a replica does not) and refuses one that
continues its sequence but not its history. The leader then repairs it: the
divergent tail is discarded, what was discarded is written down durably first,
and the node is caught up and rejoins. All three then replay the identical log.

It also runs a real hand-off: the leader is stopped, a follower campaigns for a
new term, a surviving majority grants it, the new leader writes at its own term,
and the old leader — restarted still believing it leads — is **fenced**, because
every node enforces the term it durably recorded rather than the one it was
started with. A vote is written and synced before it is answered, so a node
cannot grant the same term twice after a restart.

And a partition is now tested as something other than a stopped process.
`bin/check-partition` never stops anything: it partitions a **running** node with
an `iptables` REJECT from one peer's address, so the node keeps its address, its
journal and every other conversation it was having. It asserts that the majority
commits without a node that is still alive; that the same process — not a
restarted one — reports what it missed and is caught up; that a leader pushed
into the minority is refused by name, cannot elect itself, and does not record
the term it lost; that at the same moment the other side of that split elects a
leader and commits, with the vote granted by the very node refusing to answer the
minority; and that when the split heals with both sides having written at the
same sequence, the minority's record is reconciled rather than spliced. The last
thing it checks is that both followers are still running with the start times
they had at the beginning: if any of it had been done by stopping a container,
that assertion is how you would know.

One limit is worth stating precisely, because it is the kind of thing a
distributed system hides. **A leader's connect is not covered by any timeout this
package configures.** `HEY_DURABLE_LOG_REPLICATION_TIMEOUT_MS` bounds the wait
for a reply; the TCP connect ahead of it goes through
`DistTransport.establish_connect` → `Net.connect`, which takes no timeout at all.
A peer whose packets are *rejected* fails fast, and a peer whose packets are
silently *dropped* blocks the leader for the kernel's connect timeout instead —
minutes, not milliseconds. Every other queue in this package is explicitly
bounded and this one is not, so it is named rather than glossed: it needs a
connect timeout in the Hey standard library, which is not this package's to
change.

Until quorum replication is what you deploy, do not read this as surviving host
loss.

## Is it faster than SQLite?

That is the whole reason this exists, so it is measured rather than asserted.
On Linux, both engines using the same `fdatasync` barrier:

| Writers | SQLite | This journal | Ratio |
|---:|---:|---:|---:|
| 1 | 2,100/s | 2,728/s | **1.30×** |
| 4 | 1,254/s | 5,173/s | **4.12×** |
| 8 | 1,503/s | 8,576/s | **5.71×** |
| 32 | 1,824/s | 27,245/s | **14.94×** |

SQLite gets *slower* as writers arrive, because a WAL writer holds the exclusive
write lock across its `fdatasync`. This journal gets faster, because every
concurrent caller shares one barrier.

**At one writer it used to lose, 0.78×, and no longer does.** The broker held
the first record of a batch for the batch window so that concurrent callers
could join it; with one caller that was a wait for company that provably could
not come, since a caller blocked in `append` cannot append again. Skipping it
there took one writer from 1,309 to 2,665 records/s and p50 from 0.674 to 0.260
ms, with `average_batch` unchanged at eight and thirty-two writers.
`DurableLog.stats` reports `window_waits` so a consumer can check that rather
than believe it. The one-writer margin is small and noisy — one barrier against
one barrier — so the claim is that this package no longer *costs* you anything
at a single writer, not that it wins comfortably there.

Method and limits: [docs/BENCHMARK-2026-09-05-solitary-writer.md](docs/BENCHMARK-2026-09-05-solitary-writer.md),
and the original comparison in [docs/BENCHMARK-2026-09-04-linux-vs-sqlite.md](docs/BENCHMARK-2026-09-04-linux-vs-sqlite.md).
Both are a laptop under Docker; the ratios are the point, the absolute numbers
are not.

## Platforms

Darwin and Linux do not agree on what "sync" means, so they do not share a
primitive. On Darwin `fsync` costs 0.045 ms and is not power-safe, `F_BARRIERFSYNC`
0.239 ms and orders without flushing, and only `F_FULLFSYNC` (4.020 ms) flushes
the device. On Linux `fdatasync` is the real barrier and costs 0.514 ms. This
package issues the correct one per platform, asserts which it issued, and never
falls back to a weaker one.

Linux is gated separately, because a green gate on Darwin proves nothing about a
platform that uses a different primitive:

```sh
bin/check-linux
```

## Where this stands

The C, native-adapter and Hey gates pass on Darwin and on Linux
(`bin/check-linux`), the real-filesystem exhaustion gate passes on both
(`bin/check-enospc`), the three-node cluster gate passes against real peers
(`bin/check-cluster`), and the partition gate passes against three nodes none of
which is ever stopped (`bin/check-partition`). Supply a current
`hey-lang-bootstrap-plan` checkout through `HEY_ROOT` and run `bin/check`.

Built and gated, each one test-first, each gate proved red before it was trusted:

1. atomically published segment rotation, with the writer killed at every step
   of the cut, and a failed-barrier gate for the half a `SIGKILL` cannot reach;
2. a backpressure soak, bounded admission with a typed refusal, and filesystem
   exhaustion on a real full filesystem;
3. verified snapshots, restore, and retirement that records the seam before it
   deletes anything;
4. replay lag measured end to end, with the expectations written down first —
   one of them was missed, and fixing it took both a resumable cursor and an
   O(1) cursor open;
5. quorum replication against real peers: majority confirms, minority refuses,
   a lagging follower is healed from what it reported, a new leader is elected
   by a real majority, and the leader it replaced is fenced.

6. partition as distinct from a stopped process: a live node unreachable from
   one side of a split and answering the other at the same time, a minority that
   can neither commit nor elect itself, a majority that does both without it, and
   a heal that reconciles two histories instead of splicing them
   (`bin/check-partition`).

Not done, and therefore not claimed:

- **numbers from more than one machine.** Every measurement here so far is a
  laptop or a container on one, and every document names the host, device and
  parameters that produced it. Read a figure as what it is: what to expect on
  hardware like the hardware named on it. A real-Linux run has since happened on
  a Samsung 980 PRO, and its numbers are labelled with the whole storage stack --
  LUKS, btrfs copy-on-write and zstd:3 compression sit between the journal and
  that device, so they are real-Linux-on-that-host figures and not bare NVMe.
- **fresh-image reproducibility after the toolchain repair.** The required Hey
  portability and devtools fixes are now merged and pushed at
  `hey-lang-bootstrap-plan` branch `hey-lang-tgz`, commit `ecc446b90`.
  Native Omarchy/Arch (glibc 2.44, GCC 16.2.1) release builds pass with zero
  fallback. Build the package's cluster image with `bin/build-toolchain-image`
  against that checkout. The existing cluster/partition acceptance used the
  equivalent pre-integration toolchain fixes; a fresh container-image rebuild
  at the published commit is not yet recorded here. The package's six gate
  results remain valid; native build acceptance is not a new container receipt.

- **a transport that pools its connections.** The leader's transport still
  connects, handshakes, calls and says bye for every replicated record. That is
  a limit of the acceptance harness rather than of the package, and the reason
  is structural: Distributed Hey threads the peer value through every call, so a
  pooled connection has to be threaded through `DurableLogCluster.append` --
  the one module whose decision logic must stay simple enough to reason about.
  No replication throughput number is quoted anywhere in this package, and this
  is why: `bin/check-cluster` and `bin/check-partition` assert what crosses the
  link and what lands durably, never how fast.

  The follower half of this is **done**. A follower opens its journal once per
  process and holds the exclusive writer lock unbroken for the life of that
  process, which `bin/check-cluster` asserts by reading the follower's own count
  of real opens after it has accepted at least two records. It does not use an
  actor, because it cannot: Hey has no closures, so a handler cannot capture a
  journal, and an actor holds state but is reachable only by one-way
  `Remote.send` with no synchronous ask -- the thing that can own the journal
  cannot answer, and the thing that can answer cannot own it. Retention lives in
  the native adapter instead, behind `DurableLog.open_retained`, and the handler
  names the path rather than capturing anything.

Record each passing checkpoint in
`JayTeeSF/cagents@main_v2/projects/cagents/tasks/durable-mutation-journal`.
Do not integrate this package as cagents authority until the gaps above are
either closed or accepted in writing by the consumer.

Non-negotiable rules: never acknowledge RAM alone; never skip a complete
corrupt frame; truncate only a partial/uncommitted tail; preserve ambiguous
post-COMMIT responses through application idempotency; keep queues bounded;
and never make SQLite or Git the hidden acknowledgement boundary.

## Check

`bin/check` is the shared `hey_packager` validation — manifest, `VERSION`, every
declared file, required documentation, the archive-entry pre-flight, and the
executable documentation example — followed by this package's own gate:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" bin/check
```

The package-specific portion is available directly as `bin/package-check`. It
runs the version drift guard, `make clean check`, `bin/check-enospc` -- which
mounts a small real filesystem, fills it, and runs the journal into the wall --
and `bin/check-hey`. The C
core alone, without a Hey toolchain, is `make clean check`.

To validate only the generated dispatcher plus both the interpreter and
stage0-compiled receipts:

```sh
HEY_ROOT=/path/to/hey-lang-bootstrap-plan bin/check-hey
```

The gates compile with strict warnings, run append/scan recovery tests, truncate
a two-batch journal at every byte boundary, verify corruption is not silently
discarded, reject valid frames that belong elsewhere in the log, inject
short-write and failed-sync errors, exercise real `SIGKILL` at write/sync/receipt
boundaries and at every step of a segment cut, exercise concurrent append
callers, and prove the broker uses fewer durable batches than records.

See [docs/FORMAT.md](docs/FORMAT.md) for the v3 byte format and recovery rules,
and [docs/TESTING.md](docs/TESTING.md) for the full gate description. The first
packaged-core measurements are in
[docs/BENCHMARK-2026-09-04.md](docs/BENCHMARK-2026-09-04.md).

For a local concurrency measurement (writers, operations per writer, maximum
batch, and batch window in microseconds):

```sh
bin/benchmark 8 250 64 250
```

For replay lag — submit to observed, end to end, including the batch window, the
durability barrier and the cursor cadence a materializer actually pays:

```sh
bin/benchmark-replay-lag 8 200 64 250 256
```

Measured results and the expectations they were checked against are in
[docs/BENCHMARK-2026-09-04-replay-lag.md](docs/BENCHMARK-2026-09-04-replay-lag.md).
One expectation was missed: replay lag GROWS with the length of the log, because
a cursor cannot resume and a catching-up reader re-walks everything it has
already seen.

## Standard package controls

This package uses `hey_packager` 0.1.6 or newer for validation, release
construction, source handoff, and immutable registry publication. The tool is
vendored as `bin/hey-packager`; it is release tooling, not a runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/package-zip` remains a compatibility alias for `bin/release`. Use
`bin/publish` only when the version does not already exist under
`$HOME/dev/jayteesf.github.io/packages/hey_durable_log`; published versions are
immutable, so change `VERSION` (through `bin/bump`) whenever released bytes
change.
