/* hey_iocp: the Windows backend of Hey's batched TCP event loop.
 *
 * EXPERIMENTAL / UNVERIFIED: this file is cross-compiled and linked into a PE
 * DLL from macOS by bin/build-native; it has never run on Windows. See
 * README.md.
 *
 * The contract is hey_epoll's (wait -> next/data ... -> send, unconsumed input
 * kept here, text hand-over), built on an I/O completion port:
 *
 * - the listener keeps HEY_IOCP_ACCEPTS AcceptEx operations outstanding; each
 *   completion accepts one connection, which is read at once (non-blocking
 *   recv) and then gets a zero-byte overlapped WSARecv;
 * - a zero-byte receive completes when input is waiting, without holding a
 *   buffer while the connection is idle; the loop then reads with ordinary
 *   non-blocking recv() until it would block, and posts the next zero-byte
 *   receive (readiness emulated on completion: the shape hey_epoll's API needs);
 * - send() writes straight from the caller's text with non-blocking send();
 *   what does not fit goes out as one overlapped WSASend, and text sent while
 *   that is in flight is queued behind it (never written into its buffer);
 * - one GetQueuedCompletionStatusEx call dequeues up to 1024 completions.
 *
 * A closed connection's memory is released only when the kernel has returned
 * every operation it still owned (closesocket cancels them; their completions
 * arrive later).
 *
 * The Windows SDK headers are deliberately not included (the same approach as
 * Hey's runtime/hey_windows_*.c): the declarations below let Clang cross-compile
 * without an SDK. They must be revalidated on a Windows host.
 */
#if !defined(_WIN32) || !defined(_WIN64)
#error "hey_iocp is the Windows x64 backend: use hey_epoll on Linux and hey_kqueue on macOS/BSD"
#endif

#include "hey_iocp.h"

#include <limits.h>
#include <stddef.h>
#include <stdint.h>

/* ---- the C runtime and Win32 surface used here -------------------------- */

void *malloc(size_t size);
void *realloc(void *pointer, size_t size);
void free(void *pointer);
void *memcpy(void *target, const void *source, size_t count);
void *memmove(void *target, const void *source, size_t count);
void *memset(void *target, int value, size_t count);

#define HEY_WIN_IMPORT __declspec(dllimport)
#define HEY_WIN_API __stdcall

typedef unsigned long HeyWinDword;     /* DWORD: 32 bits on LLP64 Windows */
typedef uintptr_t HeyWinSocket;        /* SOCKET */
typedef void *HeyWinHandle;            /* HANDLE */
typedef int HeyWinBool;                /* BOOL */

typedef struct HeyWinOverlapped {
  uintptr_t internal;                  /* NTSTATUS of the completed operation */
  uintptr_t internal_high;
  HeyWinDword offset;
  HeyWinDword offset_high;
  HeyWinHandle event;
} HeyWinOverlapped;

typedef struct HeyWinOverlappedEntry {
  uintptr_t completion_key;
  HeyWinOverlapped *overlapped;
  uintptr_t internal;
  HeyWinDword bytes;
} HeyWinOverlappedEntry;

typedef struct HeyWinWsaBuf {
  unsigned long length;
  char *data;
} HeyWinWsaBuf;

typedef struct HeyWinInAddr { uint32_t s_addr_value; } HeyWinInAddr;

typedef struct HeyWinSockaddrIn {
  short family;
  unsigned short port;
  HeyWinInAddr address;
  char zero[8];
} HeyWinSockaddrIn;

typedef struct HeyWinGuid {
  uint32_t data1;
  uint16_t data2;
  uint16_t data3;
  uint8_t data4[8];
} HeyWinGuid;

typedef HeyWinBool (HEY_WIN_API *HeyWinAcceptEx)(HeyWinSocket listener, HeyWinSocket accepted, void *output,
  HeyWinDword receive_length, HeyWinDword local_length, HeyWinDword remote_length, HeyWinDword *received,
  HeyWinOverlapped *overlapped);

HEY_WIN_IMPORT int HEY_WIN_API WSAStartup(unsigned short version, void *data);
HEY_WIN_IMPORT int HEY_WIN_API WSACleanup(void);
HEY_WIN_IMPORT int HEY_WIN_API WSAGetLastError(void);
HEY_WIN_IMPORT HeyWinSocket HEY_WIN_API WSASocketW(int family, int type, int protocol, void *info, unsigned int group, HeyWinDword flags);
HEY_WIN_IMPORT int HEY_WIN_API bind(HeyWinSocket s, const void *address, int length);
HEY_WIN_IMPORT int HEY_WIN_API listen(HeyWinSocket s, int backlog);
HEY_WIN_IMPORT int HEY_WIN_API closesocket(HeyWinSocket s);
HEY_WIN_IMPORT int HEY_WIN_API ioctlsocket(HeyWinSocket s, long command, unsigned long *argument);
HEY_WIN_IMPORT int HEY_WIN_API setsockopt(HeyWinSocket s, int level, int name, const char *value, int length);
HEY_WIN_IMPORT int HEY_WIN_API getsockname(HeyWinSocket s, void *address, int *length);
HEY_WIN_IMPORT int HEY_WIN_API recv(HeyWinSocket s, char *buffer, int length, int flags);
HEY_WIN_IMPORT int HEY_WIN_API send(HeyWinSocket s, const char *buffer, int length, int flags);
HEY_WIN_IMPORT int HEY_WIN_API WSARecv(HeyWinSocket s, HeyWinWsaBuf *buffers, HeyWinDword count, HeyWinDword *received,
  HeyWinDword *flags, HeyWinOverlapped *overlapped, void *routine);
HEY_WIN_IMPORT int HEY_WIN_API WSASend(HeyWinSocket s, HeyWinWsaBuf *buffers, HeyWinDword count, HeyWinDword *sent,
  HeyWinDword flags, HeyWinOverlapped *overlapped, void *routine);
HEY_WIN_IMPORT int HEY_WIN_API WSAIoctl(HeyWinSocket s, HeyWinDword code, void *in, HeyWinDword in_length, void *out,
  HeyWinDword out_length, HeyWinDword *returned, HeyWinOverlapped *overlapped, void *routine);
HEY_WIN_IMPORT int HEY_WIN_API inet_pton(int family, const char *text, void *address);
HEY_WIN_IMPORT unsigned short HEY_WIN_API htons(unsigned short value);
HEY_WIN_IMPORT unsigned short HEY_WIN_API ntohs(unsigned short value);

HEY_WIN_IMPORT HeyWinHandle HEY_WIN_API CreateIoCompletionPort(HeyWinHandle file, HeyWinHandle port, uintptr_t key, HeyWinDword threads);
HEY_WIN_IMPORT HeyWinBool HEY_WIN_API GetQueuedCompletionStatusEx(HeyWinHandle port, HeyWinOverlappedEntry *entries,
  unsigned long count, unsigned long *removed, HeyWinDword timeout_ms, HeyWinBool alertable);
HEY_WIN_IMPORT HeyWinBool HEY_WIN_API CloseHandle(HeyWinHandle handle);

#define HEY_WIN_AF_INET 2
#define HEY_WIN_SOCK_STREAM 1
#define HEY_WIN_IPPROTO_TCP 6
#define HEY_WIN_SOL_SOCKET 0xffff
#define HEY_WIN_SO_EXCLUSIVEADDRUSE ((int)(~4))
#define HEY_WIN_SO_UPDATE_ACCEPT_CONTEXT 0x700B
#define HEY_WIN_TCP_NODELAY 1
#define HEY_WIN_FIONBIO ((long)0x8004667eL)
#define HEY_WIN_SIO_GET_EXTENSION_FUNCTION_POINTER 0xc8000006UL
#define HEY_WIN_WSA_FLAG_OVERLAPPED 0x01UL
#define HEY_WIN_INVALID_SOCKET (~(HeyWinSocket)0)
#define HEY_WIN_SOCKET_ERROR (-1)
#define HEY_WIN_WSAEINTR 10004
#define HEY_WIN_WSAEWOULDBLOCK 10035
#define HEY_WIN_WSA_IO_PENDING 997
#define HEY_WIN_INFINITE 0xffffffffUL
#define HEY_WIN_SOMAXCONN 0x7fffffff

static const HeyWinGuid hey_win_wsaid_acceptex = {0xb5367df1, 0xcbac, 0x11cf, {0x95, 0xca, 0x00, 0x80, 0x5f, 0x48, 0xa1, 0x92}};

/* ---- the loop ------------------------------------------------------------ */

#define HEY_IOCP_BACKEND "iocp"
#define HEY_IOCP_MAX_EVENTS 1024
#define HEY_IOCP_ACCEPTS 64
#define HEY_IOCP_READ_CHUNK 65536
#define HEY_IOCP_MAX_INPUT (1024 * 1024)
#define HEY_IOCP_ADDRESS_SPACE ((int)sizeof(HeyWinSockaddrIn) + 16)

enum { HEY_IOCP_OP_ACCEPT = 1, HEY_IOCP_OP_RECV = 2, HEY_IOCP_OP_SEND = 3 };

struct HeyIocpConn;

typedef struct HeyIocpOp {
  HeyWinOverlapped overlapped;          /* first: a completion's pointer is the op */
  uint8_t kind;
  struct HeyIocpConn *conn;              /* recv/send */
  HeyWinSocket accepted;                 /* accept */
  char addresses[2 * HEY_IOCP_ADDRESS_SPACE];
} HeyIocpOp;

typedef struct HeyIocpConn {
  HeyWinSocket socket;
  uint32_t slot;
  uint8_t open;
  uint8_t want_close;
  uint8_t queued;
  uint8_t recv_posted;
  uint8_t send_posted;
  uint32_t pending_ops;                  /* operations the kernel still owns */
  char *in;
  size_t in_off, in_len, in_cap;
  char *inflight;                        /* the buffer an overlapped WSASend owns */
  size_t inflight_len;
  char *out;                             /* queued behind the in-flight send */
  size_t out_len, out_cap;
  HeyIocpOp recv_op;
  HeyIocpOp send_op;
} HeyIocpConn;

typedef struct HeyIocpSlot {
  HeyIocpConn *conn;
  uint32_t gen;
  uint32_t next_free;
} HeyIocpSlot;

typedef struct HeyIocpLoop {
  HeyWinHandle port_handle;
  HeyWinSocket listener;
  int port;
  int closing;
  HeyWinAcceptEx accept_ex;
  HeyIocpOp accepts[HEY_IOCP_ACCEPTS];
  uint32_t accepts_pending;
  HeyIocpSlot *slots;
  uint32_t slots_cap;
  uint32_t free_head;                    /* UINT32_MAX: none */
  uint32_t zombies;                      /* closed connections waiting for their operations */
  int *ready;
  size_t ready_len, ready_pos, ready_cap;
  int *pending;
  size_t pending_len, pending_cap;
  char *scratch;
  HeyWinOverlappedEntry entries[HEY_IOCP_MAX_EVENTS];   /* here, not on the stack: no __chkstk */
  char stats_text[640];
  uint64_t accepted, closed, live, waits, batches_ready, bytes_in, bytes_out;
  uint64_t accept_errors, oversize, invalid_text, partial_writes, completions;
} HeyIocpLoop;

static HeyIocpLoop *hey_iocp_loop(HeyNativeHandle value) { return (HeyIocpLoop *)value; }

static int64_t hey_iocp_id(HeyIocpLoop *loop, uint32_t slot) {
  return ((int64_t)loop->slots[slot].gen << 32) | (int64_t)slot;
}

static HeyIocpConn *hey_iocp_lookup(HeyIocpLoop *loop, int64_t id) {
  if (!loop || id < 0) return NULL;
  uint32_t slot = (uint32_t)(id & 0xffffffff);
  uint32_t gen = (uint32_t)((uint64_t)id >> 32);
  if (slot >= loop->slots_cap) return NULL;
  HeyIocpSlot *s = &loop->slots[slot];
  if (!s->conn || !s->conn->open || s->gen != gen) return NULL;
  return s->conn;
}

static int hey_iocp_grow_ints(int **items, size_t *cap, size_t need) {
  if (need <= *cap) return 1;
  size_t next = *cap ? *cap * 2 : 256;
  while (next < need) next *= 2;
  int *grown = (int *)realloc(*items, next * sizeof(int));
  if (!grown) return 0;
  *items = grown;
  *cap = next;
  return 1;
}

static int hey_iocp_take_slot(HeyIocpLoop *loop, uint32_t *slot_out) {
  if (loop->free_head == UINT32_MAX) {
    uint32_t old_cap = loop->slots_cap;
    uint32_t next = old_cap ? old_cap * 2 : 1024;
    HeyIocpSlot *grown = (HeyIocpSlot *)realloc(loop->slots, (size_t)next * sizeof(HeyIocpSlot));
    if (!grown) return 0;
    for (uint32_t i = old_cap; i < next; i++) {
      grown[i].conn = NULL;
      grown[i].gen = 0;
      grown[i].next_free = i + 1 < next ? i + 1 : UINT32_MAX;
    }
    loop->slots = grown;
    loop->slots_cap = next;
    loop->free_head = old_cap;
  }
  uint32_t slot = loop->free_head;
  loop->free_head = loop->slots[slot].next_free;
  *slot_out = slot;
  return 1;
}

static void hey_iocp_release(HeyIocpLoop *loop, HeyIocpConn *c) {
  HeyIocpSlot *s = &loop->slots[c->slot];
  s->conn = NULL;
  s->next_free = loop->free_head;
  loop->free_head = c->slot;
  free(c->in);
  free(c->inflight);
  free(c->out);
  free(c);
}

static void hey_iocp_close_conn(HeyIocpLoop *loop, HeyIocpConn *c) {
  if (!c->open) return;
  c->open = 0;
  loop->slots[c->slot].gen++;        /* every id handed out for it is now stale */
  closesocket(c->socket);            /* cancels its outstanding operations */
  c->socket = HEY_WIN_INVALID_SOCKET;
  loop->closed++;
  if (loop->live) loop->live--;
  if (c->pending_ops == 0) hey_iocp_release(loop, c);
  else loop->zombies++;
}

/* An operation of `c` came back: release a closed connection with its last one. */
static int hey_iocp_op_done(HeyIocpLoop *loop, HeyIocpConn *c) {
  if (c->pending_ops) c->pending_ops--;
  if (!c->open) {
    if (c->pending_ops == 0) {
      if (loop->zombies) loop->zombies--;
      hey_iocp_release(loop, c);
    }
    return 0;
  }
  return 1;
}

/* ---- receive ------------------------------------------------------------ */

static void hey_iocp_post_recv(HeyIocpLoop *loop, HeyIocpConn *c) {
  if (!c->open || c->recv_posted) return;
  static char nothing[1];
  HeyWinWsaBuf buffer = {0, nothing};
  HeyWinDword flags = 0;
  memset(&c->recv_op.overlapped, 0, sizeof(c->recv_op.overlapped));
  c->recv_op.kind = HEY_IOCP_OP_RECV;
  c->recv_op.conn = c;
  c->recv_posted = 1;
  c->pending_ops++;
  if (WSARecv(c->socket, &buffer, 1, NULL, &flags, &c->recv_op.overlapped, NULL) == HEY_WIN_SOCKET_ERROR &&
      WSAGetLastError() != HEY_WIN_WSA_IO_PENDING) {
    c->recv_posted = 0;
    c->pending_ops--;
    hey_iocp_close_conn(loop, c);
  }
  /* success or pending: the completion is queued to the port either way */
}

static void hey_iocp_mark_ready(HeyIocpLoop *loop, HeyIocpConn *c) {
  if (!c->open || c->queued || c->in_len == c->in_off) return;
  if (!hey_iocp_grow_ints(&loop->ready, &loop->ready_cap, loop->ready_len + 1)) return;
  c->queued = 1;
  loop->ready[loop->ready_len++] = (int)c->slot;
}

/* Non-blocking reads until the socket would block. Returns 0 when it was closed. */
static int hey_iocp_read_all(HeyIocpLoop *loop, HeyIocpConn *c) {
  for (;;) {
    int n = recv(c->socket, loop->scratch, HEY_IOCP_READ_CHUNK, 0);
    if (n > 0) {
      loop->bytes_in += (uint64_t)n;
      if (c->in_off == c->in_len) c->in_off = c->in_len = 0;
      size_t need = c->in_len + (size_t)n;
      if (need - c->in_off > HEY_IOCP_MAX_INPUT) { loop->oversize++; hey_iocp_close_conn(loop, c); return 0; }
      if (need > c->in_cap) {
        if (c->in_off > 0) {
          memmove(c->in, c->in + c->in_off, c->in_len - c->in_off);
          c->in_len -= c->in_off;
          c->in_off = 0;
          need = c->in_len + (size_t)n;
        }
        if (need > c->in_cap) {
          size_t cap = c->in_cap ? c->in_cap : 1024;
          while (cap < need) cap *= 2;
          char *grown = (char *)realloc(c->in, cap);
          if (!grown) { hey_iocp_close_conn(loop, c); return 0; }
          c->in = grown;
          c->in_cap = cap;
        }
      }
      memcpy(c->in + c->in_len, loop->scratch, (size_t)n);
      c->in_len += (size_t)n;
      /* a short read drained it: the next zero-byte receive reports any more */
      if (n < HEY_IOCP_READ_CHUNK) return 1;
      continue;
    }
    if (n == 0) { hey_iocp_close_conn(loop, c); return 0; }
    int error = WSAGetLastError();
    if (error == HEY_WIN_WSAEINTR) continue;
    if (error == HEY_WIN_WSAEWOULDBLOCK) return 1;
    hey_iocp_close_conn(loop, c);
    return 0;
  }
}

/* ---- send --------------------------------------------------------------- */

static void hey_iocp_post_send(HeyIocpLoop *loop, HeyIocpConn *c) {
  if (!c->open || c->send_posted || c->out_len == 0) return;
  free(c->inflight);
  c->inflight = c->out;               /* the queue becomes the in-flight buffer */
  c->inflight_len = c->out_len;
  c->out = NULL;
  c->out_len = c->out_cap = 0;
  HeyWinWsaBuf buffer = {(unsigned long)c->inflight_len, c->inflight};
  memset(&c->send_op.overlapped, 0, sizeof(c->send_op.overlapped));
  c->send_op.kind = HEY_IOCP_OP_SEND;
  c->send_op.conn = c;
  c->send_posted = 1;
  c->pending_ops++;
  if (WSASend(c->socket, &buffer, 1, NULL, 0, &c->send_op.overlapped, NULL) == HEY_WIN_SOCKET_ERROR &&
      WSAGetLastError() != HEY_WIN_WSA_IO_PENDING) {
    c->send_posted = 0;
    c->pending_ops--;
    hey_iocp_close_conn(loop, c);
  }
}

static int hey_iocp_queue(HeyIocpConn *c, const char *data, size_t len) {
  size_t need = c->out_len + len;
  if (need > c->out_cap) {
    size_t cap = c->out_cap ? c->out_cap : 4096;
    while (cap < need) cap *= 2;
    char *grown = (char *)realloc(c->out, cap);
    if (!grown) return 0;
    c->out = grown;
    c->out_cap = cap;
  }
  memcpy(c->out + c->out_len, data, len);
  c->out_len += len;
  return 1;
}

/* ---- accept ------------------------------------------------------------- */

static void hey_iocp_post_accept(HeyIocpLoop *loop, HeyIocpOp *op) {
  if (loop->closing) return;
  op->accepted = WSASocketW(HEY_WIN_AF_INET, HEY_WIN_SOCK_STREAM, HEY_WIN_IPPROTO_TCP, NULL, 0, HEY_WIN_WSA_FLAG_OVERLAPPED);
  if (op->accepted == HEY_WIN_INVALID_SOCKET) { loop->accept_errors++; return; }
  memset(&op->overlapped, 0, sizeof(op->overlapped));
  op->kind = HEY_IOCP_OP_ACCEPT;
  op->conn = NULL;
  HeyWinDword received = 0;
  loop->accepts_pending++;
  /* receive_length 0: complete on the connection, not on its first bytes, so
     a client that connects and stays silent cannot hold an accept slot */
  if (!loop->accept_ex(loop->listener, op->accepted, op->addresses, 0, HEY_IOCP_ADDRESS_SPACE, HEY_IOCP_ADDRESS_SPACE,
                       &received, &op->overlapped) &&
      WSAGetLastError() != HEY_WIN_WSA_IO_PENDING) {
    loop->accepts_pending--;
    closesocket(op->accepted);
    op->accepted = HEY_WIN_INVALID_SOCKET;
    loop->accept_errors++;
  }
}

static void hey_iocp_accepted(HeyIocpLoop *loop, HeyIocpOp *op, int ok) {
  if (loop->accepts_pending) loop->accepts_pending--;
  HeyWinSocket s = op->accepted;
  op->accepted = HEY_WIN_INVALID_SOCKET;
  if (!ok || loop->closing) {
    if (s != HEY_WIN_INVALID_SOCKET) closesocket(s);
    if (!ok) loop->accept_errors++;
    hey_iocp_post_accept(loop, op);
    return;
  }
  unsigned long nonblocking = 1;
  int one = 1;
  uint32_t slot = 0;
  HeyIocpConn *c = NULL;
  if (setsockopt(s, HEY_WIN_SOL_SOCKET, HEY_WIN_SO_UPDATE_ACCEPT_CONTEXT, (const char *)&loop->listener, (int)sizeof(loop->listener)) != 0 ||
      ioctlsocket(s, HEY_WIN_FIONBIO, &nonblocking) != 0 ||
      CreateIoCompletionPort((HeyWinHandle)s, loop->port_handle, 0, 0) == NULL ||
      !(c = (HeyIocpConn *)malloc(sizeof(HeyIocpConn))) ||
      !hey_iocp_take_slot(loop, &slot)) {
    free(c);
    closesocket(s);
    loop->accept_errors++;
    hey_iocp_post_accept(loop, op);
    return;
  }
  setsockopt(s, HEY_WIN_IPPROTO_TCP, HEY_WIN_TCP_NODELAY, (const char *)&one, (int)sizeof(one));
  memset(c, 0, sizeof(*c));
  c->socket = s;
  c->slot = slot;
  c->open = 1;
  loop->slots[slot].conn = c;
  loop->accepted++;
  loop->live++;
  hey_iocp_post_accept(loop, op);
  /* clients usually send the request with the handshake: read it now */
  if (hey_iocp_read_all(loop, c)) {
    hey_iocp_post_recv(loop, c);
    hey_iocp_mark_ready(loop, c);
  }
}

/* ---- text check: the hand-over is UTF-8 text without NUL --------------- */

static size_t hey_iocp_text_prefix(const unsigned char *s, size_t n, int *bad) {
  size_t i = 0;
  *bad = 0;
  while (i < n) {
    unsigned char b = s[i];
    if (b >= 0x01 && b < 0x80) { i++; continue; }
    if (b == 0) { *bad = 1; return i; }
    size_t need;
    uint32_t cp;
    if (b >= 0xc2 && b <= 0xdf) { need = 1; cp = b & 0x1f; }
    else if (b >= 0xe0 && b <= 0xef) { need = 2; cp = b & 0x0f; }
    else if (b >= 0xf0 && b <= 0xf4) { need = 3; cp = b & 0x07; }
    else { *bad = 1; return i; }
    if (i + need >= n) {
      for (size_t k = i + 1; k < n; k++) if ((s[k] & 0xc0) != 0x80) { *bad = 1; return i; }
      return i;
    }
    for (size_t k = 1; k <= need; k++) {
      if ((s[i + k] & 0xc0) != 0x80) { *bad = 1; return i; }
      cp = (cp << 6) | (s[i + k] & 0x3f);
    }
    if ((need == 2 && cp < 0x800) || (need == 3 && (cp < 0x10000 || cp > 0x10ffff)) || (cp >= 0xd800 && cp <= 0xdfff)) {
      *bad = 1;
      return i;
    }
    i += need + 1;
  }
  return i;
}

/* ---- stats text without a C runtime formatter ---------------------------- */

static size_t hey_iocp_put(char *out, size_t at, size_t cap, const char *text) {
  while (*text && at + 1 < cap) out[at++] = *text++;
  return at;
}

static size_t hey_iocp_put_u64(char *out, size_t at, size_t cap, uint64_t value) {
  char digits[24];
  int n = 0;
  do { digits[n++] = (char)('0' + value % 10); value /= 10; } while (value);
  while (n > 0 && at + 1 < cap) out[at++] = digits[--n];
  return at;
}

/* ---- public functions ---------------------------------------------------- */

HeyNativeHandle hey_iocp_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport) {
  (void)reuseport;   /* Windows has no load-spreading SO_REUSEPORT; one listener per port */
  char host_c[64];
  if (host.length >= sizeof(host_c)) return (HeyNativeHandle)0;
  memcpy(host_c, host.data, host.length);
  host_c[host.length] = '\0';

  unsigned char wsa_data[512];
  if (WSAStartup(0x0202, wsa_data) != 0) return (HeyNativeHandle)0;

  HeyWinSockaddrIn addr;
  memset(&addr, 0, sizeof(addr));
  addr.family = HEY_WIN_AF_INET;
  addr.port = htons((unsigned short)port);
  if (inet_pton(HEY_WIN_AF_INET, host_c, &addr.address) != 1) { WSACleanup(); return (HeyNativeHandle)0; }

  HeyWinSocket lfd = WSASocketW(HEY_WIN_AF_INET, HEY_WIN_SOCK_STREAM, HEY_WIN_IPPROTO_TCP, NULL, 0, HEY_WIN_WSA_FLAG_OVERLAPPED);
  if (lfd == HEY_WIN_INVALID_SOCKET) { WSACleanup(); return (HeyNativeHandle)0; }
  int one = 1;
  setsockopt(lfd, HEY_WIN_SOL_SOCKET, HEY_WIN_SO_EXCLUSIVEADDRUSE, (const char *)&one, (int)sizeof(one));
  if (bind(lfd, &addr, (int)sizeof(addr)) != 0 || listen(lfd, backlog > 0 ? backlog : HEY_WIN_SOMAXCONN) != 0) {
    closesocket(lfd);
    WSACleanup();
    return (HeyNativeHandle)0;
  }
  int alen = (int)sizeof(addr);
  getsockname(lfd, &addr, &alen);

  HeyIocpLoop *loop = (HeyIocpLoop *)malloc(sizeof(HeyIocpLoop));
  if (!loop) { closesocket(lfd); WSACleanup(); return (HeyNativeHandle)0; }
  memset(loop, 0, sizeof(*loop));
  loop->listener = lfd;
  loop->port = ntohs(addr.port);
  loop->free_head = UINT32_MAX;
  loop->scratch = (char *)malloc(HEY_IOCP_READ_CHUNK);
  loop->port_handle = CreateIoCompletionPort((HeyWinHandle)(intptr_t)-1, NULL, 0, 1);
  HeyWinGuid guid = hey_win_wsaid_acceptex;
  HeyWinDword returned = 0;
  if (!loop->scratch || loop->port_handle == NULL ||
      CreateIoCompletionPort((HeyWinHandle)lfd, loop->port_handle, 0, 0) == NULL ||
      WSAIoctl(lfd, HEY_WIN_SIO_GET_EXTENSION_FUNCTION_POINTER, &guid, (HeyWinDword)sizeof(guid), &loop->accept_ex,
               (HeyWinDword)sizeof(loop->accept_ex), &returned, NULL, NULL) != 0 || loop->accept_ex == NULL) {
    if (loop->port_handle) CloseHandle(loop->port_handle);
    closesocket(lfd);
    free(loop->scratch);
    free(loop);
    WSACleanup();
    return (HeyNativeHandle)0;
  }
  for (int i = 0; i < HEY_IOCP_ACCEPTS; i++) {
    loop->accepts[i].accepted = HEY_WIN_INVALID_SOCKET;
    hey_iocp_post_accept(loop, &loop->accepts[i]);
  }
  return (HeyNativeHandle)loop;
}

static void hey_iocp_complete(HeyIocpLoop *loop, HeyWinOverlappedEntry *entry) {
  HeyIocpOp *op = (HeyIocpOp *)entry->overlapped;
  if (!op) return;
  int ok = op->overlapped.internal == 0;   /* NTSTATUS STATUS_SUCCESS */
  loop->completions++;
  if (op->kind == HEY_IOCP_OP_ACCEPT) { hey_iocp_accepted(loop, op, ok); return; }
  HeyIocpConn *c = op->conn;
  if (op->kind == HEY_IOCP_OP_RECV) {
    c->recv_posted = 0;
    if (!hey_iocp_op_done(loop, c)) return;
    if (!ok) { hey_iocp_close_conn(loop, c); return; }
    if (!hey_iocp_read_all(loop, c)) return;
    hey_iocp_post_recv(loop, c);
    hey_iocp_mark_ready(loop, c);
    return;
  }
  if (op->kind == HEY_IOCP_OP_SEND) {
    c->send_posted = 0;
    if (!hey_iocp_op_done(loop, c)) return;
    if (!ok) { hey_iocp_close_conn(loop, c); return; }
    size_t sent = entry->bytes;
    loop->bytes_out += (uint64_t)sent;
    if (sent < c->inflight_len) {
      /* a short overlapped send: put the rest in front of the queue */
      size_t rest = c->inflight_len - sent;
      char *merged = (char *)malloc(rest + c->out_len);
      if (!merged) { hey_iocp_close_conn(loop, c); return; }
      memcpy(merged, c->inflight + sent, rest);
      if (c->out_len) memcpy(merged + rest, c->out, c->out_len);
      free(c->out);
      c->out = merged;
      c->out_len = c->out_cap = rest + c->out_len;
    }
    free(c->inflight);
    c->inflight = NULL;
    c->inflight_len = 0;
    if (c->out_len) { hey_iocp_post_send(loop, c); return; }
    if (c->want_close) hey_iocp_close_conn(loop, c);
  }
}

int32_t hey_iocp_close(HeyNativeHandle value) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  if (!loop) return -1;
  loop->closing = 1;
  for (uint32_t i = 0; i < loop->slots_cap; i++) {
    if (loop->slots[i].conn && loop->slots[i].conn->open) hey_iocp_close_conn(loop, loop->slots[i].conn);
  }
  /* Closing the listener cancels the outstanding AcceptEx operations; each
     comes back failed and hey_iocp_accepted closes its socket. */
  closesocket(loop->listener);
  /* Drain: the kernel returns every cancelled operation before its memory may go. */
  int rounds = 0;
  while ((loop->zombies > 0 || loop->accepts_pending > 0) && rounds < 50) {
    unsigned long n = 0;
    if (!GetQueuedCompletionStatusEx(loop->port_handle, loop->entries, HEY_IOCP_MAX_EVENTS, &n, 100, 0)) { rounds++; continue; }
    for (unsigned long i = 0; i < n; i++) hey_iocp_complete(loop, &loop->entries[i]);
  }
  CloseHandle(loop->port_handle);
  if (loop->zombies > 0 || loop->accepts_pending > 0) {
    /* operations still owned by the kernel after 5 s: leak their memory rather
       than free what the kernel may still write */
    WSACleanup();
    return -2;
  }
  free(loop->slots);
  free(loop->ready);
  free(loop->pending);
  free(loop->scratch);
  free(loop);
  WSACleanup();
  return 0;
}

int32_t hey_iocp_wait(HeyNativeHandle value, int32_t timeout_ms) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  if (!loop) return -1;
  size_t untaken_from = loop->ready_pos;
  for (size_t i = 0; i < loop->ready_len; i++) {
    int slot = loop->ready[i];
    HeyIocpConn *c = (size_t)slot < loop->slots_cap ? loop->slots[slot].conn : NULL;
    if (c) c->queued = 0;
    if (i >= untaken_from && hey_iocp_grow_ints(&loop->pending, &loop->pending_cap, loop->pending_len + 1)) {
      loop->pending[loop->pending_len++] = slot;
    }
  }
  loop->ready_len = loop->ready_pos = 0;
  size_t carried = loop->pending_len;
  for (size_t i = 0; i < carried; i++) {
    int slot = loop->pending[i];
    HeyIocpConn *c = (size_t)slot < loop->slots_cap ? loop->slots[slot].conn : NULL;
    if (c && c->open) hey_iocp_mark_ready(loop, c);
  }
  loop->pending_len = 0;
  HeyWinDword timeout = loop->ready_len ? 0 : (timeout_ms < 0 ? HEY_WIN_INFINITE : (HeyWinDword)timeout_ms);
  loop->waits++;

  unsigned long n = 0;
  if (GetQueuedCompletionStatusEx(loop->port_handle, loop->entries, HEY_IOCP_MAX_EVENTS, &n, timeout, 0)) {
    for (unsigned long i = 0; i < n; i++) hey_iocp_complete(loop, &loop->entries[i]);
  }
  loop->batches_ready += loop->ready_len;
  return (int32_t)loop->ready_len;
}

int64_t hey_iocp_next(HeyNativeHandle value) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  if (!loop) return -1;
  while (loop->ready_pos < loop->ready_len) {
    int slot = loop->ready[loop->ready_pos++];
    HeyIocpConn *c = (size_t)slot < loop->slots_cap ? loop->slots[slot].conn : NULL;
    if (c && c->open && c->in_len > c->in_off) return hey_iocp_id(loop, (uint32_t)slot);
  }
  return -1;
}

HeyNativeUtf8View hey_iocp_data(HeyNativeHandle value, int64_t id) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  HeyIocpConn *c = hey_iocp_lookup(loop, id);
  if (!c) return (HeyNativeUtf8View){"", 0};
  const char *start = c->in + c->in_off;
  size_t len = c->in_len - c->in_off;
  int bad = 0;
  size_t ok = hey_iocp_text_prefix((const unsigned char *)start, len, &bad);
  if (bad) {
    loop->invalid_text++;
    hey_iocp_close_conn(loop, c);
    return (HeyNativeUtf8View){"", 0};
  }
  return (HeyNativeUtf8View){start, ok};
}

int32_t hey_iocp_send(HeyNativeHandle value, int64_t id, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  HeyIocpConn *c = hey_iocp_lookup(loop, id);
  if (!c) return 0;
  size_t available = c->in_len - c->in_off;
  size_t take = consumed < 0 ? 0 : (size_t)consumed;
  if (take > available) take = available;
  c->in_off += take;
  if (c->in_off == c->in_len) {
    c->in_off = c->in_len = 0;
    free(c->in);
    c->in = NULL;
    c->in_cap = 0;
  }
  if (close_after) c->want_close = 1;

  const char *src = data.data;
  size_t len = data.length;
  if (!c->send_posted && c->out_len == 0) {
    /* nothing in flight or queued: write straight from the caller's text */
    while (len > 0) {
      int chunk = len > (size_t)INT_MAX ? INT_MAX : (int)len;
      int n = send(c->socket, src, chunk, 0);
      if (n > 0) { loop->bytes_out += (uint64_t)n; src += n; len -= (size_t)n; continue; }
      int error = WSAGetLastError();
      if (error == HEY_WIN_WSAEINTR) continue;
      if (error == HEY_WIN_WSAEWOULDBLOCK) break;
      hey_iocp_close_conn(loop, c);
      return 0;
    }
  }
  if (len > 0) {
    loop->partial_writes++;
    if (!hey_iocp_queue(c, src, len)) { hey_iocp_close_conn(loop, c); return 0; }
    hey_iocp_post_send(loop, c);
    if (!c->open) return 1;
  } else if (c->want_close && !c->send_posted && c->out_len == 0) {
    hey_iocp_close_conn(loop, c);
    return 1;
  }
  if (c->open && c->in_len > c->in_off && hey_iocp_grow_ints(&loop->pending, &loop->pending_cap, loop->pending_len + 1)) {
    loop->pending[loop->pending_len++] = (int)c->slot;
  }
  return 1;
}

int32_t hey_iocp_drop(HeyNativeHandle value, int64_t id) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  HeyIocpConn *c = hey_iocp_lookup(loop, id);
  if (!c) return 0;
  hey_iocp_close_conn(loop, c);
  return 1;
}

int32_t hey_iocp_port(HeyNativeHandle value) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  return loop ? loop->port : -1;
}

HeyNativeUtf8View hey_iocp_stats(HeyNativeHandle value) {
  HeyIocpLoop *loop = hey_iocp_loop(value);
  if (!loop) return (HeyNativeUtf8View){"{}", 2};
  char *o = loop->stats_text;
  size_t cap = sizeof(loop->stats_text), at = 0;
  const char *names[] = {"live", "accepted", "closed", "waits", "ready", "bytes_in", "bytes_out", "accept_errors",
                         "oversize", "invalid_text", "partial_writes", "completions", "zombies"};
  uint64_t values[] = {loop->live, loop->accepted, loop->closed, loop->waits, loop->batches_ready, loop->bytes_in,
                       loop->bytes_out, loop->accept_errors, loop->oversize, loop->invalid_text, loop->partial_writes,
                       loop->completions, loop->zombies};
  at = hey_iocp_put(o, at, cap, "{\"backend\":\"" HEY_IOCP_BACKEND "\"");
  for (size_t i = 0; i < sizeof(values) / sizeof(values[0]); i++) {
    at = hey_iocp_put(o, at, cap, ",\"");
    at = hey_iocp_put(o, at, cap, names[i]);
    at = hey_iocp_put(o, at, cap, "\":");
    at = hey_iocp_put_u64(o, at, cap, values[i]);
  }
  at = hey_iocp_put(o, at, cap, "}");
  o[at] = '\0';
  return (HeyNativeUtf8View){o, at};
}

HeyNativeUtf8View hey_iocp_backend(void) {
  return (HeyNativeUtf8View){HEY_IOCP_BACKEND, sizeof(HEY_IOCP_BACKEND) - 1};
}
