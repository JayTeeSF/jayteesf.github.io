# hey_secret_lint

Flags `==` / `!=` on values that look secret in a Hey project's sources, and
`Crypto.constant_time_equal?` calls given text instead of bytes, so secret
comparisons go through `Crypto.constant_time_equal?(bytes(a), bytes(b))`.

```sh
hey secret-lint .
```

See [docs/README.md](docs/README.md).
