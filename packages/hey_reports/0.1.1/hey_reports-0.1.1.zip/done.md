# DONE — hey_reports (newest first)

## 0.1.1 — the compiled lane builds again

`bin/check` was red: `FAIL [compiled lane]: main_spec did not BUILD`.
The compiled lane cannot lower `bytes()` in its MIR-to-LLVM emitter,
which pushes the whole program onto the legacy consumer, and the legacy
consumer cannot lower `for x in call()`. `ReportsSvg.render_result` and
`main_spec` now bind each call result to a local before looping over it.
This is a compiler workaround, recorded in `docs/ROADMAP.md`. All 6 specs
build in both lanes again, with identical output.

## 0.1.0 — first working package

Chart model, SVG renderer (bar/line/pie with axes, tick labels, axis
titles and legends), hey-tv-scene-v2 renderer, three surface themes,
integer-only geometry, and a two-lane gate.

**Evidence, not claims:**

- `bin/check` green: 6 specs × 2 lanes, stdout diffed and identical;
  hey_tv's own `Television.validate_scene` accepts the scene document
  and its negative control rejects an invented widget kind; five SVGs
  rasterised by `rsvg-convert` (librsvg 2.62.3) against measured
  per-file PNG byte floors; `hey package verify` and `hey_packager
  check` pass.
- Real render, real file, real numbers: `tmp/spec-bar-web.svg` is
  4947 bytes, `Files.size` agrees with `byte_length` exactly, and the
  PNG is 16980 bytes.
- XSS: `<script>alert('pwn')</script>` as a series label, a category
  and a title; the string `<script` does not appear in the output.

**Failures found and fixed along the way** (each cost real time):

1. `s.values` silently invoked the BUILTIN `values(s)` instead of
   reading the field — returned a plausible array, then failed several
   frames later on `comparison < expects two integers`. Field renamed
   to `points`.
2. Nested float ops lower to `0` in the compiled lane. Silently.
3. Object literals containing indexing or calls cannot be lowered.
4. `type()` cannot be lowered at all.
5. Arithmetic inside a string concatenation becomes CONCATENATION when
   compiled: `900 + 900 + 1800` printed `9009001800`.
6. A float as a function parameter is truncated to an integer when
   compiled. This one removed floating point from the package entirely.

**A gate that could not fail, found and fixed:** the PNG floor started
as one global 2000-byte threshold. A deliberately blanked 800×480 chart
rasterised to 3523 bytes and passed. Replaced with measured per-file
floors, then re-broken to confirm it now goes red.

**Deliberately not built:** all raster encoding; line and pie on
television (blocked on scene-v2 having no absolute positioning); a
native mobile renderer (blocked on hey_mobile having no drawing
vocabulary); fractional axis ticks; real font metrics; interactivity.

**Not published.** Local commits only, no remote, release-READY.
