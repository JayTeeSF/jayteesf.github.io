#ifndef HEY_IO_URING_H
#define HEY_IO_URING_H

#include "hey_native_abi.h"

/* One event loop: a TCP listener plus every connection it accepted, driven by
   one io_uring (Linux only). The serving calls (wait/next/data/send/drop/
   stats/close) have exactly the signatures of hey_epoll's, so hey_poller can
   call any backend's extension the same way. A loop is owned by exactly one
   Hey thread: the one that opened it (the ring is a single-issuer ring). */
HeyNativeHandle hey_io_uring_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport,
                                  int32_t sq_entries, int32_t cq_entries, int32_t buffers, int32_t buffer_size);
int32_t hey_io_uring_close(HeyNativeHandle loop);
int32_t hey_io_uring_wait(HeyNativeHandle loop, int32_t timeout_ms);
int64_t hey_io_uring_next(HeyNativeHandle loop);
HeyNativeUtf8View hey_io_uring_data(HeyNativeHandle loop, int64_t connection);
int32_t hey_io_uring_send(HeyNativeHandle loop, int64_t connection, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after);
int32_t hey_io_uring_drop(HeyNativeHandle loop, int64_t connection);
int32_t hey_io_uring_port(HeyNativeHandle loop);
HeyNativeUtf8View hey_io_uring_stats(HeyNativeHandle loop);
HeyNativeUtf8View hey_io_uring_backend(void);
/* Why the last open() on this thread returned no loop: {"code":...,"message":...}. */
HeyNativeUtf8View hey_io_uring_open_error(void);
/* Whether this kernel and process can run the loop, without opening a listener.
   min_kernel ('' = the built-in 6.0) and sysctl_path ('' = /proc/sys/kernel/
   io_uring_disabled) exist so the refusal paths can be tested. */
HeyNativeUtf8View hey_io_uring_probe(HeyNativeUtf8View min_kernel, HeyNativeUtf8View sysctl_path);

#endif
