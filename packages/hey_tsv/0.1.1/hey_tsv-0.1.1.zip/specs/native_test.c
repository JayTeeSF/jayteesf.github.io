#include "hey_native_abi.h"
#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include "hey_tsv.h"
static void put32(uint8_t *p,uint32_t n){p[0]=n;p[1]=n>>8;p[2]=n>>16;p[3]=n>>24;}
int main(void){
 uint8_t b[256]={0};memcpy(b,"HYR1",4);put32(b+4,1);put32(b+8,4);size_t n=12;
 put32(b+n,UINT32_MAX);n+=4;put32(b+n,0);n+=4;
 const char payload[]="a\t\n\r\0\x1a\\N日本語";size_t size=sizeof(payload)-1;
 put32(b+n,size);n+=4;memcpy(b+n,payload,size);n+=size;put32(b+n,3);n+=4;memcpy(b+n,"123",3);n+=3;
 HeyNativeBytesView input={b,n};HeyNativeOwnedBytes encoded=tsv_encode(input);assert(encoded.data);
 const char expected[]="\\N\t\ta\\t\\n\\r\\0\\Z\\\\N日本語\t123\n";
 assert(encoded.length==sizeof(expected)-1 && !memcmp(encoded.data,expected,sizeof(expected)-1));
 assert(tsv_rows(input)==1 && tsv_last_u64(input,3)==123);
 assert(!tsv_encode((HeyNativeBytesView){b,n-1}).data);
 uint8_t saved=b[24];b[24]=255;assert(!tsv_encode(input).data);b[24]=saved;
 encoded.release(encoded.context,encoded.data,encoded.length);
 puts("PASS: exact escaped TSV, NULL/empty/NUL, Unicode and malformed-frame refusal");return 0;
}
