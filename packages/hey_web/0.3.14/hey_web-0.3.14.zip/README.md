# hey_web

`hey_web` is the application layer above Hey's current `stdlib:Web`, `stdlib:Http`, `stdlib:Net`, `stdlib:Ehy`, and Jobs runtime. (The version lives in `VERSION` / `HeyWebConfig.version()`; this file deliberately does not repeat it.)

It does **not** reimplement HTTP parsing, sockets, TLS, route dispatch, or the package manager. It adds the conveniences normally supplied by tools such as curl and Puma plus a small Rails-shaped application structure, and -- since the 0.2.x line -- a documented **fast lane** of modules extracted whole from a production app (RecallCoach) for serving on `stdlib:Web` directly:

| Rails/Ruby concept | Hey equivalent |
|---|---|
| `config/puma.rb` | `config/hey_web.json` plus `HeyWebServer` |
| `config/routes.rb` | `HeyWebRouter` route declarations in Hey source |
| controller classes | modules with request functions |
| ERB views/layouts | EHY through `HeyWebView` |
| JSON actions | `Web.json`, `Web.created`, and `HeyWebController.from_result` |
| Active Job | Hey `job`/`Jobs.define` plus `HeyWebJobs` |
| Active Record / Sequel | sibling `hey_record`, `hey_sqlite3`, and `hey_mysql` packages |

Routes remain Hey source because handlers are first-class compiled callables. JSON configuration controls the serve options and nothing else: `host`, `port`, `workers`, `max_connections`, `read_timeout_ms`, `max_body_bytes` (plus `max_requests` for one-shot receipts). Each has an explicit default and can be changed at process start, without a rebuild, through `HEY_WEB_WORKERS`, `HEY_WEB_MAX_CONNECTIONS`, `HEY_WEB_READ_TIMEOUT_MS` or `HEY_WEB_MAX_BODY_BYTES`; an invalid value stops the server before it binds. See "Serve settings" below. There is no middleware surface -- see "One serving lane" below for what was removed and why.

## curl-style client

```sh
bin/hey-web https://example.com/
bin/hey-web -H 'accept: application/json' https://example.com/items
bin/hey-web --json '{"name":"Ada"}' https://example.com/items
bin/hey-web -X PATCH --json '{"name":"Grace"}' https://example.com/items/1
bin/hey-web -o artifact.zip https://example.com/artifact.zip
```

The client delegates URL parsing, HTTP/HTTPS, redirects, TLS validation, bounded reads, and byte-preserving downloads to `stdlib:Http`. It adds CLI parsing, JSON bodies, status checking, presentation, and output-file behavior.

## Puma-style application server

```hey
import 'pkg:hey_web@<version>/main'
import 'stdlib:Web'
import 'stdlib:Cli'

module HealthController
  fn show(request)
    return Web.json({ok: true, service: 'cards'})
  end
end

program
  let config = HeyWebServer.options(Cli.args(), HeyWebConfig.load_or_default('config/hey_web.json'))
  let routes = [Web.get('/health', HealthController.show)]
  let app = HeyWeb.application('cards', routes, config)
  says HeyWebServer.banner(app)
  let running = HeyWeb.serve(app)
end
```

The default is `workers: 4` (the RecallCoach production value; correct since v0.99.399a fixed dispatch-path cloning -- docs/PERFORMANCE.md). `workers: 0` selects Hey's automatic online-CPU count. Slow, retryable, or durable work belongs in Jobs rather than request workers.

## The default serving lane

(0.3.7 adds a second, opt-in lane in its own module for many idle
connections, at the owner's request: see "Readiness lane" below. Nothing
here changed.)


hey_web's default (and HeyWeb.serve's only) lane is (maintainer ruling,
2026-07-30) exactly the RecallCoach production pattern -- a flat route table handed straight to
`stdlib:Web`'s native serve, with NOTHING layered on the request path:

```hey
Web.serve(Web.stack([Web.max_body(1048576)], routes), {host: host, port: port, workers: 4, max_connections: 1024, read_timeout_ms: 5000})
```

## Serve settings

| Setting | Default | Start-time override | Runtime meaning |
|---|---|---|---|
| `workers` | 4 | `HEY_WEB_WORKERS` | accept loops; the runtime caps it at 64 |
| `max_connections` | 1024 | `HEY_WEB_MAX_CONNECTIONS` | simultaneous serving connections; required when `worker_resource` is set (Hey 0.99.611a+) |
| `read_timeout_ms` | 5000 | `HEY_WEB_READ_TIMEOUT_MS` | longest gap between reads of a partial request; the socket closes on expiry |
| `max_body_bytes` | 1048576 | `HEY_WEB_MAX_BODY_BYTES` | 413 above this; at most 1048576, because the runtime closes any connection whose request passes 1 MiB |
| `backend` | `poll` | `HEY_WEB_BACKEND` | `poll`, `auto`, `epoll`, `kqueue` or `io_uring` (Hey 0.99.611a+; 610a serves on poll). `auto` takes the platform's readiness backend and falls back to poll; a named backend that cannot open refuses to start |
| `handler_workers` | 0 | `HEY_WEB_HANDLER_WORKERS` | requests run at once on a readiness backend; 0 means one per `workers`. Passed only when `backend` is not `poll` |

Precedence, lowest first: these defaults, the app's overrides, the environment. `HeyWebConfig.resolve(overrides, environment)` returns the config with `setting_sources` naming where each value came from, and `HeyWebServer.serve_routes(routes, overrides)` serves with it. Keep-alive idle time is the runtime's own `HEY_WEB_KEEPALIVE_IDLE_MS` (default 5000). `request_timeout_ms` was removed in 0.3.13: no Hey runtime ever read it.

### One database reader per serving worker

Pass `worker_resource: {open, close}` in the overrides and each serving
worker opens one resource the first time it serves, hands it to every
request as `request.worker_resource`, and closes it when it retires.
hey_record 0.6.0's `HeyRecordReader.hooks` builds the pair for a database
reader. The poller lane (`HeyWebPoller.run_loop`) does the same with one
resource per loop.

```hey
let readers = HeyRecordReader.hooks({connect: Sqlite3.connect, path: Db.path(),
  setup: HeyRecordReader.sqlite_setup()})
HeyWebServer.serve_routes(routes, {host: host, port: port, max_connections: 64, worker_resource: readers})
```

The worker bound is the resource bound: `max_connections` on `poll`,
`handler_workers` on a readiness backend, one per loop on the poller lane.
Set it to the number of database connections you want open. Hey 0.99.610a
ignores `worker_resource`, so handlers that open a connection when
`request.worker_resource` is absent run on both runtimes. Measured on Elders
Prayer (`/api/schedule`, 64 clients): 8,516 req/s at 22.8 ms p95 opening per
query; 56,328 req/s at 1.25 ms p95 with readers on 611a.

`HeyWebServer.serve(app)` is precisely that call over
`app.routes`/`app.config`. RecallCoach serves its production traffic
this way (itself the fleet-proven elders_prayer_app pattern: measured
62-69K req/s on `/health`, p50 ~57us, stdlib lane), and the handlers
are built from the fast-lane modules below.

### Removed in 0.3.0 (breaking), and what replaces each call

The 0.1.x-0.2.x middleware serving lane reached `Web.service` +
`Web.start`. In a compiled binary `Web.service` is JSON-delegated to
the stdlib sidecar (trunk `runtime/heyc.c` `facades[]`), so the
listener and worker pool were created IN the sidecar -- which owned the
LISTEN socket and had never seen the routes. Every request produced a
well-formed EMPTY 200 (500s at 0.99.474a) and no registered handler
ever ran; the only benchmark ever built on that lane was retracted in
full on 2026-07-28 because of it. A serving API that silently stops
serving when compiled is not an API, so the lane is DELETED, not
documented around:

| removed public surface | replacement |
|---|---|
| `HeyWebServer.service(application)` | none -- deleted outright. `HeyWebServer.serve` (native `Web.serve`) is the lane. |
| `HeyWebServer.middleware(config)` + the config `middleware` list | handler-level fast-lane modules (rows below). |
| middleware `secure_headers` | `HeyWebResponses` builders (the same headers inlined in every response). |
| middleware `log_requests` | `HeyWebRequestLog.config_with` + `wrap` in the router's logged wrappers. |
| middleware `request_id` | the `request_id` field of every `HeyWebRequestLog.line`. |
| middleware `max_body` | the `max_body_bytes` serve option (enforced by the runtime server). |
| middleware `require_json` | `HeyWebResponses.body_json` + the handler's own validation. |
| middleware `recover_errors` | none -- fail-fast; receipts assert `hey error:`-free server logs instead of masking throws. |
| `application.stack` record key | `application.routes` (the flat table; `Web.serve`/`Web.dispatch` take it directly). |
| config keys `backlog`, `write_timeout_ms`, `idle_timeout_ms` | none. `read_timeout_ms` returned in 0.3.13 because `Web.serve` reads it. |
| `HeyWeb.dispatch(app, request)` over the stack | same signature, now pure dispatch over `app.routes`. |

Honest performance note: the deleted lane was never validly benchmarked
against stdlib serving (the one comparison was the retraction above),
and the ~7 ms per-pure-Hey-call delegation figure the fast lane's
builtin-only discipline was tuned around dates to hey 0.99.390a (the
0.99.402a sidecar cut stdlib-call cost to ~60-80 us). The claim here is
NOT "measured faster": it is that this is the production-proven shape,
and a like-for-like number is still owed -- see RecallCoach
docs/framework-extraction.md section 7, whose G1 slice is that
measurement.

### Fast-lane modules

The supporting cast around the one lane. `main.hey` imports all five;
import them individually when you want the minimal surface:

| module | import | what it owns |
|---|---|---|
| `HeyWebListen` | `pkg:hey_web@<version>/listen` | HOST/PORT resolution: digits-only PORT parse (no silent 0), loud failure |
| `HeyWebOrigin` | `pkg:hey_web@<version>/origin` | public-origin policy: one reader, derived defaults, wildcard-bind refusal, loopback port-drift refusal, require-public posture |
| `HeyWebRequest` | `pkg:hey_web@<version>/request_support` | raw query parse (live runtime hands a raw string), never-nil param/header access, rightmost-trusted-hop `remote_ip` |
| `HeyWebRequestLog` | `pkg:hey_web@<version>/request_log` | one JSON line per request: allowlist-only header capture, authorization/cookie/set-cookie unloggable even when named, quiet poll routes |
| `HeyWebResponses` | `pkg:hey_web@<version>/responses` | builtin-only JSON/error/redirect builders with security headers inlined |

Shared discipline, learned the hard way in the source app: no nil ever
crosses these public surfaces (missing param/header answers `''`);
every env read is `Env.default` (bare `Env.get` does not lower
compiled); text scanning uses bare `index_of`/`slice` builtins
(`Text.index_of`/`Text.slice` do not lower); and `bin/check` holds a
COMPILED receipt (`tools/compiled_receipt.hey`) whose stdout must be
byte-identical between the interpreter and a real binary.

Env names are prefix-parameterized (the hey_mysql `from_env_prefix`
pattern). RecallCoach's bindings are the documented reference: listen
reads bare `HOST`/`PORT` (prefix `''`, reference default port 3748);
origin/request/log take the app prefix (`'RECALL_COACH_'` there), e.g.
`HeyWebOrigin.base_url_with('ACME_', host, port)` reads
`ACME_BASE_URL` and `ACME_REQUIRE_PUBLIC_ORIGIN`, and
`HeyWebRequestLog.config_with('ACME_', '')` reads `ACME_ACCESS_LOG`,
`ACME_LOG_HEADERS`, `ACME_LOG_QUIET_ROUTES`, `ACME_TRUSTED_PROXIES`.

Trunk overlap, stated plainly: since 0.99.474a `stdlib:Web`'s
`log_requests` middleware emits a structured access-log line -- the
trunk lifted this module's reference implementation. hey_web has no
middleware stack to hang it on (removed with the broken lane), so
`HeyWebRequestLog` is the package's access log: the app-level shape
(allowlisted extra headers, quiet routes, per-route labels, an env
prefix) wrapped per-route.

## Readiness lane for many idle connections (`poller.hey`, opt-in)

The default lane above is unchanged. `HeyWebPoller.serve_application(app)`
serves the same application record (same routes, handlers, request record via
`Web.request_from_http`, routing via `Web.dispatch`) from readiness-driven
event loops (hey_poller: epoll on Linux, kqueue on macOS) instead of a thread
per connection. Import it explicitly
(`import 'pkg:hey_web@0.3.7/poller'`); apps that do not are untouched. Details,
limits and when not to use it: [docs/POLLER.md](docs/POLLER.md).

### Engines compared

Same app (`tools/engine_bench_app.hey`, `GET /hello/:name`), wrk for 20 s.
Linux: arm64 container (Colima on an Apple M3 Pro), server limited with
`--cpus`, **mimalloc preloaded for both** (see below). macOS: same Mac, no
limit (Web.serve then uses all 12 cores; one poller loop uses one).

| where | connections | Web.serve (default) | HeyWebPoller |
|---|---|---|---|
| Linux, 1 CPU | 64 | 101,648 req/s, p99 75.8 ms, 67 threads | 76,360 req/s, p99 1.3 ms, 1 thread |
| Linux, 1 CPU | 10,000 | 80,171 req/s, **187,536 responses refused** (non-2xx), 147 MB, 259 threads | 56,184 req/s, 0 refused, 52 MB, 1 thread |
| Linux, 4 CPUs | 64 | 384,638 req/s, p99 0.7 ms | 244,644 req/s, p99 2.1 ms (4 loops) |
| Linux, 4 CPUs | 10,000 | 182,748 req/s, **1,776,962 refused**, 156 MB | 215,652 req/s, 0 refused, 72 MB, p99 74 ms |
| macOS | 64 | 181,203 req/s (all cores) | 81,726 req/s (one loop, kqueue) |
| macOS | 4,000 | 127,321 req/s, 160 MB, 2,307 threads | 74,661 req/s, 6.7 MB, 1 thread |

Read it as: Web.serve is faster for a modest number of busy connections;
the readiness lane holds ten thousand connections without refusing any, with
a third of the memory, one thread per loop, and (on one CPU) a far shorter
tail. Measured by hey_fast_web's `bench/hey-web-engines` (Linux) and `oha`
(macOS), 2026-10-13, Hey 0.99.601a, hey_poller 0.1.0.

### On Alpine (musl): preload a scalable malloc

musl's `malloc` takes one global lock and Hey allocates per value. On Linux,
1 CPU, the same Web.serve app did **15,016 req/s with musl's malloc and 98,787
with mimalloc** (`apk add mimalloc2`, `LD_PRELOAD=/usr/lib/libmimalloc.so.2`);
on 4 CPUs, 74,952 vs 406,375. This needs no code change, applies to every
hey_web app on an Alpine image, and was reported to the Hey team (allocator
choice belongs in the runtime).

## Pages embedding (`bin/pages-embed`)

Compile-time page embedding is the only zero-read-per-request page cache
`stdlib:Web` allows (handlers are resolved by name and cannot close over
boot-time state). Hand-maintaining the heredoc twin of every HTML asset
is how RecallCoach shipped a no-op edit (asset edited, heredoc served);
this generator makes the asset the only authored copy:

```sh
bin/pages-embed --pages-dir web/pages --out web/pages_generated.hey \
  --module Pages --bindings '{"app_name":"Demo"}'
```

- `*.html` assets embed verbatim; `*.html.ehy` assets render through
  stdlib Ehy at GENERATION time with `--bindings` (never at request
  time). The wrapper absolutizes the path flags and chdirs to
  `$HEY_ROOT` first, because stdlib Ehy shells out to `./bin/heyc`
  relative to the cwd (the EHY cwd quirk, tracked upstream).
- The generated module carries `NAME_page()` per asset, `names()`,
  `page(name)` (empty string for unknown names, never nil), and
  `assets_in_sync(dir)` -- the old byte-equality spec become a
  staleness check.
- THE SINGLE-QUOTE CONSTRAINT IS ENFORCED MECHANICALLY: an asset
  containing any `'` is refused with a message naming the file and
  offset, because a literal single quote deep inside a triple-quoted
  heredoc breaks `heyc build` while every interpreter lane stays green
  (RecallCoach core report heredoc-single-quote-deep-offset-selfc.md).
  CRLF assets are refused for the same byte-identity reason.
- Proof in `bin/check`: the interpreter round-trip
  (specs/pages_embed_spec.hey + tools/pages_roundtrip_driver.hey, port
  46511) and a COMPILED receipt (tools/pages_serve_receipt.hey, port
  46512) both assert served bytes == authored asset bytes.

## Resource controllers

```hey
let users_controller = {
  index: UsersController.index,
  show: UsersController.show,
  create: UsersController.create,
  update: UsersController.update,
  destroy: UsersController.destroy
}

let routes = HeyWebRouter.resources('/users', users_controller)
```

This emits index, show, create, PATCH update, PUT update, and delete routes.

## EHY views

```hey
module PagesController
  fn index(request)
    return HeyWebView.response(
      'views/pages/index.ehy',
      {title: 'Hey Web'},
      'views/layouts/application.ehy'
    )
  end
end
```

## Verify and release

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
bin/release
bin/source-zip
./bin/reproduce-prompt
```

See `docs/GETTING_STARTED.md`, `docs/ARCHITECTURE.md`, and `docs/ROADMAP.md`.

Performance: `HeyWebClient` pays a ~7 ms interpreter-delegation boundary per call on hey 0.99.390a, and `Web.serve` currently runs fastest with `workers: 1`. Measurements, the worker-count table, and a vendorable ~0.4 ms plain-HTTP transport (`examples/fast_transport.hey`) are in `docs/PERFORMANCE.md`.

## Live localhost receipt

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check-live-http
```

This starts a one-request `stdlib:Web` server and fetches its JSON endpoint through the `hey-web` client. Set `HEY_WEB_TEST_PORT` when port 39091 is unavailable.

### EHY syntax

EHY is Hey's ERB-style template format. Interpolate with `<%= expression %>`, execute control-flow statements with `<% ... %>`, and write template comments with `<%# ... %>`.

```ehy
<section>
  <h1><%= title %></h1>
  <% if signed_in %>
    <p>Welcome back, <%= name %>.</p>
  <% end %>
</section>
```

Mustache-style `{{ title }}` is not EHY and should not be used in `.ehy` Files.

## Standard package controls

This package uses `hey_packager` 0.1.2 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_web`.
