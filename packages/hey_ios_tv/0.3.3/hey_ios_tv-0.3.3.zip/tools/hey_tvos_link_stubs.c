/*
 * hey_tvos_link_stubs.c -- link-time stubs for hey_ios_tv native apps.
 *
 * The real Hey runtime (claude_01 runtime/hey_runtime.c) is compiled and
 * linked into every native tvOS app so that scene-contract-v2 apps can
 * build objects/arrays and encode JSON (the v1 string shim is gone). The
 * runtime unconditionally references OpenSSL (TLS + crypto) symbols that
 * are NOT part of the public Apple TV SDK. A tvOS public-display / card
 * app never opens a TLS socket or hashes bytes, so those code paths are
 * never reached -- but a whole .o is linked in one piece, so the linker
 * still demands every external symbol resolve.
 *
 * These stubs satisfy the linker for exactly that set. Each traps if it
 * is ever actually called, so an app that unexpectedly reaches crypto/TLS
 * fails loudly at runtime rather than linking against a silent no-op.
 *
 * Generated to match the undefined-symbol set of the tvOS-simulator build
 * of hey_runtime.c; regenerate if the runtime grows new crypto/TLS uses.
 */
#include <stdlib.h>

__attribute__((noreturn)) static void hey_tvos_tls_unavailable(void) {
  abort();
}

void *CRYPTO_memcmp() { hey_tvos_tls_unavailable(); }
void *d2i_X509_fp() { hey_tvos_tls_unavailable(); }
void *ERR_clear_error() { hey_tvos_tls_unavailable(); }
void *ERR_error_string_n() { hey_tvos_tls_unavailable(); }
void *ERR_peek_last_error() { hey_tvos_tls_unavailable(); }
void *EVP_aes_256_gcm() { hey_tvos_tls_unavailable(); }
void *EVP_CIPHER_CTX_ctrl() { hey_tvos_tls_unavailable(); }
void *EVP_CIPHER_CTX_free() { hey_tvos_tls_unavailable(); }
void *EVP_CIPHER_CTX_new() { hey_tvos_tls_unavailable(); }
void *EVP_DecryptFinal_ex() { hey_tvos_tls_unavailable(); }
void *EVP_DecryptInit_ex() { hey_tvos_tls_unavailable(); }
void *EVP_DecryptUpdate() { hey_tvos_tls_unavailable(); }
void *EVP_DigestFinal_ex() { hey_tvos_tls_unavailable(); }
void *EVP_DigestInit_ex() { hey_tvos_tls_unavailable(); }
void *EVP_DigestUpdate() { hey_tvos_tls_unavailable(); }
void *EVP_EncryptFinal_ex() { hey_tvos_tls_unavailable(); }
void *EVP_EncryptInit_ex() { hey_tvos_tls_unavailable(); }
void *EVP_EncryptUpdate() { hey_tvos_tls_unavailable(); }
void *EVP_MD_CTX_free() { hey_tvos_tls_unavailable(); }
void *EVP_MD_CTX_new() { hey_tvos_tls_unavailable(); }
void *EVP_PBE_scrypt() { hey_tvos_tls_unavailable(); }
void *EVP_sha256() { hey_tvos_tls_unavailable(); }
void *OPENSSL_cleanse() { hey_tvos_tls_unavailable(); }
void *OpenSSL_version() { hey_tvos_tls_unavailable(); }
void *RAND_bytes() { hey_tvos_tls_unavailable(); }
void *SSL_connect() { hey_tvos_tls_unavailable(); }
void *SSL_ctrl() { hey_tvos_tls_unavailable(); }
void *SSL_CTX_ctrl() { hey_tvos_tls_unavailable(); }
void *SSL_CTX_free() { hey_tvos_tls_unavailable(); }
void *SSL_CTX_get_cert_store() { hey_tvos_tls_unavailable(); }
void *SSL_CTX_load_verify_locations() { hey_tvos_tls_unavailable(); }
void *SSL_CTX_new() { hey_tvos_tls_unavailable(); }
void *SSL_CTX_set_default_verify_paths() { hey_tvos_tls_unavailable(); }
void *SSL_CTX_set_verify() { hey_tvos_tls_unavailable(); }
void *SSL_free() { hey_tvos_tls_unavailable(); }
void *SSL_get_error() { hey_tvos_tls_unavailable(); }
void *SSL_get_verify_result() { hey_tvos_tls_unavailable(); }
void *SSL_get0_param() { hey_tvos_tls_unavailable(); }
void *SSL_new() { hey_tvos_tls_unavailable(); }
void *SSL_pending() { hey_tvos_tls_unavailable(); }
void *SSL_read() { hey_tvos_tls_unavailable(); }
void *SSL_set_fd() { hey_tvos_tls_unavailable(); }
void *SSL_shutdown() { hey_tvos_tls_unavailable(); }
void *SSL_write() { hey_tvos_tls_unavailable(); }
void *TLS_client_method() { hey_tvos_tls_unavailable(); }
void *X509_free() { hey_tvos_tls_unavailable(); }
void *X509_STORE_add_cert() { hey_tvos_tls_unavailable(); }
void *X509_VERIFY_PARAM_set_hostflags() { hey_tvos_tls_unavailable(); }
void *X509_VERIFY_PARAM_set1_host() { hey_tvos_tls_unavailable(); }
void *X509_VERIFY_PARAM_set1_ip_asc() { hey_tvos_tls_unavailable(); }
