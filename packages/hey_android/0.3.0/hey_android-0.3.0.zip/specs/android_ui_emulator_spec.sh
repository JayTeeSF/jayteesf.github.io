#!/usr/bin/env bash
# The View shims on the Android 16 (API 36) arm64 emulator, headless.
#
#   1. examples/rows.hey draws its rows through JNI: the pixels of row 3 are the
#      row colour. Control: the same app with NativeActivity still holding the
#      surface has the same Views laid out, and none of them drawn.
#   2. A tap injected with `adb shell input tap` on row 3 changes the screen text,
#      seen in the screenshot, in the View tree and in a line the Hey program
#      prints. Control: a tap below the rows changes nothing.
#   3. Rotation keeps the program and still draws, and a tap still lands.
#   4. A second launch starts a fresh program that draws again.
#   5. A runtime error in the Hey loop ends the activity cleanly. Control: linked
#      without --wrap=exit, the same error kills the process.
#   6. The APK has no dex. Control: an APK with a dex added is refused.
#
# HEY_ANDROID_UI_EVIDENCE=DIR keeps the screenshots (PNG) in DIR.
#
# THE EMULATOR IS ALWAYS SHUT DOWN, on success, on failure and on interrupt, and
# the spec fails if an emulator process for the AVD is left behind.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
export HEY_ROOT
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-ui-emulator-spec.XXXXXX")
mkdir -p "$work/shots"
serial=''
evidence=${HEY_ANDROID_UI_EVIDENCE:-}
pass() { echo "PASS: $*"; }
control() { echo "PASS (control): $*"; }
bad() { echo "FAIL: $*"; failed=1; }
field() { /usr/bin/python3 -c 'import json,sys
v = json.load(open(sys.argv[1]))
for k in sys.argv[2].split("."): v = v[k] if isinstance(v, dict) else None
print(v if isinstance(v, str) else json.dumps(v))' "$1" "$2"; }
screen() { /usr/bin/python3 "$ROOT/specs/support/screen.py" "$@"; }
adbs() { "$HEY_ANDROID_ADB" -s "$serial" "$@"; }

stop_emulator() {
  if [ -n "$serial" ]; then
    adbs shell cmd window user-rotation lock 0 > /dev/null 2>&1 || true
    adbs shell cmd window user-rotation free > /dev/null 2>&1 || true
    if "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" > "$work/shutdown.log" 2>&1; then
      serial=''
    else
      cat "$work/shutdown.log"
    fi
  fi
  if pgrep -f "qemu-system.*-avd $HEY_ANDROID_AVD( |$)" > /dev/null 2>&1; then
    bad "an emulator process for $HEY_ANDROID_AVD is still running after shutdown"
    return 1
  fi
  return 0
}
on_exit() {
  status=$?
  [ -n "$serial" ] && { stop_emulator || status=1; }
  if [ -n "$evidence" ]; then
    mkdir -p "$evidence" && cp "$work"/shots/*.png "$evidence"/ 2> /dev/null || true
  fi
  rm -rf "$work"
  exit "$status"
}
trap on_exit EXIT
trap 'exit 130' INT TERM

# ---- helpers ------------------------------------------------------------------------------------
app() { # NAME SOURCE PACKAGE [VAR=VALUE...]: build, install and launch in --ui mode
  local app_name=$1 app_source=$2 app_package=$3
  shift 3
  env "$@" "$ROOT/tools/hey-android-app.sh" --source "$ROOT/examples/$app_source.hey" --out "$work/android/$app_name" \
    --package-id "$app_package" --label "Hey $app_name" --device "$serial" --launch --ui > "$work/$app_name.log" 2>&1
}
shot() { # NAME: a raw screenshot, a PNG and the View tree as uiautomator sees it
  adbs exec-out screencap > "$work/shots/$1.raw"
  adbs exec-out screencap -p > "$work/shots/$1.png"
  adbs shell rm -f /sdcard/hey-ui.xml > /dev/null 2>&1
  adbs shell uiautomator dump /sdcard/hey-ui.xml > /dev/null 2>&1
  adbs exec-out cat /sdcard/hey-ui.xml > "$work/shots/$1.xml" 2> /dev/null
}
wait_log() { # TAG PATTERN SECONDS: succeeds when a logcat line under TAG matches PATTERN
  for _ in $(seq 1 "$3"); do
    adbs logcat -d -v tag -s "$1:*" 2> /dev/null | grep -q -- "$2" && return 0
    /bin/sleep 1
  done
  return 1
}
log_has() { adbs logcat -d -v tag -s "$1:*" 2> /dev/null | grep -q -- "$2"; }
share() { # SHOT TEXT RRGGBB: the percentage of the text's View rectangle in that colour
  bounds=$(screen bounds "$work/shots/$1.xml" "$2" 2> /dev/null) || { echo 0; return; }
  read -r x0 y0 x1 y1 <<< "$bounds"
  total=$(((x1 - x0) * (y1 - y0)))
  [ "$total" -gt 0 ] || { echo 0; return; }
  echo $(($(screen count "$work/shots/$1.raw" "$x0" "$y0" "$x1" "$y1" "$3") * 100 / total))
}
centre() { # SHOT TEXT: "x y" at the middle of the text's View
  read -r x0 y0 x1 y1 <<< "$(screen bounds "$work/shots/$1.xml" "$2")"
  echo "$(((x0 + x1) / 2)) $(((y0 + y1) / 2))"
}
gone() { # PACKAGE SECONDS: succeeds when no process of the package remains
  for _ in $(seq 1 "$2"); do
    adbs shell pidof "$1" > /dev/null 2>&1 || return 0
    /bin/sleep 1
  done
  return 1
}
BLUE=1E88E5  # odd rows (native/ui/hey_android_ui.c)
AMBER=FFC107 # even rows; the status row is row 0

# ---- boot ---------------------------------------------------------------------------------------
"$ROOT/tools/hey-android-emulator.sh" create-avd > "$work/avd.log" 2>&1 || { bad "could not create the AVD: $(cat "$work/avd.log")"; exit 1; }
if ! boot_line=$("$ROOT/tools/hey-android-emulator.sh" boot 2> "$work/boot.err"); then
  bad "the emulator did not boot: $(tail -5 "$work/boot.err")"
  exit 1
fi
serial=$(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^serial=//p')
pass "booted AVD $HEY_ANDROID_AVD headless as $serial"
adbs shell settings put system accelerometer_rotation 0 > /dev/null 2>&1
adbs shell settings put system user_rotation 0 > /dev/null 2>&1
adbs shell svc power stayon true > /dev/null 2>&1 || true

# ---- 1. Views drew, and the control -------------------------------------------------------------
if app surface-taken rows com.jayteesf.hey.rows.control HEY_ANDROID_NEGATIVE_CONTROL=surface-taken; then
  /bin/sleep 3
  shot surface-taken
  taken_bounds=$(screen bounds "$work/shots/surface-taken.xml" 'Row 3' 2> /dev/null || true)
  taken_share=$(share surface-taken 'Row 3' "$BLUE")
  if [ -n "$taken_bounds" ] && [ "$taken_share" -lt 5 ]; then
    control "with NativeActivity still holding the surface, uiautomator lists the 'Row 3' View at [$taken_bounds], but ${taken_share}% of it is drawn blue: the pixel check tells laid out from drawn"
  else
    bad "(control) surface-taken: bounds '$taken_bounds', ${taken_share}% blue"
  fi
else
  bad "(control) the surface-taken build did not commit a screen: $(tail -5 "$work/surface-taken.log")"
fi
adbs shell am force-stop com.jayteesf.hey.rows.control > /dev/null 2>&1

package=com.jayteesf.hey.rows
if app rows rows "$package"; then
  r=$work/android/rows/receipt.json
  pass "rows installs and commits its first screen on API $(field "$r" device.api): $(field "$r" ui.views_on_screen) views on screen, read back through JNI"
  [ "$(field "$r" ui.views_on_screen)" = 5 ] || bad "rows reported $(field "$r" ui.views_on_screen) views, not 5"
else
  bad "rows did not commit a screen: $(tail -8 "$work/rows.log")"
  exit 1
fi
first_pid=$(adbs shell pidof "$package" | tr -d '\r')
/bin/sleep 3
shot start
row3=$(share start 'Row 3' "$BLUE")
status_share=$(share start 'Tap a row' "$AMBER")
if [ "$row3" -ge 70 ] && [ "$status_share" -ge 70 ]; then
  pass "Views drew: 'Row 3' at [$(screen bounds "$work/shots/start.xml" 'Row 3')] is ${row3}% blue and the status row 'Tap a row' is ${status_share}% amber"
else
  bad "Views did not draw: 'Row 3' ${row3}% blue, 'Tap a row' ${status_share}% amber"
fi

# ---- 2. taps ------------------------------------------------------------------------------------
read -r _ _ _ last_bottom <<< "$(screen bounds "$work/shots/start.xml" 'Row 4')"
read -r width height <<< "$(screen size "$work/shots/start.raw" | tr x ' ')"
read -r sx0 sy0 sx1 sy1 <<< "$(screen bounds "$work/shots/start.xml" 'Tap a row')"
miss_y=$(((last_bottom + height) / 2))
adbs shell input tap $((width / 2)) "$miss_y"
if wait_log hey.ui 'on no row' 10; then
  /bin/sleep 2
  shot missed
  changed=$(screen differ "$work/shots/start.raw" "$work/shots/missed.raw" "$sx0" "$sy0" "$sx1" "$sy1")
  if ! log_has hey.out 'rows: tapped' && [ "$changed" = 0 ]; then
    control "a tap at ($((width / 2)), $miss_y), below the rows, is hit-tested to no row: no event reaches Hey and 0 pixels of the status row change"
  else
    bad "(control) the tap below the rows changed $changed status pixels or reached Hey"
  fi
else
  bad '(control) the tap below the rows was not seen by the input queue'
fi

read -r tx ty <<< "$(centre start 'Row 3')"
adbs shell input tap "$tx" "$ty"
if wait_log hey.out 'rows: tapped row-3, showing: Row 3 was tapped' 15; then
  /bin/sleep 2
  shot tapped
  changed=$(screen differ "$work/shots/missed.raw" "$work/shots/tapped.raw" "$sx0" "$sy0" "$sx1" "$sy1")
  tapped_bounds=$(screen bounds "$work/shots/tapped.xml" 'Row 3 was tapped' 2> /dev/null || true)
  if [ -n "$tapped_bounds" ] && [ "$changed" -gt 100 ] && log_has hey.ui 'on row-3'; then
    pass "a tap at ($tx, $ty) on row 3 reaches Hey ('rows: tapped row-3, showing: Row 3 was tapped' in logcat), the View tree now shows 'Row 3 was tapped' at [$tapped_bounds], and $changed pixels of the status row changed"
  else
    bad "after the tap: bounds '$tapped_bounds', $changed status pixels changed"
  fi
else
  bad 'the tap on row 3 did not reach the Hey program'
fi

# ---- 3. rotation --------------------------------------------------------------------------------
portrait=$(screen size "$work/shots/tapped.raw")
# `settings put system user_rotation 1` written right after boot was measured not to
# rotate this AVD, so the spec uses the window manager's own command and waits until
# the display reports the new orientation. `adb emu rotate` was measured to do nothing.
adbs shell cmd window user-rotation lock 1 > /dev/null 2>&1
rotated=false
for _ in $(seq 1 15); do
  adbs shell dumpsys display 2> /dev/null | grep -q 'mCurrentOrientation=1' && { rotated=true; break; }
  /bin/sleep 1
done
[ "$rotated" = true ] || bad 'the display did not report orientation 1 within 15 seconds of cmd window user-rotation lock 1'
/bin/sleep 3
shot landscape
landscape=$(screen size "$work/shots/landscape.raw")
read -r lw lh <<< "$(printf '%s' "$landscape" | tr x ' ')"
row3=$(share landscape 'Row 3' "$BLUE")
if [ "$lw" -gt "$lh" ] && [ "$row3" -ge 70 ] && screen bounds "$work/shots/landscape.xml" 'Row 3 was tapped' > /dev/null 2>&1; then
  pass "rotated to $landscape, the same program still draws: 'Row 3' at [$(screen bounds "$work/shots/landscape.xml" 'Row 3')] is ${row3}% blue, and 'Row 3 was tapped' is still shown"
else
  bad "after rotation ($landscape): 'Row 3' ${row3}% blue"
fi
read -r pw ph <<< "$(printf '%s' "$portrait" | tr x ' ')"
if [ "$pw" -lt "$ph" ]; then
  control "the orientation check sees the difference: before rotation the screen was $portrait"
else
  bad "(control) the portrait screen was already $portrait"
fi
read -r tx ty <<< "$(centre landscape 'Row 1')"
adbs shell input tap "$tx" "$ty"
if wait_log hey.out 'rows: tapped row-1, showing: Row 1 was tapped' 15; then
  pass "in landscape a tap at ($tx, $ty) lands on row 1, hit-tested against the rotated layout"
else
  bad 'in landscape the tap on row 1 did not reach the Hey program'
fi
if [ "$(adbs logcat -d -v tag -s 'hey.app:*' | grep -c 'starting the Hey program')" = 1 ]; then
  pass 'rotation did not restart the program (one start in logcat)'
else
  bad 'rotation restarted the Hey program'
fi
adbs shell cmd window user-rotation lock 0 > /dev/null 2>&1
/bin/sleep 3

# ---- 4. a second launch -------------------------------------------------------------------------
adbs shell am force-stop "$package"
gone "$package" 10 || bad 'force-stop left the rows process running'
adbs logcat -c
adbs shell am start -W -n "$package/android.app.NativeActivity" > "$work/relaunch.txt" 2>&1
if wait_log hey.ui 'commit: ' 30; then
  /bin/sleep 3
  shot relaunch
  second_pid=$(adbs shell pidof "$package" | tr -d '\r')
  row3=$(share relaunch 'Row 3' "$BLUE")
  if [ "$row3" -ge 70 ] && screen bounds "$work/shots/relaunch.xml" 'Tap a row' > /dev/null 2>&1 && [ "$second_pid" != "$first_pid" ]; then
    pass "launched again, a fresh process (pid $first_pid, then $second_pid) and a fresh program draw 'Tap a row' again, with 'Row 3' ${row3}% blue"
  else
    bad "the second launch: 'Row 3' ${row3}% blue, pids $first_pid and $second_pid"
  fi
else
  bad 'the second launch committed no screen'
fi
adbs shell am force-stop "$package"

# ---- 5. a runtime error in the loop -------------------------------------------------------------
crash_patterns='FATAL EXCEPTION|Fatal signal [0-9]+|AndroidRuntime|am_crash|Application Error|ANR in|Tombstone written|Abort message'
error_run() { # NAME [VAR=VALUE...]: launch rows_error, tap row 3, wait for the process to go
  name=$1
  shift
  pkg=com.jayteesf.hey.rowserror
  app "$name" rows_error "$pkg" "$@" || return 1
  /bin/sleep 3
  shot "$name"
  read -r ex ey <<< "$(centre "$name" 'Row 3')"
  adbs shell input tap "$ex" "$ey"
  gone "$pkg" 20
  adbs logcat -d -v threadtime > "$work/$name-logcat.txt"
  adbs logcat -d -v tag -s 'hey.app:*' 'hey.out:*' 'hey.err:*' > "$work/$name-hey.txt"
}
if error_run rows_error; then
  crashes=$(grep -E "$crash_patterns" "$work/rows_error-logcat.txt" | grep -c 'rowserror' || true)
  dialogs=$(adbs shell dumpsys window 2> /dev/null | grep -cE '(Application Error|Application Not Responding): com.jayteesf.hey.rowserror' || true)
  if grep -q 'rows_error: tapped row-3, failing now' "$work/rows_error-hey.txt" &&
     grep -q 'hey error: the tap handler stops here on purpose' "$work/rows_error-hey.txt" &&
     grep -q 'hey program exited with status 70' "$work/rows_error-hey.txt" &&
     grep -q 'finishing the activity' "$work/rows_error-hey.txt" &&
     grep -q 'activity destroyed' "$work/rows_error-hey.txt" && [ "$crashes" = 0 ] && [ "$dialogs" = 0 ]; then
    pass "a runtime error in the Hey loop, on the tap: the message is in logcat, exit(70) finishes the activity, it is destroyed, the process is gone, 0 crash markers, no crash dialog"
  else
    bad "rows_error did not end cleanly: $crashes crash markers, $dialogs dialogs; $(tail -6 "$work/rows_error-hey.txt")"
  fi
else
  bad "rows_error did not end after the tap: $(tail -5 "$work/rows_error.log")"
fi
if error_run rows_error-unwrapped HEY_ANDROID_NEGATIVE_CONTROL=unwrapped-exit; then
  if grep -q 'hey error: the tap handler stops here on purpose' "$work/rows_error-unwrapped-hey.txt" &&
     ! grep -q 'hey program exited' "$work/rows_error-unwrapped-hey.txt" && ! grep -q 'finishing the activity' "$work/rows_error-unwrapped-hey.txt"; then
    control 'linked without --wrap=exit, the same error kills the process: no end of program logged and no activity finished'
  else
    bad "(control) the unwrapped-exit build still ended cleanly: $(tail -4 "$work/rows_error-unwrapped-hey.txt")"
  fi
else
  bad "(control) the unwrapped-exit rows_error did not end after the tap: $(tail -5 "$work/rows_error-unwrapped.log")"
fi

# ---- 6. the APK has no dex ----------------------------------------------------------------------
apk=$work/android/rows/app.apk
if line=$("$ROOT/tools/hey-android-verify.sh" apk "$apk" "$package" 2>&1) && printf '%s' "$line" | grep -q 'has_code=false dex=0'; then
  pass "the rows APK has hasCode=false, no dex and a 16 KB aligned library ($(field "$work/android/rows/receipt.json" shared_library.load_alignment)): $(printf '%s' "$line" | cut -c1-110)"
else
  bad "the rows APK check: $line"
fi
cp "$apk" "$work/with-dex.apk"
printf 'dex\n035\0' > "$work/classes.dex"
(cd "$work" && /usr/bin/zip -q -X with-dex.apk classes.dex)
"$HEY_ANDROID_BUILD_TOOLS_DIR/zipalign" -P 16 -f 4 "$work/with-dex.apk" "$work/with-dex-aligned.apk" > /dev/null
java_home=$(hey_android_java_home)
env JAVA_HOME="$java_home" PATH="$java_home/bin:/usr/bin:/bin" "$HEY_ANDROID_BUILD_TOOLS_DIR/apksigner" sign \
  --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android \
  --v4-signing-enabled false --out "$work/with-dex-signed.apk" "$work/with-dex-aligned.apk" > /dev/null 2>&1
if out=$("$ROOT/tools/hey-android-verify.sh" apk "$work/with-dex-signed.apk" "$package" 2>&1); then
  bad '(control) the rows APK with a classes.dex added was accepted'
else
  control "the rows APK with a classes.dex added is refused: $(printf '%s\n' "$out" | grep -m1 'dex' | cut -c1-120)"
fi
sources=$(cd "$ROOT" && find . -path ./dist -prune -o \( -name '*.java' -o -name '*.kt' -o -name '*.kts' \) -print)
touch "$work/Listener.java"
planted=$(cd "$work" && find . \( -name '*.java' -o -name '*.kt' -o -name '*.kts' \) -print)
if [ -z "$sources" ] && [ -n "$planted" ]; then
  pass 'the package holds no Java or Kotlin source; control: the same search finds a planted Listener.java'
else
  bad "Java or Kotlin source search: package '$sources', planted '$planted'"
fi

# ---- shut down ----------------------------------------------------------------------------------
if stop_emulator; then
  pass "the emulator was shut down and no emulator process for $HEY_ANDROID_AVD remains"
fi
exit $failed
