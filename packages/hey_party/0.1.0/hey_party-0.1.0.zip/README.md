# hey_party

Authoritative party rooms, mobile controllers, lobbies, and deterministic multiplayer games.

This is an independently versioned third-party Hey package. It is not part
of Hey core or the standard library.

## Package boundary

See `docs/DESIGN.md`. The package consumes current published dependencies
from `https://www.jayteesf.com/packages/` and delegates release/source ZIP/
publication controls to `hey_packager`.

## Development

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
```

## Release and publish

```sh
bin/release
bin/source-zip
bin/publish --no-commit
```

Existing immutable versions must never be replaced.

## Build and release tooling

`hey_packager` is invoked as local build/release tooling through `bin/release`,
`bin/package-zip`, `bin/source-zip`, and `bin/publish`. It is deliberately not a
runtime package dependency and is therefore not written into application locks.
