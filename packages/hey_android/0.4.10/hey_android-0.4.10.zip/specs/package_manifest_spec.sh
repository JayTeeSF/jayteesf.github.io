#!/usr/bin/env bash
# The package manifest must carry every renderer source needed by the installed
# build tool. Source-root checks cannot prove this because javac can see files
# that an immutable package archive omits.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"

ruby - "$ROOT" <<'RB'
require 'json'
root = ARGV[0]
declared = JSON.parse(File.read(File.join(root, 'hey-package.json'))).fetch('files')
renderer = Dir.glob('renderer/**/*', File::FNM_DOTMATCH, base: root).select { |p| File.file?(File.join(root, p)) }.uniq
missing = (renderer - declared).sort
abort('FAIL: renderer files omitted from hey-package.json: ' + missing.join(', ')) unless missing.empty?
puts "PASS: hey-package.json carries all #{renderer.length} renderer files used by source-root builds"
RB
