#define _POSIX_C_SOURCE 200809L
/* F_FULLFSYNC is a Darwin extension and strict _POSIX_C_SOURCE hides it. It is
   the only barrier on this platform that actually flushes the drive cache, so
   the durability promise depends on it being visible here. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#endif

#include "hey_durable_log.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define HDL_SEGMENT_HEADER_SIZE 64u
#define HDL_FRAME_HEADER_SIZE 48u
#define HDL_COMMIT_PAYLOAD_SIZE 24u
#define HDL_FORMAT_VERSION 1u
#define HDL_FRAME_MAGIC 0x464c4448u
#define HDL_FRAME_DATA 1u
#define HDL_FRAME_COMMIT 2u
#define HDL_DEFAULT_MAX_RECORD_BYTES (16u * 1024u * 1024u)
#define HDL_DEFAULT_MAX_BATCH_RECORDS 4096u
#define HDL_DEFAULT_QUEUE_CAPACITY 4096u
#define HDL_DEFAULT_BROKER_BATCH_RECORDS 64u
#define HDL_DEFAULT_BATCH_WINDOW_US 250u

static const unsigned char HDL_SEGMENT_MAGIC[8] = {'H', 'D', 'L', 'G', 'v', '0', '0', '1'};

typedef struct {
  uint64_t offset;
  uint64_t sequence;
  uint64_t batch_id;
  uint64_t stream_id;
  uint32_t payload_length;
  uint32_t frame_crc;
} hdl_pending_frame;

struct hdl_log {
  int fd;
  char *path;
  uint64_t append_offset;
  uint64_t next_sequence;
  uint64_t next_batch_id;
  uint32_t previous_frame_crc;
  uint32_t max_record_bytes;
  uint32_t max_batch_records;
  /* Set once a durability barrier has failed on this descriptor. From that
     moment the handle cannot tell the truth about what is durable, so it stops
     acknowledging. Only reopening -- which re-runs recovery over the bytes on
     disk -- restores the knowledge the failed barrier destroyed. */
  int poisoned;
  pthread_mutex_t mutex;
};

struct hdl_cursor {
  int fd;
  uint64_t offset;
  uint64_t committed_offset;
  uint32_t max_record_bytes;
  unsigned char *payload;
};

typedef struct hdl_request hdl_request;
struct hdl_request {
  hdl_record record;
  hdl_receipt receipt;
  hdl_status status;
  int done;
  pthread_cond_t completed;
  hdl_request *next;
};

struct hdl_broker {
  hdl_log *log;
  pthread_t writer;
  pthread_mutex_t mutex;
  pthread_cond_t not_empty;
  pthread_cond_t not_full;
  hdl_request *head;
  hdl_request *tail;
  uint32_t queued;
  uint32_t queue_capacity;
  uint32_t max_batch_records;
  uint32_t batch_window_microseconds;
  int stopping;
  hdl_broker_stats stats;
};

typedef struct {
  uint64_t committed_offset;
  uint64_t last_sequence;
  uint64_t last_batch_id;
  uint32_t previous_frame_crc;
} hdl_recovery;

#ifdef HDL_ENABLE_TEST_HOOKS
static _Atomic int hdl_fail_sync = 0;
static _Atomic long long hdl_write_budget = -1;
static _Atomic long long hdl_kill_write_budget = -1;
static _Atomic int hdl_kill_before_sync = 0;
static _Atomic int hdl_kill_after_sync = 0;

void hdl_test_fail_next_sync(void) {
  atomic_store(&hdl_fail_sync, 1);
}

void hdl_test_fail_write_after_bytes(long long bytes) {
  atomic_store(&hdl_write_budget, bytes);
}

void hdl_test_kill_during_write_after_bytes(long long bytes) {
  atomic_store(&hdl_kill_write_budget, bytes);
}

void hdl_test_kill_before_next_sync(void) {
  atomic_store(&hdl_kill_before_sync, 1);
}

void hdl_test_kill_after_next_sync(void) {
  atomic_store(&hdl_kill_after_sync, 1);
}

void hdl_test_clear_failures(void) {
  atomic_store(&hdl_fail_sync, 0);
  atomic_store(&hdl_write_budget, -1);
  atomic_store(&hdl_kill_write_budget, -1);
  atomic_store(&hdl_kill_before_sync, 0);
  atomic_store(&hdl_kill_after_sync, 0);
}
#endif

const char *hdl_sync_barrier_name(void) {
#if defined(__APPLE__)
  return "F_FULLFSYNC";
#else
  return "fdatasync";
#endif
}

/* The durability barrier. This function IS the acknowledgement boundary: every
   promise this package makes reduces to "we returned only after this succeeded".
 *
 * On Darwin, fdatasync/fsync are NOT that boundary. fsync(2) on this platform
 * says so directly: after it returns, "the drive itself may not physically
 * write the data to the platters for quite some time", on power loss "the
 * application may find that only some or none of their data was written", and
 * "this is not a theoretical edge case". Acknowledging there would mean
 * acknowledging the drive's volatile cache -- the same defect as acknowledging
 * RAM, one layer further down, and undetectable until the power actually fails.
 * F_FULLFSYNC asks the drive to flush that cache, which is the guarantee we
 * claim, so it is what we issue.
 *
 * There is no silent fallback. A filesystem that refuses F_FULLFSYNC returns
 * the error to the caller and the batch is NOT acknowledged, because quietly
 * degrading to a weaker barrier would leave the promise stated and unmet --
 * exactly the failure this package exists to prevent. */
static int sync_data(int fd) {
#ifdef HDL_ENABLE_TEST_HOOKS
  if (atomic_exchange(&hdl_kill_before_sync, 0) != 0) raise(SIGKILL);
  if (atomic_exchange(&hdl_fail_sync, 0) != 0) {
    errno = EIO;
    return -1;
  }
#endif
#if defined(__APPLE__)
  int result = fcntl(fd, F_FULLFSYNC, 0);
#else
  int result = fdatasync(fd);
#endif
#ifdef HDL_ENABLE_TEST_HOOKS
  if (result == 0 && atomic_exchange(&hdl_kill_after_sync, 0) != 0) raise(SIGKILL);
#endif
  return result;
}

static ssize_t write_bytes(int fd, const unsigned char *bytes, size_t length) {
#ifdef HDL_ENABLE_TEST_HOOKS
  long long budget = atomic_load(&hdl_write_budget);
  long long kill_budget = atomic_load(&hdl_kill_write_budget);
  if (budget == 0) {
    errno = ENOSPC;
    return -1;
  }
  if (budget > 0 && (unsigned long long)budget < length) length = (size_t)budget;
  if (kill_budget == 0) raise(SIGKILL);
  if (kill_budget > 0 && (unsigned long long)kill_budget < length) length = (size_t)kill_budget;
#endif
  ssize_t result = write(fd, bytes, length);
#ifdef HDL_ENABLE_TEST_HOOKS
  if (result > 0 && budget > 0) atomic_fetch_sub(&hdl_write_budget, result);
  if (result > 0 && kill_budget > 0) atomic_fetch_sub(&hdl_kill_write_budget, result);
#endif
  return result;
}

static void put_u16(unsigned char *out, uint16_t value) {
  out[0] = (unsigned char)value;
  out[1] = (unsigned char)(value >> 8);
}

static void put_u32(unsigned char *out, uint32_t value) {
  for (int index = 0; index < 4; index++) out[index] = (unsigned char)(value >> (index * 8));
}

static void put_u64(unsigned char *out, uint64_t value) {
  for (int index = 0; index < 8; index++) out[index] = (unsigned char)(value >> (index * 8));
}

static uint16_t get_u16(const unsigned char *in) {
  return (uint16_t)((uint16_t)in[0] | ((uint16_t)in[1] << 8));
}

static uint32_t get_u32(const unsigned char *in) {
  uint32_t value = 0;
  for (int index = 0; index < 4; index++) value |= (uint32_t)in[index] << (index * 8);
  return value;
}

static uint64_t get_u64(const unsigned char *in) {
  uint64_t value = 0;
  for (int index = 0; index < 8; index++) value |= (uint64_t)in[index] << (index * 8);
  return value;
}

static uint32_t crc32_continue(uint32_t state, const unsigned char *bytes, size_t length) {
  uint32_t crc = state;
  for (size_t index = 0; index < length; index++) {
    crc ^= bytes[index];
    for (int bit = 0; bit < 8; bit++) crc = (crc >> 1) ^ (0xedb88320u & (uint32_t)-(int32_t)(crc & 1u));
  }
  return crc;
}

static uint32_t crc32_parts(const unsigned char *first,
                            size_t first_length,
                            const unsigned char *second,
                            size_t second_length) {
  uint32_t crc = crc32_continue(0xffffffffu, first, first_length);
  crc = crc32_continue(crc, second, second_length);
  return ~crc;
}

static int write_all(int fd, const unsigned char *bytes, size_t length) {
  size_t offset = 0;
  while (offset < length) {
    ssize_t written = write_bytes(fd, bytes + offset, length - offset);
    if (written < 0 && errno == EINTR) continue;
    if (written <= 0) return -1;
    offset += (size_t)written;
  }
  return 0;
}

static int pread_all(int fd, unsigned char *bytes, size_t length, uint64_t offset) {
  size_t consumed = 0;
  while (consumed < length) {
    ssize_t read_count = pread(fd, bytes + consumed, length - consumed, (off_t)(offset + consumed));
    if (read_count < 0 && errno == EINTR) continue;
    if (read_count <= 0) return -1;
    consumed += (size_t)read_count;
  }
  return 0;
}

static uint64_t unix_nanoseconds(void) {
  struct timespec now;
  if (clock_gettime(CLOCK_REALTIME, &now) != 0) return 0;
  return (uint64_t)now.tv_sec * 1000000000u + (uint64_t)now.tv_nsec;
}

static struct timespec realtime_after_microseconds(uint32_t microseconds) {
  struct timespec deadline;
  (void)clock_gettime(CLOCK_REALTIME, &deadline);
  deadline.tv_nsec += (long)microseconds * 1000L;
  deadline.tv_sec += deadline.tv_nsec / 1000000000L;
  deadline.tv_nsec %= 1000000000L;
  return deadline;
}

static int sync_parent_directory(const char *path) {
  const char *slash = strrchr(path, '/');
  char *directory = NULL;
  if (slash == NULL) {
    directory = strdup(".");
  } else if (slash == path) {
    directory = strdup("/");
  } else {
    size_t length = (size_t)(slash - path);
    directory = malloc(length + 1);
    if (directory != NULL) {
      memcpy(directory, path, length);
      directory[length] = '\0';
    }
  }
  if (directory == NULL) return -1;
  int fd = open(directory, O_RDONLY | O_CLOEXEC | O_DIRECTORY);
  free(directory);
  if (fd < 0) return -1;
  int result = fsync(fd);
  int saved_errno = errno;
  close(fd);
  errno = saved_errno;
  return result;
}

static hdl_status initialize_segment(int fd, const char *path, uint64_t generation) {
  unsigned char header[HDL_SEGMENT_HEADER_SIZE];
  memset(header, 0, sizeof(header));
  memcpy(header, HDL_SEGMENT_MAGIC, sizeof(HDL_SEGMENT_MAGIC));
  put_u32(header + 8, HDL_SEGMENT_HEADER_SIZE);
  put_u32(header + 12, HDL_FORMAT_VERSION);
  put_u64(header + 16, generation);
  put_u64(header + 24, unix_nanoseconds());
  put_u32(header + 60, crc32_parts(header, 60, NULL, 0));
  if (write_all(fd, header, sizeof(header)) != 0) return HDL_IO;
  if (sync_data(fd) != 0) return HDL_IO;
  if (sync_parent_directory(path) != 0) return HDL_IO;
  return HDL_OK;
}

static hdl_status validate_segment_header(int fd, uint64_t file_size) {
  if (file_size < HDL_SEGMENT_HEADER_SIZE) return HDL_CORRUPTION;
  unsigned char header[HDL_SEGMENT_HEADER_SIZE];
  if (pread_all(fd, header, sizeof(header), 0) != 0) return HDL_IO;
  if (memcmp(header, HDL_SEGMENT_MAGIC, sizeof(HDL_SEGMENT_MAGIC)) != 0 ||
      get_u32(header + 8) != HDL_SEGMENT_HEADER_SIZE ||
      get_u32(header + 12) != HDL_FORMAT_VERSION ||
      get_u32(header + 60) != crc32_parts(header, 60, NULL, 0)) {
    return HDL_CORRUPTION;
  }
  return HDL_OK;
}

static uint32_t batch_crc_add(uint32_t state, uint32_t frame_crc) {
  unsigned char value[4];
  put_u32(value, frame_crc);
  return crc32_continue(state, value, sizeof(value));
}

static void encode_frame_header(unsigned char out[HDL_FRAME_HEADER_SIZE],
                                uint16_t type,
                                uint32_t payload_length,
                                uint64_t sequence,
                                uint64_t batch_id,
                                uint64_t stream_id,
                                uint32_t previous_frame_crc) {
  memset(out, 0, HDL_FRAME_HEADER_SIZE);
  put_u32(out, HDL_FRAME_MAGIC);
  put_u16(out + 4, HDL_FORMAT_VERSION);
  put_u16(out + 6, type);
  put_u32(out + 8, HDL_FRAME_HEADER_SIZE + payload_length);
  put_u32(out + 12, payload_length);
  put_u64(out + 16, sequence);
  put_u64(out + 24, batch_id);
  put_u64(out + 32, stream_id);
  put_u32(out + 40, previous_frame_crc);
}

static uint32_t finish_frame_header(unsigned char header[HDL_FRAME_HEADER_SIZE],
                                    const unsigned char *payload,
                                    uint32_t payload_length) {
  put_u32(header + 44, 0);
  uint32_t crc = crc32_parts(header, HDL_FRAME_HEADER_SIZE, payload, payload_length);
  put_u32(header + 44, crc);
  return crc;
}

static hdl_status validate_frame(int fd,
                                 uint64_t offset,
                                 uint64_t file_size,
                                 uint32_t max_record_bytes,
                                 unsigned char header[HDL_FRAME_HEADER_SIZE],
                                 unsigned char **payload_out,
                                 int *short_tail) {
  *payload_out = NULL;
  *short_tail = 0;
  if (file_size - offset < HDL_FRAME_HEADER_SIZE) {
    *short_tail = 1;
    return HDL_OK;
  }
  if (pread_all(fd, header, HDL_FRAME_HEADER_SIZE, offset) != 0) return HDL_IO;
  uint16_t type = get_u16(header + 6);
  uint32_t payload_length = get_u32(header + 12);
  uint32_t frame_length = get_u32(header + 8);
  if (get_u32(header) != HDL_FRAME_MAGIC ||
      get_u16(header + 4) != HDL_FORMAT_VERSION ||
      (type != HDL_FRAME_DATA && type != HDL_FRAME_COMMIT) ||
      frame_length != HDL_FRAME_HEADER_SIZE + payload_length ||
      (type == HDL_FRAME_DATA && payload_length > max_record_bytes) ||
      (type == HDL_FRAME_COMMIT && payload_length != HDL_COMMIT_PAYLOAD_SIZE)) {
    return HDL_CORRUPTION;
  }
  if ((uint64_t)frame_length > file_size - offset) {
    *short_tail = 1;
    return HDL_OK;
  }
  unsigned char *payload = NULL;
  if (payload_length > 0) {
    payload = malloc(payload_length);
    if (payload == NULL) return HDL_NOMEM;
    if (pread_all(fd, payload, payload_length, offset + HDL_FRAME_HEADER_SIZE) != 0) {
      free(payload);
      return HDL_IO;
    }
  }
  uint32_t stored_crc = get_u32(header + 44);
  put_u32(header + 44, 0);
  uint32_t actual_crc = crc32_parts(header, HDL_FRAME_HEADER_SIZE, payload, payload_length);
  put_u32(header + 44, stored_crc);
  if (stored_crc != actual_crc) {
    free(payload);
    return HDL_CORRUPTION;
  }
  *payload_out = payload;
  return HDL_OK;
}

static hdl_status scan_file(hdl_log *log,
                            hdl_scan_callback callback,
                            void *context,
                            int repair_tail,
                            hdl_recovery *recovery) {
  struct stat metadata;
  if (fstat(log->fd, &metadata) != 0 || metadata.st_size < 0) return HDL_IO;
  uint64_t file_size = (uint64_t)metadata.st_size;
  hdl_status status = validate_segment_header(log->fd, file_size);
  if (status != HDL_OK) return status;

  uint64_t offset = HDL_SEGMENT_HEADER_SIZE;
  uint64_t committed_offset = HDL_SEGMENT_HEADER_SIZE;
  uint64_t last_sequence = 0;
  uint64_t last_batch_id = 0;
  uint32_t previous_crc = 0;
  uint32_t committed_previous_crc = 0;
  hdl_pending_frame *pending = NULL;
  size_t pending_count = 0;
  size_t pending_capacity = 0;
  uint64_t pending_batch_id = 0;
  uint32_t batch_crc_state = 0xffffffffu;
  int tail_incomplete = 0;

  while (offset < file_size) {
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    unsigned char *payload = NULL;
    int short_tail = 0;
    status = validate_frame(log->fd, offset, file_size, log->max_record_bytes,
                            header, &payload, &short_tail);
    if (status != HDL_OK) break;
    if (short_tail) {
      tail_incomplete = 1;
      break;
    }
    uint16_t type = get_u16(header + 6);
    uint32_t frame_length = get_u32(header + 8);
    uint32_t frame_crc = get_u32(header + 44);
    uint64_t sequence = get_u64(header + 16);
    uint64_t batch_id = get_u64(header + 24);
    if (get_u32(header + 40) != previous_crc) {
      free(payload);
      status = HDL_CORRUPTION;
      break;
    }

    if (type == HDL_FRAME_DATA) {
      if (batch_id == 0 || sequence != last_sequence + pending_count + 1 ||
          (pending_count > 0 && batch_id != pending_batch_id)) {
        free(payload);
        status = HDL_CORRUPTION;
        break;
      }
      if (pending_count == 0) pending_batch_id = batch_id;
      if (pending_count == pending_capacity) {
        size_t next_capacity = pending_capacity == 0 ? 16 : pending_capacity * 2;
        if (next_capacity > log->max_batch_records) next_capacity = log->max_batch_records;
        if (next_capacity <= pending_capacity) {
          free(payload);
          status = HDL_LIMIT;
          break;
        }
        hdl_pending_frame *next = realloc(pending, next_capacity * sizeof(*next));
        if (next == NULL) {
          free(payload);
          status = HDL_NOMEM;
          break;
        }
        pending = next;
        pending_capacity = next_capacity;
      }
      pending[pending_count++] = (hdl_pending_frame){
        offset, sequence, batch_id, get_u64(header + 32), get_u32(header + 12), frame_crc
      };
      batch_crc_state = batch_crc_add(batch_crc_state, frame_crc);
    } else {
      uint64_t first = get_u64(payload);
      uint64_t last = get_u64(payload + 8);
      uint32_t count = get_u32(payload + 16);
      uint32_t batch_crc = get_u32(payload + 20);
      uint32_t expected_batch_crc = ~batch_crc_state;
      if (pending_count == 0 || batch_id != pending_batch_id ||
          count != pending_count || first != pending[0].sequence ||
          last != pending[pending_count - 1].sequence || sequence != last ||
          batch_crc != expected_batch_crc || batch_id != last_batch_id + 1) {
        free(payload);
        status = HDL_CORRUPTION;
        break;
      }
      if (callback != NULL) {
        for (size_t index = 0; index < pending_count; index++) {
          unsigned char *record_payload = NULL;
          if (pending[index].payload_length > 0) {
            record_payload = malloc(pending[index].payload_length);
            if (record_payload == NULL) {
              free(payload);
              status = HDL_NOMEM;
              goto finished;
            }
            if (pread_all(log->fd, record_payload, pending[index].payload_length,
                          pending[index].offset + HDL_FRAME_HEADER_SIZE) != 0) {
              free(record_payload);
              free(payload);
              status = HDL_IO;
              goto finished;
            }
          }
          int callback_result = callback(context, pending[index].sequence,
                                         pending[index].batch_id,
                                         pending[index].stream_id,
                                         record_payload,
                                         pending[index].payload_length);
          free(record_payload);
          if (callback_result != 0) {
            free(payload);
            status = HDL_INVALID;
            goto finished;
          }
        }
      }
      last_sequence = last;
      last_batch_id = batch_id;
      committed_offset = offset + frame_length;
      committed_previous_crc = frame_crc;
      pending_count = 0;
      pending_batch_id = 0;
      batch_crc_state = 0xffffffffu;
    }
    previous_crc = frame_crc;
    offset += frame_length;
    free(payload);
  }

finished:
  free(pending);
  if (status != HDL_OK) return status;
  if (repair_tail && (tail_incomplete || pending_count > 0 || offset != committed_offset)) {
    if (ftruncate(log->fd, (off_t)committed_offset) != 0 || sync_data(log->fd) != 0) return HDL_IO;
  }
  recovery->committed_offset = committed_offset;
  recovery->last_sequence = last_sequence;
  recovery->last_batch_id = last_batch_id;
  recovery->previous_frame_crc = committed_previous_crc;
  return HDL_OK;
}

hdl_status hdl_open(const char *path, const hdl_options *options, hdl_log **out) {
  if (path == NULL || path[0] == '\0' || out == NULL) return HDL_INVALID;
  *out = NULL;
  hdl_log *log = calloc(1, sizeof(*log));
  if (log == NULL) return HDL_NOMEM;
  log->fd = -1;
  log->path = strdup(path);
  log->max_record_bytes = options != NULL && options->max_record_bytes != 0
                            ? options->max_record_bytes : HDL_DEFAULT_MAX_RECORD_BYTES;
  log->max_batch_records = options != NULL && options->max_batch_records != 0
                              ? options->max_batch_records : HDL_DEFAULT_MAX_BATCH_RECORDS;
  if (log->path == NULL || pthread_mutex_init(&log->mutex, NULL) != 0) {
    free(log->path);
    free(log);
    return HDL_NOMEM;
  }

  int created = access(path, F_OK) != 0;
  log->fd = open(path, O_RDWR | O_CREAT | O_CLOEXEC | O_APPEND, 0600);
  if (log->fd < 0) {
    hdl_close(log);
    return HDL_IO;
  }
  struct stat metadata;
  if (fstat(log->fd, &metadata) != 0) {
    hdl_close(log);
    return HDL_IO;
  }
  if (metadata.st_size == 0) {
    hdl_status init_status = initialize_segment(log->fd, path, options == NULL ? 1 : options->generation);
    if (init_status != HDL_OK) {
      hdl_close(log);
      return init_status;
    }
    created = 1;
  }
  (void)created;

  hdl_recovery recovery;
  hdl_status status = scan_file(log, NULL, NULL, 1, &recovery);
  if (status != HDL_OK) {
    hdl_close(log);
    return status;
  }
  log->append_offset = recovery.committed_offset;
  log->next_sequence = recovery.last_sequence + 1;
  log->next_batch_id = recovery.last_batch_id + 1;
  log->previous_frame_crc = recovery.previous_frame_crc;
  if (lseek(log->fd, (off_t)log->append_offset, SEEK_SET) < 0) {
    hdl_close(log);
    return HDL_IO;
  }
  *out = log;
  return HDL_OK;
}

hdl_status hdl_append_batch(hdl_log *log,
                            const hdl_record *records,
                            size_t count,
                            hdl_receipt *receipt) {
  if (log == NULL || records == NULL || count == 0 || count > log->max_batch_records) return HDL_INVALID;
  for (size_t index = 0; index < count; index++) {
    if ((records[index].payload_length > 0 && records[index].payload == NULL) ||
        records[index].payload_length > log->max_record_bytes) return HDL_INVALID;
  }
  pthread_mutex_lock(&log->mutex);
  if (log->poisoned) {
    pthread_mutex_unlock(&log->mutex);
    return HDL_POISONED;
  }
  uint64_t batch_id = log->next_batch_id;
  uint64_t first_sequence = log->next_sequence;
  uint64_t sequence = first_sequence;
  uint64_t start_offset = log->append_offset;
  uint64_t offset = start_offset;
  uint32_t previous_crc = log->previous_frame_crc;
  uint32_t batch_crc_state = 0xffffffffu;
  hdl_status status = HDL_OK;
  int barrier_failed = 0;

  for (size_t index = 0; index < count; index++, sequence++) {
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    const unsigned char *payload = records[index].payload;
    encode_frame_header(header, HDL_FRAME_DATA, records[index].payload_length,
                        sequence, batch_id, records[index].stream_id, previous_crc);
    uint32_t frame_crc = finish_frame_header(header, payload, records[index].payload_length);
    if (write_all(log->fd, header, sizeof(header)) != 0 ||
        write_all(log->fd, payload, records[index].payload_length) != 0) {
      status = HDL_IO;
      break;
    }
    batch_crc_state = batch_crc_add(batch_crc_state, frame_crc);
    previous_crc = frame_crc;
    offset += sizeof(header) + records[index].payload_length;
  }

  uint64_t last_sequence = first_sequence + count - 1;
  if (status == HDL_OK) {
    unsigned char payload[HDL_COMMIT_PAYLOAD_SIZE];
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    put_u64(payload, first_sequence);
    put_u64(payload + 8, last_sequence);
    put_u32(payload + 16, (uint32_t)count);
    put_u32(payload + 20, ~batch_crc_state);
    encode_frame_header(header, HDL_FRAME_COMMIT, sizeof(payload), last_sequence,
                        batch_id, 0, previous_crc);
    uint32_t frame_crc = finish_frame_header(header, payload, sizeof(payload));
    if (write_all(log->fd, header, sizeof(header)) != 0 ||
        write_all(log->fd, payload, sizeof(payload)) != 0) {
      status = HDL_IO;
    } else if (sync_data(log->fd) != 0) {
      /* The barrier itself failed. From here this descriptor cannot be trusted
         to report durability, so the handle stops acknowledging entirely. A
         failed WRITE is different and deliberately does not land here: the
         bytes did not all reach the file, and the rollback below returns it to
         a state we still know. */
      status = HDL_IO;
      barrier_failed = 1;
    } else {
      previous_crc = frame_crc;
      offset += sizeof(header) + sizeof(payload);
    }
  }

  if (status == HDL_OK) {
    log->append_offset = offset;
    log->next_sequence = last_sequence + 1;
    log->next_batch_id = batch_id + 1;
    log->previous_frame_crc = previous_crc;
    if (receipt != NULL) {
      receipt->batch_id = batch_id;
      receipt->first_sequence = first_sequence;
      receipt->last_sequence = last_sequence;
      receipt->durable_offset = offset;
    }
  } else {
    /* Roll the failed batch back. If the rollback's own barrier fails we cannot
       even prove the file is back where it started, which poisons the handle
       for the same reason. */
    if (ftruncate(log->fd, (off_t)start_offset) != 0) {
      status = HDL_IO;
      barrier_failed = 1;
    } else if (sync_data(log->fd) != 0) {
      status = HDL_IO;
      barrier_failed = 1;
    }
    (void)lseek(log->fd, (off_t)start_offset, SEEK_SET);
    if (barrier_failed) log->poisoned = 1;
  }
  pthread_mutex_unlock(&log->mutex);
  return status;
}

hdl_status hdl_scan(hdl_log *log, hdl_scan_callback callback, void *context) {
  if (log == NULL) return HDL_INVALID;
  pthread_mutex_lock(&log->mutex);
  hdl_recovery recovery;
  hdl_status status = scan_file(log, callback, context, 0, &recovery);
  pthread_mutex_unlock(&log->mutex);
  return status;
}

hdl_status hdl_cursor_open(hdl_log *log, hdl_cursor **out) {
  if (log == NULL || out == NULL) return HDL_INVALID;
  *out = NULL;
  hdl_cursor *cursor = calloc(1, sizeof(*cursor));
  if (cursor == NULL) return HDL_NOMEM;
  cursor->fd = -1;

  pthread_mutex_lock(&log->mutex);
  hdl_recovery recovery;
  hdl_status status = scan_file(log, NULL, NULL, 0, &recovery);
  if (status == HDL_OK) {
    cursor->fd = dup(log->fd);
    if (cursor->fd < 0) status = HDL_IO;
  }
  if (status == HDL_OK) {
    cursor->offset = HDL_SEGMENT_HEADER_SIZE;
    cursor->committed_offset = recovery.committed_offset;
    cursor->max_record_bytes = log->max_record_bytes;
  }
  pthread_mutex_unlock(&log->mutex);

  if (status != HDL_OK) {
    if (cursor->fd >= 0) close(cursor->fd);
    free(cursor);
    return status;
  }
  *out = cursor;
  return HDL_OK;
}

hdl_status hdl_cursor_next(hdl_cursor *cursor, hdl_cursor_record *out) {
  if (cursor == NULL || out == NULL) return HDL_INVALID;
  free(cursor->payload);
  cursor->payload = NULL;
  memset(out, 0, sizeof(*out));

  while (cursor->offset < cursor->committed_offset) {
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    unsigned char *payload = NULL;
    int short_tail = 0;
    hdl_status status = validate_frame(cursor->fd, cursor->offset,
                                       cursor->committed_offset,
                                       cursor->max_record_bytes,
                                       header, &payload, &short_tail);
    if (status != HDL_OK) return status;
    if (short_tail) return HDL_CORRUPTION;
    cursor->offset += get_u32(header + 8);
    if (get_u16(header + 6) == HDL_FRAME_COMMIT) {
      free(payload);
      continue;
    }
    cursor->payload = payload;
    out->sequence = get_u64(header + 16);
    out->batch_id = get_u64(header + 24);
    out->stream_id = get_u64(header + 32);
    out->payload = cursor->payload;
    out->payload_length = get_u32(header + 12);
    return HDL_OK;
  }
  return HDL_DONE;
}

hdl_status hdl_cursor_close(hdl_cursor *cursor) {
  if (cursor == NULL) return HDL_INVALID;
  hdl_status status = close(cursor->fd) == 0 ? HDL_OK : HDL_IO;
  free(cursor->payload);
  free(cursor);
  return status;
}

hdl_status hdl_close(hdl_log *log) {
  if (log == NULL) return HDL_INVALID;
  hdl_status status = HDL_OK;
  if (log->fd >= 0 && close(log->fd) != 0) status = HDL_IO;
  pthread_mutex_destroy(&log->mutex);
  free(log->path);
  free(log);
  return status;
}

static void *broker_writer(void *opaque) {
  hdl_broker *broker = opaque;
  hdl_request **requests = calloc(broker->max_batch_records, sizeof(*requests));
  hdl_record *records = calloc(broker->max_batch_records, sizeof(*records));
  if (requests == NULL || records == NULL) {
    free(requests);
    free(records);
    pthread_mutex_lock(&broker->mutex);
    broker->stopping = 1;
    for (hdl_request *request = broker->head; request != NULL; request = request->next) {
      request->status = HDL_NOMEM;
      request->done = 1;
      pthread_cond_signal(&request->completed);
    }
    pthread_cond_broadcast(&broker->not_full);
    pthread_mutex_unlock(&broker->mutex);
    return NULL;
  }

  for (;;) {
    pthread_mutex_lock(&broker->mutex);
    while (broker->head == NULL && !broker->stopping) {
      pthread_cond_wait(&broker->not_empty, &broker->mutex);
    }
    if (broker->head == NULL && broker->stopping) {
      pthread_mutex_unlock(&broker->mutex);
      break;
    }
    struct timespec deadline = realtime_after_microseconds(broker->batch_window_microseconds);
    while (broker->queued < broker->max_batch_records && !broker->stopping) {
      int wait_status = pthread_cond_timedwait(&broker->not_empty, &broker->mutex, &deadline);
      if (wait_status == ETIMEDOUT) break;
    }
    uint32_t count = 0;
    while (count < broker->max_batch_records && broker->head != NULL) {
      requests[count] = broker->head;
      broker->head = broker->head->next;
      requests[count]->next = NULL;
      records[count] = requests[count]->record;
      broker->queued--;
      count++;
    }
    if (broker->head == NULL) broker->tail = NULL;
    pthread_cond_broadcast(&broker->not_full);
    pthread_mutex_unlock(&broker->mutex);

    hdl_receipt batch_receipt;
    hdl_status status = hdl_append_batch(broker->log, records, count, &batch_receipt);

    pthread_mutex_lock(&broker->mutex);
    if (status == HDL_OK) {
      broker->stats.records += count;
      broker->stats.durable_batches++;
      if (count > broker->stats.largest_batch) broker->stats.largest_batch = count;
    }
    for (uint32_t index = 0; index < count; index++) {
      requests[index]->status = status;
      if (status == HDL_OK) {
        requests[index]->receipt = batch_receipt;
        requests[index]->receipt.first_sequence = batch_receipt.first_sequence + index;
        requests[index]->receipt.last_sequence = batch_receipt.first_sequence + index;
      }
      requests[index]->done = 1;
      pthread_cond_signal(&requests[index]->completed);
    }
    pthread_mutex_unlock(&broker->mutex);
  }

  free(requests);
  free(records);
  return NULL;
}

hdl_status hdl_broker_open(hdl_log *log,
                           const hdl_broker_options *options,
                           hdl_broker **out) {
  if (log == NULL || out == NULL) return HDL_INVALID;
  *out = NULL;
  hdl_broker *broker = calloc(1, sizeof(*broker));
  if (broker == NULL) return HDL_NOMEM;
  broker->log = log;
  broker->queue_capacity = options != NULL && options->queue_capacity != 0
                             ? options->queue_capacity : HDL_DEFAULT_QUEUE_CAPACITY;
  broker->max_batch_records = options != NULL && options->max_batch_records != 0
                                ? options->max_batch_records : HDL_DEFAULT_BROKER_BATCH_RECORDS;
  broker->batch_window_microseconds = options != NULL && options->batch_window_microseconds != 0
                                        ? options->batch_window_microseconds : HDL_DEFAULT_BATCH_WINDOW_US;
  if (broker->max_batch_records > broker->queue_capacity) {
    broker->max_batch_records = broker->queue_capacity;
  }
  if (pthread_mutex_init(&broker->mutex, NULL) != 0) {
    free(broker);
    return HDL_NOMEM;
  }
  if (pthread_cond_init(&broker->not_empty, NULL) != 0) {
    pthread_mutex_destroy(&broker->mutex);
    free(broker);
    return HDL_NOMEM;
  }
  if (pthread_cond_init(&broker->not_full, NULL) != 0) {
    pthread_cond_destroy(&broker->not_empty);
    pthread_mutex_destroy(&broker->mutex);
    free(broker);
    return HDL_NOMEM;
  }
  if (pthread_create(&broker->writer, NULL, broker_writer, broker) != 0) {
    pthread_cond_destroy(&broker->not_full);
    pthread_cond_destroy(&broker->not_empty);
    pthread_mutex_destroy(&broker->mutex);
    free(broker);
    return HDL_IO;
  }
  *out = broker;
  return HDL_OK;
}

hdl_status hdl_broker_submit(hdl_broker *broker,
                             const hdl_record *record,
                             hdl_receipt *receipt) {
  if (broker == NULL || record == NULL ||
      (record->payload_length > 0 && record->payload == NULL)) return HDL_INVALID;
  hdl_request request;
  memset(&request, 0, sizeof(request));
  request.record = *record;
  if (pthread_cond_init(&request.completed, NULL) != 0) return HDL_NOMEM;

  pthread_mutex_lock(&broker->mutex);
  while (broker->queued >= broker->queue_capacity && !broker->stopping) {
    pthread_cond_wait(&broker->not_full, &broker->mutex);
  }
  if (broker->stopping) {
    pthread_mutex_unlock(&broker->mutex);
    pthread_cond_destroy(&request.completed);
    return HDL_CLOSED;
  }
  if (broker->tail == NULL) broker->head = &request;
  else broker->tail->next = &request;
  broker->tail = &request;
  broker->queued++;
  pthread_cond_signal(&broker->not_empty);
  while (!request.done) pthread_cond_wait(&request.completed, &broker->mutex);
  pthread_mutex_unlock(&broker->mutex);

  pthread_cond_destroy(&request.completed);
  if (receipt != NULL && request.status == HDL_OK) *receipt = request.receipt;
  return request.status;
}

hdl_status hdl_broker_get_stats(hdl_broker *broker, hdl_broker_stats *out) {
  if (broker == NULL || out == NULL) return HDL_INVALID;
  pthread_mutex_lock(&broker->mutex);
  *out = broker->stats;
  pthread_mutex_unlock(&broker->mutex);
  return HDL_OK;
}

hdl_status hdl_broker_close(hdl_broker *broker) {
  if (broker == NULL) return HDL_INVALID;
  pthread_mutex_lock(&broker->mutex);
  broker->stopping = 1;
  pthread_cond_broadcast(&broker->not_empty);
  pthread_cond_broadcast(&broker->not_full);
  pthread_mutex_unlock(&broker->mutex);
  if (pthread_join(broker->writer, NULL) != 0) return HDL_IO;
  pthread_cond_destroy(&broker->not_full);
  pthread_cond_destroy(&broker->not_empty);
  pthread_mutex_destroy(&broker->mutex);
  free(broker);
  return HDL_OK;
}

const char *hdl_status_name(hdl_status status) {
  switch (status) {
    case HDL_OK: return "ok";
    case HDL_INVALID: return "invalid";
    case HDL_IO: return "io";
    case HDL_CORRUPTION: return "corruption";
    case HDL_NOMEM: return "nomem";
    case HDL_LIMIT: return "limit";
    case HDL_CLOSED: return "closed";
    case HDL_DONE: return "done";
    case HDL_POISONED: return "poisoned";
  }
  return "unknown";
}
