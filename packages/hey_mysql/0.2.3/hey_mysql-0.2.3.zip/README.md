# hey_mysql 0.2.3

`hey_mysql` is an independently versioned MariaDB/MySQL client package for the current compatible Hey native-extension interface. Database behavior, Connector/C compatibility, TLS policy, native builds, and live-server receipts belong to this package—not the Hey language repository.

## Boundary

- `native/`, `hey.native.json`, and `native.hey` provide opaque Connector/C connection/result handles over Hey native ABI v2.
- `adapter.hey` provides query results, transactions, escaped parameter plans, and the database-neutral connection shape consumed by higher-level packages.
- Hey supplies only generic package, FFI, opaque-handle, blocking-call, worker, and Job foundations.

## Build and verify

Install MariaDB Connector/C or MySQL client development files, then run:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

`bin/build-native` probes the installed headers instead of guessing from preprocessor names:

- MySQL 8/9: `MYSQL_OPT_SSL_MODE` and `enum mysql_ssl_mode`;
- MariaDB Connector/C: `MYSQL_OPT_SSL_ENFORCE` and `MYSQL_OPT_SSL_VERIFY_SERVER_CERT`.

For an immutable installed package, write native outputs outside the package cache:

```sh
package="$PWD/.hey/packages/hey_mysql/0.2.3"
out="$PWD/.hey/native/hey_mysql/0.2.3/darwin-arm64"
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" "$package/bin/build-native" --out "$out"
export HEY_MYSQL_LIBRARY="$out/libhey_mysql.dylib"
```

## Use

```hey
import 'pkg:hey_mysql@0.2.3/main'

let opened = Mysql.connect({
  host: '127.0.0.1',
  port: 3306,
  username: 'app',
  password: 'secret',
  database: 'app_production',
  connect_timeout_seconds: 5,
  encoding: 'utf8mb4',
  tls: {mode: 'preferred'},
})

if opened.ok == false
  fail opened.code + ': ' + opened.error
end

let database = opened.value
let rows = Mysql.query_params(database,
  'SELECT id, name FROM cards WHERE name = ?',
  ['Ada'])
Mysql.close(database)
```

TLS modes are `disabled`, `preferred`, `required`, and `verify_server_cert`. Verification requires `tls.ca` or `tls.ca_path`. `Mysql.tls_api(connection)` identifies the selected Connector/C option family, while `Mysql.tls_active(connection)` reports the negotiated connection state.

## Receipts

The base gate proves:

- header compatibility for MySQL 8/9 and MariaDB Connector/C;
- generated ABI, dynamic loading, opaque handles, TLS mode configuration, escaping, bounded refusal, and teardown through interpreter, native-C, and direct LLVM;
- the higher-level adapter through interpreter and native-C.

A configured live server remains a separate destructive integration receipt:

```sh
HEY_MYSQL_TEST_HOST="127.0.0.1" \
HEY_MYSQL_TEST_PORT="3306" \
HEY_MYSQL_TEST_USER="app" \
HEY_MYSQL_TEST_PASSWORD="secret" \
HEY_MYSQL_TEST_DATABASE="app_test" \
HEY_MYSQL_TEST_TLS="preferred" \
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
./bin/check-live
```

The live gate creates and drops `hey_mysql_0201_receipt`. It currently proves interpreter and native-C live behavior. Direct-LLVM native load/refusal passes, but the complete dynamic live-SQL fixture still exceeds the self-hosted LLVM supported subset for dynamic environment/string expressions; the gate reports `llvm_live=false` rather than hiding that compiler limitation.

## Honest limitation

0.2.3 uses Connector/C escaping to realize generated `?` parameter plans. This is not server-side prepared execution. SQL containing literal question marks or comments should use `Mysql.query`. `MYSQL_STMT`, typed/binary binds, cancellation, and statement reuse remain future package work.

## Standard package controls

This package uses `hey_packager` 0.1.2 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_mysql`.
