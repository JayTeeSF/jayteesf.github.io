#define _POSIX_C_SOURCE 200809L

#include "hey_durable_log.h"

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

/* A REAL full filesystem, not a mocked ENOSPC.
 *
 * A mock proves the error branch compiles. A full disk proves something else
 * entirely, because ENOSPC does not arrive where a mock puts it: it can arrive
 * in the middle of a frame write, in the rollback that follows it, while a
 * segment is being cut, or -- on some filesystems -- at fdatasync, after every
 * write has already returned success. The promise under test is one sentence:
 * the journal never acknowledges a mutation it could not make durable, and a
 * disk that fills up does not damage the prefix it already acknowledged.
 *
 * Run through bin/check-enospc, which mounts a small real filesystem and passes
 * it in argv[1]. */

static void fail(const char *message) {
  fprintf(stderr, "FAIL: %s\n", message);
  exit(1);
}

static int collect(void *opaque, uint64_t sequence, uint64_t batch_id,
                   uint64_t stream_id, const void *payload, uint32_t payload_length) {
  uint64_t *count = opaque;
  (void)batch_id;
  (void)stream_id;
  (void)payload;
  (void)payload_length;
  if (sequence != *count + 1) fail("the recovered log is not in sequence");
  (*count)++;
  return 0;
}

/* Fill the filesystem until the kernel says there is nothing left. The file
   stays until the test deletes it, which is how space comes back. */
static void fill_the_filesystem(const char *path) {
  int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd < 0) fail("create the filler file");
  static unsigned char block[64 * 1024];
  memset(block, 0xa5, sizeof(block));
  size_t length = sizeof(block);
  for (;;) {
    ssize_t written = write(fd, block, length);
    if (written > 0) continue;
    if (written < 0 && errno == EINTR) continue;
    if (length > 1) {
      /* Squeeze the last bytes out with smaller writes: a filesystem with 3 KiB
         free is not full, and the journal would keep going. */
      length /= 2;
      continue;
    }
    break;
  }
  if (fsync(fd) != 0 && errno != ENOSPC) fail("sync the filler file");
  close(fd);
}

/* Hand back a measured amount of space, so the journal has room to run right up
   against the wall -- crossing several segment cuts on the way -- instead of
   stopping at the first append after a completely full disk. */
static void release_space(const char *path, off_t bytes) {
  struct stat metadata;
  if (stat(path, &metadata) != 0) fail("stat the filler file");
  if (metadata.st_size <= bytes) fail("the filler file is smaller than the space to release");
  if (truncate(path, metadata.st_size - bytes) != 0) fail("release space from the filler file");
}

static size_t published_segments(const char *directory) {
  DIR *handle = opendir(directory);
  if (handle == NULL) fail("open the journal directory");
  size_t count = 0;
  struct dirent *entry;
  while ((entry = readdir(handle)) != NULL) {
    size_t length = strlen(entry->d_name);
    if (length == 37 && strcmp(entry->d_name + 33, ".seg") == 0) count++;
  }
  closedir(handle);
  return count;
}

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "usage: enospc_test <mount-point-of-a-small-real-filesystem>\n");
    return 2;
  }
  char journal[1024];
  char filler[1024];
  snprintf(journal, sizeof(journal), "%s/journal", argv[1]);
  snprintf(filler, sizeof(filler), "%s/filler", argv[1]);

  /* A journal left over from an earlier run would make every count in this test
     a lie: the acknowledged counter starts at zero while the log does not. That
     is not hypothetical -- it is what the first green run of this gate actually
     was, and the mismatch is what exposed it. */
  struct stat existing;
  if (stat(journal, &existing) == 0) {
    fail("the test filesystem already holds a journal; this gate needs a fresh filesystem");
  }

  /* Segments small enough that the exhaustion also lands on a cut, which is the
     one place a failure creates a file rather than extending one. */
  hdl_options options = {1, 0, 0, 0, 4096};
  hdl_log *log = NULL;
  if (hdl_open(journal, &options, &log) != HDL_OK) fail("open a journal on the test filesystem");

  uint64_t acknowledged = 0;
  const char payload[] = "a mutation that must be durable or refused";
  hdl_record record = {5, payload, sizeof(payload) - 1, 1};
  for (int index = 0; index < 20; index++) {
    if (hdl_append_batch(log, &record, 1, NULL) != HDL_OK) {
      fail("an append failed before the filesystem was anywhere near full");
    }
    acknowledged++;
  }

  fill_the_filesystem(filler);
  release_space(filler, 256 * 1024);

  hdl_status status = HDL_OK;
  int attempts = 0;
  while (status == HDL_OK && attempts < 100000) {
    status = hdl_append_batch(log, &record, 1, NULL);
    attempts++;
    if (status == HDL_OK) acknowledged++;
  }
  if (status == HDL_OK) fail("the filesystem never ran out of space; this gate is not testing exhaustion");
  if (status != HDL_IO && status != HDL_POISONED) {
    fprintf(stderr, "exhaustion reported %s\n", hdl_status_name(status));
    fail("a full filesystem must be reported as an I/O failure or a poisoned handle");
  }
  if (hdl_close(log) != HDL_OK) fail("close the journal after exhaustion");

  /* The squeeze must have crossed several cuts, or this gate is only testing
     ENOSPC on a growing file and never on a segment being created. */
  if (published_segments(journal) < 4) {
    fail("the journal did not rotate on the way to exhaustion; the cut path was not exercised");
  }

  /* The prefix that was acknowledged is intact, in order, and not one record
     more: nothing was acknowledged that the disk could not take. */
  if (hdl_open(journal, &options, &log) != HDL_OK) {
    fail("a full filesystem must not leave the journal unopenable");
  }
  uint64_t recovered = 0;
  if (hdl_scan(log, collect, &recovered) != HDL_OK) fail("scan the journal recovered from exhaustion");
  if (recovered != acknowledged) {
    fprintf(stderr, "acknowledged %llu, recovered %llu\n",
            (unsigned long long)acknowledged, (unsigned long long)recovered);
    fail("the journal did not hold exactly the records it acknowledged");
  }

  /* And it is a journal again once there is room, continuing the same log. */
  if (unlink(filler) != 0) fail("free the filesystem again");
  hdl_receipt receipt;
  if (hdl_append_batch(log, &record, 1, &receipt) != HDL_OK) {
    fail("the journal did not recover its ability to append once space returned");
  }
  if (receipt.first_sequence != acknowledged + 1) fail("exhaustion broke the sequence");
  if (hdl_close(log) != HDL_OK) fail("close the journal after recovery");

  printf("PASS: a full filesystem refuses rather than acknowledging, and keeps its committed prefix (%llu records)\n",
         (unsigned long long)acknowledged);
  return 0;
}
