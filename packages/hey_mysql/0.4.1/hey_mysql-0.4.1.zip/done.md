# Done

- Replaced the historical mysql CLI subprocess adapter with Connector/C over Hey native ABI v2.
- Added explicit connection/result ownership, bounded timeouts, charset selection, rows, transactions, ping, insert IDs, affected rows, and safe escaping.
- Added build-time TLS API detection for MySQL 8/9 `MYSQL_OPT_SSL_MODE` and MariaDB legacy options; removed invalid enum-name preprocessor detection.
- Added stable TLS modes, negotiated-TLS reporting, and a package-owned configured live-server receipt.
- Proved native plumbing through interpreter, native-C, and direct LLVM; proved the callback-rich adapter through interpreter and native-C.
- Updated native generation to the stable `hey native` command and removed `hey_packager` from runtime dependencies.
- v0.3.2: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes.
