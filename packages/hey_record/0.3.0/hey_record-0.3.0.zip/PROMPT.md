# Continue hey_record

Read README.md, docs/DESIGN.md, goals.md, in-progress.md, todos.md, done.md, manifests, implementation files, and specs before editing.

This is pure-Hey porcelain; never add C FFI or engine-specific handles here. Driver packages implement the connection callback contract. Keep datasets immutable, SQL values parameterized, and unscoped writes rejected.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

Published versions are immutable. Change the package version whenever released bytes change.

## Files the next LLM needs

For focused work, upload:

1. the latest full `hey-lang-bootstrap-plan` source ZIP;
2. this package's latest source/release ZIP (`hey_record-0.3.0.zip`).

For coordinated adapter/porcelain work, upload the latest database-stack handoff instead of the individual package ZIPs; it should contain `hey_record`, `hey_sqlite3`, and `hey_mysql`, release metadata, cross-package verification, language findings, and the roadmap.
