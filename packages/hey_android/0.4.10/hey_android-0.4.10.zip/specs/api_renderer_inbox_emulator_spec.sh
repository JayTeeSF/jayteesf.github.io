#!/usr/bin/env bash
# A synthetic unread Ron conversation on a disposable API 36 AVD created under
# the test's temporary directory. It never shares the maintainer's emulator.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
export HEY_ANDROID_ROOT
. "$ROOT/tools/android-env.sh"
hey_android_isolate

AVD=hey_android_inbox_fixture
PORT=${HEY_ANDROID_INBOX_TEST_PORT:-5584}
SERIAL=emulator-$PORT
PACKAGE=com.jayteesf.hey.inboxfixture
ACTIVITY=hey.android.api.HeyAndroidApiActivity
ADB=$HEY_ANDROID_ADB
export ADB
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-inbox-emulator.XXXXXX")
mkdir -p "$work/shots"
export ANDROID_AVD_HOME="$work/avd-home"
mkdir -p "$ANDROID_AVD_HOME"
evidence=${HEY_ANDROID_INBOX_EVIDENCE:-}
emulator_pid=''
server_pid=''
installed=false
pass() { echo "PASS: $*"; }
bad() { echo "FAIL: $*"; failed=1; }
adbs() { "$ADB" -s "$SERIAL" "$@"; }
drive() { "$HEY_ANDROID_RUBY" "$ROOT/specs/support/drive.rb" "$SERIAL" "$@" > "$work/drive.last" 2>&1; }
texts() { "$HEY_ANDROID_RUBY" "$ROOT/specs/support/drive.rb" "$SERIAL" texts 2> /dev/null; }
shot() { "$HEY_ANDROID_RUBY" "$ROOT/specs/support/drive.rb" "$SERIAL" shot "$work/shots/$1.png" > /dev/null; }

cleanup() {
  status=$?
  if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi
  if [ "$installed" = true ]; then adbs uninstall "$PACKAGE" >/dev/null 2>&1 || true; fi
  # Stop only the AVD and console port created by this test. Never stop the
  # user's already-running emulator or the shared ADB daemon.
  if [ -n "$emulator_pid" ]; then
    adbs emu kill >/dev/null 2>&1 || true
    for _ in $(seq 1 30); do kill -0 "$emulator_pid" 2>/dev/null || break; /bin/sleep 1; done
    kill "$emulator_pid" 2>/dev/null || true
    wait "$emulator_pid" 2>/dev/null || true
  fi
  for _ in $(seq 1 15); do
    pids=$(pgrep -f "qemu-system.*-port $PORT( |$)" 2>/dev/null || true)
    [ -n "$pids" ] || break
    kill $pids 2>/dev/null || true
    /bin/sleep 1
  done
  if pgrep -f "qemu-system.*-port $PORT( |$)" >/dev/null 2>&1; then
    echo "FAIL: test emulator on port $PORT remains running"
    status=1
  fi
  if [ -n "$evidence" ]; then
    mkdir -p "$evidence"
    cp -R "$work/shots/." "$evidence/"
    cp "$work"/*.log "$evidence/" 2>/dev/null || true
    [ ! -f "$work/apk/app.apk" ] || cp "$work/apk/app.apk" "$evidence/inbox-fixture.apk"
    if [ -f "$work/apk/app.apk" ]; then
      "$HEY_ANDROID_BUILD_TOOLS_DIR/aapt" dump xmltree "$work/apk/app.apk" AndroidManifest.xml > "$evidence/manifest-tree.txt" 2>&1 || true
    fi
  fi
  rm -rf "$work"
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT TERM

if pgrep -f "qemu-system.*-port $PORT( |$)" >/dev/null 2>&1; then
  bad "test port $PORT is already in use; leaving that emulator untouched"
  exit 1
fi

port=$("$HEY_ANDROID_RUBY" -rsocket -e 's = TCPServer.new("127.0.0.1", 0); puts s.addr[1]; s.close')
java_home=$(hey_android_java_home)
if [ -z "$java_home" ] || ! printf 'no\n' | env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" \
  "$HEY_ANDROID_AVDMANAGER" create avd --force --name "$AVD" --package "$HEY_ANDROID_SYSTEM_IMAGE" \
  --device "$HEY_ANDROID_AVD_DEVICE" > "$work/avd-create.log" 2>&1; then
  bad "could not create disposable API 36 AVD: $(tail -8 "$work/avd-create.log")"
  exit 1
fi
pass "created disposable AVD metadata under $ANDROID_AVD_HOME"
"$HEY_ANDROID_RUBY" "$ROOT/specs/support/fake_inbox_server.rb" --port "$port" \
  --description "$ROOT/specs/support/inbox_conversation_description.json" > "$work/server.log" 2>&1 &
server_pid=$!
for _ in $(seq 1 50); do
  if curl -fsS "http://127.0.0.1:$port/v1/app/description" >/dev/null 2>&1; then break; fi
  /bin/sleep 0.2
done
curl -fsS "http://127.0.0.1:$port/v1/app/description" >/dev/null || { bad "synthetic server failed: $(cat "$work/server.log")"; exit 1; }

if ! "$ROOT/tools/hey-android-api-app.sh" \
  --description "$ROOT/specs/support/inbox_conversation_description.json" \
  --origin "http://10.0.2.2:$port" --package-id "$PACKAGE" --label 'Inbox fixture' \
  --out "$work/apk" > "$work/build.log" 2>&1; then
  bad "fixture APK did not build: $(tail -8 "$work/build.log")"
  exit 1
fi

"$HEY_ANDROID_EMULATOR_BIN" -avd "$AVD" -port "$PORT" -no-window -no-audio -no-snapshot \
  -no-boot-anim -gpu swiftshader_indirect > "$work/emulator.log" 2>&1 &
emulator_pid=$!
"$ADB" start-server >/dev/null 2>&1 || true
booted=false
for _ in $(seq 1 "${HEY_ANDROID_BOOT_TIMEOUT:-300}"); do
  if ! kill -0 "$emulator_pid" 2>/dev/null; then break; fi
  if [ "$("$ADB" -s "$SERIAL" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ]; then booted=true; break; fi
  /bin/sleep 1
done
if [ "$booted" != true ]; then
  bad "test AVD failed to boot: $(tail -8 "$work/emulator.log")"
  exit 1
fi
pass "booted disposable AVD $AVD as $SERIAL; the maintainer's emulator was not selected"
adbs shell wm dismiss-keyguard >/dev/null 2>&1 || true
if ! adbs install -r "$work/apk/app.apk" > "$work/install.log" 2>&1; then
  bad "fixture install failed: $(cat "$work/install.log")"
  exit 1
fi
installed=true
adbs shell am start -W -n "$PACKAGE/$ACTIVITY" > "$work/launch.log" 2>&1 || true
if grep -Eq 'Error type|does not exist|Error:' "$work/launch.log"; then
  adbs shell dumpsys package "$PACKAGE" > "$work/package-dump.log" 2>&1 || true
  adbs logcat -d -t 250 > "$work/device-logcat.log" 2>&1 || true
  bad "fixture Activity launch failed: $(cat "$work/launch.log"); package: $(adbs shell pm list packages | grep -F "$PACKAGE" || true); resolver: $(adbs shell cmd package resolve-activity --brief "$PACKAGE/$ACTIVITY" 2>&1 | tr '\n' ' ')"
  exit 1
fi
drive wait Name 30 || {
  bad "fixture sign-in did not appear: $(cat "$work/drive.last"); app log: $(adbs logcat -d -t 120 2>/dev/null | grep -E 'hey.api|FATAL EXCEPTION|AndroidRuntime' | tail -12 | tr '\n' '|')"
  exit 1
}
drive type Name ann
drive type Passphrase fixture-pass-1
adbs shell input keyevent 111 >/dev/null 2>&1 || true
drive tap 'Sign in'
drive wait 'Shared with you' 30 || { bad "the Shared tab did not appear: $(cat "$work/drive.last")"; exit 1; }
drive tap 'Shared with you'
drive wait 'A shared video' 30 || { bad "the synthetic conversation was not listed"; exit 1; }
if ! printf '%s\n' "$(texts)" | grep -Fq '🔴 1 new'; then
  bad "the exact Ron conversation row does not expose the unread marker"
  exit 1
fi
shot unread-conversation-row
pass "the Shared list identifies Ron's exact unread video conversation with the red 1-new marker"
drive tap 'A shared video'
drive wait 'FINAL MESSAGE MARKER.' 30 --contains || { bad "conversation final marker did not render"; exit 1; }
shot conversation-top
"$HEY_ANDROID_RUBY" - "$work/shots/conversation-top.png.xml" <<'RB'
require 'rexml/document'
root = REXML::Document.new(File.read(ARGV[0])).root
nodes = ([root] + REXML::XPath.match(root, './/node')).select { |n| n.name == 'node' }
body = nodes.find { |n| (n.attributes['text'] || '').include?('Thanks for sharing this video, Jay.') }
scroll = nodes.find { |n| n.attributes['class'] == 'android.widget.ScrollView' }
abort('first and final sentences are not exposed by one message view') if body.nil? || !(body.attributes['text'] || '').include?('FINAL MESSAGE MARKER.')
abort('message text ends in an ellipsis') if (body.attributes['text'] || '').rstrip.end_with?("…", '...')
height = lambda do |node|
  match = /\A\[(\d+),(\d+)\]\[(\d+),(\d+)\]\z/.match(node.attributes['bounds'] || '')
  abort('message or scroll view has invalid bounds') unless match
  match[4].to_i - match[2].to_i
end
abort('message view is only a compact preview, not a full multi-paragraph body') if scroll.nil? || height.call(body) < height.call(scroll) * 0.20
puts format('full message body occupies %d px within %d px scroll viewport', height.call(body), height.call(scroll))
RB
pass "the message's Android view itself contains both distinctive sentences and grows beyond a compact three-line preview"
for _ in 1 2 3; do adbs shell input swipe 540 1850 540 650 350 >/dev/null 2>&1; /bin/sleep 0.5; done
shot conversation-bottom
"$HEY_ANDROID_RUBY" - "$work/shots/conversation-top.png.xml" "$work/shots/conversation-bottom.png.xml" <<'RB'
require 'rexml/document'
message_bounds = lambda do |path|
  root = REXML::Document.new(File.read(path)).root
  nodes = ([root] + REXML::XPath.match(root, './/node')).select { |n| n.name == 'node' }
  node = nodes.find { |n| (n.attributes['text'] || '').include?('Thanks for sharing this video, Jay.') }
  abort('full message is not present after scrolling') if node.nil? || !(node.attributes['text'] || '').include?('FINAL MESSAGE MARKER.')
  match = /\A\[(\d+),(\d+)\]\[(\d+),(\d+)\]\z/.match(node.attributes['bounds'] || '')
  abort('message view has invalid bounds') unless match
  match.captures.map(&:to_i)
end
top = message_bounds.call(ARGV[0])
bottom = message_bounds.call(ARGV[1])
abort('the long conversation did not scroll to its final paragraphs') if top[1] - bottom[1] < 100
puts format('message view moved upward %d px while scrolling', top[1] - bottom[1])
RB
pass "the long conversation scrolls, and the final marker remains in its full message view"
message=$(texts)
if printf '%s\n' "$message" | grep -Fq 'Thanks for sharing this video, Jay.' \
   && printf '%s\n' "$message" | grep -Fq 'FINAL MESSAGE MARKER.'; then
  pass "the open thread contains the message from its distinctive first sentence through its final marker"
else
  bad "the open thread text is incomplete"
  exit 1
fi
if grep -Fq 'FINAL MESSAGE MARKER.' "$work/shots/conversation-bottom.png.xml"; then
  pass "after scrolling, Android exposes the final message marker in the native view tree"
else
  bad "the bottom conversation screenshot has no final marker in its view tree"
fi
adbs shell input keyevent 4
drive wait 'A shared video' 20 || { bad "returning from the conversation did not restore Shared"; exit 1; }
if drive gone '🔴 1 new' 20 --contains; then
  pass "reading Ron's thread clears the red marker from that exact Shared row"
else
  bad "the exact Shared row still shows the unread marker after the thread is read"
fi
if [ "$failed" = 0 ]; then
  pass "Android renderer conversation layout passes on a disposable API 36 device; all fixture data is synthetic"
fi
exit "$failed"
