#!/usr/bin/env sh
# Pins the 0.4.7 background_color contract in tools/hey_native_tv_runtime.m:
# a top-level "background_color" hex string, when present and parseable,
# fills the scene background flat -- the one field a SERVER-rendered scene
# needs to dim the screen at night (maintainer report, 2026-07-31). When the
# field is ABSENT the background path must be exactly the 0.4.6 one (felt
# gradient, background.color, or the dark viewDidLoad default), so every
# existing scene renders pixel-identically. Additive, like handles_back and
# keep_awake before it.
#
# The rendering path is Objective-C, not Hey, so the Hey spec harness cannot
# exercise it; like back_button_spec.sh this spec mechanically pins the
# load-bearing decisions and then compiles the scene-v2 renderer with
# -DHEY_SCENE_V2 (the whole v2 renderer is invisible to a compile without
# that define).
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
RUNTIME="$ROOT/tools/hey_native_tv_runtime.m"

fail() { echo "background color spec: $1" >&2; exit 1; }

# 1. The field must be read at all, from the TOP LEVEL of the scene document
#    (scene[...], not a widget dictionary), so a scene WITH background_color
#    parses into a background fill.
grep -q 'scene\[@"background_color"\]' "$RUNTIME" || fail 'top-level background_color never read: the server cannot dim the screen'

# 2. It must be type-guarded exactly like every other scene color field
#    (caption_color pattern): a non-string value falls through to the 0.4.6
#    path instead of crashing or half-applying.
grep -q '\[scene\[@"background_color"\] isKindOfClass:NSString.class\]' "$RUNTIME" || fail 'background_color not isKindOfClass-guarded like the other color fields'

# 3. Parsing must go through the one shared hex parser with a nil fallback,
#    so an unparseable value ("", "night", "#12345") is DROPPED and the
#    legacy background path runs -- never a half-parsed color.
grep -q 'HeyColorFromHex(scene\[@"background_color"\], nil)' "$RUNTIME" || fail 'background_color not parsed via HeyColorFromHex with a nil fallback'

# 4. Absent means byte-identical to 0.4.6: the legacy background object's
#    felt and color branches must both still exist for scenes WITHOUT the
#    new field.
grep -q 'bg\[@"felt"\]' "$RUNTIME" || fail 'legacy background.felt branch gone: scenes without background_color would change'
grep -q 'bg\[@"color"\]' "$RUNTIME" || fail 'legacy background.color branch gone: scenes without background_color would change'

# 5. The scene-v2 renderer has to actually build for the Apple TV SDK.
#    Interpreter-green is not compiled-green, and the v2 half of this file is
#    invisible to a compile without -DHEY_SCENE_V2.
if [ "$(uname -s)" = Darwin ] && xcrun --sdk appletvos --show-sdk-path >/dev/null 2>&1; then
  clang=$(xcrun --sdk appletvos --find clang)
  sdk=$(xcrun --sdk appletvos --show-sdk-path)
  "$clang" --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -DHEY_SCENE_V2 -fsyntax-only "$RUNTIME" || fail 'scene-v2 renderer does not compile for tvOS'
else
  echo 'background color spec: no tvOS SDK here, skipped the compile check'
fi

echo 'background color spec passed'
