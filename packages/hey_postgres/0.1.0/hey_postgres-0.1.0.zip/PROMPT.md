# hey_postgres

Native PostgreSQL adapter for Hey over libpq. Public API in `adapter.hey`
(`Postgres`); low-level ownership in `Native.hey` (`PostgresNative`); C shim in
`native/`. Build with `bin/build-native`; verify with `bin/check`. See
`PACKAGE_SPEC.md` for the authoritative contract.
