package hey.android.api;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pictures for rows, fetched once and remembered.
 *
 * <p>A picture is the one thing on these screens that comes from somewhere
 * OTHER than this app's own server: i.ytimg.com, a publisher, a store. So this
 * is deliberately not part of {@link HeyAndroidHttp}, which carries the
 * session token -- nothing here sends a header, a cookie or a token anywhere,
 * because the address came out of a row and an address out of a row is not a
 * place to present credentials.
 *
 * <p>HTTPS ONLY, for the same reason. A row can name any address at all, and a
 * plaintext fetch would tell whatever is on the path exactly what somebody is
 * reading. Anything else is simply not fetched and the row draws without a
 * picture, which is what it did before this file existed.
 *
 * <p>MISSING IS NORMAL, not an error worth showing: the sweep that fills these
 * addresses in runs behind the app, links rot, and a title that is not out yet
 * has no picture by definition. A failure leaves the space empty and is logged,
 * never raised -- a shelf of red error boxes would be worse than a plain list.
 */
final class HeyAndroidPictures {
  static final String TAG = "hey.api";

  /** What a caller wants when one arrives. Called on the main thread. */
  interface Ready {
    void drew(Bitmap picture);
  }

  private static final int LIMIT = 120;
  private static final int MAX_BYTES = 4 * 1024 * 1024;

  private final ExecutorService pool = Executors.newFixedThreadPool(2);
  private final Handler main = new Handler(Looper.getMainLooper());

  /**
   * The ones already fetched, oldest dropped first. Bounded because a library
   * runs to hundreds of rows and a bitmap is not small; the cap is on COUNT
   * rather than bytes, which is cruder than a byte budget and enough at the
   * size these thumbnails are.
   */
  private final Map<String, Bitmap> held = Collections.synchronizedMap(
      new LinkedHashMap<String, Bitmap>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Bitmap> eldest) {
          return size() > LIMIT;
        }
      });

  /** Addresses already asked for and answered with nothing, so a broken one is asked for once. */
  private final Map<String, Boolean> barren = Collections.synchronizedMap(new LinkedHashMap<String, Boolean>() {
    @Override protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
      return size() > LIMIT * 4;
    }
  });

  /** True when this is an address this will even try. */
  static boolean fetchable(String address) {
    return address != null && address.startsWith("https://");
  }

  /**
   * Cached under its SIZE as well as its address. The same poster is wanted
   * small beside a row and whole at the top of its own screen, and one key for
   * both would hand whichever was asked for first to the other -- a header
   * built from a half-size thumbnail is exactly the blur this was asked to fix.
   */
  private static String key(String address, boolean full) {
    return (full ? "full|" : "thumb|") + address;
  }

  /** The one already held, or null. Lets a row draw without a flash when it is scrolled back to. */
  Bitmap held(String address, boolean full) {
    return address == null ? null : held.get(key(address, full));
  }

  /**
   * Fetch it, unless it is already held or already known to be missing.
   *
   * <p>The caller passes the address it wants back so it can check the row it
   * is about to draw into is still showing the same one: these are list rows,
   * and a slow fetch landing after the view was reused is how the wrong picture
   * ends up against the wrong title.
   */
  void want(String address, boolean full, Ready then) {
    if (!fetchable(address)) return;
    String at = key(address, full);
    Bitmap already = held.get(at);
    if (already != null) {
      then.drew(already);
      return;
    }
    if (barren.containsKey(address)) return;
    pool.execute(() -> {
      Bitmap picture = read(address, full);
      if (picture == null) {
        barren.put(address, Boolean.TRUE);
        return;
      }
      held.put(at, picture);
      main.post(() -> then.drew(picture));
    });
  }

  private Bitmap read(String address, boolean full) {
    HttpURLConnection conn = null;
    try {
      conn = (HttpURLConnection) new URL(address).openConnection();
      conn.setInstanceFollowRedirects(true);
      conn.setConnectTimeout(10000);
      conn.setReadTimeout(15000);
      conn.setRequestProperty("Accept", "image/*");
      int status = conn.getResponseCode();
      if (status < 200 || status > 299) return null;
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      try (InputStream in = conn.getInputStream()) {
        byte[] chunk = new byte[16384];
        int n;
        while ((n = in.read(chunk)) > 0) {
          out.write(chunk, 0, n);
          if (out.size() > MAX_BYTES) return null;
        }
      }
      byte[] bytes = out.toByteArray();
      // Half size for a row, because a full poster decoded at its own
      // resolution is megabytes of heap per row for no visible gain. FULL size
      // when it is the picture at the top of a screen, which is the whole point
      // of drawing it there.
      BitmapFactory.Options options = new BitmapFactory.Options();
      options.inSampleSize = full ? 1 : 2;
      return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
    } catch (Exception e) {
      Log.i(TAG, "no picture from " + address + ": " + e);
      return null;
    } finally {
      if (conn != null) conn.disconnect();
    }
  }
}
