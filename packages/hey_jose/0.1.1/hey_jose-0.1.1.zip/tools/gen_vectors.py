#!/usr/bin/env python3
"""Generate real known-good JWS test vectors (RS256 + ES256) using the openssl
CLI. Emits shell `export` lines the package-check sources. Uses only the Python
standard library plus openssl; no third-party crypto. TEST-ONLY."""
import base64
import json
import os
import subprocess
import sys
import tempfile

def b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")

def run(args, **kw):
    return subprocess.run(args, check=True, capture_output=True, **kw)

def sign(key_path: str, signing_input: str) -> bytes:
    p = subprocess.run(["openssl", "dgst", "-sha256", "-sign", key_path, "-binary"],
                       input=signing_input.encode("ascii"), check=True, capture_output=True)
    return p.stdout

def der_to_raw_ecdsa(der: bytes, size: int = 32) -> bytes:
    # SEQUENCE { INTEGER r, INTEGER s }
    assert der[0] == 0x30
    i = 2
    if der[1] & 0x80:  # long-form length
        i = 2 + (der[1] & 0x7F)
    def read_int(idx):
        assert der[idx] == 0x02
        ln = der[idx + 1]
        val = der[idx + 2: idx + 2 + ln]
        return val.lstrip(b"\x00"), idx + 2 + ln
    r, i = read_int(i)
    s, i = read_int(i)
    return r.rjust(size, b"\x00") + s.rjust(size, b"\x00")

def make_jwt(header: dict, claims: dict, key_path: str, ec: bool) -> str:
    seg = b64u(json.dumps(header, separators=(",", ":")).encode()) + "." + \
          b64u(json.dumps(claims, separators=(",", ":")).encode())
    raw = sign(key_path, seg)
    if ec:
        raw = der_to_raw_ecdsa(raw, 32)
    return seg + "." + b64u(raw)

def main():
    d = tempfile.mkdtemp()
    iss = "https://issuer.example/"
    aud = "mmeoww-api"
    claims = {"iss": iss, "aud": aud, "sub": "user-1", "exp": 4102444800, "nbf": 0, "iat": 0}

    # --- RSA / RS256 ---
    rsa = os.path.join(d, "rsa.pem")
    run(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:2048", "-out", rsa])
    mod = run(["openssl", "rsa", "-in", rsa, "-noout", "-modulus"]).stdout.decode()
    mod_hex = mod.strip().split("=", 1)[1]
    n = bytes.fromhex(mod_hex)
    e = (65537).to_bytes(3, "big")
    rsa_jwks = {"keys": [{"kty": "RSA", "kid": "rsa1", "alg": "RS256", "use": "sig", "n": b64u(n), "e": b64u(e)}]}
    rs_token = make_jwt({"alg": "RS256", "typ": "JWT", "kid": "rsa1"}, claims, rsa, ec=False)
    # tampered: flip last char of signature
    tampered = rs_token[:-1] + ("A" if rs_token[-1] != "A" else "B")
    # alg=none forgery (no signature)
    none_tok = b64u(json.dumps({"alg": "none", "typ": "JWT", "kid": "rsa1"}).encode()) + "." + \
               b64u(json.dumps(claims).encode()) + "."

    # --- EC / ES256 (P-256) ---
    ec = os.path.join(d, "ec.pem")
    run(["openssl", "genpkey", "-algorithm", "EC", "-pkeyopt", "ec_paramgen_curve:P-256", "-out", ec])
    text = run(["openssl", "ec", "-in", ec, "-noout", "-text"]).stdout.decode()
    # parse the "pub:" hex block (04 || X || Y)
    lines = text.splitlines()
    hexbytes = []
    grab = False
    for ln in lines:
        s = ln.strip()
        if s.startswith("pub:"):
            grab = True
            continue
        if grab:
            if ":" in s and all(c in "0123456789abcdef:" for c in s):
                hexbytes += s.split(":")
            else:
                break
    pub = bytes(int(h, 16) for h in hexbytes if h)
    assert pub[0] == 0x04 and len(pub) == 65, f"unexpected EC point len {len(pub)}"
    x, y = pub[1:33], pub[33:65]
    ec_jwks = {"keys": [{"kty": "EC", "kid": "ec1", "alg": "ES256", "crv": "P-256", "use": "sig", "x": b64u(x), "y": b64u(y)}]}
    es_token = make_jwt({"alg": "ES256", "typ": "JWT", "kid": "ec1"}, claims, ec, ec=True)

    out = {
        "HEY_JOSE_ISS": iss,
        "HEY_JOSE_AUD": aud,
        "HEY_JOSE_RS256_TOKEN": rs_token,
        "HEY_JOSE_RS256_JWKS": json.dumps(rsa_jwks),
        "HEY_JOSE_TAMPERED_TOKEN": tampered,
        "HEY_JOSE_NONE_TOKEN": none_tok,
        "HEY_JOSE_ES256_TOKEN": es_token,
        "HEY_JOSE_ES256_JWKS": json.dumps(ec_jwks),
    }
    for k, v in out.items():
        # single-quote for safe shell sourcing
        print(f"export {k}='{v}'")

if __name__ == "__main__":
    main()
