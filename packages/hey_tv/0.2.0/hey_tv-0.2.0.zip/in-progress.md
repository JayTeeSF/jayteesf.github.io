# In progress

- Validate the first independent Apple TV, Android TV, and party-room consumers.
