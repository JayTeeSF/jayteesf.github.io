# Framework-created classes are named in AndroidManifest.xml. Keep their
# identity and constructor; direct references and Android overrides are traced.
-keep,allowoptimization class hey.android.api.HeyAndroidApiActivity {
    public <init>();
}
-keep,allowoptimization class hey.android.api.HeyAndroidAudioService {
    public <init>();
}
-keep,allowoptimization class hey.android.api.HeyAndroidShareProvider {
    public <init>();
}
# Preserve useful stack locations for the private per-release mapping.
-keepattributes SourceFile,LineNumberTable
