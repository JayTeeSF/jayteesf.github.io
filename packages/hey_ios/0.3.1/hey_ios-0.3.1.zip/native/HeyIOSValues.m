#import "HeyIOSValues.h"
#import <CommonCrypto/CommonDigest.h>

const NSInteger HeyIOSRendererLevel = 2;
NSString *const HeyIOSRendererPlatform = @"ios";
NSString *const HeyIOSDescriptionSchema = @"hey-mobile-api-app-v1";
const NSUInteger HeyIOSDescriptionMaxBytes = 2000000;

#pragma mark - values

NSDictionary *HeyIOSDict(id value) { return [value isKindOfClass:[NSDictionary class]] ? value : @{}; }
NSArray *HeyIOSArray(id value) { return [value isKindOfClass:[NSArray class]] ? value : @[]; }

BOOL HeyIOSIsBoolean(id value) {
  return [value isKindOfClass:[NSNumber class]] && CFGetTypeID((__bridge CFTypeRef)value) == CFBooleanGetTypeID();
}

NSString *HeyIOSString(id value) {
  if ([value isKindOfClass:[NSString class]]) return value;
  if (HeyIOSIsBoolean(value)) return [value boolValue] ? @"true" : @"false";
  if ([value isKindOfClass:[NSNumber class]]) return [value stringValue];
  return @"";
}

static BOOL HeyIOSDigits(NSString *s) {
  if (s.length == 0) return NO;
  NSUInteger i = [s hasPrefix:@"-"] ? 1 : 0;
  if (i == s.length) return NO;
  for (; i < s.length; i++) {
    unichar c = [s characterAtIndex:i];
    if (c < '0' || c > '9') return NO;
  }
  return YES;
}

NSInteger HeyIOSInteger(id value) {
  if (HeyIOSIsBoolean(value)) return 0;
  if ([value isKindOfClass:[NSNumber class]]) return [value integerValue];
  if ([value isKindOfClass:[NSString class]] && HeyIOSDigits(value)) return [value integerValue];
  return 0;
}

id HeyIOSAt(id json, NSString *path) {
  if (![path isKindOfClass:[NSString class]] || path.length == 0) return nil;
  id cur = json;
  for (NSString *part in [path componentsSeparatedByString:@"."]) {
    if (![cur isKindOfClass:[NSDictionary class]]) return nil;
    cur = cur[part];
    if (cur == nil || cur == [NSNull null]) return nil;
  }
  return cur;
}

// THE WHOLE SCALE, ALWAYS FIVE. "★★★½" read as three stars on a phone: a
// rating is a position on a scale, so the empty stars are drawn too. The text
// carries ★ (full), ⯪ (half) and ☆ (empty); the host swaps them for the
// system's star symbols wherever the line is shown.
// AND THE NUMBER AFTER IT, "★★★⯪☆ 3.5": the shape is what people read, the
// number settles a half. The first app's gate compiles this function on its
// own and checks every value from 0 to 10 halves (a 5 once drew six stars).
NSString *HeyIOSStars(NSInteger halves) {
  if (halves <= 0) return @"";
  if (halves > 10) halves = 10;
  NSMutableString *s = [NSMutableString string];
  for (NSInteger i = 1; i <= 5; i++) {
    if (i * 2 <= halves) [s appendString:@"★"];
    else if (i * 2 == halves + 1) [s appendString:@"⯪"];
    else [s appendString:@"☆"];
  }
  [s appendFormat:@" %g", halves / 2.0];
  return s;
}

// Seconds as "42 min", "1 h" or "1 h 5 min"; nothing when unknown.
NSString *HeyIOSDuration(NSInteger seconds) {
  if (seconds <= 0) return @"";
  NSInteger minutes = MAX(1, (seconds + 30) / 60);
  if (minutes < 60) return [NSString stringWithFormat:@"%ld min", (long)minutes];
  NSInteger rest = minutes % 60;
  return rest == 0 ? [NSString stringWithFormat:@"%ld h", (long)(minutes / 60)] : [NSString stringWithFormat:@"%ld h %ld min", (long)(minutes / 60), (long)rest];
}

NSString *HeyIOSFormat(NSString *inner, id obj, NSDictionary *labels) {
  NSRange colon = [inner rangeOfString:@":"];
  NSString *mod = colon.location == NSNotFound ? @"" : [inner substringToIndex:colon.location];
  NSString *path = colon.location == NSNotFound ? inner : [inner substringFromIndex:colon.location + 1];
  id raw = HeyIOSAt(obj, path);
  NSString *text = HeyIOSString(raw);
  if (mod.length == 0) return text;
  if ([mod isEqualToString:@"label"]) {
    NSString *label = HeyIOSString(HeyIOSDict(labels)[text]);
    return label.length > 0 ? label : text;
  }
  if ([mod isEqualToString:@"date"]) return text.length >= 10 ? [text substringToIndex:10] : text;
  if ([mod isEqualToString:@"duration"]) return HeyIOSDuration(HeyIOSInteger(raw));
  if ([mod isEqualToString:@"stars"]) return HeyIOSStars(HeyIOSInteger(raw));
  // An unknown modifier is an empty placeholder: the template is hidden.
  return @"";
}

// 'title' is a path; 'From {sharer}' is a template that renders as nothing when
// any placeholder is empty.
NSString *HeyIOSRender(id spec, id obj, NSDictionary *labels) {
  if (![spec isKindOfClass:[NSString class]]) return @"";
  NSString *s = spec;
  if (s.length == 0) return @"";
  if ([s rangeOfString:@"{"].location == NSNotFound) return HeyIOSString(HeyIOSAt(obj, s));
  NSMutableString *out = [NSMutableString string];
  NSUInteger at = 0;
  while (at < s.length) {
    NSRange open = [s rangeOfString:@"{" options:0 range:NSMakeRange(at, s.length - at)];
    if (open.location == NSNotFound) { [out appendString:[s substringFromIndex:at]]; break; }
    [out appendString:[s substringWithRange:NSMakeRange(at, open.location - at)]];
    NSRange close = [s rangeOfString:@"}" options:0 range:NSMakeRange(open.location, s.length - open.location)];
    if (close.location == NSNotFound) break;
    NSString *value = HeyIOSFormat([s substringWithRange:NSMakeRange(open.location + 1, close.location - open.location - 1)], obj, labels);
    if (value.length == 0) return @"";
    [out appendString:value];
    at = close.location + 1;
  }
  return out;
}

NSString *HeyIOSLine(id spec, id obj, NSDictionary *labels) {
  if ([spec isKindOfClass:[NSString class]]) return HeyIOSRender(spec, obj, labels);
  if (![spec isKindOfClass:[NSArray class]]) return @"";
  NSMutableArray *parts = [NSMutableArray array];
  for (id piece in spec) {
    NSString *text = HeyIOSRender(HeyIOSString(piece), obj, labels);
    if (text.length > 0) [parts addObject:text];
  }
  // A no-break space before the dot keeps it with the word before it, so a
  // wrapped line never starts with "· 2026".
  return [parts componentsJoinedByString:@" · "];
}

// Text that is a template only when it has a {placeholder}; otherwise literal.
NSString *HeyIOSText(id spec, id obj, NSDictionary *labels) {
  NSString *s = HeyIOSString(spec);
  if ([s rangeOfString:@"{"].location == NSNotFound) return s;
  return HeyIOSRender(s, obj, labels);
}

BOOL HeyIOSTruthyValue(id value) {
  if (value == nil || value == [NSNull null]) return NO;
  if ([value isKindOfClass:[NSString class]]) return [(NSString *)value length] > 0;
  if ([value isKindOfClass:[NSNumber class]]) return [value doubleValue] != 0;
  if ([value isKindOfClass:[NSArray class]]) return [(NSArray *)value count] > 0;
  return YES;
}

BOOL HeyIOSTruthy(id row, NSString *path) {
  if (path.length == 0) return NO;
  return HeyIOSTruthyValue(HeyIOSAt(row, path));
}

static BOOL HeyIOSPresent(NSDictionary *d, NSString *key) {
  id v = d[key];
  return v != nil && v != [NSNull null];
}

// nil, 'field', '!field', [all of these], or {field, equals | not | in}
// against a row or the screen's JSON; values compare as text.
BOOL HeyIOSCondition(id spec, id obj) {
  if ([spec isKindOfClass:[NSString class]]) {
    NSString *s = spec;
    BOOL negate = [s hasPrefix:@"!"];
    if (negate) s = [s substringFromIndex:1];
    BOOL truthy = HeyIOSTruthyValue(HeyIOSAt(obj, s));
    return negate ? !truthy : truthy;
  }
  if ([spec isKindOfClass:[NSArray class]]) {
    for (id part in spec) if (!HeyIOSCondition(part, obj)) return NO;
    return YES;
  }
  if (![spec isKindOfClass:[NSDictionary class]]) return YES;
  NSDictionary *d = spec;
  NSString *value = HeyIOSString(HeyIOSAt(obj, HeyIOSString(d[@"field"])));
  if (HeyIOSPresent(d, @"equals")) return [value isEqualToString:HeyIOSString(d[@"equals"])];
  if (HeyIOSPresent(d, @"not")) return ![value isEqualToString:HeyIOSString(d[@"not"])];
  if (HeyIOSPresent(d, @"in")) {
    for (id option in HeyIOSArray(d[@"in"])) if ([HeyIOSString(option) isEqualToString:value]) return YES;
    return NO;
  }
  return YES;
}

// '$name' and '@name' read a variable or a row field; a trailing '?' makes the
// key optional: nil (left out of the body) when the value is empty or absent.
id HeyIOSValue(id spec, NSDictionary *vars, id row) {
  if (![spec isKindOfClass:[NSString class]]) return spec;
  NSString *s = spec;
  if (![s hasPrefix:@"$"] && ![s hasPrefix:@"@"]) return s;
  BOOL optional = [s hasSuffix:@"?"];
  NSString *name = [s substringWithRange:NSMakeRange(1, s.length - 1 - (optional ? 1 : 0))];
  id value = [s hasPrefix:@"$"] ? HeyIOSDict(vars)[name] : HeyIOSAt(row, name);
  if (value == [NSNull null]) value = nil;
  BOOL empty = value == nil || ([value isKindOfClass:[NSString class]] && [(NSString *)value length] == 0) || ([value isKindOfClass:[NSArray class]] && [(NSArray *)value count] == 0);
  if (empty) return optional ? nil : @"";
  return value;
}

// '$name' a variable, '=word' the word, anything else a path read from the
// row and then from the screen's answer.
NSString *HeyIOSParam(id spec, NSDictionary *vars, id row, id json) {
  NSString *p = HeyIOSString(spec);
  if ([p hasPrefix:@"$"]) return HeyIOSString(HeyIOSDict(vars)[[p substringFromIndex:1]]);
  if ([p hasPrefix:@"="]) return [p substringFromIndex:1];
  NSString *fromRow = HeyIOSString(HeyIOSAt(row, p));
  return fromRow.length > 0 ? fromRow : HeyIOSString(HeyIOSAt(json, p));
}

NSString *HeyIOSFillPath(NSString *path, NSDictionary *vars) {
  NSMutableString *out = [path mutableCopy];
  NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!$&'()*+,-.:;=@_~"];
  for (NSString *key in HeyIOSDict(vars)) {
    NSString *token = [NSString stringWithFormat:@"{%@}", key];
    NSString *value = [HeyIOSString(vars[key]) stringByAddingPercentEncodingWithAllowedCharacters:allowed] ?: @"";
    [out replaceOccurrencesOfString:token withString:value options:0 range:NSMakeRange(0, out.length)];
  }
  return out;
}

#pragma mark - kinds

static NSArray *HeyIOSScreenTypes(NSInteger level) {
  return level <= 1 ? @[@"list", @"form", @"search", @"audio", @"detail"] : @[@"list", @"form", @"search", @"audio"];
}
static NSArray *HeyIOSSectionKinds(void) { return @[@"fields", @"actions", @"rows", @"from", @"route"]; }
static NSArray *HeyIOSActionKinds(void) { return @[@"request", @"open_url", @"open_screen", @"video", @"share", @"copy", @"rating", @"web_sign_in", @"document", @"set_var", @"choose"]; }
static NSArray *HeyIOSFieldKinds(void) { return @[@"text", @"secure", @"new_secure", @"url", @"prose", @"multiline", @"choice", @"rating", @"code", @"number"]; }
static NSArray *HeyIOSRowKinds(void) { return @[@"screen", @"action", @"text"]; }

NSString *HeyIOSActionKind(id action) {
  NSString *kind = HeyIOSString(HeyIOSDict(action)[@"kind"]);
  return kind.length > 0 ? kind : @"request";
}

// A section's kind: an explicit kind, else the key it is shaped by: 'fields'
// (label and value from the screen's JSON), 'actions' (buttons), 'rows' (a
// literal list), 'from' (an array inside the screen's JSON), or a route.
NSString *HeyIOSSectionKind(id section) {
  NSDictionary *spec = HeyIOSDict(section);
  if (HeyIOSPresent(spec, @"kind")) return HeyIOSString(spec[@"kind"]);
  if ([spec[@"fields"] isKindOfClass:[NSArray class]]) return @"fields";
  if ([spec[@"actions"] isKindOfClass:[NSArray class]]) return @"actions";
  if ([spec[@"rows"] isKindOfClass:[NSArray class]]) return @"rows";
  if (HeyIOSPresent(spec, @"from")) return @"from";
  return @"route";
}

NSString *HeyIOSRowKind(id row) {
  NSDictionary *d = HeyIOSDict(row);
  if (HeyIOSPresent(d, @"kind")) return HeyIOSString(d[@"kind"]);
  if (HeyIOSPresent(d, @"action")) return @"action";
  if (HeyIOSPresent(d, @"screen")) return @"screen";
  return @"text";
}

static BOOL HeyIOSKnownActionAt(id action, NSInteger level) {
  if (![action isKindOfClass:[NSDictionary class]]) return NO;
  if (![HeyIOSActionKinds() containsObject:HeyIOSActionKind(action)]) return NO;
  if (HeyIOSPresent(action, @"then_action")) return HeyIOSKnownActionAt(action[@"then_action"], level);
  return YES;
}

BOOL HeyIOSKnown(NSString *category, id element, NSInteger level) {
  NSDictionary *d = HeyIOSDict(element);
  if ([category isEqualToString:@"screen"]) return [HeyIOSScreenTypes(level) containsObject:HeyIOSString(d[@"type"])];
  if ([category isEqualToString:@"section"]) return [HeyIOSSectionKinds() containsObject:HeyIOSSectionKind(d)];
  if ([category isEqualToString:@"action"]) return HeyIOSKnownActionAt(element, level);
  if ([category isEqualToString:@"field"]) return [HeyIOSFieldKinds() containsObject:HeyIOSString(d[@"kind"])];
  if ([category isEqualToString:@"row"]) {
    NSString *kind = HeyIOSRowKind(d);
    if (![HeyIOSRowKinds() containsObject:kind]) return NO;
    if ([kind isEqualToString:@"action"]) return HeyIOSKnownActionAt(d[@"action"], level);
    return YES;
  }
  return NO;
}

BOOL HeyIOSKnownAction(id action) { return HeyIOSKnown(@"action", action, HeyIOSRendererLevel); }
BOOL HeyIOSKnownScreen(id screen) { return HeyIOSKnown(@"screen", screen, HeyIOSRendererLevel); }
BOOL HeyIOSKnownSection(id section) { return HeyIOSKnown(@"section", section, HeyIOSRendererLevel); }
BOOL HeyIOSKnownField(id field) { return HeyIOSKnown(@"field", field, HeyIOSRendererLevel); }
BOOL HeyIOSKnownRow(id row) { return HeyIOSKnown(@"row", row, HeyIOSRendererLevel); }

#pragma mark - names

NSDictionary<NSString *, NSString *> *HeyIOSIconTable(void) {
  static NSDictionary *table;
  static dispatch_once_t once;
  dispatch_once(&once, ^{
    table = @{
      @"library": @"books.vertical", @"search": @"magnifyingglass", @"add": @"plus.circle", @"headphones": @"headphones",
      @"people": @"person.2", @"person": @"person.crop.circle", @"person_add": @"person.badge.plus",
      @"person_remove": @"person.crop.circle.badge.minus", @"person_key": @"person.badge.key",
      @"video": @"play.rectangle", @"tv": @"tv", @"tv_box": @"appletv", @"movie": @"film", @"book": @"book.closed",
      @"mic": @"mic", @"music": @"music.note", @"article": @"doc.plaintext", @"read_aloud": @"text.book.closed",
      @"radio": @"antenna.radiowaves.left.and.right", @"document": @"doc.text", @"photo": @"photo",
      @"photo_frame": @"photo.on.rectangle", @"photo_check": @"photo.badge.checkmark", @"link": @"link",
      @"link_circle": @"link.circle", @"open_external": @"arrow.up.right.square", @"tag": @"number",
      @"stack": @"square.stack", @"stack_shared": @"square.stack.3d.up", @"stack_add": @"plus.square.on.square",
      @"screen_add": @"plus.rectangle.on.rectangle", @"grid": @"square.grid.2x2", @"edit": @"square.and.pencil",
      @"edit_line": @"pencil.line", @"pencil": @"pencil", @"delete": @"trash", @"check": @"checkmark",
      @"check_circle": @"checkmark.circle", @"check_stack": @"checkmark.rectangle.stack", @"close": @"xmark",
      @"cancel_circle": @"xmark.circle", @"remove_circle": @"minus.circle", @"send": @"paperplane",
      @"share": @"square.and.arrow.up", @"import": @"square.and.arrow.down", @"download": @"arrow.down.circle",
      @"upgrade": @"arrow.up.circle", @"arrow_up": @"arrow.up", @"arrow_down": @"arrow.down",
      @"arrow_down_line": @"arrow.down.to.line", @"arrow_forward_circle": @"arrow.right.circle",
      @"undo": @"arrow.uturn.backward", @"refresh": @"arrow.clockwise", @"history": @"clock.arrow.circlepath",
      @"mail": @"envelope", @"mail_open": @"envelope.open", @"inbox": @"tray", @"inbox_out": @"tray.and.arrow.down",
      @"bell": @"bell", @"gift": @"gift", @"hand": @"hand.raised", @"seen": @"eye", @"not_seen": @"eye.slash",
      @"help": @"questionmark.circle", @"info": @"info.circle", @"warning": @"exclamationmark.triangle",
      @"play_circle": @"play.circle", @"play_tv": @"play.tv", @"sliders": @"slider.horizontal.3", @"ruler": @"ruler",
      @"key": @"key", @"lock": @"lock", @"sign_out": @"rectangle.portrait.and.arrow.right", @"phone_off": @"iphone.slash",
      @"settings": @"gearshape", @"list": @"list.bullet", @"folder": @"folder", @"calendar": @"calendar",
      @"web": @"globe", @"star": @"star", @"qr_code": @"qrcode"
    };
  });
  return table;
}

NSDictionary<NSString *, NSArray<NSString *> *> *HeyIOSFileKindTable(void) {
  return @{@"csv": @[@"public.comma-separated-values-text"], @"json": @[@"public.json"], @"text": @[@"public.plain-text"]};
}

NSString *HeyIOSSymbolName(NSString *name) {
  if (![name isKindOfClass:[NSString class]] || name.length == 0) return nil;
  return HeyIOSIconTable()[name] ?: name;
}

NSArray<NSString *> *HeyIOSTypeIdentifiers(NSDictionary *action) {
  NSMutableArray *out = [NSMutableArray array];
  NSArray *accept = HeyIOSArray(action[@"accept"]);
  NSArray *source = accept.count > 0 ? accept : HeyIOSArray(action[@"types"]);
  for (id entry in source) {
    NSString *name = HeyIOSString(entry);
    NSArray *ids = HeyIOSFileKindTable()[name] ?: (name.length > 0 ? @[name] : @[]);
    for (NSString *identifier in ids) if (![out containsObject:identifier]) [out addObject:identifier];
  }
  return out;
}

#pragma mark - served descriptions

NSString *HeyIOSSHA256Hex(NSData *data) {
  unsigned char digest[CC_SHA256_DIGEST_LENGTH];
  CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
  NSMutableString *hex = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
  for (int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++) [hex appendFormat:@"%02x", digest[i]];
  return hex;
}

static NSString *HeyIOSETagHash(NSString *header) {
  NSString *s = [header stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
  if ([s hasPrefix:@"W/"]) s = [s substringFromIndex:2];
  s = [s stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"\""]];
  if (s.length != 64) return nil;
  NSCharacterSet *hex = [NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdefABCDEF"];
  if ([s rangeOfCharacterFromSet:hex.invertedSet].location != NSNotFound) return nil;
  return s.lowercaseString;
}

NSString *HeyIOSDescriptionRefusal(NSData *body, NSString *etagHeader, NSDictionary **parsed) {
  if (parsed) *parsed = nil;
  if (body.length > HeyIOSDescriptionMaxBytes) return @"too_large";
  NSString *claimed = etagHeader.length > 0 ? HeyIOSETagHash(etagHeader) : nil;
  if (claimed != nil && ![claimed isEqualToString:HeyIOSSHA256Hex(body ?: [NSData data])]) return @"etag";
  id json = body.length > 0 ? [NSJSONSerialization JSONObjectWithData:body options:0 error:nil] : nil;
  if (json == nil) return @"not_json";
  if (![json isKindOfClass:[NSDictionary class]]) return @"not_object";
  NSDictionary *d = json;
  if (![HeyIOSString(d[@"schema"]) isEqualToString:HeyIOSDescriptionSchema] || ![d[@"schema"] isKindOfClass:[NSString class]]) return @"schema";
  id level = d[@"level"];
  if (![level isKindOfClass:[NSNumber class]] || HeyIOSIsBoolean(level) || [level doubleValue] != floor([level doubleValue]) || [level integerValue] < 1 || [level integerValue] > HeyIOSRendererLevel) return @"level";
  if (![d[@"platform"] isKindOfClass:[NSString class]] || ![d[@"platform"] isEqualToString:HeyIOSRendererPlatform]) return @"platform";
  if (![d[@"screens"] isKindOfClass:[NSArray class]] || [d[@"screens"] count] == 0) return @"screens";
  NSMutableDictionary *byID = [NSMutableDictionary dictionary];
  for (id screen in d[@"screens"]) {
    if (![screen isKindOfClass:[NSDictionary class]] || ![screen[@"id"] isKindOfClass:[NSString class]] || ![screen[@"type"] isKindOfClass:[NSString class]]) return @"screens";
    byID[screen[@"id"]] = screen;
  }
  if (![d[@"tabs"] isKindOfClass:[NSArray class]]) return @"tabs";
  BOOL anyDrawn = NO;
  for (id tab in d[@"tabs"]) {
    NSDictionary *screen = [tab isKindOfClass:[NSString class]] ? byID[tab] : nil;
    if (screen == nil) return @"tabs";
    if (HeyIOSKnownScreen(screen)) anyDrawn = YES;
  }
  if (!anyDrawn) return @"tabs";
  NSDictionary *signIn = byID[HeyIOSString(HeyIOSDict(d[@"session"])[@"sign_in_screen"])];
  if (signIn == nil || !HeyIOSKnownScreen(signIn)) return @"sign_in";
  if (parsed) *parsed = d;
  return nil;
}

NSData *HeyIOSDescriptionPick(NSData *baked, NSData *stored, NSData *served, NSString *servedETag, NSString **source) {
  if (served != nil && HeyIOSDescriptionRefusal(served, servedETag, NULL) == nil) {
    if (source) *source = @"served";
    return served;
  }
  if (stored != nil && HeyIOSDescriptionRefusal(stored, nil, NULL) == nil) {
    if (source) *source = @"stored";
    return stored;
  }
  if (source) *source = @"baked";
  return baked;
}

NSDictionary *HeyIOSDescriptionMerged(NSDictionary *served, NSDictionary *baked) {
  NSMutableDictionary *out = [served mutableCopy];
  [out removeObjectForKey:@"origin"];
  for (NSString *key in @[@"keychain_service", @"url_scheme", @"served", @"find_fixture"]) {
    if (baked[key] != nil) out[key] = baked[key]; else [out removeObjectForKey:key];
  }
  NSMutableDictionary *session = [HeyIOSDict(served[@"session"]) mutableCopy];
  NSDictionary *bakedSession = HeyIOSDict(baked[@"session"]);
  for (NSString *key in @[@"header", @"prefix", @"check", @"sign_out"]) {
    if (bakedSession[key] != nil) session[key] = bakedSession[key]; else [session removeObjectForKey:key];
  }
  out[@"session"] = session;
  return out;
}
