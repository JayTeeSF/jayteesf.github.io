# Done

- Added SQLite and MySQL dialect descriptors.
- Added parameterized select/insert/update/delete plans.
- Added immutable datasets, safe order helpers, transactions, model descriptors, and adapter-aware migration DDL.
- Preserved explicit connection injection and independent driver releases.
