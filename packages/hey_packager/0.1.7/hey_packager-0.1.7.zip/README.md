# hey_packager

`hey_packager` is package-owned porcelain for releasing and publishing Hey
packages. It keeps website-specific policy out of `stdlib:Packages` while giving
every package the same verified ZIP, release metadata, checksums, documentation,
source handoff, and immutable registry workflow.

```sh
bin/hey-packager --help
bin/check
bin/release
bin/publish
```

The default website registry is:

```text
$HOME/dev/jayteesf.github.io/packages
```

Override it with `--registry-root` or `HEY_PACKAGE_REGISTRY_ROOT`.

## Standard package controls

Adopt `hey_packager` by declaring `"hey_packager": ">=0.1.1 <0.2.0"` and copying its canonical `bin/hey-packager`, `bin/check`, `bin/bump`, `bin/release`, `bin/publish`, `bin/package-zip`, and `bin/source-zip`. `bin/release` only builds release artifacts under `dist/`; `bin/publish` is the separate step that copies the version into the registry and commits it there (it never pushes).

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish
```

`bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_packager`; bump first with `bin/bump VERSION` (the script supplies the package root). Pass `--no-commit` to leave the registry checkout uncommitted.
