package hey.android.api;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

/**
 * The build tool's check of the description it is about to bake:
 *
 *   java hey.android.api.BakeCheckMain DESCRIPTION_FILE
 *
 * Exits 0 and prints "ok sha256=... level=N platform=android screens=N tabs=N
 * drawn_tabs=N sign_in=ID" when this renderer takes the bytes as they are;
 * exits 1 naming the refusal otherwise. An APK never ships a baked copy its
 * own renderer would refuse.
 */
public final class BakeCheckMain {
  public static void main(String[] args) throws Exception {
    if (args.length != 1) {
      System.err.println("usage: BakeCheckMain DESCRIPTION_FILE");
      System.exit(2);
    }
    byte[] body = Files.readAllBytes(Paths.get(args[0]));
    String refusal = Descriptions.refusal(body, null);
    if (refusal != null) {
      System.out.println("refused " + refusal);
      System.exit(1);
    }
    Map<String, Object> d = Json.dict(Json.parse(body));
    int drawn = 0;
    for (Object t : Json.list(d.get("tabs"))) {
      for (Object s : Json.list(d.get("screens"))) {
        if (Values.string(Json.dict(s).get("id")).equals(Values.string(t)) && Screens.drawsScreen(s)) drawn++;
      }
    }
    String signIn = Values.string(Json.dict(d.get("session")).get("sign_in_screen"));
    System.out.println("ok sha256=" + Descriptions.sha256Hex(body) + " level=" + Values.string(d.get("level")) + " platform=" + Values.string(d.get("platform"))
        + " screens=" + Json.list(d.get("screens")).size() + " tabs=" + Json.list(d.get("tabs")).size() + " drawn_tabs=" + drawn + " sign_in=" + signIn
        + " served=" + Values.string(Json.dict(d.get("served")).get("path")));
  }
}
