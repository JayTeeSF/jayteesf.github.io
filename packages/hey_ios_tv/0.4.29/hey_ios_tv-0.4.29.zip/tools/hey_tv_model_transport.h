#import <Foundation/Foundation.h>

// Generic native transport policy. Application UI, navigation and commands
// remain in bundled Hey; these helpers only construct/validate wire values.
static NSInteger HeyTVModelPort(NSURL *url) {
  if (url.port) { return url.port.integerValue; }
  return [url.scheme.lowercaseString isEqualToString:@"https"] ? 443 : 80;
}

static BOOL HeyTVModelSameOrigin(NSURL *a, NSURL *b) {
  if (!a || !b || a.user.length || a.password.length || b.user.length || b.password.length) { return NO; }
  NSString *scheme = a.scheme.lowercaseString;
  if (![scheme isEqualToString:@"https"] && ![scheme isEqualToString:@"http"]) { return NO; }
  return a.host.length && [scheme isEqualToString:b.scheme.lowercaseString]
      && [a.host.lowercaseString isEqualToString:b.host.lowercaseString]
      && HeyTVModelPort(a) == HeyTVModelPort(b);
}

static BOOL HeyTVModelShouldRedirect(void) { return NO; }

static NSMutableURLRequest *HeyTVModelRequest(NSDictionary *fetch, NSURL *origin, NSString *device) {
  NSString *address = [fetch[@"url"] isKindOfClass:NSString.class] ? fetch[@"url"] : nil;
  NSURL *url = address ? [NSURL URLWithString:address] : nil;
  NSString *schema = [fetch[@"schema"] isKindOfClass:NSString.class] ? fetch[@"schema"] : nil;
  if (!HeyTVModelSameOrigin(url, origin) || !schema.length || [schema isEqualToString:@"hey-tv-scene-v2"]) { return nil; }
  NSString *method = [fetch[@"method"] isKindOfClass:NSString.class] ? fetch[@"method"] : @"GET";
  if (![method isEqualToString:@"GET"] && ![method isEqualToString:@"POST"]) { return nil; }
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:12];
  request.HTTPMethod = method;
  request.HTTPShouldHandleCookies = NO;
  [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
  NSString *credential = [fetch[@"credential"] isKindOfClass:NSString.class] ? fetch[@"credential"] : @"";
  if (credential.length) {
    if (![credential isEqualToString:@"device"] || !device.length) { return nil; }
    [request setValue:[@"Bearer " stringByAppendingString:device] forHTTPHeaderField:@"Authorization"];
  }
  if ([method isEqualToString:@"POST"]) {
    id body = fetch[@"body"] ?: @{};
    if (![body isKindOfClass:NSDictionary.class] || ![NSJSONSerialization isValidJSONObject:body]) { return nil; }
    request.HTTPBody = [NSJSONSerialization dataWithJSONObject:body options:0 error:NULL];
    if (!request.HTTPBody) { return nil; }
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
  }
  return request;
}

static NSDictionary *HeyTVModelEvent(NSData *bytes, NSString *schema, NSString *identifier, NSInteger status) {
  // A response must be a complete UTF-8 JSON object of the locally requested
  // schema before Hey sees it. No remotely fetched value is a scene.
  if (!bytes.length || bytes.length > 8 * 1024 * 1024 || !schema.length) { return nil; }
  NSString *body = [[NSString alloc] initWithData:bytes encoding:NSUTF8StringEncoding];
  if (!body) { return nil; }
  id parsed = [NSJSONSerialization JSONObjectWithData:bytes options:0 error:NULL];
  if (![parsed isKindOfClass:NSDictionary.class] || ![parsed[@"schema"] isEqual:schema]) { return nil; }
  return @{@"kind": @"data", @"id": identifier ?: @"", @"status": @(status), @"body": body, @"data": parsed};
}

static NSTimeInterval HeyTVModelRetryDelay(NSUInteger failures) {
  NSTimeInterval seconds = 1;
  for (NSUInteger i = 1; i < failures && seconds < 60; i++) { seconds *= 2; }
  return MIN(seconds, 60);
}

// The credential never follows even a same-origin redirect. Applications use
// stable API paths; a redirect is an error retried by the original request.
@interface HeyTVModelSessionDelegate : NSObject <NSURLSessionTaskDelegate>
@end
@implementation HeyTVModelSessionDelegate
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task
    willPerformHTTPRedirection:(NSHTTPURLResponse *)response newRequest:(NSURLRequest *)request
    completionHandler:(void (^)(NSURLRequest *))completionHandler {
  (void)session; (void)task; (void)response; (void)request;
  completionHandler(HeyTVModelShouldRedirect() ? request : nil);
}
@end

// Bundled search keyboard. The system keyboard is the same one legacy scenes
// get; in a bundled app its text reaches tv_scene_step only as a JSON string
// value inside an event, never formatted into a URL, path or fetch. The app
// carries it onward in a POST body of its own model fetch.
static NSString *HeyTVKeyboardText(NSString *raw) {
  return [(raw ?: @"") stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
}

// {"kind":"keyboard","text":...}, {"kind":"keyboard_pick","id":...},
// {"kind":"keyboard_closed","text":...}: one string field per event.
static NSString *HeyTVKeyboardEvent(NSString *kind, NSString *field, NSString *value) {
  if (!kind.length || !field.length) { return nil; }
  NSDictionary *event = @{@"kind": kind, field: value ?: @""};
  NSData *json = [NSJSONSerialization dataWithJSONObject:event options:NSJSONWritingWithoutEscapingSlashes error:NULL];
  return json ? [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding] : nil;
}

// A bundled results tile is picked by its grid item `id`; a tile without one
// is drawn but cannot be picked. Its `select` path is never followed.
static NSString *HeyTVKeyboardTileId(id item) {
  if (![item isKindOfClass:NSDictionary.class]) { return nil; }
  id identifier = ((NSDictionary *)item)[@"id"];
  return [identifier isKindOfClass:NSString.class] && [identifier length] ? identifier : nil;
}

// Everything the keyboard's results view draws from a document, by the legacy
// results rule: the first grid, the `more` count line, the QR payload and the
// `scan` caption. Equal signatures draw the same results.
static NSString *HeyTVKeyboardResultsSignature(NSDictionary *scene) {
  NSArray *widgets = [scene[@"widgets"] isKindOfClass:NSArray.class] ? scene[@"widgets"] : @[];
  id grid = NSNull.null, more = NSNull.null, qr = NSNull.null, scan = NSNull.null;
  for (id raw in widgets) {
    if (![raw isKindOfClass:NSDictionary.class]) { continue; }
    NSDictionary *w = raw;
    if (grid == NSNull.null && [w[@"kind"] isEqual:@"grid"]) { grid = w; }
    if ([w[@"id"] isEqual:@"more"] && [w[@"text"] isKindOfClass:NSString.class]) { more = w[@"text"]; }
    if ([w[@"kind"] isEqual:@"qr"] && [w[@"payload"] isKindOfClass:NSString.class]) { qr = w[@"payload"]; }
    if ([w[@"id"] isEqual:@"scan"] && [w[@"text"] isKindOfClass:NSString.class]) { scan = w[@"text"]; }
  }
  NSArray *parts = @[grid, more, qr, scan];
  if (![NSJSONSerialization isValidJSONObject:parts]) { return [NSUUID UUID].UUIDString; }
  NSData *json = [NSJSONSerialization dataWithJSONObject:parts options:NSJSONWritingSortedKeys error:NULL];
  return json ? [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding] : [NSUUID UUID].UUIDString;
}
