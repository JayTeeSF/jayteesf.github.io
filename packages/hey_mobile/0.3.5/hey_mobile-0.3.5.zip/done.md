# Done

- v0.1.0 lifecycle state/effects.
- Enrollment payload validation and development/release transport policy.
- Screen/action/accessibility descriptors and test doubles.
- Removed release tooling from runtime dependencies and adopted `hey_packager` 0.1.2 controls.
- v0.2.0 `api_screens`: an app's screens bound to JSON routes, described in ordinary Hey and executed by a native host. Optional body values (`$name?`, `@name?`), rows already done (`done_when`), conditional selects (`when`), templates with labels, dates and half stars, audio position and share routes. `problems` names each fault with negative controls; `routes` lists every route from actions, menus, rows, forms and web links. First consumer: My Queue on iPhone through `hey_ios` 0.2.0.
- v0.3.0 levels and served descriptions: `for_level` fits a description to a renderer's level (min_level and instead, unknown kinds removed, spelled for the level); neutral icon names and file kinds; the update description; `values.hey` as the reference evaluator with 117 vectors, 21 served descriptions to take or refuse, and the icon table in `conformance/`; `docs/RENDERERS.md`. First renderer: `hey_ios` 0.3.0; first server: My Queue's `GET /v1/app/description`.
- v0.3.1: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes.

- v0.3.5: optional header `image_open_url` contract, retained across platform/level fitting; safe HTTP(S) and accessible artwork behavior defined for both renderers.
