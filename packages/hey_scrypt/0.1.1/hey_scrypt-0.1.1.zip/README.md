# hey_scrypt

Bounded native scrypt password hashing with the modern Ruby scrypt-compatible hexadecimal storage format. Explicit work factors; no implicit cheap defaults or calibration. OpenSSL 3 is required.

See docs/README.md.
