package hey.android.api;
import android.content.Context;
final class HeyAndroidSecureStore {
  static String held;
  HeyAndroidSecureStore(Context c, String name) {}
  String read() { return held; }
  boolean write(String value) { held = value; return true; }
  void clear() { held = null; }
}
