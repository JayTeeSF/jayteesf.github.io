package hey.android.api;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.MediaDescription;
import android.media.MediaMetadata;
import android.media.browse.MediaBrowser;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.service.media.MediaBrowserService;
import android.util.Log;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * What a car talks to.
 *
 * <p>A CAR DRAWS ITS OWN SCREENS. Nothing this renderer knows how to draw
 * reaches a head unit: it asks for a tree of things to browse, shows that tree
 * in its own shape with its own controls, and presses this service's session.
 * So a car needs no renderer at all -- it needs the same feed the Listen tab
 * reads, handed over in the shape a car asks for.
 *
 * <p>THE TREE IS THE DESCRIPTION'S, NOT THIS FILE'S. The groupings a listener
 * sees in the car (started, not played yet, sent to you) are the sections of
 * the description's audio block, in its order and with its words. This file
 * knows no field names and invents no categories; the server decides what may
 * be played and how it is grouped, once, for every surface.
 *
 * <p>FRAMEWORK CLASSES ONLY, as everywhere in this renderer: this build is
 * javac and d8 against android.jar with no dependency manager, so it is
 * {@link MediaBrowserService} and {@link MediaSession} rather than the media
 * compat libraries the usual car documentation assumes.
 */
public final class HeyAndroidAudioService extends MediaBrowserService {
  static final String TAG = "hey.api";

  /** The tree's root, and the prefix of a section id. Opaque to everyone but this file. */
  private static final String ROOT = "root";
  private static final String SECTION = "section:";

  /** What the notification's own buttons send back here. */
  private static final String ACTION_PLAY_PAUSE = "hey.android.api.PLAY_PAUSE";
  private static final String ACTION_STOP = "hey.android.api.STOP";
  private static final String CHANNEL = "hey.android.api.playing";
  private static final int NOTE = 1;

  private HeyAndroidPlayback playback;
  private MediaSession session;
  /** The feed as last answered, so a browse and a play see the same thing. */
  private Object feed;
  /** Why the feed could not be read, so a car can say that instead of showing nothing. */
  private String trouble;

  @Override
  public void onCreate() {
    super.onCreate();
    playback = HeyAndroidPlayback.of(this);
    session = new MediaSession(this, "HeyAndroidAudio");
    session.setCallback(new Controls());
    setSessionToken(session.getSessionToken());
    playback.watch(this::publish);
    session.setActive(true);
    channel();
    publish();
    Log.i(TAG, "audio service: ready");
  }

  @Override
  public void onDestroy() {
    playback.unwatch(this::publish);
    session.release();
    super.onDestroy();
  }

  /**
   * WHO MAY BROWSE SOMEBODY'S QUEUE. Not everyone: this tree is one person's
   * library, and any app on the device could otherwise ask for it. Our own
   * package may, because it is us; a head unit may, because holding
   * MEDIA_CONTENT_CONTROL is a privilege only the system grants. Anything else
   * is refused, which is what returning null means here.
   */
  @Override
  public BrowserRoot onGetRoot(String packageName, int uid, Bundle hints) {
    if (uid == Process.myUid()) return new BrowserRoot(ROOT, null);
    boolean trusted = checkPermission(android.Manifest.permission.MEDIA_CONTENT_CONTROL, Process.myPid(), uid)
        == PackageManager.PERMISSION_GRANTED;
    if (trusted) return new BrowserRoot(ROOT, null);
    Log.i(TAG, "audio service: refused a browse from " + packageName);
    return null;
  }

  @Override
  public void onLoadChildren(String parentId, Result<List<MediaBrowser.MediaItem>> result) {
    // The answer comes from the network, so it is always detached and filled in
    // when the feed arrives: a car waits on a spinner rather than an empty list.
    result.detach();
    withFeed(() -> result.sendResult(children(parentId)));
  }

  private List<MediaBrowser.MediaItem> children(String parentId) {
    List<MediaBrowser.MediaItem> out = new ArrayList<>();
    List<Screens.AudioSection> sections = sections();
    if (ROOT.equals(parentId)) {
      // NOT SIGNED IN IS NOT AN EMPTY QUEUE. A car's own words for an empty
      // tree are "media isn't available", which is what it would also say
      // about somebody who simply has not signed in yet -- so the reason is
      // handed over as the one thing in the list, in the description's words.
      if (feed == null) {
        String said = trouble != null ? trouble : Values.string(playback.audio().get("signed_out"));
        if (said.isEmpty()) said = "Nothing to play yet.";
        MediaDescription only = new MediaDescription.Builder()
            .setMediaId("trouble")
            .setTitle(said)
            .build();
        out.add(new MediaBrowser.MediaItem(only, MediaBrowser.MediaItem.FLAG_BROWSABLE));
        return out;
      }
      for (Screens.AudioSection section : sections) {
        if (section.tracks.isEmpty()) continue;
        MediaDescription description = new MediaDescription.Builder()
            .setMediaId(SECTION + section.title)
            .setTitle(section.title)
            .setSubtitle(section.note)
            .build();
        out.add(new MediaBrowser.MediaItem(description, MediaBrowser.MediaItem.FLAG_BROWSABLE));
      }
      return out;
    }
    if (parentId == null || !parentId.startsWith(SECTION)) return out;
    String wanted = parentId.substring(SECTION.length());
    for (Screens.AudioSection section : sections) {
      if (!section.title.equals(wanted)) continue;
      for (Screens.Track track : section.tracks) {
        // ONLY WHAT CAN BE PLAYED IS OFFERED HERE. On a screen a row that will
        // not play is worth drawing with its reason next to it; in a car it is
        // a thing you press while driving and nothing happens.
        if (!track.playable) continue;
        MediaDescription.Builder description = new MediaDescription.Builder()
            .setMediaId(track.id)
            .setTitle(track.title)
            .setSubtitle(track.subtitle);
        if (HeyAndroidPictures.fetchable(track.image)) description.setIconUri(Uri.parse(track.image));
        out.add(new MediaBrowser.MediaItem(description.build(), MediaBrowser.MediaItem.FLAG_PLAYABLE));
      }
    }
    return out;
  }

  private List<Screens.AudioSection> sections() {
    Map<String, Object> audio = playback.audio();
    return Screens.audio(audio, feed, playback.description == null ? new LinkedHashMap<>() : playback.description.labels());
  }

  /** Ask for the feed if it is not in hand, then do the thing that needed it. */
  private void withFeed(Runnable then) {
    if (feed != null) {
      then.run();
      return;
    }
    Map<String, Object> source = Json.dict(playback.audio().get("source"));
    if (source.isEmpty()) {
      then.run();
      return;
    }
    playback.http.send(source, new LinkedHashMap<>(), null, (status, json, error) -> {
      if (error == null) {
        feed = json;
        trouble = null;
      } else {
        // A sign-in problem has the description's own sentence for it; anything
        // else is said as it came back, because a car cannot be asked to guess.
        trouble = status == 401 ? Values.string(playback.audio().get("signed_out")) : error;
        Log.i(TAG, "audio service: could not read the feed: " + error);
      }
      then.run();
    });
  }

  private Screens.Track find(String id) {
    for (Screens.AudioSection section : sections()) {
      for (Screens.Track track : section.tracks) {
        if (track.id.equals(id)) return track;
      }
    }
    return null;
  }

  /**
   * The buttons on the notification come back here rather than to an Activity,
   * so they work with no screen open at all.
   */
  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    String action = intent == null ? null : intent.getAction();
    if (ACTION_PLAY_PAUSE.equals(action)) {
      if (playback.player.state() == HeyAndroidPlayer.State.PLAYING) playback.player.pause();
      else playback.player.resume();
    } else if (ACTION_STOP.equals(action)) {
      playback.player.stop(false);
    }
    return START_NOT_STICKY;
  }

  private void channel() {
    NotificationManager notes = getSystemService(NotificationManager.class);
    if (notes == null || notes.getNotificationChannel(CHANNEL) != null) return;
    // LOW, and silent: this is a handle on something the listener already
    // started, not news. A channel that dings every time a page turns is a
    // channel people switch off, taking the controls with it.
    NotificationChannel made = new NotificationChannel(CHANNEL, "Playing", NotificationManager.IMPORTANCE_LOW);
    made.setDescription("What is playing now, and the controls for it.");
    made.setShowBadge(false);
    made.setSound(null, null);
    notes.createNotificationChannel(made);
  }

  private PendingIntent button(String action) {
    Intent intent = new Intent(this, HeyAndroidAudioService.class).setAction(action);
    return PendingIntent.getService(this, action.hashCode(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  /**
   * THE NOTIFICATION IS WHAT KEEPS AUDIO ALIVE, not a courtesy. Android stops a
   * service the moment its app leaves the screen unless the service is in the
   * foreground, and a foreground service must show one. So this is the
   * difference between audio that survives a pocket and audio that dies in it.
   *
   * <p>It follows the player rather than the screen: it appears when something
   * starts, updates as the state changes, and goes when nothing is playing.
   */
  private void note() {
    HeyAndroidPlayer player = playback.player;
    Screens.Track track = player.track();
    if (track == null || player.state() == HeyAndroidPlayer.State.IDLE) {
      stopForeground(STOP_FOREGROUND_REMOVE);
      return;
    }
    boolean playing = player.state() == HeyAndroidPlayer.State.PLAYING;
    Map<String, Object> audio = playback.audio();
    Notification.Builder note = new Notification.Builder(this, CHANNEL)
        .setContentTitle(track.title)
        .setContentText(track.subtitle)
        .setSmallIcon(android.R.drawable.ic_media_play)
        .setOnlyAlertOnce(true)
        .setOngoing(playing)
        .setVisibility(Notification.VISIBILITY_PUBLIC)
        .setStyle(new Notification.MediaStyle()
            .setMediaSession(session.getSessionToken())
            .setShowActionsInCompactView(0))
        .addAction(new Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this,
                playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
            Screens.says(audio, playing ? "pause" : "play"),
            button(ACTION_PLAY_PAUSE)).build())
        .addAction(new Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop", button(ACTION_STOP)).build());
    try {
      startForeground(NOTE, note.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    } catch (Exception e) {
      // A refused foreground start costs background playing, not this session:
      // whatever is playing goes on while the app is on screen.
      Log.i(TAG, "could not go to the foreground: " + e);
    }
  }

  /** Tell whoever is listening -- a car, a lock screen -- what is playing and what may be pressed. */
  private void publish() {
    HeyAndroidPlayer player = playback.player;
    int state;
    switch (player.state()) {
      case PLAYING: state = PlaybackState.STATE_PLAYING; break;
      case PAUSED: state = PlaybackState.STATE_PAUSED; break;
      case LOADING: state = PlaybackState.STATE_BUFFERING; break;
      case FAILED: state = PlaybackState.STATE_ERROR; break;
      default: state = PlaybackState.STATE_STOPPED; break;
    }
    PlaybackState.Builder playbackState = new PlaybackState.Builder()
        .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
            | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP
            | PlaybackState.ACTION_PLAY_FROM_MEDIA_ID | PlaybackState.ACTION_SEEK_TO
            | PlaybackState.ACTION_FAST_FORWARD | PlaybackState.ACTION_REWIND)
        .setState(state, player.seconds() * 1000L, 1.0f);
    if (player.state() == HeyAndroidPlayer.State.FAILED) {
      // The one-argument form: the numbered error codes are on the compat
      // class, which this build does not have.
      playbackState.setErrorMessage(Screens.says(playback.audio(), "failed"));
    }
    session.setPlaybackState(playbackState.build());

    Screens.Track track = player.track();
    if (track == null) {
      session.setMetadata(null);
      note();
      return;
    }
    MediaMetadata.Builder held = new MediaMetadata.Builder()
        .putString(MediaMetadata.METADATA_KEY_MEDIA_ID, track.id)
        .putString(MediaMetadata.METADATA_KEY_TITLE, track.title)
        .putString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE, track.subtitle);
    if (player.duration() > 0) held.putLong(MediaMetadata.METADATA_KEY_DURATION, player.duration() * 1000L);
    if (HeyAndroidPictures.fetchable(track.image)) held.putString(MediaMetadata.METADATA_KEY_ART_URI, track.image);
    session.setMetadata(held.build());
    note();
  }

  /** What a car's buttons do. */
  private final class Controls extends MediaSession.Callback {
    @Override public void onPlayFromMediaId(String mediaId, Bundle extras) {
      withFeed(() -> {
        Screens.Track track = find(mediaId);
        if (track == null) {
          Log.i(TAG, "audio service: nothing to play for " + mediaId);
          return;
        }
        playback.player.play(track, playback.headers(), HeyAndroidAudioService.this, playback.http.origin);
      });
    }

    @Override public void onPlay() { playback.player.resume(); }

    @Override public void onPause() { playback.player.pause(); }

    @Override public void onStop() { playback.player.stop(false); }

    // THE SAME JUMP AS THE SCREEN'S, from the same place, so the two surfaces
    // do not disagree about what "back" means.
    @Override public void onRewind() { playback.player.skip(Screens.skipBack()); }

    @Override public void onFastForward() { playback.player.skip(Screens.skipOn()); }

    @Override public void onSeekTo(long ms) { playback.player.seekTo((int) (ms / 1000)); }
  }
}
