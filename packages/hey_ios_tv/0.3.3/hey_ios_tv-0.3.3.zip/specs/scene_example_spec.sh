#!/usr/bin/env sh
# Runs the scene-contract-v2 example app's embedded spec block, pinning the
# exact tv_scene_init / tv_scene_step (select-flip) JSON documents. This is
# the same source compiled into a native tvOS app by hey-ios-tv-app.sh.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
[ -x "$HEY_ROOT/bin/heyc" ] || { echo "missing Hey compiler: $HEY_ROOT/bin/heyc" >&2; exit 1; }
env HEY_ROOT="$HEY_ROOT" HEY_STDLIB_PATH="$HEY_ROOT/stdlib" \
  "$HEY_ROOT/bin/heyc" "$ROOT/examples/native_tvos_scene_app.hey" --test
echo "scene-v2 example spec passed"
