# In progress

v0.2.0 provides the independent Connector/C FFI package, query/result handling, TLS options, timeout controls, safe escaping, and transaction APIs. The maintained receipt is compile/load/expected-failure unless a live server is explicitly configured.
