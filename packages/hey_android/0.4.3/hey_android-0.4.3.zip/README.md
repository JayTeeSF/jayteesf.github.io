# hey_android

`hey_android` builds Android 16 (API 36) apps on this Mac with no Gradle, in
two lanes:

- **A Hey program with the Hey runtime** (0.2.0, 0.3.0): `android.app.NativeActivity`
  with `hasCode="false"` loads one shared library holding the Hey program
  (compiled through Hey's LLVM lane), the Hey runtime from the pinned Hey
  checkout (compiled unmodified for Android) and a small C entry point. Views
  are drawn through JNI.
- **A server-described app** (0.4.0): a native Java renderer for the
  `hey_mobile` api_screens description a server sends, like `hey_ios`'s
  renderer. It names no product.

The rule against Java was withdrawn on 2026-09-14: Java and Kotlin are allowed
for speed (`docs/ROADMAP.md`).

**Use 0.4.1 or newer for the server-described renderer.** The immutable 0.4.0
archive omitted four Android renderer classes that were present in its source
checkout, so installed-package builds could not compile the Activity. 0.4.1
contains the complete renderer and an archive-manifest regression gate.

## What works in 0.2.0

- **Build:** `tools/hey-android-app.sh` builds a Hey program into a signed APK.
  It uses heyc, NDK r28 clang, aapt2, zipalign and apksigner, with no Gradle.
- **Run:** it installs and launches the APK on the API 36 emulator.
  - What the program `says` appears in logcat, byte for byte as on the Mac.
  - A Hey runtime error appears in logcat and ends the activity cleanly.
- **Runtime features on Android:**
  - maps, arrays, `Text.join` and JSON;
  - SHA-256 of text and of files;
  - secure random bytes and constant-time compare.
- **Reported as unavailable:** TLS, AES-256-GCM, scrypt and Argon2id each
  return a named error, never a fake result.
- **Checks between steps:**
  - The IR is target-neutral.
  - The library is aarch64 with 16 KB LOAD alignment, and every undefined
    symbol comes from libc, libm, libdl, liblog or libandroid.
  - No OpenSSL, Apple crypto or Homebrew trace is in the build.
  - The APK has no dex, stores the library uncompressed with 16 KB alignment,
    and has a verifying signature.
- **Evidence:** every run writes `receipt.json`.
- **Pins:** `bin/android-doctor` checks and prints them: platform 36,
  build-tools 36.0.0, NDK 28.2.13676358, the API 36 Play system image and
  JDK 17. It also prints the Hey checkout's identity. Anything missing comes
  with the exact `sdkmanager` line.
- **Gate:** `bin/check` runs all of this, including the emulator, with a
  negative control for every check. See `docs/TESTING.md`.

## The commands

```sh
cd ~/dev/hey_android
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"   # the Hey checkout whose runtime ships in the app

bin/android-doctor                                    # pins, SDK pieces, JDK, Hey identity
tools/hey-android-emulator.sh create-avd              # once: AVD hey_android_API_36 ("hey_android API 36")

tools/hey-android-app.sh \
  --source examples/hello_runtime.hey \
  --out /tmp/hey-hello \
  --package-id com.jayteesf.hey.hello \
  --label 'Hey Hello' \
  --emulator hey_android_API_36 --launch
```

**What `--emulator` does:**
- boots the AVD headless if it is not running;
- installs and launches the app;
- waits for the program to end;
- writes these into `--out`: `app.apk`, `receipt.json`, `stdout.txt`,
  `stderr.txt`, `logcat-hey.txt` and `logcat.txt`;
- shuts the emulator down again.

**Other options:**
- `--device SERIAL` uses a device that is already running instead.
- Leave out both `--emulator` and `--device` to only build.
- `--keystore FILE --key-alias ALIAS` signs for release. The password comes
  from `HEY_ANDROID_KEYSTORE_PASSWORD`.

**Where the output goes** (see `native/glue/hey_android_glue.c`):
- stdout goes to logcat tag `hey.out`;
- stderr goes to `hey.err`;
- the entry point's own lines go to `hey.app`.

```sh
adb logcat -v tag -s 'hey.app:*' 'hey.out:*' 'hey.err:*'
```

When several agents build at once, set `HEY_HEYC_LOCK` to a lock command, for
example `HEY_HEYC_LOCK="with-lock.sh build --"`. The tool puts it in front of
heyc, whose build cache is not safe for parallel builds.

## What works in 0.3.0: Views from a Hey program, and a tap

Phase 2's first slice. Still no Java or Kotlin source, no `classes.dex`, and
`hasCode="false"`.

- **The program owns the loop.** It waits for the next event, describes the
  screen as rows, and commits it (`examples/rows.hey`):

  ```hey
  import 'pkg:hey_android@0.4.3/android_ui'

  program
    let ui = HeyAndroidUi.open().value
    let running = true
    while running
      let event = HeyAndroidUi.next_event(ui)   # {kind: 'start' | 'tap' | 'destroy', id}
      if event.kind == 'destroy'
        set running = false
      else
        HeyAndroidUi.draw(ui, [{id: 'row-1', label: 'Row 1'}])
      end
    end
  end
  ```
- **The shims** are C in `native/ui`, declared in `native/ui/hey.native.json`
  and called through `stdlib:Native`: `begin`, `text_row`, `commit`,
  `next_event` and `errors`. They are linked into the app's own library, and
  the program opens it by its soname.
- **Every JNI call runs on the UI thread.** The Hey thread hands a finished
  description over through a pipe on the UI thread's looper. The UI thread
  never waits on Hey, and Hey never runs on the UI thread.
- **Taps** are hit-tested in native code against the rows' bounds and arrive
  as `{"kind":"tap","id":"row-3"}`. There is no press state, touch scrolling,
  text entry or TalkBack activation yet. hey_android uses no Java in any form
  (no source, no `classes.dex`, no generated or in-memory dex), so some of these
  come back only natively and some not at all. `docs/ROADMAP.md` lists what
  that rule costs: among other things, audio in the foreground only and no
  Android Auto.
- **Gates on the emulator:** the rows' pixels are drawn; a tap injected with
  adb changes the screen text; rotation and a second launch still draw; a
  runtime error in the loop finishes the activity; the APK has no dex. Each
  has a negative control.

```sh
tools/hey-android-app.sh --source examples/rows.hey --out /tmp/hey-rows \
  --package-id com.jayteesf.hey.rows --label 'Hey rows' \
  --emulator hey_android_API_36 --launch --ui --keep-emulator
```

`--ui` waits for the first screen instead of the program's end and leaves the
app running. Shut the emulator down afterwards:
`tools/hey-android-emulator.sh shutdown emulator-5584`.

## What works in 0.4.0: a renderer for served screens

Source in `renderer/`: `renderer/java` is pure Java (JSON, the value language,
description refusal, what a screen draws, running actions) and runs on the Mac;
`renderer/android` is the Activity, HTTP, the Keystore store and description
loading. It declares **level 1** for platform `android`.

- **Description:** the stored last-good served copy, else the baked one; asks
  `GET <served path>?platform=android&level=1` with `If-None-Match`; a new copy
  is stored and drawn when nothing is in progress. Origin and session keys come
  only from the baked copy.
- **Draws:** list and form screens; fields, actions, literal rows, rows from the
  screen's answer and route sections; request, open_screen and open_url actions
  with confirm and then; text-like form fields; headers, conditions, tabs, the
  nav button, system back, scrolling.
- **Hides, and never sends:** anything the level does not know, and the level-1
  kinds this build does not draw yet (search and audio screens, prompts, choose,
  rating, share, copy, video, web sign-in, document, set_var, choice and rating
  fields).
- **Session:** the sign-in form's token sealed with an Android Keystore
  AES-256-GCM key in the no-backup directory; 401 signs out; sign-out revokes
  and removes it.
- **Conformance:** hey_mobile's values (117), names (81 icons, 3 file kinds)
  and descriptions (21) vectors pass on the Mac, with mutation controls.

```sh
tools/hey-android-api-app.sh \
  --description served-android-1.json \
  --origin http://10.0.2.2:3080 \
  --package-id com.example.app.debug --label 'Example (debug)' \
  --out /tmp/api-app [--device emulator-5584 --launch]
```

`--description` is baked byte for byte and must be a copy the renderer takes;
`--origin` is `https://host[:port]`, or `http://` only to `10.0.2.2`,
`127.0.0.1` or `localhost`. The APK is debug-signed. Logcat tag `hey.api` says
which copy is drawn, each request's method, path and status, and each screen
ready, never a token or a body.

### Prompts and a Google Play release

A `request` action can ask for text first (`prompt`), after its confirm: that
is how a server-described account deletion screen asks for the passphrase.

    tools/hey-android-api-app.sh --description FILE --origin https://HOST --package-id ID --label NAME \
      --out DIR --version-code N --icon icon.png \
      --release --keystore upload.jks --keychain-service SERVICE --aab

writes `app.aab` for a Google Play upload and a matching `app.apk`, both signed
with the upload key and not debuggable, with `receipt.json` naming the
certificate. The keystore password is read from the Keychain (or
`--keystore-password-env VAR`). See docs/ROADMAP.md, phase 2B, slice 2.

## What is not done

- **The Hey lane draws only text rows and taps.** No buttons, text entry,
  scrolling or back handling from Hey yet.
- **The renderer is level 1 only, and a subset of it** (above), debug-signed,
  with no icons, images, row actions, paging, share intent, AAB or media. The
  next slices are in `docs/ROADMAP.md`, phase 2B.
- **A runtime error ends the app.** The Hey runtime exits on any error, and
  there is no per-call error boundary yet. The error reaches logcat and the
  activity finishes cleanly. After the program ends and its activity is gone,
  the process exits, and the next launch starts a fresh runtime.
- **LLVM-lane miscompiles.** A string parameter put in a map literal that a
  function returns comes back as an integer, and a few similar shapes go wrong
  silently (`docs/ROADMAP.md`, toolchain request 6). `examples/rows.hey` avoids
  them; check new UI code on the Mac with `specs/android_ui_host_spec.sh`'s
  fake shims before trusting it on a device.
- **One target:** arm64-v8a, minimum API 35, target API 36. There is no x86_64
  or armv7 library and no AAB yet.
- **16 KB pages are checked, not run.** The alignment is verified statically;
  the emulator kernel uses 4 KB pages.
- **LLVM-lane limits.** Some Hey code does not compile through the LLVM lane
  yet: `Array#join`, closures such as `names.map(fn(n) ...)`, `a ? b : c`,
  `Bytes.from_text` and `Tls.available`. Those programs cannot be built for
  Android until heyc lowers them. The list, with reproductions, is in
  `docs/ROADMAP.md`.
- **Stdlib calls that need the toolchain are refused.**
  - On the LLVM lane, a stdlib call without a native route in the runtime is
    handed to a Hey toolchain at run time, and a phone has none.
    `Files.write_text` is one such call; use `Files.write_atomic` instead.
  - The IR check refuses these calls by name before anything is built.
- **Networking from Hey.** The Hey runtime has no TLS on Android. The renderer
  uses the platform's `HttpURLConnection`.

The earlier Gradle lane (API 34, AGP 8.5.2, NDK 26.1, a generated Java
Activity) was removed in 0.2.0.

## Package import

```hey
import 'pkg:hey_android@0.4.3/main'
import 'pkg:hey_android@0.4.3/android_ui'
```

`HeyAndroidToolchain.versions()` returns the pins, and
`HeyAndroid.native_receipt?(receipt)` recognises a clean run receipt.

## Standard package controls

`hey_packager` validates, releases and publishes the package.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
bin/check          # includes the emulator runs; several minutes
bin/release
bin/publish
```
