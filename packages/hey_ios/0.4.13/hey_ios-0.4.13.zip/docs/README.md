# hey_ios 0.4.13

Apple-specific capability contracts and build metadata for Hey iOS applications.

The root `README.md` contains the public package overview. This documentation directory is copied intact into every registry publication by `hey_packager`.

## Release controls

```sh
bin/check
bin/release
bin/publish --no-commit
bin/source-zip
```

See `GETTING_STARTED.md`, `DESIGN.md`, `TESTING.md`, and `ROADMAP.md` for package-specific guidance.
