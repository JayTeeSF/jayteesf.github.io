/* hey_android runtime profile: the three platform primitives for bionic.
 * See include/hey_android_platform_crypto.h for why this exists. */
#include "hey_android_platform_crypto.h"
#include "sha256.h"

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/random.h>

_Static_assert(sizeof(CC_SHA256_CTX) == sizeof(SHA256_CTX), "CC_SHA256_CTX must match the vendored SHA256_CTX");

int hey_android_sha256_init(CC_SHA256_CTX *ctx) {
  if (!ctx) return 0;
  SHA256_CTX inner;
  sha256_init(&inner);
  memcpy(ctx, &inner, sizeof inner);
  return 1;
}

int hey_android_sha256_update(CC_SHA256_CTX *ctx, const void *data, CC_LONG length) {
  if (!ctx || (!data && length)) return 0;
  SHA256_CTX inner;
  memcpy(&inner, ctx, sizeof inner);
  sha256_update(&inner, (const BYTE *)data, length);
  memcpy(ctx, &inner, sizeof inner);
  return 1;
}

int hey_android_sha256_final(unsigned char *digest, CC_SHA256_CTX *ctx) {
  if (!digest || !ctx) return 0;
  SHA256_CTX inner;
  memcpy(&inner, ctx, sizeof inner);
  sha256_final(&inner, digest);
  memset(&inner, 0, sizeof inner);
  memset(ctx, 0, sizeof *ctx);
  return 1;
}

/* Kernel randomness. getrandom blocks only until the pool is first seeded,
 * which has happened long before an app can run. A short read is continued;
 * any other failure is reported, so the runtime answers crypto_random_failed
 * instead of returning bytes that are not random. */
int hey_android_random_bytes(void *bytes, size_t count) {
  unsigned char *next = (unsigned char *)bytes;
  if (!next && count) return -1;
  while (count > 0) {
    ssize_t got = getrandom(next, count, 0);
    if (got < 0) {
      if (errno == EINTR) continue;
      if (errno == ENOSYS) {
        arc4random_buf(next, count);
        return kCCSuccess;
      }
      return -1;
    }
    next += got;
    count -= (size_t)got;
  }
  return kCCSuccess;
}

/* 0 when equal, 1 otherwise; the loop always visits every byte. */
int hey_android_timingsafe_bcmp(const void *left, const void *right, size_t length) {
  const unsigned char *a = (const unsigned char *)left;
  const unsigned char *b = (const unsigned char *)right;
  unsigned char difference = 0;
  for (size_t i = 0; i < length; i++) difference |= (unsigned char)(a[i] ^ b[i]);
  return difference != 0;
}
