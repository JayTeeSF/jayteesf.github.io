#include "hey_toml.h"
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
static char *decode(const void *s,size_t n,unsigned memory,unsigned output){HeyNativeOwnedBytes b=toml_document((HeyNativeBytesView){s,n},1048576,memory,output,0);assert(b.data);char *out=malloc(b.length+1);assert(out);memcpy(out,b.data,b.length);out[b.length]=0;b.release(b.context,b.data,b.length);return out;}
int main(void){
 const char *source="title = '日本語'\nmax = 9223372036854775807\nmin = -9223372036854775808\nflag = true\nvalues = [1, 'two', false]\n[server]\nport = 3307\n";
 char *out=decode(source,strlen(source),16777216,8388608);assert(strstr(out,"\"ok\":true"));assert(strstr(out,"9223372036854775807"));assert(strstr(out,"-9223372036854775808"));assert(strstr(out,"日本語"));free(out);
 const char *bad="token = 'PRIVATE_TEST_MARKER'\ntoken = 'other'\n";out=decode(bad,strlen(bad),16777216,8388608);assert(strstr(out,"invalid_toml"));assert(!strstr(out,"PRIVATE_TEST_MARKER"));free(out);
 const unsigned char invalid[]={ 'x','=','"',0xff,'"','\n'};out=decode(invalid,sizeof(invalid),16777216,8388608);assert(strstr(out,"invalid_toml"));free(out);
 char large[8192];memset(large,'a',sizeof(large));memcpy(large,"x = '",5);large[sizeof(large)-2]='\'';large[sizeof(large)-1]='\n';out=decode(large,sizeof(large),4096,8388608);assert(strstr(out,"toml_memory_limit"));free(out);
 out=decode(large,sizeof(large),16777216,256);assert(strstr(out,"toml_output_limit"));free(out);
 out=decode("",0,16777216,8388608);assert(strstr(out,"\"ok\":true"));free(out);
 const char *nulkey="\"\\u0000\" = 'value'\n";
 out=decode(nulkey,strlen(nulkey),16777216,8388608);assert(strstr(out,"toml_key_not_representable"));free(out);
 const char raw_nul[]={'a','=','1',0,'\n'};out=decode(raw_nul,sizeof(raw_nul),16777216,8388608);assert(strstr(out,"invalid_toml"));free(out);
 out=decode("μ = 'value'\n",strlen("μ = 'value'\n"),16777216,8388608);assert(strstr(out,"invalid_toml"));free(out);
 for(unsigned i=0;i<1000;i++){out=decode("x = 1\n",6,16777216,8388608);assert(strstr(out,"\"ok\":true"));free(out);}
 puts("PASS: native syntax, UTF-8, secret-safe errors, integer edges, resource failures and repeated cleanup");
 return 0;
}
