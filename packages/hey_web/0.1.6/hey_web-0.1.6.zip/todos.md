# Todos

- Run live HTTP/HTTPS client and server receipts on target hosts.
- Add cookies, signed sessions, form decoding, named routes, request-test helpers, and streaming conveniences for 0.1.5.
- Add multipart/range/graceful-drain production work for 0.1.4.
- Track stdlib HTTP/2, pooling, WebSocket, and server TLS capabilities without duplicating them here.
