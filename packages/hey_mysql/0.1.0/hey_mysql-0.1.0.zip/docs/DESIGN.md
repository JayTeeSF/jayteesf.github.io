# Design

The adapter normalizes mysql batch output into object rows and exposes callable query/execute fields. Direct argv avoids shell parsing. The password is omitted from argv, though `MYSQL_PWD` remains an interim client-process mechanism rather than the final secret transport.

The target architecture follows the useful mysql2 traits: a small native binding, typed rows, prepared statements, explicit encoding/timeouts, streaming, and predictable error metadata.
