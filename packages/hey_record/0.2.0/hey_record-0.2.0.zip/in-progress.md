# In progress

v0.2.0 introduces dialect-aware parameterized plans and the adapter callback contract used by `hey_sqlite3@0.2.0` and `hey_mysql@0.2.0`. The next porcelain work is migration bookkeeping, validations, associations, and pool/Job ownership conventions.
