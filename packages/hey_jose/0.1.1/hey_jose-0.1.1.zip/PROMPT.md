# hey_jose

JWT/JWS/JWKS verification for Hey over OpenSSL. Public API in `jose.hey`
(`Jose`); low-level boundary in `Native.hey` (`JoseNative`); C shim in
`native/`. Build with `bin/build-native`; verify with `bin/check`. See
`PACKAGE_SPEC.md` for the authoritative contract. Verification only; never
implement cryptographic primitives in Hey.
