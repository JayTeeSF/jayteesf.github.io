#pragma once
#include "hey_native_abi.h"
HeyNativeOwnedBytes tsv_encode(HeyNativeBytesView batch);
uint32_t tsv_rows(HeyNativeBytesView batch);
uint64_t tsv_last_u64(HeyNativeBytesView batch, uint32_t column);
