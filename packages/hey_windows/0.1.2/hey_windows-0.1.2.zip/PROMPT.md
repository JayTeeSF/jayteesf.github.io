# hey_windows: working notes for an agent

- The executable contains no Hey: Hey does not run on Windows yet. Hey runs on
  the build host (manifest tool and spec). Do not add Hey runtime code to
  native/host.c and do not claim Windows support for Hey itself.
- WebView2 is COM in C here: vtable structs, CINTERFACE and COBJMACROS. Keep it
  one C file plus WebView2Loader.dll; no C++ runtime.
- Load WebView2Loader.dll by full path beside the program only
  (LOAD_WITH_ALTERED_SEARCH_PATH); bin/package-check fails on a bare-name load.
- native/app_manifest.h is generated; edit manifest.hey or pass flags to
  bin/build-exe, never the header.
- Wine proves the window and the receipt, not the browser. Say which when
  reporting. A real PC run of `MyQueue.exe --self-test receipt.txt` is the
  only proof of `hey_windows_webview2=present`.
- Release with the hey_packager controls (bin/check, bin/release, bin/publish).
  Bump with bin/bump; hey-version-files lists every copy of the version.
