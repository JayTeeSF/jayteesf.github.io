# Todo

- A device receipt once Apple grants the CarPlay audio entitlement on an App ID.
- Tabs (CPTabBarTemplate) when a feed has more than one list worth a tab.
- A second consumer that is not My Queue.
