# Done

- v0.1.0 lifecycle state/effects.
- Enrollment payload validation and development/release transport policy.
- Screen/action/accessibility descriptors and test doubles.
- Removed release tooling from runtime dependencies and adopted `hey_packager` 0.1.2 controls.
- v0.2.0 `api_screens`: an app's screens bound to JSON routes, described in ordinary Hey and executed by a native host. Optional body values (`$name?`, `@name?`), rows already done (`done_when`), conditional selects (`when`), templates with labels, dates and half stars, audio position and share routes. `problems` names each fault with negative controls; `routes` lists every route from actions, menus, rows, forms and web links. First consumer: My Queue on iPhone through `hey_ios` 0.2.0.
