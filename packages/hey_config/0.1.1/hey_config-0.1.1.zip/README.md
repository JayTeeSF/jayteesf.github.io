# hey_config

Typed configuration layers, environment overlays, secret references, and validation receipts shared by every Hey application type.

This is a Milestone 0 contract prototype. It passes `bin/check` (`hey package verify`, and its documentation example run
by the Hey compiler) but has not been published to the package registry.
