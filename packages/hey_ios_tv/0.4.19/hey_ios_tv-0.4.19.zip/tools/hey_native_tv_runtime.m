#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreImage/CoreImage.h>
#import <AVFoundation/AVFoundation.h>
#include <math.h>   // sin/exp/M_PI for the synthesised sound cues (0.4.9)
#include <stdint.h>

// hey_ios_tv native tvOS app template.
//
// The real Hey runtime (claude_01 runtime/hey_runtime.c, compiled for the
// Apple TV target) is linked into every app, so the v1 no-runtime string
// shim is GONE -- the runtime provides hey_runtime_init/shutdown, the
// hey_llvm_* string helpers, and the boxed-value ABI. The build script
// (hey-ios-tv-app.sh) calls hey_runtime_init() before the first scene is
// built and hey_runtime_shutdown() on termination.
//
// One template, two contracts, selected at build time by -DHEY_SCENE_V2:
//   * HEY_SCENE_V2 defined  -> scene-contract-v2 JSON renderer (below).
//   * otherwise             -> the v1 opaque-i64 game contract (unchanged).
// The build script nm-checks the compiled app object for
// _hey_fn_tv_scene_init and defines HEY_SCENE_V2 when it is present.

// ---- runtime (provided by hey_runtime.c, linked in) ---------------------
extern void hey_runtime_init(void);
extern void hey_runtime_shutdown(void);
extern void hey_runtime_set_argv(int argc, char **argv);
// Extract a C string from a Hey str return. Hey str-returning entries come
// back either as a raw NUL-terminated C string (single-expression returns)
// or as a boxed HeyValue* (control-flow returns). A boxed value's first
// word is its kind enum (0..13); scene JSON always starts with '{' (123) or
// '[' (91), so the first word disambiguates the two representations safely.
extern char *hey_llvm_value_to_raw_string_cstr(void *value);

static NSString *HeyStringFromReturn(const void *ret) {
  if (!ret) { return @""; }
  uint32_t tag = *(const uint32_t *)ret;         // HeyKind for a boxed value
  if (tag <= 13) {                               // HEY_ACTOR_DEFINITION == 13
    char *owned = hey_llvm_value_to_raw_string_cstr((void *)ret);
    NSString *s = owned ? [NSString stringWithUTF8String:owned] : @"";
    if (owned) { free(owned); }                  // owned copy from the runtime
    return s;                                     // boxed HeyValue* leaks (bounded, per-step)
  }
  return [NSString stringWithUTF8String:(const char *)ret];  // raw runtime cstr; do not free
}

#if defined(HEY_SCENE_V2)
// =========================================================================
// scene-contract-v2 renderer (hey-tv-scene-v2)
// =========================================================================
extern const char *hey_fn_tv_scene_init(void);
extern const char *hey_fn_tv_scene_step(const char *scene_json, const char *event_json);

static UIColor *HeyColorFromHex(NSString *hex, UIColor *fallback) {
  if (![hex isKindOfClass:NSString.class]) { return fallback; }
  NSString *s = [[hex stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet]
                    stringByReplacingOccurrencesOfString:@"#" withString:@""];
  if (s.length != 6 && s.length != 8) { return fallback; }
  unsigned int rgb = 0;
  NSScanner *scan = [NSScanner scannerWithString:s.length == 8 ? [s substringFromIndex:2] : s];
  if (![scan scanHexInt:&rgb]) { return fallback; }
  return [UIColor colorWithRed:((rgb >> 16) & 0xFF) / 255.0
                         green:((rgb >> 8) & 0xFF) / 255.0
                          blue:(rgb & 0xFF) / 255.0
                         alpha:1.0];
}

// --- inline markdown ---------------------------------------------------
//
// A DELIBERATELY SMALL SUBSET: **bold**, *italic*, and `code`. Nothing else.
//
// UNDERSCORE IS NOT A MARKER, and that is not an oversight. This app writes
// fill-in-the-blank stems as runs of underscores -- "Plant cells use the ____
// to turn sunlight into sugar" -- and there are nine such stems in the sample
// decks alone. Treating _ as italic would mangle every cloze question on the
// wall. Caught by testing the parser against real content, not by reading it.
//
// The subset is small because this renders a question on a wall for a whole
// room, so the only formatting worth having is the kind that survives being
// read from the back: emphasis on the word that carries the question, and a
// monospace run for a term or a formula that must be read literally.
// Headings are already the widget style; links and images mean nothing on a
// screen nobody touches.
//
// BACKWARD COMPATIBILITY IS THE FIRST REQUIREMENT. Text containing no marker
// must render EXACTLY as it did before this existed -- every pack already in
// the field, and every scene the server renders today, is unmarked text. So
// HeyAttributedFromMarkdown returns a plain attributed string in that case,
// and an unmatched or stray marker is emitted LITERALLY rather than eating
// the rest of the line. A student reading "2 * 3 * 4" must see asterisks, not
// an italic 3. For the same reason the backslash escape covers ONLY the
// markers and itself: a backslash in unmarked text is not an escape and is
// emitted as itself, so "C:\Users" does not quietly lose a character.
//
// Traits are derived from the label's own font via its descriptor, so bold
// and italic follow whatever size and weight the widget style chose -- a bold
// run inside a 76pt title is a bold 76pt title, not a hardcoded size.
static UIFont *HeyFontWithTraits(UIFont *base, UIFontDescriptorSymbolicTraits add) {
  UIFontDescriptor *d = base.fontDescriptor;
  UIFontDescriptorSymbolicTraits want = d.symbolicTraits | add;
  UIFontDescriptor *nd = [d fontDescriptorWithSymbolicTraits:want];
  if (!nd) { return base; }
  return [UIFont fontWithDescriptor:nd size:base.pointSize];
}

static NSAttributedString *HeyAttributedFromMarkdown(NSString *src, UIFont *base, UIColor *color) {
  NSMutableAttributedString *out = [[NSMutableAttributedString alloc] init];
  NSUInteger n = src.length;
  NSUInteger i = 0;
  NSMutableString *run = [NSMutableString string];

  // Flush the plain run collected so far with the current base attributes.
  void (^flush)(void) = ^{
    if (run.length == 0) { return; }
    [out appendAttributedString:[[NSAttributedString alloc] initWithString:run
        attributes:@{NSFontAttributeName: base, NSForegroundColorAttributeName: color}]];
    [run setString:@""];
  };

  while (i < n) {
    unichar c = [src characterAtIndex:i];

    // A backslash escapes a MARKER, or another backslash, so a literal
    // asterisk or backtick can always be written. It escapes NOTHING ELSE,
    // and that restriction is the backward-compatibility rule again rather
    // than a stylistic choice. An escape that swallowed whatever followed it
    // would silently DELETE the backslash from every unmarked string that
    // happens to contain one -- "C:\Users", "\alpha", "a\b" -- none of which
    // opted into markdown and all of which rendered literally before this
    // existed. In front of an ordinary character the backslash falls through
    // to the literal-text path below and is emitted as itself.
    if (c == '\\' && i + 1 < n) {
      unichar next = [src characterAtIndex:i + 1];
      if (next == '*' || next == '`' || next == '\\') {
        [run appendFormat:@"%C", next];
        i += 2;
        continue;
      }
    }

    NSString *marker = nil;
    UIFontDescriptorSymbolicTraits traits = 0;
    BOOL mono = NO;
    if (c == '*' && i + 1 < n && [src characterAtIndex:i + 1] == '*') {
      marker = @"**"; traits = UIFontDescriptorTraitBold;
    } else if (c == '*') {
      marker = @"*"; traits = UIFontDescriptorTraitItalic;
    } else if (c == '`') {
      marker = @"`"; mono = YES;
    }

    if (marker) {
      NSRange rest = NSMakeRange(i + marker.length, n - i - marker.length);
      // THE FLANKING RULE, and it is what makes arithmetic safe. An emphasis
      // marker only opens when the character after it is NOT whitespace, and
      // only closes when the character before it is NOT whitespace. Without
      // it "2 * 3 * 4 equals 24" renders as "2  3  4" with an italic 3 --
      // measured, not imagined, before this rule existed. Code spans are
      // exempt: `  ` is a legitimate literal.
      BOOL emphasis = !mono;
      BOOL opens = rest.length > 0 &&
          (!emphasis || ![[NSCharacterSet whitespaceCharacterSet]
                            characterIsMember:[src characterAtIndex:rest.location]]);
      if (!opens) {
        [run appendString:marker];
        i += marker.length;
        continue;
      }
      NSRange close = [src rangeOfString:marker options:0 range:rest];
      // A closer preceded by whitespace does not close. Walk on to the next
      // candidate rather than giving up, so "*a * b*" still emphasises.
      while (emphasis && close.location != NSNotFound && close.location > rest.location &&
             [[NSCharacterSet whitespaceCharacterSet]
                characterIsMember:[src characterAtIndex:close.location - 1]]) {
        NSUInteger from = close.location + marker.length;
        if (from >= n) { close = NSMakeRange(NSNotFound, 0); break; }
        close = [src rangeOfString:marker options:0 range:NSMakeRange(from, n - from)];
      }
      NSUInteger inner = (close.location == NSNotFound) ? 0 : close.location - rest.location;
      // An unmatched marker, or an empty span, is literal text -- never a
      // swallowed rest-of-line.
      if (close.location == NSNotFound || inner == 0) {
        [run appendString:marker];
        i += marker.length;
        continue;
      }
      flush();
      NSString *span = [src substringWithRange:NSMakeRange(rest.location, inner)];
      UIFont *font = mono
          ? [UIFont monospacedSystemFontOfSize:base.pointSize weight:UIFontWeightRegular]
          : HeyFontWithTraits(base, traits);
      [out appendAttributedString:[[NSAttributedString alloc] initWithString:span
          attributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color}]];
      i = close.location + marker.length;
      continue;
    }

    [run appendFormat:@"%C", c];
    i += 1;
  }
  flush();
  return out;
}

static UIColor *HeyScaleColor(UIColor *base, CGFloat factor) {
  CGFloat r = 0, g = 0, b = 0, a = 1;
  [base getRed:&r green:&g blue:&b alpha:&a];
  return [UIColor colorWithRed:MIN(1, r * factor) green:MIN(1, g * factor) blue:MIN(1, b * factor) alpha:a];
}

// ---- a single playing card (renderer-owned geometry + style) ------------
// 2.5:3.5 proportions, white face with corner rank+suit indices and a large
// center pip, hearts/diamonds red and spades/clubs near-black, soft drop
// shadow; a face-down card is a deep-blue patterned back with a border.
@interface HeyCardView : UIView
@property(copy, nonatomic) NSString *rank;
@property(copy, nonatomic) NSString *suit;
@property(nonatomic) BOOL faceUp;
@end

@implementation HeyCardView

+ (CGFloat)widthForHeight:(CGFloat)h { return h / 1.4; }   // 2.5 : 3.5

- (instancetype)initWithHeight:(CGFloat)h {
  CGFloat w = [HeyCardView widthForHeight:h];
  self = [super initWithFrame:CGRectMake(0, 0, w, h)];
  if (self) {
    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.layer.shadowColor = UIColor.blackColor.CGColor;
    self.layer.shadowOpacity = 0.35;
    self.layer.shadowRadius = 10.0;
    self.layer.shadowOffset = CGSizeMake(0, 7);
    [NSLayoutConstraint activateConstraints:@[
      [self.widthAnchor constraintEqualToConstant:w],
      [self.heightAnchor constraintEqualToConstant:h],
    ]];
    self.translatesAutoresizingMaskIntoConstraints = NO;
  }
  return self;
}

- (NSString *)pipGlyph {
  NSString *s = self.suit.lowercaseString;
  if ([s hasPrefix:@"spade"]) { return @"♠"; }
  if ([s hasPrefix:@"heart"]) { return @"♥"; }
  if ([s hasPrefix:@"diamond"]) { return @"♦"; }
  if ([s hasPrefix:@"club"]) { return @"♣"; }
  return @"?";
}

- (UIColor *)suitColor {
  NSString *s = self.suit.lowercaseString;
  if ([s hasPrefix:@"heart"] || [s hasPrefix:@"diamond"]) {
    return [UIColor colorWithRed:0xC0 / 255.0 green:0x39 / 255.0 blue:0x2B / 255.0 alpha:1.0]; // #C0392B
  }
  return [UIColor colorWithWhite:0.10 alpha:1.0]; // near-black
}

- (void)layoutSubviews {
  [super layoutSubviews];
  CGFloat radius = self.bounds.size.width * 0.09;
  self.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:radius].CGPath;
}

- (void)drawRect:(CGRect)rect {
  CGRect b = self.bounds;
  CGFloat w = b.size.width, h = b.size.height;
  CGFloat radius = w * 0.09;
  UIBezierPath *card = [UIBezierPath bezierPathWithRoundedRect:b cornerRadius:radius];

  if (!self.faceUp) {
    // deep-blue patterned back with border
    UIColor *back = [UIColor colorWithRed:0x16 / 255.0 green:0x30 / 255.0 blue:0x5C / 255.0 alpha:1.0]; // #16305C
    [back setFill];
    [card fill];
    CGRect inner = CGRectInset(b, w * 0.07, w * 0.07);
    UIBezierPath *innerPath = [UIBezierPath bezierPathWithRoundedRect:inner cornerRadius:radius * 0.7];
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSaveGState(ctx);
    [innerPath addClip];
    UIColor *hatch = [UIColor colorWithRed:0x3A / 255.0 green:0x5B / 255.0 blue:0x9C / 255.0 alpha:0.9];
    [hatch setStroke];
    UIBezierPath *lines = [UIBezierPath bezierPath];
    lines.lineWidth = 2.0;
    CGFloat step = w * 0.17;
    for (CGFloat x = -h; x < w + h; x += step) {
      [lines moveToPoint:CGPointMake(x, 0)];
      [lines addLineToPoint:CGPointMake(x + h, h)];
      [lines moveToPoint:CGPointMake(x + h, 0)];
      [lines addLineToPoint:CGPointMake(x, h)];
    }
    [lines stroke];
    CGContextRestoreGState(ctx);
    [[UIColor colorWithRed:0x8F / 255.0 green:0xAB / 255.0 blue:0xE0 / 255.0 alpha:1.0] setStroke];
    innerPath.lineWidth = 3.0;
    [innerPath stroke];
    return;
  }

  // white face
  [[UIColor colorWithRed:0.99 green:0.99 blue:0.97 alpha:1.0] setFill];
  [card fill];
  [[UIColor colorWithWhite:0.86 alpha:1.0] setStroke];
  card.lineWidth = 1.5;
  [card stroke];

  UIColor *color = [self suitColor];
  NSString *pip = [self pipGlyph];
  NSString *rk = self.rank.length ? self.rank.uppercaseString : @"?";

  // large center pip
  UIFont *centerFont = [UIFont systemFontOfSize:h * 0.42 weight:UIFontWeightMedium];
  NSDictionary *centerAttrs = @{ NSFontAttributeName: centerFont, NSForegroundColorAttributeName: color };
  CGSize cs = [pip sizeWithAttributes:centerAttrs];
  [pip drawAtPoint:CGPointMake((w - cs.width) / 2.0, (h - cs.height) / 2.0) withAttributes:centerAttrs];

  // corner index: rank over suit pip, top-left and (rotated) bottom-right
  UIFont *rankFont = [UIFont systemFontOfSize:h * 0.15 weight:UIFontWeightSemibold];
  UIFont *smallPipFont = [UIFont systemFontOfSize:h * 0.13 weight:UIFontWeightRegular];
  NSDictionary *rankAttrs = @{ NSFontAttributeName: rankFont, NSForegroundColorAttributeName: color };
  NSDictionary *smallPipAttrs = @{ NSFontAttributeName: smallPipFont, NSForegroundColorAttributeName: color };
  CGFloat inset = w * 0.09;

  [rk drawAtPoint:CGPointMake(inset, inset * 0.7) withAttributes:rankAttrs];
  [pip drawAtPoint:CGPointMake(inset, inset * 0.7 + rankFont.lineHeight * 0.85) withAttributes:smallPipAttrs];

  CGContextRef ctx = UIGraphicsGetCurrentContext();
  CGContextSaveGState(ctx);
  CGContextTranslateCTM(ctx, w, h);
  CGContextRotateCTM(ctx, M_PI);
  [rk drawAtPoint:CGPointMake(inset, inset * 0.7) withAttributes:rankAttrs];
  [pip drawAtPoint:CGPointMake(inset, inset * 0.7 + rankFont.lineHeight * 0.85) withAttributes:smallPipAttrs];
  CGContextRestoreGState(ctx);
}
@end

// ---- an empty stack slot: a dashed rounded outline ----------------------
@interface HeyCardSlotView : UIView
@end
@implementation HeyCardSlotView
- (instancetype)initWithHeight:(CGFloat)h {
  CGFloat w = [HeyCardView widthForHeight:h];
  self = [super initWithFrame:CGRectMake(0, 0, w, h)];
  if (self) {
    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
      [self.widthAnchor constraintEqualToConstant:w],
      [self.heightAnchor constraintEqualToConstant:h],
    ]];
  }
  return self;
}
- (void)drawRect:(CGRect)rect {
  CGRect b = CGRectInset(self.bounds, 3, 3);
  UIBezierPath *p = [UIBezierPath bezierPathWithRoundedRect:b cornerRadius:b.size.width * 0.09];
  CGFloat dashes[] = {12, 9};
  [p setLineDash:dashes count:2 phase:0];
  p.lineWidth = 3.0;
  [[UIColor colorWithWhite:1.0 alpha:0.35] setStroke];
  [p stroke];
}
@end

// ---- the keyboard (search branch, unreleased) -----------------------------
//
//   {"keyboard_submit": "/tv/<dev>/search/{q}/3/0/0",
//    "keyboard_placeholder": "Search your queue"}
//
// WHY THIS EXISTS. The television's search was a chip keyboard -- a-b-c picked
// one letter at a time with the remote -- and the owner's report was simply
// "our search interface doesn't support audio ... I meant voice input". tvOS
// already has a search keyboard with dictation on it; this app was bypassing
// the platform's keyboard and reimplementing a worse one. We do not implement
// voice: we stop getting in its way. The mic on the Siri Remote then works
// because it is the system keyboard's, and it needs Siri enabled on the box.
//
// The scene names a SUBMIT TEMPLATE containing {q}. The text is percent-encoded
// into it, which is why the query rides in a path segment: the search route
// already had that shape, so the server needed no new contract.
@interface HeyKeyboardDelegate : NSObject <UISearchResultsUpdating>
@property(copy, nonatomic) NSString *text;
@property(copy, nonatomic) void (^onDismiss)(NSString *);
// RESULTS FOLLOW THE TEXT. Reported from the couch: "I shouldn't have to press
// menu after I finish typing anything. The UI should automatically search for
// results as I'm typing (or as I'm speaking them); I shouldn't have to goto a
// different UI to see the results."
@property(copy, nonatomic) void (^onLive)(NSString *);
@property(strong, nonatomic) NSTimer *liveTimer;
@end
@implementation HeyKeyboardDelegate
- (void)updateSearchResultsForSearchController:(UISearchController *)sc {
  self.text = sc.searchBar.text ?: @"";
  // DEBOUNCED, because this fires per keystroke and dictation delivers a word
  // at a time. Without it every letter is a round trip and the grid underneath
  // flickers through half-typed queries.
  [self.liveTimer invalidate];
  __weak __typeof__(self) weakSelf = self;
  self.liveTimer = [NSTimer scheduledTimerWithTimeInterval:0.35 repeats:NO block:^(NSTimer *t) {
    (void)t;
    __typeof__(self) me = weakSelf;
    if (me && me.onLive) { me.onLive(me.text ?: @""); }
  }];
}
@end

// The container reports its OWN dismissal. The first attempt at this listened
// for a notification that nothing ever posted, so the keyboard would have
// presented perfectly and then swallowed every search in silence.
@interface HeyKeyboardContainer : UISearchContainerViewController
@property(copy, nonatomic) void (^onGone)(void);
@end
@implementation HeyKeyboardContainer
- (void)viewDidDisappear:(BOOL)animated {
  [super viewDidDisappear:animated];
  if (self.onGone) { void (^g)(void) = self.onGone; self.onGone = nil; g(); }
}
@end

// ---- search results the focus engine can actually reach --------------------
//
// EVERYWHERE ELSE IN THIS APP FOCUS IS SERVER-DRIVEN: the remote sends a press,
// the server answers with a scene whose cursor has moved, and the tiles are
// inert views. That model cannot work underneath a presented keyboard, because
// a modal owns the remote -- every arrow press drives the keypad and none of
// them can reach the scene behind. Reported from the couch: "I can't scroll and
// pick the search result I want ... I have to press the menu button again to
// interact with the search results, at which point I cannot interact with
// search anymore."
//
// So on THIS screen only, the tiles are real focusable controls living inside
// the search controller's own results view, which is what every other TV app
// does (the owner's words: "whatever all the other apps (netflix, appletv+,
// prime, hulu, disney+, hbo, etc) do"). Down off the keyboard moves focus into
// them, Select opens, and nothing has to be dismissed to get there.
@interface HeyFocusTile : UIButton
@property(copy, nonatomic) NSString *path;
@end
@implementation HeyFocusTile
- (void)didUpdateFocusInContext:(UIFocusUpdateContext *)context
       withAnimationCoordinator:(UIFocusAnimationCoordinator *)coordinator {
  [super didUpdateFocusInContext:context withAnimationCoordinator:coordinator];
  BOOL focused = (context.nextFocusedView == self);
  [coordinator addCoordinatedAnimations:^{
    self.transform = focused ? CGAffineTransformMakeScale(1.08, 1.08) : CGAffineTransformIdentity;
    self.layer.borderWidth = focused ? 6 : 0;
    self.layer.borderColor = UIColor.whiteColor.CGColor;
    self.layer.cornerRadius = 12;
  } completion:nil];
}
@end

@interface HeySearchResultsViewController : UIViewController
@property(copy, nonatomic) void (^onPick)(NSString *path);
@property(copy, nonatomic) UIView *(^makeTile)(NSDictionary *item, CGFloat w, CGFloat h);
@property(strong, nonatomic) UIScrollView *scroller;
@property(strong, nonatomic) UILabel *status;
@property(strong, nonatomic) UIImageView *emptyArt;
- (void)showItems:(NSArray *)items columns:(NSInteger)columns
        tileWidth:(CGFloat)tw tileHeight:(CGFloat)th status:(NSString *)statusText;
- (void)showQR:(UIImage *)qr caption:(NSString *)caption;
@end
@implementation HeySearchResultsViewController
- (void)viewDidLoad {
  [super viewDidLoad];
  self.scroller = [[UIScrollView alloc] init];
  self.scroller.translatesAutoresizingMaskIntoConstraints = NO;
  [self.view addSubview:self.scroller];
  self.status = [[UILabel alloc] init];
  self.status.translatesAutoresizingMaskIntoConstraints = NO;
  self.status.font = [UIFont systemFontOfSize:30 weight:UIFontWeightRegular];
  self.status.textColor = [UIColor colorWithWhite:0.62 alpha:1];
  self.status.textAlignment = NSTextAlignmentCenter;
  [self.view addSubview:self.status];
  [NSLayoutConstraint activateConstraints:@[
    [self.scroller.topAnchor constraintEqualToAnchor:self.view.topAnchor constant:24],
    [self.scroller.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [self.scroller.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [self.status.topAnchor constraintEqualToAnchor:self.scroller.bottomAnchor constant:12],
    [self.status.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [self.status.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [self.status.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor constant:-24],
  ]];
}

- (void)showItems:(NSArray *)items columns:(NSInteger)columns
        tileWidth:(CGFloat)tw tileHeight:(CGFloat)th status:(NSString *)statusText {
  for (UIView *v in self.scroller.subviews) { [v removeFromSuperview]; }
  [self.emptyArt removeFromSuperview];
  self.emptyArt = nil;
  self.status.text = statusText ?: @"";
  if (columns < 1) { columns = 1; }
  if (tw < 120) { tw = 120; }
  if (th < 120) { th = 120; }
  CGFloat gap = 36;

  // THE KEYBOARD DECIDES HOW MUCH ROOM IS LEFT, and there is more than one
  // keyboard: the linear a-z strip is shallow, the square grid one is much
  // taller, and the viewer can switch between them at any time with Play/Pause.
  // The server sizes tiles for a full screen and cannot know which is up, so a
  // tile sized for the strip is cut off under the grid. Scale to the height
  // this controller was actually handed, keeping the tile's proportions; never
  // scale UP, because a roomy screen should not inflate the artwork.
  CGFloat available = self.view.bounds.size.height - 24 - 12 - 40 - 24;
  if (available > 160 && th > available) {
    CGFloat scale = available / th;
    th = available;
    tw = tw * scale;
  }

  UIStackView *rows = [[UIStackView alloc] init];
  rows.axis = UILayoutConstraintAxisVertical;
  rows.alignment = UIStackViewAlignmentLeading;
  rows.spacing = gap;
  rows.translatesAutoresizingMaskIntoConstraints = NO;
  UIStackView *row = nil;
  NSInteger inRow = 0, index = 0;
  for (id raw in items) {
    if (![raw isKindOfClass:NSDictionary.class]) { continue; }
    NSDictionary *item = raw;
    if (!row || inRow == columns) {
      row = [[UIStackView alloc] init];
      row.axis = UILayoutConstraintAxisHorizontal;
      row.alignment = UIStackViewAlignmentTop;
      row.spacing = gap;
      row.translatesAutoresizingMaskIntoConstraints = NO;
      [rows addArrangedSubview:row];
      inRow = 0;
    }
    HeyFocusTile *button = [HeyFocusTile buttonWithType:UIButtonTypeCustom];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    button.path = [item[@"select"] isKindOfClass:NSString.class] ? item[@"select"] : nil;
    UIView *art = self.makeTile ? self.makeTile(item, tw, th) : nil;
    if (art) {
      // THE ARTWORK MUST NOT EAT THE PRESS, or the button never fires and the
      // tile looks focusable but does nothing when Selected.
      art.userInteractionEnabled = NO;
      art.translatesAutoresizingMaskIntoConstraints = NO;
      [button addSubview:art];
      [NSLayoutConstraint activateConstraints:@[
        [art.topAnchor constraintEqualToAnchor:button.topAnchor],
        [art.leadingAnchor constraintEqualToAnchor:button.leadingAnchor],
        [art.trailingAnchor constraintEqualToAnchor:button.trailingAnchor],
        [art.bottomAnchor constraintEqualToAnchor:button.bottomAnchor],
      ]];
    }
    [button.widthAnchor constraintEqualToConstant:tw].active = YES;
    [button.heightAnchor constraintEqualToConstant:th].active = YES;
    [button addTarget:self action:@selector(tilePicked:) forControlEvents:UIControlEventPrimaryActionTriggered];
    [row addArrangedSubview:button];
    inRow++; index++;
  }
  [self.scroller addSubview:rows];
  [NSLayoutConstraint activateConstraints:@[
    [rows.topAnchor constraintEqualToAnchor:self.scroller.topAnchor],
    [rows.bottomAnchor constraintEqualToAnchor:self.scroller.bottomAnchor],
    [rows.centerXAnchor constraintEqualToAnchor:self.scroller.centerXAnchor],
  ]];
  if (index > 0) {
    [rows.widthAnchor constraintEqualToConstant:columns * tw + (columns - 1) * gap].active = YES;
  }
}

// THE PHONE IS STILL A WAY IN, and it used to live in the scene behind the
// keyboard -- which this controller now covers. Dropping it silently would have
// removed the only route for a box with no dictation, so the empty state keeps
// it here instead. Not focusable: it is something to point a phone at, not
// something to select.
- (void)showQR:(UIImage *)qr caption:(NSString *)caption {
  for (UIView *v in self.scroller.subviews) { [v removeFromSuperview]; }
  self.status.text = caption ?: @"";
  [self.emptyArt removeFromSuperview];
  self.emptyArt = nil;
  if (qr == nil) { return; }
  // IN THE VIEW, NOT THE SCROLLER. Pinned inside the scroll view it had to be
  // both 260 points tall and as tall as a scroller several times that height,
  // which is unsatisfiable -- UIKit broke one of the constraints and the QR
  // simply never appeared. Nothing scrolls on the empty screen anyway.
  UIImageView *iv = [[UIImageView alloc] initWithImage:qr];
  iv.translatesAutoresizingMaskIntoConstraints = NO;
  [self.view addSubview:iv];
  self.emptyArt = iv;
  [NSLayoutConstraint activateConstraints:@[
    [iv.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [iv.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
    [iv.widthAnchor constraintEqualToConstant:260],
    [iv.heightAnchor constraintEqualToConstant:260],
  ]];
}

- (void)tilePicked:(HeyFocusTile *)sender {
  if (sender.path.length && self.onPick) { self.onPick(sender.path); }
}
@end

@interface HeySceneViewController : UIViewController
@property(copy, nonatomic) NSString *sceneJson;
@property(strong, nonatomic) UIView *contentView;
@property(strong, nonatomic) CAGradientLayer *feltLayer;
@property(nonatomic) BOOL seeded;
// Live-data support (0.4.0). A scene may declare "tick" and/or "fetch"; the
// renderer owns the clock and the socket so the Hey app stays pure.
@property(strong, nonatomic) NSTimer *pollTimer;
@property(copy, nonatomic) NSString *pollSignature;
@property(nonatomic) BOOL fetchInFlight;
// The scene fetch in flight, so a NEWER remote press can supersede it: the
// viewer's latest press wins, instead of waiting behind a stale round trip.
@property(strong, nonatomic) NSURLSessionDataTask *sceneTask;
@property(nonatomic) CFAbsoluteTime lastPressAt;
// Bootstrap fallback: the fetch url baked into the app's OWN first scene
// (tv_scene_init), kept separately from whatever url the poll has since been
// re-armed onto, plus a count of consecutive failed scene-mode polls.
@property(copy, nonatomic) NSString *bootstrapFetchUrl;
// The last url a live search actually asked for, so re-entering the same query
// (a debounce that fires twice, a keystroke that nets out to nothing) does not
// re-ask. Cleared with the keyboard.
@property(copy, nonatomic) NSString *lastLiveSearchUrl;
// The results view the keyboard is presenting over, while it is presenting.
@property(weak, nonatomic) HeySearchResultsViewController *searchResults;
// The live query in flight, cancelled whenever a newer one is typed.
@property(strong, nonatomic) NSURLSessionDataTask *liveSearchTask;
@property(nonatomic) NSInteger consecutiveFetchFailures;
// Back-button support (0.4.6). YES only while the CURRENTLY INSTALLED scene
// declares top-level "handles_back": true; re-evaluated on every scene
// install (renderScene), because scenes change every poll.
@property(nonatomic) BOOL handlesBack;
// What the CURRENTLY INSTALLED scene declared in "keep_awake" -- kept, not just
// applied, because it is only half of the answer: the reel below overrides it
// while a film is actually playing, and the override has to survive the next
// poll re-declaring the scene's own value.
@property(nonatomic) BOOL sceneKeepAwake;
// Whether WE consumed the in-flight Menu press at press-down. The decision
// is captured once in -pressesBegan: and reused for the matching
// ended/cancelled, so a poll that swaps the scene mid-press can never split
// one physical press between the funnel and the system.
@property(nonatomic) BOOL menuPressOwned;
// Sound (0.4.9). The engine is built lazily on the first scene that actually
// asks for a cue, so an app that never declares "sound" allocates no audio
// objects and behaves byte-identically to 0.4.8.
@property(strong, nonatomic) AVAudioEngine *audioEngine;
@property(strong, nonatomic) AVAudioPlayerNode *audioPlayer;
// The cue CURRENTLY sounding. This is the whole idempotence mechanism: a
// scene-mode poll re-installs the document every couple of seconds, so
// starting playback per install would retrigger the cue endlessly. Playback
// changes only when the resolved cue name actually differs from this.
@property(copy, nonatomic) NSString *currentCue;
// Graphics (0.4.9). Remote images are fetched once and reused, keyed by url.
// NSCache so tvOS can evict under pressure rather than growing without bound.
@property(strong, nonatomic) NSCache *imageCache;
// Signing out happens ONCE, not on every poll. The scene that declares it is
// answered by a server that will go on answering it until this television
// stops asking, so without this the id would be re-minted several times a
// second and the screen would never settle.
@property(assign, nonatomic) BOOL forgettingDevice;
// Video (0.4.13). The ATTRACT REEL: a display nobody is using plays the demo
// with sound until someone touches the remote.
@property(strong, nonatomic) AVPlayer *videoPlayer;
@property(strong, nonatomic) AVPlayerLayer *videoLayer;
// The end-of-item observer TOKEN. It has to be kept, because the block form of
// addObserverForName: registers an opaque observer object -- NOT self -- and
// `removeObserver:self` therefore removes nothing. Without the token each
// install leaks a registration.
@property(strong, nonatomic) id videoEndObserver;
// The KEY currently playing -- "file:<name>" for a bundled reel, otherwise the
// url. The same idempotence mechanism the cue uses, and for the same reason:
// the scene is re-installed every couple of seconds, so starting playback per
// install would restart the reel ~30x a minute. It is the resolved key rather
// than the url because a bundled reel has no url at all, and comparing on a
// nil field never matches.
@property(copy, nonatomic) NSString *currentVideo;
// The key that MUST NOT START AGAIN while the scene keeps asking for it. Two
// things put a key here, and both need the identical treatment because the
// server goes on emitting the same scene until it notices something changed:
//   - the VIEWER dismissed it (any remote press stops the reel; without this
//     the next poll restarts it two seconds later and the remote appears dead)
//   - it PLAYED TO THE END with loop:false (the film is over; without this the
//     next poll plays it again, forever)
// A resource that could not be resolved lands here too, so a missing bundle
// file is one log line rather than one every two seconds.
// Cleared when the key changes or video goes away, so a later reel still plays.
@property(copy, nonatomic) NSString *suppressedVideo;
// open_url (open-url branch, unreleased). The LAST value a scene asked this
// app to hand to another app, so the same scene re-installed every poll opens
// it exactly once. Cleared when a scene stops carrying the field.
@property(copy, nonatomic) NSString *openedUrl;
// keyboard (search branch, unreleased). The submit template a scene last asked
// for, so the same scene re-installed on every poll presents the keyboard
// exactly once. Same identity rule as open_url above.
@property(copy, nonatomic) NSString *keyboardArmed;
@property(strong, nonatomic) HeyKeyboardDelegate *keyboardDelegate;
// audio (audio branch, unreleased). A stream playing UNDER the scene -- no
// layer -- for a radio while a page is read. Same identity rule as video: the
// url; the same url re-installed every poll leaves it playing.
@property(strong, nonatomic) AVPlayer *radioPlayer;
@property(copy, nonatomic) NSString *currentRadio;
@property(strong, nonatomic) id radioEndObserver;
// apps (apps branch, unreleased). The schemes from LSApplicationQueriesSchemes
// that canOpenURL answers yes for, comma-joined, probed once per launch and
// sent on every poll as X-Hey-TV-Apps.
@property(copy, nonatomic) NSString *installedSchemesCache;
// The reel's REQUESTED volume, kept apart from the volume actually applied to
// the player. Muting writes 0 to the player and never to this, so unmuting
// restores the volume the scene asked for -- not 1.0, which would blast a room
// the maintainer deliberately keeps quiet.
@property(nonatomic) double videoRequestedVolume;
// ---- per-television sound settings (0.4.13) ------------------------------
// A mute belongs to ONE television in ONE room, so it lives here and in
// NSUserDefaults, never on the server: server-held state would either follow
// every display on the account or need per-display storage that does not
// exist. Both default to NOT muted, which is why the stored fact is "muted"
// rather than "enabled" -- an absent key reads as NO, so a TV that never opens
// the menu sounds exactly as it does today.
@property(nonatomic) BOOL soundtrackMuted;   // sound.file + the attract reel
@property(nonatomic) BOOL effectsMuted;      // sound.cue, the synthesised palette
// THE SCREEN ROW IS NOT A MUTE, and it is the one setting the SERVER acts on.
// 0 auto (the server's own clock decides), 1 dark, 2 light. It is sent as a
// request header on every scene poll rather than stored server-side, for the
// same reason the mutes are not sent at all: this is a property of one
// television in one room, and per-display storage does not exist. Auto is 0 so
// an absent key -- a TV that has never opened the menu -- keeps the automatic
// behaviour it shipped with.
@property(nonatomic) NSInteger screenMode;
// Whether the INSTALLED scene invites the settings menu ("allow_settings").
// Checked, never assumed, exactly like handles_back: a live classroom screen
// must not be openable by a stray press.
@property(nonatomic) BOOL sceneAllowsSettings;
// The overlay: nil whenever it is closed. It is the whole open/closed state,
// so there is no second flag to disagree with it.
@property(strong, nonatomic) UIView *settingsView;
@property(strong, nonatomic) NSArray<UIView *> *settingsRowViews;
@property(strong, nonatomic) NSArray<UILabel *> *settingsStateLabels;
@property(nonatomic) NSInteger settingsIndex;
@end

// ---- bootstrap fallback threshold ---------------------------------------
// A scene-mode poll may re-arm the renderer onto a NEW url: that is how the
// Jackbox-style room handoff works -- a pack bakes ONE generic bootstrap url,
// the server answers with a scene whose own fetch.url is room-specific, and
// the renderer follows it. If that room later disappears (expiry, restart,
// deploy) every poll fails, nothing is ever installed, and the screen is stuck
// on its last frame forever. The server cannot fix it, because the TV is no
// longer asking the server anything it can answer. So the renderer counts
// CONSECUTIVE failed scene polls and, at the limit, re-points the poll at the
// baked url, which re-bootstraps the display with nobody touching the TV.
//
// 5 is chosen against the documented 2000ms default cadence: ~10s of a dead
// screen before recovery is attempted. Fewer (1-2) would throw away a healthy
// room over one Wi-Fi hiccup or a single slow response; many more would leave
// a visibly frozen TV long enough for someone to get up and restart the app,
// which is exactly the failure this removes. It is a COUNT, not a duration, so
// a pack that polls more slowly waits proportionally longer before giving up
// on its room -- the right trade, since a slow cadence implies a slow game.
//
// There is deliberately NO back-off: the cadence is already the app's declared
// fetch.ms, requests never stack (fetchInFlight), and a bounded retry against
// one bootstrap url every few seconds is cheaper than the alternative of a
// screen that stays dead until a human intervenes.
static const NSInteger kHeySceneFetchFailureLimit = 5;

@implementation HeySceneViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = [UIColor colorWithRed:0x10 / 255.0 green:0x18 / 255.0 blue:0x20 / 255.0 alpha:1.0];

  self.contentView = [[UIView alloc] init];
  self.contentView.translatesAutoresizingMaskIntoConstraints = NO;
  [self.view addSubview:self.contentView];
  [NSLayoutConstraint activateConstraints:@[
    [self.contentView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [self.contentView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [self.contentView.topAnchor constraintEqualToAnchor:self.view.topAnchor],
    [self.contentView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
  ]];

  // The per-television mutes, BEFORE the first render: renderScene syncs sound,
  // and a TV booting muted must not make the noise once on its way up.
  [self loadSoundSettings];

  const char *initBytes = hey_fn_tv_scene_init();
  self.sceneJson = HeyStringFromReturn(initBytes);
  // THE PLACEHOLDER BECOMES THIS TELEVISION'S OWN ID, before anything reads a
  // url out of the scene. A pack built for one room bakes a real id and
  // contains no placeholder, so this is a no-op for those and the two kinds of
  // build stay one code path.
  if ([self.sceneJson containsString:kHeyDevicePlaceholder]) {
    self.sceneJson = [self.sceneJson stringByReplacingOccurrencesOfString:kHeyDevicePlaceholder
                                                               withString:[self deviceIdentity]];
  }
  // Capture the BAKED fetch url before any server document can replace it.
  // This is the address the pack was built with and the only one still
  // guaranteed to exist after a room-specific url goes away.
  self.bootstrapFetchUrl = [self fetchUrlInScene:[self parsedScene]];
  [self renderScene];

  // COMING BACK IS A POLL. tvOS suspends this app while Netflix is in front
  // and the poll timer sleeps with it; when the viewer returns, the scene
  // that was owed (the "How was it?" the open screen declared) should be on
  // screen at once, not after the timer catches up. Opaque observer, weak
  // self, the same discipline as the radio observer.
  __weak __typeof__(self) weakActive = self;
  [NSNotificationCenter.defaultCenter addObserverForName:UIApplicationDidBecomeActiveNotification
                                                  object:nil
                                                   queue:NSOperationQueue.mainQueue
                                              usingBlock:^(NSNotification *note) {
    (void)note;
    [weakActive repollForScreenChange];
  }];

  // ---- input: ONE mechanism per input class, no double-fires ------------
  // Directional + Select + Play/Pause arrive as UIPress events and are
  // handled in -pressesBegan: below (simulator arrow keys and hardware
  // edge-clicks both deliver these as presses). The Siri Remote clickpad
  // ALSO reports directional gestures as touch swipes, which never surface
  // as presses -- those are covered by the swipe recognizers here. A given
  // physical input reaches exactly one path, so nothing double-fires. The
  // per-pressType UITapGestureRecognizers are intentionally GONE: they were
  // unreliable for arrow presses on real hardware.
  NSArray<NSNumber *> *swipeDirs = @[
    @(UISwipeGestureRecognizerDirectionUp), @(UISwipeGestureRecognizerDirectionDown),
    @(UISwipeGestureRecognizerDirectionLeft), @(UISwipeGestureRecognizerDirectionRight)
  ];
  for (NSNumber *dir in swipeDirs) {
    UISwipeGestureRecognizer *swipe =
        [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(remoteSwipe:)];
    swipe.direction = (UISwipeGestureRecognizerDirection)dir.unsignedIntegerValue;
    [self.view addGestureRecognizer:swipe];
  }
}

- (BOOL)canBecomeFocused { return YES; }

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
  if (self.seeded) { return; }
  self.seeded = YES;
  long long ms = (long long)([NSDate date].timeIntervalSince1970 * 1000.0);
  NSString *event = [NSString stringWithFormat:@"{\"kind\":\"seed\",\"value\":%lld}", ms];
  [self stepWithEvent:event];
}

- (NSDictionary *)parsedScene {
  NSData *data = [self.sceneJson dataUsingEncoding:NSUTF8StringEncoding];
  if (!data) { return @{}; }
  id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
  return [parsed isKindOfClass:NSDictionary.class] ? parsed : @{};
}

- (void)stepWithEvent:(NSString *)eventJson {
  const char *next = hey_fn_tv_scene_step(self.sceneJson.UTF8String, eventJson.UTF8String);
  NSString *nextScene = HeyStringFromReturn(next);
  if ([nextScene isEqualToString:self.sceneJson]) { return; } // unchanged: skip re-render
  // A REMOTE PRESS IS A REQUEST, NOT A REPAINT. The program answers a press
  // with an interim document: the same widgets under a fast poll of the path
  // the scene named for that button. Painting that interim document is what
  // made every press flicker (it carries no `compact` flag and no hints, so
  // the layout shifted and the bottom line fell off) and waiting for its poll
  // timer cost up to 300 ms before the request left. So the server's scene
  // stays on screen untouched, only the interim document's `fetch` is taken,
  // and it is sent NOW, superseding any scene fetch still in flight: the
  // viewer's latest press wins. Presses keep reading the server's scene, so
  // a second press before the answer lands re-asks from the same cursor
  // rather than being dropped. Every other event renders as before.
  BOOL remote = [eventJson rangeOfString:@"\"kind\":\"remote\""].location != NSNotFound;
  NSLog(@"[hey_ios_tv] step: remote=%d inFlight=%d event=%@", (int)remote, (int)self.fetchInFlight, eventJson);
  if (remote) {
    NSData *bytes = [nextScene dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *interim = bytes ? [NSJSONSerialization JSONObjectWithData:bytes options:0 error:NULL] : nil;
    NSDictionary *fetch = [interim[@"fetch"] isKindOfClass:NSDictionary.class] ? interim[@"fetch"] : nil;
    if ([fetch[@"url"] isKindOfClass:NSString.class] && [fetch[@"mode"] isKindOfClass:NSString.class]
        && [fetch[@"mode"] isEqualToString:@"scene"]) {
      self.lastPressAt = CFAbsoluteTimeGetCurrent();
      if (self.sceneTask) { [self.sceneTask cancel]; self.sceneTask = nil; self.fetchInFlight = NO; }
      [self startFetch:fetch];
      return;
    }
  }
  self.sceneJson = nextScene;
  [self renderScene];
}

// ---- live data: tick + fetch (0.4.0) -----------------------------------
//
// A scene opts in by carrying either of:
//   "tick":  {"ms": 1000}
//   "fetch": {"url": "http://host/path", "ms": 2000, "mode": "scene", "id": "room"}
//
// The timer period comes from tick.ms, else fetch.ms, else 2000, floored at
// 250ms. With mode "scene" the fetched document IS the next scene and the
// renderer installs it directly -- that is what lets a display app project
// server-rendered state without asking the Hey app to parse JSON (the tvOS
// LLVM subset builds documents by string concatenation and cannot decode
// them). Any other mode delivers {"kind":"data",...} through the normal
// event funnel instead.
//
// Networking is NSURLSession on purpose: the Hey runtime excludes its TLS
// client for this target (HEY_RUNTIME_NO_TLS_CLIENT), so it does not provide the
// whole OpenSSL surface with abort() traps, so an HTTPS request issued from
// Hey's own stdlib would kill the app.
//
// Because a fetched scene carries its own fetch declaration, a scene-mode poll
// can move the renderer onto a different url. -noteFailedScenePoll below is the
// way back: see kHeySceneFetchFailureLimit.
- (void)syncLiveDataWithScene:(NSDictionary *)scene {
  NSDictionary *tick = [scene[@"tick"] isKindOfClass:NSDictionary.class] ? scene[@"tick"] : nil;
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;

  double ms = 0.0;
  if ([tick[@"ms"] isKindOfClass:NSNumber.class]) { ms = [tick[@"ms"] doubleValue]; }
  if (ms <= 0.0 && [fetch[@"ms"] isKindOfClass:NSNumber.class]) { ms = [fetch[@"ms"] doubleValue]; }
  if (ms <= 0.0) { ms = 2000.0; }
  if (ms < 250.0) { ms = 250.0; }

  NSString *url = [fetch[@"url"] isKindOfClass:NSString.class] ? fetch[@"url"] : @"";
  NSString *signature = [NSString stringWithFormat:@"%.0f|%@|%@|%@",
                         ms, tick ? @"t" : @"-", url,
                         [fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @""];
  if ([signature isEqualToString:self.pollSignature]) { return; }  // nothing changed
  self.pollSignature = signature;

  [self.pollTimer invalidate];
  self.pollTimer = nil;
  if (!tick && !fetch) { return; }

  __weak __typeof__(self) weakSelf = self;
  self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:(ms / 1000.0)
                                                   repeats:YES
                                                     block:^(NSTimer *timer) {
    (void)timer;
    [weakSelf onLiveDataTimer];
  }];
}

- (void)onLiveDataTimer {
  NSDictionary *scene = [self parsedScene];
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  if ([fetch[@"url"] isKindOfClass:NSString.class]) { [self startFetch:fetch]; }
  if ([scene[@"tick"] isKindOfClass:NSDictionary.class]) {
    long long ms = (long long)([NSDate date].timeIntervalSince1970 * 1000.0);
    [self stepWithEvent:[NSString stringWithFormat:@"{\"kind\":\"tick\",\"ms\":%lld}", ms]];
  }
}

// One poll, right now, because a SETTING changed rather than because time
// passed. The repeating timer is left exactly as it is: re-arming it here would
// slide every subsequent poll to a phase decided by when somebody opened a
// menu, and the poll cadence is the server's to set through `fetch.ms`.
//
// A fetch already in flight carries the OLD header and startFetch refuses to
// stack requests, so in that case the change lands on the next ordinary tick --
// the pre-existing behaviour, which is the right thing to fall back to.
- (void)repollForScreenChange {
  NSDictionary *scene = [self parsedScene];
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  if ([fetch[@"url"] isKindOfClass:NSString.class]) { [self startFetch:fetch]; }
}

- (void)startFetch:(NSDictionary *)fetch {
  if (self.fetchInFlight) { return; }              // never stack requests
  NSURL *url = [NSURL URLWithString:fetch[@"url"]];
  if (!url) { return; }
  BOOL sceneMode = [[fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @""
                    isEqualToString:@"scene"];
  NSString *fetchId = [fetch[@"id"] isKindOfClass:NSString.class] ? fetch[@"id"] : @"";
  self.fetchInFlight = YES;

  // THE SCREEN PREFERENCE RIDES THE POLL, as a header rather than a query
  // parameter. The URL is what the renderer re-arms on and what it compares to
  // decide it has moved rooms, so mangling it here would make every preference
  // change look like a new room. A header changes nothing the renderer keys on
  // and nothing a server that ignores it has to cope with -- an older server
  // simply keeps deciding on its own clock, which is exactly `auto`.
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
  [request setValue:HeyScreenModeName(self.screenMode) forHTTPHeaderField:@"X-Hey-TV-Screen"];
  // WHICH APPS THIS TV CAN OPEN rides the poll the same way (apps branch,
  // unreleased): the server can then default "open it in..." to an app that
  // is actually installed instead of the one the link was saved from. An
  // older server ignores the header; an empty value means none of the listed
  // schemes answered.
  [request setValue:[self installedSchemes] forHTTPHeaderField:@"X-Hey-TV-Apps"];

  __weak __typeof__(self) weakSelf = self;
  CFAbsoluteTime pressAt = self.lastPressAt;
  self.lastPressAt = 0;
  NSURLSessionDataTask *task =
      [NSURLSession.sharedSession dataTaskWithRequest:request
                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    if (error.code == NSURLErrorCancelled) { return; }   // superseded by a newer press
    long long status = [response isKindOfClass:NSHTTPURLResponse.class]
                           ? (long long)((NSHTTPURLResponse *)response).statusCode : 0;
    NSString *body = data.length ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
    dispatch_async(dispatch_get_main_queue(), ^{
      __typeof__(self) strongSelf = weakSelf;
      if (!strongSelf) { return; }
      strongSelf.fetchInFlight = NO;
      strongSelf.sceneTask = nil;
      if (sceneMode) {
        // Only a successful, non-empty document may replace the scene; a
        // failed poll must leave whatever is on screen untouched.
        if (status == 200 && body.length) {
          strongSelf.consecutiveFetchFailures = 0;   // the streak is broken
          if (![body isEqualToString:strongSelf.sceneJson]) {
            strongSelf.sceneJson = body;
            [strongSelf renderScene];
            if (pressAt > 0) {
              NSLog(@"[hey_ios_tv] press -> scene on screen in %.0f ms", (CFAbsoluteTimeGetCurrent() - pressAt) * 1000.0);
            }
          }
        } else {
          // Transport error, timeout, non-2xx, or an empty body: everything
          // that did NOT yield an installable document counts against the
          // bootstrap-fallback streak. `error` is folded in here rather than
          // inspected -- a failed transport reports status 0 and no body.
          [strongSelf noteFailedScenePoll];
        }
        return;
      }
      NSDictionary *event = @{ @"kind": @"data", @"id": fetchId,
                               @"status": @(status), @"body": body ?: @"" };
      NSData *json = [NSJSONSerialization dataWithJSONObject:event options:0 error:NULL];
      if (!json) { return; }
      [strongSelf stepWithEvent:[[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding]];
    });
  }];
  if (sceneMode) { self.sceneTask = task; }
  [task resume];
}

// The schemes this TV can open, out of the ones Info.plist declares it may ask
// about (LSApplicationQueriesSchemes), as "nflx,youtube,hulu". Probed once:
// canOpenURL is cheap but the answer only changes when an app is installed,
// and the app relaunches for that anyway.
- (NSString *)installedSchemes {
  if (self.installedSchemesCache != nil) { return self.installedSchemesCache; }
  id declared = NSBundle.mainBundle.infoDictionary[@"LSApplicationQueriesSchemes"];
  NSArray *schemes = [declared isKindOfClass:NSArray.class] ? declared : @[];
  NSMutableArray<NSString *> *found = [NSMutableArray array];
  for (id scheme in schemes) {
    if (![scheme isKindOfClass:NSString.class] || ((NSString *)scheme).length == 0) { continue; }
    NSURL *probe = [NSURL URLWithString:[NSString stringWithFormat:@"%@://", scheme]];
    if (probe && [UIApplication.sharedApplication canOpenURL:probe]) { [found addObject:scheme]; }
  }
  self.installedSchemesCache = [found componentsJoinedByString:@","];
  NSLog(@"[hey_ios_tv] apps: %@", self.installedSchemesCache.length ? self.installedSchemesCache : @"(none of the declared schemes)");
  return self.installedSchemesCache;
}

// The fetch url a scene document declares, or nil when it declares none.
- (NSString *)fetchUrlInScene:(NSDictionary *)scene {
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  NSString *url = [fetch[@"url"] isKindOfClass:NSString.class] ? fetch[@"url"] : nil;
  return url.length ? url : nil;
}

// One failed scene-mode poll. At kHeySceneFetchFailureLimit consecutive
// failures, re-point the poll at the baked bootstrap url so the screen can
// re-bootstrap itself onto a fresh room with no human involved.
//
// Recovery rewrites ONLY fetch.url in the scene currently on screen; the
// widgets are left exactly as they are, so the display keeps showing its last
// good frame until the bootstrap url answers with a real document. Re-render
// is what re-arms the timer, via the usual syncLiveDataWithScene signature.
//
// This applies to scene mode only. In any other mode the Hey app owns the
// scene and already sees the failure as a {"kind":"data","status":...} event,
// so the renderer must not overrule it.
- (void)noteFailedScenePoll {
  NSString *bootstrap = self.bootstrapFetchUrl;
  if (!bootstrap.length) { return; }   // nothing was baked in: nowhere to go

  if (self.consecutiveFetchFailures < kHeySceneFetchFailureLimit) {
    self.consecutiveFetchFailures++;   // clamped: a long outage cannot overflow
  }
  if (self.consecutiveFetchFailures < kHeySceneFetchFailureLimit) { return; }

  NSDictionary *scene = [self parsedScene];
  NSDictionary *fetch = [scene[@"fetch"] isKindOfClass:NSDictionary.class] ? scene[@"fetch"] : nil;
  NSString *mode = [fetch[@"mode"] isKindOfClass:NSString.class] ? fetch[@"mode"] : @"";
  if (![mode isEqualToString:@"scene"]) { return; }  // scene swapped out under us
  NSString *current = [self fetchUrlInScene:scene];
  // Already home: keep hammering the bootstrap url on its normal cadence
  // rather than re-installing the same document over and over.
  if (current && [current isEqualToString:bootstrap]) { return; }

  NSMutableDictionary *nextScene = [scene mutableCopy];
  NSMutableDictionary *nextFetch = [fetch mutableCopy];
  nextFetch[@"url"] = bootstrap;
  nextScene[@"fetch"] = nextFetch;
  NSData *json = [NSJSONSerialization dataWithJSONObject:nextScene options:0 error:NULL];
  if (!json) { return; }
  NSString *doc = [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding];
  if (!doc.length) { return; }

  NSLog(@"[hey_ios_tv] %ld consecutive failed scene polls of %@; returning to bootstrap url %@",
        (long)self.consecutiveFetchFailures, current ?: @"(none)", bootstrap);
  self.consecutiveFetchFailures = 0;   // give the bootstrap url a full budget
  self.sceneJson = doc;
  [self renderScene];
}

- (void)viewWillDisappear:(BOOL)animated {
  [super viewWillDisappear:animated];
  [self.pollTimer invalidate];
  self.pollTimer = nil;
  self.pollSignature = nil;   // so returning to the view reschedules
  self.consecutiveFetchFailures = 0;   // and starts its failure budget fresh
}

- (void)dealloc {
  [_pollTimer invalidate];
}

// Maps a UIPress type to the scene "button" name, or nil for types we do
// NOT own unconditionally. Menu is deliberately ABSENT from this table: it
// is owned per-scene (see -ownsMenuPress:), because a renderer that always
// swallows Menu makes the app inescapable at its root -- Menu-at-root must
// keep suspending the app (tvOS convention and an App Store requirement).
static NSString *HeyButtonForPressType(UIPressType type) {
  switch (type) {
    case UIPressTypeSelect: return @"select";
    case UIPressTypeUpArrow: return @"up";
    case UIPressTypeDownArrow: return @"down";
    case UIPressTypeLeftArrow: return @"left";
    case UIPressTypeRightArrow: return @"right";
    case UIPressTypePlayPause: return @"playpause";
    default: return nil;   // anything else: never swallowed
  }
}

// ---- the back button: Menu, per-scene (0.4.6) ---------------------------
//
// The 'back' event existed only in specs before 0.4.6: HeyButtonForPressType
// had no Menu case, so on hardware a Menu press never reached the scene
// funnel and a multi-screen app was inescapable without remapping back onto
// other buttons (field defect, RecallCoach demo, 2026-07-30).
//
// A scene now claims the press by declaring, at the top level of the scene
// document, "handles_back": true. While the installed scene declares it,
// press-down delivers {"kind":"remote","button":"back"} through the normal
// event funnel. When the field is absent or false the press is forwarded to
// super exactly as before, so tvOS still suspends the app -- absent means
// false, and every pre-0.4.6 scene behaves byte-identically.
//
// The flag is cached at install time (syncBackHandlingWithScene, called from
// renderScene like keep_awake) rather than parsed per press, and re-evaluated
// on EVERY install because scene-mode polls replace the document every few
// seconds: a server can hand out "handles_back": true on a question screen
// and drop it on the lobby screen, restoring Menu-suspends at the root.
- (void)syncBackHandlingWithScene:(NSDictionary *)scene {
  BOOL wanted = NO;
  id declared = scene[@"handles_back"];
  if ([declared isKindOfClass:NSNumber.class]) { wanted = [declared boolValue]; }
  if (self.handlesBack == wanted) { return; }
  self.handlesBack = wanted;
  NSLog(@"[hey_ios_tv] handles_back=%@ (Menu %@)",
        wanted ? @"true" : @"false",
        wanted ? @"delivered to the scene as 'back'" : @"bubbles to tvOS");
}

// ---- sound (0.4.9) -------------------------------------------------------
//
// A scene declares, at the top level:
//
//   {"sound": {"cue": "think", "volume": 0.35}}
//
// WHY THE CUES ARE SYNTHESISED AND NOT SHIPPED AS AUDIO FILES. The exported
// pack stays a pure code artifact -- no asset bundle, no loader, no path
// resolution on the device -- and a cue is a few hundred bytes of coefficients
// instead of a megabyte of PCM. It is also far easier to TUNE: changing the
// mood is editing a note table, not re-recording and re-exporting audio.
//
// The palette takes its INSPIRATION from the game-show era -- that warm,
// slightly nostalgic "the room is thinking" feel. It is composed here, in note
// tables, rather than sampled from anything.
//
// THE PALETTE IS DELIBERATELY NOT A CLOCK (maintainer, 2026-08-07: "We do NOT
// want a ticking clock that is obnoxious and pressures students. We want light
// & fun"). `think` is a four-note figure on a MAJOR PENTATONIC scale, whose
// defining property is that no two notes in it can beat against each other --
// there is no semitone and no tritone, so it cannot build tension however long
// it loops. A tick would do the opposite: a metronome is a deadline you can
// hear, and it hurts precisely the students who are already anxious.
typedef struct {
  double at;    // seconds from the start of the buffer
  double hz;
  double dur;   // seconds; the envelope decays across this
  double amp;   // 0..1 before the master volume is applied
} HeyCueNote;

// THE THINKING BED. A two-bar phrase at a relaxed ~100bpm: a soft WALKING BASS
// under a sparse pentatonic melody. The bass is what makes it read as
// game-show nostalgia rather than a ringtone -- that era's thinking music is
// always a gentle walking figure, and without it the melody alone sounds like
// a notification chime.
//
// It is a real phrase, not a one-bar fragment on repeat: it steps up, turns
// around, and RESOLVES to C before the loop, with a rest in the last half
// second so the repeat breathes instead of nagging. Everything is on the C
// major pentatonic (C D E G A) -- no semitone, no tritone -- so however many
// times it comes round it cannot sour or build tension.
//
// THE STRUCTURAL FACTS ARE BORROWED; THE TUNE IS NOT. The quiz-show thinking
// bed everyone remembers is in C MAJOR, 4/4, at ROUGHLY 132bpm. Those are
// facts about a genre -- a key, a meter, a tempo -- and they are what actually
// carry the nostalgia. The MELODY below is our own: a I-vi-IV-V turnaround
// with a pentatonic line over it, which is the most ordinary progression in
// popular music and belongs to nobody.
//
// The earlier draft sat at ~100bpm and that was the single biggest thing
// wrong with it -- too slow to feel like a game show, it read as lounge music.
//
// 132bpm -> beat 0.4545s, bar 1.8182s, four bars 7.2727s.
//
// A2 110.00 / C3 130.81 / E3 164.81 / F3 174.61 / G3 196.00
// C5 523.25 / D5 587.33 / E5 659.25 / G5 783.99 / A5 880.00
static const HeyCueNote kHeyCueThink[] = {
    // Walking bass on the half note, I - vi - IV - V. Low, quiet, long decay:
    // felt more than heard, and it is what stops the melody reading as a
    // notification chime.
    {0.0000, 130.81, 0.85, 0.10}, {0.4545 * 2, 196.00, 0.85, 0.09},
    {1.8182, 110.00, 0.85, 0.10}, {1.8182 + 0.9091, 164.81, 0.85, 0.09},
    {3.6364, 174.61, 0.85, 0.10}, {3.6364 + 0.9091, 130.81, 0.85, 0.09},
    {5.4545, 196.00, 0.85, 0.10}, {5.4545 + 0.9091, 196.00, 0.85, 0.09},
    // Our melody: up through bar 2, turn at bar 3, and leave it UNRESOLVED on
    // D so the loop pulls forward into the next repeat instead of stopping.
    {0.0000, 659.25, 0.80, 0.12}, {0.9091, 783.99, 0.80, 0.11},
    {1.8182, 880.00, 0.80, 0.12}, {2.7273, 783.99, 0.80, 0.11},
    {3.6364, 659.25, 0.80, 0.12}, {4.5455, 587.33, 0.80, 0.11},
    {5.4545, 659.25, 0.80, 0.12}, {6.3636, 587.33, 0.60, 0.10},
};
// A quick major triad: "here comes the answer", not "you were wrong".
static const HeyCueNote kHeyCueReveal[] = {
    {0.00, 523.25, 0.50, 0.15}, {0.08, 659.25, 0.55, 0.14},
    {0.16, 783.99, 0.70, 0.13},
};
// One short blip for a joiner. Quiet on purpose: in a class of thirty this
// fires thirty times in a minute, and anything louder becomes a nuisance.
static const HeyCueNote kHeyCueJoin[] = {{0.00, 783.99, 0.22, 0.10}};
// The finish. Brighter and an octave taller, but still pentatonic.
static const HeyCueNote kHeyCueCelebrate[] = {
    {0.00, 523.25, 0.45, 0.15}, {0.10, 659.25, 0.45, 0.15},
    {0.20, 783.99, 0.50, 0.15}, {0.30, 1046.50, 0.90, 0.16},
};

// Returns nil for an unknown or silent cue -- the caller treats that as "stop",
// so a typo silences rather than crashing, matching how an unknown widget kind
// renders a placeholder instead of trapping.
static AVAudioPCMBuffer *HeyCueBuffer(NSString *cue, AVAudioFormat *format, BOOL *outLoops) {
  const HeyCueNote *notes = NULL;
  size_t count = 0;
  double seconds = 0.0;
  BOOL loops = NO;

  if ([cue isEqualToString:@"think"]) {
    notes = kHeyCueThink; count = sizeof(kHeyCueThink) / sizeof(kHeyCueThink[0]);
    seconds = 7.2727; loops = YES;        // four bars at 132bpm, 4/4
  } else if ([cue isEqualToString:@"reveal"]) {
    notes = kHeyCueReveal; count = sizeof(kHeyCueReveal) / sizeof(kHeyCueReveal[0]);
    seconds = 1.00;
  } else if ([cue isEqualToString:@"join"]) {
    notes = kHeyCueJoin; count = sizeof(kHeyCueJoin) / sizeof(kHeyCueJoin[0]);
    seconds = 0.30;
  } else if ([cue isEqualToString:@"celebrate"]) {
    notes = kHeyCueCelebrate; count = sizeof(kHeyCueCelebrate) / sizeof(kHeyCueCelebrate[0]);
    seconds = 1.50;
  } else {
    return nil;
  }
  if (outLoops) { *outLoops = loops; }

  double sr = format.sampleRate;
  AVAudioFrameCount frames = (AVAudioFrameCount)(seconds * sr);
  AVAudioPCMBuffer *buffer = [[AVAudioPCMBuffer alloc] initWithPCMFormat:format frameCapacity:frames];
  if (!buffer || !buffer.floatChannelData) { return nil; }
  buffer.frameLength = frames;

  float *left = buffer.floatChannelData[0];
  memset(left, 0, (size_t)frames * sizeof(float));
  for (size_t n = 0; n < count; n++) {
    HeyCueNote note = notes[n];
    AVAudioFrameCount start = (AVAudioFrameCount)(note.at * sr);
    AVAudioFrameCount len = (AVAudioFrameCount)(note.dur * sr);
    for (AVAudioFrameCount i = 0; i < len && (start + i) < frames; i++) {
      double t = (double)i / sr;
      // A PIANO-SHAPED TONE. Three things separate a piano from the plain
      // sine-plus-two-harmonics this used to be, and all three matter more to
      // "does it sound nostalgic" than the notes do:
      //
      // 1. MANY PARTIALS, falling off about 1/n. A piano is bright at the
      //    attack because the upper partials are genuinely loud for a moment.
      // 2. HIGHER PARTIALS DIE FIRST. The decay rate grows with the partial
      //    number, so the tone gets progressively darker as it rings -- that
      //    darkening IS the piano character. A fixed envelope across all
      //    partials sounds like an organ.
      // 3. A SHORT ATTACK RAMP. Not for realism, for hygiene: starting a
      //    partial at full amplitude puts a step discontinuity in the buffer,
      //    which is an audible click on every note.
      double attack = t < 0.004 ? (t / 0.004) : 1.0;
      double w = 0.0;
      for (int p = 1; p <= 8; p++) {
        double partial_amp = 1.0 / (double)p;
        double partial_env = exp(-(2.4 + 0.75 * (double)p) * t / note.dur);
        w += partial_amp * partial_env * sin(2.0 * M_PI * note.hz * (double)p * t);
      }
      double env = attack;
      // MASTER GAIN, MEASURED RATHER THAN GUESSED. The note amplitudes set the
      // BALANCE between voices; this sets the absolute level. The first draft
      // used 0.55 and the loudest cue peaked at 0.132 -- which the default
      // volume then scaled to ~0.046, i.e. inaudible across a classroom. That
      // is a bug you cannot hear in code review; it was found by rendering the
      // samples to a file and measuring the peak.
      //
      // 2.19 puts the piano timbre's peak at ~0.75, so the 0.6 default volume
      // lands near 0.45: carries to the back of a room, still under speech,
      // and well clear of clipping. RE-MEASURE THIS IF THE TIMBRE CHANGES --
      // the old sine-plus-two-harmonics needed 3.0 for the same peak, so the
      // constant is a property of the waveform, not a taste setting.
      left[start + i] += (float)(note.amp * env * w * 2.19);
    }
  }
  // Identical in both ears: a cue that moves across the room would draw
  // attention to itself, which is the opposite of a background bed.
  if (format.channelCount > 1 && buffer.floatChannelData[1]) {
    memcpy(buffer.floatChannelData[1], left, (size_t)frames * sizeof(float));
  }
  return buffer;
}

- (BOOL)ensureAudioEngine {
  if (self.audioEngine.isRunning) { return YES; }
  if (!self.audioEngine) {
    NSError *sessionError = nil;
    // AMBIENT, not Playback: it mixes with whatever else is playing and never
    // claims the system audio route. A quiz screen has no business stopping
    // the music someone already had on in the room.
    [AVAudioSession.sharedInstance setCategory:AVAudioSessionCategoryAmbient error:&sessionError];
    [AVAudioSession.sharedInstance setActive:YES error:&sessionError];
    if (sessionError) { NSLog(@"[hey_ios_tv] audio session: %@", sessionError.localizedDescription); }

    AVAudioEngine *engine = [[AVAudioEngine alloc] init];
    AVAudioPlayerNode *player = [[AVAudioPlayerNode alloc] init];
    [engine attachNode:player];
    AVAudioFormat *format = [[AVAudioFormat alloc] initStandardFormatWithSampleRate:44100.0 channels:2];
    [engine connect:player to:engine.mainMixerNode format:format];
    self.audioEngine = engine;
    self.audioPlayer = player;
  }
  NSError *startError = nil;
  if (![self.audioEngine startAndReturnError:&startError]) {
    // Audio is a garnish. If the engine will not start we log it and the app
    // carries on silently -- a quiz that refuses to run because a chime failed
    // would be a far worse bug than no chime.
    NSLog(@"[hey_ios_tv] audio engine did not start: %@", startError.localizedDescription);
    return NO;
  }
  return YES;
}

// Called from renderScene on EVERY install, exactly like handles_back. The
// guard below is what makes that safe: a scene-mode poll replaces the document
// every couple of seconds, and restarting the cue each time would machine-gun
// it. Playback changes ONLY when the resolved cue name differs.
//
// ABSENT MEANS SILENCE, not "unchanged". That is the additive-compatible
// reading -- every pre-0.4.9 scene declares no "sound" and therefore plays
// none, byte-identically to 0.4.8 -- and it is also the only reading that
// cannot get stuck: were absence to mean "carry on", a server that stopped
// emitting the field could never turn the sound off again.
// A BUNDLED AUDIO FILE, decoded once into a buffer. `name` is a bundle
// resource name with extension, e.g. "question-to-answer.m4a" -- never a path,
// because the caller is a server-rendered scene document and must not be able
// to name an arbitrary location on the device.
// THE CONTRACT ABOVE, IN ONE PLACE, because video now names bundled files the
// same way audio does and two copies of a security check drift. `subsystem` is
// only the log prefix, so each caller's lines read as they always did.
- (NSString *)bundlePathForResourceName:(NSString *)name subsystem:(NSString *)subsystem {
  NSString *stem = name.stringByDeletingPathExtension;
  NSString *ext = name.pathExtension;
  if (!stem.length || !ext.length) { return nil; }
  // Reject anything that tries to escape the bundle. A scene comes off the
  // network; treating its strings as trusted paths would be the bug.
  if ([name containsString:@"/"] || [name containsString:@".."]) {
    NSLog(@"[hey_ios_tv] %@: refusing path-like file name %@", subsystem, name);
    return nil;
  }
  NSString *path = [NSBundle.mainBundle pathForResource:stem ofType:ext];
  if (!path) {
    NSLog(@"[hey_ios_tv] %@: %@ is not in the app bundle", subsystem, name);
    return nil;
  }
  return path;
}

- (AVAudioPCMBuffer *)bufferForBundledFile:(NSString *)name {
  NSString *path = [self bundlePathForResourceName:name subsystem:@"sound"];
  if (!path) { return nil; }
  NSError *error = nil;
  AVAudioFile *file = [[AVAudioFile alloc] initForReading:[NSURL fileURLWithPath:path] error:&error];
  if (!file) {
    NSLog(@"[hey_ios_tv] sound: could not open %@: %@", name, error.localizedDescription);
    return nil;
  }
  // Decode into the PLAYER's format, not the file's: the mixer connection is
  // 44.1k stereo float and scheduling a 48k buffer onto it plays at the wrong
  // speed. AVAudioFile converts on read when the buffer format differs.
  AVAudioFormat *format = [self.audioPlayer outputFormatForBus:0];
  AVAudioFrameCount frames =
      (AVAudioFrameCount)(file.length * format.sampleRate / file.fileFormat.sampleRate) + 1024;
  AVAudioPCMBuffer *buffer = [[AVAudioPCMBuffer alloc] initWithPCMFormat:format frameCapacity:frames];
  if (!buffer) { return nil; }
  if (![file readIntoBuffer:buffer error:&error]) {
    NSLog(@"[hey_ios_tv] sound: could not decode %@: %@", name, error.localizedDescription);
    return nil;
  }
  return buffer;
}

- (void)syncSoundWithScene:(NSDictionary *)scene {
  NSDictionary *sound = [scene[@"sound"] isKindOfClass:NSDictionary.class] ? scene[@"sound"] : nil;
  NSString *cue = [sound[@"cue"] isKindOfClass:NSString.class] ? sound[@"cue"] : @"silence";
  NSString *fileName = [sound[@"file"] isKindOfClass:NSString.class] ? sound[@"file"] : nil;

  // ONE IDENTITY FOR "WHAT IS SOUNDING", whether it came from a file or the
  // synthesiser. Everything downstream compares this, so a file cue gets the
  // same across-poll idempotence a synthesised one does.
  NSString *wanted = fileName.length ? [@"file:" stringByAppendingString:fileName] : cue;
  NSString *playing = self.currentCue ?: @"silence";
  if ([wanted isEqualToString:playing]) { return; }   // already sounding; leave it alone

  [self.audioPlayer stop];
  self.currentCue = wanted;
  if (!fileName.length && [cue isEqualToString:@"silence"]) {
    NSLog(@"[hey_ios_tv] sound=silence");
    return;
  }
  // THE PER-TELEVISION MUTE, applied to the shape of the audio rather than to
  // the audio itself: a bundled file is the SOUNDTRACK, a synthesised cue is a
  // SOUND EFFECT, and the two are muted independently. currentCue keeps the
  // value it would have had, so a muted TV is idempotent across polls exactly
  // like an audible one and does not re-decide every couple of seconds.
  if (fileName.length ? self.soundtrackMuted : self.effectsMuted) {
    NSLog(@"[hey_ios_tv] sound=%@ suppressed (%@ muted on this television)",
          wanted, fileName.length ? @"soundtrack" : @"sound effects");
    return;
  }
  if (![self ensureAudioEngine]) { return; }

  AVAudioFormat *format = [self.audioPlayer outputFormatForBus:0];
  BOOL loops = NO;
  AVAudioPCMBuffer *buffer = nil;
  if (fileName.length) {
    buffer = [self bufferForBundledFile:fileName];
    // A file cue declares its own repeat behaviour: unlike the synthesised
    // palette, whether a recording should repeat is a property of the
    // RECORDING, not of the cue name.
    loops = [sound[@"loop"] isKindOfClass:NSNumber.class] ? [sound[@"loop"] boolValue] : NO;
  } else {
    buffer = HeyCueBuffer(cue, format, &loops);
  }
  if (!buffer) {
    NSLog(@"[hey_ios_tv] sound: nothing to play for %@ (treated as silence)", wanted);
    self.currentCue = @"silence";
    return;
  }
  // 0.6 against the measured peaks above gives an effective peak near 0.45 --
  // clearly audible at the back of a room, still sitting under speech.
  double volume = [sound[@"volume"] isKindOfClass:NSNumber.class]
                      ? [sound[@"volume"] doubleValue] : 0.6;
  if (volume < 0.0) { volume = 0.0; }
  if (volume > 1.0) { volume = 1.0; }
  self.audioPlayer.volume = (float)volume;

  [self.audioPlayer scheduleBuffer:buffer
                            atTime:nil
                           options:loops ? AVAudioPlayerNodeBufferLoops : 0
                 completionHandler:nil];
  [self.audioPlayer play];
  NSLog(@"[hey_ios_tv] sound=%@ (%@, volume %.2f)", wanted, loops ? @"looping" : @"once", volume);
}

// ---- the sound settings, as stored facts ---------------------------------
// Stored as "muted", never as "enabled". -boolForKey: answers NO for a key
// that was never written, so the default falls out of the storage instead of
// being remembered somewhere: a television that has never opened the menu is
// audible, which is the compatibility contract.
static NSString *const kHeySoundtrackMutedKey = @"hey_ios_tv.soundtrack_muted";
static NSString *const kHeyEffectsMutedKey = @"hey_ios_tv.effects_muted";
static NSString *const kHeyScreenModeKey = @"hey_ios_tv.screen_mode";
// ONE TELEVISION, ONE IDENTITY, MINTED HERE AND NOWHERE ELSE.
//
// A pack used to bake the device id it browses as, which is right for a pack
// built for one Apple TV in one room and catastrophic for one handed to the
// App Store: every copy of the first App Store app built this way carried its
// maintainer's own paired device id, so the first stranger who installed it
// was shown the maintainer's library. Reported 2026-09-13.
//
// A distribution pack now bakes the placeholder below instead, and this is
// what replaces it. NSUserDefaults, because the id must survive a relaunch --
// a television that mints a new one every boot is a television that has to be
// paired every boot -- and must NOT survive a delete, which is exactly what
// NSUserDefaults does.
//
// NOT identifierForVendor: that is stable per vendor per device, so two people
// in one household sharing an Apple TV would share an identity, and deleting
// the app would not shake it off. A random 96-bit value is the same shape the
// per-room packs already mint (bin/tv-build) and has neither problem.
static NSString *const kHeyDeviceIdKey = @"hey_ios_tv.device_id";
// The placeholder a distribution pack bakes where its device id would go
// (0.4.18 spelling; the unpublished working copy used an app-specific one).
static NSString *const kHeyDevicePlaceholder = @"__HEY_TV_DEVICE__";

// auto | dark | light -- the wire vocabulary, and the ONLY place it is spelled.
static NSString *HeyScreenModeName(NSInteger mode) {
  if (mode == 1) { return @"dark"; }
  if (mode == 2) { return @"light"; }
  return @"auto";
}

// The id this television is known by. Read once, minted on first launch.
- (NSString *)deviceIdentity {
  NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
  NSString *found = [defaults stringForKey:kHeyDeviceIdKey];
  if (found.length > 0) { return found; }
  // 12 bytes, hex, prefixed -- byte for byte the shape bin/tv-build mints for a
  // single-room pack, so the server cannot tell the two apart and needs no new
  // rule to accept one.
  // arc4random_buf, not SecRandomCopyBytes: it is seeded by the kernel, is in
  // libc so it needs no extra framework linked, and -- the part that matters
  // here -- has no failure path at all. A random source that can fail needs a
  // fallback, and every fallback anyone reaches for under time pressure is
  // more predictable than this, which is the shape of the bug being fixed.
  uint8_t raw[12];
  arc4random_buf(raw, sizeof(raw));
  NSMutableString *hex = [NSMutableString stringWithString:@"tv-"];
  for (size_t i = 0; i < sizeof(raw); i++) { [hex appendFormat:@"%02x", raw[i]]; }
  [defaults setObject:hex forKey:kHeyDeviceIdKey];
  [defaults synchronize];
  NSLog(@"[hey_ios_tv] minted this television's id: %@", hex);
  return hex;
}

// SIGNING OUT IS FORGETTING WHO WE ARE. The server can revoke the pairing, but
// only this side can stop presenting the same identity afterwards -- and a
// television that is unpaired while keeping its id is one the owner can pair
// straight back, which is not what "sign out" means to the person pressing it.
- (void)forgetDeviceIdentity {
  [NSUserDefaults.standardUserDefaults removeObjectForKey:kHeyDeviceIdKey];
  [NSUserDefaults.standardUserDefaults synchronize];
  NSLog(@"[hey_ios_tv] this television forgot its id; a new one is minted on the next launch");
}

- (void)loadSoundSettings {
  NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
  self.soundtrackMuted = [defaults boolForKey:kHeySoundtrackMutedKey];
  self.effectsMuted = [defaults boolForKey:kHeyEffectsMutedKey];
  // integerForKey answers 0 for an absent key, which IS auto -- so a TV that
  // has never opened the menu keeps the server's clock, unchanged.
  self.screenMode = [defaults integerForKey:kHeyScreenModeKey];
  if (self.screenMode < 0 || self.screenMode > 2) { self.screenMode = 0; }
  if (self.soundtrackMuted || self.effectsMuted || self.screenMode != 0) {
    NSLog(@"[hey_ios_tv] settings: soundtrack %@, effects %@, screen %@",
          self.soundtrackMuted ? @"muted" : @"on", self.effectsMuted ? @"muted" : @"on",
          HeyScreenModeName(self.screenMode));
  }
}

// ONE path for every mute change, so nothing can be muted in storage and still
// sounding. Called after either flag is flipped.
- (void)applySoundSettings {
  NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
  [defaults setBool:self.soundtrackMuted forKey:kHeySoundtrackMutedKey];
  [defaults setBool:self.effectsMuted forKey:kHeyEffectsMutedKey];
  [defaults setInteger:self.screenMode forKey:kHeyScreenModeKey];

  // A film ALREADY PLAYING goes quiet now, not at the next reel: the whole
  // point of the menu is the noise happening in the room while you stand there.
  [self applyVideoVolume];

  // Re-decide the scene's own audio from scratch. currentCue has to be cleared
  // first or the idempotence guard would see "already sounding" and skip the
  // re-evaluation that unmuting exists to cause.
  [self.audioPlayer stop];
  self.currentCue = nil;
  [self syncSoundWithScene:[self parsedScene]];
}

- (void)fireRemoteButton:(NSString *)button {
  NSString *event = [NSString stringWithFormat:@"{\"kind\":\"remote\",\"button\":\"%@\"}", button];
  [self stepWithEvent:event];
}

// The action fires exactly once, on press-down. Any press we do not own --
// including Menu whenever the installed scene does not declare
// "handles_back": true -- is forwarded to super so the system default
// (suspend/exit) still runs.

// ---- the attract reel (0.4.13) -------------------------------------------
//
//   {"video": {"file": "attract-reel.mp4", "loop": false, "volume": 0.2}}
//   {"video": {"url": "https://...", "loop": true, "volume": 0.2}}
//
// A display that has been sitting idle plays this full-bleed with sound. It is
// the one screen in the product nobody is looking at, which is exactly why it
// is worth something: a classroom TV waiting for a lesson can be selling the
// product instead of showing a code.
//
// NOT the tvOS top shelf, which was tried first and abandoned: top-shelf
// preview video is played MUTED with no way to change it, and this film is cut
// around its soundtrack.
//
// The reel SHIPS IN THE APP (maintainer, 2026-08-08): "file" names a bundle
// resource, resolved exactly the way {"sound": {"file": ...}} resolves one --
// a name with extension, never a path, because a scene document comes off the
// network and must not be able to name a location on the device. "url" remains
// for a remote film; when both are present the bundled one wins, since it is
// the one guaranteed to be there.
//
// ABSENT MEANS STOP, so a scene that stops emitting video tears the player down
// and every older scene keeps behaving exactly as it did.

// ---- open_url (open-url branch, unreleased) -----------------------------
//
//   {"open_url": "nflx://www.netflix.com/title/80234304"}
//
// A document-level string: hand this URL to whichever app registered its
// scheme (Netflix, YouTube, Prime Video, ...). This is the one sanctioned way
// a tvOS app launches another app; there is no web view and no way to read
// what the other app then does. Same additive rule as video: ABSENT means
// nothing happens and the last value is forgotten, so an older scene renders
// exactly as before. Opened ONCE per distinct value, because a scene-mode poll
// re-installs the same document every couple of seconds and re-firing would
// bounce the viewer back into the other app every poll. The scene the server
// serves after this one is what asks the viewer how it was.
- (void)applyOpenUrl:(NSDictionary *)scene {
  NSString *wanted = [scene[@"open_url"] isKindOfClass:NSString.class] ? scene[@"open_url"] : nil;
  if (wanted.length == 0) {
    self.openedUrl = nil;
    return;
  }
  if (self.openedUrl.length && [self.openedUrl isEqualToString:wanted]) { return; }
  self.openedUrl = wanted;
  NSURL *parsed = [NSURL URLWithString:wanted];
  if (parsed == nil) {
    NSLog(@"[hey_ios_tv] open_url: unusable url %@", wanted);
    return;
  }
  NSLog(@"[hey_ios_tv] open_url: opening %@", wanted);
  [UIApplication.sharedApplication openURL:parsed options:@{} completionHandler:^(BOOL success) {
    NSLog(@"[hey_ios_tv] open_url: %@ %@", success ? @"opened" : @"REFUSED (no app registers that scheme?)", wanted);
  }];
}

// LIVE SEARCH: the query goes straight out as a scene fetch, and the scene it
// answers with is installed BEHIND the keyboard the viewer is still typing in.
//
// This deliberately does NOT go through the button funnel that the submit-on-
// dismiss version used. That funnel resolves a press by looking its NAME up in
// the CURRENT scene's state, and after the first keystroke the current scene
// is a RESULTS scene, which declares no keyboard_submit at all. Routed that
// way, live search would have worked exactly once and then gone silent -- the
// same class of fault as the original "submitting pod" that found no hint.
- (void)searchLiveWithText:(NSString *)text template:(NSString *)urlTemplate {
  if (urlTemplate.length == 0) { return; }
  NSString *trimmed = [text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
  // SPACES BECOME UNDERSCORES: the {q} rule of keyboard_submit (SCENE_CONTRACT),
  // NOT percent-encoding. The first server built on it swaps underscores back
  // to spaces and decodes nothing, so a percent-escape would arrive as literal
  // text and match nothing.
  // Anything that is not a letter, a digit or a space is dropped rather than
  // encoded, because nothing downstream decodes and a slash would break the
  // path segment outright. Dictation returns apostrophes and commas freely.
  // A SET, NOT A CHARACTER COMPARISON: specs/inline_markdown_spec.sh forbids
  // comparing against the underscore anywhere in this file, so it can never
  // become a markdown marker. Here it is only a word separator.
  NSCharacterSet *separators = [NSCharacterSet characterSetWithCharactersInString:@" _-"];
  NSMutableString *clean = [NSMutableString string];
  for (NSUInteger i = 0; i < trimmed.length; i++) {
    unichar ch = [trimmed characterAtIndex:i];
    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')) {
      [clean appendFormat:@"%C", ch];
    } else if ([separators characterIsMember:ch]) {
      [clean appendString:@"_"];
    }
  }
  // "-" IS THE EMPTY QUERY in a {q} path segment. Backspacing to nothing puts the
  // viewer back on the screen that says what to do, not on a stale grid.
  NSString *q = clean.length ? [clean copy] : @"-";
  NSString *path = [urlTemplate stringByReplacingOccurrencesOfString:@"{q}" withString:q];

  // THE TEMPLATE IS A PATH, NOT A URL. Everything else the renderer fetches is
  // absolute because the server built it; this one is written by the scene, so
  // the origin comes from wherever we are actually polling.
  NSString *reference = [self fetchUrlInScene:[self parsedScene]] ?: self.bootstrapFetchUrl;
  NSURL *base = reference.length ? [NSURL URLWithString:reference] : nil;
  if (base.scheme.length == 0 || base.host.length == 0) {
    NSLog(@"[hey_ios_tv] keyboard: live search has no origin to ask (reference=%@)", reference ?: @"(nil)");
    return;
  }
  NSString *origin = base.port
      ? [NSString stringWithFormat:@"%@://%@:%@", base.scheme, base.host, base.port]
      : [NSString stringWithFormat:@"%@://%@", base.scheme, base.host];
  NSString *urlString = [path hasPrefix:@"http"] ? path : [origin stringByAppendingString:path];

  if (self.lastLiveSearchUrl.length && [self.lastLiveSearchUrl isEqualToString:urlString]) { return; }
  self.lastLiveSearchUrl = urlString;
  NSLog(@"[hey_ios_tv] keyboard: live q=%@ -> %@", q, urlString);
  // THE ANSWER GOES INTO THE RESULTS VIEW, NOT INTO THE SCENE. Installing it as
  // the scene would repaint a screen the keyboard is covering, and would fight
  // the poll timer for the same slot. THE NEWEST QUERY WINS: a round trip for a
  // prefix nobody is waiting for any more must not land after the one being
  // typed now.
  [self.liveSearchTask cancel];
  NSURL *url = [NSURL URLWithString:urlString];
  if (!url) { return; }
  __weak __typeof__(self) weakSelf = self;
  NSURLSessionDataTask *task =
      [NSURLSession.sharedSession dataTaskWithURL:url
                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    (void)response;
    if (error.code == NSURLErrorCancelled) { return; }
    if (!data.length) { return; }
    NSDictionary *doc = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if (![doc isKindOfClass:NSDictionary.class]) { return; }
    dispatch_async(dispatch_get_main_queue(), ^{
      __typeof__(self) me = weakSelf;
      if (me) { [me installLiveResults:doc]; }
    });
  }];
  self.liveSearchTask = task;
  [task resume];
}

// Pull the grid and the count line out of a search scene and hand them to the
// results view. Nothing else in the document is used: there is no title any
// more, the hints belong to a server cursor this screen does not have, and the
// QR belongs to the empty screen the keyboard is covering.
- (void)installLiveResults:(NSDictionary *)doc {
  HeySearchResultsViewController *results = self.searchResults;
  if (results == nil) { return; }
  NSArray *widgets = [doc[@"widgets"] isKindOfClass:NSArray.class] ? doc[@"widgets"] : @[];
  NSDictionary *grid = nil;
  NSString *status = @"";
  NSString *qrPayload = nil, *scanCaption = nil;
  for (id raw in widgets) {
    if (![raw isKindOfClass:NSDictionary.class]) { continue; }
    NSDictionary *w = raw;
    if (grid == nil && [w[@"kind"] isEqual:@"grid"]) { grid = w; }
    if ([w[@"id"] isEqual:@"more"] && [w[@"text"] isKindOfClass:NSString.class]) { status = w[@"text"]; }
    if ([w[@"kind"] isEqual:@"qr"] && [w[@"payload"] isKindOfClass:NSString.class]) { qrPayload = w[@"payload"]; }
    if ([w[@"id"] isEqual:@"scan"] && [w[@"text"] isKindOfClass:NSString.class]) { scanCaption = w[@"text"]; }
  }
  NSArray *items = [grid[@"items"] isKindOfClass:NSArray.class] ? grid[@"items"] : @[];
  // THE EMPTY QUERY IS NOT AN EMPTY RESULT. Presenting the search controller
  // fires updateSearchResultsForSearchController immediately with no text, so
  // this runs once before the viewer has typed anything -- and treating that
  // as "0 results" wiped the phone QR off the screen a frame after it appeared.
  // The scene for the empty query carries the QR instead of a grid; show it.
  if (items.count == 0 && qrPayload.length) {
    NSLog(@"[hey_ios_tv] keyboard: empty query, showing the phone QR");
    [results showQR:[self qrImageForString:qrPayload size:260] caption:scanCaption];
    return;
  }
  NSDictionary *tile = [grid[@"tile"] isKindOfClass:NSDictionary.class] ? grid[@"tile"] : @{};
  NSInteger columns = [grid[@"columns"] isKindOfClass:NSNumber.class] ? [grid[@"columns"] integerValue] : 4;
  CGFloat tw = [tile[@"width"] isKindOfClass:NSNumber.class] ? [tile[@"width"] doubleValue] : 380;
  CGFloat th = [tile[@"height"] isKindOfClass:NSNumber.class] ? [tile[@"height"] doubleValue] : 300;
  NSLog(@"[hey_ios_tv] keyboard: live results %lu", (unsigned long)items.count);
  [results showItems:items columns:columns tileWidth:tw tileHeight:th status:status];
}

// Selecting a tile closes the keyboard and goes where the TILE said, not where
// the scene said. The scene behind is still the empty search screen, so
// dismissing alone would drop the viewer back on a QR code.
- (void)openPickedSearchResult:(NSString *)path {
  NSString *reference = [self fetchUrlInScene:[self parsedScene]] ?: self.bootstrapFetchUrl;
  NSURL *base = reference.length ? [NSURL URLWithString:reference] : nil;
  NSString *urlString = path;
  if (![path hasPrefix:@"http"] && base.scheme.length && base.host.length) {
    NSString *origin = base.port
        ? [NSString stringWithFormat:@"%@://%@:%@", base.scheme, base.host, base.port]
        : [NSString stringWithFormat:@"%@://%@", base.scheme, base.host];
    urlString = [origin stringByAppendingString:path];
  }
  self.keyboardArmed = nil;
  self.lastLiveSearchUrl = nil;
  __weak __typeof__(self) weakSelf = self;
  [self dismissViewControllerAnimated:YES completion:^{
    __typeof__(self) me = weakSelf;
    if (me == nil) { return; }
    if (me.sceneTask) { [me.sceneTask cancel]; me.sceneTask = nil; me.fetchInFlight = NO; }
    [me startFetch:@{@"url": urlString, @"mode": @"scene"}];
  }];
}

- (void)applyKeyboard:(NSDictionary *)scene {
  // FLAT KEYS, not a nested object. The Hey app reads the scene with a scanner
  // that finds "key":"value" anywhere in the document, so it cannot see inside
  // a nested dict -- and a top-level "keyboard" object would collide with the
  // string it needs to look up. Both sides read the same flat field.
  NSString *submit = [scene[@"keyboard_submit"] isKindOfClass:NSString.class] ? scene[@"keyboard_submit"] : nil;
  // ONLY THE EMPTY SEARCH SCREEN DECLARES A KEYBOARD, and typing navigates the
  // scene UNDERNEATH to the results -- which declare none. Clearing the flag
  // here would mean the very next poll re-presented a second keyboard on top
  // of the one the viewer is already typing into. While one is on screen it
  // owns the flag; -keyboardWentAway clears it when it actually closes.
  if (submit.length == 0) {
    if (self.presentedViewController == nil) { self.keyboardArmed = nil; }
    return;
  }
  if (self.keyboardArmed.length && [self.keyboardArmed isEqualToString:submit]) { return; }
  self.keyboardArmed = submit;

  HeyKeyboardDelegate *d = [[HeyKeyboardDelegate alloc] init];
  self.keyboardDelegate = d;
  // A REAL RESULTS CONTROLLER, NOT nil. On iOS nil is legal and means "show
  // results in place"; on tvOS UISearchController REQUIRES one and throws from
  // its initialiser if it does not get one -- which crashed the app the instant
  // the search screen loaded. An empty one is honest here: the results this
  // keyboard produces are a whole new scene from the server, not a list drawn
  // underneath the search bar.
  // THE RESULTS LIVE INSIDE THE SEARCH CONTROLLER NOW, which is the whole
  // point. Presenting over a transparent view and painting results in the scene
  // BEHIND put them somewhere the focus engine cannot reach: a modal owns the
  // remote, so Down drove the keypad and the tiles were unreachable without
  // dismissing first. UISearchContainerViewController lays this controller out
  // directly beneath the search bar and keyboard, so the tiles are both visible
  // and focusable, and nothing overlaps -- which also retires the "letters show
  // through the artwork" fault, since the two are no longer stacked at all.
  HeySearchResultsViewController *results = [[HeySearchResultsViewController alloc] init];
  UIColor *behind = HeyColorFromHex(scene[@"background_color"], nil);
  results.view.backgroundColor = behind ?: UIColor.blackColor;
  __weak __typeof__(self) weakForTiles = self;
  results.makeTile = ^UIView *(NSDictionary *item, CGFloat w, CGFloat h) {
    __typeof__(self) me = weakForTiles;
    return me ? [me tileForItem:item width:w height:h selected:NO] : nil;
  };
  results.onPick = ^(NSString *path) {
    __typeof__(self) me = weakForTiles;
    if (me == nil) { return; }
    NSLog(@"[hey_ios_tv] keyboard: picked %@", path);
    [me openPickedSearchResult:path];
  };
  self.searchResults = results;
  UIViewController *empty = results;
  // Seeded from the scene that armed the keyboard, which is the one screen that
  // still carries the QR and the line explaining it.
  NSString *qrPayload = nil, *scanCaption = nil;
  for (id raw in ([scene[@"widgets"] isKindOfClass:NSArray.class] ? scene[@"widgets"] : @[])) {
    if (![raw isKindOfClass:NSDictionary.class]) { continue; }
    NSDictionary *w = raw;
    if ([w[@"kind"] isEqual:@"qr"] && [w[@"payload"] isKindOfClass:NSString.class]) { qrPayload = w[@"payload"]; }
    if ([w[@"id"] isEqual:@"scan"] && [w[@"text"] isKindOfClass:NSString.class]) { scanCaption = w[@"text"]; }
  }
  if (qrPayload.length) {
    [results showQR:[self qrImageForString:qrPayload size:260] caption:scanCaption];
  }
  UISearchController *sc = [[UISearchController alloc] initWithSearchResultsController:empty];
  sc.searchResultsUpdater = d;
  sc.searchBar.placeholder = [scene[@"keyboard_placeholder"] isKindOfClass:NSString.class]
    ? scene[@"keyboard_placeholder"] : @"Search";

  // NO SUBMIT KEY, AND NOW NO SUBMIT PRESS EITHER. tvOS has no search key on
  // this keyboard because the platform expects the list underneath to follow
  // the text. This used to submit on DISMISS -- speak, then Menu -- which the
  // owner rejected outright: "I shouldn't have to press menu after I finish
  // typing anything ... I shouldn't have to goto a different UI to see the
  // results." Every change now navigates the scene BEHIND the keyboard, so the
  // grid under the bar is the answer, updating as it is spoken or typed.
  __weak __typeof__(self) weakSelf = self;
  d.onLive = ^(NSString *text) {
    __typeof__(self) me = weakSelf;
    if (me == nil) { return; }
    [me searchLiveWithText:text template:submit];
  };
  // The dismissal submits NOTHING. It closes the keyboard over results that
  // are already on screen, and frees the flag so the empty search screen can
  // arm a new one later.
  d.onDismiss = ^(NSString *text) {
    __typeof__(self) me = weakSelf;
    NSLog(@"[hey_ios_tv] keyboard: closed with text=%@ (len %lu)", text ?: @"(nil)", (unsigned long)(text.length));
    if (me == nil) { return; }
    me.keyboardArmed = nil;
    me.lastLiveSearchUrl = nil;
  };

  HeyKeyboardContainer *container =
    [[HeyKeyboardContainer alloc] initWithSearchController:sc];
  // The dismissal IS the submit, however it happens.
  __weak UISearchController *weakSc = sc;
  __weak HeyKeyboardDelegate *weakD = d;
  NSLog(@"[hey_ios_tv] keyboard: presenting for %@", submit);
  container.onGone = ^{
    NSLog(@"[hey_ios_tv] keyboard: container disappeared");
    HeyKeyboardDelegate *dd = weakD;
    UISearchController *ss = weakSc;
    if (dd && dd.onDismiss) { dd.onDismiss(dd.text ?: (ss.searchBar.text ?: @"")); }
  };
  UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:container];
  // OVER, NOT FULL SCREEN. UIModalPresentationFullScreen REMOVES the presenting
  // view from the hierarchy once the animation ends, so the scene behind stops
  // being drawn and the viewer types into a black screen. OverFullScreen keeps
  // it, which is the whole mechanism by which results show under the bar.
  nav.modalPresentationStyle = UIModalPresentationOverFullScreen;
  nav.view.backgroundColor = UIColor.clearColor;
  nav.view.opaque = NO;
  [self presentViewController:nav animated:YES completion:nil];
}

// ---- audio (audio branch, unreleased) -------------------------------------
//
//   {"audio": {"url": "https://ice1.somafm.com/groovesalad-128-mp3", "volume": 0.35, "loop": true}}
//
// A stream that plays UNDER the scene. Video's layer covers the screen, which
// is right for a reel and wrong for a radio behind a page someone is reading,
// so this has no layer at all. The same url re-installed every poll leaves it
// playing; a new url replaces it; {"stop": true} (or an empty url) stops it.
// ABSENT LEAVES IT PLAYING, unlike video: the shell installs a brief document
// of its own on every remote press, carrying no audio field, and the radio
// must not drop out between one page and the next (Maintainer, 2026-09-08
// evening, the first read on the couch). A scene that wants silence says so.
// Volume follows the per-television soundtrack mute. A live stream never
// ends; `loop` matters only for a file that does.
- (void)stopAudio {
  if (self.radioEndObserver) { [NSNotificationCenter.defaultCenter removeObserver:self.radioEndObserver]; self.radioEndObserver = nil; }
  if (self.radioPlayer) { [self.radioPlayer pause]; NSLog(@"[hey_ios_tv] audio: stopped %@", self.currentRadio); }
  self.radioPlayer = nil;
  self.currentRadio = nil;
}

- (void)applyAudio:(NSDictionary *)scene {
  if (![scene[@"audio"] isKindOfClass:NSDictionary.class]) { return; }   // absent: untouched
  NSDictionary *audio = scene[@"audio"];
  NSString *url = [audio[@"url"] isKindOfClass:NSString.class] ? audio[@"url"] : nil;
  BOOL stop = [audio[@"stop"] isKindOfClass:NSNumber.class] && [audio[@"stop"] boolValue];
  if (stop || url.length == 0) {
    [self stopAudio];
    return;
  }
  double requested = [audio[@"volume"] isKindOfClass:NSNumber.class] ? [audio[@"volume"] doubleValue] : 0.3;
  float volume = (float)MAX(0.0, MIN(1.0, requested));
  if (self.currentRadio.length && [self.currentRadio isEqualToString:url]) {
    if (self.radioPlayer) { self.radioPlayer.volume = self.soundtrackMuted ? 0.0f : volume; }
    return;
  }
  [self stopAudio];
  NSURL *parsed = [NSURL URLWithString:url];
  if (parsed == nil) {
    NSLog(@"[hey_ios_tv] audio: unusable url %@", url);
    self.currentRadio = url;   // one log line, not one per poll
    return;
  }
  self.radioPlayer = [AVPlayer playerWithURL:parsed];
  self.radioPlayer.volume = self.soundtrackMuted ? 0.0f : volume;
  self.radioPlayer.actionAtItemEnd = AVPlayerActionAtItemEndNone;
  BOOL loop = [audio[@"loop"] isKindOfClass:NSNumber.class] ? [audio[@"loop"] boolValue] : YES;
  if (loop) {
    __weak __typeof__(self) weakSelf = self;
    self.radioEndObserver = [NSNotificationCenter.defaultCenter
        addObserverForName:AVPlayerItemDidPlayToEndTimeNotification
                    object:self.radioPlayer.currentItem
                     queue:NSOperationQueue.mainQueue
                usingBlock:^(NSNotification *note) {
                  (void)note;
                  [weakSelf.radioPlayer seekToTime:kCMTimeZero];
                  [weakSelf.radioPlayer play];
                }];
  }
  self.currentRadio = url;
  [self.radioPlayer play];
  NSLog(@"[hey_ios_tv] audio=%@ volume=%.2f", url, self.radioPlayer.volume);
}

- (void)applyVideo:(NSDictionary *)scene {
  NSDictionary *video = [scene[@"video"] isKindOfClass:NSDictionary.class] ? scene[@"video"] : nil;
  NSString *url = [video[@"url"] isKindOfClass:NSString.class] ? video[@"url"] : nil;
  NSString *fileName = [video[@"file"] isKindOfClass:NSString.class] ? video[@"file"] : nil;

  if (fileName.length == 0 && url.length == 0) {
    [self stopVideoKeepingSuppression:NO];
    return;
  }
  // ONE IDENTITY FOR "WHICH FILM", bundled or remote, exactly as the sound path
  // does it. Everything below compares this and never the url: a bundled reel
  // has no url, so a url comparison would never match itself and every poll
  // would restart the film.
  NSString *wanted = fileName.length ? [@"file:" stringByAppendingString:fileName] : url;

  // Dismissed by the viewer, or already played to the end, and the server has
  // not moved on yet.
  if (self.suppressedVideo.length && [self.suppressedVideo isEqualToString:wanted]) { return; }
  if (self.currentVideo.length && [self.currentVideo isEqualToString:wanted]) { return; }

  [self stopVideoKeepingSuppression:NO];

  // RESOLVE BEFORE ANYTHING IS BUILT, so a film that cannot be played leaves no
  // player and no layer over the scene underneath.
  NSURL *parsed = nil;
  if (fileName.length) {
    NSString *path = [self bundlePathForResourceName:fileName subsystem:@"video"];
    if (path.length) { parsed = [NSURL fileURLWithPath:path]; }
  } else {
    parsed = [NSURL URLWithString:url];
    if (parsed == nil) { NSLog(@"[hey_ios_tv] video: unusable url %@", url); }
  }
  if (parsed == nil) {
    // Nothing about a missing resource or a malformed url gets better on the
    // next poll, and the scene will keep asking every two seconds. Suppress it
    // so the failure is one log line, not thirty a minute.
    self.suppressedVideo = wanted;
    return;
  }

  self.videoPlayer = [AVPlayer playerWithURL:parsed];
  // LOW BY DEFAULT (maintainer, 2026-08-08). This starts by itself in a room
  // nobody asked, so it must not be the loudest thing in there.
  double volume = [video[@"volume"] isKindOfClass:NSNumber.class] ? [video[@"volume"] doubleValue] : 0.2;
  // REMEMBERED, then applied. The mute writes the player's volume and nothing
  // else, so this is what unmuting comes back to.
  self.videoRequestedVolume = MAX(0.0, MIN(1.0, volume));
  [self applyVideoVolume];
  self.videoPlayer.actionAtItemEnd = AVPlayerActionAtItemEndNone;

  // A WALKTHROUGH MUST NOT LOOK LIKE THE APP.
  //
  // This filled the whole screen, and the film is a recording OF this app, made
  // on this app -- so the two were pixel-identical and there was nothing
  // anywhere to tell you which one you were looking at. Reported as: "it's very
  // difficult for a new user (of a certain age) to realize that they are
  // watching a video ... of what the app looks like."
  //
  // Insetting it is what makes that answerable at all. The layer used to be the
  // full bounds and sits ON TOP of every widget, so anything the server drew
  // around the film -- a title, a badge, a footer -- was underneath it and
  // invisible. With a margin, the scene's own widgets show in the border, which
  // means the chrome is SERVER-SIDE from here on: what it says can change
  // without rebuilding this app or re-encoding a single video.
  //
  // The inset is deliberately generous. A thin border reads as a rendering
  // artefact; this reads as a picture sitting on a page.
  CGRect b = self.view.bounds;
  CGFloat insetX = b.size.width * 0.115;
  // 0.22, NOT 0.16. At 0.16 the frame cut the title in half -- there is a badge
  // line AND a heading above the film, and both have to clear it. Measured on
  // the simulator; if another line is ever added up there, this is the number.
  CGFloat top = b.size.height * 0.22;     // room for the badge and the heading
  CGFloat bottom = b.size.height * 0.13;  // and a line of help below
  CGRect stage = CGRectMake(b.origin.x + insetX, b.origin.y + top,
                            b.size.width - insetX * 2,
                            b.size.height - top - bottom);

  self.videoLayer = [AVPlayerLayer playerLayerWithPlayer:self.videoPlayer];
  self.videoLayer.frame = stage;
  self.videoLayer.videoGravity = AVLayerVideoGravityResizeAspect;
  // A visible edge, so the film reads as a framed thing rather than as the
  // screen having changed underneath you.
  self.videoLayer.cornerRadius = 18;
  self.videoLayer.masksToBounds = YES;
  self.videoLayer.borderWidth = 3;
  self.videoLayer.borderColor = [UIColor colorWithWhite:1 alpha:0.35].CGColor;
  [self.view.layer addSublayer:self.videoLayer];
  // A new sublayer goes on TOP of everything, including an open settings
  // overlay. Put the overlay back in front so a film that starts while the
  // menu is up cannot swallow it.
  if (self.settingsView) { [self.view bringSubviewToFront:self.settingsView]; }

  BOOL loop = [video[@"loop"] isKindOfClass:NSNumber.class] ? [video[@"loop"] boolValue] : YES;
  // BOTH cases need the end-of-item notification. A looping reel re-seeks; a
  // one-shot reel must TEAR DOWN -- with actionAtItemEnd None and no observer
  // the player simply stops, and the layer stays up over the last frame,
  // covering the waiting scene until someone restarts the app.
  __weak typeof(self) weakSelf = self;
  NSString *finishedKey = wanted;
  self.videoEndObserver =
      [[NSNotificationCenter defaultCenter]
          addObserverForName:AVPlayerItemDidPlayToEndTimeNotification
                      object:self.videoPlayer.currentItem
                       queue:[NSOperationQueue mainQueue]
                  usingBlock:^(NSNotification *note) {
                    if (loop) {
                      [weakSelf.videoPlayer seekToTime:kCMTimeZero];
                      [weakSelf.videoPlayer play];
                      return;
                    }
                    // Tearing down removes THIS observer, which releases the
                    // block that is running. Hop to the next main-queue turn so
                    // the block has returned before that happens.
                    dispatch_async(dispatch_get_main_queue(), ^{
                      __strong __typeof(weakSelf) strongSelf = weakSelf;
                      if (strongSelf == nil) { return; }
                      // The film is over. It must not come back: the server
                      // keeps emitting the same key for as long as the display
                      // is idle, so without this the next poll replays it.
                      strongSelf.suppressedVideo = finishedKey;
                      [strongSelf stopVideoKeepingSuppression:YES];
                      NSLog(@"[hey_ios_tv] video finished: %@", finishedKey);
                    });
                  }];
  self.currentVideo = wanted;
  [self.videoPlayer play];
  // A film is now playing, so the screensaver must not come up over it however
  // the scene declared keep_awake. Recomputed, never poked: see applyIdleTimer.
  [self applyIdleTimer];
  NSLog(@"[hey_ios_tv] video=%@ loop=%d volume=%.2f", wanted, loop, self.videoPlayer.volume);
}

// THE ONE PLACE the player's volume is written, from the requested volume and
// the soundtrack mute -- the same single-writer shape the idle timer uses, and
// for the same reason: the mute must not be able to overwrite what the scene
// asked for, or unmuting has nothing to restore.
// It is deliberately SILENT: it runs on every film install, and a log line
// there would be a new line in the ordinary unmuted case. The mute itself is
// logged once, where it is chosen.
- (void)applyVideoVolume {
  if (self.videoPlayer == nil) { return; }
  self.videoPlayer.volume = self.soundtrackMuted ? 0.0f : (float)self.videoRequestedVolume;
}

- (void)stopVideoKeepingSuppression:(BOOL)keep {
  if (self.videoPlayer == nil && self.videoLayer == nil) {
    if (!keep) { self.suppressedVideo = nil; }
    return;
  }
  // By TOKEN. removeObserver:self would remove nothing here -- the block form
  // of addObserverForName: registers an object of its own, not self.
  if (self.videoEndObserver) {
    [[NSNotificationCenter defaultCenter] removeObserver:self.videoEndObserver];
    self.videoEndObserver = nil;
  }
  [self.videoPlayer pause];
  [self.videoLayer removeFromSuperlayer];
  self.videoPlayer = nil;
  self.videoLayer = nil;
  self.currentVideo = nil;
  if (!keep) { self.suppressedVideo = nil; }
  // Nothing is playing now -- dismissed, finished, or the scene stopped asking
  // for it -- so the scene's own keep_awake takes effect again. This is the
  // whole reason the override is computed rather than latched: a display parked
  // on an unclaimed code goes back to being allowed to sleep.
  [self applyIdleTimer];
}

// ANY press stops the reel and is SWALLOWED -- it does not also fire a scene
// button. Someone walking up to a playing screen is dismissing it, not choosing
// something, and the alternative is that their first press silently does
// whatever the underlying screen had focused.
- (BOOL)dismissVideoIfPlaying {
  if (self.videoPlayer == nil) { return NO; }
  self.suppressedVideo = self.currentVideo;
  [self stopVideoKeepingSuppression:YES];
  NSLog(@"[hey_ios_tv] video dismissed by remote");
  return YES;
}

// ---- the sound settings menu (0.4.13) ------------------------------------
//
// UP opens it, and ONLY on a scene that asks for it with top-level
// "allow_settings": true -- checked and never assumed, the same shape and the
// same reason as handles_back and allow_demo. Every document that wants the
// binding declares it, including the app's own boot splash; nothing here
// infers the binding from what a document happens to look like. A renderer
// that recognised a screen by its bytes would be reasoning about a document
// this package does not own, and the app would break it by editing a screen it
// had every right to edit.
//
// An app that never emits the marker simply has no settings entry, exactly as
// one that never emits allow_demo has no demo. That is the contract, not a gap.
//
// PRE-QUIZ SCREENS ONLY -- see docs/SCENE_CONTRACT.md. On a live question
// screen every button is inert on purpose, so a classroom display cannot be
// clobbered by a stray press, and a scene that opened a menu over the question
// would be throwing that away.
- (BOOL)settingsEntryAllowed {
  return self.sceneAllowsSettings;
}

// Cached at install like handles_back, because scene-mode polls replace the
// document every couple of seconds and a per-press parse would re-read it.
- (void)syncSettingsEntryWithScene:(NSDictionary *)scene {
  BOOL wanted = NO;
  id declared = scene[@"allow_settings"];
  if ([declared isKindOfClass:NSNumber.class]) { wanted = [declared boolValue]; }
  if (self.sceneAllowsSettings == wanted) { return; }
  self.sceneAllowsSettings = wanted;
  NSLog(@"[hey_ios_tv] allow_settings=%@ (Up %@)",
        wanted ? @"true" : @"false",
        wanted ? @"opens the sound menu" : @"goes to the scene");
}

// The overlay is a SIBLING of contentView, not a child: renderScene empties
// contentView every poll, and the menu has to survive that. It adds nothing to
// the scene and removes nothing from it, so closing it leaves the screen
// exactly as it was.
- (void)openSettings {
  if (self.settingsView) { return; }

  UIView *scrim = [[UIView alloc] init];
  scrim.translatesAutoresizingMaskIntoConstraints = NO;
  // Dark enough to read against a bright quiz screen or a playing film, sheer
  // enough that the room can see the menu is ON TOP of something, not a
  // navigation away from it.
  scrim.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.82];
  [self.view addSubview:scrim];
  [NSLayoutConstraint activateConstraints:@[
    [scrim.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
    [scrim.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    [scrim.topAnchor constraintEqualToAnchor:self.view.topAnchor],
    [scrim.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
  ]];

  UIView *card = [[UIView alloc] init];
  card.translatesAutoresizingMaskIntoConstraints = NO;
  // One shade up from the renderer's own background (0x101820), so the card
  // reads as a panel rather than a second application.
  card.backgroundColor = [UIColor colorWithRed:0x18 / 255.0 green:0x24 / 255.0 blue:0x30 / 255.0 alpha:1.0];
  card.layer.cornerRadius = 28;
  card.layer.borderWidth = 1;
  card.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.12].CGColor;
  [scrim addSubview:card];

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  // "Settings", not "Sound": the screen row is not about noise.
  title.text = @"Settings";
  // The file's own type scale: headline.
  title.font = [UIFont systemFontOfSize:48 weight:UIFontWeightSemibold];
  title.textColor = UIColor.whiteColor;

  NSMutableArray<UIView *> *rows = [NSMutableArray array];
  NSMutableArray<UILabel *> *states = [NSMutableArray array];
  for (NSString *name in @[ @"Soundtrack", @"Sound effects", @"Screen" ]) {
    UIView *row = [[UIView alloc] init];
    row.translatesAutoresizingMaskIntoConstraints = NO;
    row.layer.cornerRadius = 16;
    [row.heightAnchor constraintEqualToConstant:96].active = YES;

    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = name;
    label.font = [UIFont systemFontOfSize:36 weight:UIFontWeightRegular];   // body
    [row addSubview:label];

    UILabel *state = [[UILabel alloc] init];
    state.translatesAutoresizingMaskIntoConstraints = NO;
    state.font = [UIFont systemFontOfSize:36 weight:UIFontWeightSemibold];
    state.textAlignment = NSTextAlignmentRight;
    [row addSubview:state];

    [NSLayoutConstraint activateConstraints:@[
      [label.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:28],
      [label.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
      [state.trailingAnchor constraintEqualToAnchor:row.trailingAnchor constant:-28],
      [state.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
    ]];
    [rows addObject:row];
    [states addObject:state];
  }

  UILabel *footer = [[UILabel alloc] init];
  footer.translatesAutoresizingMaskIntoConstraints = NO;
  // "change", not "toggle": one of the three rows cycles rather than flips.
  footer.text = @"Up / Down to choose     Select to change     Menu to close";
  footer.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular];    // caption
  footer.textColor = [UIColor colorWithWhite:1.0 alpha:0.45];

  UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:
                            [@[ title ] arrayByAddingObjectsFromArray:
                                 [rows arrayByAddingObject:footer]]];
  stack.axis = UILayoutConstraintAxisVertical;
  stack.alignment = UIStackViewAlignmentFill;
  stack.spacing = 24;
  stack.translatesAutoresizingMaskIntoConstraints = NO;
  [card addSubview:stack];
  // A little more air under the title and above the footer than between the
  // two rows, so the rows read as one group.
  [stack setCustomSpacing:36 afterView:title];
  [stack setCustomSpacing:36 afterView:rows.lastObject];

  [NSLayoutConstraint activateConstraints:@[
    [card.centerXAnchor constraintEqualToAnchor:scrim.centerXAnchor],
    [card.centerYAnchor constraintEqualToAnchor:scrim.centerYAnchor],
    [card.widthAnchor constraintEqualToConstant:900],
    [stack.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:56],
    [stack.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-56],
    [stack.topAnchor constraintEqualToAnchor:card.topAnchor constant:48],
    [stack.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-48],
  ]];

  self.settingsView = scrim;
  self.settingsRowViews = rows;
  self.settingsStateLabels = states;
  self.settingsIndex = 0;
  [self refreshSettingsRows];
  NSLog(@"[hey_ios_tv] settings opened");
}

- (void)closeSettings {
  if (self.settingsView == nil) { return; }
  [self.settingsView removeFromSuperview];
  self.settingsView = nil;
  self.settingsRowViews = nil;
  self.settingsStateLabels = nil;
  NSLog(@"[hey_ios_tv] settings closed (soundtrack %@, effects %@, screen %@)",
        self.soundtrackMuted ? @"muted" : @"on", self.effectsMuted ? @"muted" : @"on",
        HeyScreenModeName(self.screenMode));
}

// There is no UIKit focus here -- the whole renderer is driven by raw presses,
// and a focus engine would fight the scene underneath. So the selected row is
// drawn, not focused: a lit panel and full-brightness text, dim otherwise,
// which is what reads from the back of a classroom.
- (void)refreshSettingsRows {
  BOOL muted[2] = { self.soundtrackMuted, self.effectsMuted };
  for (NSUInteger i = 0; i < self.settingsRowViews.count; i++) {
    BOOL selected = ((NSInteger)i == self.settingsIndex);
    UIView *row = self.settingsRowViews[i];
    row.backgroundColor = selected ? [UIColor colorWithWhite:1.0 alpha:0.16] : UIColor.clearColor;
    for (UIView *sub in row.subviews) {
      if ([sub isKindOfClass:UILabel.class]) {
        ((UILabel *)sub).textColor =
            selected ? UIColor.whiteColor : [UIColor colorWithWhite:1.0 alpha:0.6];
      }
    }
    UILabel *state = self.settingsStateLabels[i];
    // The screen row is not a mute, so it reads its own three-state vocabulary
    // rather than On/Off -- "Auto" has to be nameable, or nobody can tell the
    // difference between "the server decided" and "I chose light".
    BOOL isScreen = (i == 2);
    BOOL quiet = isScreen ? (self.screenMode == 0) : muted[i];
    state.text = isScreen ? [HeyScreenModeName(self.screenMode) capitalizedString]
                          : (muted[i] ? @"Off" : @"On");
    // The state stays legible even when its row is not the selected one: it is
    // the fact somebody walked over to check.
    if (!selected) {
      state.textColor = quiet ? [UIColor colorWithWhite:1.0 alpha:0.45]
                              : [UIColor colorWithWhite:1.0 alpha:0.8];
    }
  }
}

- (void)settingsMoveBy:(NSInteger)delta {
  NSInteger count = (NSInteger)self.settingsRowViews.count;
  if (count == 0) { return; }
  NSInteger next = self.settingsIndex + delta;
  if (next < 0) { next = 0; }                 // stops at the ends rather than
  if (next > count - 1) { next = count - 1; } // wrapping: two rows, no surprise
  if (next == self.settingsIndex) { return; }
  self.settingsIndex = next;
  [self refreshSettingsRows];
}

- (void)settingsToggleSelected {
  if (self.settingsIndex == 0) { self.soundtrackMuted = !self.soundtrackMuted; }
  else if (self.settingsIndex == 1) { self.effectsMuted = !self.effectsMuted; }
  else {
    // Three states, so Select CYCLES rather than toggles: auto -> dark ->
    // light -> auto. One button, and every state is reachable without a second
    // one to explain.
    self.screenMode = (self.screenMode + 1) % 3;
    NSLog(@"[hey_ios_tv] settings: screen %@", HeyScreenModeName(self.screenMode));
    [self applySoundSettings];
    [self refreshSettingsRows];
    // ...AND ASK THE SERVER NOW, rather than waiting out the poll interval.
    // The SERVER paints the scene, so nothing local can apply this; but the
    // viewer is standing in front of the television having just pressed the
    // button, and a screen that changes up to a full interval later reads as a
    // press that did not take. This re-polls with the new header immediately,
    // so the repaint costs one round trip instead of up to `fetch.ms`.
    //
    // It is the FETCH half of onLiveDataTimer and deliberately not the whole
    // thing: that method also emits a `tick` event, and a settings press must
    // not advance anything the scene is counting.
    [self repollForScreenChange];
    return;
  }
  NSLog(@"[hey_ios_tv] sound settings: %@ %@",
        self.settingsIndex == 0 ? @"soundtrack" : @"sound effects",
        (self.settingsIndex == 0 ? self.soundtrackMuted : self.effectsMuted) ? @"muted" : @"on");
  [self applySoundSettings];
  [self refreshSettingsRows];
}

// EVERY press belongs to the overlay while it is open -- the same discipline
// the reel's dismissing press follows. A press that fell through would reach a
// scene the viewer cannot even see.
- (void)settingsHandlePressType:(UIPressType)type {
  switch (type) {
    case UIPressTypeUpArrow: [self settingsMoveBy:-1]; break;
    case UIPressTypeDownArrow: [self settingsMoveBy:1]; break;
    case UIPressTypeSelect: [self settingsToggleSelected]; break;
    case UIPressTypeMenu:
    case UIPressTypePlayPause: [self closeSettings]; break;
    default: break;   // swallowed, and deliberately does nothing
  }
}

- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  // THE MENU IS CHECKED BEFORE THE REEL, and the order is load-bearing. A film
  // can start while the menu is open (the poll that installs it does not know
  // the menu is up), and if the dismissing press ran first, every press meant
  // for the menu the viewer is looking at would go to dismissing a film behind
  // it instead. With no menu open the reel still takes the first press, so the
  // documented behaviour is unchanged: Up during a film dismisses it, and the
  // Up after that opens the menu.
  //
  // The menu owns the remote while it is up, INCLUDING Menu itself: the press
  // that closes it is recorded as ours (menuPressOwned) so the matching
  // press-ended is swallowed too and tvOS does not also suspend the app.
  if (self.settingsView) {
    for (UIPress *press in presses) {
      if (press.type == UIPressTypeMenu) { self.menuPressOwned = YES; }
      [self settingsHandlePressType:press.type];
    }
    return;
  }
  // A PRESENTED MODAL OWNS ITS OWN MENU PRESS. Without this the keyboard
  // submitted correctly and the television still went somewhere else: Menu
  // fired the scene's `back` on press-down, the app navigated away, and THEN
  // the modal finished dismissing and emitted the search -- resolved against
  // whatever scene had just replaced the search screen, which carried no
  // keyboard hint. The log said "submitting pod" and the shelf went to the
  // rail. Let the system dismiss what is on top; the dismissal is the submit.
  // WE DISMISS IT OURSELVES, and own the press. Two earlier versions each
  // traded one failure for another: swallowing Menu outright left a keyboard
  // that would not close, and forwarding it to the system closed the keyboard
  // and then handed the SAME press to the app at its root, where tvOS reads
  // Menu as "quit" -- so submitting a search exited to the home screen.
  //
  // Dismissing here fires the container's viewDidDisappear, which IS the
  // submit, and marking the press owned stops pressesEnded handing it on. The
  // modal's Menu belongs to the modal, start to finish.
  if (self.presentedViewController != nil) {
    for (UIPress *press in presses) {
      if (press.type == UIPressTypeMenu) {
        self.menuPressOwned = YES;
        [self dismissViewControllerAnimated:YES completion:nil];
        return;
      }
    }
    return;
  }
  if ([self dismissVideoIfPlaying]) { return; }
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      self.menuPressOwned = self.handlesBack;   // decide once, at press-down
      if (self.menuPressOwned) {
        [self fireRemoteButton:@"back"];
        [unhandled removeObject:press];
      }
      continue;
    }
    // UP OPENS THE SOUND MENU where the screen allows it, and is not also
    // delivered to the scene -- one press, one meaning.
    if (press.type == UIPressTypeUpArrow && [self settingsEntryAllowed]) {
      [self openSettings];
      [unhandled removeObject:press];
      continue;
    }
    NSString *button = HeyButtonForPressType(press.type);
    if (button) {
      [self fireRemoteButton:button];
      [unhandled removeObject:press];
    }
  }
  if (unhandled.count) { [super pressesBegan:unhandled withEvent:event]; }
}

// We already acted on press-down; on end/cancel just swallow the presses we
// own (so they do not fire twice) and forward the rest up the chain. Menu is
// swallowed here iff WE consumed its press-down (menuPressOwned), never by
// re-reading handlesBack -- the scene may have changed mid-press.
- (void)pressesEnded:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      if (self.menuPressOwned) { [unhandled removeObject:press]; }
      self.menuPressOwned = NO;
      continue;
    }
    if (HeyButtonForPressType(press.type)) { [unhandled removeObject:press]; }
  }
  if (unhandled.count) { [super pressesEnded:unhandled withEvent:event]; }
}

- (void)pressesCancelled:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
  NSMutableSet<UIPress *> *unhandled = [presses mutableCopy];
  for (UIPress *press in presses) {
    if (press.type == UIPressTypeMenu) {
      if (self.menuPressOwned) { [unhandled removeObject:press]; }
      self.menuPressOwned = NO;
      continue;
    }
    if (HeyButtonForPressType(press.type)) { [unhandled removeObject:press]; }
  }
  if (unhandled.count) { [super pressesCancelled:unhandled withEvent:event]; }
}

// Clickpad touch swipes -> the same directional actions. These fire only for
// touch gestures, which never arrive as presses, so there is no double-fire.
- (void)remoteSwipe:(UISwipeGestureRecognizer *)recognizer {
  // The clickpad reaches the menu on the same terms the buttons do: while it is
  // open every swipe belongs to it, and a swipe up opens it where a press up
  // would. Otherwise a Siri Remote user could scroll the scene underneath a
  // menu they are looking at.
  if (self.settingsView) {
    if (recognizer.direction == UISwipeGestureRecognizerDirectionUp) { [self settingsMoveBy:-1]; }
    else if (recognizer.direction == UISwipeGestureRecognizerDirectionDown) { [self settingsMoveBy:1]; }
    return;
  }
  if (recognizer.direction == UISwipeGestureRecognizerDirectionUp && [self settingsEntryAllowed]) {
    [self openSettings];
    return;
  }
  NSString *button = @"up";
  switch (recognizer.direction) {
    case UISwipeGestureRecognizerDirectionUp: button = @"up"; break;
    case UISwipeGestureRecognizerDirectionDown: button = @"down"; break;
    case UISwipeGestureRecognizerDirectionLeft: button = @"left"; break;
    case UISwipeGestureRecognizerDirectionRight: button = @"right"; break;
    default: return;
  }
  [self fireRemoteButton:button];
}

// ---- rendering (diff-lite: rebuild the widget tree each step) ------------
// The tvOS screensaver is a BUG during a live quiz: the whole room is looking
// at the screen, nobody is touching a remote, and tvOS has no idea the display
// is doing anything. A scene asks to stay awake with "keep_awake": true.
//
// Scene-DECLARED rather than always-on, deliberately. A display parked on an
// unclaimed code could sit for hours, and holding the screen awake forever
// wastes power and risks burn-in for no one's benefit. The server knows which
// it is -- a claimed room keeps the TV awake, an unclaimed one lets it sleep.
//
// Absent means false, so every pack built before this behaves exactly as it
// did. idleTimerDisabled must be touched on the main thread; renderScene is
// already there.
//
// A PLAYING FILM OVERRIDES THE DECLARATION. The scene that carries the attract
// reel is the unclaimed waiting screen, which declares keep_awake:false on
// purpose -- it may sit for hours. But tvOS "Start After" can be set to two
// minutes, and the reel runs longer than that, so with the idle timer live the
// screensaver comes up over a playing film. The RENDERER is the only side that
// knows a film is actually playing (the server goes on emitting the identical
// idle scene either way, so asking it for keep_awake:true would hold the TV
// awake forever and throw away the burn-in reasoning that put false there).
// SIGNING OUT, THE HALF ONLY THIS SIDE CAN DO.
//
// The server revokes the pairing, which stops this television reading the
// library. It cannot make the television stop BEING that television -- and an
// identity that is merely revoked can be paired again with one press on a
// phone, because Auth.pair clears revoked_at on conflict. That is "hide the
// library", not "sign out".
//
// So the scene says forget_device, and this drops the minted id. The next
// launch mints a new one and asks for a new code as a brand new television.
//
// A PACK BUILT FOR ONE ROOM bakes its id and carries no placeholder, so there
// is nothing here to forget: the server's revocation still takes effect and
// the screen still goes back to a pairing code, it is simply the same id
// asking. That is correct for a television nobody else has a copy of.
- (void)syncDeviceIdentityWithScene:(NSDictionary *)scene {
  id declared = scene[@"forget_device"];
  if (![declared isKindOfClass:NSNumber.class] || ![declared boolValue]) { return; }
  if (self.forgettingDevice) { return; }
  self.forgettingDevice = YES;
  [self forgetDeviceIdentity];
  // REBUILT FROM THE PACK, not patched in place. Every url on screen still
  // carries the old id -- the poll, the bootstrap, the hints -- and rewriting
  // them one by one is a list that grows every time a scene gains a field.
  // Asking the Hey side for its boot document again and substituting the NEW
  // identity gives exactly the state a first launch has, which is what a
  // television that has just signed out is.
  //
  // Async, because this runs inside renderScene and replacing the scene it is
  // rendering underneath itself is how a half-drawn screen happens.
  __weak __typeof__(self) weakSelf = self;
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    __typeof__(self) me = weakSelf;
    if (me == nil) { return; }
    NSString *fresh = HeyStringFromReturn(hey_fn_tv_scene_init());
    if ([fresh containsString:kHeyDevicePlaceholder]) {
      fresh = [fresh stringByReplacingOccurrencesOfString:kHeyDevicePlaceholder
                                               withString:[me deviceIdentity]];
    }
    me.sceneJson = fresh;
    me.bootstrapFetchUrl = [me fetchUrlInScene:[me parsedScene]];
    me.forgettingDevice = NO;
    [me renderScene];
  });
}

- (void)syncIdleTimerWithScene:(NSDictionary *)scene {
  id declared = scene[@"keep_awake"];
  self.sceneKeepAwake = [declared isKindOfClass:NSNumber.class] ? [declared boolValue] : NO;
  [self applyIdleTimer];
}

// THE ONE PLACE idleTimerDisabled is written, from BOTH of its inputs. Nothing
// pokes it behind this method's back, so the order of syncIdleTimerWithScene:
// and applyVideo: within renderScene cannot matter: whichever runs second
// recomputes from the same two facts and lands on the same answer. Were the
// video path to set the flag directly instead, the very next poll -- two
// seconds later, mid-film -- would recompute from the scene alone and hand the
// screensaver back its opening.
- (void)applyIdleTimer {
  BOOL playing = (self.videoPlayer != nil);
  BOOL wanted = self.sceneKeepAwake || playing;

  UIApplication *app = UIApplication.sharedApplication;
  if (app.idleTimerDisabled == wanted) { return; }
  app.idleTimerDisabled = wanted;
  // Report what was APPLIED and why, not what the scene asked for: during a
  // film those two disagree, and a log that only ever echoed the declaration
  // would be the first thing to mislead anyone debugging a screensaver.
  NSLog(@"[hey_ios_tv] keep_awake=%@ (scene declared %@, video %@; tvOS screensaver %@)",
        wanted ? @"true" : @"false",
        self.sceneKeepAwake ? @"true" : @"false",
        playing ? @"playing" : @"stopped",
        wanted ? @"suppressed" : @"allowed");
}

- (void)renderScene {
  NSDictionary *scene = [self parsedScene];
  // Re-arm the clock/socket whenever the scene's tick/fetch declaration
  // changes. renderScene only runs when the scene actually changed, so an
  // idle app never reschedules.
  [self syncLiveDataWithScene:scene];
  [self syncIdleTimerWithScene:scene];
  [self syncDeviceIdentityWithScene:scene];
  [self syncBackHandlingWithScene:scene];
  [self syncSettingsEntryWithScene:scene];
  [self syncSoundWithScene:scene];
  // The attract reel sits ALONGSIDE the sound sync, on the same per-poll,
  // idempotent-by-url contract. It is applied after the scene body is built so
  // its layer lands on top of whatever the screen was showing.
  [self applyVideo:scene];
  // The radio under a page, on the same idempotent-by-url contract, no layer.
  [self applyAudio:scene];
  // Handing the viewer to another app comes LAST, once this scene is built:
  // the scene underneath is what they come back to.
  [self applyOpenUrl:scene];
  // The keyboard sits on the same contract: presented once for the scene that
  // asks, not on every poll of it.
  [self applyKeyboard:scene];

  // background: top-level background_color, felt gradient, or flat color.
  //
  // "background_color" (0.4.7) is a top-level hex string: one flat fill for
  // the whole scene background, added so a SERVER-rendered scene can dim the
  // screen (maintainer report 2026-07-31: the white quiz screen is too bright
  // at night) with a single field. When present and parseable it wins over
  // the background object's felt/color; when ABSENT -- or not a string, or
  // not a parseable hex value (HeyColorFromHex returns the nil fallback) --
  // the branches below run exactly as they did in 0.4.6, so every existing
  // scene renders pixel-identically. Same additive rule as handles_back and
  // keep_awake: absent means today's behavior; same guard pattern as
  // caption_color: isKindOfClass check + HeyColorFromHex with a fallback.
  [self.feltLayer removeFromSuperlayer];
  self.feltLayer = nil;
  UIColor *flat = [scene[@"background_color"] isKindOfClass:NSString.class]
                      ? HeyColorFromHex(scene[@"background_color"], nil) : nil;
  NSDictionary *bg = [scene[@"background"] isKindOfClass:NSDictionary.class] ? scene[@"background"] : @{};
  if (flat) {
    self.view.backgroundColor = flat;
  } else if ([bg[@"felt"] isKindOfClass:NSString.class]) {
    UIColor *base = HeyColorFromHex(bg[@"felt"], [UIColor colorWithRed:0x1E / 255.0 green:0x4D / 255.0 blue:0x3B / 255.0 alpha:1.0]);
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = self.view.bounds;
    g.colors = @[ (id)HeyScaleColor(base, 1.35).CGColor, (id)HeyScaleColor(base, 0.6).CGColor ];
    g.startPoint = CGPointMake(0.5, 0.0);
    g.endPoint = CGPointMake(0.5, 1.0);
    [self.view.layer insertSublayer:g atIndex:0];
    self.feltLayer = g;
    self.view.backgroundColor = base;
  } else if ([bg[@"color"] isKindOfClass:NSString.class]) {
    self.view.backgroundColor = HeyColorFromHex(bg[@"color"], UIColor.blackColor);
  }

  for (UIView *sub in self.contentView.subviews.copy) { [sub removeFromSuperview]; }

  // three slot columns: top / center / bottom, each a vertical stack
  // `compact: true` on the document (tv-grid branch, unreleased): a dense scene
  // such as a two-row artwork shelf with a caption line and a hint line asks for
  // tighter column spacing and margins; every scene without the flag lays out
  // pixel-identically to before.
  BOOL compact = [scene[@"compact"] isKindOfClass:NSNumber.class] && [scene[@"compact"] boolValue];
  CGFloat colSpacing = compact ? 14 : 28;
  CGFloat edge = compact ? 18 : 40;
  CGFloat spacerMin = compact ? 6 : 16;
  UIStackView *(^makeColumn)(void) = ^UIStackView *(void) {
    UIStackView *s = [[UIStackView alloc] init];
    s.axis = UILayoutConstraintAxisVertical;
    s.alignment = UIStackViewAlignmentCenter;
    s.spacing = colSpacing;
    s.translatesAutoresizingMaskIntoConstraints = NO;
    return s;
  };
  UIStackView *top = makeColumn(), *center = makeColumn(), *bottom = makeColumn();
  // A LEFT RAIL (slot: "rail"), for the tools that are not content: search,
  // settings, the account. Prime and Netflix both put this axis on the left
  // edge precisely so it does not compete with the content sections along the
  // top. Left-aligned rather than centred, because a column of labels that
  // centres itself reads as a list of unrelated words.
  UIStackView *rail = [[UIStackView alloc] init];
  rail.axis = UILayoutConstraintAxisVertical;
  rail.alignment = UIStackViewAlignmentLeading;
  rail.spacing = colSpacing;
  rail.translatesAutoresizingMaskIntoConstraints = NO;

  NSArray *widgets = [scene[@"widgets"] isKindOfClass:NSArray.class] ? scene[@"widgets"] : @[];
  for (id item in widgets) {
    if (![item isKindOfClass:NSDictionary.class]) { continue; }
    NSDictionary *w = item;
    UIView *view = [self viewForWidget:w];
    if (!view) { continue; }
    NSString *slot = [w[@"slot"] isKindOfClass:NSString.class] ? w[@"slot"] : @"center";
    if ([slot isEqualToString:@"top"]) { [top addArrangedSubview:view]; }
    else if ([slot isEqualToString:@"bottom"]) { [bottom addArrangedSubview:view]; }
    else if ([slot isEqualToString:@"rail"]) { [rail addArrangedSubview:view]; }
    else { [center addArrangedSubview:view]; }
  }

  // Assemble the three slot columns into ONE top-to-bottom flow that can never
  // overlap: a vertical stack view never lays its arranged subviews on top of
  // one another. Two flexible spacers keep `top` pinned to the top, `bottom`
  // pinned to the bottom, and `center` in the middle when there is slack; when
  // a scene is tall (two dealt hands, or a wide card fan above a status line
  // and a QR) the spacers simply shrink, so text never overprints text.
  UIView *(^makeSpacer)(void) = ^UIView *(void) {
    UIView *v = [[UIView alloc] init];
    v.translatesAutoresizingMaskIntoConstraints = NO;
    [v setContentHuggingPriority:1 forAxis:UILayoutConstraintAxisVertical];  // stretch me first
    [v.widthAnchor constraintEqualToConstant:0].active = YES;
    return v;
  };
  UIView *spacerTop = makeSpacer(), *spacerBottom = makeSpacer();

  UIStackView *flow = [[UIStackView alloc] init];
  flow.axis = UILayoutConstraintAxisVertical;
  flow.alignment = UIStackViewAlignmentCenter;
  flow.distribution = UIStackViewDistributionFill;
  flow.translatesAutoresizingMaskIntoConstraints = NO;
  [flow addArrangedSubview:top];
  [flow addArrangedSubview:spacerTop];
  [flow addArrangedSubview:center];
  [flow addArrangedSubview:spacerBottom];
  [flow addArrangedSubview:bottom];
  // A SCENE WITH NO RAIL LAYS OUT EXACTLY AS BEFORE. The rail only wraps the
  // flow when a widget actually asked for it, so the twenty-odd scenes that
  // predate this are untouched pixel for pixel -- the same rule the `compact`
  // flag follows a few lines up.
  BOOL hasRail = rail.arrangedSubviews.count > 0;
  UIView *shell = flow;
  if (hasRail) {
    UIStackView *side = [[UIStackView alloc] init];
    side.axis = UILayoutConstraintAxisHorizontal;
    side.alignment = UIStackViewAlignmentFill;
    side.spacing = compact ? 28 : 44;
    side.translatesAutoresizingMaskIntoConstraints = NO;
    // The rail GROUPS AT THE TOP. Without this it is a full-height stack and
    // UIKit spreads three labels down the whole screen -- measured on the
    // simulator: Search at mid-height, Services and Help adrift near the
    // bottom, reading as three unrelated words rather than one menu.
    UIStackView *railColumn = [[UIStackView alloc] init];
    railColumn.axis = UILayoutConstraintAxisVertical;
    railColumn.alignment = UIStackViewAlignmentLeading;
    railColumn.spacing = 0;
    railColumn.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *railTail = [[UIView alloc] init];
    railTail.translatesAutoresizingMaskIntoConstraints = NO;
    [railTail setContentHuggingPriority:1 forAxis:UILayoutConstraintAxisVertical];
    [railColumn addArrangedSubview:rail];
    [railColumn addArrangedSubview:railTail];
    [side addArrangedSubview:railColumn];
    [side addArrangedSubview:flow];
    // The rail takes only what its labels need; the content keeps the rest.
    [railColumn setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [railColumn setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    shell = side;
  }
  [self.contentView addSubview:shell];

  UILayoutGuide *safe = self.contentView.safeAreaLayoutGuide;
  // The bottom pin yields (only) if a scene is too tall to fit, letting the
  // flow overflow downward rather than forcing an unsatisfiable layout.
  NSLayoutConstraint *bottomPin =
      [shell.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor constant:-edge];
  bottomPin.priority = UILayoutPriorityRequired - 1;
  // Equal spacers keep the center column visually centered when there is slack.
  NSLayoutConstraint *equalSpacers =
      [spacerTop.heightAnchor constraintEqualToAnchor:spacerBottom.heightAnchor];
  equalSpacers.priority = UILayoutPriorityDefaultHigh;
  NSLayoutConstraint *xPin = hasRail
      ? [shell.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor constant:edge]
      : [shell.centerXAnchor constraintEqualToAnchor:self.contentView.centerXAnchor];
  if (hasRail) {
    [shell.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor constant:-edge].active = YES;
  }
  [NSLayoutConstraint activateConstraints:@[
    xPin,
    [shell.topAnchor constraintEqualToAnchor:safe.topAnchor constant:edge],
    bottomPin,
    [spacerTop.heightAnchor constraintGreaterThanOrEqualToConstant:spacerMin],
    [spacerBottom.heightAnchor constraintGreaterThanOrEqualToConstant:spacerMin],
    equalSpacers,
  ]];
}

- (UIView *)viewForWidget:(NSDictionary *)w {
  NSString *kind = [w[@"kind"] isKindOfClass:NSString.class] ? w[@"kind"] : @"";
  if ([kind isEqualToString:@"text"]) { return [self textViewForWidget:w]; }
  if ([kind isEqualToString:@"image"]) { return [self imageViewForWidget:w]; }
  if ([kind isEqualToString:@"qr"]) { return [self qrViewForWidget:w]; }
  if ([kind isEqualToString:@"rect"]) { return [self rectViewForWidget:w]; }
  if ([kind isEqualToString:@"card"]) { return [self cardViewForWidget:w height:230]; }
  if ([kind isEqualToString:@"stack"]) { return [self stackViewForWidget:w]; }
  if ([kind isEqualToString:@"hand"]) { return [self handViewForWidget:w]; }
  if ([kind isEqualToString:@"grid"]) { return [self gridViewForWidget:w]; }     // tv-grid branch, unreleased
  if ([kind isEqualToString:@"chips"]) { return [self chipsViewForWidget:w]; }   // tv-grid branch, unreleased
  if ([kind isEqualToString:@"spinner"]) { return [self spinnerViewForWidget:w]; }
  if ([kind isEqualToString:@"listrow"]) { return [self listRowViewForWidget:w]; }
  return [self placeholderForKind:kind];   // unknown kind: visible, never a crash
}

- (UILabel *)textViewForWidget:(NSDictionary *)w {
  UILabel *label = [[UILabel alloc] init];
  label.translatesAutoresizingMaskIntoConstraints = NO;
  label.text = [w[@"text"] isKindOfClass:NSString.class] ? w[@"text"] : @"";
  label.numberOfLines = 0;
  // numberOfLines=0 alone never wraps here: the widget columns are centered
  // with no width constraint, so a long single label's INTRINSIC width wins
  // and the line runs off both screen edges (seen on-device with a long
  // question stem). tvOS UIKit is logically 1920x1080, so cap every label at
  // 1760pt (80pt margins) and tell the intrinsic-size machinery to wrap at
  // the same width.
  // "max_width": PROSE IS NOT A CAPTION. 1760pt at the 36pt body face is about
  // 98 characters a line; every readability study since Tinker and Paterson in
  // the 1930s puts the comfortable range at 45-75, with 66 the usual target,
  // because the eye loses the start of the next line on a long return sweep.
  // 1760 stays the default, so every scene that does not ask is unmoved; the
  // reader asks for roughly 1200, which is about 66 characters.
  CGFloat maxW = [w[@"max_width"] isKindOfClass:NSNumber.class] ? (CGFloat)[w[@"max_width"] doubleValue] : 1760;
  if (maxW < 240 || maxW > 1760) { maxW = 1760; }
  label.preferredMaxLayoutWidth = maxW;
  [label.widthAnchor constraintLessThanOrEqualToConstant:maxW].active = YES;
  // "min_width": A COLUMN OF ROWS THAT SHARE A LEFT EDGE.
  //
  // Every label shrinks to its own text, and the column centres each one, so a
  // list of rows whose labels differ in length comes out ragged down BOTH
  // sides -- the Services screen read as fifteen service names scattered about
  // the middle of the screen rather than as a list. Left-aligning the text
  // alone does not fix it: a narrower label is still centred as a block, so its
  // left edge still lands somewhere else.
  //
  // Given a floor, every row is the same width, the blocks line up, and
  // align:"left" then puts every name at the same x. Reported from the couch:
  // "the list of services (names) are centered it looks bad".
  if ([w[@"min_width"] isKindOfClass:NSNumber.class]) {
    [label.widthAnchor constraintGreaterThanOrEqualToConstant:(CGFloat)[w[@"min_width"] doubleValue]].active = YES;
  }
  NSString *style = [w[@"style"] isKindOfClass:NSString.class] ? w[@"style"] : @"body";
  if ([style isEqualToString:@"title"]) { label.font = [UIFont systemFontOfSize:76 weight:UIFontWeightBold]; }
  else if ([style isEqualToString:@"headline"]) { label.font = [UIFont systemFontOfSize:48 weight:UIFontWeightSemibold]; }
  else if ([style isEqualToString:@"caption"]) { label.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular]; }
  else { label.font = [UIFont systemFontOfSize:36 weight:UIFontWeightRegular]; }
  label.textColor = HeyColorFromHex(w[@"color"], UIColor.whiteColor);
  // INLINE MARKDOWN, applied AFTER the font and colour are settled, because
  // bold and italic runs are derived from whatever font the style above
  // chose. Set only when a marker is actually present: an unmarked string
  // keeps the plain label.text path it has always used, so every scene and
  // every shipped pack renders byte-identically to before.
  NSString *raw = label.text;
  if (raw.length && ([raw containsString:@"*"] || [raw containsString:@"`"] || [raw containsString:@"\\"])) {
    label.attributedText = HeyAttributedFromMarkdown(raw, label.font, label.textColor);
  }
  NSString *align = [w[@"align"] isKindOfClass:NSString.class] ? w[@"align"] : @"center";
  label.textAlignment = [align isEqualToString:@"left"] ? NSTextAlignmentLeft
      : [align isEqualToString:@"right"] ? NSTextAlignmentRight : NSTextAlignmentCenter;
  // LINE AND PARAGRAPH SPACING (spacing branch, unreleased), in points, for a
  // page of body text read from a sofa: "line_spacing" is added between
  // lines, "paragraph_spacing" after each newline. Applied through a
  // paragraph style over whatever attributed or plain text the label holds,
  // keeping the alignment above, and only when a scene asks, so every other
  // label renders exactly as before.
  double lineSpacing = [w[@"line_spacing"] isKindOfClass:NSNumber.class] ? [w[@"line_spacing"] doubleValue] : 0;
  double paragraphSpacing = [w[@"paragraph_spacing"] isKindOfClass:NSNumber.class] ? [w[@"paragraph_spacing"] doubleValue] : 0;
  if (lineSpacing > 0 || paragraphSpacing > 0) {
    NSMutableParagraphStyle *para = [[NSMutableParagraphStyle alloc] init];
    para.lineSpacing = (CGFloat)MAX(0, lineSpacing);
    para.paragraphSpacing = (CGFloat)MAX(0, paragraphSpacing);
    para.alignment = label.textAlignment;
    para.lineBreakMode = NSLineBreakByWordWrapping;
    NSMutableAttributedString *spaced = label.attributedText
        ? [[NSMutableAttributedString alloc] initWithAttributedString:label.attributedText]
        : [[NSMutableAttributedString alloc] initWithString:label.text ?: @""
                                                  attributes:@{NSFontAttributeName: label.font, NSForegroundColorAttributeName: label.textColor}];
    [spaced addAttribute:NSParagraphStyleAttributeName value:para range:NSMakeRange(0, spaced.length)];
    label.attributedText = spaced;
  }
  return label;
}

- (UIImageView *)imageViewForWidget:(NSDictionary *)w {
  UIImageView *iv = [[UIImageView alloc] init];
  iv.translatesAutoresizingMaskIntoConstraints = NO;
  iv.contentMode = UIViewContentModeScaleAspectFit;
  NSString *symbol = [w[@"symbol"] isKindOfClass:NSString.class] ? w[@"symbol"] : @"";
  UIImage *img = symbol.length ? [UIImage systemImageNamed:symbol] : nil;
  UIColor *tint = HeyColorFromHex(w[@"tint"], nil);
  if (img && tint) { img = [img imageWithTintColor:tint renderingMode:UIImageRenderingModeAlwaysOriginal]; }
  iv.image = img;

  // 0.4.9: a real picture, not just an SF Symbol. "url" is fetched once and
  // cached; "symbol" still works exactly as before and acts as the placeholder
  // while the download is in flight. A widget with no "url" takes no new code
  // path at all, so every 0.4.8 scene renders identically.
  NSString *url = [w[@"url"] isKindOfClass:NSString.class] ? w[@"url"] : @"";
  if (url.length) { [self loadRemoteImage:url into:iv]; }

  // The 140x140 box was hardcoded through 0.4.8. It stays the default so
  // existing scenes are unmoved, but artwork needs to be bigger than an icon.
  CGFloat width = [w[@"width"] isKindOfClass:NSNumber.class] ? (CGFloat)[w[@"width"] doubleValue] : 140;
  CGFloat height = [w[@"height"] isKindOfClass:NSNumber.class] ? (CGFloat)[w[@"height"] doubleValue] : 140;
  if (width <= 0) { width = 140; }
  if (height <= 0) { height = 140; }
  [NSLayoutConstraint activateConstraints:@[
    [iv.widthAnchor constraintEqualToConstant:width],
    [iv.heightAnchor constraintEqualToConstant:height],
  ]];
  return iv;
}

// THE CACHE IS NOT AN OPTIMISATION, IT IS WHAT MAKES REMOTE IMAGES WORK AT
// ALL. A scene-mode poll rebuilds every widget view every couple of seconds,
// so a download that takes longer than one poll would land on a view that has
// already been thrown away -- and the replacement would start the download
// again, forever, showing nothing. Caching by url means the SECOND render
// (two seconds later) has the image synchronously. The image view is held
// weakly so a late arrival for a discarded view is simply dropped.
- (void)loadRemoteImage:(NSString *)urlString into:(UIImageView *)imageView {
  if (!self.imageCache) { self.imageCache = [[NSCache alloc] init]; }
  UIImage *cached = [self.imageCache objectForKey:urlString];
  if (cached) { imageView.image = cached; return; }

  NSURL *url = [NSURL URLWithString:urlString];
  if (!url) { return; }
  __weak UIImageView *weakImageView = imageView;
  __weak __typeof__(self) weakSelf = self;
  NSURLSessionDataTask *task =
      [NSURLSession.sharedSession dataTaskWithURL:url
                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    (void)response; (void)error;
    if (!data.length) { return; }
    UIImage *image = [UIImage imageWithData:data];
    if (!image) { return; }              // not an image; leave the symbol showing
    dispatch_async(dispatch_get_main_queue(), ^{
      __typeof__(self) strongSelf = weakSelf;
      if (strongSelf) { [strongSelf.imageCache setObject:image forKey:urlString]; }
      UIImageView *strongImageView = weakImageView;
      if (strongImageView) { strongImageView.image = image; }
    });
  }];
  [task resume];
}

- (UIImage *)qrImageForString:(NSString *)text size:(CGFloat)side {
  CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
  [filter setValue:[text dataUsingEncoding:NSUTF8StringEncoding] forKey:@"inputMessage"];
  [filter setValue:@"M" forKey:@"inputCorrectionLevel"];
  CIImage *output = filter.outputImage;
  if (!output) { return nil; }
  CGFloat scale = side / output.extent.size.width;
  CIImage *scaled = [output imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
  CIContext *context = [CIContext context];
  CGImageRef cg = [context createCGImage:scaled fromRect:scaled.extent];
  if (!cg) { return nil; }
  UIImage *image = [UIImage imageWithCGImage:cg];
  CGImageRelease(cg);
  return image;
}

- (UIView *)qrViewForWidget:(NSDictionary *)w {
  UIStackView *col = [[UIStackView alloc] init];
  col.axis = UILayoutConstraintAxisVertical;
  col.alignment = UIStackViewAlignmentCenter;
  col.spacing = 14;
  col.translatesAutoresizingMaskIntoConstraints = NO;

  NSString *payload = [w[@"payload"] isKindOfClass:NSString.class] ? w[@"payload"] : @"";
  UIImageView *qr = [[UIImageView alloc] init];
  qr.translatesAutoresizingMaskIntoConstraints = NO;
  qr.accessibilityIdentifier = @"scene-qr";
  qr.layer.magnificationFilter = kCAFilterNearest;
  if (payload.length) { qr.image = [self qrImageForString:payload size:260]; }
  [NSLayoutConstraint activateConstraints:@[
    [qr.widthAnchor constraintEqualToConstant:260],
    [qr.heightAnchor constraintEqualToConstant:260],
  ]];
  [col addArrangedSubview:qr];

  if ([w[@"caption"] isKindOfClass:NSString.class]) {
    UILabel *cap = [[UILabel alloc] init];
    cap.text = w[@"caption"];
    cap.font = [UIFont systemFontOfSize:28 weight:UIFontWeightRegular];
    // caption_color lets a light-background scene use a readable caption;
    // the near-white default predates light scenes and stays for backward
    // compatibility (dark scenes rely on it).
    cap.textColor = HeyColorFromHex(w[@"caption_color"], [UIColor colorWithWhite:0.9 alpha:1.0]);
    cap.textAlignment = NSTextAlignmentCenter;
    cap.numberOfLines = 0;
    cap.preferredMaxLayoutWidth = 1760;
    [cap.widthAnchor constraintLessThanOrEqualToConstant:1760].active = YES;
    [col addArrangedSubview:cap];
  }
  return col;
}

- (UIView *)rectViewForWidget:(NSDictionary *)w {
  UIView *v = [[UIView alloc] init];
  v.translatesAutoresizingMaskIntoConstraints = NO;
  v.backgroundColor = HeyColorFromHex(w[@"color"], UIColor.grayColor);
  v.layer.cornerRadius = 12;
  CGFloat width = [w[@"width"] respondsToSelector:@selector(doubleValue)] ? [w[@"width"] doubleValue] : 240;
  CGFloat height = [w[@"height"] respondsToSelector:@selector(doubleValue)] ? [w[@"height"] doubleValue] : 140;
  [NSLayoutConstraint activateConstraints:@[
    [v.widthAnchor constraintEqualToConstant:width],
    [v.heightAnchor constraintEqualToConstant:height],
  ]];
  return v;
}

- (HeyCardView *)cardFromDict:(NSDictionary *)c height:(CGFloat)h {
  HeyCardView *card = [[HeyCardView alloc] initWithHeight:h];
  card.rank = [c[@"rank"] isKindOfClass:NSString.class] ? c[@"rank"] : @"";
  card.suit = [c[@"suit"] isKindOfClass:NSString.class] ? c[@"suit"] : @"";
  NSString *face = [c[@"face"] isKindOfClass:NSString.class] ? c[@"face"] : @"up";
  card.faceUp = ![face isEqualToString:@"down"];
  [card setNeedsDisplay];
  return card;
}

- (UIView *)cardViewForWidget:(NSDictionary *)w height:(CGFloat)h {
  return [self cardFromDict:w height:h];
}

// A hand: a row of cards with an optional caption beneath it. Built as an
// explicit-constraint container (not a bare UIStackView) so its height ALWAYS
// includes the caption -- the caption is pinned inside the container and the
// container's bottom is pinned to it. That guarantees the hand contributes its
// full height to the enclosing slot column, so the next widget in the flow is
// laid out below the caption instead of overprinting it.
- (UIView *)handViewForWidget:(NSDictionary *)w {
  CGFloat cardH = 210;
  UIView *container = [[UIView alloc] init];
  container.translatesAutoresizingMaskIntoConstraints = NO;

  UIStackView *row = [[UIStackView alloc] init];
  row.axis = UILayoutConstraintAxisHorizontal;
  row.alignment = UIStackViewAlignmentCenter;
  row.spacing = 22;
  row.translatesAutoresizingMaskIntoConstraints = NO;
  NSArray *cards = [w[@"cards"] isKindOfClass:NSArray.class] ? w[@"cards"] : @[];
  for (id c in cards) {
    if (![c isKindOfClass:NSDictionary.class]) { continue; }
    [row addArrangedSubview:[self cardFromDict:c height:cardH]];
  }
  [container addSubview:row];

  NSMutableArray<NSLayoutConstraint *> *cons = [@[
    [row.topAnchor constraintEqualToAnchor:container.topAnchor],
    [row.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
    [row.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor],
    [row.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor],
    [row.heightAnchor constraintEqualToConstant:cardH],
    [container.widthAnchor constraintGreaterThanOrEqualToAnchor:row.widthAnchor],
  ] mutableCopy];

  UIView *lastView = row;   // the view whose bottom defines the container height
  if ([w[@"label"] isKindOfClass:NSString.class]) {
    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = w[@"label"];
    label.font = [UIFont systemFontOfSize:40 weight:UIFontWeightSemibold];
    label.textColor = UIColor.whiteColor;
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 1;
    [container addSubview:label];
    [cons addObjectsFromArray:@[
      [label.topAnchor constraintEqualToAnchor:row.bottomAnchor constant:16],
      [label.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
      [label.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor],
      [label.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor],
      [container.widthAnchor constraintGreaterThanOrEqualToAnchor:label.widthAnchor],
    ]];
    lastView = label;
  }
  // Pin the container bottom to the caption (or the card row when captionless):
  // this is what makes the caption count toward the container's height.
  [cons addObject:[container.bottomAnchor constraintEqualToAnchor:lastView.bottomAnchor]];
  // Hug content horizontally: minimise width subject to the >= guards above,
  // so the container settles at max(rowWidth, labelWidth).
  NSLayoutConstraint *hug = [container.widthAnchor constraintEqualToConstant:0];
  hug.priority = UILayoutPriorityDefaultLow;
  [cons addObject:hug];
  [NSLayoutConstraint activateConstraints:cons];
  return container;
}

- (UIView *)stackViewForWidget:(NSDictionary *)w {
  CGFloat h = 210;
  CGFloat cardW = [HeyCardView widthForHeight:h];
  NSArray *cards = [w[@"cards"] isKindOfClass:NSArray.class] ? w[@"cards"] : @[];
  NSString *fan = [w[@"fan"] isKindOfClass:NSString.class] ? w[@"fan"] : @"none";
  double overlap = [w[@"overlap"] respondsToSelector:@selector(doubleValue)] ? [w[@"overlap"] doubleValue] : 0.22;

  UIView *container = [[UIView alloc] init];
  container.translatesAutoresizingMaskIntoConstraints = NO;

  if (cards.count == 0) {
    HeyCardSlotView *slot = [[HeyCardSlotView alloc] initWithHeight:h];
    [container addSubview:slot];
    [NSLayoutConstraint activateConstraints:@[
      [container.widthAnchor constraintEqualToConstant:cardW],
      [container.heightAnchor constraintEqualToConstant:h],
      [slot.leadingAnchor constraintEqualToAnchor:container.leadingAnchor],
      [slot.topAnchor constraintEqualToAnchor:container.topAnchor],
    ]];
    return container;
  }

  CGFloat dx = [fan isEqualToString:@"right"] ? cardW * (1.0 - overlap) : 0;
  CGFloat dy = [fan isEqualToString:@"down"] ? h * (1.0 - overlap) : 0;
  NSUInteger i = 0;
  CGFloat maxX = 0, maxY = 0;
  for (id c in cards) {
    if (![c isKindOfClass:NSDictionary.class]) { continue; }
    HeyCardView *card = [self cardFromDict:c height:h];
    card.translatesAutoresizingMaskIntoConstraints = YES;
    card.frame = CGRectMake(dx * i, dy * i, cardW, h);
    [container addSubview:card];
    maxX = MAX(maxX, dx * i + cardW);
    maxY = MAX(maxY, dy * i + h);
    i++;
  }
  [NSLayoutConstraint activateConstraints:@[
    [container.widthAnchor constraintEqualToConstant:maxX],
    [container.heightAnchor constraintEqualToConstant:maxY],
  ]];
  return container;
}

// ---- grid + chips (tv-grid branch, unreleased) ---------------------------
//
// A library is not a list of sentences. `grid` lays artwork tiles out in rows
// the way the TV app and the old web app do -- picture, title, provider and
// year, stars -- with one tile SELECTED. The server owns the cursor (it pages
// the items and names the selected index), so a poll every few seconds
// rebuilds the same picture the couch already sees; the renderer never handles
// a press for it. `chips` is one row of pills with one filled: the media-type
// filter; "focused" true draws the selected pill as the cursor.
//
//   {"kind":"grid","id":"items","columns":4,"selected":2,
//    "tile":{"width":380,"height":300},
//    "items":[{"id":"...","image":"https://...","symbol":"play.rectangle",
//              "title":"...","meta":"YouTube - 2025","stars":3,"badge":"YouTube"}]}
//   {"kind":"chips","id":"filters","selected":1,"focused":false,"items":["All","Video","TV"]}
//
// Tiles are fixed-size (tile.width x tile.height); the artwork box is 16:9 of
// the width. Artwork loads through the same cache as the image widget, so the
// second poll has it synchronously; while it is in flight the media-type
// symbol shows. stars < 0 draws no star row (a set is not rated).
static UIColor *HeyGridInk(void) { return [UIColor colorWithRed:0xF2/255.0 green:0xF6/255.0 blue:0xFA/255.0 alpha:1]; }
static UIColor *HeyGridMuted(void) { return [UIColor colorWithRed:0x8F/255.0 green:0xA3/255.0 blue:0xB8/255.0 alpha:1]; }
static UIColor *HeyGridAccent(void) { return [UIColor colorWithRed:0x4D/255.0 green:0xA3/255.0 blue:0xFF/255.0 alpha:1]; }
static UIColor *HeyGridCard(void) { return [UIColor colorWithRed:0x16/255.0 green:0x21/255.0 blue:0x3A/255.0 alpha:1]; }
static UIColor *HeyGridGold(void) { return [UIColor colorWithRed:0xFF/255.0 green:0xC5/255.0 blue:0x3D/255.0 alpha:1]; }

static UILabel *HeyStarsLabel(NSInteger stars, CGFloat size) {
  UILabel *l = [[UILabel alloc] init];
  l.translatesAutoresizingMaskIntoConstraints = NO;
  NSMutableAttributedString *a = [[NSMutableAttributedString alloc] init];
  UIFont *f = [UIFont systemFontOfSize:size weight:UIFontWeightMedium];
  for (NSInteger i = 1; i <= 5; i++) {
    BOOL on = i <= stars;
    NSAttributedString *piece = [[NSAttributedString alloc]
        initWithString:on ? @"★" : @"☆"
            attributes:@{ NSFontAttributeName: f,
                          NSForegroundColorAttributeName: on ? HeyGridGold() : HeyGridMuted() }];
    [a appendAttributedString:piece];
  }
  l.attributedText = a;
  return l;
}

- (UIView *)tileForItem:(NSDictionary *)it width:(CGFloat)tw height:(CGFloat)th selected:(BOOL)selected {
  UIView *tile = [[UIView alloc] init];
  tile.translatesAutoresizingMaskIntoConstraints = NO;
  tile.clipsToBounds = NO;

  CGFloat artH = round(tw * 9.0 / 16.0);
  UIView *art = [[UIView alloc] init];
  art.translatesAutoresizingMaskIntoConstraints = NO;
  art.backgroundColor = HeyGridCard();
  art.layer.cornerRadius = 14;
  art.clipsToBounds = YES;
  [tile addSubview:art];

  // Placeholder: the media-type glyph, centred, muted. Sits UNDER the picture
  // view so a loaded image simply covers it.
  NSString *symbol = [it[@"symbol"] isKindOfClass:NSString.class] ? it[@"symbol"] : @"play.rectangle";
  UIImage *glyph = [UIImage systemImageNamed:symbol];
  if (glyph) {
    UIImageView *ph = [[UIImageView alloc] initWithImage:[glyph imageWithTintColor:HeyGridMuted() renderingMode:UIImageRenderingModeAlwaysOriginal]];
    ph.translatesAutoresizingMaskIntoConstraints = NO;
    ph.contentMode = UIViewContentModeScaleAspectFit;
    [art addSubview:ph];
    [NSLayoutConstraint activateConstraints:@[
      [ph.centerXAnchor constraintEqualToAnchor:art.centerXAnchor],
      [ph.centerYAnchor constraintEqualToAnchor:art.centerYAnchor],
      [ph.widthAnchor constraintEqualToConstant:84],
      [ph.heightAnchor constraintEqualToConstant:84],
    ]];
  }
  NSString *image = [it[@"image"] isKindOfClass:NSString.class] ? it[@"image"] : @"";
  if (image.length) {
    UIImageView *iv = [[UIImageView alloc] init];
    iv.translatesAutoresizingMaskIntoConstraints = NO;
    iv.contentMode = UIViewContentModeScaleAspectFill;
    iv.clipsToBounds = YES;
    [art addSubview:iv];
    [NSLayoutConstraint activateConstraints:@[
      [iv.leadingAnchor constraintEqualToAnchor:art.leadingAnchor],
      [iv.trailingAnchor constraintEqualToAnchor:art.trailingAnchor],
      [iv.topAnchor constraintEqualToAnchor:art.topAnchor],
      [iv.bottomAnchor constraintEqualToAnchor:art.bottomAnchor],
    ]];
    [self loadRemoteImage:image into:iv];
  }

  // Provider badge, top-left of the artwork.
  NSString *badge = [it[@"badge"] isKindOfClass:NSString.class] ? it[@"badge"] : @"";
  if (badge.length) {
    UIView *pill = [[UIView alloc] init];
    pill.translatesAutoresizingMaskIntoConstraints = NO;
    pill.backgroundColor = [UIColor colorWithWhite:0 alpha:0.62];
    pill.layer.cornerRadius = 10;
    UILabel *bl = [[UILabel alloc] init];
    bl.translatesAutoresizingMaskIntoConstraints = NO;
    bl.text = badge;
    bl.font = [UIFont systemFontOfSize:22 weight:UIFontWeightSemibold];
    bl.textColor = UIColor.whiteColor;
    [pill addSubview:bl];
    [art addSubview:pill];
    [NSLayoutConstraint activateConstraints:@[
      [bl.leadingAnchor constraintEqualToAnchor:pill.leadingAnchor constant:12],
      [bl.trailingAnchor constraintEqualToAnchor:pill.trailingAnchor constant:-12],
      [bl.topAnchor constraintEqualToAnchor:pill.topAnchor constant:5],
      [bl.bottomAnchor constraintEqualToAnchor:pill.bottomAnchor constant:-5],
      [pill.leadingAnchor constraintEqualToAnchor:art.leadingAnchor constant:12],
      [pill.topAnchor constraintEqualToAnchor:art.topAnchor constant:12],
    ]];
  }

  // The tile's height is FIXED (rows must align), so the title gets exactly the
  // lines that fit above the meta/stars row and truncates past that. Measured
  // 2026-09-08: a two-line title in a tile too short for it pushed the meta
  // text into the star row.
  UIFont *titleFont = [UIFont systemFontOfSize:30 weight:selected ? UIFontWeightBold : UIFontWeightSemibold];
  const CGFloat kTitleTop = 10, kRowH = 32, kRowGap = 6, kBottomPad = 4;
  CGFloat titleAvail = th - artH - kTitleTop - kRowGap - kRowH - kBottomPad;
  CGFloat lineH = ceil(titleFont.lineHeight);
  NSInteger titleLines = titleAvail >= 2 * lineH ? 2 : 1;

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  title.text = [it[@"title"] isKindOfClass:NSString.class] ? it[@"title"] : @"";
  title.font = titleFont;
  title.textColor = selected ? UIColor.whiteColor : HeyGridInk();
  title.numberOfLines = titleLines;
  title.lineBreakMode = NSLineBreakByTruncatingTail;
  title.textAlignment = NSTextAlignmentLeft;
  [title setContentCompressionResistancePriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisVertical];
  [tile addSubview:title];

  UILabel *meta = [[UILabel alloc] init];
  meta.translatesAutoresizingMaskIntoConstraints = NO;
  meta.text = [it[@"meta"] isKindOfClass:NSString.class] ? it[@"meta"] : @"";
  // 24pt so "2024 · TVmaze" fits a 320 tile whole; the server puts the year FIRST, so when the row still truncates it is the provider that takes the ellipsis, never the year.
  meta.font = [UIFont systemFontOfSize:24 weight:UIFontWeightRegular];
  meta.textColor = HeyGridMuted();
  meta.numberOfLines = 1;
  meta.lineBreakMode = NSLineBreakByTruncatingTail;
  // Meta yields, stars never do: when the two compete for the row, the meta
  // text takes the ellipsis and all five stars stay whole.
  [meta setContentCompressionResistancePriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
  [meta setContentHuggingPriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
  [tile addSubview:meta];

  NSInteger stars = [it[@"stars"] isKindOfClass:NSNumber.class] ? [it[@"stars"] integerValue] : -1;
  UILabel *starRow = stars >= 0 ? HeyStarsLabel(stars, 26) : nil;
  if (starRow) {
    [starRow setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [starRow setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [tile addSubview:starRow];
  }

  NSMutableArray<NSLayoutConstraint *> *cons = [@[
    [tile.widthAnchor constraintEqualToConstant:tw],
    [tile.heightAnchor constraintEqualToConstant:th],
    [art.leadingAnchor constraintEqualToAnchor:tile.leadingAnchor],
    [art.trailingAnchor constraintEqualToAnchor:tile.trailingAnchor],
    [art.topAnchor constraintEqualToAnchor:tile.topAnchor],
    [art.heightAnchor constraintEqualToConstant:artH],
    [title.leadingAnchor constraintEqualToAnchor:tile.leadingAnchor constant:4],
    [title.trailingAnchor constraintEqualToAnchor:tile.trailingAnchor constant:-4],
    [title.topAnchor constraintEqualToAnchor:art.bottomAnchor constant:kTitleTop],
    // Never taller than the lines that fit, so the row below always lands
    // inside the fixed tile height (rows must align across the shelf).
    [title.heightAnchor constraintLessThanOrEqualToConstant:titleLines * lineH + 2],
    [meta.leadingAnchor constraintEqualToAnchor:title.leadingAnchor],
    // ONE row that FOLLOWS the title (a one-line title used to leave a loose
    // gap above a bottom-pinned row): meta at the left, stars at the right.
    [meta.heightAnchor constraintEqualToConstant:kRowH],
    [meta.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:kRowGap],
    [meta.bottomAnchor constraintLessThanOrEqualToAnchor:tile.bottomAnchor constant:-kBottomPad],
  ] mutableCopy];
  if (starRow) {
    [cons addObjectsFromArray:@[
      [starRow.trailingAnchor constraintEqualToAnchor:title.trailingAnchor],
      [starRow.centerYAnchor constraintEqualToAnchor:meta.centerYAnchor],
      [meta.trailingAnchor constraintLessThanOrEqualToAnchor:starRow.leadingAnchor constant:-8],
    ]];
  } else {
    [cons addObject:[meta.trailingAnchor constraintEqualToAnchor:title.trailingAnchor]];
  }
  [NSLayoutConstraint activateConstraints:cons];

  // WHERE THE CONTROL IS, AT ALL TIMES. From the couch: "we need it to be clear
  // what's highlighted and where the control is at all times. The little white
  // shadow is not effective."
  //
  // The focused tile already had a border, a shadow and a 1.08 scale. The thing
  // it did NOT have was anything to stand out AGAINST: every other tile on the
  // screen was at full brightness, so the eye had to find a slightly larger
  // rectangle among a dozen equally bright ones. Netflix, Apple TV+ and Prime
  // all hold the unfocused content back -- the contrast is the signal, not the
  // ornament on the focused one.
  //
  // So the focused tile lifts further (1.16, which is plainly a different size
  // at ten feet rather than a maybe), and everything unfocused drops to 55%.
  // The peek row underneath is unfocused by definition and dims with it, which
  // is also what a peeked row should look like.
  if (selected) {
    art.layer.borderWidth = 5;
    art.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.98].CGColor;
    tile.layer.shadowColor = UIColor.blackColor.CGColor;
    tile.layer.shadowOpacity = 0.8;
    tile.layer.shadowRadius = 28;
    tile.layer.shadowOffset = CGSizeMake(0, 16);
    tile.transform = CGAffineTransformMakeScale(1.16, 1.16);
  } else {
    tile.alpha = 0.55;
  }
  return tile;
}

- (UIView *)gridViewForWidget:(NSDictionary *)w {
  NSInteger columns = [w[@"columns"] isKindOfClass:NSNumber.class] ? [w[@"columns"] integerValue] : 4;
  if (columns < 1) { columns = 1; }
  NSInteger selected = [w[@"selected"] isKindOfClass:NSNumber.class] ? [w[@"selected"] integerValue] : -1;
  NSDictionary *tile = [w[@"tile"] isKindOfClass:NSDictionary.class] ? w[@"tile"] : @{};
  CGFloat tw = [tile[@"width"] isKindOfClass:NSNumber.class] ? [tile[@"width"] doubleValue] : 380;
  CGFloat th = [tile[@"height"] isKindOfClass:NSNumber.class] ? [tile[@"height"] doubleValue] : 300;
  if (tw < 120) { tw = 120; }
  if (th < 120) { th = 120; }
  CGFloat gap = 36;
  NSArray *items = [w[@"items"] isKindOfClass:NSArray.class] ? w[@"items"] : @[];

  UIStackView *rows = [[UIStackView alloc] init];
  rows.axis = UILayoutConstraintAxisVertical;
  rows.alignment = UIStackViewAlignmentLeading;
  rows.spacing = gap;
  rows.translatesAutoresizingMaskIntoConstraints = NO;

  UIStackView *row = nil;
  NSInteger inRow = 0, index = 0;
  for (id item in items) {
    if (![item isKindOfClass:NSDictionary.class]) { continue; }
    if (!row || inRow == columns) {
      row = [[UIStackView alloc] init];
      row.axis = UILayoutConstraintAxisHorizontal;
      row.alignment = UIStackViewAlignmentTop;
      row.spacing = gap;
      row.translatesAutoresizingMaskIntoConstraints = NO;
      [rows addArrangedSubview:row];
      inRow = 0;
    }
    [row addArrangedSubview:[self tileForItem:item width:tw height:th selected:index == selected]];
    inRow++; index++;
  }
  if (index == 0) {
    UILabel *empty = [[UILabel alloc] init];
    empty.translatesAutoresizingMaskIntoConstraints = NO;
    empty.text = @"Nothing here yet.";
    empty.font = [UIFont systemFontOfSize:36 weight:UIFontWeightRegular];
    empty.textColor = HeyGridMuted();
    [rows addArrangedSubview:empty];
  }
  // A fixed footprint so the flow column can centre it; short last rows stay
  // left-aligned inside it.
  [rows.widthAnchor constraintEqualToConstant:columns * tw + (columns - 1) * gap].active = YES;

  // "clip_height": THE NEXT ROW IS CUT OFF, NOT SHRUNK. Reported from the
  // couch: "you seem to be squashing the next row ... We need the subsequent
  // row to be a FULL row, not squished icons ... it's got to be cut-off on
  // purpose." The server had been asking for a short TILE, which is a different
  // thing three ways: heights below 120 are clamped up, a placeholder glyph is
  // aspect-FIT so it genuinely squashes, and the tile still draws its corners
  // and border at the short height, so the row reads as deliberately small
  // rather than as the top of something larger.
  //
  // Tiles are built at full size and a window shows only the top band of them,
  // which is what Netflix, Prime and the rest actually do. The scene asks for
  // the visible height; nothing else about the row changes.
  CGFloat clipH = [w[@"clip_height"] isKindOfClass:NSNumber.class] ? (CGFloat)[w[@"clip_height"] doubleValue] : 0;
  if (clipH > 0 && clipH < th) {
    UIView *window = [[UIView alloc] init];
    window.translatesAutoresizingMaskIntoConstraints = NO;
    window.clipsToBounds = YES;
    [window addSubview:rows];
    [NSLayoutConstraint activateConstraints:@[
      [rows.topAnchor constraintEqualToAnchor:window.topAnchor],
      [rows.leadingAnchor constraintEqualToAnchor:window.leadingAnchor],
      [window.widthAnchor constraintEqualToAnchor:rows.widthAnchor],
      [window.heightAnchor constraintEqualToConstant:clipH],
    ]];
    return window;
  }
  return rows;
}

- (UIView *)chipsViewForWidget:(NSDictionary *)w {
  NSInteger selected = [w[@"selected"] isKindOfClass:NSNumber.class] ? [w[@"selected"] integerValue] : -1;
  BOOL focused = [w[@"focused"] isKindOfClass:NSNumber.class] ? [w[@"focused"] boolValue] : NO;
  NSArray *items = [w[@"items"] isKindOfClass:NSArray.class] ? w[@"items"] : @[];
  // TYPE AND A BAR, NOT PILLS.
  //
  // The first cut drew each section as a small rounded pill: a dark blue
  // capsule with the current one filled accent-blue. Reported from the couch as
  // looking "weak", and it does -- eight identical little buttons read as a
  // toolbar of minor controls, not as the primary way through the library, and
  // at ten feet the filled one is a slightly different blue smudge.
  //
  // Netflix, Prime and the tvOS Music app all resolve this the same way and it
  // is worth copying: the sections are plain WORDS, large, widely spaced, and
  // the current one is marked by weight, brightness and a solid bar beneath it.
  // Nothing is boxed. A bar under a word is unmissable across a room because it
  // is the only horizontal line on the screen, and it cannot be confused with
  // the rounded artwork below it.
  //
  // FOCUSED AND SELECTED ARE DRAWN DIFFERENTLY, which the pills could not do at
  // all. When the row has the remote, the cursor is a bright word over a full
  // accent bar. When it does not, the section you are actually in keeps a
  // dimmer bar, so leaving the row does not lose your place on screen.
  UIStackView *rowView = [[UIStackView alloc] init];
  rowView.axis = UILayoutConstraintAxisHorizontal;
  rowView.alignment = UIStackViewAlignmentTop;
  rowView.spacing = 44;
  rowView.translatesAutoresizingMaskIntoConstraints = NO;
  NSInteger i = 0;
  for (id item in items) {
    NSString *text = [item isKindOfClass:NSString.class] ? item : @"";
    BOOL on = i == selected;

    UIView *cell = [[UIView alloc] init];
    cell.translatesAutoresizingMaskIntoConstraints = NO;

    UILabel *l = [[UILabel alloc] init];
    l.translatesAutoresizingMaskIntoConstraints = NO;
    l.text = text;
    l.font = [UIFont systemFontOfSize:34 weight:on ? UIFontWeightBold : UIFontWeightMedium];
    l.textColor = on ? [UIColor colorWithWhite:1 alpha:1]
                     : [UIColor colorWithRed:0x8F/255.0 green:0xA3/255.0 blue:0xB8/255.0 alpha:1];
    [cell addSubview:l];

    // The bar. Full accent under the cursor; a dimmed one under the section you
    // are in while the remote is somewhere else; nothing under the rest.
    UIView *bar = [[UIView alloc] init];
    bar.translatesAutoresizingMaskIntoConstraints = NO;
    bar.layer.cornerRadius = 3;
    bar.backgroundColor = on ? (focused ? HeyGridAccent()
                                        : [HeyGridAccent() colorWithAlphaComponent:0.45])
                             : [UIColor clearColor];
    [cell addSubview:bar];

    [NSLayoutConstraint activateConstraints:@[
      [l.topAnchor constraintEqualToAnchor:cell.topAnchor],
      [l.leadingAnchor constraintEqualToAnchor:cell.leadingAnchor],
      [l.trailingAnchor constraintEqualToAnchor:cell.trailingAnchor],
      [bar.topAnchor constraintEqualToAnchor:l.bottomAnchor constant:10],
      [bar.leadingAnchor constraintEqualToAnchor:cell.leadingAnchor],
      [bar.trailingAnchor constraintEqualToAnchor:cell.trailingAnchor],
      [bar.heightAnchor constraintEqualToConstant:6],
      [bar.bottomAnchor constraintEqualToAnchor:cell.bottomAnchor],
    ]];
    [rowView addArrangedSubview:cell];
    i++;
  }
  return rowView;
}

// THREE DOTS THAT ACTUALLY MOVE.
//
// The boot screen used to read "Connecting to https://<the production origin> as
// tv-<the device id>..." while it waited -- putting the production origin AND the
// device token on a television in somebody's living room, where the one thing
// you can be sure of is that other people can see it. It says nothing now, and
// this is what shows instead.
//
// It has to be a widget rather than a string because the Hey side has no timer:
// tv_scene_init runs once and tv_scene_step only runs on a button. A caption
// reading "..." would sit there motionless for however long the server takes,
// which is exactly when a viewer needs to know the difference between "working"
// and "wedged". The animation is the whole point of it.
- (UIView *)spinnerViewForWidget:(NSDictionary *)w {
  UIColor *tint = HeyColorFromHex(w[@"tint"], [UIColor colorWithRed:0x8F/255.0 green:0xA3/255.0 blue:0xB8/255.0 alpha:1]);
  CGFloat side = [w[@"size"] isKindOfClass:NSNumber.class] ? [w[@"size"] doubleValue] : 16;
  UIStackView *row = [[UIStackView alloc] init];
  row.axis = UILayoutConstraintAxisHorizontal;
  row.alignment = UIStackViewAlignmentCenter;
  row.spacing = side;
  row.translatesAutoresizingMaskIntoConstraints = NO;
  for (int i = 0; i < 3; i++) {
    UIView *dot = [[UIView alloc] init];
    dot.translatesAutoresizingMaskIntoConstraints = NO;
    dot.backgroundColor = tint;
    dot.layer.cornerRadius = side / 2.0;
    [NSLayoutConstraint activateConstraints:@[
      [dot.widthAnchor constraintEqualToConstant:side],
      [dot.heightAnchor constraintEqualToConstant:side],
    ]];
    // Staggered, so it reads left to right as one thing rather than three
    // lights blinking at each other.
    CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"opacity"];
    pulse.fromValue = @0.15;
    pulse.toValue = @1.0;
    pulse.duration = 0.6;
    pulse.beginTime = CACurrentMediaTime() + (0.2 * i);
    pulse.autoreverses = YES;
    pulse.repeatCount = HUGE_VALF;
    dot.layer.opacity = 0.15;
    [dot.layer addAnimation:pulse forKey:@"pulse"];
    [row addArrangedSubview:dot];
  }
  return row;
}

// A SETTINGS ROW, because a column of text is not a list.
//
// Services was fifteen centred strings, each one "pointer + circle + name" as
// plain text. Left-aligning them and giving them a common width made the names
// line up, and it was still wrong -- reported as "still ugly", correctly. The
// problem was never the alignment: text with a ○ typed in front of it is not a
// control, there was nothing to separate the twelve apps from the three
// preferences underneath them, and the focused row was distinguished only by
// being a slightly different colour of the same flat text.
//
// This is the shape tvOS Settings uses and the reason it works at ten feet: a
// row of fixed height with a filled BAND behind the focused one, a real symbol
// on the left for the on/off state, and the label always starting at the same
// x. The band is the thing that carries -- a solid rectangle is visible from
// across a room when a colour change is not.
- (UIView *)listRowViewForWidget:(NSDictionary *)w {
  BOOL on = [w[@"on"] isKindOfClass:NSNumber.class] ? [w[@"on"] boolValue] : NO;
  BOOL focused = [w[@"focused"] isKindOfClass:NSNumber.class] ? [w[@"focused"] boolValue] : NO;
  CGFloat width = [w[@"width"] isKindOfClass:NSNumber.class] ? (CGFloat)[w[@"width"] doubleValue] : 1100;
  NSString *text = [w[@"text"] isKindOfClass:NSString.class] ? w[@"text"] : @"";

  UIView *row = [[UIView alloc] init];
  row.translatesAutoresizingMaskIntoConstraints = NO;
  row.layer.cornerRadius = 14;
  row.backgroundColor = focused ? HeyGridAccent() : [UIColor clearColor];

  UIColor *ink = focused ? [UIColor colorWithRed:0x0B/255.0 green:0x12/255.0 blue:0x20/255.0 alpha:1]
                         : [UIColor colorWithRed:0xF2/255.0 green:0xF6/255.0 blue:0xFA/255.0 alpha:1];

  // The state, as a symbol rather than a typed circle: filled and ticked when
  // the thing is on, an empty ring when it is not.
  UIImageView *mark = [[UIImageView alloc] init];
  mark.translatesAutoresizingMaskIntoConstraints = NO;
  mark.contentMode = UIViewContentModeScaleAspectFit;
  UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:28 weight:UIImageSymbolWeightSemibold];
  mark.image = [UIImage systemImageNamed:(on ? @"checkmark.circle.fill" : @"circle") withConfiguration:cfg];
  mark.tintColor = focused ? ink : (on ? HeyGridAccent()
                                       : [UIColor colorWithRed:0x8F/255.0 green:0xA3/255.0 blue:0xB8/255.0 alpha:1]);

  UILabel *l = [[UILabel alloc] init];
  l.translatesAutoresizingMaskIntoConstraints = NO;
  l.text = text;
  l.font = [UIFont systemFontOfSize:30 weight:focused ? UIFontWeightSemibold : UIFontWeightRegular];
  l.textColor = ink;
  l.textAlignment = NSTextAlignmentLeft;

  [row addSubview:mark];
  [row addSubview:l];
  [NSLayoutConstraint activateConstraints:@[
    [row.widthAnchor constraintEqualToConstant:width],
    // 46, NOT 52. Thirteen services plus a gap plus three preferences is
    // seventeen rows, and at 52 the last one was clipped off the bottom of the
    // screen -- adding TIDAL cost exactly one row of headroom. Measured on the
    // simulator each time the list grew; if it grows again, this is the number
    // to look at first.
    [row.heightAnchor constraintEqualToConstant:46],
    [mark.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:26],
    [mark.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
    [mark.widthAnchor constraintEqualToConstant:32],
    [mark.heightAnchor constraintEqualToConstant:32],
    [l.leadingAnchor constraintEqualToAnchor:mark.trailingAnchor constant:22],
    [l.trailingAnchor constraintLessThanOrEqualToAnchor:row.trailingAnchor constant:-26],
    [l.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
  ]];
  return row;
}

- (UIView *)placeholderForKind:(NSString *)kind {
  UILabel *label = [[UILabel alloc] init];
  label.text = [NSString stringWithFormat:@"[%@?]", kind.length ? kind : @"widget"];
  label.font = [UIFont monospacedSystemFontOfSize:30 weight:UIFontWeightRegular];
  label.textColor = [UIColor colorWithRed:1.0 green:0.6 blue:0.2 alpha:1.0];
  label.textAlignment = NSTextAlignmentCenter;
  label.layer.borderColor = [UIColor colorWithRed:1.0 green:0.6 blue:0.2 alpha:1.0].CGColor;
  label.layer.borderWidth = 2;
  return label;
}

- (void)viewDidLayoutSubviews {
  [super viewDidLayoutSubviews];
  self.feltLayer.frame = self.view.bounds;
}
@end

#define HEY_ROOT_VIEW_CONTROLLER HeySceneViewController

#else
// =========================================================================
// v1 game contract (opaque i64 + manifest); unchanged behavior.
// =========================================================================
extern const char *HEY_ENTRY_SYMBOL(void);
extern long long hey_fn_tvos_action_code(long long action_id);
extern long long hey_fn_tvos_game_init(void);
extern long long hey_fn_tvos_game_step(long long state, long long action_id);
extern const char *hey_fn_tvos_game_text(long long state);

@interface HeyTVViewController : UIViewController
@property(nonatomic) long long gameState;
@property(strong, nonatomic) UILabel *gameLabel;
@end

@implementation HeyTVViewController

- (UIImage *)qrImageForString:(NSString *)text size:(CGFloat)side {
  CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
  [filter setValue:[text dataUsingEncoding:NSUTF8StringEncoding] forKey:@"inputMessage"];
  [filter setValue:@"M" forKey:@"inputCorrectionLevel"];
  CIImage *output = filter.outputImage;
  if (!output) { return nil; }
  CGFloat scale = side / output.extent.size.width;
  CIImage *scaled = [output imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
  CIContext *context = [CIContext context];
  CGImageRef cg = [context createCGImage:scaled fromRect:scaled.extent];
  if (!cg) { return nil; }
  UIImage *image = [UIImage imageWithCGImage:cg];
  CGImageRelease(cg);
  return image;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.view.backgroundColor = UIColor.blackColor;
  const char *manifestBytes = HEY_ENTRY_SYMBOL();
  NSString *manifest = manifestBytes ? [NSString stringWithUTF8String:manifestBytes] : @"{}";
  NSDictionary *fields = @{};
  NSData *manifestData = [manifest dataUsingEncoding:NSUTF8StringEncoding];
  if (manifestData) {
    id parsed = [NSJSONSerialization JSONObjectWithData:manifestData options:0 error:NULL];
    if ([parsed isKindOfClass:NSDictionary.class]) { fields = parsed; }
  }
  NSString *titleText = [fields[@"title"] isKindOfClass:NSString.class] ? fields[@"title"] : @"Hey TV";
  NSString *joinUrl = [fields[@"join_url"] isKindOfClass:NSString.class] ? fields[@"join_url"] : @"";

  UILabel *title = [[UILabel alloc] init];
  title.translatesAutoresizingMaskIntoConstraints = NO;
  title.text = titleText;
  title.textColor = UIColor.whiteColor;
  title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1];
  [self.view addSubview:title];

  UIImageView *qrView = [[UIImageView alloc] init];
  qrView.translatesAutoresizingMaskIntoConstraints = NO;
  qrView.accessibilityIdentifier = @"join-qr";
  if (joinUrl.length > 0) { qrView.image = [self qrImageForString:joinUrl size:360]; }
  [self.view addSubview:qrView];

  UILabel *joinLabel = [[UILabel alloc] init];
  joinLabel.translatesAutoresizingMaskIntoConstraints = NO;
  joinLabel.text = joinUrl;
  joinLabel.textColor = UIColor.lightGrayColor;
  joinLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
  [self.view addSubview:joinLabel];

  self.gameState = hey_fn_tvos_game_init();
  UILabel *game = [[UILabel alloc] init];
  game.translatesAutoresizingMaskIntoConstraints = NO;
  game.textColor = UIColor.whiteColor;
  game.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  game.numberOfLines = 3;
  game.textAlignment = NSTextAlignmentCenter;
  game.accessibilityIdentifier = @"game-state";
  self.gameLabel = game;
  [self refreshGameLabel];
  [self.view addSubview:game];

  [NSLayoutConstraint activateConstraints:@[
    [title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:60],
    [qrView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [qrView.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:40],
    [qrView.widthAnchor constraintEqualToConstant:360],
    [qrView.heightAnchor constraintEqualToConstant:360],
    [joinLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
    [joinLabel.topAnchor constraintEqualToAnchor:qrView.bottomAnchor constant:16],
    [game.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:120],
    [game.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-120],
    [game.topAnchor constraintEqualToAnchor:joinLabel.bottomAnchor constant:60]
  ]];

  NSArray<NSNumber *> *pressTypes = @[
    @(UIPressTypeSelect), @(UIPressTypeUpArrow), @(UIPressTypeDownArrow),
    @(UIPressTypeLeftArrow), @(UIPressTypeRightArrow), @(UIPressTypePlayPause)
  ];
  for (NSNumber *pressType in pressTypes) {
    UITapGestureRecognizer *tap =
        [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(remotePress:)];
    tap.allowedPressTypes = @[ pressType ];
    [self.view addGestureRecognizer:tap];
  }
}

- (void)refreshGameLabel {
  const char *text = hey_fn_tvos_game_text(self.gameState);
  self.gameLabel.text = text ? [NSString stringWithUTF8String:text] : @"";
}

- (void)remotePress:(UITapGestureRecognizer *)recognizer {
  NSNumber *pressType = recognizer.allowedPressTypes.firstObject;
  long long action = 1;
  switch ((UIPressType)pressType.integerValue) {
    case UIPressTypeSelect: action = 1; break;
    case UIPressTypeUpArrow: action = 2; break;
    case UIPressTypeDownArrow: action = 3; break;
    case UIPressTypeLeftArrow: action = 4; break;
    case UIPressTypeRightArrow: action = 5; break;
    case UIPressTypePlayPause: action = 6; break;
    default: action = 1; break;
  }
  self.gameState = hey_fn_tvos_game_step(self.gameState, action);
  self.gameLabel.accessibilityValue =
      [NSString stringWithFormat:@"%lld", hey_fn_tvos_action_code(action)];
  [self refreshGameLabel];
}
@end

#define HEY_ROOT_VIEW_CONTROLLER HeyTVViewController

#endif

// ---- shared app delegate + entry point ----------------------------------
@interface HeyTVAppDelegate : UIResponder <UIApplicationDelegate>
@property(strong, nonatomic) UIWindow *window;
@end

@implementation HeyTVAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
  self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  self.window.rootViewController = [[HEY_ROOT_VIEW_CONTROLLER alloc] init];
  [self.window makeKeyAndVisible];
  return YES;
}
- (void)applicationWillTerminate:(UIApplication *)application {
  hey_runtime_shutdown();
}
@end

int main(int argc, char **argv) {
  @autoreleasepool {
    hey_runtime_init();
    hey_runtime_set_argv(argc, argv);
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(HeyTVAppDelegate.class));
  }
}
