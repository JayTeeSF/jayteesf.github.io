# Todos

- 0.2.0 second half: extract RecallCoach's fast-lane modules (listen,
  origin, request_support, request_log, responses), delete the stale
  `src/` duplicates, drop the `../elders_prayer_app/bin/heyc` fallback
  from `bin/heyc`.
- Run live HTTP/HTTPS client and server receipts on target hosts.
- Add cookies, signed sessions, form decoding, named routes, request-test helpers, and streaming conveniences.
- Add multipart/range/graceful-drain production work.
- Track stdlib HTTP/2, pooling, WebSocket, and server TLS capabilities without duplicating them here.
