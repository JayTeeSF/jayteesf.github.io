# Todo

- Add restoration/state descriptions.
- Add navigation reducer and deterministic test driver.
- Validate API against an unrelated mobile app.
- Add hey_android consumer before considering stdlib promotion.
