package hey.android.api;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * JSON requests to the baked origin, off the UI thread, answered on it. The
 * bearer header comes from the bundled session block. A 401 on a request that carried a token, other than
 * the session check itself, means signed out. Logcat names the method, path and
 * status only: never a token or a body.
 */
final class HeyAndroidHttp implements Actions.Transport {
  /** Set by the activity from the system's car mode; read on every request. */
  static volatile boolean driving = false;

  static final String TAG = "hey.api";

  interface Session {
    String token();

    Map<String, Object> description();

    void signedOut();
  }

  private final ExecutorService pool = Executors.newFixedThreadPool(3);
  private final Handler main = new Handler(Looper.getMainLooper());
  final String origin;
  private final Session session;
  private volatile int generation;
  private volatile boolean closed;

  /** Replies from an old account or a destroyed host must have no side effects. */
  void invalidate() { generation++; }

  void close() {
    closed = true;
    invalidate();
    pool.shutdownNow();
    main.removeCallbacksAndMessages(null);
  }

  HeyAndroidHttp(String origin, Session session) {
    this.origin = origin;
    this.session = session;
  }

  @Override
  public void send(Map<String, Object> route, Map<String, Object> vars, Object row, Actions.Reply reply) {
    String path = Values.fillPath(Values.string(route.get("path")), vars);
    String method = Values.string(route.get("method"));
    if (method.isEmpty()) method = "GET";
    Map<String, Object> body = Actions.body(route, vars, row);
    request(method, path, body, reply);
  }

  void request(String method, String path, Map<String, Object> body, Actions.Reply reply) {
    if (closed) return;
    Map<String, Object> sessionSpec = Json.dict(session.description().get("session"));
    String token = session.token();
    int started = generation;
    String header = Values.string(sessionSpec.get("header"));
    String prefix = Values.string(sessionSpec.get("prefix"));
    boolean isCheck = path.equals(Values.string(Json.dict(sessionSpec.get("check")).get("path")));
    pool.execute(() -> {
      int status = 0;
      Object json = null;
      String message = null;
      HttpURLConnection conn = null;
      try {
        if (started != generation) return;
        conn = (HttpURLConnection) new URL(origin + path).openConnection();
        conn.setInstanceFollowRedirects(false);
        conn.setConnectTimeout(20_000);
        conn.setReadTimeout(20_000);
        conn.setUseCaches(false);
        conn.setRequestMethod(method);
        conn.setRequestProperty("accept", "application/json");
        // A product-neutral hint for server-side semantic telemetry. This is
        // not authorization: the bearer still decides who may do anything.
        conn.setRequestProperty("x-my-queue-surface", Values.RENDERER_PLATFORM);
        // DRIVING (0.4.16): while the phone is in car mode (Android Auto), every
        // request says so, and the description decides what that changes.
        if (driving) conn.setRequestProperty("x-hey-driving", "1");
        if (token != null && !token.isEmpty() && !header.isEmpty()) conn.setRequestProperty(header, prefix + token);
        if (body != null) {
          byte[] bytes = Json.encodeBytes(body);
          conn.setDoOutput(true);
          conn.setRequestProperty("content-type", "application/json");
          conn.setFixedLengthStreamingMode(bytes.length);
          try (OutputStream out = conn.getOutputStream()) {
            out.write(bytes);
          }
        }
        status = conn.getResponseCode();
        byte[] answer = readAll(status >= 400 ? conn.getErrorStream() : conn.getInputStream());
        json = answer.length > 0 ? Json.parseOrNull(answer) : null;
        if (status >= 300) {
          message = Values.string(Json.dict(json).get("error"));
          if (message.isEmpty()) message = "The server answered " + status + ".";
        }
      } catch (IOException | RuntimeException e) {
        status = 0;
        message = "Could not reach the server.";
      } finally {
        if (conn != null) conn.disconnect();
      }
      Log.i(TAG, "request: " + method + " " + path + " -> " + status);
      final int s = status;
      final Object j = json;
      final String m = message;
      main.post(() -> {
        if (started != generation || !Objects.equals(token, session.token())) return;
        if (s == 401 && token != null && !token.isEmpty() && !isCheck) session.signedOut();
        if (started != generation || !Objects.equals(token, session.token())) return;
        reply.done(s, j, m);
      });
    });
  }

  static byte[] readAll(InputStream in) throws IOException {
    return readLimited(in, Integer.MAX_VALUE);
  }

  static byte[] readLimited(InputStream in, int limit) throws IOException {
    if (in == null) return new byte[0];
    try (InputStream stream = in) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buf = new byte[16384];
      int n;
      while ((n = stream.read(buf)) > 0) {
        out.write(buf, 0, n);
        if (out.size() >= limit) break;
      }
      return out.toByteArray();
    }
  }
}
