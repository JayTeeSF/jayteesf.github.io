# Changelog

## 0.1.1

- Adopt the current `hey-package.json` manifest schema.
- Place importable modules at the installed package root.
- Remove the obsolete package-owned checksum, ZIP, registry, and release tooling.
- Use `private import` and `private fn` for implementation-only API surface.
- Add pack/install/receipt/lock/import verification against Hey v0.99.198a.
