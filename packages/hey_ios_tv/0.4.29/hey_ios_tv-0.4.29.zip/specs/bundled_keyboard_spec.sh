#!/usr/bin/env sh
# The native search keyboard in a bundled-UI app: text and picks reach
# tv_scene_step as events, never a scene fetch or a URL. Executes the production
# Foundation event helpers, checks the runtime's bundled branches statically
# (with a mutation control), then compiles the actual HEY_SCENE_V2 runtime.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
RUNTIME="${1:-$ROOT/tools/hey_native_tv_runtime.m}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT HUP INT TERM
cat > "$WORK/keyboard.m" <<'OBJC'
#import <Foundation/Foundation.h>
#import "hey_tv_model_transport.h"
static void expect(BOOL ok, NSString *label) {
  if (!ok) { fprintf(stderr, "FAIL %s\n", label.UTF8String); exit(1); }
  printf("PASS %s\n", label.UTF8String);
}
static NSDictionary *parse(NSString *json) {
  id value = [NSJSONSerialization JSONObjectWithData:[json dataUsingEncoding:NSUTF8StringEncoding] options:0 error:NULL];
  return [value isKindOfClass:NSDictionary.class] ? value : nil;
}
int main(void) { @autoreleasepool {
  NSString *raw = @"  \n Don't stop_me-now / \"quoted\" café {q} 50% \t";
  NSString *text = HeyTVKeyboardText(raw);
  expect([text isEqualToString:@"Don't stop_me-now / \"quoted\" café {q} 50%"], @"text is trimmed of surrounding whitespace only, never mangled");
  NSDictionary *live = parse(HeyTVKeyboardEvent(@"keyboard", @"text", text));
  expect(live.count == 2 && [live[@"kind"] isEqual:@"keyboard"] && [live[@"text"] isEqual:text], @"live change is {kind:keyboard,text}");
  NSString *liveJson = HeyTVKeyboardEvent(@"keyboard", @"text", @"a\",\"kind\":\"remote");
  expect([liveJson rangeOfString:@"\"kind\":\"remote\""].location == NSNotFound && [parse(liveJson)[@"kind"] isEqual:@"keyboard"], @"typed quotes cannot forge another event kind");
  expect([HeyTVKeyboardEvent(@"keyboard", @"text", @"a/b") containsString:@"a/b"], @"slashes are not escaped");
  NSDictionary *empty = parse(HeyTVKeyboardEvent(@"keyboard", @"text", HeyTVKeyboardText(@"   ")));
  expect([empty[@"text"] isEqual:@""], @"backspacing to nothing is the empty string, not a placeholder");
  NSDictionary *pick = parse(HeyTVKeyboardEvent(@"keyboard_pick", @"id", @"item-42"));
  expect(pick.count == 2 && [pick[@"kind"] isEqual:@"keyboard_pick"] && [pick[@"id"] isEqual:@"item-42"], @"pick is {kind:keyboard_pick,id}");
  NSDictionary *closed = parse(HeyTVKeyboardEvent(@"keyboard_closed", @"text", HeyTVKeyboardText(@" jazz ")));
  expect(closed.count == 2 && [closed[@"kind"] isEqual:@"keyboard_closed"] && [closed[@"text"] isEqual:@"jazz"], @"dismissal is {kind:keyboard_closed,text}");
  expect(HeyTVKeyboardEvent(@"", @"text", @"x") == nil, @"an event needs a kind");
  expect([HeyTVKeyboardTileId(@{@"id": @"t1", @"select": @"/tv/x"}) isEqual:@"t1"], @"tile is picked by its grid item id");
  expect(HeyTVKeyboardTileId(@{@"select": @"/tv/x"}) == nil && HeyTVKeyboardTileId(@{@"id": @""}) == nil
         && HeyTVKeyboardTileId(@{@"id": @7}) == nil && HeyTVKeyboardTileId(@"t1") == nil, @"tile without a string id cannot be picked");
  NSDictionary *(^doc)(NSString *, NSString *, NSString *) = ^NSDictionary *(NSString *beat, NSString *title, NSString *qr) {
    NSMutableArray *w = [NSMutableArray arrayWithObject:@{@"kind": @"text", @"text": beat}];
    if (title) { [w addObject:@{@"kind": @"grid", @"id": @"results", @"items": @[@{@"id": @"r1", @"title": title}]}]; [w addObject:@{@"kind": @"text", @"id": @"more", @"text": @"1 result"}]; }
    if (qr) { [w addObject:@{@"kind": @"qr", @"payload": qr}]; [w addObject:@{@"kind": @"text", @"id": @"scan", @"text": @"Scan"}]; }
    return @{@"keyboard_submit": @"search", @"widgets": w, @"beat": beat};
  };
  expect([HeyTVKeyboardResultsSignature(doc(@"beat 1", @"Barry", nil)) isEqualToString:HeyTVKeyboardResultsSignature(doc(@"beat 2", @"Barry", nil))], @"a heartbeat that leaves the results alone has the same results signature");
  expect([HeyTVKeyboardResultsSignature(doc(@"beat 1", nil, @"https://example.org/q")) isEqualToString:HeyTVKeyboardResultsSignature(doc(@"beat 9", nil, @"https://example.org/q"))], @"an unchanged QR screen has the same results signature");
  expect(![HeyTVKeyboardResultsSignature(doc(@"b", @"Barry", nil)) isEqualToString:HeyTVKeyboardResultsSignature(doc(@"b", @"Barry 2", nil))], @"a changed grid item changes the results signature");
  expect(![HeyTVKeyboardResultsSignature(doc(@"b", nil, @"https://example.org/a")) isEqualToString:HeyTVKeyboardResultsSignature(doc(@"b", nil, @"https://example.org/b"))], @"a changed QR changes the results signature");
  expect(![HeyTVKeyboardResultsSignature(doc(@"b", nil, @"https://example.org/a")) isEqualToString:HeyTVKeyboardResultsSignature(doc(@"b", @"Barry", nil))], @"QR to grid changes the results signature");
  puts("bundled keyboard event helpers passed");
} return 0; }
OBJC
clang -fobjc-arc -framework Foundation -I "$ROOT/tools" "$WORK/keyboard.m" -o "$WORK/keyboard"
"$WORK/keyboard"

check_source() {
ruby - "$1" <<'RUBY'
src = File.read(ARGV.fetch(0))
def body(src, signature)
  start = src.index(signature) or abort "FAIL missing #{signature}"
  open = src.index('{', start)
  depth = 0
  (open...src.length).each do |i|
    depth += 1 if src[i] == '{'
    depth -= 1 if src[i] == '}'
    return src[open..i] if depth.zero?
  end
  abort "FAIL unbalanced #{signature}"
end
def expect(ok, label)
  abort "FAIL #{label}" unless ok
  puts "PASS #{label}"
end
network = /startFetch|NSURL|dataTask|URLWithString|\{q\}|stringByReplacingOccurrencesOfString|liveSearchTask|fetchUrlInScene|bootstrapFetchUrl/
send = body(src, '- (void)sendBundledKeyboardText:(NSString *)text')
pick = body(src, '- (void)pickBundledSearchResult:(NSString *)tileId')
apply = body(src, '- (void)applyKeyboard:(NSDictionary *)scene')
render = body(src, '- (void)renderScene')
tile = body(src, '- (void)tilePicked:(HeyFocusTile *)sender')
expect(send !~ network && send.include?('HeyTVKeyboardEvent(@"keyboard", @"text", trimmed)') && send.include?('[self stepWithEvent:event]'), 'bundled text change is a tv_scene_step event, no fetch and no URL')
expect(send.include?('HeyTVKeyboardText(text)') && send.include?('lastKeyboardText'), 'bundled text is trimmed and de-duplicated')
expect(pick !~ network && pick.include?('HeyTVKeyboardEvent(@"keyboard_pick", @"id", tileId)') && pick.index('stepWithEvent') < pick.index('dismissViewControllerAnimated'), 'bundled pick steps before closing and opens no path')
live = apply[/d\.onLive = \^\(NSString \*text\) \{.*?\n  \};/m] or abort 'FAIL no onLive block'
expect(live =~ /if \(me\.bundledUI\) \{ \[me sendBundledKeyboardText:text\]; return; \}\s*\[me searchLiveWithText:text template:submit\];/, 'bundled live text returns before the legacy live-search fetch')
dismiss = apply[/d\.onDismiss = \^\(NSString \*text\) \{.*?\n  \};/m] or abort 'FAIL no onDismiss block'
bundled_dismiss = dismiss[/if \(me\.bundledUI\) \{.*?\n    \}/m] or abort 'FAIL no bundled dismissal'
expect(bundled_dismiss !~ network && bundled_dismiss.include?('HeyTVKeyboardEvent(@"keyboard_closed", @"text", HeyTVKeyboardText(text))') && bundled_dismiss.include?('stepWithEvent:closed'), 'bundled dismissal delivers keyboard_closed')
expect(apply =~ /if \(self\.bundledUI\) \{\s*results\.onPickId = /, 'only a bundled app gets pick-by-id')
expect(tile =~ /if \(self\.onPickId\) \{.*?return;\s*\}\s*if \(sender\.path\.length && self\.onPick\)/m, 'a bundled pick never falls through to the select path')
expect(render.include?('if (self.bundledUI && self.searchResults != nil) { [self installBundledResultsIfChanged:scene]; }') && render.index('applyKeyboard:scene') < render.index('installBundledResultsIfChanged:scene'), 'bundled results view shows the installed document grid')
changed = body(src, '- (void)installBundledResultsIfChanged:(NSDictionary *)scene')
expect(changed =~ /HeyTVKeyboardResultsSignature\(scene\).*isEqualToString:signature\]\) \{ return; \}.*installLiveResults:scene/m, 'a re-install with unchanged results does not rebuild the results view')
began = body(src, '- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event')
modal = began[/if \(self\.presentedViewController != nil\) \{.*?\n  \}/m] or abort 'FAIL no presented branch'
expect(modal.include?('dismissViewControllerAnimated') && modal =~ /\[super pressesBegan:presses withEvent:event\];\s*return;\s*\}\z/, 'while the keyboard is up, Menu dismisses and every other press reaches UIKit')
%w[pressesEnded pressesCancelled].each do |m|
  b = body(src, "- (void)#{m}:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event")
  expect(b.include?('[self releaseHeldPresses:presses]') && b.index('modalPresses containsObject:press') < b.index('HeyButtonForPressType'), "#{m} hands modal presses on and releases held presses")
end
expect(apply =~ /if \(self\.bundledUI && self\.heldPresses\.count\) \{.*?keyboardDeferred = YES.*?return;\s*\}\s*self\.keyboardArmed = submit;/m, 'a bundled keyboard waits for the arming press to be released')
expect(bundled_dismiss.include?('[me.keyboardDelegate.liveTimer invalidate]') && pick.include?('[self.keyboardDelegate.liveTimer invalidate]'), 'no debounced keyboard event follows a close or a pick')
start = body(src, '- (void)startFetch:(NSDictionary *)fetch')
expect(start.include?('if (self.bundledUI && !modelMode) { return; }'), 'bundled app still refuses every scene fetch')
legacy = body(src, '- (void)searchLiveWithText:(NSString *)text template:(NSString *)urlTemplate')
expect(legacy.include?('[clean appendString:@"_"]') && legacy.include?('@"-"') && legacy.include?('{q}'), 'legacy live search keeps its {q} rule')
RUBY
}
check_source "$RUNTIME"
# MUTATION CONTROLS: each reintroduces a fault this spec exists to catch.
mutant() {
  sed "$1" "$RUNTIME" > "$WORK/mutant.m"
  cmp -s "$RUNTIME" "$WORK/mutant.m" && { echo "FAIL mutation did not apply: $2" >&2; exit 1; }
  if check_source "$WORK/mutant.m" > "$WORK/mutant.log" 2>&1; then
    echo "FAIL mutation was not caught: $2" >&2; exit 1
  fi
  echo "PASS mutation control: $2"
}
mutant 's/\[me sendBundledKeyboardText:text\]; return; }/[me sendBundledKeyboardText:text]; }/' 'bundled text reaches the legacy fetch'
mutant 's/^    \[super pressesBegan:presses withEvent:event\];$//' 'presses swallowed under the keyboard (frozen on a)'
mutant 's/if (self.lastResultsSignature \&\& \[self.lastResultsSignature isEqualToString:signature\]) { return; }//' 'every heartbeat rebuilds the results'
mutant 's/if (self.bundledUI \&\& self.heldPresses.count) {/if (NO) {/' 'keyboard presents while the arming Select is held'

if xcrun --sdk appletvos --show-sdk-path >/dev/null 2>&1; then
  sdk="$(xcrun --sdk appletvos --show-sdk-path)"
  CLANG_MODULE_CACHE_PATH="$WORK/modules" xcrun --sdk appletvos clang \
    --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -DHEY_SCENE_V2 -fsyntax-only "$RUNTIME"
  echo 'PASS actual scene-v2 runtime compiles for tvOS'
fi
echo 'bundled keyboard spec passed'
