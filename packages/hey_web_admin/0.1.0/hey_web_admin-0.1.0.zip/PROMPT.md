# Continuation prompt

`hey_web_admin` scaffolds CRUD admin screens for `hey_web` apps.

Any change must keep ALL of these true, together, in one commit:

1. `VERSION`, `hey-package.json`'s `version`, and `HeyAdmin.version()`
   in `main.hey` all agree. `bin/check` greps for this.
2. `bin/check` green (interpreter) AND `bin/check-compiled` green
   (compiled, byte-identical lane agreement). **An interpreted green is
   not a green** — this package has hit three compiled-only defects,
   every one producing plausible output rather than an error.
3. `tools/red-check` reports zero holes. New behaviour needs a new
   mutation proving its gate can go red.
4. `README.md`'s Limits list still tells the truth, and `docs/*.md` and
   `docs/examples/basic.hey` still run and still describe what ships.
5. `specs/generic_cagents_spec.hey` still passes and still leaves
   `~/dev/generic_cagents` unmodified. That tree is READ-ONLY.

Two things are not negotiable at any version:

- **Escape by default.** Every record value reaches a page through
  `HeyAdminEscape`. A new screen needs a new `<script>`-payload
  assertion.
- **The admin refuses to mount unguarded.** No default that serves
  records without an `authorize` callback, ever. `HEY_ADMIN_INSECURE=1`
  is the only way past it and it stays loud.

Never add a helper that can return `nil` — `heyc build` refuses to lower
locals initialised from one, and the interpreter will not tell you.
