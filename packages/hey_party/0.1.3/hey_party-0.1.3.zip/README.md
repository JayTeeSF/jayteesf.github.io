# hey_party

> **RETIRED, 2026-09-19.** Unlisted from the package registry; the published
> archives stay on disk so nothing already fetched is invalidated, and re-adding
> the index entries would bring it back.
>
> Nothing depends on it. recall_coach_app evaluated it and decided against it on the record (docs/agents/research/tv-stack.md): it pins hey_tv 0.1.0 exactly where hey_ios_tv pins 0.2.x, so no project can lock both, and it carries a broken hey_web 0.1.6 pin. That app copied Lobby.hey, RoomProtocol.hey and GameKernel.hey in instead -- which is what this package's own `hey party init` scaffolder does anyway.

Authoritative party rooms, mobile controllers, lobbies, and deterministic multiplayer games.

This is an independently versioned third-party Hey package. It is not part
of Hey core or the standard library.

## Package boundary

See `docs/DESIGN.md`. The package consumes current published dependencies
from `https://www.jayteesf.com/packages/` and delegates release/source ZIP/
publication controls to `hey_packager`.

## Development

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
```

## Release and publish

```sh
bin/release
bin/source-zip
bin/publish --no-commit
```

Existing immutable versions must never be replaced.

## Build and release tooling

`hey_packager` is declared in `dependencies` as `">=0.1.1 <0.2.0"`, so it appears
in an application's lock; no module imports it. It provides `bin/check`,
`bin/bump`, `bin/release` (builds the release, does not publish) and
`bin/publish` (commits `packages/NAME/VERSION` to
`~/dev/jayteesf.github.io/packages`; never overwrites, never pushes).
`bin/package-zip` and `bin/source-zip` also run through it.
