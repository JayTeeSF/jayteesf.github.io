# Todo

- Package the LocalAuthentication half of the session adapter (the Keychain half is `native/HeyIOSKeychain`, 0.2.0).
- Package protected atomic files and QR scanner adapters.
- Add signed device integration receipts from two unrelated apps.
