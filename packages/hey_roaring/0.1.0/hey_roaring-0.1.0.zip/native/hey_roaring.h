#pragma once
#include "hey_native_abi.h"
HeyNativeHandle hey_roaring_new(void);
int32_t hey_roaring_free(HeyNativeHandle bitmap);
int32_t hey_roaring_add(HeyNativeHandle bitmap, uint32_t value);
int32_t hey_roaring_add_many(HeyNativeHandle bitmap, HeyNativeBytesView values);
int32_t hey_roaring_add_range(HeyNativeHandle bitmap, uint64_t first, uint64_t end);
int32_t hey_roaring_remove(HeyNativeHandle bitmap, uint32_t value);
int32_t hey_roaring_contains(HeyNativeHandle bitmap, uint32_t value);
uint64_t hey_roaring_cardinality(HeyNativeHandle bitmap);
HeyNativeHandle hey_roaring_union(HeyNativeHandle left, HeyNativeHandle right);
HeyNativeHandle hey_roaring_intersection(HeyNativeHandle left, HeyNativeHandle right);
uint64_t hey_roaring_intersection_cardinality(HeyNativeHandle left, HeyNativeHandle right);
int32_t hey_roaring_optimize(HeyNativeHandle bitmap);
HeyNativeOwnedBytes hey_roaring_serialize(HeyNativeHandle bitmap, uint64_t max_bytes);
HeyNativeHandle hey_roaring_deserialize(HeyNativeBytesView data);
HeyNativeOwnedBytes hey_roaring_values(HeyNativeHandle bitmap, uint64_t offset, uint32_t limit);
