# hey_sqlite3 0.1.0

SQLite adapter descriptors for `hey_record`.

```hey
import 'pkg:hey_sqlite3@0.1.0/main'

let db = Sqlite3.connect('db/app.sqlite3', {
  timeout_ms: 5000,
  readonly: false
})
```

The first release executes the native `sqlite3` executable with direct argv, never a shell, and requests JSON row output. It supports query/execute callables and transactions through `hey_record`. It does not yet provide prepared statements, a persistent connection, or native FFI. Do not use `:memory:` for multi-call workflows because each CLI invocation is a separate process.

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```
