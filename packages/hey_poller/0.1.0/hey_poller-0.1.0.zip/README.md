# hey_poller

One batched TCP event-loop API for Hey servers on every OS. `Poller.open`
picks the fastest native readiness mechanism of the system the program runs on
and the rest of the program never knows which one it got:

| `Env.os()` | backend | package |
|---|---|---|
| `Linux` | epoll | [hey_epoll](https://www.jayteesf.com/packages/hey_epoll/) 0.1.1 |
| `Darwin`, `FreeBSD`, `OpenBSD`, `NetBSD`, `DragonFly` | kqueue | [hey_kqueue](https://www.jayteesf.com/packages/hey_kqueue/) 0.1.1 |
| `Windows`, `Windows_NT` | I/O completion ports | [hey_iocp](https://www.jayteesf.com/packages/hey_iocp/) 0.0.1 — **EXPERIMENTAL, never run** |
| anything else | none: `open()` fails with `poller_unsupported_os` | |

The API is hey_epoll's: one native call waits for readiness, accepts every
pending connection and reads every readable socket; the program takes each
connection's unconsumed input as text, parses its protocol in Hey, and hands
back a reply plus the number of bytes it consumed.

## Depend on it

```json
"dependencies": {
  "hey_poller": "0.1.0"
}
```

```sh
hey package ensure --project . --update-lock
# build the ONE native library this OS needs (hey_epoll on Linux, hey_kqueue on macOS)
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" .hey/packages/hey_poller/0.1.0/bin/build-native --project .
```

```hey
import 'pkg:hey_poller@0.1.0/poller'

program
  let loop = Poller.open('0.0.0.0', 8080, {backlog: 4096}).value
  says "serving on #{Poller.backend()}"          # epoll / kqueue / iocp
  while true
    let ready = Poller.wait(loop, 1000)
    let id = Poller.next(loop)
    while id >= 0
      let text = Poller.data(loop, id)           # every unconsumed byte so far
      # ... frame one request of `used` bytes, build `reply` ...
      let sent = Poller.send(loop, id, used, reply, false)
      set id = Poller.next(loop)
    end
  end
end
```

The program runs from the project root (where `.hey/native/...` is), or the
backend's library is named with `HEY_EPOLL_LIBRARY` / `HEY_KQUEUE_LIBRARY` /
`HEY_IOCP_LIBRARY` or `{library_path: ...}`.

| Call | What it does |
|---|---|
| `Poller.version()` | This package's version. |
| `Poller.backend_for(os)` | The selection rule as a pure function: `'epoll'`, `'kqueue'`, `'iocp'` or `''`. |
| `Poller.backend()` | The backend this program uses: `HEY_POLLER_BACKEND` if set, else `backend_for(Env.os())`. |
| `Poller.open(host, port, options)` | Opens a loop on that backend (`options.backend` overrides). `backlog`, `reuseport`, `library_path` go to the backend. Result value: `{kind, backend, inner, extension, handle, host, port}`. |
| `Poller.wait/next/data/send/drop/stats` | As hey_epoll's `Epoll`, called straight on the loaded extension. `stats().backend` names the backend too. |
| `Poller.close(loop)` | Closes through the backend's own `close`. |

## How the choice is made

Hey has no compile-time OS selection and no per-OS dependencies (imports are
static; every imported module compiles on every target). So hey_poller depends
on all three backends and imports their Hey porcelain (a few hundred lines of
Hey), and chooses at `open()` from `Env.os()`. What is per-OS is the native
side: `bin/build-native` builds only the selected backend's library and
`open()` loads only that one. The three backends declare one native function
table (same names, same argument and return types), so after `open()` every
serving call goes straight to the loaded extension: hey_poller adds no
per-call dispatch. Measured, it is as fast as calling the backend directly
(see [docs/DESIGN.md](docs/DESIGN.md)).

## Measured

| | requests/s | server CPU | req per CPU-second |
|---|---|---|---|
| macOS (M3 Pro), Poller → kqueue | 177k-178k | 1.0 core | 178k |
| macOS, `Kqueue` directly | 177k | 1.0 core | 177k |
| macOS, stdlib `Web.serve` | 186k-190k | 4.3-4.5 cores | 43k |
| Linux container (amd64 under Rosetta), Poller → epoll | 120k-123k | 1.0 core | 120k-123k |
| same container, `Epoll` directly | 80k-81k | 1.0 core | 80k-81k |
| same container, stdlib `Web.serve` | 56k-58k | 7.6-7.7 cores | 7.6k |

wrk, 4 threads, 64 keep-alive connections, client on the same machine. The
Linux numbers are from an emulated amd64 container and only compare the rows
with each other.

## Check

```sh
hey package ensure --project . --locked
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check     # this host
bin/linux-check                                              # Linux container: epoll
bench/compare                                                # wrk comparison
```
