package hey.android.api;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Served, stored, baked (hey_mobile docs/RENDERERS.md): which description a
 * renderer takes, and which keys only ever come from the baked copy. Pure Java:
 * conformance/descriptions.json runs against refusal() on the Mac.
 */
public final class Descriptions {
  private Descriptions() {}

  public static final String SCHEMA = "hey-mobile-api-app-v1";
  public static final int MAX_BYTES = 2_000_000;

  public static String sha256Hex(byte[] data) {
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      byte[] digest = md.digest(data == null ? new byte[0] : data);
      StringBuilder hex = new StringBuilder();
      for (byte b : digest) hex.append(String.format("%02x", b & 0xff));
      return hex.toString();
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("SHA-256 is missing", e);
    }
  }

  /** The SHA-256 an ETag header names ("<hex>" or W/"<hex>"), lower case; null when it names none. */
  static String etagHash(String header) {
    String s = header.trim();
    if (s.startsWith("W/")) s = s.substring(2);
    while (s.startsWith("\"")) s = s.substring(1);
    while (s.endsWith("\"")) s = s.substring(0, s.length() - 1);
    if (s.length() != 64) return null;
    for (int i = 0; i < s.length(); i++) {
      if (Character.digit(s.charAt(i), 16) < 0) return null;
    }
    return s.toLowerCase();
  }

  /** Why a renderer on `platform` at `level` refuses this body; null when it takes it. */
  public static String refusal(byte[] body, String etagHeader, String platform, int level) {
    if (body == null) body = new byte[0];
    if (body.length > MAX_BYTES) return "too_large";
    String claimed = etagHeader != null && !etagHeader.isEmpty() ? etagHash(etagHeader) : null;
    if (claimed != null && !claimed.equals(sha256Hex(body))) return "etag";
    Object json = body.length > 0 ? Json.parseOrNull(body) : null;
    if (json == null) return "not_json";
    if (!(json instanceof Map)) return "not_object";
    Map<String, Object> d = Json.dict(json);
    if (!(d.get("schema") instanceof String) || !SCHEMA.equals(d.get("schema"))) return "schema";
    Object lv = d.get("level");
    if (!(lv instanceof Number)) return "level";
    double ld = ((Number) lv).doubleValue();
    if (ld != Math.floor(ld) || ld < 1 || ld > level) return "level";
    if (!(d.get("platform") instanceof String) || !platform.equals(d.get("platform"))) return "platform";
    if (!(d.get("screens") instanceof List) || Json.list(d.get("screens")).isEmpty()) return "screens";
    Map<String, Map<String, Object>> byId = new HashMap<>();
    for (Object screen : Json.list(d.get("screens"))) {
      if (!(screen instanceof Map)) return "screens";
      Map<String, Object> s = Json.dict(screen);
      if (!(s.get("id") instanceof String) || !(s.get("type") instanceof String)) return "screens";
      byId.put((String) s.get("id"), s);
    }
    if (!(d.get("tabs") instanceof List)) return "tabs";
    boolean anyDrawn = false;
    for (Object tab : Json.list(d.get("tabs"))) {
      Map<String, Object> screen = tab instanceof String ? byId.get(tab) : null;
      if (screen == null) return "tabs";
      if (Values.known("screen", screen, level)) anyDrawn = true;
    }
    if (!anyDrawn) return "tabs";
    Map<String, Object> signIn = byId.get(Values.string(Json.dict(d.get("session")).get("sign_in_screen")));
    if (signIn == null || !Values.known("screen", signIn, level)) return "sign_in";
    return null;
  }

  /** The renderer's own refusal: android, RENDERER_LEVEL. */
  public static String refusal(byte[] body, String etagHeader) {
    return refusal(body, etagHeader, Values.RENDERER_PLATFORM, Values.RENDERER_LEVEL);
  }

  public static final class Pick {
    public final byte[] bytes;
    public final String source;

    Pick(byte[] bytes, String source) {
      this.bytes = bytes;
      this.source = source;
    }
  }

  /** A served copy this renderer takes, else a stored one it takes, else the baked copy. */
  public static Pick pick(byte[] baked, byte[] stored, byte[] served, String servedEtag, String platform, int level) {
    if (served != null && refusal(served, servedEtag, platform, level) == null) return new Pick(served, "served");
    if (stored != null && refusal(stored, null, platform, level) == null) return new Pick(stored, "stored");
    return new Pick(baked, "baked");
  }

  /**
   * A served or stored description with every key that must stay baked put
   * back from the baked copy: the origin is never read from it, and neither are
   * the secure-store name, url_scheme, served, or session.header, prefix, check
   * and sign_out. A served description can change screens; it cannot send the
   * session anywhere else.
   */
  public static Map<String, Object> merged(Map<String, Object> served, Map<String, Object> baked) {
    Map<String, Object> out = new LinkedHashMap<>(served);
    out.remove("origin");
    for (String key : new String[] {"keychain_service", "secure_store", "url_scheme", "served", "find_fixture"}) {
      if (baked.containsKey(key)) out.put(key, baked.get(key));
      else out.remove(key);
    }
    Map<String, Object> session = new LinkedHashMap<>(Json.dict(served.get("session")));
    Map<String, Object> bakedSession = Json.dict(baked.get("session"));
    for (String key : new String[] {"header", "prefix", "check", "sign_out"}) {
      if (bakedSession.containsKey(key)) session.put(key, bakedSession.get(key));
      else session.remove(key);
    }
    out.put("session", session);
    return out;
  }
}
