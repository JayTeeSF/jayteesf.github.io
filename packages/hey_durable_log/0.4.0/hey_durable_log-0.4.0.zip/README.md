# hey_durable_log

`hey_durable_log` is the crash-safe mutation journal being built for the
cagents v2 server. It keeps accepted mutations hot in memory at the service
layer while making acknowledgement depend on a small append-only durable
record, not on SQLite page updates.

`main` carries the implementation. It was landed from `main_v2` once the
readiness gates below were green on both platforms — not because it compiled —
and the gaps that remain are named in "Where this stands" rather than left to be
discovered.

The intended write path, which is what every guarantee below is about:

```text
authenticated Cagents mutations
        |
bounded in-memory queue (fast admission + backpressure)
        |
one ordered reducer per journal partition
        |
checksummed DATA frames + batch COMMIT
        |
durability barrier, then the receipt returned to the caller
        |
optional quorum replication before the caller is told yes
```

**Two breaking changes landed with this branch**, taken while 0.2.0 was the only
released version and nothing existed in the field:

- **Format v2.** Frame headers are 56 bytes and every frame names the log-global
  position it was written for. A v1 journal is not readable by this version, and
  a v2 build refuses one rather than misreading it.
- **A journal is a DIRECTORY**, not a file. An existing regular file at the
  journal path is refused rather than reinterpreted.

There is no conversion path from v1 and none is owed; see
[docs/FORMAT.md](docs/FORMAT.md).

## Current guarantees

- `hdl_append_batch` serializes concurrent callers and returns only after the
  DATA frames, the COMMIT frame, and a durability barrier that flushes the
  storage device's cache all complete. The barrier is `fdatasync` on Linux and
  `fcntl(F_FULLFSYNC)` on Darwin, where `fdatasync` only reaches the drive and
  not the platters; `hdl_sync_barrier_name()` reports which one this build
  issues, and the gate asserts it per platform. There is no silent fallback to
  a weaker barrier.
- `hdl_broker_submit` feeds a bounded in-memory queue whose single writer
  combines concurrent requests into one durable batch and applies
  backpressure when the queue is full. A submitter can bound how long it waits to
  be **admitted** -- `hdl_broker_submit_within`, `DurableLog.append_within` --
  and a submission refused that way was never accepted and is not in the log.
  The bound covers admission only: once a record is in a batch on its way to a
  barrier it may already be durable, so reporting it as refused would be a lie.
  `DurableLog.stats` reports what that actually cost -- records, durable batches, largest batch, and the queue's
  high-water mark -- as one snapshot, so "the queue is bounded" is a claim a
  Hey consumer can check rather than take on faith.
- Recovery publishes only batches with a complete, checksummed COMMIT frame.
- A physically short final frame or an uncommitted valid tail is truncated to
  the last committed boundary.
- A checksum failure in a complete frame fails closed as corruption.
- **One writer owns a journal.** `hdl_open` takes an exclusive advisory lock
  before recovery -- before it can truncate anything -- and a second opener is
  refused as `HDL_LOCKED` (`durable_log_open_locked` from Hey) rather than being
  handed a handle that would acknowledge the same sequence twice. The kernel
  releases the lock when the owner closes or dies, so a crash never leaves a
  journal nobody can open.
- A journal is a directory of segments, each named for its index and its base
  position in the log. A segment is published by a single `rename` after its
  bytes are synced, so a segment that recovery can see is a segment whose
  contents are already durable.
- Snapshots, restores and retirement are reachable from Hey, on the connection
  itself, because the exclusive writer lock means the owning process is the only
  one that can do them to a live journal.
- A snapshot is a journal, so it is verified by the code that validates a
  journal: read back, replayed, and compared against its own receipt. Segments
  are retired only against a snapshot that verified, and the retirement is
  recorded durably before anything is deleted.
- The active segment is cut when it reaches its size bound, always between two
  batches. The frame chain, the sequence and the batch numbering carry across
  the seam, each segment begins exactly where the last one ended, and recovery
  checks that rather than assuming it.
- A newly created segment is synchronized before it can accept a batch.
- Every frame names the log-global position it was written for, inside its own
  checksum, and recovery replays a frame only where that name matches. A
  complete, correctly-checksummed frame that belongs to another place in the
  log -- the previous life of a reused file, or a copy spliced in -- is
  corruption and fails closed, rather than being replayed as committed data.
- Each replay cursor snapshots the last validated COMMIT boundary, streams one
  record at a time, and never observes a half-written concurrent batch. It can
  resume from a position it was given -- every record says where the next one
  starts -- so a materializer catching up does not re-read what it has already
  applied, and a position that is not a frame boundary is refused rather than
  resynchronised.

These are local-disk guarantees: they hold across process crash, OS crash and
power loss on this host. Surviving loss of the host or the disk itself requires
quorum replication before acknowledgement. `cluster.hey` provides that as an
opt-in layer over Distributed Hey — a receipt then reads `quorum_durable` rather
than `local_durable`. A follower accepts only the record that CONTINUES its own
log, reports what it is missing when it cannot, and treats a retried record as
already applied rather than appending it twice; a leader can then send exactly
the gap.

Replication now runs against **real peers**: `bin/check-cluster` starts three
separate processes in three containers with real sockets between them, and then
reads each follower's own bytes rather than believing the leader's report. It
asserts that a reachable majority confirms, that two of three is still a
majority, that a minority is refused by name, that each follower holds exactly
the records it acknowledged, that a follower which fell behind is HEALED from
the position it reported, and that all three nodes then replay the identical
committed prefix — record for record, not by length.

It also runs a real hand-off: the leader is stopped, a follower campaigns for a
new term, a surviving majority grants it, the new leader writes at its own term,
and the old leader — restarted still believing it leads — is **fenced**, because
every node enforces the term it durably recorded rather than the one it was
started with. A vote is written and synced before it is answered, so a node
cannot grant the same term twice after a restart.

Two things are still NOT proved, and therefore still not claimed:

- **A fenced leader's log diverges, and nothing reconciles it.** Fencing stops a
  stale leader from acknowledging, which is the durability promise; it does not
  undo the record that leader already wrote locally before replication refused
  it. Rejoining that node as a follower today would splice two histories,
  because a frame carries no term to check a predecessor against. The cluster
  gate asserts the divergence rather than hiding it.
- **Partition, as opposed to a stopped container.** This gate kills processes;
  a partitioned-but-alive node is the observationally identical case, not the
  same case.

Until those exist, do not read this as surviving host loss.

## Is it faster than SQLite?

That is the whole reason this exists, so it is measured rather than asserted.
On Linux, both engines using the same `fdatasync` barrier:

| Writers | SQLite | This journal | Ratio |
|---:|---:|---:|---:|
| 1 | 1,630/s | 1,279/s | **0.78×** |
| 4 | 1,061/s | 3,484/s | **3.28×** |
| 8 | 944/s | 7,628/s | **8.08×** |
| 32 | 797/s | 24,305/s | **30.51×** |

SQLite gets *slower* as writers arrive, because a WAL writer holds the exclusive
write lock across its `fdatasync`. At 32 writers its p99 is 532 ms against this
journal's 2.5 ms. **At one writer SQLite wins** — there is no batch to amortise,
and if your workload has a single writer this package is a cost, not a benefit.

Method and limits: [docs/BENCHMARK-2026-09-04-linux-vs-sqlite.md](docs/BENCHMARK-2026-09-04-linux-vs-sqlite.md).

## Platforms

Darwin and Linux do not agree on what "sync" means, so they do not share a
primitive. On Darwin `fsync` costs 0.045 ms and is not power-safe, `F_BARRIERFSYNC`
0.239 ms and orders without flushing, and only `F_FULLFSYNC` (4.020 ms) flushes
the device. On Linux `fdatasync` is the real barrier and costs 0.514 ms. This
package issues the correct one per platform, asserts which it issued, and never
falls back to a weaker one.

Linux is gated separately, because a green gate on Darwin proves nothing about a
platform that uses a different primitive:

```sh
bin/check-linux
```

## Where this stands

The C, native-adapter and Hey gates pass on Darwin and on Linux
(`bin/check-linux`), the real-filesystem exhaustion gate passes on both
(`bin/check-enospc`), and the three-node cluster gate passes against real peers
(`bin/check-cluster`). Supply a current `hey-lang-bootstrap-plan` checkout
through `HEY_ROOT` and run `bin/check`.

Built and gated, each one test-first, each gate proved red before it was trusted:

1. atomically published segment rotation, with the writer killed at every step
   of the cut, and a failed-barrier gate for the half a `SIGKILL` cannot reach;
2. a backpressure soak, bounded admission with a typed refusal, and filesystem
   exhaustion on a real full filesystem;
3. verified snapshots, restore, and retirement that records the seam before it
   deletes anything;
4. replay lag measured end to end, with the expectations written down first —
   one of them was missed, and fixing it took both a resumable cursor and an
   O(1) cursor open;
5. quorum replication against real peers: majority confirms, minority refuses,
   a lagging follower is healed from what it reported, a new leader is elected
   by a real majority, and the leader it replaced is fenced.

Not done, and therefore not claimed:

- **reconciling a fenced leader's divergent tail.** Fencing stops a stale leader
  acknowledging; it does not undo the record that leader already wrote locally,
  and rejoining it today would splice two histories. The cluster gate asserts
  the divergence so it cannot be forgotten.
- **partition as distinct from a stopped process**, and any behaviour that needs
  a live-but-unreachable node.
- **representative-hardware numbers.** Every measurement here is a laptop or a
  container on one.

Record each passing checkpoint in
`JayTeeSF/cagents@main_v2/projects/cagents/tasks/durable-mutation-journal`.
Do not integrate this package as cagents authority until the gaps above are
either closed or accepted in writing by the consumer.

Non-negotiable rules: never acknowledge RAM alone; never skip a complete
corrupt frame; truncate only a partial/uncommitted tail; preserve ambiguous
post-COMMIT responses through application idempotency; keep queues bounded;
and never make SQLite or Git the hidden acknowledgement boundary.

## Check

`bin/check` is the shared `hey_packager` validation — manifest, `VERSION`, every
declared file, required documentation, the archive-entry pre-flight, and the
executable documentation example — followed by this package's own gate:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" bin/check
```

The package-specific portion is available directly as `bin/package-check`. It
runs the version drift guard, `make clean check`, `bin/check-enospc` -- which
mounts a small real filesystem, fills it, and runs the journal into the wall --
and `bin/check-hey`. The C
core alone, without a Hey toolchain, is `make clean check`.

To validate only the generated dispatcher plus both the interpreter and
stage0-compiled receipts:

```sh
HEY_ROOT=/path/to/hey-lang-bootstrap-plan bin/check-hey
```

The gates compile with strict warnings, run append/scan recovery tests, truncate
a two-batch journal at every byte boundary, verify corruption is not silently
discarded, reject valid frames that belong elsewhere in the log, inject
short-write and failed-sync errors, exercise real `SIGKILL` at write/sync/receipt
boundaries and at every step of a segment cut, exercise concurrent append
callers, and prove the broker uses fewer durable batches than records.

See [docs/FORMAT.md](docs/FORMAT.md) for the v2 byte format and recovery rules,
and [docs/TESTING.md](docs/TESTING.md) for the full gate description. The first
packaged-core measurements are in
[docs/BENCHMARK-2026-09-04.md](docs/BENCHMARK-2026-09-04.md).

For a local concurrency measurement (writers, operations per writer, maximum
batch, and batch window in microseconds):

```sh
bin/benchmark 8 250 64 250
```

For replay lag — submit to observed, end to end, including the batch window, the
durability barrier and the cursor cadence a materializer actually pays:

```sh
bin/benchmark-replay-lag 8 200 64 250 256
```

Measured results and the expectations they were checked against are in
[docs/BENCHMARK-2026-09-04-replay-lag.md](docs/BENCHMARK-2026-09-04-replay-lag.md).
One expectation was missed: replay lag GROWS with the length of the log, because
a cursor cannot resume and a catching-up reader re-walks everything it has
already seen.

## Standard package controls

This package uses `hey_packager` 0.1.6 or newer for validation, release
construction, source handoff, and immutable registry publication. The tool is
vendored as `bin/hey-packager`; it is release tooling, not a runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/package-zip` remains a compatibility alias for `bin/release`. Use
`bin/publish` only when the version does not already exist under
`$HOME/dev/jayteesf.github.io/packages/hey_durable_log`; published versions are
immutable, so change `VERSION` (through `bin/bump`) whenever released bytes
change.
