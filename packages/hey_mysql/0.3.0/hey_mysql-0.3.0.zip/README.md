# hey_mysql 0.2.7

`hey_mysql` is an independently versioned MariaDB/MySQL client package for the current compatible Hey native-extension interface. Database behavior, Connector/C compatibility, TLS policy, native builds, and live-server receipts belong to this package—not the Hey language repository.

## Boundary

- `native/`, `hey.native.json`, and `native.hey` provide opaque Connector/C connection/result handles over Hey native ABI v2.
- `adapter.hey` provides query results, transactions, escaped parameter plans, and the database-neutral connection shape consumed by higher-level packages.
- Hey supplies only generic package, FFI, opaque-handle, blocking-call, worker, and Job foundations.

## Build and verify

Install MariaDB Connector/C or MySQL client development files, then run:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

`bin/build-native` probes the installed headers instead of guessing from preprocessor names:

- MySQL 8/9: `MYSQL_OPT_SSL_MODE` and `enum mysql_ssl_mode`;
- MariaDB Connector/C: `MYSQL_OPT_SSL_ENFORCE` and `MYSQL_OPT_SSL_VERIFY_SERVER_CERT`.

For an immutable installed package, write native outputs outside the package cache:

```sh
package="$PWD/.hey/packages/hey_mysql/0.2.7"
out="$PWD/.hey/native/hey_mysql/0.2.6/darwin-arm64"
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" "$package/bin/build-native" --out "$out"
export HEY_MYSQL_LIBRARY="$out/libhey_mysql.dylib"
```

## Use

```hey
import 'pkg:hey_mysql@0.2.7/main'

let opened = Mysql.connect({
  host: '127.0.0.1',
  port: 3306,
  username: 'app',
  password: 'secret',
  database: 'app_production',
  connect_timeout_seconds: 5,
  encoding: 'utf8mb4',
  tls: {mode: 'preferred'},
})

if opened.ok == false
  fail opened.code + ': ' + opened.error
end

let database = opened.value
let rows = Mysql.query_params(database,
  'SELECT id, name FROM cards WHERE name = ?',
  ['Ada'])
Mysql.close(database)
```

TLS modes are `disabled`, `preferred`, `required`, and `verify_server_cert`. Verification requires `tls.ca` or `tls.ca_path`. `Mysql.tls_api(connection)` identifies the selected Connector/C option family, while `Mysql.tls_active(connection)` reports the negotiated connection state.

## Configuration from the environment

`config_from_env.hey` builds the `Mysql.connect(options)` record from
environment variables, so consumers stop hand-writing the map. It is the
generalization of RecallCoach's proven `App.mysql_config`.

```hey
import 'pkg:hey_mysql@<version>/config_from_env'

let cfg = MysqlConfig.from_env()                      # reads MYSQL_*
let other = MysqlConfig.from_env_prefix('ACME_MYSQL_') # reads ACME_MYSQL_*
let tuned = MysqlConfig.from_env_with('MYSQL_', {port: 3306, tls: 'preferred'})
```

- Env vars (per prefix, default `MYSQL_`): `HOST`, `PORT`, `USERNAME`,
  `PASSWORD`, `DATABASE`, `CONNECT_TIMEOUT_SECONDS`, `ENCODING`, `TLS_MODE`,
  `SSL_MODE`. Reads use `Env.default`/`Env.int_default` only (compiled-lane
  safe); an empty value counts as missing.
- The record carries every alias pair its consumers have needed:
  `user`/`username`, `tls`/`tls_mode`/`ssl_mode` (ssl_mode has its own env
  var and follows tls_mode when unset), `connect_timeout`/
  `connect_timeout_seconds`. All fields are always present; nil never
  crosses this API.
- Fallbacks: host `127.0.0.1`, port `3307` (the provisioning tier's default
  published port; pass `{port: 3306}` for a plain server), timeout 5s,
  encoding `utf8mb4`, tls `required`, and user/password/database default to
  `HEY_MYSQL_APP_NAME` (default `app`). The `defaults` record of
  `from_env_with` overrides any fallback; the environment always wins over
  both.

## Dev provisioning (`hey mysql-dev`)

The package ships the development-MySQL provisioning tier RecallCoach
proved in production use, as a locked package command (manifest
`"commands": {"mysql-dev": "bin/mysql-dev.hey"}`, the hey_ios_tv
precedent). Consumers with the package locked run `hey mysql-dev
SUBCOMMAND` from the project root, or invoke
`.hey/packages/hey_mysql/<version>/tools/hey-mysql-dev.sh` directly.

Subcommands: `up [--force]`, `down`, `clean-containers`, `configure-auth`,
`db-create`, `select-port`, `probe`, `compose`, `build-native`,
`install-system-deps`, `env-file-path` (prints the sourceable env-layering
helper). The compose file itself belongs to the consumer project; scripts
never hardcode a runtime (`docker compose`, then `docker-compose` -- Rancher
Desktop, colima, and Docker Desktop all work), and any external provider is
honored via `HEY_MYSQL_EXTERNAL=1`.

### The provisioning contract

1. **Idempotent by default; destruction is a flag.** `mysql-dev up` is a
   NO-OP whenever MySQL is already serving -- the resolved endpoint answers
   (any provider: compose, an SSH tunnel, a system install), the compose
   service is running, or the selected port is listening. `--force` is the
   ONLY path that recreates the container, because recreation drops every
   live connection of a server that is SHARED by dev servers, worktrees,
   and test tiers. (RecallCoach learned this live: an automated tier
   recreating the container dropped the maintainer's storage mid-session.)
   `down` and `clean-containers` never remove the named data volume.
2. **A root-side gate applies only to the server it can actually reach.**
   Before any root-over-container-socket operation (`configure-auth`'s DROP
   USER, `db-create`'s compose path), the compose-managed probe
   (`mysql-dev probe`) must prove the compose service actually HOLDS the
   resolved endpoint: the service answers AND owns the published port, and
   the resolved host is local. Otherwise the operation skips LOUDLY (exit 0
   for the skip, exit 3 from the probe) -- because when the real provider is
   a tunnel or an external server, a root-side step against an idle
   container would "succeed" against a server the project never dials.
3. **Every environment's database is granted every time.** `configure-auth`
   drops and recreates the application account (one modern
   caching_sha2_password identity, REQUIRE SSL, TLS-proven TCP login), and
   a dropped account takes its grants with it -- so `db-create` grants base,
   `_test`, and the current environment's databases on every run.
4. **Env layering with test isolation.** The sourceable `load-env` helper
   (path via `mysql-dev env-file-path`) layers shell > `.env.<environment>`
   > `.env` > `.env.local`. The one exception to "the shell wins": in the
   `test` environment `MYSQL_DATABASE` is FORCED to `<base>_test`, so an
   inherited development database name can never be truncated by a test
   run.

Parameterization (all optional): `HEY_MYSQL_PROJECT_ROOT` (default `$PWD`),
`HEY_MYSQL_APP_NAME` (default `app`; RecallCoach binds `recall_coach`),
`HEY_MYSQL_ENV_VAR` (selector variable name, default `APP_ENV`; RecallCoach
binds `RECALL_COACH_ENV`), `HEY_MYSQL_SERVICE` (default `mysql`),
`HEY_MYSQL_PORT_DEFAULT` (default `3307`), `HEY_MYSQL_PORT_SCAN_LIMIT`
(default `200`), `HEY_MYSQL_BIND_ATTEMPTS` (default `20`),
`HEY_MYSQL_ENV_FILE`, `HEY_MYSQL_COMPOSE_COMMAND`,
`HEY_MYSQL_SKIP_COMPOSE_DETECTION=1`, `HEY_MYSQL_EXTERNAL=1`,
`HEY_MYSQL_TEST_DATABASE_OVERRIDE`.

## Receipts

The base gate proves:

- header compatibility for MySQL 8/9 and MariaDB Connector/C;
- generated ABI, dynamic loading, opaque handles, TLS mode configuration, escaping, bounded refusal, and teardown through interpreter, native-C, and direct LLVM;
- the higher-level adapter through interpreter and native-C.

A configured live server remains a separate destructive integration receipt:

```sh
HEY_MYSQL_TEST_HOST="127.0.0.1" \
HEY_MYSQL_TEST_PORT="3306" \
HEY_MYSQL_TEST_USER="app" \
HEY_MYSQL_TEST_PASSWORD="secret" \
HEY_MYSQL_TEST_DATABASE="app_test" \
HEY_MYSQL_TEST_TLS="preferred" \
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
./bin/check-live
```

The live gate creates and drops `hey_mysql_0201_receipt`. It currently proves interpreter and native-C live behavior. Direct-LLVM native load/refusal passes, but the complete dynamic live-SQL fixture still exceeds the self-hosted LLVM supported subset for dynamic environment/string expressions; the gate reports `llvm_live=false` rather than hiding that compiler limitation.

## Honest limitation

0.2.7 uses Connector/C escaping to realize generated `?` parameter plans. This is not server-side prepared execution. SQL containing literal question marks or comments should use `Mysql.query`. `MYSQL_STMT`, typed/binary binds, cancellation, and statement reuse remain future package work.

## Standard package controls

This package uses `hey_packager` 0.1.2 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_mysql`.
