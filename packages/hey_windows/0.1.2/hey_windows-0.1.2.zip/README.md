# hey_windows

A Windows desktop window for a Hey web application. One Win32 window with its
own taskbar entry shows the application through Microsoft Edge WebView2. The
manifest (title, origin, size, minimum size, data folder) is validated by Hey on
the build host and compiled into the native host; the executable is cross-built
with mingw-w64 in a container and smoke-tested under Wine. No Windows machine
is needed to build it; a real PC is needed to see the browser part, because
WebView2 does not exist under Wine.

Why a window and not a tab: the owner's customers on Windows said another
browser tab is "a nightmare ... another list to have to navigate to (or forget
about)". A window on the taskbar is found again.

Why not Hey on Windows: Hey does not run on Windows yet (its runtime platform
surface is unported; the compiler can emit COFF objects but cannot yet link a
running program). So nothing inside the executable is Hey. The Hey part is the
build-host tool, the same shape as `hey_ios`, whose screens are described at
build time and drawn by a native host. When Hey targets Windows, the host can
render `hey_mobile` descriptions natively; see docs/ROADMAP.md.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
bin/check                 # specs, header currency, cross-build, Wine smoke
bin/build-exe             # dist/MyQueue.exe + dist/WebView2Loader.dll
bin/wine-smoke            # receipt and screenshot from the virtual display
```

Read docs/GETTING_STARTED.md to build an application window, docs/DESIGN.md
for how the pieces fit, docs/TESTING.md for what each check proves and what
only a PC can prove.

Third party: `third_party/webview2` is Microsoft's WebView2 SDK 1.0.2903.40
(header and x64 loader) under its BSD-style license, kept beside the code with
its LICENSE.txt and NOTICE.txt.
