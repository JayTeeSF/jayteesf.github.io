/* hey_io_uring: the io_uring backend of Hey's batched TCP event loop (Linux).
 *
 * The API and its semantics are hey_epoll's: wait -> next/data ... -> send.
 * Input is handed over as text (UTF-8 without NUL; anything else closes the
 * connection), protocol parsing stays in Hey, and the program says how many
 * input bytes each reply consumed; unconsumed input stays here and the
 * connection is offered again, so partial and pipelined requests need no
 * state on the Hey side.
 *
 * What io_uring changes underneath:
 *
 *   accept   one multishot accept on the listener; every accepted socket goes
 *            straight into the ring's registered (fixed) file table
 *            (IORING_FILE_INDEX_ALLOC), never into the process's descriptor
 *            table. A connection's slot in that table is its index here.
 *   receive  one multishot receive per connection, armed once, with buffers
 *            picked by the kernel from a provided buffer ring. Each completion
 *            is copied into the connection's input buffer and the buffer goes
 *            straight back to the ring.
 *   send     send() only appends to the connection's output buffer. The next
 *            wait() hands every connection's output to the kernel (one SEND
 *            per connection, at most one in flight) in the SAME io_uring_enter
 *            that waits for completions: one system call per loop batch, which
 *            is Hey's batch-per-wake model. A short send is resubmitted from
 *            where it stopped; later replies queue behind it.
 *   close    cancel the connection's in-flight requests and close the fixed
 *            slot, linked, in the next submit.
 *
 * Completion-queue overflow: the ring must have IORING_FEAT_NODROP (the kernel
 * keeps overflowed completions instead of dropping them); every drain checks
 * the overflow flag and flushes the kernel's backlog before the batch is
 * returned, and an early or failed submit (SQ full, -EBUSY/-EAGAIN) is retried
 * after the completion queue is reaped.
 *
 * A loop belongs to the thread that opened it: the ring is created with
 * IORING_SETUP_SINGLE_ISSUER (+ DEFER_TASKRUN where the kernel has it).
 * Nothing here is global except the per-thread "why did open fail" text.
 */
#define _GNU_SOURCE
#include "hey_io_uring.h"

#if !defined(__linux__)
#error "hey_io_uring is the Linux io_uring backend; use hey_kqueue (macOS/BSD) or hey_epoll, or hey_poller to pick one"
#endif

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <liburing.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/utsname.h>
#include <time.h>
#include <unistd.h>

#define HU_BACKEND "io_uring"
#define HU_MAX_INPUT (1024u * 1024u)
#define HU_MAX_SLOTS (1u << 20)        /* IORING_MAX_FIXED_FILES */
#define HU_BGID 0
#define HU_MIN_KERNEL "6.0"            /* multishot receive (6.0); everything else is older */
#define HU_SYSCTL "/proc/sys/kernel/io_uring_disabled"
#define HU_DEFAULT_SQ 4096
#define HU_DEFAULT_BUFFERS 1024
#define HU_DEFAULT_BUFFER_SIZE 2048
#define HU_CLOSE_GRACE_MS 1000
#define HU_EXIT_GRACE_MS 2000

enum { OP_ACCEPT = 1, OP_RECV = 2, OP_SEND = 3, OP_CLOSE = 4, OP_CANCEL = 5 };

enum {
  F_OPEN = 1,         /* a live connection */
  F_RECV = 2,         /* its multishot receive is armed */
  F_SENDING = 4,      /* a SEND of `flight` is owned by the kernel */
  F_WANT_CLOSE = 8,   /* close once every queued byte is written */
  F_QUEUED = 16,      /* in this batch's ready list */
  F_DIRTY = 32,       /* in the flush list: output (or a close) to hand to the kernel */
  F_REARM = 64        /* in the re-arm list: its receive must be armed again */
};

typedef struct HuConn {
  char *in;            /* unconsumed input: [in_off, in_len) */
  char *out;           /* replies not yet handed to the kernel */
  char *flight;        /* the bytes of the SEND in flight: [flight_sent, flight_len) */
  size_t out_len, out_cap, flight_len, flight_sent;
  uint32_t in_off, in_len, in_cap;
  uint32_t gen;
  uint32_t flags;
} HuConn;

typedef struct HuOrphan {
  uint64_t tag;        /* the SEND whose completion has not arrived yet */
  char *buffer;        /* ...for a connection that is already closed */
} HuOrphan;

typedef struct HuList {
  uint32_t *items;
  size_t len, cap;
} HuList;

typedef struct HuLoop {
  struct io_uring ring;
  int listener;
  int port;
  uint32_t slots;                    /* registered file table size */
  HuConn *conns;
  size_t conns_cap;
  struct io_uring_buf_ring *br;
  char *bufs;
  size_t bufs_bytes;
  uint32_t nbufs, buf_size;
  int br_pending;                    /* buffers re-added, not yet published */
  int accept_armed, accept_full, closing, broken;
  uint32_t accept_gen;
  HuList ready, pending, dirty, rearm, close_backlog;
  size_t ready_pos;
  HuOrphan *orphans;
  size_t orphans_len, orphans_cap;
  uint64_t outstanding;              /* accepts/receives/sends whose final completion is due */
  unsigned setup_flags;
  char setup_text[96];
  char kernel[72];
  char stats_text[1400];
  uint64_t accepted, closed, live, waits, batches_ready, bytes_in, bytes_out;
  uint64_t accept_errors, oversize, invalid_text, partial_writes;
  uint64_t submits, early_submits, submit_errors, sqes, cqes, cq_overflow_flushes, enobufs;
  uint64_t recv_rearms, accept_rearms, recv_errors, send_errors, table_full, slot_conflicts;
  uint64_t orphaned, leaked_buffers, accept_lost;
} HuLoop;

/* ---- the reason the last open()/probe() on this thread refused --------- */

static __thread char hu_err_code[64];
static __thread char hu_err_msg[512];
static __thread char hu_err_json[800];
static __thread char hu_probe_json[1024];

static void hu_fail(const char *code, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void hu_fail(const char *code, const char *fmt, ...) {
  snprintf(hu_err_code, sizeof(hu_err_code), "%s", code);
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(hu_err_msg, sizeof(hu_err_msg), fmt, ap);
  va_end(ap);
}

static void hu_clear_error(void) {
  hu_err_code[0] = '\0';
  hu_err_msg[0] = '\0';
}

/* JSON string body: escapes quotes, backslashes and control bytes. */
static size_t hu_json_escape(char *dst, size_t cap, const char *src) {
  size_t n = 0;
  for (const unsigned char *s = (const unsigned char *)src; *s && n + 7 < cap; s++) {
    if (*s == '"' || *s == '\\') { dst[n++] = '\\'; dst[n++] = (char)*s; }
    else if (*s < 0x20) n += (size_t)snprintf(dst + n, cap - n, "\\u%04x", *s);
    else dst[n++] = (char)*s;
  }
  dst[n] = '\0';
  return n;
}

/* ---- small helpers ------------------------------------------------------ */

static HuLoop *hu_loop(HeyNativeHandle value) { return (HuLoop *)(uintptr_t)value; }

static inline uint64_t hu_tag(unsigned op, uint32_t slot, uint32_t gen) {
  return (uint64_t)op | ((uint64_t)(slot & 0xffffff) << 8) | ((uint64_t)gen << 32);
}

static int64_t hu_now_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static int hu_push(HuList *list, uint32_t value) {
  if (list->len == list->cap) {
    size_t next = list->cap ? list->cap * 2 : 256;
    uint32_t *grown = (uint32_t *)realloc(list->items, next * sizeof(uint32_t));
    if (!grown) return 0;
    list->items = grown;
    list->cap = next;
  }
  list->items[list->len++] = value;
  return 1;
}

static int hu_ensure_conn(HuLoop *loop, uint32_t slot) {
  if (slot < loop->conns_cap) return 1;
  size_t next = loop->conns_cap ? loop->conns_cap : 1024;
  while (next <= slot) next *= 2;
  if (next > loop->slots) next = loop->slots;
  if (slot >= next) return 0;
  HuConn *grown = (HuConn *)realloc(loop->conns, next * sizeof(HuConn));
  if (!grown) return 0;
  memset(grown + loop->conns_cap, 0, (next - loop->conns_cap) * sizeof(HuConn));
  loop->conns = grown;
  loop->conns_cap = next;
  return 1;
}

static HuConn *hu_live(HuLoop *loop, uint32_t slot, uint32_t gen) {
  if (slot >= loop->conns_cap) return NULL;
  HuConn *c = &loop->conns[slot];
  if (!(c->flags & F_OPEN) || c->gen != gen) return NULL;
  return c;
}

static HuConn *hu_lookup(HuLoop *loop, int64_t id, uint32_t *slot_out) {
  if (!loop || id < 0) return NULL;
  uint32_t slot = (uint32_t)(id & 0xffffffff);
  uint32_t gen = (uint32_t)((uint64_t)id >> 32);
  HuConn *c = hu_live(loop, slot, gen);
  if (c && slot_out) *slot_out = slot;
  return c;
}

static int64_t hu_id(HuLoop *loop, uint32_t slot) {
  return ((int64_t)loop->conns[slot].gen << 32) | (int64_t)slot;
}

/* ---- buffers given to the kernel ---------------------------------------- */

static void hu_recycle(HuLoop *loop, unsigned bid) {
  if (bid >= loop->nbufs) return;
  io_uring_buf_ring_add(loop->br, loop->bufs + (size_t)bid * loop->buf_size, loop->buf_size, (unsigned short)bid,
                        io_uring_buf_ring_mask(loop->nbufs), loop->br_pending++);
}

static void hu_publish_buffers(HuLoop *loop) {
  if (loop->br_pending) {
    io_uring_buf_ring_advance(loop->br, loop->br_pending);
    loop->br_pending = 0;
  }
}

static void hu_orphan(HuLoop *loop, uint64_t tag, char *buffer) {
  if (loop->orphans_len == loop->orphans_cap) {
    size_t next = loop->orphans_cap ? loop->orphans_cap * 2 : 64;
    HuOrphan *grown = (HuOrphan *)realloc(loop->orphans, next * sizeof(HuOrphan));
    if (!grown) { loop->leaked_buffers++; return; }   /* the kernel may still read it: never free */
    loop->orphans = grown;
    loop->orphans_cap = next;
  }
  loop->orphans[loop->orphans_len].tag = tag;
  loop->orphans[loop->orphans_len].buffer = buffer;
  loop->orphans_len++;
  loop->orphaned++;
}

static void hu_free_orphan(HuLoop *loop, uint64_t tag) {
  for (size_t i = 0; i < loop->orphans_len; i++) {
    if (loop->orphans[i].tag == tag) {
      free(loop->orphans[i].buffer);
      loop->orphans[i] = loop->orphans[--loop->orphans_len];
      return;
    }
  }
}

/* ---- submission ---------------------------------------------------------- */

/* An SQE, submitting what is queued first when the SQ is full (counted as an
   early submit). NULL only when the kernel refused that submit as well; the
   caller then leaves its work on a list for the next pass. */
static struct io_uring_sqe *hu_sqe(HuLoop *loop) {
  struct io_uring_sqe *sqe = io_uring_get_sqe(&loop->ring);
  if (!sqe) {
    hu_publish_buffers(loop);
    loop->early_submits++;
    if (io_uring_submit(&loop->ring) < 0) loop->submit_errors++;
    sqe = io_uring_get_sqe(&loop->ring);
    if (!sqe) return NULL;
  }
  loop->sqes++;
  return sqe;
}

static int hu_arm_accept(HuLoop *loop) {
  struct io_uring_sqe *sqe = hu_sqe(loop);
  if (!sqe) return 0;
  loop->accept_gen++;
  io_uring_prep_multishot_accept_direct(sqe, loop->listener, NULL, NULL, 0);
  io_uring_sqe_set_data64(sqe, hu_tag(OP_ACCEPT, 0, loop->accept_gen));
  loop->accept_armed = 1;
  loop->outstanding++;
  return 1;
}

static int hu_arm_recv(HuLoop *loop, uint32_t slot) {
  HuConn *c = &loop->conns[slot];
  struct io_uring_sqe *sqe = hu_sqe(loop);
  if (!sqe) return 0;
  io_uring_prep_recv_multishot(sqe, (int)slot, NULL, 0, 0);
  sqe->flags |= IOSQE_FIXED_FILE | IOSQE_BUFFER_SELECT;
  sqe->buf_group = HU_BGID;
  io_uring_sqe_set_data64(sqe, hu_tag(OP_RECV, slot, c->gen));
  c->flags |= F_RECV;
  loop->outstanding++;
  return 1;
}

static int hu_submit_send(HuLoop *loop, uint32_t slot) {
  HuConn *c = &loop->conns[slot];
  struct io_uring_sqe *sqe = hu_sqe(loop);
  if (!sqe) return 0;
  size_t left = c->flight_len - c->flight_sent;
  if (left > 0x7fffffffu) left = 0x7fffffffu;   /* one SEND moves at most INT_MAX; the rest is a short send */
  io_uring_prep_send(sqe, (int)slot, c->flight + c->flight_sent, left, MSG_NOSIGNAL);
  sqe->flags |= IOSQE_FIXED_FILE;
  io_uring_sqe_set_data64(sqe, hu_tag(OP_SEND, slot, c->gen));
  c->flags |= F_SENDING;
  loop->outstanding++;
  return 1;
}

/* Cancel whatever the kernel still runs on the slot, then close it, linked so
   the close runs after the cancel even when there was nothing to cancel. */
static int hu_queue_close(HuLoop *loop, uint32_t slot, int cancel) {
  unsigned need = cancel ? 2 : 1;
  if (io_uring_sq_space_left(&loop->ring) < need) {
    hu_publish_buffers(loop);
    loop->early_submits++;
    if (io_uring_submit(&loop->ring) < 0) loop->submit_errors++;
    if (io_uring_sq_space_left(&loop->ring) < need) return 0;
  }
  if (cancel) {
    struct io_uring_sqe *sqe = io_uring_get_sqe(&loop->ring);
    io_uring_prep_cancel_fd(sqe, (int)slot, IORING_ASYNC_CANCEL_FD_FIXED | IORING_ASYNC_CANCEL_ALL);
    sqe->flags |= IOSQE_IO_HARDLINK | IOSQE_CQE_SKIP_SUCCESS;
    io_uring_sqe_set_data64(sqe, hu_tag(OP_CANCEL, slot, 0));
    loop->sqes++;
  }
  struct io_uring_sqe *sqe = io_uring_get_sqe(&loop->ring);
  io_uring_prep_close_direct(sqe, slot);
  sqe->flags |= IOSQE_CQE_SKIP_SUCCESS;
  io_uring_sqe_set_data64(sqe, hu_tag(OP_CLOSE, slot, 0));
  loop->sqes++;
  return 1;
}

static void hu_close_conn(HuLoop *loop, uint32_t slot) {
  HuConn *c = &loop->conns[slot];
  if (!(c->flags & F_OPEN)) return;
  int cancel = (c->flags & (F_RECV | F_SENDING)) != 0;
  if (c->flags & F_SENDING) hu_orphan(loop, hu_tag(OP_SEND, slot, c->gen), c->flight);  /* freed on its completion */
  else free(c->flight);
  free(c->in);
  free(c->out);
  uint32_t gen = c->gen;
  memset(c, 0, sizeof(*c));
  c->gen = gen + 1;      /* every id and completion of the old connection is now stale */
  if (!hu_queue_close(loop, slot, cancel)) (void)hu_push(&loop->close_backlog, slot | (cancel ? 0x80000000u : 0));
  loop->closed++;
  if (loop->live) loop->live--;
  loop->accept_full = 0;  /* a slot is (about to be) free again */
}

static void hu_mark_dirty(HuLoop *loop, uint32_t slot) {
  HuConn *c = &loop->conns[slot];
  if (c->flags & F_DIRTY) return;
  if (hu_push(&loop->dirty, slot)) c->flags |= F_DIRTY;
}

static void hu_mark_rearm(HuLoop *loop, uint32_t slot) {
  HuConn *c = &loop->conns[slot];
  if (c->flags & F_REARM) return;
  if (hu_push(&loop->rearm, slot)) c->flags |= F_REARM;
}

static void hu_mark_ready(HuLoop *loop, uint32_t slot) {
  HuConn *c = &loop->conns[slot];
  if ((c->flags & F_QUEUED) || c->in_len == c->in_off) return;
  if (hu_push(&loop->ready, slot)) c->flags |= F_QUEUED;
}

/* (Re-)arms the multishot accept, but only into an empty completion queue
   and as the first entry of its submit. Linux 6.8 (at least) has a multishot
   accept that cannot post its completion AT ISSUE TIME (the CQ is overflowing)
   fail the request with -ECANCELED after the socket was already installed in a
   fixed slot: that connection is lost (its slot leaks and its client hangs).
   Measured on 6.8 with a 16-entry CQ and 300 queued connections. So: never
   issue the accept while the CQ has an overflow backlog, submit whatever is
   queued before it (no completion of the same submit fills the CQ ahead of
   it), and size the CQ to at least twice the listen queue (open), since an
   accept at issue takes every queued connection in one go. A loss that still
   happens is counted (accept_lost). (Accepts after the first, from the
   kernel's poll wakeups, report a full CQ correctly.) */
static void hu_arm_accept_safely(HuLoop *loop) {
  if (loop->accept_armed || loop->accept_full || loop->closing || loop->live >= loop->slots) return;
  if (io_uring_cq_has_overflow(&loop->ring) || io_uring_cq_ready(&loop->ring) > 0) return;  /* the next drain empties it */
  if (io_uring_sq_ready(&loop->ring) > 0) {
    hu_publish_buffers(loop);
    loop->early_submits++;
    if (io_uring_submit(&loop->ring) < 0) { loop->submit_errors++; return; }
    if (io_uring_cq_has_overflow(&loop->ring) || io_uring_cq_ready(&loop->ring) > 0) return;
  }
  if (hu_arm_accept(loop)) loop->accept_rearms++;
}

/* Everything the batch left for the kernel: closes that did not fit, output
   (one SEND per connection, never two in flight), closes after the last byte,
   receives to re-arm, the accept. */
static void hu_prepare(HuLoop *loop) {
  hu_arm_accept_safely(loop);
  if (loop->close_backlog.len) {
    size_t keep = 0;
    for (size_t i = 0; i < loop->close_backlog.len; i++) {
      uint32_t v = loop->close_backlog.items[i];
      if (!hu_queue_close(loop, v & 0x7fffffffu, (v & 0x80000000u) != 0)) loop->close_backlog.items[keep++] = v;
    }
    loop->close_backlog.len = keep;
  }
  if (loop->dirty.len) {
    size_t n = loop->dirty.len, keep = 0;
    for (size_t i = 0; i < n; i++) {
      uint32_t slot = loop->dirty.items[i];
      HuConn *c = &loop->conns[slot];
      c->flags &= ~(uint32_t)F_DIRTY;
      if (!(c->flags & F_OPEN) || (c->flags & F_SENDING)) continue;   /* its completion re-marks it */
      if (c->flight_sent < c->flight_len) {
        if (!hu_submit_send(loop, slot)) { c->flags |= F_DIRTY; loop->dirty.items[keep++] = slot; }
        continue;
      }
      if (c->out_len > 0) {
        free(c->flight);
        c->flight = c->out;
        c->flight_len = c->out_len;
        c->flight_sent = 0;
        c->out = NULL;
        c->out_len = c->out_cap = 0;
        if (!hu_submit_send(loop, slot)) { c->flags |= F_DIRTY; loop->dirty.items[keep++] = slot; }
        continue;
      }
      free(c->flight);
      c->flight = NULL;
      c->flight_len = c->flight_sent = 0;
      if (c->flags & F_WANT_CLOSE) hu_close_conn(loop, slot);
    }
    /* items appended while flushing (none today) stay after the kept ones */
    if (loop->dirty.len > n) memmove(loop->dirty.items + keep, loop->dirty.items + n, (loop->dirty.len - n) * sizeof(uint32_t));
    loop->dirty.len = keep + (loop->dirty.len - n);
  }
  if (loop->rearm.len) {
    size_t keep = 0;
    for (size_t i = 0; i < loop->rearm.len; i++) {
      uint32_t slot = loop->rearm.items[i];
      HuConn *c = &loop->conns[slot];
      c->flags &= ~(uint32_t)F_REARM;
      if (!(c->flags & F_OPEN) || (c->flags & F_RECV)) continue;
      if (hu_arm_recv(loop, slot)) loop->recv_rearms++;
      else { c->flags |= F_REARM; loop->rearm.items[keep++] = slot; }
    }
    loop->rearm.len = keep;
  }
  hu_publish_buffers(loop);
}

/* ---- completions --------------------------------------------------------- */

/* Appends received bytes. Returns 0 when the connection had to be closed. */
static int hu_append_input(HuLoop *loop, uint32_t slot, const char *data, size_t n) {
  HuConn *c = &loop->conns[slot];
  loop->bytes_in += n;
  if (c->in_off == c->in_len) c->in_off = c->in_len = 0;
  size_t need = (size_t)c->in_len + n;
  if (need - c->in_off > HU_MAX_INPUT) { loop->oversize++; hu_close_conn(loop, slot); return 0; }
  if (need > c->in_cap) {
    if (c->in_off > 0) {      /* reclaim consumed space before growing */
      memmove(c->in, c->in + c->in_off, c->in_len - c->in_off);
      c->in_len -= c->in_off;
      c->in_off = 0;
      need = (size_t)c->in_len + n;
    }
    if (need > c->in_cap) {
      size_t cap = c->in_cap ? c->in_cap : 1024;
      while (cap < need) cap *= 2;
      char *grown = (char *)realloc(c->in, cap);
      if (!grown) { hu_close_conn(loop, slot); return 0; }
      c->in = grown;
      c->in_cap = (uint32_t)cap;
    }
  }
  memcpy(c->in + c->in_len, data, n);
  c->in_len += (uint32_t)n;
  return 1;
}

static void hu_on_accept(HuLoop *loop, uint32_t gen, int res, unsigned flags) {
  if (!(flags & IORING_CQE_F_MORE)) {
    if (loop->outstanding) loop->outstanding--;
    if (gen == loop->accept_gen) loop->accept_armed = 0;   /* re-armed by the next prepare */
  }
  if (res < 0) {
    if (res == -ENFILE || res == -EMFILE) { loop->table_full++; loop->accept_full = 1; }
    else if (res != -ECANCELED) loop->accept_errors++;
    else if (!loop->closing) loop->accept_lost++;   /* not cancelled by us: see hu_arm_accept_safely */
    return;
  }
  uint32_t slot = (uint32_t)res;
  if (slot >= loop->slots || !hu_ensure_conn(loop, slot)) {
    loop->accept_errors++;
    if (!hu_queue_close(loop, slot, 0)) (void)hu_push(&loop->close_backlog, slot);
    return;
  }
  HuConn *c = &loop->conns[slot];
  uint32_t conn_gen = c->gen;
  if (c->flags & F_OPEN) {      /* cannot happen while every close goes through hu_close_conn */
    loop->slot_conflicts++;
    if (c->flags & F_SENDING) hu_orphan(loop, hu_tag(OP_SEND, slot, c->gen), c->flight);
    else free(c->flight);
    free(c->in);
    free(c->out);
    if (loop->live) loop->live--;
    conn_gen++;
  }
  memset(c, 0, sizeof(*c));
  c->gen = conn_gen;
  c->flags = F_OPEN;
  loop->accepted++;
  loop->live++;
  if (!hu_arm_recv(loop, slot)) hu_mark_rearm(loop, slot);
}

static void hu_on_recv(HuLoop *loop, uint32_t slot, uint32_t gen, int res, unsigned flags) {
  int more = (flags & IORING_CQE_F_MORE) != 0;
  int has_buffer = (flags & IORING_CQE_F_BUFFER) != 0;
  unsigned bid = flags >> IORING_CQE_BUFFER_SHIFT;
  if (!more && loop->outstanding) loop->outstanding--;
  HuConn *c = hu_live(loop, slot, gen);
  if (c) {
    if (!more) c->flags &= ~(uint32_t)F_RECV;
    if (res > 0 && has_buffer && bid < loop->nbufs && (unsigned)res <= loop->buf_size) {
      if (hu_append_input(loop, slot, loop->bufs + (size_t)bid * loop->buf_size, (size_t)res)) hu_mark_ready(loop, slot);
    } else if (res == 0) {
      hu_close_conn(loop, slot);         /* the peer closed */
    } else if (res == -ENOBUFS) {
      loop->enobufs++;                   /* the buffer ring ran dry: re-armed after this drain refills it */
    } else if (res < 0 && res != -ECANCELED) {
      loop->recv_errors++;
      hu_close_conn(loop, slot);
    }
    if ((c->flags & F_OPEN) && c->gen == gen && !(c->flags & F_RECV)) hu_mark_rearm(loop, slot);
  }
  if (has_buffer) hu_recycle(loop, bid);   /* always: a stale completion still owns a buffer */
}

static void hu_on_send(HuLoop *loop, uint32_t slot, uint32_t gen, int res) {
  if (loop->outstanding) loop->outstanding--;
  HuConn *c = hu_live(loop, slot, gen);
  if (!c) { hu_free_orphan(loop, hu_tag(OP_SEND, slot, gen)); return; }
  c->flags &= ~(uint32_t)F_SENDING;
  if (res == -EAGAIN || res == -EINTR) { hu_mark_dirty(loop, slot); return; }   /* resent as is */
  if (res <= 0) { loop->send_errors++; hu_close_conn(loop, slot); return; }
  loop->bytes_out += (uint64_t)res;
  c->flight_sent += (size_t)res;
  if (c->flight_sent < c->flight_len) {  /* short send */
    /* The socket took part of it: send the rest, from where it stopped. */
    loop->partial_writes++;
    if (!hu_submit_send(loop, slot)) hu_mark_dirty(loop, slot);
    return;
  }
  free(c->flight);       /* idle connections keep no buffers */
  c->flight = NULL;
  c->flight_len = c->flight_sent = 0;
  if (c->out_len > 0 || (c->flags & F_WANT_CLOSE)) hu_mark_dirty(loop, slot);
}

static void hu_handle(HuLoop *loop, const struct io_uring_cqe *cqe) {
  uint64_t tag = io_uring_cqe_get_data64(cqe);
  unsigned op = (unsigned)(tag & 0xff);
  uint32_t slot = (uint32_t)((tag >> 8) & 0xffffff);
  uint32_t gen = (uint32_t)(tag >> 32);
  switch (op) {
    case OP_ACCEPT: hu_on_accept(loop, gen, cqe->res, cqe->flags); break;
    case OP_RECV: hu_on_recv(loop, slot, gen, cqe->res, cqe->flags); break;
    case OP_SEND: hu_on_send(loop, slot, gen, cqe->res); break;
    default: break;   /* cancel/close report only failures; nothing depends on them */
  }
}

/* Reaps every completion, including the ones the kernel kept back when the
   CQ was full (IORING_FEAT_NODROP: they wait in an overflow list and the
   IORING_SQ_CQ_OVERFLOW flag says so). Returns how many were handled. */
static size_t hu_drain(HuLoop *loop) {
  size_t total = 0;
  size_t budget = (size_t)loop->ring.cq.ring_entries * 8;   /* never spin forever under a flood */
  for (;;) {
    unsigned head, n = 0;
    struct io_uring_cqe *cqe;
    io_uring_for_each_cqe(&loop->ring, head, cqe) {
      hu_handle(loop, cqe);
      n++;
    }
    if (n) io_uring_cq_advance(&loop->ring, n);
    total += n;
    hu_publish_buffers(loop);
    if (io_uring_cq_has_overflow(&loop->ring) && total < budget) {
      loop->cq_overflow_flushes++;
      (void)io_uring_get_events(&loop->ring);   /* moves the overflow list into the CQ we just emptied */
      continue;
    }
    if (n == 0 || total >= budget) break;
  }
  loop->cqes += total;
  return total;
}

/* The one system call of a batch: submit what is queued, then wait for at
   least one completion (timeout_ms: -1 forever, 0 not at all). Returns -1 if
   the ring cannot be used any more. */
static int hu_enter(HuLoop *loop, int timeout_ms) {
  int r;
  loop->submits++;
  if (timeout_ms == 0) {
    r = io_uring_submit_and_get_events(&loop->ring);
  } else if (timeout_ms < 0) {
    r = io_uring_submit_and_wait(&loop->ring, 1);
  } else {
    struct __kernel_timespec ts;
    struct io_uring_cqe *cqe = NULL;
    ts.tv_sec = timeout_ms / 1000;
    ts.tv_nsec = (long long)(timeout_ms % 1000) * 1000000LL;
    r = io_uring_submit_and_wait_timeout(&loop->ring, &cqe, 1, &ts, NULL);
  }
  if (r >= 0 || r == -ETIME || r == -EINTR) return 0;
  if (r == -EAGAIN || r == -EBUSY) {     /* reap, then the next pass submits again */
    loop->submit_errors++;
    return 0;
  }
  loop->submit_errors++;
  if (r == -EEXIST || r == -EBADF || r == -EBADFD || r == -EFAULT || r == -EOPNOTSUPP) return -1;  /* wrong thread or ring gone */
  return 0;
}

/* ---- the text check: the hand-over is UTF-8 text without NUL ---------- */

static size_t hu_text_prefix(const unsigned char *s, size_t n, int *bad) {
  size_t i = 0;
  *bad = 0;
  while (i < n) {
    unsigned char b = s[i];
    if (b >= 0x01 && b < 0x80) { i++; continue; }
    if (b == 0) { *bad = 1; return i; }
    size_t need;
    uint32_t cp;
    if (b >= 0xc2 && b <= 0xdf) { need = 1; cp = b & 0x1f; }
    else if (b >= 0xe0 && b <= 0xef) { need = 2; cp = b & 0x0f; }
    else if (b >= 0xf0 && b <= 0xf4) { need = 3; cp = b & 0x07; }
    else { *bad = 1; return i; }
    if (i + need >= n) {
      for (size_t k = i + 1; k < n; k++) if ((s[k] & 0xc0) != 0x80) { *bad = 1; return i; }
      return i;   /* a sequence split across receives: held back until complete */
    }
    for (size_t k = 1; k <= need; k++) {
      if ((s[i + k] & 0xc0) != 0x80) { *bad = 1; return i; }
      cp = (cp << 6) | (s[i + k] & 0x3f);
    }
    if ((need == 2 && cp < 0x800) || (need == 3 && (cp < 0x10000 || cp > 0x10ffff)) || (cp >= 0xd800 && cp <= 0xdfff)) {
      *bad = 1;
      return i;
    }
    i += need + 1;
  }
  return i;
}

/* ---- can this kernel and process run the loop? -------------------------- */

static void hu_text_copy(char *dst, size_t cap, HeyNativeUtf8View view, const char *fallback) {
  if (view.length == 0 || view.length >= cap) { snprintf(dst, cap, "%s", fallback); return; }
  memcpy(dst, view.data, view.length);
  dst[view.length] = '\0';
}

static int hu_version_at_least(const char *have, const char *want) {
  int hm = 0, hn = 0, wm = 0, wn = 0;
  if (sscanf(have, "%d.%d", &hm, &hn) < 1) return 0;
  if (sscanf(want, "%d.%d", &wm, &wn) < 1) return 1;
  return hm > wm || (hm == wm && hn >= wn);
}

/* The setup every loop needs: kernel version, the io_uring_disabled sysctl,
   the ring itself (single issuer + deferred task work when the kernel has
   them), required features and opcodes. On failure the reason is recorded
   with hu_fail() and the ring is not left open. */
static int hu_setup(struct io_uring *ring, unsigned sq, unsigned cq, const char *min_kernel, const char *sysctl_path,
                    unsigned *flags_out, char *kernel, size_t kernel_cap) {
  struct utsname u;
  if (uname(&u) != 0) snprintf(u.release, sizeof(u.release), "unknown");
  snprintf(kernel, kernel_cap, "%s", u.release);
  if (!hu_version_at_least(u.release, min_kernel)) {
    hu_fail("io_uring_kernel_too_old",
            "this loop needs Linux %s or later (multishot receive, provided buffer rings, fixed-file cancel); this kernel is %s",
            min_kernel, u.release);
    return 0;
  }

  int disabled = 0;
  FILE *f = fopen(sysctl_path, "r");
  if (f) {
    if (fscanf(f, "%d", &disabled) != 1) disabled = 0;
    fclose(f);
  }
  if (disabled >= 2) {
    hu_fail("io_uring_disabled", "kernel.io_uring_disabled=%d: io_uring is switched off for every process on this host", disabled);
    return 0;
  }

  static const unsigned attempts[] = {
    IORING_SETUP_SINGLE_ISSUER | IORING_SETUP_DEFER_TASKRUN,   /* 6.1 */
    IORING_SETUP_SINGLE_ISSUER | IORING_SETUP_COOP_TASKRUN,    /* 6.0 */
    IORING_SETUP_COOP_TASKRUN,                                  /* 5.19 */
    0
  };
  int r = -EINVAL;
  unsigned used = 0;
  struct io_uring_params p;
  for (size_t i = 0; i < sizeof(attempts) / sizeof(attempts[0]); i++) {
    memset(&p, 0, sizeof(p));
    p.flags = attempts[i] | IORING_SETUP_CQSIZE | IORING_SETUP_SUBMIT_ALL;
    p.cq_entries = cq;
    r = io_uring_queue_init_params(sq, ring, &p);
    used = p.flags;
    if (r != -EINVAL) break;
  }
  if (r < 0) {
    if (r == -EPERM && disabled == 1) {
      hu_fail("io_uring_disabled", "kernel.io_uring_disabled=1 and this process is neither privileged nor in kernel.io_uring_group (io_uring_setup: EPERM)");
    } else if (r == -EPERM) {
      hu_fail("io_uring_blocked",
              "io_uring_setup was refused (EPERM) by a seccomp filter or security policy; Docker's default seccomp profile blocks io_uring "
              "(run the container with --security-opt seccomp=unconfined, or a profile that allows io_uring_setup, io_uring_enter and io_uring_register)");
    } else if (r == -ENOSYS) {
      hu_fail("io_uring_not_in_kernel", "io_uring_setup is not implemented here (ENOSYS): a kernel without CONFIG_IO_URING, or a sandbox that hides it");
    } else if (r == -ENOMEM) {
      hu_fail("io_uring_no_memory", "io_uring_setup: ENOMEM (no memory for a %u/%u entry ring)", sq, cq);
    } else {
      hu_fail("io_uring_setup_failed", "io_uring_setup failed: %s", strerror(-r));
    }
    return 0;
  }

  struct { unsigned bit; const char *name; } features[] = {
    {IORING_FEAT_NODROP, "IORING_FEAT_NODROP (completions kept, not dropped, when the CQ overflows; 5.5)"},
    {IORING_FEAT_EXT_ARG, "IORING_FEAT_EXT_ARG (a timeout on the submit-and-wait call; 5.11)"},
    {IORING_FEAT_FAST_POLL, "IORING_FEAT_FAST_POLL (5.7)"},
    {IORING_FEAT_SUBMIT_STABLE, "IORING_FEAT_SUBMIT_STABLE (5.5)"},
  };
  for (size_t i = 0; i < sizeof(features) / sizeof(features[0]); i++) {
    if (!(p.features & features[i].bit)) {
      io_uring_queue_exit(ring);
      hu_fail("io_uring_missing_feature", "this kernel's io_uring lacks %s", features[i].name);
      return 0;
    }
  }
  struct io_uring_probe *probe = io_uring_get_probe_ring(ring);
  if (!probe) {
    io_uring_queue_exit(ring);
    hu_fail("io_uring_missing_feature", "this kernel's io_uring cannot report its opcodes (IORING_REGISTER_PROBE, 5.6)");
    return 0;
  }
  struct { int op; const char *name; } ops[] = {
    {IORING_OP_ACCEPT, "ACCEPT"}, {IORING_OP_RECV, "RECV"}, {IORING_OP_SEND, "SEND"},
    {IORING_OP_CLOSE, "CLOSE"}, {IORING_OP_ASYNC_CANCEL, "ASYNC_CANCEL"},
  };
  for (size_t i = 0; i < sizeof(ops) / sizeof(ops[0]); i++) {
    if (!io_uring_opcode_supported(probe, ops[i].op)) {
      io_uring_free_probe(probe);
      io_uring_queue_exit(ring);
      hu_fail("io_uring_missing_feature", "this kernel's io_uring lacks IORING_OP_%s", ops[i].name);
      return 0;
    }
  }
  io_uring_free_probe(probe);
  *flags_out = used;
  return 1;
}

static void hu_setup_text(char *dst, size_t cap, unsigned flags) {
  snprintf(dst, cap, "%s%s%s",
           (flags & IORING_SETUP_SINGLE_ISSUER) ? "single_issuer," : "",
           (flags & IORING_SETUP_DEFER_TASKRUN) ? "defer_taskrun," : "",
           (flags & IORING_SETUP_COOP_TASKRUN) ? "coop_taskrun," : "");
  size_t n = strlen(dst);
  if (n && dst[n - 1] == ',') dst[n - 1] = '\0';
}

/* Registers the fixed-file table and the provided buffer ring. */
static int hu_register(struct io_uring *ring, uint32_t slots, uint32_t nbufs, struct io_uring_buf_ring **br_out) {
  int r = io_uring_register_files_sparse(ring, slots);
  if (r < 0) {
    if (r == -EMFILE) hu_fail("io_uring_missing_feature", "registering %u fixed files: EMFILE (above RLIMIT_NOFILE)", slots);
    else hu_fail("io_uring_missing_feature", "this kernel cannot register a sparse fixed-file table (5.19): %s", strerror(-r));
    return 0;
  }
  int err = 0;
  struct io_uring_buf_ring *br = io_uring_setup_buf_ring(ring, nbufs, HU_BGID, 0, &err);
  if (!br) {
    hu_fail("io_uring_missing_feature", "this kernel cannot register a provided buffer ring (IORING_REGISTER_PBUF_RING, 5.19): %s", strerror(-err));
    return 0;
  }
  *br_out = br;
  return 1;
}

HeyNativeUtf8View hey_io_uring_probe(HeyNativeUtf8View min_kernel_view, HeyNativeUtf8View sysctl_view) {
  char min_kernel[32], sysctl_path[256], kernel[72], setup[96], msg[600];
  hu_text_copy(min_kernel, sizeof(min_kernel), min_kernel_view, HU_MIN_KERNEL);
  hu_text_copy(sysctl_path, sizeof(sysctl_path), sysctl_view, HU_SYSCTL);
  hu_clear_error();
  struct io_uring ring;
  unsigned flags = 0;
  int ok = hu_setup(&ring, 8, 16, min_kernel, sysctl_path, &flags, kernel, sizeof(kernel));
  if (ok) {
    struct io_uring_buf_ring *br = NULL;
    ok = hu_register(&ring, 16, 8, &br);
    if (br) io_uring_free_buf_ring(&ring, br, 8, HU_BGID);
    io_uring_queue_exit(&ring);
  }
  int n;
  if (ok) {
    hu_setup_text(setup, sizeof(setup), flags);
    n = snprintf(hu_probe_json, sizeof(hu_probe_json), "{\"ok\":true,\"kernel\":\"%s\",\"setup\":\"%s\"}", kernel, setup);
  } else {
    char k[160];
    hu_json_escape(msg, sizeof(msg), hu_err_msg);
    hu_json_escape(k, sizeof(k), kernel);
    n = snprintf(hu_probe_json, sizeof(hu_probe_json), "{\"ok\":false,\"code\":\"%s\",\"message\":\"%s\",\"kernel\":\"%s\"}", hu_err_code, msg, k);
  }
  if (n < 0) n = 0;
  if ((size_t)n >= sizeof(hu_probe_json)) n = (int)sizeof(hu_probe_json) - 1;
  return (HeyNativeUtf8View){hu_probe_json, (size_t)n};
}

HeyNativeUtf8View hey_io_uring_open_error(void) {
  char msg[600];
  hu_json_escape(msg, sizeof(msg), hu_err_msg);
  int n = snprintf(hu_err_json, sizeof(hu_err_json), "{\"code\":\"%s\",\"message\":\"%s\"}",
                   hu_err_code[0] ? hu_err_code : "io_uring_unknown", msg);
  if (n < 0) n = 0;
  if ((size_t)n >= sizeof(hu_err_json)) n = (int)sizeof(hu_err_json) - 1;
  return (HeyNativeUtf8View){hu_err_json, (size_t)n};
}

/* ---- public functions ---------------------------------------------------- */

static unsigned hu_pow2(unsigned v, unsigned lo, unsigned hi) {
  if (v < lo) v = lo;
  if (v > hi) v = hi;
  unsigned p = 1;
  while (p < v) p <<= 1;
  return p;
}

HeyNativeHandle hey_io_uring_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport,
                                  int32_t sq_entries, int32_t cq_entries, int32_t buffers, int32_t buffer_size) {
  hu_clear_error();
  char host_c[64];
  if (host.length >= sizeof(host_c)) { hu_fail("io_uring_bad_address", "host is too long"); return (HeyNativeHandle)0; }
  memcpy(host_c, host.data, host.length);
  host_c[host.length] = '\0';
  struct sockaddr_in addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons((uint16_t)port);
  if (inet_pton(AF_INET, host_c, &addr.sin_addr) != 1) {
    hu_fail("io_uring_bad_address", "%s is not an IPv4 address", host_c);
    return (HeyNativeHandle)0;
  }

  unsigned sq = hu_pow2(sq_entries > 0 ? (unsigned)sq_entries : HU_DEFAULT_SQ, 8, 32768);
  unsigned cq = hu_pow2(cq_entries > 0 ? (unsigned)cq_entries : sq * 4, sq, 65536);
  /* A (re-)armed multishot accept takes the whole listen queue at once; the
     CQ must hold all of it, or Linux 6.8 loses a connection (see
     hu_arm_accept_safely). So the CQ is at least twice the listen queue the
     kernel will really keep (backlog, capped by net.core.somaxconn). */
  unsigned queue = (unsigned)(backlog > 0 ? backlog : 4096);
  FILE *somax = fopen("/proc/sys/net/core/somaxconn", "r");
  if (somax) {
    unsigned cap = 0;
    if (fscanf(somax, "%u", &cap) == 1 && cap > 0 && cap < queue) queue = cap;
    fclose(somax);
  }
  if (cq < 2 * queue) cq = hu_pow2(2 * queue, sq, 65536);
  unsigned nbufs = hu_pow2(buffers > 0 ? (unsigned)buffers : HU_DEFAULT_BUFFERS, 4, 32768);
  unsigned bsize = (unsigned)(buffer_size > 0 ? buffer_size : HU_DEFAULT_BUFFER_SIZE);
  if (bsize < 256) bsize = 256;
  if (bsize > (1u << 20)) bsize = 1u << 20;

  /* The fixed-file table may be as large as the descriptor allowance: raise
     the soft limit to the hard one (as hey_epoll does) and use that. */
  struct rlimit rl;
  uint64_t slots = 65536;
  if (getrlimit(RLIMIT_NOFILE, &rl) == 0) {
    if (rl.rlim_cur < rl.rlim_max) {
      rl.rlim_cur = rl.rlim_max;
      (void)setrlimit(RLIMIT_NOFILE, &rl);
      (void)getrlimit(RLIMIT_NOFILE, &rl);
    }
    slots = rl.rlim_cur == RLIM_INFINITY ? HU_MAX_SLOTS : (uint64_t)rl.rlim_cur;
  }
  if (slots > HU_MAX_SLOTS) slots = HU_MAX_SLOTS;
  if (slots < 16) slots = 16;

  HuLoop *loop = (HuLoop *)calloc(1, sizeof(HuLoop));
  if (!loop) { hu_fail("io_uring_no_memory", "no memory for the loop"); return (HeyNativeHandle)0; }
  loop->listener = -1;
  loop->slots = (uint32_t)slots;
  loop->nbufs = nbufs;
  loop->buf_size = bsize;
  if (!hu_setup(&loop->ring, sq, cq, HU_MIN_KERNEL, HU_SYSCTL, &loop->setup_flags, loop->kernel, sizeof(loop->kernel))) {
    free(loop);
    return (HeyNativeHandle)0;
  }
  hu_setup_text(loop->setup_text, sizeof(loop->setup_text), loop->setup_flags);
  if (!hu_register(&loop->ring, loop->slots, nbufs, &loop->br)) {
    io_uring_queue_exit(&loop->ring);
    free(loop);
    return (HeyNativeHandle)0;
  }
  loop->bufs_bytes = (size_t)nbufs * bsize;
  void *mem = mmap(NULL, loop->bufs_bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (mem == MAP_FAILED) {
    io_uring_free_buf_ring(&loop->ring, loop->br, nbufs, HU_BGID);
    io_uring_queue_exit(&loop->ring);
    free(loop);
    hu_fail("io_uring_no_memory", "no memory for %u receive buffers of %u bytes", nbufs, bsize);
    return (HeyNativeHandle)0;
  }
  loop->bufs = (char *)mem;
  for (unsigned i = 0; i < nbufs; i++) hu_recycle(loop, i);
  hu_publish_buffers(loop);

  int lfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
  int one = 1;
  int listen_ok = lfd >= 0;
  if (listen_ok) {
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    if (reuseport) setsockopt(lfd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(one));
    /* Accepted sockets inherit TCP_NODELAY from the listener on Linux; a
       direct descriptor cannot be given socket options from user space. */
    setsockopt(lfd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    listen_ok = bind(lfd, (struct sockaddr *)&addr, sizeof(addr)) == 0 && listen(lfd, backlog > 0 ? backlog : 4096) == 0;
  }
  if (!listen_ok) {
    int e = errno;
    if (lfd >= 0) close(lfd);
    munmap(loop->bufs, loop->bufs_bytes);
    io_uring_free_buf_ring(&loop->ring, loop->br, nbufs, HU_BGID);
    io_uring_queue_exit(&loop->ring);
    free(loop);
    hu_fail("io_uring_listen_failed", "could not listen on %s:%d: %s", host_c, port, strerror(e));
    return (HeyNativeHandle)0;
  }
  socklen_t alen = sizeof(addr);
  getsockname(lfd, (struct sockaddr *)&addr, &alen);
  loop->listener = lfd;
  loop->port = ntohs(addr.sin_port);

  /* Arm the multishot accept now and look for an immediate refusal (a kernel
     without multishot accept answers -EINVAL at once). */
  hu_arm_accept(loop);
  (void)io_uring_submit_and_get_events(&loop->ring);
  loop->submits++;
  struct io_uring_cqe *cqe = NULL;
  if (io_uring_peek_cqe(&loop->ring, &cqe) == 0 && cqe && (cqe->user_data & 0xff) == OP_ACCEPT && cqe->res == -EINVAL) {
    io_uring_cqe_seen(&loop->ring, cqe);
    close(lfd);
    munmap(loop->bufs, loop->bufs_bytes);
    io_uring_free_buf_ring(&loop->ring, loop->br, nbufs, HU_BGID);
    io_uring_queue_exit(&loop->ring);
    free(loop);
    hu_fail("io_uring_missing_feature", "this kernel refused a multishot accept into the fixed-file table (5.19)");
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)loop;
}

int32_t hey_io_uring_close(HeyNativeHandle value) {
  HuLoop *loop = hu_loop(value);
  if (!loop) return -1;
  loop->closing = 1;
  if (!loop->broken) {
    /* hey_epoll's send() has written a reply by the time it returns; here the
       write happens in the next submit. Deliver what is queued (bounded)
       before closing, so close() after send() means the same thing. */
    int64_t deadline = hu_now_ms() + HU_CLOSE_GRACE_MS;
    for (;;) {
      int sending = 0;
      for (size_t s = 0; s < loop->conns_cap && !sending; s++) {
        HuConn *c = &loop->conns[s];
        if ((c->flags & F_OPEN) && ((c->flags & F_SENDING) || c->out_len > 0 || c->flight_sent < c->flight_len)) sending = 1;
      }
      if (!sending || hu_now_ms() >= deadline) break;
      hu_prepare(loop);
      if (hu_enter(loop, 20) < 0) break;
      hu_drain(loop);
    }
  }
  for (size_t s = 0; s < loop->conns_cap; s++) if (loop->conns[s].flags & F_OPEN) hu_close_conn(loop, (uint32_t)s);
  if (!loop->broken) {
    struct io_uring_sqe *sqe = hu_sqe(loop);
    if (sqe) {
      io_uring_prep_cancel64(sqe, 0, IORING_ASYNC_CANCEL_ANY);   /* the accept, and anything left */
      sqe->flags |= IOSQE_CQE_SKIP_SUCCESS;
      io_uring_sqe_set_data64(sqe, hu_tag(OP_CANCEL, 0, 0));
    }
    int64_t deadline = hu_now_ms() + HU_EXIT_GRACE_MS;
    while (hu_now_ms() < deadline) {
      hu_prepare(loop);
      if (hu_enter(loop, loop->outstanding ? 20 : 0) < 0) break;
      hu_drain(loop);
      if (loop->outstanding == 0 && loop->close_backlog.len == 0) break;
    }
  }
  int quiet = loop->outstanding == 0;
  if (quiet) {
    io_uring_free_buf_ring(&loop->ring, loop->br, loop->nbufs, HU_BGID);
  }
  io_uring_queue_exit(&loop->ring);
  if (loop->listener >= 0) close(loop->listener);
  if (quiet) {
    munmap(loop->bufs, loop->bufs_bytes);
    for (size_t i = 0; i < loop->orphans_len; i++) free(loop->orphans[i].buffer);
  }
  /* Otherwise the kernel may still own the receive buffers and a send's bytes:
     leaking them is safe, freeing them is not. */
  free(loop->orphans);
  free(loop->conns);
  free(loop->ready.items);
  free(loop->pending.items);
  free(loop->dirty.items);
  free(loop->rearm.items);
  free(loop->close_backlog.items);
  free(loop);
  return quiet ? 0 : 1;
}

int32_t hey_io_uring_wait(HeyNativeHandle value, int32_t timeout_ms) {
  HuLoop *loop = hu_loop(value);
  if (!loop || loop->broken) return -1;
  /* Connections of the last batch that Hey did not take (it may stop early to
     bound a batch) are carried into this one; the ones it took wait for new
     input or for a send() that leaves pipelined bytes behind. */
  size_t untaken_from = loop->ready_pos;
  for (size_t i = 0; i < loop->ready.len; i++) {
    uint32_t slot = loop->ready.items[i];
    if (slot < loop->conns_cap) loop->conns[slot].flags &= ~(uint32_t)F_QUEUED;
    if (i >= untaken_from) (void)hu_push(&loop->pending, slot);
  }
  loop->ready.len = loop->ready_pos = 0;
  size_t carried = loop->pending.len;
  for (size_t i = 0; i < carried; i++) {
    uint32_t slot = loop->pending.items[i];
    if (slot < loop->conns_cap && (loop->conns[slot].flags & F_OPEN)) hu_mark_ready(loop, slot);
  }
  loop->pending.len = 0;
  int timeout = loop->ready.len ? 0 : timeout_ms;
  loop->waits++;
  int64_t deadline = timeout > 0 ? hu_now_ms() + timeout : 0;
  for (;;) {
    hu_prepare(loop);
    int left = timeout;
    if (timeout > 0) {
      int64_t now = hu_now_ms();
      left = now >= deadline ? 0 : (int)(deadline - now);
    }
    if (hu_enter(loop, left) < 0) { loop->broken = 1; return -1; }
    hu_drain(loop);
    /* Completions that were not input (an accept, a send) do not end the
       wait: it returns when a connection has input or the time is up. */
    if (loop->ready.len > 0 || left == 0) break;
  }
  loop->batches_ready += loop->ready.len;
  return (int32_t)loop->ready.len;
}

int64_t hey_io_uring_next(HeyNativeHandle value) {
  HuLoop *loop = hu_loop(value);
  if (!loop) return -1;
  while (loop->ready_pos < loop->ready.len) {
    uint32_t slot = loop->ready.items[loop->ready_pos++];
    if (slot < loop->conns_cap) {
      HuConn *c = &loop->conns[slot];
      if ((c->flags & F_OPEN) && c->in_len > c->in_off) return hu_id(loop, slot);
    }
  }
  return -1;
}

HeyNativeUtf8View hey_io_uring_data(HeyNativeHandle value, int64_t id) {
  HuLoop *loop = hu_loop(value);
  uint32_t slot = 0;
  HuConn *c = hu_lookup(loop, id, &slot);
  if (!c || c->in_len == c->in_off) return (HeyNativeUtf8View){"", 0};
  const char *start = c->in + c->in_off;
  size_t len = c->in_len - c->in_off;
  int bad = 0;
  size_t ok = hu_text_prefix((const unsigned char *)start, len, &bad);
  if (bad) {
    loop->invalid_text++;
    hu_close_conn(loop, slot);
    return (HeyNativeUtf8View){"", 0};
  }
  return (HeyNativeUtf8View){start, ok};
}

int32_t hey_io_uring_send(HeyNativeHandle value, int64_t id, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after) {
  HuLoop *loop = hu_loop(value);
  uint32_t slot = 0;
  HuConn *c = hu_lookup(loop, id, &slot);
  if (!c) return 0;
  size_t available = c->in_len - c->in_off;
  size_t take = consumed < 0 ? 0 : (size_t)consumed;
  if (take > available) take = available;
  c->in_off += (uint32_t)take;
  if (c->in_off == c->in_len) {
    /* An idle keep-alive connection keeps no buffer. */
    c->in_off = c->in_len = 0;
    free(c->in);
    c->in = NULL;
    c->in_cap = 0;
  }
  if (close_after) c->flags |= F_WANT_CLOSE;
  if (data.length > 0) {
    size_t need = c->out_len + data.length;
    if (need > c->out_cap) {
      size_t cap = c->out_cap ? c->out_cap : 4096;
      while (cap < need) cap *= 2;
      char *grown = (char *)realloc(c->out, cap);
      if (!grown) { hu_close_conn(loop, slot); return 0; }
      c->out = grown;
      c->out_cap = cap;
    }
    memcpy(c->out + c->out_len, data.data, data.length);
    c->out_len += data.length;
  }
  if (c->out_len > 0 || (c->flags & F_WANT_CLOSE)) hu_mark_dirty(loop, slot);
  /* Pipelined input after this request: offer it again on the next wait. */
  if (c->in_len > c->in_off) (void)hu_push(&loop->pending, slot);
  return 1;
}

int32_t hey_io_uring_drop(HeyNativeHandle value, int64_t id) {
  HuLoop *loop = hu_loop(value);
  uint32_t slot = 0;
  if (!hu_lookup(loop, id, &slot)) return 0;
  hu_close_conn(loop, slot);
  return 1;
}

int32_t hey_io_uring_port(HeyNativeHandle value) {
  HuLoop *loop = hu_loop(value);
  return loop ? loop->port : -1;
}

HeyNativeUtf8View hey_io_uring_stats(HeyNativeHandle value) {
  HuLoop *loop = hu_loop(value);
  if (!loop) return (HeyNativeUtf8View){"{}", 2};
  char kernel[160];
  hu_json_escape(kernel, sizeof(kernel), loop->kernel);
#define U(x) (unsigned long long)(x)
  int n = snprintf(loop->stats_text, sizeof(loop->stats_text),
    "{\"backend\":\"%s\",\"live\":%llu,\"accepted\":%llu,\"closed\":%llu,\"waits\":%llu,\"ready\":%llu,"
    "\"bytes_in\":%llu,\"bytes_out\":%llu,\"accept_errors\":%llu,\"oversize\":%llu,\"invalid_text\":%llu,\"partial_writes\":%llu,"
    "\"submits\":%llu,\"early_submits\":%llu,\"submit_errors\":%llu,\"sqes\":%llu,\"cqes\":%llu,\"cq_overflow_flushes\":%llu,"
    "\"cq_dropped\":%llu,\"enobufs\":%llu,\"recv_rearms\":%llu,\"accept_rearms\":%llu,\"recv_errors\":%llu,\"send_errors\":%llu,"
    "\"table_full\":%llu,\"accept_lost\":%llu,\"slot_conflicts\":%llu,\"orphaned\":%llu,\"leaked_buffers\":%llu,\"outstanding\":%llu,"
    "\"slots\":%u,\"sq_entries\":%u,\"cq_entries\":%u,\"buffers\":%u,\"buffer_size\":%u,\"setup\":\"%s\",\"kernel\":\"%s\"}",
    HU_BACKEND, U(loop->live), U(loop->accepted), U(loop->closed), U(loop->waits), U(loop->batches_ready),
    U(loop->bytes_in), U(loop->bytes_out), U(loop->accept_errors), U(loop->oversize), U(loop->invalid_text), U(loop->partial_writes),
    U(loop->submits), U(loop->early_submits), U(loop->submit_errors), U(loop->sqes), U(loop->cqes), U(loop->cq_overflow_flushes),
    U(loop->ring.cq.koverflow ? *loop->ring.cq.koverflow : 0), U(loop->enobufs), U(loop->recv_rearms), U(loop->accept_rearms),
    U(loop->recv_errors), U(loop->send_errors), U(loop->table_full), U(loop->accept_lost), U(loop->slot_conflicts), U(loop->orphaned), U(loop->leaked_buffers),
    U(loop->outstanding), loop->slots, loop->ring.sq.ring_entries, loop->ring.cq.ring_entries, loop->nbufs, loop->buf_size,
    loop->setup_text, kernel);
#undef U
  if (n < 0) n = 0;
  if ((size_t)n >= sizeof(loop->stats_text)) n = (int)sizeof(loop->stats_text) - 1;
  return (HeyNativeUtf8View){loop->stats_text, (size_t)n};
}

HeyNativeUtf8View hey_io_uring_backend(void) {
  return (HeyNativeUtf8View){HU_BACKEND, sizeof(HU_BACKEND) - 1};
}
