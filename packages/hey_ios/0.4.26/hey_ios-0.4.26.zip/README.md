# hey_ios

Apple-specific capability contracts layered under `hey_mobile`. This first slice declares UIKit lifecycle hosting, Keychain, LocalAuthentication, protected files, AVFoundation QR scanning, URLSession, Apple frameworks, and entitlement metadata. Native adapters remain opaque; no Keychain item, LAContext, key, or UIKit object crosses into ordinary Hey values.

Compiler/SDK/sign/install/launch porcelain for ordinary Hey iOS apps remains in the Hey language repository under `hey mobile ios ...`.

## Search screens show something before a search; driving-aware screens (0.4.23)

A `search` screen may add `idle_sections` and `idle_source`. With nothing
typed, the renderer reads `idle_source` once, like a list screen's `source`,
and draws `idle_sections` (rows, `from` lists, row actions) under the search
field. Typing replaces them with the search's own sections; emptying the
field, or the screen coming back into view, reads them again.

A screen with `driving_aware: true` starts Core Motion activity updates when
it appears, and only when the app was built with `--motion-driving` (which
adds `NSMotionUsageDescription` and links CoreMotion); the first start is
iOS's permission prompt. While the latest activity is automotive (medium or
high confidence) every request carries `x-hey-driving: 1`, and a shown
driving-aware screen reloads when that changes. What driving means is the
description's and its server's business.

## Picture memory budget (0.4.22)

Ordinary pictures (list rows and the picture at the top of a screen) are
bounded by memory, not by count. A download stops at 4 MiB. A picture whose
header declares more than 12000 px a side or 40 MP is refused before it is
decoded. What is kept is a thumbnail sized to where it is drawn: 256 px on the
longest side for a row, 1200 px for a header. The cache is limited to 48 MiB of
decoded bytes and keyed by address and size, so a row never holds a header's
large copy. Each picture is fetched once however many rows want it, with at
most four downloads running and 48 waiting; a row that was skipped asks again
when it is configured again. Share artwork keeps its own stricter path.

## Hierarchical form choices and standard text traits (0.4.21)

An existing `choice` field may add `choices.tree: {id, parent, selectable}`.
The ordinary `choices` method, path, list, value and label bindings still load
through the authenticated API. Tree routes permit GET in any letter case
(including the default method) with no body or an empty `body: {}`, and are
always sent as a bodyless GET; any other method or a non-empty body is refused
before transport. Tree IDs and parents, strings or numbers (a number is its
decimal text, so `7` and `"7"` are the same node), identify a forest; an empty
or null parent identifies a root. Boolean selectable controls selection, so a
structural ancestor can expand without being selected. A folder's disclosure
button expands its children independently of selecting the folder itself.
Static options remain separate roots and are available during loading and
errors, including an empty value such as “Only this item.” Ordinary flat choice
menus retain their existing behavior.

Selection updates the form draft; Cancel preserves its previous value. Neither
operation sends the form. Metadata errors offer retry, and invalid duplicate,
orphan or cyclic trees are refused. Trees are limited to 4096 remote nodes.
Delayed source and choice responses are scoped to the form and session, and a
source response cannot replace fields the user has edited or selected. A field
that is focused but not yet typed in still fills, in place. Only the newest
source request and the newest choices request per field may write; Try again
does nothing while a load is in flight.
A late source that adds or removes source-gated links, or fails, while someone
is typing redraws around the edited row, so the keyboard and cursor stay put.
Swiping the picker sheet down finishes exactly like Cancel.

Ordinary text, prose and multiline editors use sentence capitalization and
default correction. A field with id `username` gets neither, whatever its
kind (multiline and code included), so a name is
sent exactly as typed and only the server folds its case. Structured URL,
password and code inputs retain their specialized traits. These are keyboard
suggestions: the renderer never changes string case and preserves multiline
authored text. A selectable remote choice must have a value that differs from
every static option, or the whole tree is refused as malformed.

`HEY_IOS_SIM_UDID=<simulator> bin/check-tree-choice` runs the real UIKit
control with synthetic data and sessions. `HEY_IOS_TREE_CONTROL` selects one of
`duplicate`, `lifetime`, `private`, `traits`, `transport`, `loading`, `tint`,
`shape`, `swipe`, `blank`, `focus`, `untyped`, `stale`, `inflight`, `reload` or
`sheet`; each mutation must compile and
fail the native assertions. No real accounts or external messages are used.

## Visible confirmations in scrolled lists (0.4.20)

Confirmation popovers stay anchored within the visible list after scrolling. The generic UIKit regression checks the scrolled anchor, cancellation without execution, and one confirmed execution; the existing share-sheet behavior is unchanged. Run `HEY_IOS_SIM_UDID=<owned simulator> bin/check-confirmation` for the native check.

## Standard keyboard dictation (0.4.19)

Search, multiline prose, single-line text and prompt fields use ordinary UIKit text inputs with the system keyboard. Tap the keyboard's microphone to dictate when dictation is enabled and available on the device. Apple owns listening, waveform, completion and insertion at the current selection; the renderer has no recording control, speech recognizer or private keyboard launcher. Editing remains a draft until the user explicitly chooses Search, Save or Send.

The existing `speech_input` description flag remains compatible across platforms; iOS needs no app microphone or speech permission for keyboard dictation. The build tool's legacy `--speech-input` metadata switch remains accepted for compatibility, but is unnecessary for this input method. Secure and structured fields retain their normal keyboard traits.

`bin/check-standard-input` exercises real UIKit search, prose and prompt input against synthetic values, selected-range insertion, cursor placement, multiline preservation and absence of recording controls. Simulator verification covers editing and keyboard focus; actual microphone recognition and keyboard availability require a physical device with dictation enabled.

## Sharing after a form save (0.4.17)

A rich share opens the system sheet immediately with the exact authored text followed by the return URL in one plain-text item. Its artwork is one promised image attachment in `UIActivityItemsConfiguration`. No separate rich-link item or preview image is exported, avoiding a second image in external targets. Targets load that attachment asynchronously; a stalled image no longer prevents the sheet opening. Artwork has an eight-second absolute deadline, a 4 MiB compressed-body limit and source-image limits (12 million pixels, 8192 per side, at most 8-bit depth). ImageIO downsamples accepted artwork to at most 1024 pixels per side and 8 MiB decoded storage. A refusal or failure visibly leaves the text/link available for sharing again. Leaving the originating screen or changing accounts prevents late image delivery.

A form can opt into post-save sharing with `primary.on_success.share_retry_title`, alongside its existing `share` response path. The supplied title becomes the primary button after a successful save. Pressing it with unchanged values shares the exact retained response without a POST or GET. Cancelling sharing keeps that result. Editing restores the ordinary primary action for an explicitly new save; leaving the form or changing sessions purges the retained response. A missing/invalid share payload reports a visible failure and cannot cause a duplicate save on retry. Routes and wording stay in the app's Hey description.

`bin/check-reply-share` runs actual app/scene delegates, the multiline editor and `UIActivityViewController` against synthetic sessions and transport. It loads the target-facing text, URL and image providers, checks artwork pixels and downsampling, cancellation/retry counts, edits, account/leave cleanup, delayed responses, failed/dripping/oversized/malformed images and missing share payloads. Attachment-removal and duplicate-POST mutations must fail. `HEY_IOS_SHARE_CASE` selects one case; `HEY_IOS_SIM_UDID` selects the simulator.

## Bundled UI only (0.4.15)

Hey modules generate the platform description at build time; the shipped app always draws that bundled UI. The host has no definition downloader, downloaded-description cache reader/writer, or pending UI replacement. Launch, foreground and manual refresh request content/state through the bundled routes. A legacy `served` field and valid definitions stored by older builds cannot enable runtime UI delivery. Offline launch still reads the bundle.

`bin/check-baked-ui` compiles the actual Foundation selector and runs a synthetic app with the shipped app delegate, scene delegate and UIKit controllers. It covers valid stored/served overrides, a matching legacy disk cache, cold launch, foreground, manual refresh and offline startup/resume, while checking authenticated content and badge refresh. All transport and sessions are synthetic. `--selection-only` runs the Mac gate without a simulator. Offline description validation and value conformance helpers remain available to build tools.

## Copying displayed text (0.4.12)

Static content text can be copied with the platform gesture. A touch and hold on a label (a title or a header line) or on a detail field row (`fields` sections: description, note, message, tags) shows the system Copy menu, and Copy puts the whole displayed value on the pasteboard, ready to paste into a search field. Each also has a VoiceOver Copy action. Buttons, text fields and text views are left alone, and a reused table cell always copies its current value.

`bin/check-copy-text` checks the source contract and the synthetic fixture `specs/fixtures/native_copy_text_description.json`. On a booted simulator running that fixture against `specs/support/copy_text_api_server.py`, `bin/check-copy-text-simulator` copies the title and five fields, pastes each into search and checks the request the server saw, and `bin/check-copy-text-accessibility` checks each field's value and Copy action. Run them without Simulator.app open: its pasteboard sync copies the Mac's clipboard into the simulator.

## Header artwork links (0.4.11)

A screen header may set `"image_open_url": "item.canonical_url"` beside its `image` binding. The renderer resolves this value against the screen JSON and makes only the artwork a link, announced as “Open content” by VoiceOver. A tap opens the resolved absolute HTTP(S) URL through the same system browser API as `open_url`. Missing, empty, relative, or unsafe destinations leave the artwork inert; the title and body remain ordinary text. Descriptions without the optional field render as before.

`bin/check-header-image-link` executes the actual UIKit header on the simulator, checking the opened URL, accessibility, text isolation, and inert cases. Four negative controls break binding resolution, validation, browser destination, and accessibility, and each must fail. The host also syntax-compiles with `-Werror`.

## Searchable multi-select sheets (0.4.3)

A level-3 `choose_many` can now consume `choices.search` from `hey_mobile 0.3.4`. The sheet keeps its current ticked values while remote results arrive, merges unseen results by value, and computes Done from the post-search option set. The search route and option mapping stay in the description; the native host remains product-neutral.

`HeyIOSMergeOptions` is Foundation-only and runs against the same new level-3 conformance vectors as `hey_mobile`. `bin/check-searchable-choose-many` additionally syntax-checks the actual UIKit host for the iOS Simulator and proves the search bridge calls that helper.

## The running time and the skip controls, on the 0.4.x line (0.4.2)

The now playing bar's elapsed and total time, and the jump-back and
jump-on controls, were released as 0.3.4 and 0.3.5 from a branch. `main`
went to 0.4.0 and 0.4.1 without them, so the two newest releases did not
have what the two before them did: an app taking 0.4.1 lost the timer and
the skip buttons, and an app keeping 0.3.5 had no `--distribution` and no
level-3 audio. Nothing said so.

This rebases that work onto `main`, so 0.4.2 is the first release with
both. The native merge was clean; only the version declarations
conflicted.

- **The running time.** `currentSeconds` and `currentDuration`, reported
  while a thing plays.
- **The skips.** `skipBy:` with `HeyIOSAudioSkipBack` (15s) and
  `HeyIOSAudioSkipOn` (30s), and the remote commands that carry those
  preferred intervals to the lock screen and the car.
- **Two rows.** `buildNowPlaying` lays the bar out in two rows with
  `sizeNowPlaying`. On one row the clock truncated to "12:3…" and the
  play and forward buttons were pushed off screen on a 6.1-inch phone.

## A profile that grants Associated Domains is read as one (0.4.1)

0.4.0 read a profile's Associated Domains grant in a format that refuses a bare string, and profiles grant it as the string `*`, so `--associated-domain` stopped every device and distribution build, granted or not. The grant is read as XML now; `bin/package-check` runs the tool's own function on a string grant, a list grant and a profile without it.

## Level 3, audio with no credential, App Store packs and universal links (0.4.0)

- **Renderer level 3** (`hey_mobile` 0.3.2). `choose_many` lists the options with a tick beside each and a Done button; what follows sends `$values`, a list, and can say `{value_titles}`. A form lookup's `offers` draws what the lookup found as one button under a field the viewer typed something else in; a tap puts it in. `bin/conformance` runs `level3.json` as well as the level-2 vectors, with a second negative control (level 3 without `choose_many`). A level-2 description draws as before.
- **No credential rides on an audio fetch.** `HeyIOSAudio` plays every page from a plain `AVURLAsset` with no options. `headersForURL` is gone (that is why this is 0.4.0): an app sets `resolveAddress` instead, and the host does so from the description's `audio.sign` route, which exchanges an address on the app's own server for a short-lived one that needs no header. Each page is resolved just before it plays, and once more if it fails while playing. `bin/package-check` fails if the request-header asset option appears in the native code, with a control. An app whose server protects audio with the session header must add a sign route.
- **App Store packs.** `tools/hey-ios-api-app.sh --distribution` builds for iphoneos, signs with App Store profiles (get-task-allow false), stamps the Xcode provenance keys and writes `<Name>.ipa`; nothing is installed.
- **Universal links.** `--associated-domain HOST` signs a device or distribution build with `applinks:HOST`. A profile that does not grant Associated Domains stops the build with the portal step. A simulator build claims no domain.

## Signing in no longer crashes on a phone (0.3.1)

In 0.3.0 the Sign in button could close the app on an iPhone. The form's requests run as a chain of blocks, and the last step freed the running block before it read what it needed to finish. The simulator happened not to reuse that memory, so it always looked fine there. Dragging a row to reorder a list had the same fault. Both are fixed. `bin/block-lifetimes` (run by `bin/package-check`) builds the host for the iOS Simulator with AddressSanitizer, runs both chains against a stubbed request, and checks that each one fails with a heap-use-after-free when its fix is reverted.

Gotcha: a block kept alive only by a `__block` reference to itself (`hold = run`) must copy every capture it still needs into locals before it sets that reference to nil.

## Historical level-2 renderer with served descriptions (0.3.0)

The runtime delivery described below was removed in 0.4.15.

`hey_mobile` 0.3.0 lets a server send an app its screens. This host is a renderer at level 2 of that contract (`api-renderer.json`; `docs/RENDERERS.md` in hey_mobile):

- **Served, stored, baked.** On launch it draws the last good served copy this build stored, else the baked copy, at once. On launch and on every return to the foreground it asks the description's `served` route (`?platform=ios&level=2`, `If-None-Match` the copy in hand, no credentials) and draws a new copy it takes when nothing is in progress. A network failure, an error status or a refused body changes nothing. The origin, the session header and checks, the Keychain service and the url scheme always come from the baked copy.
- **Hide what you do not know.** An unknown screen type, section, action, field or row kind is not drawn, and no action it does not recognise sends a request.
- **One evaluator.** `native/HeyIOSValues.{h,m}` (Foundation only) holds the value language, the kinds, icon and file-kind names and the rules for taking a served body. `bin/conformance` compiles it for this Mac and runs hey_mobile's `conformance/` vectors against it, with a negative control; `bin/package-check` runs it.
- The Hey shell may export `fn ios_app_origin()`: the origin, baked beside a description whose bytes are the server's.

## The native host for api_screens apps (0.2.0)

An app described with `hey_mobile` 0.2.0 `api_screens` runs on iPhone through this package. Nothing here names a product, a route or a service: the description decides every screen and request.

| file | what it is |
|---|---|
| `native/HeyIOSApiHost.{h,m}` | the bundled renderer: tabs, lists, forms, search with polling, sign-in, deep links, document upload, video, web links, badges and the Listen tab |
| `native/HeyIOSValues.{h,m}` | the value language, kinds, names and offline description validation, Foundation only |
| `native/HeyIOSKeychain.{h,m}` | the session token, readable after first unlock |
| `native/HeyIOSAudio.{h,m}` | playback through AVQueuePlayer (pages in order, resume, position reports) or Apple Music, Now Playing and remote commands, the running time (`currentSeconds`, `currentDuration`) and jumps back and on (`skipBy:`) |
| `native/HeyIOSShareController.{h,m}` | a share extension that saves a link through the description's share route |
| `audio.hey` | the audio capability contract (background mode, session category, Info.plist keys) |
| `tools/hey-ios-api-app.sh` | compiles the Hey shell through the LLVM lane (no Hey runtime linked), links the host, builds the share extension and icon, signs, installs on a simulator or a paired iPhone |

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
  "$HEY_IOS/tools/hey-ios-api-app.sh" --source ios/app.hey --out build/ios \
  --bundle-id com.example.app --display-name 'Example' --share-extension \
  --url-scheme example --icon-png build/AppIcon-1024.png [--sim-udid UDID]
# a paired iPhone: --device-udid ID --sign-identity "Apple Development: ..." --profile P --extension-profile P
```

The Hey shell exports `fn ios_app_manifest()` (the description as a literal string) and `fn ios_manifest_length()` (its byte length). The build tool still accepts the legacy `ios_action_code(0)` contract when the compiler emits its original runtime-free `i64 -> i64` ABI; current pointer-shaped legacy exports are rejected because this shell deliberately links no Hey runtime.

### Extensions (`--extension DIR`)

Another package adds native code to the app through `DIR/ios-extension.json`: sources compiled beside the host, frameworks, entitlements (linked into a simulator build, carried on a device only when the profile grants them) and scene declarations for Info.plist. The host configures any scene role other than the phone's window from that declaration, and a scene reads the audio feed with `HeyIOSApiHostLoadAudioFeed`, re-reading on `HeyIOSApiHostAudioFeedDidChange`. `hey_carplay` (the CarPlay audio scene) is the first extension. `--with carplay` from the unpublished working copy is gone.

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_ios`.
