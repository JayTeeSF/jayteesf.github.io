# Done

- 0.1.0: extracted the pure catalog/chain i18n kernel from the
  RecallCoach prototype; folded catalog-aware Accept-Language negotiation
  into locale_for_request.
- 0.1.2: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes. Declares hey_packager as ">=0.1.1 <0.2.0".
