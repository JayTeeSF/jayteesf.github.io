package hey.android.api;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Running an action a description names. This is the only place a tap becomes
 * a request, and it refuses first: AN ACTION THIS BUILD DOES NOT DRAW DOES
 * NOTHING. It is hidden where it would be drawn (Screens), and refused again
 * here, so no path sends its request. Pure Java, driven by the host tests with
 * a recording transport.
 */
public final class Actions {
  private Actions() {}

  public interface Reply {
    void done(int status, Object json, String error);
  }

  public interface Transport {
    /** Send a route with its path filled from vars and its body from body(route, vars, row). */
    void send(Map<String, Object> route, Map<String, Object> vars, Object row, Reply reply);
  }

  public interface Host {
    Map<String, Object> vars();

    Object screenJson();

    Map<String, Object> labels();

    void confirm(String title, String message, String button, boolean destructive, Runnable then);

    /** Asks for the action's prompt fields; calls then with the variables and the typed text (prompted), or not at all when cancelled or incomplete. */
    void prompt(Map<String, Object> action, Object row, Map<String, Object> vars, java.util.function.Consumer<Map<String, Object>> then);

    void openScreen(String id, Map<String, Object> params);

    void openUrl(String address);

    /** Play a film in the app, rather than handing its address to another one. */
    void playVideo(String address);

    void toast(String text);

    void alert(String title, String message);

    void signOut();

    void pop();

    void reload();
  }

  /** A request body: each value through Values.value; an omitted one is left out. null when the route has no body. */
  public static Map<String, Object> body(Map<String, Object> route, Map<String, Object> vars, Object row) {
    if (!(route.get("body") instanceof Map)) return null;
    Map<String, Object> out = new LinkedHashMap<>();
    for (Map.Entry<String, Object> e : Json.dict(route.get("body")).entrySet()) {
      Object v = Values.value(e.getValue(), vars, row);
      if (v != Values.OMIT) out.put(e.getKey(), v);
    }
    return out;
  }

  /** The screen's variables, plus '@name' for each text or number in the screen's answer, then in the row. */
  public static Map<String, Object> varsWith(Host host, Object row) {
    Map<String, Object> vars = new LinkedHashMap<>(Json.dict(host.vars()));
    for (Object source : new Object[] {host.screenJson(), row}) {
      if (!(source instanceof Map)) continue;
      for (Map.Entry<String, Object> e : Json.dict(source).entrySet()) {
        Object v = e.getValue();
        if (v instanceof String || (v instanceof Number)) vars.put("@" + e.getKey(), v);
      }
    }
    return vars;
  }

  /** Runs the action; false, with nothing sent, when this build does not draw it. */
  public static boolean run(Map<String, Object> action, Object row, Host host, Transport transport) {
    if (!Screens.drawsAction(action)) return false;
    Map<String, Object> vars = varsWith(host, row);
    String kind = Values.actionKind(action);
    Object subject = row != null ? row : host.screenJson();
    Runnable go;
    switch (kind) {
      case "open_url":
        go = () -> {
          String address = Values.line(action.get("value"), subject, host.labels());
          if (!address.isEmpty()) host.openUrl(address);
        };
        break;
      case "video":
        go = () -> {
          String address = Values.line(action.get("value"), subject, host.labels());
          if (!address.isEmpty()) host.playVideo(address);
        };
        break;
      case "open_screen":
        go = () -> host.openScreen(Values.string(action.get("screen")), Screens.params(action.get("params"), vars, row, host.screenJson()));
        break;
      default:
        go = () -> {
          if (!Json.dict(action.get("prompt")).isEmpty()) host.prompt(action, row, vars, ready -> send(action, ready, row, host, transport));
          else send(action, vars, row, host, transport);
        };
    }
    Map<String, Object> confirm = Json.dict(action.get("confirm"));
    if (!confirm.isEmpty()) {
      host.confirm(Values.string(confirm.get("title")), Values.string(confirm.get("message")), Values.string(confirm.get("button")),
          "destructive".equals(action.get("style")), go);
    } else {
      go.run();
    }
    return true;
  }

  /** What a prompt's fields gave: the problem to show, or the variables with each field's trimmed text as $id. */
  public static final class Prompted {
    public final String problem;
    public final Map<String, Object> vars;

    Prompted(String problem, Map<String, Object> vars) {
      this.problem = problem;
      this.vars = vars;
    }
  }

  public static Prompted prompted(Map<String, Object> action, Map<String, Object> vars, Map<String, Object> typed) {
    Map<String, Object> next = new LinkedHashMap<>(vars);
    for (Object f : Json.list(Json.dict(action.get("prompt")).get("fields"))) {
      Map<String, Object> field = Json.dict(f);
      String text = Values.string(typed.get(Values.string(field.get("id")))).trim();
      if (Values.truthy(field.get("required")) && text.isEmpty()) return new Prompted(Values.string(field.get("label")) + " is needed.", null);
      next.put(Values.string(field.get("id")), text);
    }
    return new Prompted(null, next);
  }

  /** A prompt field's starting text: its value path read from the row, else from the screen's answer. */
  public static String prefill(Map<String, Object> field, Object row, Object screenJson) {
    String path = Values.string(field.get("value"));
    if (path.isEmpty()) return "";
    String fromRow = row == null ? "" : Values.string(Values.value("@" + path, null, row));
    return fromRow.isEmpty() && screenJson != null ? Values.string(Values.value("@" + path, null, screenJson)) : fromRow;
  }

  static void send(Map<String, Object> action, Map<String, Object> vars, Object row, Host host, Transport transport) {
    Map<String, Object> route = Json.dict(action.get("request"));
    if (route.isEmpty()) {
      after(action, vars, null, host);
      return;
    }
    transport.send(route, vars, row, (status, json, error) -> {
      if (error != null) {
        String failed = Values.string(action.get("failed_title"));
        host.alert(failed.isEmpty() ? "That did not work" : failed, error);
        return;
      }
      after(action, vars, json, host);
    });
  }

  /** After a write: its done message, then where to go ('reload' by default, 'stay', 'pop', 'sign_out', or {screen, params}). */
  static void after(Map<String, Object> action, Map<String, Object> vars, Object json, Host host) {
    Map<String, Object> both = new LinkedHashMap<>(vars);
    if (json instanceof Map) both.putAll(Json.dict(json));
    String doneSpec = Values.string(action.get("done"));
    String done = Values.render(doneSpec, both, host.labels());
    if (done.isEmpty() && !doneSpec.isEmpty() && doneSpec.indexOf('{') < 0) done = doneSpec;
    if (!done.isEmpty()) host.toast(done);
    Object then = action.get("then");
    if (then instanceof Map) {
      Map<String, Object> next = Json.dict(then);
      Map<String, Object> params = new LinkedHashMap<>();
      for (Map.Entry<String, Object> e : Json.dict(next.get("params")).entrySet()) {
        params.put(e.getKey(), Values.param(e.getValue(), vars, both, null));
      }
      if (Values.truthy(next.get("replace"))) host.pop();
      host.openScreen(Values.string(next.get("screen")), params);
      return;
    }
    String word = Values.string(then);
    switch (word) {
      case "pop": host.pop(); return;
      case "sign_out": host.signOut(); return;
      case "stay": return;
      default: host.reload();
    }
  }
}
