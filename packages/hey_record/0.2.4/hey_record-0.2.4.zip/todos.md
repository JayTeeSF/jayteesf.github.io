# Todo

1. Migration table, locking, status, up/down, and schema version receipts.
2. Validations and error collections without callbacks hidden in persistence.
3. Explicit associations and eager-loading plans.
4. Pool and partitioned Job ownership helpers supplied by adapters/app infrastructure.
5. Schema introspection and portable type mapping.
