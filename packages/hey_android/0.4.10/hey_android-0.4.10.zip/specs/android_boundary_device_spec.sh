#!/usr/bin/env bash
# Focused real Android media/account boundary checks. Owns only the AVD it boots.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-boundary-device.XXXXXX")
serial=''
server_pid=''
on_exit() {
  local result=$?
  if [ -n "$serial" ]; then
    "$HEY_ANDROID_ADB" -s "$serial" uninstall hey.android.boundary >/dev/null 2>&1 || true
    "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" || result=1
  fi
  if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi
  if [ -n "${HEY_ANDROID_BOUNDARY_EVIDENCE:-}" ]; then
    mkdir -p "$HEY_ANDROID_BOUNDARY_EVIDENCE"
    cp "$work"/*.log "$HEY_ANDROID_BOUNDARY_EVIDENCE/" 2>/dev/null || true
  fi
  rm -rf "$work"
  exit "$result"
}
trap on_exit EXIT
trap 'exit 130' INT TERM
port=3582
bash "$ROOT/specs/support/build_boundary_device.sh" "$work/apk" "$port" > "$work/build.log" 2>&1
"$HEY_ANDROID_RUBY" "$ROOT/specs/support/boundary_server.rb" "$port" "$work/requests.log" > "$work/server.log" 2>&1 &
server_pid=$!
for i in $(seq 1 40); do
  if curl --max-time 1 -fsS "http://127.0.0.1:$port/health" >/dev/null 2>&1; then break; fi
  sleep 0.1
done
curl --max-time 1 -fsS "http://127.0.0.1:$port/health" >/dev/null
"$ROOT/tools/hey-android-emulator.sh" create-avd
boot_line=$("$ROOT/tools/hey-android-emulator.sh" boot)
serial=$(printf '%s\n' "$boot_line" | tr ' ' '\n' | sed -n 's/^serial=//p')
echo "$boot_line"
"$HEY_ANDROID_ADB" -s "$serial" install -r "$work/apk/app.apk" > "$work/install.log"
"$HEY_ANDROID_ADB" -s "$serial" logcat -c
"$HEY_ANDROID_ADB" -s "$serial" shell am instrument -w -r hey.android.boundary/hey.android.api.BoundaryInstrumentation > "$work/instrument.log"
cat "$work/instrument.log"
"$HEY_ANDROID_ADB" -s "$serial" logcat -d -s 'hey.boundary:*' 'hey.api:*' > "$work/device.log"
if grep -q 'FAIL:' "$work/instrument.log" || ! grep -q 'Android boundary device checks' "$work/instrument.log"; then
  cat "$work/device.log"; exit 1
fi
"$HEY_ANDROID_RUBY" -rjson -e 'rows=File.readlines(ARGV[0]).map{|s|JSON.parse(s)}; abort("FAIL: a redirect reached its sink") if rows.any?{|r|r["path"]=="/sink"}; abort("FAIL: A position was sent under B/C") if rows.any?{|r|r["path"]=="/position/a-track" && r["account"]!="A"}; abort("FAIL: own audio was not authenticated") unless rows.any?{|r|r["path"]=="/audio.wav" && r["account"]=="A"}; puts "PASS: no redirect sink was contacted and no old-account position used a new bearer"' "$work/requests.log"
