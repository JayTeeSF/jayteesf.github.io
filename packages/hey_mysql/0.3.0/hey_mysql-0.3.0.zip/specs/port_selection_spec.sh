#!/usr/bin/env sh
# Port-selection logic for tools/dev/select-mysql-port: preference order,
# occupied-port scan, persistence, --after, and refusal of junk. No docker:
# compose detection is explicitly skipped (HEY_MYSQL_SKIP_COMPOSE_DETECTION).
#
# Ports: this box serves live MySQL over an SSH tunnel on 3308 and an app on
# 3748 -- this spec NEVER goes near either. It probes only in a high scratch
# range (46300+), and its one deliberate listener binds 127.0.0.1 in that
# range for under a second.
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
SELECT="$PACKAGE_ROOT/tools/dev/select-mysql-port"

tmp="$(mktemp -d "${TMPDIR:-/tmp}/hey-mysql-port-spec.XXXXXX")"
listener_pid=''
cleanup() {
  if test -n "$listener_pid"; then kill "$listener_pid" 2>/dev/null || true; fi
  rm -rf "$tmp"
}
trap cleanup EXIT HUP INT TERM

fail() {
  echo "FAIL: port_selection_spec: $1" >&2
  exit 1
}

run_select() {
  env -u MYSQL_PORT \
    HEY_MYSQL_PROJECT_ROOT="$tmp" \
    HEY_MYSQL_ENV_FILE="$tmp/.env" \
    HEY_MYSQL_SKIP_COMPOSE_DETECTION=1 \
    HEY_MYSQL_PORT_DEFAULT="$1" \
    HEY_MYSQL_PORT_SCAN_LIMIT=40 \
    "$SELECT" ${2:-}
}

# Find a base port with free room in the scratch range.
base=46311
while lsof -nP -iTCP:"$base" -sTCP:LISTEN >/dev/null 2>&1 || \
      lsof -nP -iTCP:"$((base + 1))" -sTCP:LISTEN >/dev/null 2>&1 || \
      lsof -nP -iTCP:"$((base + 2))" -sTCP:LISTEN >/dev/null 2>&1; do
  base=$((base + 3))
  test "$base" -lt 46500 || fail 'no free scratch ports found'
done

# 1. A free preferred port is selected, printed, and persisted.
selected="$(run_select "$base")"
test "$selected" = "$base" || fail "expected $base, got $selected"
grep -q "^MYSQL_PORT=$base\$" "$tmp/.env" || fail 'selected port was not persisted to the env file'

# 2. The persisted value is preferred on the next run (no drift).
selected="$(run_select "$((base + 2))")"
test "$selected" = "$base" || fail "persisted port should win over the default (got $selected)"

# 3. An occupied port is skipped and the next free one persisted.
occupier=''
if command -v python3 >/dev/null 2>&1; then
  python3 -c '
import socket, sys, time
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("127.0.0.1", int(sys.argv[1])))
s.listen(1)
sys.stdout.write("ready\n")
sys.stdout.flush()
time.sleep(20)
' "$base" > "$tmp/listener.out" &
  listener_pid=$!
  occupier=python3
elif command -v ruby >/dev/null 2>&1; then
  ruby -rsocket -e 's = TCPServer.new("127.0.0.1", Integer(ARGV[0])); puts "ready"; STDOUT.flush; sleep 20' "$base" > "$tmp/listener.out" &
  listener_pid=$!
  occupier=ruby
fi
if test -n "$occupier"; then
  waited=0
  while ! grep -q ready "$tmp/listener.out" 2>/dev/null; do
    waited=$((waited + 1))
    test "$waited" -le 50 || fail 'scratch listener never came up'
    sleep 0.1 2>/dev/null || sleep 1
  done
  selected="$(run_select "$base")"
  test "$selected" != "$base" || fail 'an occupied port must not be selected'
  test "$selected" -gt "$base" || fail "scan should move upward (got $selected)"
  grep -q "^MYSQL_PORT=$selected\$" "$tmp/.env" || fail 'replacement port was not persisted'
  kill "$listener_pid" 2>/dev/null || true
  wait "$listener_pid" 2>/dev/null || true
  listener_pid=''
else
  echo 'note: no python3/ruby; occupied-port case not exercised' >&2
fi

# 4. --after starts strictly past the given port (the bind-race path).
selected="$(run_select "$base" "--after $((base + 1))")"
test "$selected" -ge "$((base + 2))" || fail "--after $((base + 1)) should select >= $((base + 2)) (got $selected)"

# 5. Junk in the env file is refused (exit 64), not clamped.
printf 'MYSQL_PORT=notaport\n' > "$tmp/.env"
if run_select "$base" >/dev/null 2>&1; then
  fail 'an invalid persisted port must be refused'
fi

# 6. A missing env file is bootstrapped.
rm -f "$tmp/.env"
selected="$(run_select "$base")"
test -f "$tmp/.env" || fail 'env file should be created when missing'
grep -q "^MYSQL_PORT=$selected\$" "$tmp/.env" || fail 'bootstrapped env file should carry the selection'

echo 'PASS: hey_mysql port selection scan, persistence, --after, and refusal'
