#include "hey_sqlite3.h"
#include <sqlite3.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static char *hey_sqlite3_extension_c_string(HeyNativeUtf8View value) {
  char *out = (char *)malloc(value.length + 1);
  if (!out) return NULL;
  if (value.length && value.data) memcpy(out, value.data, value.length);
  out[value.length] = '\0';
  return out;
}

int32_t hey_sqlite3_load_extension(HeyNativeHandle database, HeyNativeUtf8View path, HeyNativeUtf8View entrypoint) {
  sqlite3 *db = (sqlite3 *)(uintptr_t)database;
  if (!db) return (int32_t)SQLITE_MISUSE;

  char *path_c = hey_sqlite3_extension_c_string(path);
  char *entrypoint_c = hey_sqlite3_extension_c_string(entrypoint);
  if (!path_c || !entrypoint_c) {
    free(path_c);
    free(entrypoint_c);
    return (int32_t)SQLITE_NOMEM;
  }

  int rc = sqlite3_enable_load_extension(db, 1);
  if (rc == SQLITE_OK) {
    char *message = NULL;
    rc = sqlite3_load_extension(db, path_c, entrypoint_c[0] ? entrypoint_c : NULL, &message);
    if (message) sqlite3_free(message);
  }

  /* Re-disable loading regardless of the load result.  A package may ask to
     load one audited extension without leaving arbitrary SQL-triggered loads
     enabled for the rest of the connection lifetime. */
  int disable_rc = sqlite3_enable_load_extension(db, 0);
  if (rc == SQLITE_OK && disable_rc != SQLITE_OK) rc = disable_rc;

  free(path_c);
  free(entrypoint_c);
  return (int32_t)rc;
}
