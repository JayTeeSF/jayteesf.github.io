/* hey_kqueue: a batched, edge-triggered TCP event loop for Hey on kqueue.
 *
 * The same contract as hey_epoll (wait -> next/data ... -> send), built for
 * the kqueue kernels only (macOS, FreeBSD, OpenBSD, NetBSD, DragonFly):
 *
 * - registrations are not one kevent() call each: they are queued in a
 *   changelist and handed to the kernel with the next wait's kevent(), so an
 *   accept or a write-interest arm costs no extra system call;
 * - an accepted socket inherits O_NONBLOCK, SO_NOSIGPIPE and TCP_NODELAY from
 *   the listener (BSD semantics, checked once per loop at the first accept;
 *   a kernel that does not inherit them gets them set per socket);
 * - the listener's event says how many connections are pending, so accept()
 *   runs that many times instead of until EAGAIN.
 *
 * The bytes are handed over as text (UTF-8 without NUL; anything else is
 * refused and the connection closed), protocol parsing stays in Hey, and the
 * program says how many input bytes each reply consumed. Unconsumed input stays
 * here and the connection is offered again on the next wait.
 *
 * One loop belongs to one thread. Nothing here is global.
 */
#if !(defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__) || defined(__DragonFly__))
#error "hey_kqueue is the kqueue backend: build it for macOS or a BSD (use hey_epoll on Linux, hey_iocp on Windows)"
#endif

#if defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__)
#define HEY_KQ_HAVE_ACCEPT4 1
#else
#define HEY_KQ_HAVE_ACCEPT4 0
#endif

#include "hey_kqueue.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/event.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#define HEY_KQ_BACKEND "kqueue"
#define HEY_KQ_MAX_EVENTS 1024
#define HEY_KQ_MAX_CHANGES 64       /* flushed early (with EV_RECEIPT) when full */
#define HEY_KQ_READ_CHUNK 65536
#define HEY_KQ_MAX_INPUT (1024 * 1024)

typedef struct HeyKqConn {
  char *in;
  char *out;
  size_t in_off, in_len, in_cap;
  size_t out_off, out_len, out_cap;
  uint32_t gen;
  uint8_t open;
  uint8_t want_close;
  uint8_t queued;
  uint8_t write_armed;
} HeyKqConn;

typedef struct HeyKqLoop {
  int kq;
  int listener;
  int port;
  int inherit_checked;   /* first accept looked at what the socket inherited */
  int set_per_socket;    /* this kernel does not inherit: set options per socket */
  HeyKqConn *conns;
  size_t conns_cap;
  int *ready;
  size_t ready_len, ready_pos, ready_cap;
  int *pending;
  size_t pending_len, pending_cap;
  struct kevent changes[HEY_KQ_MAX_CHANGES];
  int changes_len;
  char *scratch;
  char stats_text[640];
  uint64_t accepted, closed, live, waits, batches_ready, bytes_in, bytes_out;
  uint64_t accept_errors, oversize, invalid_text, partial_writes, changes_sent, early_flushes;
} HeyKqLoop;

static HeyKqLoop *hey_kq_loop(HeyNativeHandle value) { return (HeyKqLoop *)(uintptr_t)value; }

static int64_t hey_kq_id(HeyKqLoop *loop, int fd) {
  return ((int64_t)loop->conns[fd].gen << 32) | (int64_t)(uint32_t)fd;
}

static HeyKqConn *hey_kq_lookup(HeyKqLoop *loop, int64_t id, int *fd_out) {
  if (!loop || id < 0) return NULL;
  int fd = (int)(id & 0xffffffff);
  uint32_t gen = (uint32_t)((uint64_t)id >> 32);
  if (fd < 0 || (size_t)fd >= loop->conns_cap) return NULL;
  HeyKqConn *c = &loop->conns[fd];
  if (!c->open || c->gen != gen) return NULL;
  if (fd_out) *fd_out = fd;
  return c;
}

static int hey_kq_grow_ints(int **items, size_t *cap, size_t need) {
  if (need <= *cap) return 1;
  size_t next = *cap ? *cap * 2 : 256;
  while (next < need) next *= 2;
  int *grown = (int *)realloc(*items, next * sizeof(int));
  if (!grown) return 0;
  *items = grown;
  *cap = next;
  return 1;
}

static int hey_kq_ensure_conn(HeyKqLoop *loop, int fd) {
  if ((size_t)fd < loop->conns_cap) return 1;
  size_t next = loop->conns_cap ? loop->conns_cap : 1024;
  while (next <= (size_t)fd) next *= 2;
  HeyKqConn *grown = (HeyKqConn *)realloc(loop->conns, next * sizeof(HeyKqConn));
  if (!grown) return 0;
  memset(grown + loop->conns_cap, 0, (next - loop->conns_cap) * sizeof(HeyKqConn));
  loop->conns = grown;
  loop->conns_cap = next;
  return 1;
}

static int hey_kq_set_nonblocking(int fd) {
  int flags = fcntl(fd, F_GETFL, 0);
  if (flags < 0) return -1;
  if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) return -1;
  return 0;
}

static void hey_kq_socket_options(int fd) {
  int one = 1;
#if defined(SO_NOSIGPIPE)
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one));
#endif
  setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
}

/* ---- the changelist ----------------------------------------------------- */

static void hey_kq_close_fd(HeyKqLoop *loop, int fd);

/* Hands every queued change to the kernel now, without draining events
   (EV_RECEIPT makes each change answer with its own EV_ERROR record). */
static void hey_kq_flush_changes(HeyKqLoop *loop) {
  int n = loop->changes_len;
  if (n == 0) return;
  struct kevent receipts[HEY_KQ_MAX_CHANGES];
  for (int i = 0; i < n; i++) loop->changes[i].flags |= EV_RECEIPT;
  struct timespec zero = {0, 0};
  int got;
  do { got = kevent(loop->kq, loop->changes, n, receipts, n, &zero); } while (got < 0 && errno == EINTR);
  loop->changes_len = 0;
  loop->changes_sent += (uint64_t)n;
  loop->early_flushes++;
  for (int i = 0; i < got; i++) {
    if ((receipts[i].flags & EV_ERROR) && receipts[i].data != 0) {
      int fd = (int)receipts[i].ident;
      if (fd != loop->listener && (size_t)fd < loop->conns_cap && loop->conns[fd].open) hey_kq_close_fd(loop, fd);
    }
  }
}

static void hey_kq_change(HeyKqLoop *loop, int fd, int16_t filter, uint16_t flags) {
  if (loop->changes_len == HEY_KQ_MAX_CHANGES) hey_kq_flush_changes(loop);
  EV_SET(&loop->changes[loop->changes_len], (uintptr_t)fd, filter, flags, 0, 0, NULL);
  loop->changes_len++;
}

/* A closed descriptor number can be reused by the next accept before the
   changelist reaches the kernel: its queued changes must go with it. */
static void hey_kq_forget_changes(HeyKqLoop *loop, int fd) {
  int kept = 0;
  for (int i = 0; i < loop->changes_len; i++) {
    if ((int)loop->changes[i].ident == fd) continue;
    if (kept != i) loop->changes[kept] = loop->changes[i];
    kept++;
  }
  loop->changes_len = kept;
}

static void hey_kq_close_fd(HeyKqLoop *loop, int fd) {
  HeyKqConn *c = &loop->conns[fd];
  if (!c->open) return;
  free(c->in);
  free(c->out);
  uint32_t gen = c->gen;
  memset(c, 0, sizeof(*c));
  c->gen = gen + 1;     /* every id handed out for the old socket is now stale */
  hey_kq_forget_changes(loop, fd);
  close(fd);            /* closing removes its knotes from the kqueue */
  loop->closed++;
  if (loop->live) loop->live--;
}

/* ---- output ------------------------------------------------------------- */

static ssize_t hey_kq_write_some(int fd, const char *data, size_t len) {
#if defined(MSG_NOSIGNAL)
  return send(fd, data, len, MSG_NOSIGNAL);
#else
  return send(fd, data, len, 0);
#endif
}

/* Returns 0 when the connection had to be closed. */
static int hey_kq_flush(HeyKqLoop *loop, int fd) {
  HeyKqConn *c = &loop->conns[fd];
  while (c->out_off < c->out_len) {
    ssize_t n = hey_kq_write_some(fd, c->out + c->out_off, c->out_len - c->out_off);
    if (n > 0) { c->out_off += (size_t)n; loop->bytes_out += (uint64_t)n; continue; }
    if (n < 0 && errno == EINTR) continue;
    if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
      if (!c->write_armed) {
        c->write_armed = 1;
        hey_kq_change(loop, fd, EVFILT_WRITE, EV_ADD | EV_ONESHOT);
      }
      return 1;
    }
    hey_kq_close_fd(loop, fd);
    return 0;
  }
  c->out_off = c->out_len = 0;
  free(c->out); c->out = NULL; c->out_cap = 0;   /* idle connections keep no buffers */
  if (c->want_close) { hey_kq_close_fd(loop, fd); return 0; }
  return 1;
}

/* ---- input -------------------------------------------------------------- */

static void hey_kq_mark_ready(HeyKqLoop *loop, int fd) {
  HeyKqConn *c = &loop->conns[fd];
  if (c->queued || c->in_len == c->in_off) return;
  if (!hey_kq_grow_ints(&loop->ready, &loop->ready_cap, loop->ready_len + 1)) return;
  c->queued = 1;
  loop->ready[loop->ready_len++] = fd;
}

/* Reads until the socket is drained. Returns 0 when the connection was closed. */
static int hey_kq_read_all(HeyKqLoop *loop, int fd, int drain) {
  HeyKqConn *c = &loop->conns[fd];
  for (;;) {
    ssize_t n = recv(fd, loop->scratch, HEY_KQ_READ_CHUNK, 0);
    if (n > 0) {
      loop->bytes_in += (uint64_t)n;
      if (c->in_off == c->in_len) c->in_off = c->in_len = 0;
      size_t need = c->in_len + (size_t)n;
      if (need - c->in_off > HEY_KQ_MAX_INPUT) { loop->oversize++; hey_kq_close_fd(loop, fd); return 0; }
      if (need > c->in_cap) {
        if (c->in_off > 0) {       /* reclaim consumed space before growing */
          memmove(c->in, c->in + c->in_off, c->in_len - c->in_off);
          c->in_len -= c->in_off;
          c->in_off = 0;
          need = c->in_len + (size_t)n;
        }
        if (need > c->in_cap) {
          size_t cap = c->in_cap ? c->in_cap : 1024;
          while (cap < need) cap *= 2;
          char *grown = (char *)realloc(c->in, cap);
          if (!grown) { hey_kq_close_fd(loop, fd); return 0; }
          c->in = grown;
          c->in_cap = cap;
        }
      }
      memcpy(c->in + c->in_len, loop->scratch, (size_t)n);
      c->in_len += (size_t)n;
      /* A short read drained the socket; EV_CLEAR raises a new event for any
         later arrival, so the recv() that would only say EAGAIN is skipped,
         unless the peer also hung up (then read on to see the 0). */
      if (!drain && (size_t)n < HEY_KQ_READ_CHUNK) return 1;
      continue;
    }
    if (n == 0) { hey_kq_close_fd(loop, fd); return 0; }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) return 1;
    hey_kq_close_fd(loop, fd);
    return 0;
  }
}

/* budget: how many connections the kernel said are pending (<= 0: until EAGAIN). */
static void hey_kq_accept_all(HeyKqLoop *loop, intptr_t budget) {
  for (intptr_t taken = 0; budget <= 0 || taken < budget; taken++) {
#if HEY_KQ_HAVE_ACCEPT4
    int fd = accept4(loop->listener, NULL, NULL, SOCK_NONBLOCK | SOCK_CLOEXEC);
#else
    int fd = accept(loop->listener, NULL, NULL);
#endif
    if (fd < 0) {
      if (errno == EINTR) { taken--; continue; }
      if (errno != EAGAIN && errno != EWOULDBLOCK) loop->accept_errors++;
      return;
    }
#if !HEY_KQ_HAVE_ACCEPT4
    (void)fcntl(fd, F_SETFD, FD_CLOEXEC);
#endif
    if (!loop->inherit_checked) {
      loop->inherit_checked = 1;
      int flags = fcntl(fd, F_GETFL, 0);
      if (flags < 0 || !(flags & O_NONBLOCK)) loop->set_per_socket = 1;
    }
    if (loop->set_per_socket) {
      if (hey_kq_set_nonblocking(fd) != 0) { close(fd); loop->accept_errors++; continue; }
      hey_kq_socket_options(fd);
    }
    if (!hey_kq_ensure_conn(loop, fd)) { close(fd); loop->accept_errors++; continue; }
    HeyKqConn *c = &loop->conns[fd];
    uint32_t gen = c->gen;
    memset(c, 0, sizeof(*c));
    c->gen = gen;
    c->open = 1;
    loop->accepted++;
    loop->live++;
    /* Clients usually send the request with the handshake: read it now. The
       read filter goes into the changelist; kqueue evaluates a filter when
       it is attached, so bytes that arrive in between still raise an event. */
    if (hey_kq_read_all(loop, fd, 0)) {
      hey_kq_change(loop, fd, EVFILT_READ, EV_ADD | EV_CLEAR);
      hey_kq_mark_ready(loop, fd);
    }
  }
}

/* ---- text check: the hand-over is UTF-8 text without NUL --------------- */

static size_t hey_kq_text_prefix(const unsigned char *s, size_t n, int *bad) {
  size_t i = 0;
  *bad = 0;
  while (i < n) {
    unsigned char b = s[i];
    if (b >= 0x01 && b < 0x80) { i++; continue; }
    if (b == 0) { *bad = 1; return i; }
    size_t need;
    uint32_t cp;
    if (b >= 0xc2 && b <= 0xdf) { need = 1; cp = b & 0x1f; }
    else if (b >= 0xe0 && b <= 0xef) { need = 2; cp = b & 0x0f; }
    else if (b >= 0xf0 && b <= 0xf4) { need = 3; cp = b & 0x07; }
    else { *bad = 1; return i; }
    if (i + need >= n) {
      /* fewer continuation bytes than needed remain: maybe a split read */
      for (size_t k = i + 1; k < n; k++) if ((s[k] & 0xc0) != 0x80) { *bad = 1; return i; }
      return i;
    }
    for (size_t k = 1; k <= need; k++) {
      if ((s[i + k] & 0xc0) != 0x80) { *bad = 1; return i; }
      cp = (cp << 6) | (s[i + k] & 0x3f);
    }
    if ((need == 2 && cp < 0x800) || (need == 3 && (cp < 0x10000 || cp > 0x10ffff)) || (cp >= 0xd800 && cp <= 0xdfff)) {
      *bad = 1;
      return i;
    }
    i += need + 1;
  }
  return i;
}

/* ---- public functions ---------------------------------------------------- */

HeyNativeHandle hey_kqueue_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport) {
  char host_c[64];
  if (host.length >= sizeof(host_c)) return (HeyNativeHandle)0;
  memcpy(host_c, host.data, host.length);
  host_c[host.length] = '\0';

  /* Use the descriptor allowance the process was given (its hard limit). */
  struct rlimit rl;
  if (getrlimit(RLIMIT_NOFILE, &rl) == 0 && rl.rlim_cur < rl.rlim_max) {
    rl.rlim_cur = rl.rlim_max;
#if defined(__APPLE__)
    if (rl.rlim_cur > 10240) rl.rlim_cur = 10240;   /* Darwin refuses RLIM_INFINITY here */
#endif
    (void)setrlimit(RLIMIT_NOFILE, &rl);
  }

  struct sockaddr_in addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons((uint16_t)port);
  if (inet_pton(AF_INET, host_c, &addr.sin_addr) != 1) return (HeyNativeHandle)0;

  int lfd = socket(AF_INET, SOCK_STREAM, 0);
  if (lfd < 0) return (HeyNativeHandle)0;
  int one = 1;
  setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
  if (reuseport) setsockopt(lfd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(one));
  hey_kq_socket_options(lfd);   /* inherited by every accepted socket */
  (void)fcntl(lfd, F_SETFD, FD_CLOEXEC);
  if (bind(lfd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(lfd, backlog > 0 ? backlog : 4096) != 0 ||
      hey_kq_set_nonblocking(lfd) != 0) {
    close(lfd);
    return (HeyNativeHandle)0;
  }
  socklen_t alen = sizeof(addr);
  getsockname(lfd, (struct sockaddr *)&addr, &alen);

  HeyKqLoop *loop = (HeyKqLoop *)calloc(1, sizeof(HeyKqLoop));
  if (!loop) { close(lfd); return (HeyNativeHandle)0; }
  loop->listener = lfd;
  loop->port = ntohs(addr.sin_port);
  loop->scratch = (char *)malloc(HEY_KQ_READ_CHUNK);
  loop->kq = kqueue();
  if (loop->kq < 0 || !loop->scratch) {
    if (loop->kq >= 0) close(loop->kq);
    close(lfd);
    free(loop->scratch);
    free(loop);
    return (HeyNativeHandle)0;
  }
  (void)fcntl(loop->kq, F_SETFD, FD_CLOEXEC);
  struct kevent change;
  EV_SET(&change, lfd, EVFILT_READ, EV_ADD, 0, 0, NULL);
  if (kevent(loop->kq, &change, 1, NULL, 0, NULL) != 0) {
    close(loop->kq);
    close(lfd);
    free(loop->scratch);
    free(loop);
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)loop;
}

int32_t hey_kqueue_close(HeyNativeHandle value) {
  HeyKqLoop *loop = hey_kq_loop(value);
  if (!loop) return -1;
  for (size_t fd = 0; fd < loop->conns_cap; fd++) if (loop->conns[fd].open) hey_kq_close_fd(loop, (int)fd);
  close(loop->listener);
  close(loop->kq);
  free(loop->conns);
  free(loop->ready);
  free(loop->pending);
  free(loop->scratch);
  free(loop);
  return 0;
}

int32_t hey_kqueue_wait(HeyNativeHandle value, int32_t timeout_ms) {
  HeyKqLoop *loop = hey_kq_loop(value);
  if (!loop) return -1;
  /* Connections of the last batch that Hey did not take (it may stop early to
     bound a batch) are carried into this one; the ones it took wait for new
     input or for a send() that leaves pipelined bytes behind. */
  size_t untaken_from = loop->ready_pos;
  for (size_t i = 0; i < loop->ready_len; i++) {
    int fd = loop->ready[i];
    if ((size_t)fd < loop->conns_cap) loop->conns[fd].queued = 0;
    if (i >= untaken_from && hey_kq_grow_ints(&loop->pending, &loop->pending_cap, loop->pending_len + 1)) {
      loop->pending[loop->pending_len++] = fd;
    }
  }
  loop->ready_len = loop->ready_pos = 0;
  size_t carried = loop->pending_len;
  for (size_t i = 0; i < carried; i++) {
    int fd = loop->pending[i];
    if ((size_t)fd < loop->conns_cap && loop->conns[fd].open) hey_kq_mark_ready(loop, fd);
  }
  loop->pending_len = 0;
  int timeout = loop->ready_len ? 0 : timeout_ms;
  loop->waits++;

  struct kevent events[HEY_KQ_MAX_EVENTS];
  struct timespec ts, *tsp = NULL;
  if (timeout >= 0) { ts.tv_sec = timeout / 1000; ts.tv_nsec = (long)(timeout % 1000) * 1000000L; tsp = &ts; }
  /* The queued registrations ride along with this wait: one system call. A
     failed change comes back as an EV_ERROR event (there is room: at most
     HEY_KQ_MAX_CHANGES of the HEY_KQ_MAX_EVENTS slots). */
  int nchanges = loop->changes_len;
  loop->changes_len = 0;
  loop->changes_sent += (uint64_t)nchanges;
  int n = kevent(loop->kq, loop->changes, nchanges, events, HEY_KQ_MAX_EVENTS, tsp);
  while (n < 0 && errno == EINTR) n = kevent(loop->kq, NULL, 0, events, HEY_KQ_MAX_EVENTS, tsp);
  for (int i = 0; i < n; i++) {
    int fd = (int)events[i].ident;
    if (events[i].flags & EV_ERROR) {
      if (events[i].data != 0 && fd != loop->listener && (size_t)fd < loop->conns_cap && loop->conns[fd].open) {
        hey_kq_close_fd(loop, fd);
      }
      continue;
    }
    if (fd == loop->listener) { hey_kq_accept_all(loop, (intptr_t)events[i].data); continue; }
    if ((size_t)fd >= loop->conns_cap || !loop->conns[fd].open) continue;
    if (events[i].filter == EVFILT_WRITE) {
      loop->conns[fd].write_armed = 0;
      if (!hey_kq_flush(loop, fd)) continue;
    } else if (events[i].filter == EVFILT_READ) {
      if (!hey_kq_read_all(loop, fd, (events[i].flags & EV_EOF) != 0)) continue;
    }
    hey_kq_mark_ready(loop, fd);
  }
  loop->batches_ready += loop->ready_len;
  return (int32_t)loop->ready_len;
}

int64_t hey_kqueue_next(HeyNativeHandle value) {
  HeyKqLoop *loop = hey_kq_loop(value);
  if (!loop) return -1;
  while (loop->ready_pos < loop->ready_len) {
    int fd = loop->ready[loop->ready_pos++];
    if ((size_t)fd < loop->conns_cap && loop->conns[fd].open && loop->conns[fd].in_len > loop->conns[fd].in_off) {
      return hey_kq_id(loop, fd);
    }
  }
  return -1;
}

HeyNativeUtf8View hey_kqueue_data(HeyNativeHandle value, int64_t id) {
  HeyKqLoop *loop = hey_kq_loop(value);
  int fd = -1;
  HeyKqConn *c = hey_kq_lookup(loop, id, &fd);
  if (!c) return (HeyNativeUtf8View){"", 0};
  const char *start = c->in + c->in_off;
  size_t len = c->in_len - c->in_off;
  int bad = 0;
  size_t ok = hey_kq_text_prefix((const unsigned char *)start, len, &bad);
  if (bad) {
    loop->invalid_text++;
    hey_kq_close_fd(loop, fd);
    return (HeyNativeUtf8View){"", 0};
  }
  return (HeyNativeUtf8View){start, ok};
}

int32_t hey_kqueue_send(HeyNativeHandle value, int64_t id, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after) {
  HeyKqLoop *loop = hey_kq_loop(value);
  int fd = -1;
  HeyKqConn *c = hey_kq_lookup(loop, id, &fd);
  if (!c) return 0;
  size_t available = c->in_len - c->in_off;
  size_t take = consumed < 0 ? 0 : (size_t)consumed;
  if (take > available) take = available;
  c->in_off += take;
  if (c->in_off == c->in_len) {
    /* An idle keep-alive connection keeps no buffer. */
    c->in_off = c->in_len = 0;
    free(c->in);
    c->in = NULL;
    c->in_cap = 0;
  }
  if (close_after) c->want_close = 1;

  const char *src = data.data;
  size_t len = data.length;
  if (c->out_len == c->out_off && len > 0) {
    /* nothing queued: write straight from the caller's text */
    for (;;) {
      ssize_t n = hey_kq_write_some(fd, src, len);
      if (n > 0) { loop->bytes_out += (uint64_t)n; src += n; len -= (size_t)n; if (len == 0) break; continue; }
      if (n < 0 && errno == EINTR) continue;
      if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
      hey_kq_close_fd(loop, fd);
      return 0;
    }
  }
  if (len > 0) {
    loop->partial_writes++;
    if (c->out_off > 0 && c->out_off == c->out_len) c->out_off = c->out_len = 0;
    size_t need = c->out_len + len;
    if (need > c->out_cap) {
      size_t cap = c->out_cap ? c->out_cap : 4096;
      while (cap < need) cap *= 2;
      char *grown = (char *)realloc(c->out, cap);
      if (!grown) { hey_kq_close_fd(loop, fd); return 0; }
      c->out = grown;
      c->out_cap = cap;
    }
    memcpy(c->out + c->out_len, src, len);
    c->out_len += len;
    if (!hey_kq_flush(loop, fd)) return 1;   /* closed after the reply, or failed */
  } else if (c->want_close && c->out_len == c->out_off) {
    hey_kq_close_fd(loop, fd);
    return 1;
  }
  /* Pipelined input after this request: offer it again on the next wait. */
  if (c->open && c->in_len > c->in_off && hey_kq_grow_ints(&loop->pending, &loop->pending_cap, loop->pending_len + 1)) {
    loop->pending[loop->pending_len++] = fd;
  }
  return 1;
}

int32_t hey_kqueue_drop(HeyNativeHandle value, int64_t id) {
  HeyKqLoop *loop = hey_kq_loop(value);
  int fd = -1;
  if (!hey_kq_lookup(loop, id, &fd)) return 0;
  hey_kq_close_fd(loop, fd);
  return 1;
}

int32_t hey_kqueue_port(HeyNativeHandle value) {
  HeyKqLoop *loop = hey_kq_loop(value);
  return loop ? loop->port : -1;
}

HeyNativeUtf8View hey_kqueue_stats(HeyNativeHandle value) {
  HeyKqLoop *loop = hey_kq_loop(value);
  if (!loop) return (HeyNativeUtf8View){"{}", 2};
  int n = snprintf(loop->stats_text, sizeof(loop->stats_text),
    "{\"backend\":\"%s\",\"live\":%llu,\"accepted\":%llu,\"closed\":%llu,\"waits\":%llu,\"ready\":%llu,"
    "\"bytes_in\":%llu,\"bytes_out\":%llu,\"accept_errors\":%llu,\"oversize\":%llu,\"invalid_text\":%llu,\"partial_writes\":%llu,"
    "\"changes\":%llu,\"early_flushes\":%llu,\"inherits\":%s}",
    HEY_KQ_BACKEND, (unsigned long long)loop->live, (unsigned long long)loop->accepted, (unsigned long long)loop->closed,
    (unsigned long long)loop->waits, (unsigned long long)loop->batches_ready, (unsigned long long)loop->bytes_in,
    (unsigned long long)loop->bytes_out, (unsigned long long)loop->accept_errors, (unsigned long long)loop->oversize,
    (unsigned long long)loop->invalid_text, (unsigned long long)loop->partial_writes,
    (unsigned long long)loop->changes_sent, (unsigned long long)loop->early_flushes,
    loop->set_per_socket ? "false" : "true");
  if (n < 0) n = 0;
  if ((size_t)n >= sizeof(loop->stats_text)) n = (int)sizeof(loop->stats_text) - 1;
  return (HeyNativeUtf8View){loop->stats_text, (size_t)n};
}

HeyNativeUtf8View hey_kqueue_backend(void) {
  return (HeyNativeUtf8View){HEY_KQ_BACKEND, sizeof(HEY_KQ_BACKEND) - 1};
}
