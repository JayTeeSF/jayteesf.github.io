/* Android implementation of Hey's target-neutral runtime crypto seam.
 *
 * Core owns SHA-256 in-tree. Android supplies only the two primitives that
 * genuinely require the platform: secure random bytes and constant-time
 * comparison. No Apple or OpenSSL names are exposed by this contract.
 */
#ifndef HEY_ANDROID_PLATFORM_CRYPTO_H
#define HEY_ANDROID_PLATFORM_CRYPTO_H

#if !defined(__ANDROID__)
#error "hey_android's platform crypto profile is for Android targets only"
#endif

#include <stddef.h>

int hey_runtime_platform_random_bytes(unsigned char *out, size_t length);
int hey_runtime_platform_constant_time_bcmp(const void *left, const void *right, size_t length);

#endif
