# In progress

0.2.4 is the current native-command compatibility release. The base package gate uses the stable `hey native` interface. The configured live-server gate must still be run on real MySQL and MariaDB servers with the desired authentication and TLS policies. Full live-SQL direct-LLVM execution remains a generic compiler supported-subset receipt, not a reason to move driver code into Hey.
