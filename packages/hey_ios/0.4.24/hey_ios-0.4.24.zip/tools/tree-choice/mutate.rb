# Deliberately break one behavior in a temporary host copy. Each mutation must
# compile and make the real UIKit harness report an assertion failure.
path, control = ARGV
source = File.read(path)
pattern, replacement = case control
when 'duplicate'
  [/byID\[key\] \|\| /, '']
when 'lifetime'
  [/if\s*\(generation\s*!=\s*self\.formGeneration\s*\|\|\s*!\[session isEqual:HS\(\[\[HeyIOSApi shared\] token\]\)\]\)\s*return;/, '(void)generation; (void)session;']
when 'private'
  [/if\s*\(!\[node\[@"selectable"\] boolValue\]\)\s*return;/, '']
when 'transport'
  [/if\s*\(\(method\.length.*?return;\s*\}/m, '(void)method; (void)body;']
when 'loading'
  [/if\s*\(!self\.options\[fieldID\]\)\s*self\.options\[fieldID\]\s*=\s*\[HeyIOSTreeChoiceController staticOptions:field\];/, '']
when 'tint'
  # Restore the shipped defect: refresh Send while the sheet still dims the form.
  [/(withRowAnimation:UITableViewRowAnimationNone\];)(\n  \};\n  picker\.finished = \^\{.*?)\[strong refreshPrimaryTitle\];/m,
   "\\1\n    [strong refreshPrimaryTitle];\\2(void)strong;"]
when 'shape'
  # Reload single rows even when the source changed the table's sections.
  [/if \(!\[shapeAfter isEqualToArray:shapeBefore\]\)\s*\[self redrawShapeFrom:shapeBefore to:shapeAfter rows:changed\];\s*else if \(changed\.count\)/,
   "(void)shapeBefore; (void)shapeAfter;\n        if (changed.count)"]
when 'focus'
  # Forget which field is being edited: late sources rebuild the whole table.
  [/(- \(nullable UIView \*\)editingInput \{\n)/, "\\1  return nil;\n"]
when 'untyped'
  # Treat a focused field the person never typed in as theirs: it stays blank.
  [/if \(\[self\.touched containsObject:key\]\)\n(\s*)return;\n(\s*)id v = HeyIOSAt/, "if ([self.touched containsObject:key] || [editing isEqual:key])\n\\1return;\n\\2id v = HeyIOSAt"]
when 'stale'
  # Let any choices response write rows, not only the newest request's.
  [/if \(mine != self\.choiceRequests\[fieldID\]\.unsignedIntegerValue\)\s*return;/, '']
when 'inflight'
  # Let Try again start another load while one is still in flight.
  [/if \(\[self\.choicesLoading containsObject:HS\(field\[@"id"\]\)\]\)\s*return;/, '']
when 'reload'
  # Let an older source response land after a newer reload's.
  [/mine != self\.sourceGeneration \|\|/, 'mine == 0 ||']
when 'sheet'
  # Swiping the picker sheet down skips the finish path Cancel runs.
  [/\s*sheet\.presentationController\.delegate = picker;/, '']
when 'swipe'
  # End loads when an interactive Back swipe merely starts.
  [/  if \(parent == nil\) \[self clearSavedShare\];\n\}/,
   "  if (parent == nil) { [self clearSavedShare]; [self invalidateFormLoads]; }\n}"]
when 'blank'
  # Accept a selectable remote row whose value is empty or a static value.
  [/if \(\[selectable boolValue\] && \(!value\.length \|\| \[staticValues containsObject:value\]\)\)\s*return nil;/, '']
when 'traits'
  [/UITextAutocapitalizationTypeSentences/, 'UITextAutocapitalizationTypeNone']
else
  abort "unknown tree choice control: #{control}"
end
abort "control did not match: #{control}" unless source.match?(pattern)
File.write(path, source.gsub(pattern, replacement))
