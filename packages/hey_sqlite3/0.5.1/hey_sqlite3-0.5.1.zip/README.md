# hey_sqlite3 0.5.1

`hey_sqlite3` is an independently versioned SQLite package for the current Hey native-extension interface. It uses a real native extension built over Hey's ABI-v2 FFI and exposes a connection contract consumed by `hey_record`.

## Plumbing and porcelain

- `native/hey_sqlite3.c`, `native/hey_sqlite3_load_extension.c`, `native/hey_sqlite3.h`, `hey.native.json`, and `Native.hey` are **plumbing**. They own C signatures, opaque handles, blocking metadata, bindings, stepping, extension loading, and deterministic cleanup.
- `adapter.hey` is **porcelain**. `Sqlite3.connect`, `query_params`, `execute_params`, transactions, typed rows, and the `hey_record` callback shape live here.
- `extensions.hey` is an audited public bridge for packages such as `hey_honker` that need to load a SQLite extension without receiving or inspecting the native `sqlite3*` handle.
- Hey itself owns only the generic native ABI, loader, package manager, and conformance fixtures. SQLite release policy and API evolution belong to this package.

## Build the native library

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
./bin/build-native
```

The default output is `.native-build/<target>/libhey_sqlite3.*`. Applications should build outside the immutable installed package, for example:

```sh
PACKAGE="$PWD/.hey/packages/hey_sqlite3/0.5.1"
OUT="$PWD/.hey/native/hey_sqlite3/0.5.1/darwin-arm64"
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" "$PACKAGE/bin/build-native" --out "$OUT"
export HEY_SQLITE3_LIBRARY="$OUT/libhey_sqlite3.dylib"
```

Linux uses `.so`. Windows awaits Hey's native Windows extension-loader promotion.

## Use it

```hey
import 'pkg:hey_sqlite3@0.5.1/main'

let opened = Sqlite3.connect('app.sqlite3', {})
let database = opened.value

Sqlite3.execute(database,
  'CREATE TABLE IF NOT EXISTS cards (id INTEGER PRIMARY KEY, name TEXT NOT NULL)')

Sqlite3.execute_params(database,
  'INSERT INTO cards (name) VALUES (?)',
  ['Ada'])

let cards = Sqlite3.query_params(database,
  'SELECT id, name FROM cards WHERE name = ?',
  ['Ada'])

Sqlite3.close(database)
```

Database calls are marked blocking. Own each connection and its statements from one bounded worker or partitioned Job lane.

## Statement cache (0.4.0)

`query`, `query_params`, `execute` and `execute_params` no longer prepare and
finalize a statement on every call. Each connection keeps its prepared
statements (native/hey_sqlite3_cache.c): a call takes an idle statement with
the same SQL text, runs it, and gives it back reset and unbound. SQLite
re-prepares a cached statement by itself after a schema change, a failed step
leaves it reusable, at most 64 idle statements are kept per connection (least
recently used first out), and `Sqlite3.close` finalizes them.

Measured with `tools/statement_cache_bench.hey` (macOS arm64, in-memory
database, 20,000 calls): `query_params` point lookup 17 -> 14 us,
`execute_params` update 13 -> 11 us. Most of what remains is building row
objects in Hey; a hot path that serves JSON can let SQLite build the whole
response instead (0.5.0, below).

Opt out per connection with `{statement_cache: false}`.
`Sqlite3.cached_statements(connection)` reports the cache's size.

## JSON built by SQLite (0.5.0)

SQLite can build a response body itself (`json_object`, `json_array`,
`json_group_array`). These calls hand back that text unparsed, ready to send:
rows never become Hey objects.

```hey
# One column that SQLite built as JSON. ok(text); zero rows: ok(nil).
let post = Sqlite3.query_json(database,
  "SELECT json_object('id', id, 'body', body) FROM posts WHERE id = ?", [7])

# Any SELECT's rows as a JSON array of objects keyed by column name.
# Zero rows: ok('[]'). The statement's ORDER BY is kept.
let feed = Sqlite3.query_rows_json(database,
  'SELECT id, body, created_at FROM posts ORDER BY created_at DESC LIMIT ?', [20])

# The first row as one object; zero rows: ok(nil).
let one = Sqlite3.query_row_json(database, 'SELECT id, body FROM posts WHERE id = ?', [7])

# A column that holds JSON text nests as JSON when named in json_columns
# (otherwise it is a JSON string, because SQLite's JSON flag does not survive
# a subquery).
let tagged = Sqlite3.query_rows_json_with(database,
  'SELECT id, meta FROM posts ORDER BY id', [], {json_columns: ['meta']})
```

| call | returns | refuses (Result.err code) |
|---|---|---|
| `query_json(connection, sql, parameters)` | the first row's text, or nil for no rows | more than one column (`sqlite3_json_column_count`); a non-TEXT value, NULL included (`sqlite3_json_not_text`) |
| `query_rows_json(connection, sql, parameters)` | `[{...}, ...]`, `[]` for no rows | duplicate column names (`sqlite3_json_duplicate_column`); a BLOB value (`sqlite3_step_failed`, naming the column) |
| `query_row_json(connection, sql, parameters)` | `{...}`, or nil for no rows | as `query_rows_json` |
| `query_rows_json_with` / `query_row_json_with(..., options)` | as above; `options.json_columns` nest | a `json_columns` entry that is not a column (`sqlite3_json_column_unknown`); malformed JSON text in one (`sqlite3_step_failed`) |

SQL and binding errors come back as the same typed errors `query_params`
gives (`sqlite3_prepare_failed`, `sqlite3_bind_count_mismatch`,
`sqlite3_step_failed` with SQLite's message). Every call goes through the
statement cache.

Numbers, strings and nulls are written by SQLite, so the text is SQLite's own:
integers stay exact past 2^53, reals use SQLite's formatting (`1.0e+300`,
`-2.5e-07`), control characters are escaped, other Unicode is written as is.
JSON has no bytes: convert a BLOB in SQL (`hex(data) AS data`). `query_json`
runs your SQL as written, so a BLOB handed straight to your own
`json_object()` is read by SQLite as JSONB; the row calls refuse it instead.

Measured with `tools/json_bench.hey` (macOS arm64, compiled, in-memory
database, a 20-row feed of posts joined to authors with a like count, 3.7 KB
of JSON, 5,000 calls each):

| route | us per body |
|---|---|
| `query_params` + `Json.encode` of the rows (Hey builds the JSON) | 245 |
| `Sqlite3.query_rows_json` | 46 |
| `Sqlite3.query_json` with a hand-written `json_group_array(json_object(...))` | 35 |

`query_rows_json` costs about 11 us over hand-written SQL: it reads the column
names (one cached prepare, one native call that writes the wrapper SQL) and
passes each value through the BLOB guard (about 5 us of the 11 for 100
values).

A statement prepared once at startup and stepped by hand through
`Sqlite3Native` (hey_fast_web's `src/store.hey`) is still about 5 us cheaper
per call than `query_json` on the same SQL (15.5 vs 20.5 us for its 20-row
feed): `query_json` pays a cache lookup, a bind-count check and the column
checks that make it safe to call with any SQL. Use the adapter calls unless
those microseconds matter more than the checks.

## WAL checkpoints and sizing pragmas (0.4.0)

`Sqlite3.connect` accepts three optional whole-number pragmas, validated
before they reach SQL: `cache_size`, `mmap_size`, `wal_autocheckpoint`. None
is set unless given.

`Sqlite3.checkpoint(connection, mode)` runs `PRAGMA wal_checkpoint(MODE)` for
`PASSIVE`, `FULL`, `RESTART` or `TRUNCATE` and returns
`{busy, log_frames, checkpointed_frames}`. With `{wal_autocheckpoint: 0}` a
server can checkpoint after it has answered a batch of writes instead of inside
whichever COMMIT crosses the threshold (hey_fast_web measured the in-COMMIT
checkpoint as its worst tail latency). Keep the checkpoint on the connection
that writes: a PASSIVE checkpoint from another connection never catches up
with a steady stream of writes, so the WAL never resets.

## PostgreSQL-compatible `greatest()` / `least()`

Every connection `Sqlite3.connect` opens carries `greatest()` and `least()` as
real SQLite scalar functions, registered natively (`sqlite3_create_function_v2`)
inside `hey_sqlite3_open`. No API change and no opt-in: caller SQL can just say
`greatest(a, b)`.

They follow PostgreSQL, not SQLite: NULL arguments are **ignored**, and the
result is NULL only when **every** argument is NULL. SQLite ships no
`greatest`/`least` at all, and its multi-argument `max()`/`min()` return NULL if
*any* argument is NULL:

```
SELECT max(NULL, 5)       ->  NULL     -- SQLite's max
SELECT greatest(NULL, 5)  ->  5        -- PostgreSQL semantics, this package
SELECT greatest(NULL, NULL) IS NULL    -- 1: all arguments null
```

That difference is why an application whose SQL was written for PostgreSQL and
rewritten `GREATEST(` -> `max(` changes answers silently as soon as an argument
is nullable.

Both are variadic (one or more arguments) and compare using SQLite's own value
ordering -- NULL < INTEGER/REAL < TEXT < BLOB, numeric comparison across
INTEGER/REAL, bytewise BINARY comparison for TEXT and BLOB -- so
`greatest(2, 'a')` is `'a'` and `greatest(2, 10.5)` is `10.5`. Text always
compares under BINARY: the public `sqlite3_value_*` API exposes no hook onto a
surrounding `COLLATE NOCASE`. `specs/greatest_least_spec.hey` is the contract.

Both live in C, so a consumer on an older build picks them up only after the
native library is rebuilt from the installed package copy (`bin/build-native`).

## Safe loadable-extension bridge

0.3.2 adds a generic extension-loading surface for higher-level packages:

```hey
import 'pkg:hey_sqlite3@0.5.1/main'
import 'pkg:hey_sqlite3@0.5.1/extensions'

let opened = Sqlite3.connect('app.sqlite3', {})
let loaded = Sqlite3Extensions.load(opened.value, '/path/to/extension', 'optional_entrypoint')
```

The driver remains the only owner of `sqlite3*`. The native bridge temporarily enables extension loading, loads exactly the requested library, and disables extension loading again before returning. A missing/invalid library is a typed `sqlite3_load_extension_failed` Result. `specs/load_extension_spec.hey` is a `stdlib:Minispec` contract for this behavior.

This surface is intentionally generic; `hey_sqlite3` contains no Honker-specific code.

## hey_record connection contract

`Sqlite3.connect(database, options)` returns a plain record satisfying the
`hey_record_connection` contract hey_record 0.3.0's `HeyRecordStore` rides
on: a `dialect` field (`'sqlite3'`), the callable set `query`,
`query_params`, `execute`, `execute_params` (plus `begin`, `commit`,
`rollback`, `close`, and `interrupt`), and execute results that carry
`changes` (affected rows) and `last_insert_id`. The `changes` field is what
lets the store's delete report an absent record as the typed error
`not_found` instead of a silent ok. `specs/store_conformance_spec.hey`
proves the store round-trip (store/fetch/delete/list, delete-absent ->
`not_found`) over a real file database; it drives a hand-copied copy of the
store's sqlite3-dialect SQL rather than a locked hey_record dependency,
because hey_record is the consumer of this adapter, not a dependency of it.

### Connect-surface asymmetry

`Sqlite3.connect(database, options)` is positional where
`Mysql.connect(options)` takes one options record. For consumers that want
one shape across adapters, `Sqlite3.connect_options(options)` accepts the
database inside the record:

```hey
let opened = Sqlite3.connect_options({database: 'app.sqlite3'})
```

A missing or empty `database` entry is the typed refusal
`sqlite3_database_missing`. The positional `connect` stays supported
unchanged.

## Version single source

The in-source version literal lives in exactly one place:
`hey_sqlite3_version_value()` in `adapter.hey`. `Sqlite3.version()` and
`HeySqlite3Info.version()` both read it, the native library search path
(`.hey/native/hey_sqlite3/<version>/`) is derived from it, and
`bin/package-check` both greps that literal against the `VERSION` file and
runs `tools/version_receipt.hey` (interpreter and compiled) against
`VERSION`.

## Compiler-lane receipt status

The package gate runs the interpreter/native C receipts and the real SQLite store conformance. The richer callback-bearing adapter remains an explicit LLVM probe rather than a claimed default-LLVM parity surface until the compiler lane supports it.

## Current release boundary

This release links a system SQLite development library discovered through `pkg-config sqlite3` or `-lsqlite3`. A future package release should contain a checksum-pinned amalgamation and license/provenance receipt for reproducible Darwin, Linux, and Windows builds.

## Standard package controls

This package uses `hey_packager` for validation, release construction, source handoff, and immutable registry publication.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_sqlite3`.
