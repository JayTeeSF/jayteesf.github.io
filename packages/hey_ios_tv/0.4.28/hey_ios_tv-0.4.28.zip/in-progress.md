# In progress

- Produce the first simulator receipt from a locked package consumer.

- 0.4.28 privacy and legacy recovery source qualified; await coordinated package
  publication and TV app/device acceptance. Held 0.4.27 architecture work remains
  separate. The legacy URL-bearer protocol has not been migrated.
