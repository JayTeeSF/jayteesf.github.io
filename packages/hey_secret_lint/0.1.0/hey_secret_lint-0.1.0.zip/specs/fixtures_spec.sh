#!/usr/bin/env sh
# Fixture contract for the secret-lint command, with negative controls.
#
#   1. specs/fixtures/flagged must print exactly specs/fixtures/flagged.expected
#      and exit 1 (the Elders line, a key_hash compare, a Bearer literal, ...).
#   2. specs/fixtures/clean must print exactly specs/fixtures/clean.expected
#      and exit 0 (presence checks, constant_time_equal?, a reasoned suppression).
#   3. A project scanned from its root (no argument) skips .hey/, vendor/,
#      build/, dist/, tmp/, node_modules/, generated/, and spec/test code
#      unless --include-specs.
#   4. CONTROLS: the same comparisons run against mutated copies of the
#      package -- the secret-name detector disabled, the Basic/Bearer literal
#      rule disabled, the safe-operand exclusions disabled, the bytes-argument
#      recognizer for constant_time_equal? disabled -- and each one
#      MUST make a case above fail. A control that still passes means the
#      fixtures do not exercise that rule, and this spec fails.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
HEYC="$HEY_ROOT/bin/heyc"
[ -x "$HEYC" ] || { echo "missing Hey compiler: $HEYC" >&2; exit 1; }
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT HUP INT TERM

# run_case PACKAGE_ROOT WORKDIR EXPECTED_FILE EXPECTED_STATUS [ARGS...]
# Returns 0 when stdout and the exit status both match, 1 otherwise.
run_case() {
  pkg=$1; dir=$2; expected=$3; want=$4
  shift 4
  set +e
  (cd "$dir" && HEY_ROOT="$HEY_ROOT" HEY_STDLIB_PATH="$HEY_ROOT/stdlib" \
    "$HEYC" "$pkg/bin/secret-lint.hey" --run -- "$@") > "$tmp/out" 2> "$tmp/err"
  got=$?
  set -e
  if [ "$got" != "$want" ]; then
    echo "  exit $got, wanted $want ($*)"
    sed 's/^/  stderr: /' "$tmp/err" | head -5
    return 1
  fi
  if ! cmp -s "$expected" "$tmp/out"; then
    echo "  output differs from $(basename "$expected") ($*):"
    diff "$expected" "$tmp/out" | sed 's/^/  /' | head -20
    return 1
  fi
  return 0
}

flagged_case() { run_case "$1" "$ROOT" "$ROOT/specs/fixtures/flagged.expected" 1 specs/fixtures/flagged; }
clean_case() { run_case "$1" "$ROOT" "$ROOT/specs/fixtures/clean.expected" 0 specs/fixtures/clean; }

failures=0
pass() { echo "ok - $1"; }
bad() { echo "not ok - $1"; failures=$((failures + 1)); }

if flagged_case "$ROOT"; then pass 'flagged fixtures: every secret compare reported, exit 1'; else bad 'flagged fixtures'; fi
if clean_case "$ROOT"; then pass 'clean fixtures: nothing reported, exit 0'; else bad 'clean fixtures'; fi

# 3. Default root and skipped directories.
proj="$tmp/project"
mkdir -p "$proj/src"
line="    return supplied_token == stored"
for skipped in .hey vendor build dist tmp node_modules generated; do
  mkdir -p "$proj/$skipped/lib"
  printf 'fn f(supplied_token, stored)\n%s\nend\n' "$line" > "$proj/$skipped/lib/leak.hey"
done
printf 'fn f(supplied_token, stored)\n%s\nend\n' "$line" > "$proj/src/leak.hey"
printf 'fn g(token)\n  return token == nil\nend\n' > "$proj/src/clean.hey"
printf 'supplied_token == stored in a file that is not Hey\n' > "$proj/src/notes.md"
cat > "$tmp/default.expected" <<'OUT'
src/leak.hey:2: == on 'supplied_token' looks like a secret; use Crypto.constant_time_equal?(bytes(a), bytes(b))
secret-lint: 1 finding in 1 file (2 .hey files scanned)
OUT
if run_case "$ROOT" "$proj" "$tmp/default.expected" 1; then pass 'default root . skips .hey/ vendor/ build/ dist/ tmp/ node_modules/ generated/'; else bad 'default root and skipped directories'; fi

# Spec and test code is skipped unless --include-specs: specs/, spec/,
# tests/, test/ directories and *_spec.hey / *_test.hey files.
mkdir -p "$proj/specs" "$proj/test" "$proj/lib"
cp "$proj/src/leak.hey" "$proj/specs/leak.hey"
cp "$proj/src/leak.hey" "$proj/test/leak.hey"
cp "$proj/src/leak.hey" "$proj/lib/leak_spec.hey"
if run_case "$ROOT" "$proj" "$tmp/default.expected" 1; then pass 'specs/ test/ and *_spec.hey are skipped by default'; else bad 'spec and test code skipped by default'; fi
cat > "$tmp/specs.expected" <<'OUT'
lib/leak_spec.hey:2: == on 'supplied_token' looks like a secret; use Crypto.constant_time_equal?(bytes(a), bytes(b))
specs/leak.hey:2: == on 'supplied_token' looks like a secret; use Crypto.constant_time_equal?(bytes(a), bytes(b))
src/leak.hey:2: == on 'supplied_token' looks like a secret; use Crypto.constant_time_equal?(bytes(a), bytes(b))
test/leak.hey:2: == on 'supplied_token' looks like a secret; use Crypto.constant_time_equal?(bytes(a), bytes(b))
secret-lint: 4 findings in 4 files (5 .hey files scanned)
OUT
if run_case "$ROOT" "$proj" "$tmp/specs.expected" 1 --include-specs; then pass '--include-specs scans spec and test code too'; else bad '--include-specs'; fi

# --exclude NAME skips one more directory name.
mkdir -p "$proj/fixtures"
cp "$proj/src/leak.hey" "$proj/fixtures/leak.hey"
if run_case "$ROOT" "$proj" "$tmp/default.expected" 1 --exclude fixtures .; then pass '--exclude skips a named directory'; else bad '--exclude'; fi

# 4. Negative controls: mutate one rule at a time in a copy of the package.
# mutate NAME MARKER: copy the package, insert `return false` as the first
# statement of the function whose definition line is exactly MARKER.
mutate() {
  name=$1; marker=$2
  copy="$tmp/mutant-$name"
  mkdir -p "$copy"
  cp -R "$ROOT/bin" "$ROOT/src" "$copy/"
  awk -v m="$marker" '{ print } $0 == m { print "    return false"; hit++ } END { if (hit != 1) exit 3 }' \
    "$ROOT/src/main.hey" > "$copy/src/main.hey" || {
      echo "control $name: marker not found exactly once: $marker" >&2; exit 1; }
  printf '%s' "$copy"
}

detector="$(mutate detector '  fn secret_name?(name)')"
if flagged_case "$detector" > "$tmp/control.out"; then
  bad 'CONTROL: flagged fixtures still pass with the secret-name detector disabled'
else
  pass 'control: disabling the secret-name detector fails the flagged fixtures'
fi

literal="$(mutate literal '  fn auth_literal?(value)')"
if flagged_case "$literal" > "$tmp/control.out"; then
  bad 'CONTROL: flagged fixtures still pass with the Basic/Bearer literal rule disabled'
else
  pass 'control: disabling the Basic/Bearer literal rule fails the flagged fixtures'
fi

safe="$(mutate safe '  fn safe_operand?(toks, a, b)')"
if clean_case "$safe" > "$tmp/control.out"; then
  bad 'CONTROL: clean fixtures still pass with the safe-operand exclusions disabled'
else
  pass 'control: disabling the safe-operand exclusions fails the clean fixtures'
fi

state="$(mutate state 'private fn sl_paired_state?(toks, la, lb, ra, rb)')"
if flagged_case "$state" > "$tmp/control.out"; then
  bad 'CONTROL: flagged fixtures still pass with the OAuth state rule disabled'
else
  pass 'control: disabling the OAuth state rule fails the flagged fixtures'
fi

bytes="$(mutate bytes '  fn bytes_arg?(toks, a, b)')"
if clean_case "$bytes" > "$tmp/control.out"; then
  bad 'CONTROL: clean fixtures still pass with the bytes-argument recognizer disabled'
else
  pass 'control: disabling the bytes-argument recognizer fails the clean fixtures'
fi

[ "$failures" = 0 ] || { echo "fixtures_spec: $failures failing" >&2; exit 1; }
echo 'fixtures_spec: all cases and controls passed'
