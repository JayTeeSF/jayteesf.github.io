# TODO — hey_cache

Ordered. Each carries what would count as done.

1. **Parameterise gate 5 over MySQL as well as SQLite.**
   Done when `bin/check` runs the same `HeyRecordStore.sql` receipt against a
   `hey_mysql` (0.3.1, never 0.3.0) connection and asserts the row count in
   MySQL. Today the README's layer table claims MySQL works and only SQLite
   is measured.

2. **Bounded memory layers.**
   Done when a memory layer accepts a `max_entries` knob, an eviction policy
   is named in the README, and a spec proves the bound holds under more
   writes than the bound.

3. **Minimise the compiled-lane argument mis-binding.**
   `hey_cache_clamped_entry_value(cache, layer, entry, now_ms)` received the
   caller's loop index as its second argument in the COMPILED lane while the
   interpreter was correct (instrumented proof: caller printed the layer
   record, callee printed `0`). Worked around by flattening the signature.
   Done when there is a standalone reproduction small enough to hand to the
   compiler, or a demonstration that the workaround was masking a defect
   here rather than in `heyc`.

4. **A layer kind supplied entirely by callables.**
   Done when a consumer can add a layer type without editing `cache.hey`,
   and a spec adds one from outside the package.

5. **Single-flight, only if a real workload shows the herd.**
   Done when there is a measurement of duplicate computes under concurrency
   first. Building it before that is speculation.
