package hey.android.api;

import android.content.Context;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** The bundled UI is the only UI. Legacy downloaded definitions are never read. */
final class HeyAndroidDescription {
  static final String ASSET = "hey-api/description.json";
  static final String ORIGIN_ASSET = "hey-api/origin.txt";
  final Map<String, Object> current;
  final String origin;

  HeyAndroidDescription(Context context) throws IOException {
    byte[] bytes = asset(context, ASSET);
    try { current = Descriptions.baked(bytes); }
    catch (IllegalArgumentException error) { throw new IOException(error.getMessage(), error); }
    origin = new String(asset(context, ORIGIN_ASSET), StandardCharsets.UTF_8).trim();
    Log.i("hey.api", "description: drawing the baked copy " + Descriptions.sha256Hex(bytes).substring(0, 12)
        + " (android level " + Values.RENDERER_LEVEL + ")");
  }

  private static byte[] asset(Context context, String name) throws IOException {
    try (InputStream in = context.getAssets().open(name)) {
      return HeyAndroidHttp.readAll(in);
    }
  }

  Map<String, Object> screenNamed(String id) {
    for (Object s : Json.list(current.get("screens"))) {
      Map<String, Object> screen = Json.dict(s);
      if (Values.string(screen.get("id")).equals(id)) return screen;
    }
    return null;
  }

  Map<String, Object> labels() { return Json.dict(current.get("labels")); }

  String storeName() {
    String name = Values.string(current.get("secure_store"));
    return name.isEmpty() ? Values.string(current.get("keychain_service")) : name;
  }
}
