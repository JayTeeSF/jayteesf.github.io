Continue hey_ios as an independently versioned Apple adapter package beneath hey_mobile. Read README.md, done.md, in-progress.md, and todos.md. Keep app business logic out and native handles opaque.
