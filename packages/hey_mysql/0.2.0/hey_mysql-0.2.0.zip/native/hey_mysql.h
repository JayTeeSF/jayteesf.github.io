#ifndef HEY_MYSQL_H
#define HEY_MYSQL_H

#include "hey_native_abi.h"

HeyNativeUtf8View hey_mysql_client_info(void);
HeyNativeHandle hey_mysql_init(void);
int32_t hey_mysql_close(HeyNativeHandle connection);
int32_t hey_mysql_set_connect_timeout(HeyNativeHandle connection, uint32_t seconds);
int32_t hey_mysql_set_read_timeout(HeyNativeHandle connection, uint32_t seconds);
int32_t hey_mysql_set_write_timeout(HeyNativeHandle connection, uint32_t seconds);
int32_t hey_mysql_set_ssl(HeyNativeHandle connection, HeyNativeUtf8View key, HeyNativeUtf8View certificate, HeyNativeUtf8View ca, HeyNativeUtf8View ca_path, HeyNativeUtf8View cipher);
int32_t hey_mysql_set_ssl_verify(HeyNativeHandle connection, HeyNativeBool verify);
int32_t hey_mysql_connect(HeyNativeHandle connection, HeyNativeUtf8View host, HeyNativeUtf8View username, HeyNativeUtf8View password, HeyNativeUtf8View database, uint32_t port, HeyNativeUtf8View socket, uint64_t flags);
int32_t hey_mysql_set_charset(HeyNativeHandle connection, HeyNativeUtf8View charset);
int32_t hey_mysql_select_db(HeyNativeHandle connection, HeyNativeUtf8View database);
uint32_t hey_mysql_errcode(HeyNativeHandle connection);
HeyNativeUtf8View hey_mysql_errmsg(HeyNativeHandle connection);
HeyNativeUtf8View hey_mysql_sqlstate(HeyNativeHandle connection);
HeyNativeUtf8View hey_mysql_server_info(HeyNativeHandle connection);
uint64_t hey_mysql_thread_id(HeyNativeHandle connection);
int32_t hey_mysql_query(HeyNativeHandle connection, HeyNativeUtf8View sql);
uint32_t hey_mysql_field_count(HeyNativeHandle connection);
HeyNativeHandle hey_mysql_store_result(HeyNativeHandle connection);
int32_t hey_mysql_free_result(HeyNativeHandle result_set);
uint64_t hey_mysql_num_rows(HeyNativeHandle result_set);
uint32_t hey_mysql_num_fields(HeyNativeHandle result_set);
HeyNativeUtf8View hey_mysql_field_name(HeyNativeHandle result_set, uint32_t index);
HeyNativeBool hey_mysql_fetch_row(HeyNativeHandle result_set);
HeyNativeBool hey_mysql_column_is_null(HeyNativeHandle result_set, uint32_t index);
HeyNativeUtf8View hey_mysql_column_text(HeyNativeHandle result_set, uint32_t index);
HeyNativeBytesView hey_mysql_column_bytes(HeyNativeHandle result_set, uint32_t index);
uint64_t hey_mysql_column_length(HeyNativeHandle result_set, uint32_t index);
uint64_t hey_mysql_affected_rows(HeyNativeHandle connection);
uint64_t hey_mysql_insert_id(HeyNativeHandle connection);
int32_t hey_mysql_autocommit(HeyNativeHandle connection, HeyNativeBool enabled);
int32_t hey_mysql_commit(HeyNativeHandle connection);
int32_t hey_mysql_rollback(HeyNativeHandle connection);
int32_t hey_mysql_ping(HeyNativeHandle connection);
HeyNativeOwnedBytes hey_mysql_escape(HeyNativeHandle connection, HeyNativeUtf8View value);

#endif
