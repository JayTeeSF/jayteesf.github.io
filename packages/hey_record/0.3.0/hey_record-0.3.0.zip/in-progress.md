# In progress

Framework-extraction slice S1 (RecallCoach lineage): the record store
(store.hey), the migration ledger (migrate.hey), dialect refusal, and the
compiled-lane receipt in bin/check are implemented and green. They target
the next release (0.3.0); VERSION stays 0.2.5 until the maintainer reviews
and runs the bump/release flow. Known compiled-lane caveat carried honestly:
HeyRecordModel.find does not lower on trunk 0.99.474a (HeyRecord.first is
mis-resolved as the collections builtin), so model.hey is interpreter-lane
only and excluded from the receipt's import graph.
