package android.content;
import java.io.File;
import android.content.res.AssetManager;
public class Context {
  private final File root;
  public Context(File root) { this.root = root; }
  public Context getApplicationContext() { return this; }
  public File getFilesDir() { File f = new File(root, "files"); f.mkdirs(); return f; }
  public AssetManager getAssets() { return new AssetManager(new File(root, "assets")); }
}
