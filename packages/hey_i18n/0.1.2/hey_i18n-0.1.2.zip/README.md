# hey_i18n

Pure catalog/chain internationalization for Hey applications today, evolving under `PACKAGE_SPEC.md` into the complete target-neutral localization contract required by MMeoww: locale negotiation/fallback, messages, CLDR-compatible plural/select behavior, locale-sensitive formatting, RTL/bidi metadata, localized resources and accessibility copy.

This is an independently versioned third-party Hey package. It is not part of Hey core or the standard library. It was extracted from a working prototype built inside the RecallCoach application (see `docs/DESIGN.md` for the original design record). Preserve that v0.1.x lineage while extending it; do not replace it with a parallel package.

Read `BUILDER_START_HERE.md` and `PACKAGE_SPEC.md` before implementing the expanded contract.

## Existing v0.1.x API model

The current implementation is deliberately pure-function oriented. Hey has no mutable module/global store, so there is no `register_locale()` side effect. A locale is registered by adding a block to a catalog RECORD your app builds and passes as an ordinary argument. Existing behavior remains a regression contract while the package expands.

A catalog is `{locale_code: {key: template_string, ...}, ...}`. The default language is just another locale in the catalog; the fallback chain guarantees it as the ultimate fallback.

```hey
import 'hey_i18n:i18n'

let catalog = {
  en: {app_name: 'Demo App', greeting: 'Hello {name}'},
  es: {greeting: 'Hola {name}'},
}
let chain = I18n.chain('es-MX', 'en')
I18n.format(catalog, chain, 'greeting', {name: 'Ada'})
I18n.t(catalog, chain, 'app_name')
```

Plural-aware keys in the current implementation use a separate plural catalog, keyed the same way, with CLDR-category records.

## Existing apostrophe rule

The current source/catalog representation cannot safely place ASCII apostrophe (`'`, U+0027) in catalog values written as single-quoted Hey literals. Use the Unicode right single quotation mark (`’`, U+2019) or another safe generated catalog representation. The expanded catalog/compiler work must preserve source correctness rather than silently generating invalid Hey literals.

## Development

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
```

## Package lifecycle and `hey_packager`

MMeoww's package-construction policy requires every package created/evolved for the product to depend on the canonical immutable `hey_packager` release and to use it for common package structure/check/release/publish/source-handoff behavior.

This repository declares `hey_packager` in `dependencies` as `">=0.1.1 <0.2.0"`, so it appears in an application's lock. A range rather than an exact version, because an application lock holds one version of each package and every package that declares `hey_packager` must accept the same one; do not use `latest` or a moving branch. It provides `bin/check`, `bin/bump`, `bin/release` (builds the release, does not publish) and `bin/publish` (commits `packages/NAME/VERSION` to `~/dev/jayteesf.github.io/packages`; never overwrites, never pushes).

`hey_packager` is lifecycle/build tooling rather than an application localization API. Product code does not import packager functions for runtime localization merely because the package manifest records the lifecycle dependency.

Existing immutable `hey_i18n` versions must never be replaced. The expanded contract must be released as a new immutable version after all checks and compiled-target receipts pass.
