# hey_postgres

Reusable Hey PostgreSQL package backed by PostgreSQL `libpq`.

## Status

**AUTHORITATIVE PACKAGE CONTRACT.** This repository is the permanent home for `hey_postgres`. Generate and release the package with the current Hey toolchain; do not hand-invent native-manifest syntax, release hashes, or lock data.

## Design rules

- Hey API; libpq is an implementation detail.
- Explicit SQL; no heavyweight ORM.
- Parameterized queries are the default. Never concatenate untrusted values into SQL.
- Connection pooling is implemented in Hey with bounded actors/workers; native handles are opaque package handles.
- All blocking native calls are declared blocking to the Hey runtime/package descriptor.
- UTF-8 text and bytea are lossless; NULL is distinct from empty values.
- PostgreSQL errors expose SQLSTATE, severity, primary/detail/hint, constraint/table/column when libpq provides them.
- Transactions have explicit begin/commit/rollback semantics and rollback on failed scope.
- Prepared statements and binary parameters/results are supported where useful.
- COPY IN/OUT and cursor/streaming support must be bounded and backpressure-aware.
- TLS settings pass through libpq connection parameters; production never silently disables verification.

## Public modules

### `Postgres`

Required public operations:

- `connect(config)` -> connection
- `pool(config)` -> bounded pool
- `query(connection_or_pool, sql, params: [])` -> result
- `query_one(...)` -> row or none; error on >1 row
- `execute(...)` -> command result / affected rows
- `prepare(connection, name, sql, parameter_types: [])`
- `execute_prepared(...)`
- `transaction(connection_or_pool, fn)`
- `copy_in(...)`
- `copy_out(...)`
- `listen(connection, channel)` / `notifications(connection)`
- `close(handle)`
- `health(connection_or_pool)`

### `Postgres.Row`

- access by column name and ordinal
- `text`, `bytes`, `int`, `float`, `bool`, `uuid`, `json`, `timestamp`, nullable variants
- decoder failures include column and PostgreSQL type OID

### `Postgres.Pool`

- min/max connections
- acquire timeout
- idle/max lifetime
- health check
- bounded waiters/backpressure
- graceful drain
- metrics snapshot

## Native libpq ABI

Wrap, at minimum:

- `PQconnectdbParams`, `PQstatus`, `PQerrorMessage`, `PQfinish`
- `PQexecParams`, `PQprepare`, `PQexecPrepared`
- `PQresultStatus`, `PQntuples`, `PQnfields`, `PQfname`, `PQftype`, `PQgetisnull`, `PQgetvalue`, `PQgetlength`, `PQcmdTuples`, `PQclear`
- error-field access via `PQresultErrorField`
- transaction commands through parameter-free SQL issued by package-owned constants
- nonblocking/COPY primitives where streaming is enabled: `PQsetnonblocking`, `PQconsumeInput`, `PQisBusy`, `PQgetResult`, `PQputCopyData`, `PQputCopyEnd`, `PQgetCopyData`, `PQflush`
- notifications: `PQnotifies`, `PQfreemem`

Native boundary must never expose a raw host pointer as a Hey value. Use opaque handle IDs/descriptor-managed handles per the current Hey native-package ABI.

## Tests required before release

- connect/disconnect and failed auth
- TLS config behavior
- positional parameters including quote/injection cases
- NULL vs empty string/bytes
- every supported scalar decoder
- malformed decoder input
- transaction commit/rollback/nested-policy behavior
- prepared statement lifecycle
- pool saturation/acquire timeout/drain
- server restart/broken connection recovery
- SQLSTATE/error field mapping
- COPY round-trip and bounded memory
- LISTEN/NOTIFY
- concurrency under Hey workers
- leak checks for every libpq result/notification/native handle

## MMeoww usage

MMeoww repositories own SQL and schema-specific mapping. `hey_postgres` owns PostgreSQL transport, safety, decoding primitives, pooling and native resource lifetime only.
