#ifndef HEY_SQLITE3_H
#define HEY_SQLITE3_H

#include "hey_native_abi.h"

HeyNativeHandle hey_sqlite3_open(HeyNativeUtf8View path, int32_t flags);
int32_t hey_sqlite3_close(HeyNativeHandle database);
int32_t hey_sqlite3_errcode(HeyNativeHandle database);
int32_t hey_sqlite3_extended_errcode(HeyNativeHandle database);
HeyNativeUtf8View hey_sqlite3_errmsg(HeyNativeHandle database);
int32_t hey_sqlite3_busy_timeout(HeyNativeHandle database, int32_t milliseconds);
int32_t hey_sqlite3_exec(HeyNativeHandle database, HeyNativeUtf8View sql);
int32_t hey_sqlite3_load_extension(HeyNativeHandle database, HeyNativeUtf8View path, HeyNativeUtf8View entrypoint);
int64_t hey_sqlite3_changes(HeyNativeHandle database);
int64_t hey_sqlite3_total_changes(HeyNativeHandle database);
int64_t hey_sqlite3_last_insert_rowid(HeyNativeHandle database);
void hey_sqlite3_interrupt(HeyNativeHandle database);
HeyNativeHandle hey_sqlite3_prepare(HeyNativeHandle database, HeyNativeUtf8View sql);
int32_t hey_sqlite3_bind_parameter_count(HeyNativeHandle statement);
int32_t hey_sqlite3_bind_i64(HeyNativeHandle statement, int32_t index, int64_t value);
int32_t hey_sqlite3_bind_f64(HeyNativeHandle statement, int32_t index, double value);
int32_t hey_sqlite3_bind_text(HeyNativeHandle statement, int32_t index, HeyNativeUtf8View value);
int32_t hey_sqlite3_bind_bytes(HeyNativeHandle statement, int32_t index, HeyNativeBytesView value);
int32_t hey_sqlite3_bind_null(HeyNativeHandle statement, int32_t index);
int32_t hey_sqlite3_step(HeyNativeHandle statement);
int32_t hey_sqlite3_reset(HeyNativeHandle statement);
int32_t hey_sqlite3_clear_bindings(HeyNativeHandle statement);
int32_t hey_sqlite3_finalize(HeyNativeHandle statement);
HeyNativeBool hey_sqlite3_readonly(HeyNativeHandle statement);
int32_t hey_sqlite3_column_count(HeyNativeHandle statement);
int32_t hey_sqlite3_column_type(HeyNativeHandle statement, int32_t index);
HeyNativeUtf8View hey_sqlite3_column_name(HeyNativeHandle statement, int32_t index);
HeyNativeUtf8View hey_sqlite3_column_text(HeyNativeHandle statement, int32_t index);
HeyNativeBytesView hey_sqlite3_column_bytes(HeyNativeHandle statement, int32_t index);
int64_t hey_sqlite3_column_i64(HeyNativeHandle statement, int32_t index);
double hey_sqlite3_column_f64(HeyNativeHandle statement, int32_t index);

#endif
