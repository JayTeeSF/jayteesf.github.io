# frozen_string_literal: true
require 'minitest/autorun'
class FormDictationContractTest < Minitest::Test
  HOST = File.read(File.expand_path('../native/HeyIOSApiHost.m', __dir__))
  def test_standard_editors_remain_available_for_all_fields
    assert_includes HOST, 'UITextView *view = [[UITextView alloc] init];'
    assert_includes HOST, 'UITextField *text = [[UITextField alloc] init];'
    assert_includes HOST, 'addTextFieldWithConfigurationHandler:'
    refute_includes HOST, 'form_microphone_'
    refute_includes HOST, 'toggleFormDictation'
    refute_includes HOST, 'recognitionTaskWithRequest:'
  end
  def test_native_keyboard_is_never_replaced
    refute_match(/\.inputView\s*=|setInputView:|startDictation|UIKeyboardImpl/, HOST)
    assert_includes HOST, 'textViewDidChange:'
    assert_includes HOST, '[self clearSavedShare];'
  end
end
