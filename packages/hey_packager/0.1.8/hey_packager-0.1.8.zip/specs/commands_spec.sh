#!/usr/bin/env sh
# Behaviour tests for hey-packager's bump, version-file declarations and hook,
# the full check in front of release/publish, root-argument tolerance, and
# update-packages. Hey itself is mocked: these test the packager's decisions,
# not the compiler.
#
# EVERY BEHAVIOUR HAS A NEGATIVE CONTROL -- a case that must fail, or a line
# that must NOT change -- so a test that could never see the defect it names
# cannot stay green.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HP="$ROOT/bin/hey-packager"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/hey-packager-spec.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
tmp="$(CDPATH= cd -- "$tmp" && pwd -P)"
HEY_PACKAGE_REGISTRY_ROOT="$tmp/registry"
export HEY_PACKAGE_REGISTRY_ROOT
mkdir -p "$HEY_PACKAGE_REGISTRY_ROOT"
HEY_ROOT="$tmp/hey"
export HEY_ROOT
GIT_CONFIG_GLOBAL=/dev/null
GIT_CONFIG_NOSYSTEM=1
GIT_AUTHOR_NAME=spec GIT_AUTHOR_EMAIL=spec@example.invalid
GIT_COMMITTER_NAME=spec GIT_COMMITTER_EMAIL=spec@example.invalid
export GIT_CONFIG_GLOBAL GIT_CONFIG_NOSYSTEM GIT_AUTHOR_NAME GIT_AUTHOR_EMAIL GIT_COMMITTER_NAME GIT_COMMITTER_EMAIL

passed=0
ok() { passed=$((passed + 1)); echo "ok $passed - $*"; }
die() { echo "not ok - $*" >&2; exit 1; }
must_pass() {
  mp_name=$1; shift
  "$@" > "$tmp/out" 2>&1 || { cat "$tmp/out" >&2; die "$mp_name: expected success"; }
}
must_fail() {
  mf_name=$1; mf_pattern=$2; shift 2
  if "$@" > "$tmp/out" 2>&1; then cat "$tmp/out" >&2; die "$mf_name: expected failure, got success"; fi
  grep -F -- "$mf_pattern" "$tmp/out" >/dev/null || { cat "$tmp/out" >&2; die "$mf_name: failure did not say: $mf_pattern"; }
}
has() { grep -F -- "$2" "$1" >/dev/null || { echo "--- $1" >&2; cat "$1" >&2; die "$3"; }; }
hasnt() { if grep -F -- "$2" "$1" >/dev/null; then echo "--- $1" >&2; cat "$1" >&2; die "$3"; fi; }

mkdir -p "$HEY_ROOT/bin"
cat > "$HEY_ROOT/bin/hey" <<'SH'
#!/usr/bin/env sh
set -eu
[ -z "${MOCK_HEY_LOG:-}" ] || echo "$*" >> "$MOCK_HEY_LOG"
case "$1 $2" in
  "package verify") exit 0 ;;
  "package pack")
    root=$3; out=$5
    name=$(sed -n 's/^[[:space:]]*"name"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$root/hey-package.json" | head -n 1)
    ver=$(tr -d '[:space:]' < "$root/VERSION")
    (cd "$root" && zip -X -q "$out/$name-$ver.zip" VERSION)
    sum=$( (shasum -a 256 "$out/$name-$ver.zip" 2>/dev/null || sha256sum "$out/$name-$ver.zip") | awk '{print $1}')
    printf '{"name":"%s","version":"%s","archive_sha256":"%s","content_sha256":"c","manifest_sha256":"m"}\n' "$name" "$ver" "$sum" > "$out/$name-$ver.release.json"
    exit 0 ;;
  "package ensure")
    [ -z "${MOCK_ENSURE_FAIL:-}" ] || { echo "mock ensure failure" >&2; exit 9; }
    # package ensure --project ROOT --update-lock --registry INDEX
    [ -z "${MOCK_INDEX_COPY:-}" ] || cp "$7" "$MOCK_INDEX_COPY"
    printf '%s\n' "$MOCK_LOCK" > "$4/hey.lock.json"
    exit 0 ;;
esac
echo "unexpected mock hey invocation: $*" >&2
exit 64
SH
printf '#!/usr/bin/env sh\nexit 0\n' > "$HEY_ROOT/bin/heyc"
chmod +x "$HEY_ROOT/bin/hey" "$HEY_ROOT/bin/heyc"

make_fixture() {
  fx=$1
  mkdir -p "$fx/docs/examples" "$fx/src" "$fx/bin"
  printf '0.0.1\n' > "$fx/VERSION"
  cat > "$fx/hey-package.json" <<'JSON'
{
  "manifest_version": 1,
  "name": "bump_fixture",
  "version": "0.0.1",
  "modules": { "main": "src/main.hey" },
  "files": ["VERSION", "src/main.hey", "docs/README.md"],
  "dependencies": {
    "dep_exact": "0.1.0",
    "dep_range": ">=0.1.0 <0.2.0"
  }
}
JSON
  chmod 644 "$fx/hey-package.json"
  for doc in DESIGN GETTING_STARTED ROADMAP TESTING; do printf '# fixture\n' > "$fx/docs/$doc.md"; done
  printf '# bump_fixture 0.0.1\n\nWorks with other_pkg 0.0.1 and later.\n' > "$fx/docs/README.md"
  printf 'program\nend\n' > "$fx/docs/examples/basic.hey"
  cat > "$fx/src/main.hey" <<'HEY'
module BumpFixture
  fn version()
    return '0.0.1'
  end
  fn not_ours()
    return '10.0.1 0.0.10 0.0.1.5'
  end
end
HEY
  cat > "$fx/hey-version-files" <<'DECL'
# path [marker]
src/main.hey return '
docs/README.md bump_fixture
DECL
}

# --- 1. bump moves every declared copy, and only those ----------------------
f="$tmp/t1"; make_fixture "$f"
must_pass "bump patch" "$HP" bump "$f" patch
[ "$(cat "$f/VERSION")" = 0.0.2 ] || die "VERSION did not move"
has "$f/hey-package.json" '"version": "0.0.2"' "manifest did not move"
has "$f/src/main.hey" "return '0.0.2'" "declared src/main.hey copy did not move"
has "$f/docs/README.md" "# bump_fixture 0.0.2" "declared README heading did not move"
has "$tmp/out" "verified=VERSION+manifest+2-declared" "bump did not report its verification"
ok "bump moves VERSION, the manifest and every declared copy"
has "$f/docs/README.md" "other_pkg 0.0.1 and later" "a line without the marker was rewritten"
has "$f/src/main.hey" "'10.0.1 0.0.10 0.0.1.5'" "a longer number containing the version was rewritten"
ok "control: lines without the marker, and 10.0.1 / 0.0.10 / 0.0.1.5, are untouched"
has "$tmp/out" "docs/README.md:3:Works with other_pkg 0.0.1" "the undeclared mention was not listed"
hasnt "$tmp/out" "0.0.10 0.0.1.5" "the note listed a line whose numbers only contain the version"
ok "bump lists undeclared mentions of the old version; control: not longer numbers"
perm=$(ls -l "$f/hey-package.json" | cut -c1-10)
[ "$perm" = "-rw-r--r--" ] || die "bump changed hey-package.json's mode to $perm"
ok "bump keeps file modes"
f="$tmp/t1b"; make_fixture "$f"
printf "VERSION = '0.0.1'" > "$f/src/tail.hey"
printf 'src/tail.hey VERSION\n' >> "$f/hey-version-files"
must_pass "bump a file without a final newline" "$HP" bump "$f" patch
[ "$(cat "$f/src/tail.hey")" = "VERSION = '0.0.2'" ] || die "the unterminated declared copy did not move"
[ -n "$(tail -c 1 "$f/src/tail.hey")" ] || die "bump added a final newline to a file that had none"
[ -z "$(tail -c 1 "$f/src/main.hey")" ] || die "bump removed the final newline of a file that had one"
ok "bump keeps a missing final newline missing; control: a present one stays"

# --- 2. the read-back sees a copy left behind ------------------------------
f="$tmp/t2"; make_fixture "$f"
cat > "$f/bin/package-bump" <<'SH'
#!/usr/bin/env sh
printf '# bump_fixture %s\n' "$1" > docs/README.md
SH
chmod +x "$f/bin/package-bump"
must_fail "left-behind copy" "declared version files still disagree" "$HP" bump "$f" patch
has "$tmp/out" "docs/README.md:1: # bump_fixture 0.0.1" "the leftover line was not named"
[ "$(cat "$f/VERSION")" = 0.0.1 ] || die "VERSION was not restored after a failed bump"
has "$f/src/main.hey" "return '0.0.1'" "a declared copy was not restored after a failed bump"
ok "negative control: a hook that puts the old version back fails the bump, names the line, restores"

# --- 3. the hook runs with OLD NEW; a failing hook restores ----------------
f="$tmp/t3"; make_fixture "$f"
cat > "$f/bin/package-bump" <<'SH'
#!/usr/bin/env sh
printf '%s %s %s %s %s\n' "$1" "$2" "$HEY_BUMP_OLD" "$HEY_BUMP_NEW" "$(pwd -P)" > hook.log
SH
chmod +x "$f/bin/package-bump"
must_pass "bump with hook" "$HP" bump "$f" 0.1.0
[ "$(cat "$f/hook.log")" = "0.0.1 0.1.0 0.0.1 0.1.0 $f" ] || die "hook got: $(cat "$f/hook.log")"
has "$tmp/out" "hook=yes" "bump did not report the hook"
ok "bin/package-bump runs from the package root with OLD NEW"
f="$tmp/t3b"; make_fixture "$f"
printf '#!/usr/bin/env sh\nexit 7\n' > "$f/bin/package-bump"; chmod +x "$f/bin/package-bump"
must_fail "failing hook" "failed (exit 7)" "$HP" bump "$f" patch
[ "$(cat "$f/VERSION")" = 0.0.1 ] || die "VERSION was not restored after the hook failed"
has "$f/hey-package.json" '"version": "0.0.1"' "manifest was not restored after the hook failed"
ok "negative control: a failing hook fails the bump and restores"
f="$tmp/t3c"; make_fixture "$f"
printf '#!/usr/bin/env sh\nexit 0\n' > "$f/bin/package-bump"; chmod 644 "$f/bin/package-bump"
must_fail "non-executable hook" "not executable" "$HP" bump "$f" patch
[ "$(cat "$f/VERSION")" = 0.0.1 ] || die "a refused bump wrote VERSION"
ok "negative control: a hook that cannot run is refused before anything is written"

# --- 4. stale declarations: bump refuses first, check catches hand edits ---
f="$tmp/t4"; make_fixture "$f"
printf 'docs/DESIGN.md\n' >> "$f/hey-version-files"
must_fail "stale declaration" "holds no copy of 0.0.1; nothing was written" "$HP" bump "$f" patch
[ "$(cat "$f/VERSION")" = 0.0.1 ] || die "a refused bump wrote VERSION"
has "$f/src/main.hey" "return '0.0.1'" "a refused bump rewrote a declared file"
ok "bump refuses a declaration that holds no copy, before writing anything"
f="$tmp/t4b"; make_fixture "$f"
must_pass "check of a consistent package" "$HP" check "$f"
has "$tmp/out" "version files ok: 2 declared copies hold 0.0.1" "check did not verify the declared copies"
sed "s/return '0.0.1'/return '0.0.9'/" "$f/src/main.hey" > "$tmp/main.hey" && cat "$tmp/main.hey" > "$f/src/main.hey"
must_fail "check after a hand edit" "holds no '0.0.1'" "$HP" check "$f"
ok "check verifies declared copies; negative control: a hand-edited copy fails check"
f="$tmp/t4c"; make_fixture "$f"
printf '../outside\n' >> "$f/hey-version-files"
must_fail "escaping path" "must stay inside the package root" "$HP" check "$f"
ok "negative control: a declaration outside the package root is refused"

# --- 5. root arguments -----------------------------------------------------
f="$tmp/t5"; make_fixture "$f"
cp "$HP" "$f/bin/hey-packager"
cp "$ROOT/bin/bump" "$ROOT/bin/check" "$f/bin/"
chmod +x "$f/bin/hey-packager" "$f/bin/bump" "$f/bin/check"
must_pass "bin/bump . patch" sh -c 'cd "$1" && ./bin/bump . patch' sh "$f"
[ "$(cat "$f/VERSION")" = 0.0.2 ] || die "bin/bump . patch did not bump"
has "$tmp/out" "ignoring redundant package root '.'" "the redundant root was not reported"
must_pass "bin/check ." sh -c 'cd "$1" && ./bin/check .' sh "$f"
ok "bin/bump . patch and bin/check . accept the redundant root"
must_fail "bin/bump ." "is a directory, not a version" sh -c 'cd "$1" && ./bin/bump .' sh "$f"
must_fail "different second root" "second package root" "$f/bin/bump" "$tmp" patch
must_fail "different second root for check" "unexpected argument" "$f/bin/check" "$tmp"
must_fail "not a version" "is not a version" "$f/bin/bump" 1.2
must_fail "leading zero" "is not a version" "$f/bin/bump" 0.0.03
must_fail "not higher" "must be higher" "$f/bin/bump" 0.0.2
must_fail "lower" "must be higher" "$f/bin/bump" 0.0.1
mkdir -p "$HEY_PACKAGE_REGISTRY_ROOT/bump_fixture/0.0.3"
must_fail "already published" "already published" "$f/bin/bump" patch
rm -rf "$HEY_PACKAGE_REGISTRY_ROOT/bump_fixture"
[ "$(cat "$f/VERSION")" = 0.0.2 ] || die "a refused bump wrote VERSION"
ok "negative controls: a bare root, a different root, a non-version, no increase, a published version"

# --- 6. dry run --------------------------------------------------------------
f="$tmp/t6"; make_fixture "$f"
cat > "$f/bin/package-bump" <<'SH'
#!/usr/bin/env sh
echo ran > hook.log
SH
chmod +x "$f/bin/package-bump"
git -C "$f" init -q && git -C "$f" add -A
cp -R "$f" "$tmp/t6-before"
must_pass "dry run" "$HP" bump "$f" patch --dry-run
diff -r -x .git "$tmp/t6-before" "$f" >/dev/null || die "bump --dry-run changed the package"
[ ! -e "$f/hook.log" ] || die "bump --dry-run ran the hook in the real package"
has "$tmp/out" "+    return '0.0.2'" "the dry run did not show the declared copy's diff"
has "$tmp/out" "running bin/package-bump 0.0.1 0.0.2" "the dry run did not run the hook in its copy"
has "$tmp/out" "4 file(s) would change; nothing was written" "the dry run miscounted"
ok "bump --dry-run runs everything in a copy, prints the diff, writes nothing"
printf 'docs/DESIGN.md\n' >> "$f/hey-version-files"
must_fail "dry run of a failing bump" "the bump would FAIL" "$HP" bump "$f" patch --dry-run
ok "negative control: a dry run of a bump that would fail says so and exits non-zero"

# --- 7. normalize ------------------------------------------------------------
f="$tmp/t7"; make_fixture "$f"
printf '0.0.5\n' > "$f/VERSION"
must_fail "check after hand-edited VERSION" "bin/bump --normalize 0.0.1" "$HP" check "$f"
must_pass "normalize" "$HP" bump "$f" --normalize 0.0.1
has "$f/hey-package.json" '"version": "0.0.5"' "normalize did not move the manifest"
has "$f/src/main.hey" "return '0.0.5'" "normalize did not move a declared copy"
must_pass "check after normalize" "$HP" check "$f"
ok "bump --normalize repairs a hand-edited VERSION; control: check failed before it"

# --- 8. release runs the full check ------------------------------------------
f="$tmp/t8"; make_fixture "$f"
printf '#!/usr/bin/env sh\necho RED package-check >&2\nexit 5\n' > "$f/bin/package-check"; chmod +x "$f/bin/package-check"
must_fail "red release" "refusing to release" "$HP" release "$f" --out "$tmp/t8-out"
[ ! -e "$tmp/t8-out" ] || die "a refused release built artifacts"
ok "release refuses a red package"
must_pass "release --no-check" "$HP" release "$f" --out "$tmp/t8-out"  --no-check
has "$tmp/out" "THE FULL CHECK WAS SKIPPED (--no-check)" "an unchecked release was not loud"
[ -f "$tmp/t8-out/bump_fixture-0.0.1.zip" ] || die "release --no-check built nothing"
ok "release --no-check builds, loudly"
f="$tmp/t8b"; make_fixture "$f"
printf '#!/usr/bin/env sh\necho checked > "$(dirname "$0")/../checked.log"\n' > "$f/bin/package-check"; chmod +x "$f/bin/package-check"
must_pass "green release" "$HP" release "$f" --out "$tmp/t8b-out"
[ -f "$f/checked.log" ] || die "release did not run bin/package-check"
has "$tmp/out" "full check passed" "release did not report the check"
ok "control: a green package releases, after its check ran"
f="$tmp/t8c"; make_fixture "$f"
printf '#!/usr/bin/env sh\nexit 3\n' > "$f/bin/check"; chmod +x "$f/bin/check"
must_fail "red custom bin/check" "exit 3 from: $f/bin/check" "$HP" release "$f" --out "$tmp/t8c-out"
ok "release runs the package's own bin/check when it has one"

# --- 9. publish runs the full check; the override is explicit and recorded --
f="$tmp/t9"; make_fixture "$f"
printf '#!/usr/bin/env sh\nexit 5\n' > "$f/bin/package-check"; chmod +x "$f/bin/package-check"
mkdir -p "$tmp/site/packages"
git -C "$tmp/site" init -q
must_fail "red publish" "refusing to publish" "$HP" publish "$f" --out "$tmp/t9-out" --registry-root "$tmp/site/packages"
[ ! -e "$tmp/site/packages/bump_fixture/0.0.1" ] || die "a refused publish reached the registry"
must_fail "publish --no-check" "publish refuses --no-check" "$HP" publish "$f" --out "$tmp/t9-out" --registry-root "$tmp/site/packages" --no-check
[ ! -e "$tmp/site/packages/bump_fixture/0.0.1" ] || die "publish --no-check reached the registry"
ok "publish refuses a red package, and refuses --no-check"
must_pass "emergency publish" "$HP" publish "$f" --out "$tmp/t9-out" --registry-root "$tmp/site/packages" --emergency-publish-unchecked
has "$tmp/out" "THE FULL CHECK WAS SKIPPED" "an emergency publish was not loud"
[ -f "$tmp/site/packages/bump_fixture/0.0.1/bump_fixture-0.0.1.zip" ] || die "the emergency publish did not publish"
git -C "$tmp/site" log -1 --format=%s > "$tmp/subject"
has "$tmp/subject" "Publish bump_fixture 0.0.1 (UNCHECKED" "the registry commit does not record the skipped check"
ok "control: --emergency-publish-unchecked publishes and records it in the registry commit"
must_fail "republish" "refusing to overwrite immutable release" "$HP" publish "$f" --out "$tmp/t9-out" --registry-root "$tmp/site/packages" --emergency-publish-unchecked
ok "publish still refuses an existing version"

# --- 10. update-packages -----------------------------------------------------
reg="$tmp/reg10"
for spec in dep_exact:0.1.0 dep_exact:0.2.0 dep_range:0.1.5; do
  n=${spec%%:*}; v=${spec#*:}
  mkdir -p "$reg/$n/$v"
  printf '{"name":"%s","version":"%s","archive_sha256":"a","content_sha256":"c","manifest_sha256":"m"}\n' "$n" "$v" > "$reg/$n/$v/$n-$v.release.json"
  : > "$reg/$n/$v/$n-$v.zip"
done
f="$tmp/t10"; make_fixture "$f"
printf "import 'pkg:dep_exact@0.1.0/main'\nimport 'pkg:dep_range@0.1.0/main'\n" > "$f/src/uses.hey"
cp "$f/hey-package.json" "$tmp/t10-manifest"
must_pass "update-packages --dry-run" "$HP" update-packages "$f" --registry-root "$reg" --dry-run
has "$tmp/out" "dep_exact: '0.1.0' -> '0.2.0'" "the dry run did not plan the pin move"
cmp -s "$tmp/t10-manifest" "$f/hey-package.json" || die "update-packages --dry-run wrote the manifest"
[ ! -e "$f/hey.lock.json" ] || die "update-packages --dry-run wrote a lock"
ok "update-packages --dry-run plans and writes nothing"
MOCK_LOCK='{"packages":{"dep_exact":{"version":"0.2.0"},"dep_range":{"version":"0.1.5"}}}' \
  MOCK_HEY_LOG="$tmp/t10-log" MOCK_INDEX_COPY="$tmp/t10-index" \
  must_pass "update-packages" "$HP" update-packages "$f" --registry-root "$reg" --no-check
has "$f/hey-package.json" '"dep_exact": "0.2.0"' "the exact pin did not move"
has "$f/hey-package.json" '"dep_range": ">=0.1.0 <0.2.0"' "a range was rewritten"
has "$f/hey-package.json" '"modules": { "main": "src/main.hey" },' "the manifest was reformatted"
has "$f/src/uses.hey" "pkg:dep_exact@0.2.0/main" "the import did not follow the lock"
has "$tmp/t10-log" "package ensure --project $f --update-lock --registry" "ensure was not run against a registry index"
has "$tmp/t10-index" "$reg/dep_exact/0.2.0/dep_exact-0.2.0.zip" "the index does not name the local archive"
has "$tmp/t10-log" "package verify --project $f" "verify --project was not run"
ok "update-packages moves exact pins, refreshes the lock, follows imports, verifies"
has "$f/src/uses.hey" "pkg:dep_range@0.1.0/main" "an import with no recorded old version was rewritten"
ok "control: ranges and imports with no known old version stay as they are"
f="$tmp/t10b"; make_fixture "$f"
cp "$f/hey-package.json" "$tmp/t10b-manifest"
MOCK_ENSURE_FAIL=1 must_fail "failing ensure" "restored hey-package.json and hey.lock.json" "$HP" update-packages "$f" --registry-root "$reg" --no-check
cmp -s "$tmp/t10b-manifest" "$f/hey-package.json" || die "a failed update left the new pins"
[ ! -e "$f/hey.lock.json" ] || die "a failed update left a lock"
ok "negative control: a failing resolution restores the manifest and lock"

echo "hey-packager command specs: $passed passed"
