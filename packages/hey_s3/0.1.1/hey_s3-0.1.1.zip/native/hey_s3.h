#pragma once
#include "hey_native_abi.h"
HeyNativeHandle s3_open(HeyNativeUtf8View endpoint,HeyNativeUtf8View region,HeyNativeUtf8View bucket,HeyNativeUtf8View access,HeyNativeUtf8View secret,HeyNativeUtf8View token,uint32_t local);
int32_t s3_credentials(HeyNativeHandle,HeyNativeUtf8View,HeyNativeUtf8View,HeyNativeUtf8View);
int32_t s3_request(HeyNativeHandle,uint32_t,HeyNativeUtf8View,HeyNativeUtf8View,HeyNativeUtf8View,HeyNativeUtf8View,uint64_t);
HeyNativeOwnedBytes s3_header(HeyNativeHandle,HeyNativeUtf8View);
int32_t s3_close(HeyNativeHandle);
uint64_t s3_credential_age(HeyNativeHandle);
