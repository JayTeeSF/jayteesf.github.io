# Todo

1. Compile-time selection, if Hey grows a per-target constant or per-OS
   dependencies (asked of the Hey team 2026-10-13): then a Linux binary would
   not carry the kqueue/iocp porcelain at all.
2. Windows: hey_iocp has never run; Env.os() reports 'Unknown' on Windows in
   Hey 0.99.601a, so Poller.open there fails with poller_unsupported_os today.
3. io_uring on Linux if hey_epoll grows it (selected at open, epoll fallback).
