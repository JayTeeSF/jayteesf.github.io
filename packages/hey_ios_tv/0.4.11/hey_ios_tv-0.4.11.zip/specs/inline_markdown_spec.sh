#!/usr/bin/env sh
# Pins the 0.4.8 inline-markdown contract in tools/hey_native_tv_runtime.m:
# a text widget's string may carry **bold**, *italic* and `code`, and NOTHING
# else. The whole feature is additive, and the additive-ness is the part that
# can regress silently, so most of what this spec pins is what the parser must
# NOT do.
#
# The renderer is Objective-C, not Hey, so the Hey spec harness cannot
# exercise it; like back_button_spec.sh and background_color_spec.sh this spec
# mechanically pins the load-bearing decisions and then compiles the file for
# the Apple TV SDK in BOTH lanes. Each grep documents the defect it guards.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
RUNTIME="$ROOT/tools/hey_native_tv_runtime.m"

fail() { echo "inline markdown spec: $1" >&2; exit 1; }

# 1. The parser must exist and must be driven from the LABEL path, after the
#    style font and colour are chosen -- bold/italic runs are derived from
#    whatever font the widget style picked, so a call sited before the font
#    assignment would emphasise at the wrong size.
grep -q 'HeyAttributedFromMarkdown(raw, label.font, label.textColor)' "$RUNTIME" \
  || fail 'markdown never applied to the label, or not from the settled font/colour'

# 2. BACKWARD COMPATIBILITY, the first requirement: every pack already in the
#    field is unmarked text. A string with no marker must never enter the
#    parser at all and must keep the plain label.text path it has always used.
#    Without this gate an unmarked string round-trips through an attributed
#    string and any difference in that path becomes a field-wide rendering
#    change on content nobody edited.
grep -Fq 'if (raw.length && ([raw containsString:@"*"] || [raw containsString:@"`"] || [raw containsString:@"\\"]))' "$RUNTIME" \
  || fail 'unmarked text no longer bypasses the parser: every shipped pack could re-render'

# 3. UNDERSCORE IS NOT A MARKER. This app writes fill-in-the-blank stems as
#    runs of underscores ("Plant cells use the ____ to ..."); treating _ as
#    emphasis mangles every cloze question on the wall. Mechanically: the
#    renderer must contain no character comparison against '_'.
grep -q "== '_'" "$RUNTIME" && fail 'underscore became a marker: every cloze stem would be mangled'

# 4. A stray or unmatched marker is emitted LITERALLY and must not eat the
#    rest of the line. "2 * 3 * 4 equals 24" rendered as "2  3  4" with an
#    italic 3 before the flanking rule existed -- measured, not imagined.
grep -q 'appendString:marker' "$RUNTIME" \
  || fail 'unmatched marker no longer emitted literally: it would swallow the rest of the line'
grep -q 'whitespaceCharacterSet' "$RUNTIME" \
  || fail 'flanking rule gone: spaced arithmetic asterisks would italicise again'

# 5. The escape covers ONLY the markers and itself. An escape that consumed
#    whatever followed it would silently delete the backslash from unmarked
#    strings that merely contain one ("C:\Users", "\alpha", "a\b") -- content
#    that never opted into markdown, which is exactly what rule 2 protects.
grep -Eq 'next == .\*. \|\| next == .`. \|\| next == .\\\\.' "$RUNTIME" \
  || fail 'backslash escapes more than the markers: unmarked text would lose characters'

# 6. Traits come from the label's own font descriptor, at the label's own
#    point size. A hardcoded size here makes a bold run inside a 76pt title
#    render at body size -- worse than no emphasis, because it looks broken
#    from the back of the room.
grep -q 'base.fontDescriptor' "$RUNTIME" \
  || fail 'traits not derived from the label font descriptor'
grep -q 'fontWithDescriptor:nd size:base.pointSize' "$RUNTIME" \
  || fail 'emphasis size hardcoded instead of following the widget style'
grep -q 'monospacedSystemFontOfSize:base.pointSize' "$RUNTIME" \
  || fail 'code spans not sized from the label font'

# 7. It has to actually build for the Apple TV SDK, in BOTH lanes. The parser
#    is defined at file scope (v1 lane) but called from the scene-v2 renderer,
#    which is invisible to a compile without -DHEY_SCENE_V2; interpreter-green
#    is not compiled-green, and a package's gates must carry a compiled
#    receipt (hey_i18n 0.1.0 shipped uncompilable with every spec passing).
if [ "$(uname -s)" = Darwin ] && xcrun --sdk appletvos --show-sdk-path >/dev/null 2>&1; then
  clang=$(xcrun --sdk appletvos --find clang)
  sdk=$(xcrun --sdk appletvos --show-sdk-path)
  "$clang" --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -fsyntax-only "$RUNTIME" || fail 'renderer does not compile for tvOS (v1 lane)'
  "$clang" --target=arm64-apple-tvos17.0 -isysroot "$sdk" -fobjc-arc -fmodules \
    -DHEY_SCENE_V2 -fsyntax-only "$RUNTIME" || fail 'scene-v2 renderer does not compile for tvOS'
else
  echo 'inline markdown spec: no tvOS SDK here, skipped the compile check'
fi

echo 'inline markdown spec passed'
