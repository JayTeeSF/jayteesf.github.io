#!/usr/bin/env bash
# Focused S02: production player + credential transport, no emulator or network.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-media-origin.XXXXXX")
trap 'rm -rf "$work"' EXIT
java_home=$(hey_android_java_home)
mkdir -p "$work/classes" "$work/context"
find "$ROOT/renderer/java" "$ROOT/renderer/instrumentation/boundaries/stubs" -name '*.java' > "$work/sources"
printf '%s\n' "$ROOT/renderer/instrumentation/boundaries/host/hey/android/api/MediaOriginMain.java" >> "$work/sources"
for name in HeyAndroidPlayer HeyAndroidMediaSource; do printf '%s\n' "$ROOT/renderer/android/hey/android/api/$name.java" >> "$work/sources"; done
"$java_home/bin/javac" --release 17 -d "$work/classes" @"$work/sources"
"$java_home/bin/java" -cp "$work/classes" hey.android.api.MediaOriginMain "$work/context"
