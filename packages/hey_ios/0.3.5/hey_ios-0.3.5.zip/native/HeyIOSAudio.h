// HeyIOSAudio: the audio playback capability.
//
// Plays ONE row at a time:
//   {title, subtitle, image_url, kind,
//    audio_url | audio_urls: [page 0, page 1, ...],
//    position_page, position_seconds}          through AVQueuePlayer, or
//   {apple_music_id}                             through MPMusicPlayerController's
//                                                application queue player, for a
//                                                subscriber.
// A row with several audio_urls (an article read aloud a page at a time) plays
// them in order and resumes at position_page / position_seconds.
//
// Owns the AVAudioSession playback category (the app's Info.plist must carry
// UIBackgroundModes=audio), the lock screen and car Now Playing information,
// and the remote commands (play, pause, toggle, stop). Reports where the
// listener is through positionReporter: every reportInterval seconds while
// playing, on pause, when another row replaces this one, and once with
// finished=YES after the last page ends.
//
// It decides nothing about WHAT may be played: the caller hands it rows a
// server already filtered. HeyIOSAudioRowPlayable is a shape check only.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSNotificationName const HeyIOSAudioStateDidChange;

// How far a jump moves, in seconds. Back a little to catch a sentence, on
// rather more to clear a break -- what a listener already expects of anything
// that plays spoken audio. One pair of numbers, so a screen, a lock screen and
// a car all move by the same amount.
static const NSInteger HeyIOSAudioSkipBack = 15;
static const NSInteger HeyIOSAudioSkipOn = 30;

typedef NS_ENUM(NSInteger, HeyIOSAudioState) {
  HeyIOSAudioStateIdle = 0,
  HeyIOSAudioStateLoading,
  HeyIOSAudioStatePlaying,
  HeyIOSAudioStatePaused,
  HeyIOSAudioStateFailed
};

typedef void (^HeyIOSAudioPositionReporter)(NSDictionary *row, NSInteger seconds, NSInteger page, BOOL finished);
typedef NSDictionary<NSString *, NSString *> *_Nullable (^HeyIOSAudioHeaders)(NSURL *url);

@interface HeyIOSAudio : NSObject
+ (instancetype)shared;
@property(nonatomic, readonly) HeyIOSAudioState state;
@property(nonatomic, readonly, copy, nullable) NSDictionary *currentRow;
@property(nonatomic, readonly) NSInteger currentPage;
@property(nonatomic, readonly, copy, nullable) NSString *lastError;
@property(nonatomic, copy, nullable) HeyIOSAudioPositionReporter positionReporter;
// Request headers for an audio url, e.g. a bearer token for the app's own
// server. Sent through AVURLAsset's HTTP header option; nil sends none.
@property(nonatomic, copy, nullable) HeyIOSAudioHeaders headersForURL;
@property(nonatomic, assign) NSTimeInterval reportInterval;
// WHERE THE LISTENER IS, for a screen that wants to show it. Seconds into the
// current page, and how long that page runs; duration is 0 when it is not
// known, which is the honest answer for live radio and for a page that is
// still opening.
@property(nonatomic, readonly) NSInteger currentSeconds;
@property(nonatomic, readonly) NSInteger currentDuration;
- (void)playRow:(NSDictionary *)row;
- (void)togglePlayPause;
// Move by seconds, back when negative, clamped to the page. Spoken audio needs
// this: back a little to catch a sentence, on rather more to clear a break.
- (void)skipBy:(NSInteger)seconds;
- (void)stop;
@end

// A row carries something this module can play: an http(s) audio_url, or an
// apple_music_id when appleMusicAvailable.
BOOL HeyIOSAudioRowPlayable(NSDictionary *row, BOOL appleMusicAvailable);

// Apple Music catalogue playback is available: the user authorised media
// library access earlier AND the account can play catalogue tracks. Never
// prompts; the completion runs on the main queue.
void HeyIOSAudioCheckAppleMusic(void (^completion)(BOOL available));

NS_ASSUME_NONNULL_END
