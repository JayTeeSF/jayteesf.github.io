package hey.android.api;
import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.*;
import android.widget.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Synthetic transcripts exercise real renderer widgets; the OS owns audio. */
public final class DictationInstrumentation extends Instrumentation {
  Activity activity;
  Intent heard;
  boolean deny;
  final AtomicInteger sends = new AtomicInteger();
  static void require(boolean ok, String message) {
    if (!ok)
      throw new AssertionError(message);
  }
  static Object field(Object o, String n) throws Exception {
    Field f = o.getClass().getDeclaredField(n);
    f.setAccessible(true);
    return f.get(o);
  }
  static Object call(Object o, String n) throws Exception {
    Method m = o.getClass().getDeclaredMethod(n);
    m.setAccessible(true);
    return m.invoke(o);
  }
  static View find(View v, String label) {
    if (label.equals(v.getContentDescription()))
      return v;
    if (v instanceof ViewGroup)
      for (int i = 0; i < ((ViewGroup)v).getChildCount(); i++) {
        View got = find(((ViewGroup)v).getChildAt(i), label);
        if (got != null)
          return got;
      }
    return null;
  }
  void result(int status) throws Exception { resultAt(status, null); }
  void resultAt(int status, Integer requested) throws Exception {
    Intent data = new Intent();
    data.putStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS,
                                 new ArrayList<>(List.of("spoken")));
    Method m = activity.getClass().getDeclaredMethod(
        "onActivityResult", int.class, int.class, Intent.class);
    m.setAccessible(true);
    Field code;
    try {
      code = activity.getClass().getDeclaredField("speechRequestCode");
    } catch (NoSuchFieldException absent) {
      code = activity.getClass().getDeclaredField("SPEECH_REQUEST_CODE");
    }
    code.setAccessible(true);
    m.invoke(activity, requested == null ? code.getInt(activity) : requested,
             status, data);
  }
  void launch(View root, EditText edit, String label) {
    edit.setText("before OLD after");
    edit.setSelection(7, 10);
    View mic = find(root, "Dictate " + label);
    require(mic != null, "missing prompt/form speech control " + label);
    mic.performClick();
    require(heard != null && RecognizerIntent.ACTION_RECOGNIZE_SPEECH.equals(
                                 heard.getAction()),
            "standard system speech intent missing");
  }
  @Override
  public void onCreate(Bundle args) {
    super.onCreate(args);
    start();
  }
  @Override
  public void onStart() {
    Bundle out = new Bundle();
    try {
      addMonitor(new ActivityMonitor() {
        @Override
        public ActivityResult onStartActivity(Intent intent) {
          if (!RecognizerIntent.ACTION_RECOGNIZE_SPEECH.equals(
                  intent.getAction()))
            return null;
          if (deny)
            throw new SecurityException("synthetic denial");
          heard = intent;
          return new ActivityResult(Activity.RESULT_CANCELED, null);
        }
      });
      activity = startActivitySync(
          new Intent()
              .setClassName(getTargetContext().getPackageName(),
                            "hey.android.api.HeyAndroidApiActivity")
              .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
      waitForIdleSync();
      java.util.concurrent.atomic.AtomicReference<Throwable> failure =
          new java.util.concurrent.atomic.AtomicReference<>();
      runOnMainSync(() -> {
        try {
          View root = activity.getWindow().getDecorView();
          EditText edit = (EditText)find(root, "Message");
          require(edit != null, "missing form");
          launch(root, edit, "Message");
          result(Activity.RESULT_OK);
          require("before spoken after".contentEquals(edit.getText()),
                  "form dictation must replace selection and preserve suffix");
          require(edit.getSelectionStart() == 13,
                  "caret must follow transcript");
          launch(root, edit, "Message");
          int previousRequest;
          try {
            previousRequest =
                ((Number)field(activity, "speechRequestCode")).intValue();
          } catch (NoSuchFieldException absent) {
            previousRequest =
                ((Number)field(activity, "SPEECH_REQUEST_CODE")).intValue();
          }
          launch(root, edit, "Message");
          resultAt(Activity.RESULT_OK, previousRequest);
          require("before OLD after".contentEquals(edit.getText()),
                  "previous recognizer request changed a new draft");
          result(Activity.RESULT_OK);
          require("before spoken after".contentEquals(edit.getText()),
                  "previous result cleared current recognizer request");
          launch(root, edit, "Message");
          result(Activity.RESULT_CANCELED);

          require("before OLD after".contentEquals(edit.getText()),
                  "cancel changed draft");
          launch(root, edit, "Message");
          edit.setText("new typed draft");
          result(Activity.RESULT_OK);
          require("new typed draft".contentEquals(edit.getText()),
                  "late speech overwrote typing");
          deny = true;
          launch(root, edit, "Message");
          result(Activity.RESULT_OK);
          deny = false;
          require("before OLD after".contentEquals(edit.getText()),
                  "denied recognizer changed draft");
          Actions.Host page = (Actions.Host)call(activity, "top");
          Map<String, Object> action = Map.of(
              "title", "Share", "prompt",
              Map.of("title", "Share note", "fields",
                     List.of(Map.of("id", "note", "label", "Note", "kind",
                                    "multiline", "speech_input", true),
                             Map.of("id", "reason", "label", "Reason", "kind",
                                    "prose", "speech_input", true),
                             Map.of("id", "secret", "label", "Secret", "kind",
                                    "secure", "speech_input", true))));
          page.prompt(action, null, Map.of(), vars -> sends.incrementAndGet());
        } catch (Throwable e) {
          failure.set(e);
        }
      });
      if (failure.get() != null)
        throw failure.get();
      waitForIdleSync();
      android.graphics.Bitmap screenshot = getUiAutomation().takeScreenshot();
      try (java.io.FileOutputStream image =
               new java.io.FileOutputStream(new java.io.File(
                   getTargetContext().getFilesDir(), "dictation-prompt.png"))) {
        require(screenshot != null &&
                    screenshot.compress(
                        android.graphics.Bitmap.CompressFormat.PNG, 100, image),
                "prompt screenshot failed");
      } finally {
        if (screenshot != null)
          screenshot.recycle();
      }
      runOnMainSync(() -> {
        try {
          View root = activity.getWindow().getDecorView();
          EditText edit = (EditText)find(root, "Message");
          Actions.Host page = (Actions.Host)call(activity, "top");
          // AlertDialog windows are found through the renderer's generic dialog
          // state.

          AlertDialog dialog = (AlertDialog)field(activity, "activePrompt");
          EditText note =
              (EditText)find(dialog.getWindow().getDecorView(), "Note");
          require(find(dialog.getWindow().getDecorView(), "Dictate Secret") ==
                      null,
                  "secure prompt gained microphone");
          launch(dialog.getWindow().getDecorView(), note, "Note");
          result(Activity.RESULT_OK);
          require("before spoken after".contentEquals(note.getText()),
                  "prompt must insert selection");
          EditText reason =
              (EditText)find(dialog.getWindow().getDecorView(), "Reason");
          launch(dialog.getWindow().getDecorView(), reason, "Reason");
          result(Activity.RESULT_OK);
          require("before spoken after".contentEquals(reason.getText()),
                  "prose prompt selection failed");
          require("before spoken after".contentEquals(note.getText()),
                  "prompt dictation changed a sibling field");
          launch(dialog.getWindow().getDecorView(), note, "Note");
          result(Activity.RESULT_CANCELED);
          require("before OLD after".contentEquals(note.getText()),
                  "prompt cancel changed draft");
          launch(dialog.getWindow().getDecorView(), note, "Note");
          dialog.dismiss();
          result(Activity.RESULT_OK);

          require("before OLD after".contentEquals(note.getText()),
                  "dismissed dialog accepted transcript");
          launch(root, edit, "Message");
          call(page, "leave");
          result(Activity.RESULT_OK);
          require("before OLD after".contentEquals(edit.getText()),
                  "stale page accepted transcript");
          launch(root, edit, "Message");
          Method account = activity.getClass().getDeclaredMethod("keepSession",
                                                                 String.class);
          account.setAccessible(true);
          require(Boolean.TRUE.equals(
                      account.invoke(activity, "synthetic-next-account")),
                  "synthetic account change failed");
          result(Activity.RESULT_OK);
          require("before OLD after".contentEquals(edit.getText()),
                  "account teardown accepted transcript");
          require(sends.get() == 0, "speech automatically saved or shared");
        } catch (Throwable e) {
          failure.set(e);
        }
      });
      if (failure.get() != null)
        throw failure.get();
      out.putString("stream",
                    "dictation_fields=true selection=true prompt=true "
                        + "cancel=true stale=true explicit_save=true");
      finish(Activity.RESULT_OK, out);
    } catch (Throwable e) {
      out.putString("stream", "FAIL: " + e);
      finish(Activity.RESULT_CANCELED, out);
    } finally {
      if (activity != null)
        runOnMainSync(activity::finish);
    }
  }
}
