# Continue hey_poller

Read README.md, docs/DESIGN.md, todos.md, done.md, poller.hey and the specs
before editing.

hey_poller is the one event-loop package applications depend on. It owns the
selection rule (Poller.backend_for) and nothing else: the loops live in
hey_epoll (Linux), hey_kqueue (macOS/BSD), hey_iocp (Windows, experimental)
and hey_io_uring (Linux, selected by name only, with an epoll fallback),
which keep one native function table between them so the serving calls need
no dispatch. Never select a backend that has not run on that OS without
saying so (hey_iocp is unverified), and do not make io_uring Linux's default
without an x86 measurement that says it is faster.

Verify with:

```sh
hey package ensure --project . --locked
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
bin/linux-check            # Linux containers: epoll, the io_uring fallback, io_uring itself
bench/compare              # wrk: poller vs the backend directly vs Web.serve
```

Published versions are immutable. Change the version whenever released bytes change.
