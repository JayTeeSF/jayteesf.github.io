#!/usr/bin/env bash
# tools/hey-android-emulator.sh: the dedicated emulator for hey_android runs.
#
#   create-avd          create the pinned AVD from the Play image (does nothing if it exists)
#   boot [--port N]     start it headless and wait for boot; prints serial=emulator-N
#   shutdown SERIAL     stop it, and wait until its process is gone
#   status              list running emulator processes
#
# EVERY RUN THAT BOOTS THE EMULATOR SHUTS IT DOWN. A left-running emulator holds
# gigabytes of memory, and this Mac has already run out once because simulators
# were left running. The app tool and the specs call shutdown from an EXIT trap.
set -euo pipefail
HEY_ANDROID_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
. "$HEY_ANDROID_ROOT/tools/android-env.sh"
hey_android_isolate

state_dir=${TMPDIR:-/tmp}/hey_android-emulator
mkdir -p "$state_dir"
die() { printf 'hey-android-emulator: %s\n' "$*" >&2; exit 1; }
emulator_pids() { pgrep -f "qemu-system.*-port $1( |$)" 2>/dev/null || true; }

create_avd() {
  if "$HEY_ANDROID_EMULATOR_BIN" -list-avds 2>/dev/null | grep -Fxq "$HEY_ANDROID_AVD"; then
    printf 'avd ok name=%s\n' "$HEY_ANDROID_AVD"
    return
  fi
  java_home=$(hey_android_java_home)
  [ -n "$java_home" ] || die "JDK $HEY_ANDROID_JDK is required by avdmanager; run bin/android-doctor"
  [ -x "$HEY_ANDROID_AVDMANAGER" ] || die "avdmanager not found: $HEY_ANDROID_AVDMANAGER; run bin/android-doctor"
  printf 'no\n' | env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$HEY_ANDROID_AVDMANAGER" create avd \
    --name "$HEY_ANDROID_AVD" --package "$HEY_ANDROID_SYSTEM_IMAGE" --device "$HEY_ANDROID_AVD_DEVICE" >/dev/null
  config=$HOME/.android/avd/$HEY_ANDROID_AVD.avd/config.ini
  [ -f "$config" ] || die "avdmanager did not create $config"
  grep -v '^avd.ini.displayname=' "$config" > "$config.tmp" || true
  printf 'avd.ini.displayname=%s\n' "$HEY_ANDROID_AVD_DISPLAY" >> "$config.tmp"
  mv "$config.tmp" "$config"
  printf 'avd created name=%s display_name="%s" image=%s device=%s\n' "$HEY_ANDROID_AVD" "$HEY_ANDROID_AVD_DISPLAY" "$HEY_ANDROID_SYSTEM_IMAGE" "$HEY_ANDROID_AVD_DEVICE"
}

boot() {
  port=$HEY_ANDROID_EMULATOR_PORT
  if [ "${1:-}" = --port ]; then port=${2:?--port needs a number}; fi
  serial=emulator-$port
  "$HEY_ANDROID_EMULATOR_BIN" -list-avds 2>/dev/null | grep -Fxq "$HEY_ANDROID_AVD" || die "AVD $HEY_ANDROID_AVD does not exist; run: $0 create-avd"
  [ -z "$(emulator_pids "$port")" ] || die "an emulator is already running on port $port; stop it first: $0 shutdown $serial"
  if pgrep -f "qemu-system.*-avd $HEY_ANDROID_AVD( |$)" >/dev/null 2>&1; then die "AVD $HEY_ANDROID_AVD is already running on another port; see: $0 status"; fi
  log=$state_dir/$serial.log
  nohup "$HEY_ANDROID_EMULATOR_BIN" -avd "$HEY_ANDROID_AVD" -port "$port" -no-window -no-audio -no-snapshot \
    -no-boot-anim -gpu swiftshader_indirect > "$log" 2>&1 &
  pid=$!
  printf '%s\n' "$pid" > "$state_dir/$serial.pid"
  "$HEY_ANDROID_ADB" start-server >/dev/null 2>&1 || true
  deadline=$((SECONDS + ${HEY_ANDROID_BOOT_TIMEOUT:-300}))
  booted=''
  while [ $SECONDS -lt $deadline ]; do
    if ! kill -0 "$pid" 2>/dev/null; then
      tail -20 "$log" >&2
      die "the emulator exited during boot; log: $log"
    fi
    booted=$("$HEY_ANDROID_ADB" -s "$serial" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r' || true)
    [ "$booted" = 1 ] && break
    /bin/sleep 2
  done
  if [ "$booted" != 1 ]; then
    shutdown_serial "$serial" >&2 || true
    die "the emulator did not finish booting in ${HEY_ANDROID_BOOT_TIMEOUT:-300} seconds; log: $log"
  fi
  "$HEY_ANDROID_ADB" -s "$serial" shell wm dismiss-keyguard >/dev/null 2>&1 || true
  printf 'serial=%s pid=%s avd=%s boot_seconds=%s log=%s\n' "$serial" "$pid" "$HEY_ANDROID_AVD" "$SECONDS" "$log"
}

shutdown_serial() {
  serial=${1:?shutdown needs a serial such as emulator-$HEY_ANDROID_EMULATOR_PORT}
  port=${serial#emulator-}
  case "$port" in ''|*[!0-9]*) die "not an emulator serial: $serial" ;; esac
  "$HEY_ANDROID_ADB" -s "$serial" emu kill >/dev/null 2>&1 || true
  deadline=$((SECONDS + 60))
  while [ $SECONDS -lt $deadline ] && [ -n "$(emulator_pids "$port")" ]; do /bin/sleep 1; done
  pids=$(emulator_pids "$port")
  if [ -n "$pids" ]; then
    kill $pids 2>/dev/null || true
    /bin/sleep 5
    pids=$(emulator_pids "$port")
    [ -z "$pids" ] || kill -9 $pids 2>/dev/null || true
    /bin/sleep 1
  fi
  pidfile=$state_dir/$serial.pid
  if [ -f "$pidfile" ]; then
    launcher=$(cat "$pidfile")
    kill -0 "$launcher" 2>/dev/null && kill "$launcher" 2>/dev/null || true
    rm -f "$pidfile"
  fi
  [ -z "$(emulator_pids "$port")" ] || die "the emulator on port $port is still running"
  printf 'stopped serial=%s\n' "$serial"
}

case "${1:-}" in
  create-avd) create_avd ;;
  boot) shift; boot "$@" ;;
  shutdown) shift; shutdown_serial "$@" ;;
  status) pgrep -fl 'qemu-system' || echo 'no emulator is running' ;;
  *) sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//' >&2; exit 2 ;;
esac
