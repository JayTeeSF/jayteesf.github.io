# In progress

- Prove generated package projects consume `hey_packager` from a locked installed dependency rather than a sibling checkout.
