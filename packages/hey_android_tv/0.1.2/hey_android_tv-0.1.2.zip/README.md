# hey_android_tv

Native Android TV and Google TV adapter for target-neutral Hey television applications.

This is an independently versioned third-party Hey package. It is not part
of Hey core or the standard library.

## Package boundary

See `docs/DESIGN.md`. The package consumes current published dependencies
from `https://www.jayteesf.com/packages/` and delegates release/source ZIP/
publication controls to `hey_packager`.

## Development

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"
bin/check
```

## Release and publish

```sh
bin/release
bin/source-zip
bin/publish --no-commit
```

Existing immutable versions must never be replaced.

## Build and release tooling

`hey_packager` is declared in `dependencies` as `">=0.1.1 <0.2.0"`, so it appears
in an application's lock; no module imports it. It provides `bin/check`,
`bin/bump`, `bin/release` (builds the release, does not publish) and
`bin/publish` (commits `packages/NAME/VERSION` to
`~/dev/jayteesf.github.io/packages`; never overwrites, never pushes).
`bin/package-zip` and `bin/source-zip` also run through it.
