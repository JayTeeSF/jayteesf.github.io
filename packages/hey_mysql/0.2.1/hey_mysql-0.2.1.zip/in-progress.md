# In progress

0.2.1 is the Connector/C compatibility release extracted from Hey v0.99.269a. The base package gate is green. The configured live-server gate must still be run on real MySQL and MariaDB servers with the desired authentication and TLS policies. Full live-SQL direct-LLVM execution remains a generic compiler supported-subset receipt, not a reason to move driver code into Hey.
