# hey_iocp

> **EXPERIMENTAL / UNVERIFIED.** hey_iocp has never been loaded or run on
> Windows. It compiles and links into a windows-x64 DLL (cross-built from
> macOS with LLVM, checked for format, exports and imports), and that is all
> that has been proven. Hey 0.99.601a cannot run it anyway: there is no Windows
> Hey compiler distribution, `Native.open` loads libraries with `dlopen` only,
> and `Env.os()` reports `Unknown` on Windows. Do not depend on it for anything
> but following its progress.

The Windows backend of Hey's batched TCP event loop, on I/O completion ports.
The API is [hey_epoll](https://www.jayteesf.com/packages/hey_epoll/)'s `Epoll`
name for name (plus `backend()`), so code written for hey_epoll or hey_kqueue
would run on it unchanged; **hey_poller** selects it when `Env.os()` says
`windows`.

## Build (cross-compile)

```sh
brew install llvm lld          # clang, lld-link, llvm-dlltool, llvm-readobj
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/build-native
```

Output: `.native-build/windows-x64/hey_iocp.dll`. No Windows SDK or MinGW: the
source declares the 27 Win32/CRT entry points it uses, and the build generates
import libraries for ws2_32, kernel32 and msvcrt from .def files.

## API

| Call | What it does |
|---|---|
| `Iocp.version()` | This package's version. |
| `Iocp.backend()` | `'iocp'`. |
| `Iocp.open(host, port, options)` | Listen (IPv4). `backlog` (SOMAXCONN), `library_path`; `reuseport` is ignored (Windows has no load-spreading equivalent). On a system that is not Windows: error `iocp_unsupported_os`. |
| `Iocp.wait(loop, timeout_ms)` | The only blocking call (`GetQueuedCompletionStatusEx`, up to 1024 completions). |
| `Iocp.next`, `Iocp.data`, `Iocp.send`, `Iocp.drop`, `Iocp.stats`, `Iocp.close` | As `Epoll`. `stats` adds `completions` and `zombies` (closed connections whose cancelled operations have not come back yet). |

## Check

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
```

See [docs/TESTING.md](docs/TESTING.md) for exactly what that proves (and does not).
