#ifndef HEY_EPOLL_H
#define HEY_EPOLL_H

#include "hey_native_abi.h"

/* One event loop: a nonblocking TCP listener plus every connection it accepted,
   multiplexed by epoll (Linux) or kqueue (Darwin/BSD, for development).
   A loop is owned by exactly one Hey thread. */
HeyNativeHandle hey_epoll_open(HeyNativeUtf8View host, int32_t port, int32_t backlog, HeyNativeBool reuseport);
int32_t hey_epoll_close(HeyNativeHandle loop);
int32_t hey_epoll_wait(HeyNativeHandle loop, int32_t timeout_ms);
int64_t hey_epoll_next(HeyNativeHandle loop);
HeyNativeUtf8View hey_epoll_data(HeyNativeHandle loop, int64_t connection);
int32_t hey_epoll_send(HeyNativeHandle loop, int64_t connection, int64_t consumed, HeyNativeUtf8View data, HeyNativeBool close_after);
int32_t hey_epoll_drop(HeyNativeHandle loop, int64_t connection);
int32_t hey_epoll_port(HeyNativeHandle loop);
HeyNativeUtf8View hey_epoll_stats(HeyNativeHandle loop);
HeyNativeUtf8View hey_epoll_backend(void);

#endif
