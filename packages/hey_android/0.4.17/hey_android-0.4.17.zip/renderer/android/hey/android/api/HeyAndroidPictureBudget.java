package hey.android.api;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.ToLongFunction;

/**
 * The arithmetic and bookkeeping behind HeyAndroidPictures, kept free of
 * android.* so a host test can prove it without a device.
 *
 * <p>Three budgets, because a count of pictures says nothing about memory: a
 * 4 MiB PNG can describe 20000 x 20000 pixels, which is 1.6 GB once decoded.
 *
 * <ul>
 *   <li>SOURCE: a picture whose header declares more than MAX_SOURCE_PIXELS, or
 *       a side over MAX_SOURCE_SIDE, is refused from its bounds alone, before
 *       any decode -- even a sampled decoder has to walk every source pixel.
 *   <li>DECODE: what is kept is sampled down until its longest side fits the
 *       place it is drawn (a row, or the picture at the top of a screen).
 *   <li>HELD: the cache is limited by decoded BYTES, oldest dropped first, and
 *       one picture may take at most a quarter of it.
 * </ul>
 *
 * Plus one fetch per address however many rows want it, and a cap on how many
 * may wait: a fling through hundreds of rows must not queue hundreds of
 * downloads. A row that was skipped asks again when it is bound again.
 */
final class HeyAndroidPictureBudget {
  static final int MAX_SOURCE_SIDE = 12000;
  static final long MAX_SOURCE_PIXELS = 40_000_000L;
  /** Longest decoded side for a list row (drawn at most a few hundred pixels). */
  static final int ROW_SIDE = 512;
  /** Longest decoded side for the picture at the top of a screen. */
  static final int FULL_SIDE = 2048;
  /** Fetches that may be queued or running at once. */
  static final int MAX_WAITING = 48;

  private HeyAndroidPictureBudget() {}

  /** True when a picture with these declared bounds may be decoded at all. */
  static boolean acceptable(int width, int height) {
    if (width <= 0 || height <= 0) return false;
    if (width > MAX_SOURCE_SIDE || height > MAX_SOURCE_SIDE) return false;
    return (long) width * height <= MAX_SOURCE_PIXELS;
  }

  /** The smallest power-of-two sample whose result fits maxSide on its longest side. */
  static int sampleSize(int width, int height, int maxSide) {
    int longest = Math.max(width, height);
    int sample = 1;
    while (longest / sample > maxSide && sample < (1 << 14)) sample <<= 1;
    return sample;
  }

  /**
   * The decoded-byte budget for held pictures: an eighth of what this process
   * may allocate, never more than 48 MiB and never less than 8 MiB.
   */
  static long heldBudget(long maxHeap) {
    long eighth = maxHeap / 8;
    return Math.max(8L * 1024 * 1024, Math.min(48L * 1024 * 1024, eighth));
  }

  /** Least-recently-used values, bounded by the sum of their sizes. Not thread-safe; callers lock. */
  static final class Held<V> {
    private final long limit;
    private final ToLongFunction<V> sizer;
    private final LinkedHashMap<String, V> values = new LinkedHashMap<>(16, 0.75f, true);
    private long total;

    Held(long limit, ToLongFunction<V> sizer) {
      this.limit = limit;
      this.sizer = sizer;
    }

    V get(String key) {
      return values.get(key);
    }

    /** False when the value alone is over a quarter of the budget: drawn, but not kept. */
    boolean put(String key, V value) {
      long size = sizer.applyAsLong(value);
      if (size > limit / 4) return false;
      V old = values.remove(key);
      if (old != null) total -= sizer.applyAsLong(old);
      values.put(key, value);
      total += size;
      Iterator<Map.Entry<String, V>> eldest = values.entrySet().iterator();
      while (total > limit && eldest.hasNext()) {
        Map.Entry<String, V> e = eldest.next();
        if (e.getKey().equals(key)) continue;
        total -= sizer.applyAsLong(e.getValue());
        eldest.remove();
      }
      return true;
    }

    long total() {
      return total;
    }

    int size() {
      return values.size();
    }

    long limit() {
      return limit;
    }

    void clear() {
      values.clear();
      total = 0;
    }
  }

  /** Callers waiting on one fetch per key. Not thread-safe; callers lock. */
  static final class Waiting<T> {
    private final int cap;
    private final LinkedHashMap<String, List<T>> waiting = new LinkedHashMap<>();

    Waiting(int cap) {
      this.cap = cap;
    }

    /**
     * FETCH when this caller should start the fetch, JOINED when one is already
     * under way and it will be told with the rest, FULL when too many are
     * waiting and it should simply ask again later.
     */
    enum Joined { FETCH, JOINED, FULL }

    Joined join(String key, T caller) {
      List<T> already = waiting.get(key);
      if (already != null) {
        already.add(caller);
        return Joined.JOINED;
      }
      if (waiting.size() >= cap) return Joined.FULL;
      List<T> first = new ArrayList<>();
      first.add(caller);
      waiting.put(key, first);
      return Joined.FETCH;
    }

    /** Everyone who waited on key, removed. Empty when nobody did (a cleared session). */
    List<T> finish(String key) {
      List<T> done = waiting.remove(key);
      return done == null ? new ArrayList<>() : done;
    }

    int size() {
      return waiting.size();
    }

    void clear() {
      waiting.clear();
    }
  }
}
