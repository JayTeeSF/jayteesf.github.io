# hey_kqueue

The kqueue backend for Hey's batched TCP event loop: macOS, FreeBSD, OpenBSD,
NetBSD and DragonFly. One native call waits for readiness, accepts every
pending connection and reads every readable socket; the Hey program takes each
connection's unconsumed input as text, parses its protocol in Hey, and hands
back a reply plus the number of bytes it consumed.

The API is [hey_epoll](https://www.jayteesf.com/packages/hey_epoll/)'s `Epoll`,
name for name (plus `backend()`), so code written for one runs on the other.
Most applications should depend on **hey_poller**, which picks hey_epoll on
Linux, hey_kqueue on macOS/BSD and hey_iocp on Windows.

What is kqueue-specific (and why it is a package of its own):

- registrations go into a changelist that the next `wait()` hands to the kernel
  in the same `kevent()` call, so accepting a connection or arming write
  interest costs no system call of its own;
- accepted sockets inherit `O_NONBLOCK`, `SO_NOSIGPIPE` and `TCP_NODELAY` from
  the listener (checked once per loop), instead of 4-5 system calls per accept;
- the listener's event carries the pending-connection count, which bounds the
  accept loop.

Measured on an Apple M3 Pro with wrk (4 threads, 64 connections, keep-alive,
10 s rounds), on a quiet machine: hey_kqueue **177k req/s on one core**,
hey_epoll 0.1.1's kqueue path 176.5k (the same, within 1%), stdlib `Web.serve`
186k-190k using 4.3-4.5 cores (43k req per CPU-second against the loop's 177k).
With a new connection per request (Connection: close), hey_kqueue spends about
10% less CPU per request than hey_epoll's kqueue path (76k-78k against 69k-70k
requests per CPU-second): that is where the batched registrations and
inherited socket options pay. Details and the earlier, noisier runs:
[docs/DESIGN.md](docs/DESIGN.md#measurements).

## Build the native library

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/build-native
```

Output: `.native-build/<target>/libhey_kqueue.dylib` (`.so` on the BSDs). It
refuses to build on Linux or Windows. Applications build it outside the
immutable installed package, for example into
`.hey/native/hey_kqueue/<version>/<target>/`, or point `HEY_KQUEUE_LIBRARY` at it.
No libraries beyond libc.

## Use it

```hey
import 'pkg:hey_kqueue@0.1.1/kqueue'

program
  let loop = Kqueue.open('0.0.0.0', 8080, {backlog: 4096}).value
  while true
    let ready = Kqueue.wait(loop, 1000)          # connections with new input
    let id = Kqueue.next(loop)
    while id >= 0
      let text = Kqueue.data(loop, id)           # every unconsumed byte so far
      # ... frame one request of `used` bytes, build `reply` ...
      let sent = Kqueue.send(loop, id, used, reply, false)
      set id = Kqueue.next(loop)
    end
  end
end
```

| Call | What it does |
|---|---|
| `Kqueue.version()` | This package's version. |
| `Kqueue.backend()` | `'kqueue'`. |
| `Kqueue.open(host, port, options)` | Listen (IPv4). `backlog` (4096), `reuseport` (false), `library_path`. Raises the soft descriptor limit (to at most 10240 on macOS). Result value: `{extension, handle, port, backend}`. On a system without kqueue: error `kqueue_unsupported_os`. |
| `Kqueue.wait(loop, timeout_ms)` | The only blocking call. Returns how many connections have unconsumed input (-1 if the loop is gone). Untaken connections and pipelined leftovers are offered again without waiting. |
| `Kqueue.next(loop)` | Next connection id of the batch, or -1. Ids carry a generation, so a stale id never reaches a new socket. |
| `Kqueue.data(loop, id)` | The connection's unconsumed input as text. Input that is not UTF-8 text (or holds NUL) closes the connection and returns `''`. |
| `Kqueue.send(loop, id, consumed, text, close_after)` | Drops `consumed` input bytes, writes `text` (queued with write-readiness backpressure if the socket is full), closes after the write when asked. False when the connection is gone. |
| `Kqueue.drop(loop, id)` | Close now. |
| `Kqueue.stats(loop)` | hey_epoll's counters plus `changes` (registrations sent), `early_flushes` and `inherits`. |
| `Kqueue.close(loop)` | Close every connection, the listener, and unload. |

A loop belongs to the thread that opened it. On macOS `reuseport: true` lets
several loops bind one port but the kernel does not spread connections across
them; one loop per process is the shape that scales today (see ROADMAP).

## Check

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
bench/macos
```

See [docs/TESTING.md](docs/TESTING.md).
