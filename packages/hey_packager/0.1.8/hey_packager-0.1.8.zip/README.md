# hey_packager

`hey_packager` is package-owned porcelain for releasing and publishing Hey
packages. It keeps website-specific policy out of `stdlib:Packages` while giving
every package the same verified ZIP, release metadata, checksums, documentation,
source handoff, and immutable registry workflow.

```sh
bin/hey-packager --help
bin/check
bin/release
bin/publish
```

The default website registry is:

```text
$HOME/dev/jayteesf.github.io/packages
```

Override it with `--registry-root` or `HEY_PACKAGE_REGISTRY_ROOT`.

## Standard package controls

Adopt `hey_packager` by declaring `"hey_packager": ">=0.1.1 <0.2.0"` and copying its canonical `bin/hey-packager`, `bin/check`, `bin/bump`, `bin/release`, `bin/publish`, `bin/package-zip`, `bin/source-zip`, and `bin/update_packages`. Copy them byte for byte; put anything package-specific in the two hooks below, never in the copies. `bin/release` only builds release artifacts under `dist/`; `bin/publish` is the separate step that copies the version into the registry and commits it there (it never pushes).

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish
```

`bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_packager`; bump first with `bin/bump VERSION` (the script supplies the package root). Pass `--no-commit` to leave the registry checkout uncommitted.

## Package hooks

A package extends the shared commands in two places, and nowhere else:

| Hook | Run by | Purpose |
| --- | --- | --- |
| `bin/package-check` | `bin/check` (and so `bin/release`, `bin/publish`) | package tests |
| `hey-version-files` | `bin/bump`, `bin/check` | every other file that repeats the version |
| `bin/package-bump OLD NEW` | `bin/bump`, after the declared copies move | version steps a fixed rule cannot express |

### Bumping the version

```sh
bin/bump patch             # or minor, major, or an exact 1.2.3
bin/bump 0.2.0 --dry-run   # the whole bump in a scratch copy; prints the diff
bin/bump --normalize 0.1.7 # VERSION was edited by hand: move the rest to match
```

`bin/bump` moves `VERSION`, the manifest `"version"`, and every copy declared in
`hey-version-files`, one `PATH [MARKER]` per line:

```text
main.hey return '
specs/api_spec.hey expect stdout
docs/README.md # hey_example
```

Only whole copies change (`0.1.7` matches `v0.1.7` and `pkg-0.1.7.zip`, never
`0.1.70` or `10.1.7`). When a `MARKER` is given, only lines containing it change,
so a dependency that shares the number, or a roadmap heading, is left alone.
Then `bin/package-bump OLD NEW` runs if present. Afterwards every declared file
is read back: if any still holds the old version, or none holds the new one, the
bump fails and restores `VERSION`, the manifest and the declared files. Lines
elsewhere that still mention the old version are listed so a missing declaration
takes one read to find. `bin/check` fails when a declared copy does not hold the
current version.

The new version must be higher and not already published. A redundant root
(`bin/bump . patch`, `bin/check .`) is accepted; a different second path is refused.

### The check before release and publish

`bin/release` and `bin/publish` run the full check first (the package's own
`bin/check`, or the shared check when it has none) and refuse if it is red.
`bin/release --no-check` builds anyway, with a loud warning. `bin/publish` refuses
`--no-check`; the emergency override is `--emergency-publish-unchecked`, which
prints the same warning and records `UNCHECKED` in the registry commit message.

### Refreshing dependencies

`bin/update_packages` moves exact dependency pins to the highest version in the
local registry checkout (ranges are left alone; `--latest` replaces them too),
refreshes `hey.lock.json` with `hey package ensure --update-lock`, moves
`pkg:NAME@OLD/` imports to the locked version, runs `hey package verify
--project`, and runs the full check. `--dry-run` prints the plan and writes nothing; a
failed resolution restores the manifest and lock.
