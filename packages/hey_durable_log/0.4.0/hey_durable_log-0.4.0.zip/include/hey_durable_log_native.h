#ifndef HEY_DURABLE_LOG_NATIVE_H
#define HEY_DURABLE_LOG_NATIVE_H

#include "hey_native_abi.h"

HeyNativeHandle hey_durable_log_native_open(HeyNativeUtf8View path,
                                            int32_t queue_capacity,
                                            int32_t max_batch_records,
                                            int32_t batch_window_microseconds,
                                            int64_t segment_size_bytes);
int32_t hey_durable_log_native_close(HeyNativeHandle connection);
/* Classify a failed open. `open` can only answer "a handle or nothing", which
   collapses corruption, a bad path and ENOMEM into one indistinguishable
   failure -- and an operator's response to a CORRUPT journal (stop, restore
   from a verified snapshot) is nothing like the response to a typo. This
   re-runs the open and reports the hdl_status it reached, closing anything it
   managed to open. It is called only on the failure path. */
int32_t hey_durable_log_native_open_status(HeyNativeUtf8View path,
                                           int32_t queue_capacity,
                                           int32_t max_batch_records,
                                           int32_t batch_window_microseconds,
                                           int64_t segment_size_bytes);
HeyNativeHandle hey_durable_log_native_submit(HeyNativeHandle connection,
                                               int64_t stream_id,
                                               HeyNativeBytesView payload);
int32_t hey_durable_log_native_receipt_status(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_sequence(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_batch_id(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_durable_offset(HeyNativeHandle receipt);
void hey_durable_log_native_receipt_close(HeyNativeHandle receipt);
HeyNativeHandle hey_durable_log_native_submit_within(HeyNativeHandle connection,
                                                    int64_t stream_id,
                                                    HeyNativeBytesView payload,
                                                    int64_t admission_timeout_microseconds);
HeyNativeHandle hey_durable_log_native_snapshot_create(HeyNativeHandle connection,
                                                      HeyNativeUtf8View directory);
HeyNativeHandle hey_durable_log_native_snapshot_verify(HeyNativeUtf8View directory);
int32_t hey_durable_log_native_snapshot_restore(HeyNativeUtf8View snapshot_directory,
                                                HeyNativeUtf8View journal_directory);
int32_t hey_durable_log_native_retire(HeyNativeHandle connection, HeyNativeUtf8View directory);
int32_t hey_durable_log_native_snapshot_status(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_records(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_first_sequence(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_last_sequence(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_snapshot_digest(HeyNativeHandle snapshot);
void hey_durable_log_native_snapshot_close(HeyNativeHandle snapshot);
int64_t hey_durable_log_native_last_sequence(HeyNativeHandle connection);
HeyNativeHandle hey_durable_log_native_stats_open(HeyNativeHandle connection);
int32_t hey_durable_log_native_stats_status(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_records(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_durable_batches(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_largest_batch(HeyNativeHandle stats);
int64_t hey_durable_log_native_stats_max_queue_depth(HeyNativeHandle stats);
void hey_durable_log_native_stats_close(HeyNativeHandle stats);
HeyNativeHandle hey_durable_log_native_cursor_open(HeyNativeHandle connection);
HeyNativeHandle hey_durable_log_native_cursor_open_at(HeyNativeHandle connection, int64_t position);
int64_t hey_durable_log_native_record_position(HeyNativeHandle record);
int64_t hey_durable_log_native_record_next_position(HeyNativeHandle record);
HeyNativeHandle hey_durable_log_native_cursor_next(HeyNativeHandle cursor);
int32_t hey_durable_log_native_cursor_close(HeyNativeHandle cursor);
int32_t hey_durable_log_native_record_status(HeyNativeHandle record);
int64_t hey_durable_log_native_record_sequence(HeyNativeHandle record);
int64_t hey_durable_log_native_record_batch_id(HeyNativeHandle record);
int64_t hey_durable_log_native_record_stream_id(HeyNativeHandle record);
HeyNativeBytesView hey_durable_log_native_record_payload(HeyNativeHandle record);
void hey_durable_log_native_record_close(HeyNativeHandle record);

#endif
