// THE HOST'S REQUEST CHAINS UNDER ADDRESSSANITIZER, on the iOS Simulator.
//
// Built by bin/block-lifetimes with native/HeyIOSApiHost.m and -fsanitize=address,
// run with `simctl spawn` (no app, no window, no network). HeyIOSApi's
// perform:path:completion: is replaced so every request answers 200 on the next
// turn of the main queue, the way a real answer arrives: after the method that
// started the chain has returned. The list's load is replaced with a counter.
//
// A chain keeps its running block alive only through a __block variable (`hold`).
// A block that clears it and then reads one of its own captures reads freed
// memory: sign-in crashed on a phone that way (EXC_BAD_ACCESS at 0x10) while the
// simulator, which had not reused the memory, drew the next screen. ASan reports
// the read as heap-use-after-free on every run.
//
//   chains [form|reorder]   (no argument: both)
#import <UIKit/UIKit.h>
#import <objc/runtime.h>

const char *HeyIOSBakedOrigin(void) { return 0; }

@interface HeyIOSApi : NSObject
+ (instancetype)shared;
@property(nonatomic, copy) NSString *origin;
@end

@interface HeyIOSFormController : UITableViewController
- (instancetype)initWithScreen:(NSDictionary *)screen vars:(NSDictionary *)vars;
- (void)submit;
@property(nonatomic, assign) BOOL busy;
@end

@interface HeyIOSListController : UITableViewController
- (instancetype)initWithScreen:(NSDictionary *)screen vars:(NSDictionary *)vars;
@property(nonatomic, strong) NSMutableArray<NSMutableDictionary *> *sections;
@end

static NSInteger requests = 0;
static NSInteger loads = 0;

static void replace(Class cls, SEL sel, id block) {
  Method m = class_getInstanceMethod(cls, sel);
  if (m == NULL) { fprintf(stderr, "chains: %s has no %s\n", class_getName(cls), sel_getName(sel)); exit(2); }
  method_setImplementation(m, imp_implementationWithBlock(block));
}

static BOOL spin(BOOL (^done)(void)) {
  NSDate *limit = [NSDate dateWithTimeIntervalSinceNow:10];
  while (!done() && [limit timeIntervalSinceNow] > 0) {
    [[NSRunLoop mainRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
  }
  return done();
}

// Sign-in's shape: one request, then finish on the answer.
static BOOL runForm(void) {
  NSDictionary *screen = @{
    @"id": @"sign_in", @"type": @"form", @"fields": @[],
    @"primary": @{@"title": @"Sign in", @"busy_title": @"Signing in", @"request": @{@"path": @"/session", @"method": @"POST"}, @"on_success": @{}}
  };
  NSInteger before = requests;
  HeyIOSFormController *form = [[HeyIOSFormController alloc] initWithScreen:screen vars:@{}];
  [form submit];
  BOOL finished = spin(^BOOL { return !form.busy; });
  BOOL ok = finished && requests - before == 1;
  printf("hey_ios_chain_form_submit=%s requests=%ld finished=%s\n", ok ? "true" : "false", (long)(requests - before), finished ? "true" : "false");
  return ok;
}

// A row dragged two places: two one-step requests, then one load.
static BOOL runReorder(void) {
  NSDictionary *reorder = @{@"request": @{@"path": @"/move", @"method": @"POST"}, @"up": @"up", @"down": @"down"};
  HeyIOSListController *list = [[HeyIOSListController alloc] initWithScreen:@{@"id": @"library", @"type": @"list", @"sections": @[]} vars:@{}];
  list.sections = [@[[@{@"spec": @{@"reorder": reorder}, @"rows": @[@{@"id": @"a"}, @{@"id": @"b"}, @{@"id": @"c"}], @"footer": @""} mutableCopy]] mutableCopy];
  NSInteger before = requests;
  [list tableView:[[UITableView alloc] init] moveRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] toIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
  BOOL finished = spin(^BOOL { return loads > 0; });
  BOOL ok = finished && requests - before == 2 && loads == 1;
  printf("hey_ios_chain_reorder=%s requests=%ld loads=%ld\n", ok ? "true" : "false", (long)(requests - before), (long)loads);
  return ok;
}

int main(int argc, char **argv) {
  @autoreleasepool {
    setvbuf(stdout, NULL, _IONBF, 0);
    Class api = NSClassFromString(@"HeyIOSApi");
    Class listClass = NSClassFromString(@"HeyIOSListController");
    if (api == Nil || listClass == Nil || NSClassFromString(@"HeyIOSFormController") == Nil) { fprintf(stderr, "chains: the host's classes are not linked\n"); return 2; }
    replace(api, @selector(perform:path:completion:), ^(id me, NSURLRequest *request, NSString *path, void (^completion)(NSInteger, id, NSString *)) {
      requests += 1;
      dispatch_async(dispatch_get_main_queue(), ^{ completion(200, @{@"ok": @YES}, nil); });
    });
    replace(api, @selector(token), ^NSString *(id me) { return nil; });
    replace(listClass, NSSelectorFromString(@"load"), ^(id me) { loads += 1; });
    [HeyIOSApi shared].origin = @"http://127.0.0.1:9";

    NSString *which = argc > 1 ? [NSString stringWithUTF8String:argv[1]] : @"all";
    BOOL ok = YES;
    if ([which isEqualToString:@"all"] || [which isEqualToString:@"form"]) ok = runForm() && ok;
    if ([which isEqualToString:@"all"] || [which isEqualToString:@"reorder"]) ok = runReorder() && ok;
    if (ok) printf("hey_ios_block_chains=true\n");
    return ok ? 0 : 1;
  }
}
