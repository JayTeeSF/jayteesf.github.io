# Continuation prompt

Maintain `hey_party` as an independently versioned third-party Hey package.
Preserve the plumbing/porcelain boundary in `docs/DESIGN.md`. Prefer current
published package APIs over Hey core or stdlib changes. Every source change
must bump VERSION, update manifest/docs/specs/status, run `bin/check`, and
generate immutable release and source archives through `hey_packager`.
