#ifndef HEY_NATIVE_ABI_H
#define HEY_NATIVE_ABI_H

#include <stddef.h>
#include <stdint.h>

typedef uintptr_t HeyNativeHandle;
typedef struct HeyNativeUtf8View { const char *data; size_t length; } HeyNativeUtf8View;
typedef struct HeyNativeBytesView { const uint8_t *data; size_t length; } HeyNativeBytesView;

#endif

