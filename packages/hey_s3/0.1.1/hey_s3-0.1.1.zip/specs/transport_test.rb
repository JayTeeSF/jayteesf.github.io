require 'socket';require 'digest';require 'base64';require 'tmpdir';require 'open3';require 'fileutils'
root=File.expand_path('..',__dir__)
server=TCPServer.new('127.0.0.1',0);port=server.addr[1];objects={};requests=[]
thread=Thread.new do
 loop do
  socket=server.accept
  begin
   loop do
    first=socket.gets;break unless first
    method,target,_=first.split(' ');headers={}
    while (line=socket.gets)&&line!="\r\n"
     k,value=line.split(':',2);headers[k.downcase]=value.to_s.strip
    end
    raise 'Unsigned request' unless headers['authorization'].to_s.start_with?('AWS4-HMAC-SHA256 ')&&headers['x-amz-security-token']=='fixture-token'
    body=headers['content-length'].to_i.positive? ? socket.read(headers['content-length'].to_i) : ''
    requests<<[method,target];status=200;response='';extra={};object=objects[target]
    if method=='PUT'
     if (headers['if-none-match']=='*'&&object)||(headers['if-match']&&(!object||headers['if-match']!=object[:etag]))
      status=412
     else
      sha=Digest::SHA256.digest(body);raise 'Payload hash differs' unless Digest::SHA256.hexdigest(body)==headers['x-amz-content-sha256']&&Base64.strict_encode64(sha)==headers['x-amz-checksum-sha256']
      objects[target]={body:body,etag:'"'+Digest::SHA256.hexdigest(body)+'"',checksum:Base64.strict_encode64(sha)};object=objects[target]
     end
    elsif target.end_with?('/truncated')
     socket.write("HTTP/1.1 200 OK\r\nContent-Length: 999\r\nConnection: close\r\n\r\nshort");break
    elsif target.end_with?('/redirect')
     status=301;extra['Location']="http://127.0.0.1:#{port}/should-not-follow"
    elsif !object
     status=404
    elsif method=='GET'
     response=object[:body]
    end
    extra.merge!('ETag'=>object[:etag],'x-amz-checksum-sha256'=>object[:checksum]) if object
    extra['Content-Length']=method=='HEAD'&&object ? object[:body].bytesize.to_s : response.bytesize.to_s
    socket.write("HTTP/1.1 #{status} Fixture\r\n"+extra.map{|k,v|"#{k}: #{v}\r\n"}.join+"\r\n")
    socket.write(response) unless method=='HEAD'
   end
  rescue Errno::ECONNRESET, Errno::EPIPE
   # A rejected oversized download deliberately closes its keepalive connection.
  ensure
   socket.close
  end
 end
end
begin
 FileUtils.mkdir_p(File.join(root,'build'))
 Dir.mktmpdir('transport-',File.join(root,'build')) do |dir|
  input=File.join(dir,'input');File.binwrite(input,"cards\t日本語\\N\n"*10000)
  system(File.join(root,'build/native-test'),"http://127.0.0.1:#{port}",input,File.join(dir,'output'),Digest::SHA256.file(input).hexdigest,exception:true)
 end
 raise 'Dot path normalized' unless requests.any?{|_,path|path=='/fixture-bucket/a/./b'}
 raise 'Redirect followed' if requests.any?{|_,path|path.include?('should-not-follow')}
 puts "PASS: #{requests.size} real loopback HTTP requests"
ensure
 thread.kill;thread.join;server.close
end
