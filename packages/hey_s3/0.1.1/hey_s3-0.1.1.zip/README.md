# hey_s3

Bounded file-backed S3 GET/HEAD/conditional PUT with libcurl SigV4, connection reuse, verified TLS and SHA-256. Keys and credentials stay out of subprocess argv. No cloud-specific application policy. Native dependencies: libcurl >= 7.85 and OpenSSL. Single-owner handles. Credentials are supplied by the caller, which owns provider selection/refresh. HTTP is allowed only on explicitly enabled loopback test endpoints. No redirects, multipart uploads, object deletion or bucket management. Maximum object size: 5 GiB; callers should choose smaller restartable chunks.
