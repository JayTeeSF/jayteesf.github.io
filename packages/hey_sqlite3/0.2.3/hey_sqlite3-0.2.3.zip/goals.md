# Goals

- Keep SQLite outside the Hey language/runtime while using Hey's stable native ABI.
- Provide deterministic ownership, prepared statements, typed values, transactions, cancellation, and honest blocking metadata.
- Become the SQLite adapter consumed by `hey_record`, web applications, and other third-party packages.
