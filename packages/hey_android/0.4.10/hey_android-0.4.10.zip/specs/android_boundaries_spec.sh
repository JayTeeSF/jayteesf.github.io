#!/usr/bin/env bash
# Focused production renderer boundary tests; no heyc, emulator or network.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-boundaries.XXXXXX")
trap 'rm -rf "$work"' EXIT
java_home=$(hey_android_java_home)
mkdir -p "$work/classes" "$work/context/assets/hey-api"
cp "$ROOT/specs/support/api_fixture_description.json" "$work/context/assets/hey-api/description.json"
printf '%s' 'https://api.example.test' > "$work/context/assets/hey-api/origin.txt"
run() {
  local renderer=$1 out=$2 name
  mkdir -p "$out"
  find "$renderer/java" "$ROOT/renderer/instrumentation/boundaries/stubs" "$ROOT/renderer/instrumentation/boundaries/host" -name '*.java' > "$out/sources"
  for name in HeyAndroidMediaSource HeyAndroidPlayer HeyAndroidPlayback HeyAndroidDescription HeyAndroidHttp; do
    printf '%s\n' "$renderer/android/hey/android/api/$name.java" >> "$out/sources"
  done
  "$java_home/bin/javac" --release 17 -d "$out" @"$out/sources" || return 2
  "$java_home/bin/java" -cp "$out" hey.android.api.BoundaryMain "$work/context"
}
run "$ROOT/renderer" "$work/classes"
mutation() {
  local name=$1 file=$2 expression=$3 expected=$4
  local renderer=$work/$name
  mkdir -p "$renderer"
  cp -R "$ROOT/renderer/java" "$ROOT/renderer/android" "$renderer/"
  "$HEY_ANDROID_RUBY" -e 'p=ARGV[0]; s=File.read(p); old=s.dup; eval(ARGV[1]); abort("mutation did not match") if s==old; File.write(p,s)' "$renderer/$file" "$expression"
  if run "$renderer" "$work/$name-classes" > "$work/$name.log" 2>&1; then
    echo "FAIL: mutation $name passed"; exit 1
  elif ! grep -q "$expected" "$work/$name.log"; then
    cat "$work/$name.log"; echo "FAIL: mutation $name failed for an unexpected reason"; exit 1
  fi
  echo "PASS (control): $name is detected by the production boundary tests"
}
mutation prefix-host android/hey/android/api/HeyAndroidPlayer.java 's.sub!("Origins.same(origin, address)", "address.startsWith(origin)")' 'FAIL: no bearer for https://api.example.test.attacker.invalid'
mutation media-redirect android/hey/android/api/HeyAndroidMediaSource.java 's.sub!("setInstanceFollowRedirects(false)", "setInstanceFollowRedirects(true)")' 'automatic credential redirects enabled'
mutation retained-feed android/hey/android/api/HeyAndroidPlayback.java 's.sub!("    feed = null;", "    // feed retained");' 'FAIL: A to B clears car feed'
if rg -n 'fetchDescription|applyPending|storedFile|Descriptions\.(merged|pick)' "$ROOT/renderer/android"; then
  echo 'FAIL: production Android code contains a remote UI replacement path'; exit 1
fi
echo 'PASS: production Android code has no description fetch, cache selection or replacement path'
