package android.media;
import android.content.Context;
import android.net.Uri;
import java.util.Map;
public class MediaPlayer {
  public static MediaPlayer last;
  public Map<String, String> headers;
  public MediaDataSource source;
  public boolean released;
  public interface Ready { void ready(MediaPlayer p); }
  public interface Error { boolean error(MediaPlayer p, int what, int extra); }
  public Ready prepared, completed;
  public Error error;
  public MediaPlayer() { last = this; }
  public void setAudioAttributes(AudioAttributes a) {}
  public void setDataSource(Context c, Uri u, Map<String, String> h) { headers = h; }
  public void setDataSource(MediaDataSource source) { this.source = source; }
  public void setOnPreparedListener(Ready r) { prepared = r; }
  public void setOnCompletionListener(Ready r) { completed = r; }
  public void setOnErrorListener(Error r) { error = r; }
  public void prepareAsync() {}
  public void start() {}
  public void pause() {}
  public void seekTo(int ms) {}
  public int getCurrentPosition() { return 12000; }
  public int getDuration() { return 40000; }
  public void reset() {}
  public void release() { released = true; }
}
