# Done

- v0.1.0 lifecycle state/effects.
- Enrollment payload validation and development/release transport policy.
- Screen/action/accessibility descriptors and test doubles.
- Removed release tooling from runtime dependencies and adopted `hey_packager` 0.1.2 controls.
