#ifndef HEY_SCRYPT_H
#define HEY_SCRYPT_H
#include "hey_native_abi.h"
HeyNativeOwnedBytes scrypt_hash(HeyNativeBytesView secret,HeyNativeUtf8View salt_view,uint32_t key_len,uint64_t max_memory);
#endif
