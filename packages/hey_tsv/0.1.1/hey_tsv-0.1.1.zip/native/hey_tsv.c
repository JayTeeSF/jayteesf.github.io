#define _DARWIN_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "hey_native_abi.h"
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
static void release_bytes(void *ctx,uint8_t *p,size_t n){(void)ctx;(void)n;free(p);}
static uint32_t get32(const uint8_t *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static int utf8(const uint8_t *p,size_t n){
  for(size_t i=0;i<n;i++){
    uint8_t c=p[i];if(c<128)continue;unsigned k;uint8_t lo=128,hi=191;
    if(c>=194&&c<=223)k=1;else if(c>=224&&c<=239){k=2;if(c==224)lo=160;if(c==237)hi=159;}
    else if(c>=240&&c<=244){k=3;if(c==240)lo=144;if(c==244)hi=143;}else return 0;
    if(k>n-i-1 || p[i+1]<lo || p[i+1]>hi)return 0;
    for(unsigned j=2;j<=k;j++)if(p[i+j]<128||p[i+j]>191)return 0;i+=k;
  }return 1;
}
/* Validate the whole frame before exposing any output. All additions are bounded. */
static int frame(HeyNativeBytesView b,uint32_t *rows,uint32_t *cols,size_t *escaped){
  if(b.length<12||b.length>67108864||memcmp(b.data,"HYR1",4))return 0;
  *rows=get32(b.data+4);*cols=get32(b.data+8);
  if(*cols==0||*cols>4096||*rows>1000000)return 0;
  size_t p=12,n=0;
  for(uint32_t r=0;r<*rows;r++)for(uint32_t c=0;c<*cols;c++){
    if(b.length-p<4)return 0;uint32_t len=get32(b.data+p);p+=4;
    if(len==UINT32_MAX)n+=2;else{
      if(len>b.length-p||!utf8(b.data+p,len))return 0;
      for(uint32_t j=0;j<len;j++){uint8_t v=b.data[p+j];n+=(v==92||v==9||v==10||v==13||v==0||v==26)?2:1;}
      p+=len;
    }
    n++;if(n>134217728)return 0;
  }
  if(p!=b.length)return 0;*escaped=n;return 1;
}
HeyNativeOwnedBytes tsv_encode(HeyNativeBytesView b){
  HeyNativeOwnedBytes no={0};uint32_t rows,cols;size_t size;if(!frame(b,&rows,&cols,&size))return no;
  uint8_t *out=malloc(size?size:1);if(!out)return no;size_t p=12,o=0;
  for(uint32_t r=0;r<rows;r++)for(uint32_t c=0;c<cols;c++){
    uint32_t n=get32(b.data+p);p+=4;
    if(n==UINT32_MAX){out[o++]=92;out[o++]='N';}else{
      for(uint32_t j=0;j<n;j++){uint8_t v=b.data[p++];uint8_t e=0;
        switch(v){case 92:e=92;break;case 9:e='t';break;case 10:e='n';break;case 13:e='r';break;case 0:e='0';break;case 26:e='Z';break;}
        if(e){out[o++]=92;out[o++]=e;}else out[o++]=v;
      }
    }out[o++]=(c+1==cols)?10:9;
  }
  return (HeyNativeOwnedBytes){out,o,release_bytes,NULL};
}
uint32_t tsv_rows(HeyNativeBytesView b){uint32_t r,c;size_t n;return frame(b,&r,&c,&n)?r:UINT32_MAX;}
uint64_t tsv_last_u64(HeyNativeBytesView b,uint32_t col){
  uint32_t rows,cols;size_t z;if(!frame(b,&rows,&cols,&z)||!rows||col>=cols)return UINT64_MAX;
  size_t p=12;uint64_t out=UINT64_MAX;
  for(uint32_t r=0;r<rows;r++)for(uint32_t c=0;c<cols;c++){
    uint32_t n=get32(b.data+p);p+=4;
    if(r+1==rows&&c==col){
      if(n==UINT32_MAX||n==0||n>20)return UINT64_MAX;out=0;
      for(uint32_t j=0;j<n;j++){uint8_t v=b.data[p+j];if(v<'0'||v>'9'||out>(UINT64_MAX-(v-'0'))/10)return UINT64_MAX;out=out*10+v-'0';}
    }if(n!=UINT32_MAX)p+=n;
  }
  return out;
}
