# Continue hey_record

Continue `hey_record`, the database-independent Hey package inspired by Sequel datasets and Active Record conventions. Read `goals.md`, `in-progress.md`, `todos.md`, `done.md`, `README.md`, `docs/DESIGN.md`, source, and specs.

Preserve explicit callable adapters, ordinary object rows, guarded destructive writes, Result boundaries, and existing specs. Prioritize prepared statements and typed values before adding model magic. Update all tracking documents and this prompt with every version slice.

Keep exported modules at package-root paths while targeting Hey 0.99.259a because its current `pkg:` resolver does not follow non-root manifest module mappings.
