# hey_streamer

Driver-neutral bounded backup and restore orchestration over hey_record streams, hey_tsv and hey_zstd.

Implementation in progress. Reusable database streaming and file-transfer orchestration. Supported build targets are Linux x86-64 and Darwin arm64.

Versioned configuration owns connections, reviewed table/column selection, limits, paths and credentials by environment reference. Do not connect to or modify production/staging during development. Tests use explicitly configured disposable destinations. A transport benchmark is not proof of PII filtering or policy-aware merge behavior.

Commits use short subjects without coauthor trailers.
