# TODO — hey_reports

- Stacked and horizontal bar variants (no blockers).
- Fractional axis ticks via a scaled-integer domain.
- Time-series x axis on `stdlib:Time`.
- Revisit `ReportsGeometry`'s sine table if the compiled lane ever
  stops truncating float parameters. Low priority: the table is
  accurate to 0.008px at a 500px radius.
- Ask the hey_tv maintainer for a `path` widget kind. It is the single
  cheapest change that would give television line and pie charts.
- Report to the hey_tv maintainer: `SCENE_CONTRACT.md` promises data-URI
  and bundled-asset images; `hey_native_tv_runtime.m:826` implements SF
  symbols only. Also, the doc says unknown widget kinds render as a
  placeholder; `validate_scene` rejects them.

See `docs/ROADMAP.md` for what each item is blocked on.
