#ifndef HEY_POSTGRES_H
#define HEY_POSTGRES_H

#include "hey_native_abi.h"

/* Connection lifecycle */
HeyNativeHandle hey_postgres_connect(HeyNativeUtf8View conninfo);
int32_t hey_postgres_status(HeyNativeHandle connection);
HeyNativeUtf8View hey_postgres_error_message(HeyNativeHandle connection);
int32_t hey_postgres_server_version(HeyNativeHandle connection);
int32_t hey_postgres_set_nonblocking_off(HeyNativeHandle connection);
void hey_postgres_finish(HeyNativeHandle connection);
int32_t hey_postgres_ping(HeyNativeUtf8View conninfo);

/* Parameter accumulator (built value-by-value, then executed) */
HeyNativeHandle hey_postgres_params_new(void);
int32_t hey_postgres_params_add_text(HeyNativeHandle params, HeyNativeUtf8View value);
int32_t hey_postgres_params_add_null(HeyNativeHandle params);
int32_t hey_postgres_params_count(HeyNativeHandle params);
void hey_postgres_params_free(HeyNativeHandle params);

/* Execution (text-format parameters and results) */
HeyNativeHandle hey_postgres_exec_params(HeyNativeHandle connection, HeyNativeUtf8View sql, HeyNativeHandle params);
HeyNativeHandle hey_postgres_prepare(HeyNativeHandle connection, HeyNativeUtf8View name, HeyNativeUtf8View sql);
HeyNativeHandle hey_postgres_exec_prepared(HeyNativeHandle connection, HeyNativeUtf8View name, HeyNativeHandle params);

/* Result inspection */
int32_t hey_postgres_result_status(HeyNativeHandle result);
HeyNativeUtf8View hey_postgres_result_error(HeyNativeHandle result);
HeyNativeUtf8View hey_postgres_result_error_field(HeyNativeHandle result, int32_t code);
int32_t hey_postgres_result_ntuples(HeyNativeHandle result);
int32_t hey_postgres_result_nfields(HeyNativeHandle result);
HeyNativeUtf8View hey_postgres_result_fname(HeyNativeHandle result, int32_t column);
int64_t hey_postgres_result_ftype(HeyNativeHandle result, int32_t column);
HeyNativeBool hey_postgres_result_getisnull(HeyNativeHandle result, int32_t row, int32_t column);
HeyNativeUtf8View hey_postgres_result_getvalue(HeyNativeHandle result, int32_t row, int32_t column);
HeyNativeBytesView hey_postgres_result_getbytes(HeyNativeHandle result, int32_t row, int32_t column);
HeyNativeUtf8View hey_postgres_result_cmdtuples(HeyNativeHandle result);
void hey_postgres_clear(HeyNativeHandle result);

#endif
