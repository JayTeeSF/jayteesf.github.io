# Design

Active Record demonstrates convention-driven table/model mapping, associations, validations, callbacks, transactions, adapter abstraction, and migrations. Sequel demonstrates an explicit Database object and composable Dataset query interface. `hey_record` starts with the smaller composable core: connection descriptors, datasets, rows, SQL, transactions, models, and migrations.

An adapter connection contains callable `query` and `execute` fields. This keeps the ORM independent of SQLite/MySQL packages and lets applications choose adapters explicitly without dynamic package loading.

Destructive update/delete calls require criteria. Identifier syntax is restricted and string literals are escaped. Prepared statements remain required before this package should be treated as a complete untrusted-query boundary.
