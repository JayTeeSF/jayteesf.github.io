package hey.android.api;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * JSON for the renderer, with no Android class in it, so the same code runs in
 * the app and in the host tests. A JSON object is a LinkedHashMap (keys keep
 * their order), an array an ArrayList, a string a String, a number a Long when
 * it is written without a fraction or exponent and fits, else a Double, true
 * and false a Boolean, and null the NULL marker (so null and missing differ).
 *
 * parse refuses anything that is not exactly one JSON value, surrounded by
 * whitespace at most: a cut-off body, trailing text, a lone surrogate escape.
 */
public final class Json {
  private Json() {}

  /** JSON null. Never Java null, which means "not there". */
  public static final Object NULL = new Object() {
    @Override public String toString() { return "null"; }
  };

  public static final class ParseError extends Exception {
    private static final long serialVersionUID = 1L;

    ParseError(String message, int at) { super(message + " at " + at); }
  }

  public static Object parse(byte[] bytes) throws ParseError {
    return parse(new String(bytes, StandardCharsets.UTF_8));
  }

  public static Object parse(String text) throws ParseError {
    Parser p = new Parser(text);
    p.space();
    Object value = p.value(0);
    p.space();
    if (p.at != text.length()) throw new ParseError("text after the value", p.at);
    return value;
  }

  /** parse, or Java null when the text is not JSON. */
  public static Object parseOrNull(byte[] bytes) {
    try {
      return parse(bytes);
    } catch (ParseError e) {
      return null;
    }
  }

  private static final class Parser {
    final String s;
    int at;

    Parser(String s) { this.s = s; }

    void space() {
      while (at < s.length()) {
        char c = s.charAt(at);
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') at++;
        else break;
      }
    }

    Object value(int depth) throws ParseError {
      if (depth > 512) throw new ParseError("nested too deeply", at);
      if (at >= s.length()) throw new ParseError("the text ends", at);
      char c = s.charAt(at);
      switch (c) {
        case '{': return object(depth);
        case '[': return array(depth);
        case '"': return string();
        case 't': word("true"); return Boolean.TRUE;
        case 'f': word("false"); return Boolean.FALSE;
        case 'n': word("null"); return NULL;
        default:
          if (c == '-' || (c >= '0' && c <= '9')) return number();
          throw new ParseError("unexpected '" + c + "'", at);
      }
    }

    void word(String w) throws ParseError {
      if (!s.startsWith(w, at)) throw new ParseError("expected " + w, at);
      at += w.length();
    }

    Map<String, Object> object(int depth) throws ParseError {
      Map<String, Object> out = new LinkedHashMap<>();
      at++;
      space();
      if (at < s.length() && s.charAt(at) == '}') { at++; return out; }
      while (true) {
        space();
        if (at >= s.length() || s.charAt(at) != '"') throw new ParseError("expected a key", at);
        String key = string();
        space();
        if (at >= s.length() || s.charAt(at) != ':') throw new ParseError("expected ':'", at);
        at++;
        space();
        out.put(key, value(depth + 1));
        space();
        if (at >= s.length()) throw new ParseError("the object is not closed", at);
        char c = s.charAt(at++);
        if (c == '}') return out;
        if (c != ',') throw new ParseError("expected ',' or '}'", at - 1);
      }
    }

    List<Object> array(int depth) throws ParseError {
      List<Object> out = new ArrayList<>();
      at++;
      space();
      if (at < s.length() && s.charAt(at) == ']') { at++; return out; }
      while (true) {
        space();
        out.add(value(depth + 1));
        space();
        if (at >= s.length()) throw new ParseError("the array is not closed", at);
        char c = s.charAt(at++);
        if (c == ']') return out;
        if (c != ',') throw new ParseError("expected ',' or ']'", at - 1);
      }
    }

    String string() throws ParseError {
      at++;
      StringBuilder b = new StringBuilder();
      while (true) {
        if (at >= s.length()) throw new ParseError("the string is not closed", at);
        char c = s.charAt(at++);
        if (c == '"') return b.toString();
        if (c < 0x20) throw new ParseError("a control character in a string", at - 1);
        if (c != '\\') { b.append(c); continue; }
        if (at >= s.length()) throw new ParseError("the escape is cut off", at);
        char e = s.charAt(at++);
        switch (e) {
          case '"': b.append('"'); break;
          case '\\': b.append('\\'); break;
          case '/': b.append('/'); break;
          case 'b': b.append('\b'); break;
          case 'f': b.append('\f'); break;
          case 'n': b.append('\n'); break;
          case 'r': b.append('\r'); break;
          case 't': b.append('\t'); break;
          case 'u': {
            char unit = hex4();
            if (Character.isHighSurrogate(unit)) {
              if (!s.startsWith("\\u", at)) throw new ParseError("a lone surrogate", at);
              at += 2;
              char low = hex4();
              if (!Character.isLowSurrogate(low)) throw new ParseError("a lone surrogate", at);
              b.append(unit).append(low);
            } else if (Character.isLowSurrogate(unit)) {
              throw new ParseError("a lone surrogate", at);
            } else {
              b.append(unit);
            }
            break;
          }
          default: throw new ParseError("an unknown escape", at - 1);
        }
      }
    }

    char hex4() throws ParseError {
      if (at + 4 > s.length()) throw new ParseError("the escape is cut off", at);
      int v = 0;
      for (int i = 0; i < 4; i++) {
        int d = Character.digit(s.charAt(at + i), 16);
        if (d < 0) throw new ParseError("not a hex digit", at + i);
        v = v * 16 + d;
      }
      at += 4;
      return (char) v;
    }

    Object number() throws ParseError {
      int start = at;
      boolean fraction = false;
      if (s.charAt(at) == '-') at++;
      if (at >= s.length()) throw new ParseError("the number is cut off", at);
      if (s.charAt(at) == '0') {
        at++;
      } else if (s.charAt(at) >= '1' && s.charAt(at) <= '9') {
        while (at < s.length() && Character.isDigit(s.charAt(at))) at++;
      } else {
        throw new ParseError("not a number", at);
      }
      if (at < s.length() && s.charAt(at) == '.') {
        fraction = true;
        at++;
        int digits = at;
        while (at < s.length() && Character.isDigit(s.charAt(at))) at++;
        if (at == digits) throw new ParseError("no digits after '.'", at);
      }
      if (at < s.length() && (s.charAt(at) == 'e' || s.charAt(at) == 'E')) {
        fraction = true;
        at++;
        if (at < s.length() && (s.charAt(at) == '+' || s.charAt(at) == '-')) at++;
        int digits = at;
        while (at < s.length() && Character.isDigit(s.charAt(at))) at++;
        if (at == digits) throw new ParseError("no digits in the exponent", at);
      }
      String text = s.substring(start, at);
      if (!fraction) {
        try {
          return Long.parseLong(text);
        } catch (NumberFormatException tooBig) {
          // falls through to a double
        }
      }
      return Double.parseDouble(text);
    }
  }

  // ---- writing -----------------------------------------------------------------------------

  public static String encode(Object value) {
    StringBuilder b = new StringBuilder();
    write(b, value);
    return b.toString();
  }

  public static byte[] encodeBytes(Object value) {
    return encode(value).getBytes(StandardCharsets.UTF_8);
  }

  private static void write(StringBuilder b, Object v) {
    if (v == null || v == NULL) {
      b.append("null");
    } else if (v instanceof String) {
      quote(b, (String) v);
    } else if (v instanceof Boolean) {
      b.append(((Boolean) v) ? "true" : "false");
    } else if (v instanceof Number) {
      b.append(numberText((Number) v));
    } else if (v instanceof Map) {
      b.append('{');
      boolean first = true;
      for (Map.Entry<?, ?> e : ((Map<?, ?>) v).entrySet()) {
        if (!first) b.append(',');
        first = false;
        quote(b, String.valueOf(e.getKey()));
        b.append(':');
        write(b, e.getValue());
      }
      b.append('}');
    } else if (v instanceof List) {
      b.append('[');
      boolean first = true;
      for (Object item : (List<?>) v) {
        if (!first) b.append(',');
        first = false;
        write(b, item);
      }
      b.append(']');
    } else {
      quote(b, v.toString());
    }
  }

  /** A number in its shortest form: 3, 1.5, never 3.0. */
  public static String numberText(Number n) {
    if (n instanceof Long || n instanceof Integer || n instanceof Short || n instanceof Byte) return Long.toString(n.longValue());
    double d = n.doubleValue();
    if (Double.isNaN(d) || Double.isInfinite(d)) return "null";
    if (d == Math.rint(d) && Math.abs(d) < 1e15) return Long.toString((long) d);
    String t = Double.toString(d);
    return t;
  }

  private static void quote(StringBuilder b, String s) {
    b.append('"');
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      switch (c) {
        case '"': b.append("\\\""); break;
        case '\\': b.append("\\\\"); break;
        case '\n': b.append("\\n"); break;
        case '\r': b.append("\\r"); break;
        case '\t': b.append("\\t"); break;
        default:
          if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
          else b.append(c);
      }
    }
    b.append('"');
  }

  // ---- reading helpers ----------------------------------------------------------------------

  @SuppressWarnings("unchecked")
  public static Map<String, Object> dict(Object v) {
    return v instanceof Map ? (Map<String, Object>) v : new LinkedHashMap<>();
  }

  @SuppressWarnings("unchecked")
  public static List<Object> list(Object v) {
    return v instanceof List ? (List<Object>) v : new ArrayList<>();
  }

  /** Structural equality as JSON: numbers compare by value, whatever their Java type. */
  public static boolean same(Object a, Object b) {
    if (a == null) a = NULL;
    if (b == null) b = NULL;
    if (a instanceof Number && b instanceof Number) {
      return ((Number) a).doubleValue() == ((Number) b).doubleValue();
    }
    if (a instanceof Map && b instanceof Map) {
      Map<?, ?> ma = (Map<?, ?>) a;
      Map<?, ?> mb = (Map<?, ?>) b;
      if (ma.size() != mb.size()) return false;
      for (Map.Entry<?, ?> e : ma.entrySet()) {
        if (!mb.containsKey(e.getKey())) return false;
        if (!same(e.getValue(), mb.get(e.getKey()))) return false;
      }
      return true;
    }
    if (a instanceof List && b instanceof List) {
      List<?> la = (List<?>) a;
      List<?> lb = (List<?>) b;
      if (la.size() != lb.size()) return false;
      for (int i = 0; i < la.size(); i++) if (!same(la.get(i), lb.get(i))) return false;
      return true;
    }
    return a.equals(b);
  }
}
