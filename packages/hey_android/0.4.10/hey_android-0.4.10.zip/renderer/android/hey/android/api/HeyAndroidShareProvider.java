package hey.android.api;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

/** Private, read-only artwork cache. Receivers get access to one granted URI. */
public final class HeyAndroidShareProvider extends ContentProvider {
  static Uri keep(Context context, Bitmap picture) throws IOException {
    File directory = new File(context.getCacheDir(), "hey-share");
    if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("share cache unavailable");
    File[] old = directory.listFiles();
    if (old != null) for (File file : old) {
      if (file.getName().endsWith(".png") && file.lastModified() < System.currentTimeMillis() - 172800000L) file.delete();
    }
    File file = new File(directory, UUID.randomUUID().toString() + ".png");
    try (FileOutputStream output = new FileOutputStream(file)) {
      if (!picture.compress(Bitmap.CompressFormat.PNG, 100, output)) throw new IOException("artwork encoding failed");
    } catch (IOException failure) {
      file.delete();
      throw failure;
    }
    return new Uri.Builder().scheme("content").authority(context.getPackageName() + ".hey.share")
        .appendPath(file.getName()).build();
  }

  private File file(Uri uri) {
    Context context = getContext();
    if (context == null || !"content".equals(uri.getScheme())
        || !(context.getPackageName() + ".hey.share").equals(uri.getAuthority())
        || uri.getPathSegments().size() != 1 || uri.getQuery() != null
        || !uri.getLastPathSegment().matches("[a-f0-9-]{36}\\.png")) {
      throw new SecurityException("unknown share artwork");
    }
    return new File(new File(context.getCacheDir(), "hey-share"), uri.getLastPathSegment());
  }

  @Override public boolean onCreate() { return true; }
  @Override public String getType(Uri uri) { file(uri); return "image/png"; }
  @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
    if (!"r".equals(mode)) throw new FileNotFoundException("share artwork is read-only");
    return ParcelFileDescriptor.open(file(uri), ParcelFileDescriptor.MODE_READ_ONLY);
  }
  @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
    File file = file(uri);
    String[] columns = projection == null ? new String[] {OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
    MatrixCursor cursor = new MatrixCursor(columns, 1);
    Object[] values = new Object[columns.length];
    for (int i = 0; i < columns.length; i++) {
      if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) values[i] = "shared-artwork.png";
      if (OpenableColumns.SIZE.equals(columns[i])) values[i] = file.length();
    }
    cursor.addRow(values);
    return cursor;
  }
  @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException("read-only"); }
  @Override public int update(Uri uri, ContentValues values, String selection, String[] args) { throw new UnsupportedOperationException("read-only"); }
  @Override public int delete(Uri uri, String selection, String[] args) { throw new UnsupportedOperationException("read-only"); }
}
