# In progress

0.2.0 ships the native host for `api_screens` apps; `hey_carplay` 0.1.0 is its first extension.

- Extract VSS UIKit host adapters into reusable opaque capability entry points.
