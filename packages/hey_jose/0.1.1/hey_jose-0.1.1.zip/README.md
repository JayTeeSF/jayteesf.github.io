# hey_jose

Reusable Hey JOSE package for JWT/JWS/JWKS/OIDC verification using mature native cryptography.

## Status

**Repository created; implementation/release gate pending.** This repository is the permanent package home. `PACKAGE_SPEC.md` is the authoritative API/security/native-boundary contract. Do not implement this integration inside MMeoww or Hey core.

The native manifest, generated wrapper/build files, lock data, and immutable release must be produced by the current Hey toolchain. Do not hand-invent `hey.native.json` or release hashes.

## Packaging rule

All package scaffolding/check/release/publish/source-handoff behavior must use the canonical Hey package tooling plus `hey_packager`. The generated package manifest must declare an exact `hey_packager` dependency (currently `0.1.6`) so this package follows the same release structure and verification workflow as the rest of the Hey ecosystem.

Read `BUILDER_START_HERE.md` before implementation.
