package hey.android.api;

import android.media.MediaDataSource;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Authenticated media stays out of MediaPlayer's automatic HTTP redirect handling.
 * Each bounded range read goes to the original origin, with redirects refused.
 * The source holds no downloaded file or growing in-memory copy.
 */
final class HeyAndroidMediaSource extends MediaDataSource {
  interface Opener { HttpURLConnection open(URL url) throws IOException; }
  private static final Pattern RANGE = Pattern.compile("bytes ([0-9]+)-([0-9]+)/([0-9]+)");
  private final URL url;
  private final Map<String, String> headers;
  private final Opener opener;
  private volatile boolean closed;
  private volatile HttpURLConnection active;
  private long length = -1;

  HeyAndroidMediaSource(String address, Map<String, String> headers) throws IOException {
    this(address, headers, url -> (HttpURLConnection) url.openConnection());
  }

  HeyAndroidMediaSource(String address, Map<String, String> headers, Opener opener) throws IOException {
    this.url = new URL(address);
    this.headers = new LinkedHashMap<>(headers);
    this.opener = opener;
  }

  @Override public synchronized int readAt(long position, byte[] buffer, int offset, int size) throws IOException {
    if (closed) throw new IOException("Media session ended.");
    if (position < 0 || offset < 0 || size < 0 || offset > buffer.length - size) throw new IOException("Invalid media range.");
    if (size == 0) return 0;
    if (length >= 0 && position >= length) return -1;
    int wanted = (int) Math.min(Math.min(size, 65536), Long.MAX_VALUE - position);
    if (wanted == 0) return -1;
    HttpURLConnection conn = opener.open(url);
    active = conn;
    try {
      if (closed) throw new IOException("Media session ended.");
      conn.setInstanceFollowRedirects(false);
      conn.setConnectTimeout(20_000);
      conn.setReadTimeout(20_000);
      conn.setUseCaches(false);
      conn.setRequestProperty("accept-encoding", "identity");
      conn.setRequestProperty("range", "bytes=" + position + "-" + (position + wanted - 1));
      for (Map.Entry<String, String> header : headers.entrySet()) conn.setRequestProperty(header.getKey(), header.getValue());
      int status = conn.getResponseCode();
      if (status == 206) {
        Matcher range = RANGE.matcher(String.valueOf(conn.getHeaderField("content-range")));
        if (!range.matches()) throw new IOException("Invalid media Content-Range.");
        long start = Long.parseLong(range.group(1)), end = Long.parseLong(range.group(2)), total = Long.parseLong(range.group(3));
        if (start != position || end < start || end >= total || end - start >= wanted) throw new IOException("Unexpected media range.");
        length = total;
        wanted = (int) (end - start + 1);
      } else if (status == 200 && position == 0) {
        length = conn.getContentLengthLong();
        if (length < 0) throw new IOException("Authenticated media needs a known length.");
        wanted = (int) Math.min(wanted, length);
      } else {
        // Including every redirect, even one on this origin. No credential may
        // enter an HTTP stack that can silently follow it to a different port.
        throw new IOException("Media request refused (" + status + ").");
      }
      try (InputStream in = conn.getInputStream()) {
        int read = 0;
        while (read < wanted) {
          if (closed) throw new IOException("Media session ended.");
          int n = in.read(buffer, offset + read, wanted - read);
          if (n < 0) break;
          read += n;
        }
        if (closed) throw new IOException("Media session ended.");
        return read == 0 ? -1 : read;
      }
    } finally {
      active = null;
      conn.disconnect();
    }
  }

  @Override public synchronized long getSize() throws IOException {
    if (closed) throw new IOException("Media session ended.");
    if (length < 0) readAt(0, new byte[1], 0, 1);
    return length;
  }

  @Override public void close() {
    closed = true;
    HttpURLConnection conn = active;
    if (conn != null) conn.disconnect();
  }
}
