# Continue hey_sqlite3

Continue the SQLite adapter for Hey. Preserve the callable `hey_record` connection contract, direct argv safety, Result errors, and explicit capability reporting. Prioritize prepared statements and persistent native connections when the Hey extension boundary permits them. Update all tracking documents with every slice.

Keep exported modules at package-root paths while targeting Hey 0.99.259a because its current `pkg:` resolver does not follow non-root manifest module mappings.
