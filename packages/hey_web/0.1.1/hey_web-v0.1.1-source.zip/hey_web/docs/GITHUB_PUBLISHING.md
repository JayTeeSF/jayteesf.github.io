# Publishing through jayteesf.github.io

Copy the immutable release assets into the GitHub Pages repository:

```sh
cd "$HOME/dev/jayteesf.github.io"
mkdir -p packages/hey_web/0.1.1
cp "$HOME/Downloads/hey_web-0.1.1.zip" packages/hey_web/0.1.1/
cp "$HOME/Downloads/hey_web-0.1.1.release.json" packages/hey_web/0.1.1/
cp "$HOME/Downloads/hey_web-v0.1.1-source.zip" packages/hey_web/0.1.1/
git status --short
git add packages/hey_web/0.1.1
git commit -m "Publish hey_web 0.1.1"
git push origin master
```

The release files will be available from:

```text
https://jayteesf.github.io/packages/hey_web/0.1.1/hey_web-0.1.1.zip
https://jayteesf.github.io/packages/hey_web/0.1.1/hey_web-0.1.1.release.json
```
