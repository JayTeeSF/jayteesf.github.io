# Done

- v0.1.0 package boundary, modules, tests, toolchain installer, emulator/device launcher, docs, packaging, and LLM handoff.
- Fixed the macOS installer so `sdkmanager` and `avdmanager` share the same exported Android SDK root before AVD creation.
- Fixed AVD creation by installing Android command-line tools inside the selected SDK and invoking those SDK-local binaries; Homebrew's avdmanager no longer resolves packages from its separate root.
