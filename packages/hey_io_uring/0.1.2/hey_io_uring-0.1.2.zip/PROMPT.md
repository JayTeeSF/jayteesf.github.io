# Continue hey_io_uring

Read README.md, docs/DESIGN.md, todos.md, done.md, hey.native.json, the
native source and the specs before editing.

hey_io_uring is an independent package: the io_uring backend (Linux only)
behind the same API as hey_epoll's Epoll, so hey_poller can select it by name
(it is not hey_poller's Linux default until real x86 numbers say so). Hey owns
the generic native ABI, loader and package plumbing; this package owns the
event loop. Keep handles opaque, blocking calls honest (`wait` is the only
blocking function), one loop per thread (the ring is single-issuer), the
serving calls' native signatures equal to hey_epoll's, and every refusal a
named error from open(), never a crash.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check     # porcelain only off Linux
bin/linux-check      # Linux container: full check (seccomp=unconfined) + the blocked refusal (default seccomp)
```

Published versions are immutable. Change the version whenever released bytes change.
