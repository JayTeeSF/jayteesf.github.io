# Done

## 0.1.1

- `specs/generic_cagents_spec.hey` no longer imports another repo by
  absolute path. generic_cagents retired its web app (archived in
  1132fd0, deleted in 5d1adcc), so the import of
  `/Users/jthomas/dev/generic_cagents/domain/project.hey` failed with
  `heyc: file not found` and `bin/check` was red. The app's
  `domain/project.hey` and record `p1.json` are now kept verbatim, read-only,
  under `specs/fixtures/generic_cagents/` (from generic_cagents cd715dd),
  and the spec runs its full CRUD proof against them again.

## 0.1.0 (unreleased)

- Declaration-first metadata with row-shape inference
  (`field.hey`, `reflect.hey`), chosen after measuring that
  `hey_record` 0.3.0 exposes no model schema. See `docs/DESIGN.md`.
- Escape-by-default rendering (`escape.hey`, `view.hey`), proved with a
  real `<script>` payload on every screen and against
  `generic_cagents`' own `seat/<name>/<slice>` data.
- A mount guard that REFUSES without an `authorize` callback
  (`guard.hey`), with `HEY_ADMIN_INSECURE=1` as the loud opt-in. Proved
  in both lanes and both environments.
- List / show / new / edit / delete screens over a `HeyRecordStore`
  source, with pagination, a write allow-list, merge-not-replace
  updates, and POST-only deletion behind a confirmation screen.
- Seven spec files; six run byte-identically in both lanes.
- `tools/red-check`: 25 mutations, every gate seen RED, zero holes.
  It found two real gate holes during development, both closed.
