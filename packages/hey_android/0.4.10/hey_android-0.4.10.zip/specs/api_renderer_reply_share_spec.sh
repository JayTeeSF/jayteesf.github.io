#!/usr/bin/env bash
# Synthetic real form save -> share chooser, not a direct presenter-only test.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-android-reply.XXXXXX")
evidence=${HEY_ANDROID_REPLY_EVIDENCE:-}
java_home=$(hey_android_java_home)
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
adb=$HEY_ANDROID_ADB
serial=''
server_pid=''
cleanup() {
  local status=$?
  if [ -n "$serial" ]; then "$ROOT/tools/hey-android-emulator.sh" shutdown "$serial" >/dev/null 2>&1 || status=1; fi
  if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi
  if [ -n "$evidence" ]; then mkdir -p "$evidence"; cp "$work"/*.log "$evidence/" 2>/dev/null || true; fi
  rm -rf "$work"
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
port=3586
mkdir -p "$work/test/classes" "$work/test/dex"
"$HEY_ANDROID_RUBY" -rjson -e 'd={schema:"hey-mobile-api-app-v1",level:1,platform:"android",title:"Reply fixture",session:{sign_in_screen:"reply"},tabs:["saved"],screens:[{id:"reply",type:"form",title:"Reply",fields:[{id:"body",label:"Message",kind:"multiline",required:true}],primary:{title:"Save reply",request:{method:"POST",path:"/messages",body:{body:"$body"}},on_success:{share:"url",message:"Saved",then:"stay",share_retry_title:"Share saved reply"}}},{id:"saved",type:"list",title:"Saved replies",sections:[]}]}; File.write(ARGV[0],JSON.generate(d))' "$work/description.json"
sdk=${HEY_ANDROID_REPLY_SDK_ROOT:-$ROOT}
"$sdk/tools/hey-android-api-app.sh" --description "$work/description.json" --origin "http://10.0.2.2:$port" --package-id hey.android.sharefixture --label 'Reply fixture' --out "$work/app" > "$work/build.log" 2>&1
"$java_home/bin/javac" --release 17 -classpath "$HEY_ANDROID_PLATFORM_JAR:$work/app/classes" -d "$work/test/classes" "$ROOT/renderer/instrumentation/reply-share/hey/android/api/ReplyShareInstrumentation.java"
find "$work/test/classes" -name '*.class' > "$work/test/classes.txt"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/d8" --min-api 35 --lib "$HEY_ANDROID_PLATFORM_JAR" --classpath "$work/app/classes" --output "$work/test/dex" @"$work/test/classes.txt"
sed 's/hey.android.api.ShareInstrumentation/hey.android.api.ReplyShareInstrumentation/' "$ROOT/specs/support/share_instrumentation/AndroidManifest.xml" > "$work/test/AndroidManifest.xml"
"$bt/aapt2" link --manifest "$work/test/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -o "$work/test/base.apk"
(cd "$work/test/dex" && zip -q "$work/test/base.apk" classes.dex)
"$bt/zipalign" -P 16 -f 4 "$work/test/base.apk" "$work/test/aligned.apk"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" sign --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$work/test/app.apk" "$work/test/aligned.apk"
"$HEY_ANDROID_RUBY" "$ROOT/specs/support/reply_share_server.rb" "$port" "$work/requests.log" > "$work/server.log" 2>&1 &
server_pid=$!
"$ROOT/tools/hey-android-emulator.sh" create-avd > "$work/avd.log"
boot=$("$ROOT/tools/hey-android-emulator.sh" boot)
serial=$(printf '%s\n' "$boot" | tr ' ' '\n' | sed -n 's/^serial=//p')
"$adb" -s "$serial" uninstall hey.android.sharefixture >/dev/null 2>&1 || true
"$adb" -s "$serial" install -r "$work/app/app.apk" > "$work/install.log"
"$adb" -s "$serial" install -r "$work/test/app.apk" >> "$work/install.log"
for scenario in ${HEY_ANDROID_REPLY_SCENARIO:-normal busy-images repeat-primary navigate busy-share edit leave signout image-bounds account-cache}; do
  "$adb" -s "$serial" shell am force-stop hey.android.sharefixture
  curl -fsS "http://127.0.0.1:$port/reset" >/dev/null
  "$adb" -s "$serial" shell am instrument -w -e scenario "$scenario" hey.android.sharetest/hey.android.api.ReplyShareInstrumentation | tee "$work/$scenario.log"
  grep -q 'reply_form_share=true' "$work/$scenario.log"
done
