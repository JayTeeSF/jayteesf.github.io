# hey_ios

Apple-specific capability contracts layered under `hey_mobile`. This first slice declares UIKit lifecycle hosting, Keychain, LocalAuthentication, protected files, AVFoundation QR scanning, URLSession, Apple frameworks, and entitlement metadata. Native adapters remain opaque; no Keychain item, LAContext, key, or UIKit object crosses into ordinary Hey values.

Compiler/SDK/sign/install/launch porcelain remains in the Hey language repository under `hey mobile ios ...`.

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_ios`.
