#!/usr/bin/env python3
"""fake_api_server.py: a server shaped like a hey_mobile api_screens backend, for
specs/api_renderer_emulator_spec.sh. It names no product.

  fake_api_server.py --port N --description FILE --log FILE --tokens FILE

GET  /v1/app/description?platform=android&level=1
                         FILE's bytes as they are now (re-read each time), ETag the
                         SHA-256, Cache-Control no-cache; 304 on a matching If-None-Match
POST /v1/session         {username: ann, passphrase: fixture-pass-1} -> {token}; else 401
GET  /v1/session         who the bearer token is, or 401
POST /v1/session/revoke  the token stops working
GET  /v1/items           {items, item_count}
GET  /v1/items/<id>      {item, hook}
GET  /v1/account         {username}
POST /v1/mark            {ok}
POST /v1/search          {q} -> {items} whose title contains q; q "broken" is a 500,
                         and a q starting "slow" is answered after four seconds
anything else            404

Every request is one JSON line in --log: method, path, query, whether it carried
a bearer token, If-None-Match, the status answered, and the body's keys. Never
the token itself, so the spec can look for the token in the app's files and not
find it here by accident.
"""
import argparse
import hashlib
import json
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--description", required=True)
parser.add_argument("--log", required=True)
parser.add_argument("--tokens", required=True, help="every token issued, one per line, so a spec can look for it")
opts = parser.parse_args()

ITEMS = [
    {"id": "i1", "title": "The Left Hand of Darkness", "media_type": "book", "creator": "Ursula K. Le Guin", "hook": "An envoy on a winter world"},
    {"id": "i2", "title": "Stalker", "media_type": "movie", "creator": "Andrei Tarkovsky", "hook": "Three men walk into the Zone"},
    {"id": "i3", "title": "Longform", "media_type": "podcast", "creator": "Various", "hook": "Writers on how they work"},
]
tokens = {}
lock = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def record(self, status, keys):
        parts = urlsplit(self.path)
        line = {"method": self.command, "path": parts.path, "query": parts.query,
                "bearer": (self.headers.get("authorization") or "").startswith("Bearer "),
                "surface": self.headers.get("x-my-queue-surface"),
                "if_none_match": self.headers.get("if-none-match"), "status": status, "body_keys": keys}
        with lock, open(opts.log, "a") as f:
            f.write(json.dumps(line) + "\n")

    def who(self):
        auth = self.headers.get("authorization") or ""
        if not auth.startswith("Bearer "):
            return None
        with lock:
            return tokens.get(auth[len("Bearer "):])

    def send(self, status, payload=None, raw=None, headers=None, keys=None):
        self.record(status, keys or [])
        body = raw if raw is not None else (json.dumps(payload).encode() if payload is not None else b"")
        self.send_response(status)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        if status != 304:
            self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(body) if status != 304 else 0))
        self.end_headers()
        if status != 304:
            self.wfile.write(body)

    def body(self):
        n = int(self.headers.get("content-length") or 0)
        raw = self.rfile.read(n) if n else b""
        try:
            return json.loads(raw) if raw else {}
        except ValueError:
            return {}

    def do_GET(self):
        parts = urlsplit(self.path)
        path = parts.path
        if path == "/v1/app/description":
            q = parse_qs(parts.query)
            if q.get("platform") != ["android"] or q.get("level") != ["1"]:
                return self.send(400, {"ok": False, "error": "platform and level"})
            data = open(opts.description, "rb").read()
            etag = '"%s"' % hashlib.sha256(data).hexdigest()
            held = (self.headers.get("if-none-match") or "").replace("W/", "")
            if held == etag:
                return self.send(304, headers={"etag": etag, "cache-control": "no-cache"})
            return self.send(200, raw=data, headers={"etag": etag, "cache-control": "no-cache"})
        who = self.who()
        if who is None:
            return self.send(401, {"ok": False, "error": "sign in first"})
        if path == "/v1/session":
            return self.send(200, {"ok": True, "username": who})
        if path == "/v1/items":
            return self.send(200, {"ok": True, "items": ITEMS, "item_count": len(ITEMS)})
        if path.startswith("/v1/items/"):
            for item in ITEMS:
                if path == "/v1/items/" + item["id"]:
                    return self.send(200, {"ok": True, "item": item, "hook": item["hook"]})
            return self.send(404, {"ok": False, "error": "no such item"})
        if path == "/v1/account":
            return self.send(200, {"ok": True, "username": who})
        return self.send(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        path = urlsplit(self.path).path
        body = self.body()
        keys = sorted(body.keys()) if isinstance(body, dict) else []
        if path == "/v1/session":
            if body.get("username") == "ann" and body.get("passphrase") == "fixture-pass-1":
                token = secrets.token_hex(32)
                with lock:
                    tokens[token] = "ann"
                    with open(opts.tokens, "a") as f:
                        f.write(token + "\n")
                return self.send(200, {"ok": True, "username": "ann", "token": token}, keys=keys)
            return self.send(401, {"ok": False, "error": "wrong name or passphrase"}, keys=keys)
        who = self.who()
        if who is None:
            return self.send(401, {"ok": False, "error": "sign in first"}, keys=keys)
        if path == "/v1/session/revoke":
            auth = self.headers.get("authorization")[len("Bearer "):]
            with lock:
                tokens.pop(auth, None)
            return self.send(200, {"ok": True, "revoked": "this"}, keys=keys)
        if path == "/v1/mark":
            return self.send(200, {"ok": True}, keys=keys)
        if path == "/v1/search":
            q = str(body.get("q", "")).lower()
            if q == "broken":
                return self.send(500, {"ok": False, "error": "the search broke"}, keys=keys)
            if q.startswith("slow"):
                time.sleep(4)
            hits = [item for item in ITEMS if q and q in item["title"].lower()]
            return self.send(200, {"ok": True, "items": hits}, keys=keys)
        if path == "/v1/events":
            if body.get("event_name") != "screen.view" or body.get("surface") != "android" or not body.get("screen"):
                return self.send(400, {"ok": False, "error": "bad semantic event"}, keys=keys)
            return self.send(200, {"ok": True}, keys=keys)
        return self.send(404, {"ok": False, "error": "not found"}, keys=keys)


ThreadingHTTPServer.allow_reuse_address = True
server = ThreadingHTTPServer(("127.0.0.1", opts.port), Handler)
print("fake api server on 127.0.0.1:%d" % opts.port, flush=True)
server.serve_forever()
