#!/usr/bin/env bash
# Standalone test-only APK: production renderer classes plus one instrumentation class.
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
out=${1:?output directory required}
port=${2:-3582}
mkdir -p "$out/classes" "$out/dex" "$out/assets/hey-api"
java_home=$(hey_android_java_home)
bt=$HEY_ANDROID_BUILD_TOOLS_DIR
find "$ROOT/renderer/java" "$ROOT/renderer/android" "$ROOT/renderer/instrumentation/boundaries/device" -name '*.java' > "$out/sources"
"$java_home/bin/javac" --release 17 -classpath "$HEY_ANDROID_PLATFORM_JAR" -d "$out/classes" @"$out/sources"
find "$out/classes" -name '*.class' > "$out/classes.list"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/d8" --min-api 35 --lib "$HEY_ANDROID_PLATFORM_JAR" --output "$out/dex" @"$out/classes.list"
"$HEY_ANDROID_RUBY" -rjson -e 'd=JSON.parse(File.read(ARGV[0])); d["audio"]={"source"=>{"method"=>"GET","path"=>"/feed"},"position"=>{"method"=>"POST","path"=>"/position/{id}"},"row"=>{"id"=>"id","title"=>"title","audio_url"=>"url"},"sections"=>[{"title"=>"Queue","list"=>"tracks"}]}; File.write(ARGV[1],JSON.generate(d))' "$ROOT/specs/support/api_fixture_description.json" "$out/assets/hey-api/description.json"
printf 'http://10.0.2.2:%s' "$port" > "$out/assets/hey-api/origin.txt"
cat > "$out/AndroidManifest.xml" <<'XML'
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="hey.android.boundary">
  <uses-sdk android:minSdkVersion="35" android:targetSdkVersion="36"/>
  <uses-permission android:name="android.permission.INTERNET"/>
  <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
  <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
  <application android:label="Boundary fixture" android:debuggable="true" android:usesCleartextTraffic="true" android:allowBackup="false">
    <service android:name="hey.android.api.HeyAndroidAudioService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>
  </application>
  <instrumentation android:name="hey.android.api.BoundaryInstrumentation" android:targetPackage="hey.android.boundary"/>
</manifest>
XML
"$bt/aapt2" link --manifest "$out/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -A "$out/assets" -o "$out/base.apk"
(cd "$out/dex" && zip -q "$out/base.apk" classes.dex)
"$bt/zipalign" -P 16 -f 4 "$out/base.apk" "$out/aligned.apk"
env JAVA_HOME="$java_home" PATH="$java_home/bin:$PATH" "$bt/apksigner" sign --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$out/app.apk" "$out/aligned.apk"
