# Done

- v0.1.0 generic enrollment payload.
- Secret path and browser URL construction.
- Safe browser-page composition for QR enrollment.
- Updated runtime dependencies to repaired mobile/web releases and kept `hey_packager` external.
