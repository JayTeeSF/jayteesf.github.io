# Testing

Run the complete package gate:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"   bin/check
```

The package-specific portion is available directly as `bin/package-check`. The outer `bin/check` also validates `hey-package.json`, `VERSION`, every declared file, required documentation, and the executable documentation example.

`bin/package-check` runs `bin/conformance` (hey_mobile's vectors against the native evaluator on this Mac) and `bin/block-lifetimes`, which builds the host for the iOS Simulator with AddressSanitizer and runs the form's submit chain and the list's reorder chain against a stubbed request with `simctl spawn`. Each chain has a negative control: its fix reverted must stop with a heap-use-after-free. It boots an iPhone simulator when none is booted (`HEY_IOS_SIM_UDID` picks one) and shuts down any simulator it booted.

## Release verification

`bin/check-header-image-link` syntax-compiles the host and executes its real header on an iPhone simulator. It checks HTTP and HTTPS destinations, missing/empty/null bindings, unsafe schemes, malformed and relative URLs, missing artwork, accessible link semantics, and title/body isolation. The browser launch is intercepted so the expected canonical URL is observed without opening a network connection. Deliberate binding, validation, destination, and accessibility mutations must each fail. Like `bin/block-lifetimes`, it honors `HEY_IOS_SIM_UDID` and shuts down only a simulator it booted.

```sh
bin/release
unzip -tq "dist/hey_ios-0.4.11.zip"
unzip -tq "dist/hey_ios-registry-publication-0.4.11.zip"
cat dist/SHA256SUMS.txt
```
