#import "HeyIOSAudio.h"
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import <StoreKit/StoreKit.h>
#import <UIKit/UIKit.h>

NSNotificationName const HeyIOSAudioStateDidChange = @"HeyIOSAudioStateDidChange";

static NSString *HeyIOSAudioString(id value) {
  if ([value isKindOfClass:[NSString class]]) return value;
  if ([value isKindOfClass:[NSNumber class]]) return [value stringValue];
  return @"";
}

static NSInteger HeyIOSAudioInteger(id value) {
  return [value respondsToSelector:@selector(integerValue)] ? [value integerValue] : 0;
}

static NSArray<NSString *> *HeyIOSAudioPages(NSDictionary *row) {
  NSMutableArray *pages = [NSMutableArray array];
  if ([row[@"audio_urls"] isKindOfClass:[NSArray class]]) {
    for (id url in row[@"audio_urls"]) {
      NSString *s = HeyIOSAudioString(url);
      if (s.length > 0) [pages addObject:s];
    }
  }
  if (pages.count == 0 && HeyIOSAudioString(row[@"audio_url"]).length > 0) [pages addObject:HeyIOSAudioString(row[@"audio_url"])];
  return pages;
}

BOOL HeyIOSAudioRowPlayable(NSDictionary *row, BOOL appleMusicAvailable) {
  if (![row isKindOfClass:[NSDictionary class]]) return NO;
  NSString *audio = HeyIOSAudioString(row[@"audio_url"]);
  NSString *requires = HeyIOSAudioString(row[@"requires"]);
  if ([requires isEqualToString:@"apple_music_subscription"] && !appleMusicAvailable) return NO;
  if ([audio hasPrefix:@"https://"] || [audio hasPrefix:@"http://"]) return YES;
  return appleMusicAvailable && HeyIOSAudioString(row[@"apple_music_id"]).length > 0;
}

void HeyIOSAudioCheckAppleMusic(void (^completion)(BOOL available)) {
  if ([SKCloudServiceController authorizationStatus] != SKCloudServiceAuthorizationStatusAuthorized) {
    dispatch_async(dispatch_get_main_queue(), ^{ completion(NO); });
    return;
  }
  [[[SKCloudServiceController alloc] init] requestCapabilitiesWithCompletionHandler:^(SKCloudServiceCapability capabilities, NSError *error) {
    BOOL ok = error == nil && (capabilities & SKCloudServiceCapabilityMusicCatalogPlayback) != 0;
    dispatch_async(dispatch_get_main_queue(), ^{ completion(ok); });
  }];
}

@interface HeyIOSAudio ()
@property(nonatomic, assign, readwrite) HeyIOSAudioState state;
@property(nonatomic, copy, readwrite, nullable) NSDictionary *currentRow;
@property(nonatomic, assign, readwrite) NSInteger currentPage;
@property(nonatomic, copy, readwrite, nullable) NSString *lastError;
@property(nonatomic, strong, nullable) AVQueuePlayer *player;
@property(nonatomic, strong) NSArray<NSString *> *pages;
@property(nonatomic, strong, nullable) id timeObserver;
@property(nonatomic, strong) NSMutableArray *itemTokens;
@property(nonatomic, assign) BOOL observingPlayer;
@property(nonatomic, assign) BOOL usingAppleMusic;
@property(nonatomic, assign) BOOL commandsInstalled;
@end

@implementation HeyIOSAudio

+ (instancetype)shared {
  static HeyIOSAudio *shared;
  static dispatch_once_t once;
  dispatch_once(&once, ^{
    shared = [[HeyIOSAudio alloc] init];
    shared.reportInterval = 15;
    shared.itemTokens = [NSMutableArray array];
    shared.pages = @[];
  });
  return shared;
}

- (void)setState:(HeyIOSAudioState)state {
  _state = state;
  [self updateNowPlaying];
  [[NSNotificationCenter defaultCenter] postNotificationName:HeyIOSAudioStateDidChange object:self];
}

- (void)installCommands {
  if (self.commandsInstalled) return;
  self.commandsInstalled = YES;
  MPRemoteCommandCenter *center = [MPRemoteCommandCenter sharedCommandCenter];
  __weak typeof(self) weakSelf = self;
  [center.playCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
    (void)event;
    if (weakSelf.state != HeyIOSAudioStatePaused) return MPRemoteCommandHandlerStatusCommandFailed;
    [weakSelf togglePlayPause];
    return MPRemoteCommandHandlerStatusSuccess;
  }];
  // THE SAME TWO JUMPS A SCREEN OFFERS, so a steering wheel, a lock screen and
  // the app do not disagree about what "back" means. The intervals are declared
  // so the system can label its own buttons with them.
  center.skipBackwardCommand.preferredIntervals = @[@(HeyIOSAudioSkipBack)];
  [center.skipBackwardCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
    (void)event;
    if (weakSelf.currentRow == nil) return MPRemoteCommandHandlerStatusCommandFailed;
    [weakSelf skipBy:-HeyIOSAudioSkipBack];
    return MPRemoteCommandHandlerStatusSuccess;
  }];
  center.skipForwardCommand.preferredIntervals = @[@(HeyIOSAudioSkipOn)];
  [center.skipForwardCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
    (void)event;
    if (weakSelf.currentRow == nil) return MPRemoteCommandHandlerStatusCommandFailed;
    [weakSelf skipBy:HeyIOSAudioSkipOn];
    return MPRemoteCommandHandlerStatusSuccess;
  }];
  [center.pauseCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
    (void)event;
    if (weakSelf.state != HeyIOSAudioStatePlaying && weakSelf.state != HeyIOSAudioStateLoading) return MPRemoteCommandHandlerStatusCommandFailed;
    [weakSelf togglePlayPause];
    return MPRemoteCommandHandlerStatusSuccess;
  }];
  [center.togglePlayPauseCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
    (void)event;
    [weakSelf togglePlayPause];
    return MPRemoteCommandHandlerStatusSuccess;
  }];
  [center.stopCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent *event) {
    (void)event;
    [weakSelf stop];
    return MPRemoteCommandHandlerStatusSuccess;
  }];
  center.nextTrackCommand.enabled = NO;
  center.previousTrackCommand.enabled = NO;
  center.skipForwardCommand.enabled = NO;
  center.skipBackwardCommand.enabled = NO;
}

#pragma mark position reports

- (NSInteger)currentSeconds {
  if (self.player.currentItem == nil) return 0;
  double seconds = CMTimeGetSeconds(self.player.currentTime);
  return isfinite(seconds) && seconds > 0 ? (NSInteger)seconds : 0;
}

- (NSInteger)currentDuration {
  AVPlayerItem *item = self.player.currentItem;
  if (item == nil) return 0;
  double seconds = CMTimeGetSeconds(item.duration);
  return isfinite(seconds) && seconds > 0 ? (NSInteger)seconds : 0;
}

// A JUMP DOES NOT REPORT. Somebody hunting for a spot presses these several
// times over, and a write per press is noise about a position that is about to
// change again; the periodic report, or a pause, sends where they settled.
- (void)skipBy:(NSInteger)seconds {
  if (self.player.currentItem == nil || self.usingAppleMusic) return;
  NSInteger to = self.currentSeconds + seconds;
  if (to < 0) to = 0;
  NSInteger end = self.currentDuration;
  if (end > 0 && to > end) to = end;
  __weak typeof(self) weakSelf = self;
  [self.player seekToTime:CMTimeMakeWithSeconds(to, 600)
          toleranceBefore:kCMTimeZero
           toleranceAfter:kCMTimeZero
        completionHandler:^(BOOL finished) {
    (void)finished;
    [weakSelf updateNowPlaying];
  }];
}

- (void)reportFinished:(BOOL)finished {
  if (self.positionReporter == nil || self.currentRow == nil || self.usingAppleMusic) return;
  if (HeyIOSAudioString(self.currentRow[@"id"]).length == 0) return;
  self.positionReporter(self.currentRow, finished ? 0 : [self currentSeconds], self.currentPage, finished);
}

#pragma mark playing

- (void)playRow:(NSDictionary *)row {
  if (self.currentRow != nil && self.state != HeyIOSAudioStateIdle) [self reportFinished:NO];
  [self stopPlayers];
  self.currentRow = row;
  self.lastError = nil;
  [self installCommands];

  NSError *error = nil;
  AVAudioSession *session = [AVAudioSession sharedInstance];
  [session setCategory:AVAudioSessionCategoryPlayback mode:AVAudioSessionModeSpokenAudio options:0 error:&error];
  [session setActive:YES error:&error];

  NSString *appleID = HeyIOSAudioString(row[@"apple_music_id"]);
  NSArray<NSString *> *pages = HeyIOSAudioPages(row);
  if (pages.count == 0 && appleID.length > 0) {
    self.usingAppleMusic = YES;
    MPMusicPlayerApplicationController *music = [MPMusicPlayerController applicationQueuePlayer];
    [music setQueueWithStoreIDs:@[appleID]];
    [music play];
    self.state = HeyIOSAudioStatePlaying;
    return;
  }
  if (pages.count == 0) {
    self.lastError = @"This has no audio address.";
    self.state = HeyIOSAudioStateFailed;
    return;
  }

  self.usingAppleMusic = NO;
  self.pages = pages;
  NSInteger startPage = HeyIOSAudioInteger(row[@"position_page"]);
  if (startPage < 0 || startPage >= (NSInteger)pages.count) startPage = 0;
  self.currentPage = startPage;
  NSMutableArray<AVPlayerItem *> *items = [NSMutableArray array];
  for (NSInteger i = startPage; i < (NSInteger)pages.count; i++) {
    AVPlayerItem *item = [self itemForAddress:pages[i]];
    if (item == nil) {
      self.lastError = @"This audio address is not valid.";
      self.state = HeyIOSAudioStateFailed;
      return;
    }
    [items addObject:item];
  }
  self.player = [AVQueuePlayer queuePlayerWithItems:items];
  self.player.actionAtItemEnd = AVPlayerActionAtItemEndAdvance;
  [self.player addObserver:self forKeyPath:@"timeControlStatus" options:NSKeyValueObservingOptionNew context:NULL];
  [self.player addObserver:self forKeyPath:@"currentItem.status" options:NSKeyValueObservingOptionNew context:NULL];
  self.observingPlayer = YES;

  __weak typeof(self) weakSelf = self;
  for (AVPlayerItem *item in items) {
    id ended = [[NSNotificationCenter defaultCenter] addObserverForName:AVPlayerItemDidPlayToEndTimeNotification object:item queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
      (void)note;
      [weakSelf pageEnded];
    }];
    id failed = [[NSNotificationCenter defaultCenter] addObserverForName:AVPlayerItemFailedToPlayToEndTimeNotification object:item queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
      NSError *failure = note.userInfo[AVPlayerItemFailedToPlayToEndTimeErrorKey];
      weakSelf.lastError = failure.localizedDescription ?: @"Playback stopped.";
      weakSelf.state = HeyIOSAudioStateFailed;
    }];
    [self.itemTokens addObject:ended];
    [self.itemTokens addObject:failed];
  }
  NSTimeInterval every = self.reportInterval > 0 ? self.reportInterval : 15;
  self.timeObserver = [self.player addPeriodicTimeObserverForInterval:CMTimeMakeWithSeconds(every, 600) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
    (void)time;
    if (weakSelf.state == HeyIOSAudioStatePlaying) [weakSelf reportFinished:NO];
  }];

  NSInteger resume = HeyIOSAudioInteger(row[@"position_seconds"]);
  if (resume > 0) [self.player seekToTime:CMTimeMakeWithSeconds(resume, 600) toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero completionHandler:^(BOOL finished) { (void)finished; }];
  [self.player play];
  self.state = HeyIOSAudioStateLoading;
  [self loadArtwork:HeyIOSAudioString(row[@"image_url"]) forRow:row];
}

- (nullable AVPlayerItem *)itemForAddress:(NSString *)address {
  NSURL *url = [NSURL URLWithString:address];
  if (url == nil || url.scheme.length == 0) return nil;
  NSDictionary *headers = self.headersForURL ? self.headersForURL(url) : nil;
  NSDictionary *options = headers.count > 0 ? @{@"AVURLAssetHTTPHeaderFieldsKey": headers} : @{};
  AVURLAsset *asset = [AVURLAsset URLAssetWithURL:url options:options];
  return [AVPlayerItem playerItemWithAsset:asset];
}

- (void)pageEnded {
  if (self.currentPage + 1 < (NSInteger)self.pages.count) {
    self.currentPage += 1;
    [self reportFinished:NO];
    [self updateNowPlaying];
    return;
  }
  [self reportFinished:YES];
  [self stopPlayers];
  self.currentRow = nil;
  self.state = HeyIOSAudioStateIdle;
  [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = nil;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
  (void)change; (void)context;
  if (object != self.player) return;
  dispatch_async(dispatch_get_main_queue(), ^{
    if (object != self.player) return;
    if ([keyPath isEqualToString:@"currentItem.status"] && self.player.currentItem.status == AVPlayerItemStatusFailed) {
      self.lastError = self.player.currentItem.error.localizedDescription ?: @"This audio could not be opened.";
      self.state = HeyIOSAudioStateFailed;
      return;
    }
    if ([keyPath isEqualToString:@"timeControlStatus"] && self.state != HeyIOSAudioStateFailed) {
      switch (self.player.timeControlStatus) {
        case AVPlayerTimeControlStatusPlaying: self.state = HeyIOSAudioStatePlaying; break;
        case AVPlayerTimeControlStatusWaitingToPlayAtSpecifiedRate: self.state = HeyIOSAudioStateLoading; break;
        case AVPlayerTimeControlStatusPaused: if (self.currentRow != nil) self.state = HeyIOSAudioStatePaused; break;
      }
    }
  });
}

- (void)togglePlayPause {
  if (self.usingAppleMusic) {
    MPMusicPlayerApplicationController *music = [MPMusicPlayerController applicationQueuePlayer];
    if (self.state == HeyIOSAudioStatePlaying) { [music pause]; self.state = HeyIOSAudioStatePaused; }
    else { [music play]; self.state = HeyIOSAudioStatePlaying; }
    return;
  }
  if (self.player == nil) return;
  if (self.player.rate > 0) {
    [self.player pause];
    self.state = HeyIOSAudioStatePaused;
    [self reportFinished:NO];
  } else {
    [self.player play];
    self.state = HeyIOSAudioStatePlaying;
  }
}

- (void)stopPlayers {
  if (self.timeObserver != nil) [self.player removeTimeObserver:self.timeObserver];
  self.timeObserver = nil;
  if (self.observingPlayer) {
    [self.player removeObserver:self forKeyPath:@"timeControlStatus"];
    [self.player removeObserver:self forKeyPath:@"currentItem.status"];
  }
  self.observingPlayer = NO;
  for (id token in self.itemTokens) [[NSNotificationCenter defaultCenter] removeObserver:token];
  [self.itemTokens removeAllObjects];
  [self.player pause];
  [self.player removeAllItems];
  self.player = nil;
  if (self.usingAppleMusic) [[MPMusicPlayerController applicationQueuePlayer] stop];
  self.usingAppleMusic = NO;
  self.pages = @[];
}

- (void)stop {
  if (self.currentRow != nil && self.state != HeyIOSAudioStateIdle) [self reportFinished:NO];
  [self stopPlayers];
  self.currentRow = nil;
  self.currentPage = 0;
  self.state = HeyIOSAudioStateIdle;
  [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = nil;
}

- (void)updateNowPlaying {
  NSDictionary *row = self.currentRow;
  if (row == nil) return;
  NSMutableDictionary *info = [[MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo mutableCopy] ?: [NSMutableDictionary dictionary];
  info[MPMediaItemPropertyTitle] = HeyIOSAudioString(row[@"title"]);
  NSString *subtitle = HeyIOSAudioString(row[@"subtitle"]);
  if (subtitle.length == 0) subtitle = HeyIOSAudioString(row[@"creator"]);
  info[MPMediaItemPropertyArtist] = subtitle;
  info[MPNowPlayingInfoPropertyIsLiveStream] = @([HeyIOSAudioString(row[@"kind"]) isEqualToString:@"radio"]);
  info[MPNowPlayingInfoPropertyPlaybackRate] = @(self.state == HeyIOSAudioStatePlaying ? 1.0 : 0.0);
  if (self.pages.count > 1) {
    info[MPNowPlayingInfoPropertyChapterNumber] = @(self.currentPage);
    info[MPNowPlayingInfoPropertyChapterCount] = @(self.pages.count);
  }
  if (self.player.currentItem != nil) {
    double elapsed = CMTimeGetSeconds(self.player.currentTime);
    if (isfinite(elapsed)) info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = @(elapsed);
  }
  [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = info;
  MPNowPlayingInfoCenter.defaultCenter.playbackState = self.state == HeyIOSAudioStatePlaying ? MPNowPlayingPlaybackStatePlaying : (self.state == HeyIOSAudioStatePaused ? MPNowPlayingPlaybackStatePaused : MPNowPlayingPlaybackStateStopped);
}

- (void)loadArtwork:(NSString *)address forRow:(NSDictionary *)row {
  NSURL *url = [NSURL URLWithString:address];
  if (url == nil || url.scheme.length == 0) return;
  [[[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
    (void)response;
    UIImage *image = error == nil && data.length > 0 ? [UIImage imageWithData:data] : nil;
    if (image == nil) return;
    dispatch_async(dispatch_get_main_queue(), ^{
      if (self.currentRow != row) return;
      NSMutableDictionary *info = [[MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo mutableCopy] ?: [NSMutableDictionary dictionary];
      info[MPMediaItemPropertyArtwork] = [[MPMediaItemArtwork alloc] initWithBoundsSize:image.size requestHandler:^UIImage *(CGSize size) { (void)size; return image; }];
      [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = info;
    });
  }] resume];
}

@end
