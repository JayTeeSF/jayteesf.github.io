#include "hey_durable_log_native.h"
#include "hey_durable_log.h"

#include <limits.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  hdl_log *log;
  hdl_broker *broker;
} hey_durable_log_connection;

typedef struct {
  hdl_status status;
  hdl_receipt value;
} hey_durable_log_receipt;

typedef struct {
  hdl_status status;
  uint64_t sequence;
  uint64_t batch_id;
  uint64_t stream_id;
  uint8_t *payload;
  uint32_t payload_length;
} hey_durable_log_record;

static char *copy_utf8(HeyNativeUtf8View value) {
  char *copy = malloc(value.length + 1);
  if (copy == NULL) return NULL;
  if (value.length > 0 && value.data != NULL) memcpy(copy, value.data, value.length);
  copy[value.length] = '\0';
  return copy;
}

static hey_durable_log_connection *connection_value(HeyNativeHandle handle) {
  return (hey_durable_log_connection *)(uintptr_t)handle;
}

static hey_durable_log_receipt *receipt_value(HeyNativeHandle handle) {
  return (hey_durable_log_receipt *)(uintptr_t)handle;
}

static hdl_cursor *cursor_value(HeyNativeHandle handle) {
  return (hdl_cursor *)(uintptr_t)handle;
}

static hey_durable_log_record *record_value(HeyNativeHandle handle) {
  return (hey_durable_log_record *)(uintptr_t)handle;
}

HeyNativeHandle hey_durable_log_native_open(HeyNativeUtf8View path,
                                             int32_t queue_capacity,
                                             int32_t max_batch_records,
                                             int32_t batch_window_microseconds) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0) return (HeyNativeHandle)0;
  char *path_copy = copy_utf8(path);
  hey_durable_log_connection *connection = calloc(1, sizeof(*connection));
  if (path_copy == NULL || connection == NULL) {
    free(path_copy);
    free(connection);
    return (HeyNativeHandle)0;
  }
  hdl_status status = hdl_open(path_copy, NULL, &connection->log);
  free(path_copy);
  if (status == HDL_OK) {
    hdl_broker_options options = {
      (uint32_t)queue_capacity,
      (uint32_t)max_batch_records,
      (uint32_t)batch_window_microseconds
    };
    status = hdl_broker_open(connection->log, &options, &connection->broker);
  }
  if (status != HDL_OK) {
    if (connection->log != NULL) (void)hdl_close(connection->log);
    free(connection);
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)connection;
}

int32_t hey_durable_log_native_open_status(HeyNativeUtf8View path,
                                            int32_t queue_capacity,
                                            int32_t max_batch_records,
                                            int32_t batch_window_microseconds) {
  if (path.data == NULL || path.length == 0 || queue_capacity <= 0 ||
      max_batch_records <= 0 || batch_window_microseconds <= 0) return HDL_INVALID;
  char *path_copy = copy_utf8(path);
  if (path_copy == NULL) return HDL_NOMEM;
  hdl_log *log = NULL;
  hdl_status status = hdl_open(path_copy, NULL, &log);
  free(path_copy);
  if (log != NULL) (void)hdl_close(log);
  return status;
}

int32_t hey_durable_log_native_close(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return HDL_INVALID;
  hdl_status broker_status = hdl_broker_close(connection->broker);
  hdl_status log_status = hdl_close(connection->log);
  free(connection);
  return broker_status != HDL_OK ? broker_status : log_status;
}

HeyNativeHandle hey_durable_log_native_submit(HeyNativeHandle handle,
                                               int64_t stream_id,
                                               HeyNativeBytesView payload) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL || stream_id <= 0 || payload.length > UINT32_MAX ||
      (payload.length > 0 && payload.data == NULL)) {
    return (HeyNativeHandle)0;
  }
  hey_durable_log_receipt *receipt = calloc(1, sizeof(*receipt));
  if (receipt == NULL) return (HeyNativeHandle)0;
  hdl_record record = {(uint64_t)stream_id, payload.data, (uint32_t)payload.length};
  receipt->status = hdl_broker_submit(connection->broker, &record, &receipt->value);
  return (HeyNativeHandle)(uintptr_t)receipt;
}

int32_t hey_durable_log_native_receipt_status(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL ? HDL_INVALID : receipt->status;
}

int64_t hey_durable_log_native_receipt_sequence(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.first_sequence > INT64_MAX
           ? -1 : (int64_t)receipt->value.first_sequence;
}

int64_t hey_durable_log_native_receipt_batch_id(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.batch_id > INT64_MAX
           ? -1 : (int64_t)receipt->value.batch_id;
}

int64_t hey_durable_log_native_receipt_durable_offset(HeyNativeHandle handle) {
  hey_durable_log_receipt *receipt = receipt_value(handle);
  return receipt == NULL || receipt->status != HDL_OK || receipt->value.durable_offset > INT64_MAX
           ? -1 : (int64_t)receipt->value.durable_offset;
}

void hey_durable_log_native_receipt_close(HeyNativeHandle handle) {
  free(receipt_value(handle));
}

HeyNativeHandle hey_durable_log_native_cursor_open(HeyNativeHandle handle) {
  hey_durable_log_connection *connection = connection_value(handle);
  if (connection == NULL) return (HeyNativeHandle)0;
  hdl_cursor *cursor = NULL;
  if (hdl_cursor_open(connection->log, &cursor) != HDL_OK) return (HeyNativeHandle)0;
  return (HeyNativeHandle)(uintptr_t)cursor;
}

HeyNativeHandle hey_durable_log_native_cursor_next(HeyNativeHandle handle) {
  hdl_cursor *cursor = cursor_value(handle);
  if (cursor == NULL) return (HeyNativeHandle)0;
  hey_durable_log_record *record = calloc(1, sizeof(*record));
  if (record == NULL) return (HeyNativeHandle)0;
  hdl_cursor_record value;
  record->status = hdl_cursor_next(cursor, &value);
  if (record->status == HDL_OK) {
    record->sequence = value.sequence;
    record->batch_id = value.batch_id;
    record->stream_id = value.stream_id;
    record->payload_length = value.payload_length;
    if (value.payload_length > 0) {
      record->payload = malloc(value.payload_length);
      if (record->payload == NULL) {
        record->status = HDL_NOMEM;
        record->payload_length = 0;
      } else {
        memcpy(record->payload, value.payload, value.payload_length);
      }
    }
  }
  return (HeyNativeHandle)(uintptr_t)record;
}

int32_t hey_durable_log_native_cursor_close(HeyNativeHandle handle) {
  return hdl_cursor_close(cursor_value(handle));
}

int32_t hey_durable_log_native_record_status(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL ? HDL_INVALID : record->status;
}

int64_t hey_durable_log_native_record_sequence(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->sequence > INT64_MAX
           ? -1 : (int64_t)record->sequence;
}

int64_t hey_durable_log_native_record_batch_id(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->batch_id > INT64_MAX
           ? -1 : (int64_t)record->batch_id;
}

int64_t hey_durable_log_native_record_stream_id(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  return record == NULL || record->status != HDL_OK || record->stream_id > INT64_MAX
           ? -1 : (int64_t)record->stream_id;
}

HeyNativeBytesView hey_durable_log_native_record_payload(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  if (record == NULL || record->status != HDL_OK) return (HeyNativeBytesView){NULL, 0};
  return (HeyNativeBytesView){record->payload, record->payload_length};
}

void hey_durable_log_native_record_close(HeyNativeHandle handle) {
  hey_durable_log_record *record = record_value(handle);
  if (record == NULL) return;
  free(record->payload);
  free(record);
}
