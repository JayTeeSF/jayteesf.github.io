#define _POSIX_C_SOURCE 200809L
/* F_FULLFSYNC is a Darwin extension and strict _POSIX_C_SOURCE hides it. It is
   the only barrier on this platform that actually flushes the drive cache, so
   the durability promise depends on it being visible here. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#endif

#include "hey_durable_log.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/file.h>
#include <inttypes.h>
#include <stdio.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define HDL_SEGMENT_HEADER_SIZE 64u
#define HDL_FRAME_HEADER_SIZE 56u
#define HDL_COMMIT_PAYLOAD_SIZE 24u
#define HDL_FORMAT_VERSION 2u
#define HDL_FRAME_MAGIC 0x464c4448u
#define HDL_FRAME_DATA 1u
#define HDL_FRAME_COMMIT 2u
#define HDL_DEFAULT_MAX_RECORD_BYTES (16u * 1024u * 1024u)
#define HDL_DEFAULT_MAX_BATCH_RECORDS 4096u
#define HDL_DEFAULT_QUEUE_CAPACITY 4096u
#define HDL_DEFAULT_BROKER_BATCH_RECORDS 64u
#define HDL_DEFAULT_BATCH_WINDOW_US 250u
/* etcd's segment size, and for the same reason: large enough that cutting is
   rare, small enough that a segment can be retired, copied or verified as a
   unit. */
#define HDL_DEFAULT_SEGMENT_SIZE_BYTES (64ull * 1024ull * 1024ull)
/* A segment file is named for the two facts recovery needs: its index in the
   log and its base position in the log-global byte space. The directory listing
   is therefore the manifest, which is why there is no manifest file to keep
   atomically consistent with anything. A segment that has not been renamed into
   this name is not part of the log. */
#define HDL_SEGMENT_NAME_SIZE 38u
#define HDL_SEGMENT_SUFFIX ".seg"
#define HDL_SEGMENT_TEMPORARY_SUFFIX ".seg.tmp"
#define HDL_WRITER_LOCK "journal.lock"

static const unsigned char HDL_SEGMENT_MAGIC[8] = {'H', 'D', 'L', 'G', 'v', '0', '0', '2'};

typedef struct {
  uint64_t offset;
  uint64_t sequence;
  uint64_t batch_id;
  uint64_t stream_id;
  uint32_t payload_length;
  uint32_t frame_crc;
} hdl_pending_frame;

typedef struct {
  uint64_t index;
  uint64_t base_position;
  /* Offset at which this segment's committed data ends. Filled in for cursors;
     zero elsewhere. */
  uint64_t end_offset;
} hdl_segment;

struct hdl_log {
  int fd;
  /* Exclusive writer ownership, held for the life of the handle.

     A per-handle mutex serializes callers within a handle and does nothing
     across handles: each handle derives its append offset, sequence, batch id
     and previous-frame CRC from recovery at open time, so two handles both
     believe they own the tail and both acknowledge the same sequence. This is
     an advisory flock, which POSIX record locks could not do -- those are
     per-PROCESS, so a second open in the same process would be granted the lock
     it already holds -- and which the kernel releases when the process dies, so
     a crash never leaves a journal nobody can open. */
  int lock_fd;
  /* The journal directory. The active segment is the highest-indexed published
     segment inside it. */
  char *path;
  uint64_t segment_index;
  /* Byte position of this segment's first byte in the log as a whole. Every
     frame records base_position + its own offset, so a frame is only valid at
     the place it was written for. */
  uint64_t base_position;
  uint64_t append_offset;
  uint64_t next_sequence;
  uint64_t next_batch_id;
  uint32_t previous_frame_crc;
  uint32_t max_record_bytes;
  uint32_t max_batch_records;
  uint64_t segment_size_bytes;
  uint64_t generation;
  /* Set once a durability barrier has failed on this descriptor. From that
     moment the handle cannot tell the truth about what is durable, so it stops
     acknowledging. Only reopening -- which re-runs recovery over the bytes on
     disk -- restores the knowledge the failed barrier destroyed. */
  int poisoned;
  pthread_mutex_t mutex;
};

struct hdl_cursor {
  /* A cursor snapshots the SET as well as the boundary. Segments cut after it
     opened lie beyond its committed position, so it never reaches them, and it
     reads its own descriptors rather than sharing the append descriptor. */
  char *directory;
  hdl_segment *segments;
  size_t segment_count;
  size_t current;
  int fd;
  uint64_t offset;
  uint64_t committed_position;
  uint32_t max_record_bytes;
  unsigned char *payload;
};

typedef struct hdl_request hdl_request;
struct hdl_request {
  hdl_record record;
  hdl_receipt receipt;
  hdl_status status;
  int done;
  pthread_cond_t completed;
  hdl_request *next;
};

struct hdl_broker {
  hdl_log *log;
  pthread_t writer;
  pthread_mutex_t mutex;
  pthread_cond_t not_empty;
  pthread_cond_t not_full;
  hdl_request *head;
  hdl_request *tail;
  uint32_t queued;
  uint32_t queue_capacity;
  uint32_t max_batch_records;
  uint32_t batch_window_microseconds;
  int stopping;
  hdl_broker_stats stats;
};

typedef struct {
  uint64_t committed_offset;
  uint64_t last_sequence;
  uint64_t last_batch_id;
  uint32_t previous_frame_crc;
} hdl_recovery;

#ifdef HDL_ENABLE_TEST_HOOKS
static _Atomic int hdl_fail_sync = 0;
static _Atomic long long hdl_write_budget = -1;
static _Atomic long long hdl_kill_write_budget = -1;
static _Atomic int hdl_kill_before_sync = 0;
static _Atomic int hdl_kill_after_sync = 0;
static _Atomic int hdl_kill_rotation_point = 0;
static _Atomic int hdl_fail_rotation_sync = 0;
static _Atomic long long hdl_kill_snapshot_budget = -1;
static _Atomic long long hdl_stall_sync_microseconds = 0;

void hdl_test_fail_next_sync(void) {
  atomic_store(&hdl_fail_sync, 1);
}

void hdl_test_fail_write_after_bytes(long long bytes) {
  atomic_store(&hdl_write_budget, bytes);
}

void hdl_test_kill_during_write_after_bytes(long long bytes) {
  atomic_store(&hdl_kill_write_budget, bytes);
}

void hdl_test_kill_before_next_sync(void) {
  atomic_store(&hdl_kill_before_sync, 1);
}

void hdl_test_kill_after_next_sync(void) {
  atomic_store(&hdl_kill_after_sync, 1);
}

void hdl_test_kill_at_rotation(int point) {
  atomic_store(&hdl_kill_rotation_point, point);
}

void hdl_test_fail_rotation_sync(void) {
  atomic_store(&hdl_fail_rotation_sync, 1);
}

void hdl_test_kill_during_snapshot_after_segments(long long segments) {
  atomic_store(&hdl_kill_snapshot_budget, segments);
}

void hdl_test_stall_next_sync_microseconds(long long microseconds) {
  atomic_store(&hdl_stall_sync_microseconds, microseconds);
}

void hdl_test_clear_failures(void) {
  atomic_store(&hdl_stall_sync_microseconds, 0);
  atomic_store(&hdl_kill_snapshot_budget, -1);
  atomic_store(&hdl_kill_rotation_point, 0);
  atomic_store(&hdl_fail_rotation_sync, 0);
  atomic_store(&hdl_fail_sync, 0);
  atomic_store(&hdl_write_budget, -1);
  atomic_store(&hdl_kill_write_budget, -1);
  atomic_store(&hdl_kill_before_sync, 0);
  atomic_store(&hdl_kill_after_sync, 0);
}
#endif

/* One numbered stop per step of the cut, so the crash matrix can be enumerated
   rather than sampled. Compiled out entirely without the test hooks. */
static void rotation_checkpoint(int point) {
#ifdef HDL_ENABLE_TEST_HOOKS
  if (atomic_load(&hdl_kill_rotation_point) == point) raise(SIGKILL);
#else
  (void)point;
#endif
}

static void snapshot_checkpoint(void) {
#ifdef HDL_ENABLE_TEST_HOOKS
  long long remaining = atomic_load(&hdl_kill_snapshot_budget);
  if (remaining < 0) return;
  if (remaining == 0) raise(SIGKILL);
  atomic_store(&hdl_kill_snapshot_budget, remaining - 1);
#endif
}

static int rotation_sync_failed(void) {
#ifdef HDL_ENABLE_TEST_HOOKS
  return atomic_exchange(&hdl_fail_rotation_sync, 0) != 0;
#else
  return 0;
#endif
}

const char *hdl_sync_barrier_name(void) {
#if defined(__APPLE__)
  return "F_FULLFSYNC";
#else
  return "fdatasync";
#endif
}

/* The durability barrier. This function IS the acknowledgement boundary: every
   promise this package makes reduces to "we returned only after this succeeded".
 *
 * On Darwin, fdatasync/fsync are NOT that boundary. fsync(2) on this platform
 * says so directly: after it returns, "the drive itself may not physically
 * write the data to the platters for quite some time", on power loss "the
 * application may find that only some or none of their data was written", and
 * "this is not a theoretical edge case". Acknowledging there would mean
 * acknowledging the drive's volatile cache -- the same defect as acknowledging
 * RAM, one layer further down, and undetectable until the power actually fails.
 * F_FULLFSYNC asks the drive to flush that cache, which is the guarantee we
 * claim, so it is what we issue.
 *
 * There is no silent fallback. A filesystem that refuses F_FULLFSYNC returns
 * the error to the caller and the batch is NOT acknowledged, because quietly
 * degrading to a weaker barrier would leave the promise stated and unmet --
 * exactly the failure this package exists to prevent. */
static int sync_data(int fd) {
#ifdef HDL_ENABLE_TEST_HOOKS
  long long stall = atomic_exchange(&hdl_stall_sync_microseconds, 0);
  if (stall > 0) {
    /* nanosleep, not usleep: usleep is not declared under _POSIX_C_SOURCE
       200809L on glibc, so a build that is clean on Darwin fails on Linux with
       -Werror. The Linux gate caught exactly that. */
    struct timespec pause;
    pause.tv_sec = (time_t)(stall / 1000000);
    pause.tv_nsec = (long)((stall % 1000000) * 1000);
    (void)nanosleep(&pause, NULL);
  }
  if (atomic_exchange(&hdl_kill_before_sync, 0) != 0) raise(SIGKILL);
  if (atomic_exchange(&hdl_fail_sync, 0) != 0) {
    errno = EIO;
    return -1;
  }
#endif
#if defined(__APPLE__)
  int result = fcntl(fd, F_FULLFSYNC, 0);
#else
  int result = fdatasync(fd);
#endif
#ifdef HDL_ENABLE_TEST_HOOKS
  if (result == 0 && atomic_exchange(&hdl_kill_after_sync, 0) != 0) raise(SIGKILL);
#endif
  return result;
}

static ssize_t write_bytes(int fd, const unsigned char *bytes, size_t length) {
#ifdef HDL_ENABLE_TEST_HOOKS
  long long budget = atomic_load(&hdl_write_budget);
  long long kill_budget = atomic_load(&hdl_kill_write_budget);
  if (budget == 0) {
    errno = ENOSPC;
    return -1;
  }
  if (budget > 0 && (unsigned long long)budget < length) length = (size_t)budget;
  if (kill_budget == 0) raise(SIGKILL);
  if (kill_budget > 0 && (unsigned long long)kill_budget < length) length = (size_t)kill_budget;
#endif
  ssize_t result = write(fd, bytes, length);
#ifdef HDL_ENABLE_TEST_HOOKS
  if (result > 0 && budget > 0) atomic_fetch_sub(&hdl_write_budget, result);
  if (result > 0 && kill_budget > 0) atomic_fetch_sub(&hdl_kill_write_budget, result);
#endif
  return result;
}

static void put_u16(unsigned char *out, uint16_t value) {
  out[0] = (unsigned char)value;
  out[1] = (unsigned char)(value >> 8);
}

static void put_u32(unsigned char *out, uint32_t value) {
  for (int index = 0; index < 4; index++) out[index] = (unsigned char)(value >> (index * 8));
}

static void put_u64(unsigned char *out, uint64_t value) {
  for (int index = 0; index < 8; index++) out[index] = (unsigned char)(value >> (index * 8));
}

static uint16_t get_u16(const unsigned char *in) {
  return (uint16_t)((uint16_t)in[0] | ((uint16_t)in[1] << 8));
}

static uint32_t get_u32(const unsigned char *in) {
  uint32_t value = 0;
  for (int index = 0; index < 4; index++) value |= (uint32_t)in[index] << (index * 8);
  return value;
}

static uint64_t get_u64(const unsigned char *in) {
  uint64_t value = 0;
  for (int index = 0; index < 8; index++) value |= (uint64_t)in[index] << (index * 8);
  return value;
}

static uint32_t crc32_continue(uint32_t state, const unsigned char *bytes, size_t length) {
  uint32_t crc = state;
  for (size_t index = 0; index < length; index++) {
    crc ^= bytes[index];
    for (int bit = 0; bit < 8; bit++) crc = (crc >> 1) ^ (0xedb88320u & (uint32_t)-(int32_t)(crc & 1u));
  }
  return crc;
}

static uint32_t crc32_parts(const unsigned char *first,
                            size_t first_length,
                            const unsigned char *second,
                            size_t second_length) {
  uint32_t crc = crc32_continue(0xffffffffu, first, first_length);
  crc = crc32_continue(crc, second, second_length);
  return ~crc;
}

static int write_all(int fd, const unsigned char *bytes, size_t length) {
  size_t offset = 0;
  while (offset < length) {
    ssize_t written = write_bytes(fd, bytes + offset, length - offset);
    if (written < 0 && errno == EINTR) continue;
    if (written <= 0) return -1;
    offset += (size_t)written;
  }
  return 0;
}

static int pread_all(int fd, unsigned char *bytes, size_t length, uint64_t offset) {
  size_t consumed = 0;
  while (consumed < length) {
    ssize_t read_count = pread(fd, bytes + consumed, length - consumed, (off_t)(offset + consumed));
    if (read_count < 0 && errno == EINTR) continue;
    if (read_count <= 0) return -1;
    consumed += (size_t)read_count;
  }
  return 0;
}

static uint64_t unix_nanoseconds(void) {
  struct timespec now;
  if (clock_gettime(CLOCK_REALTIME, &now) != 0) return 0;
  return (uint64_t)now.tv_sec * 1000000000u + (uint64_t)now.tv_nsec;
}

static struct timespec realtime_after_microseconds(uint32_t microseconds) {
  struct timespec deadline;
  (void)clock_gettime(CLOCK_REALTIME, &deadline);
  deadline.tv_nsec += (long)microseconds * 1000L;
  deadline.tv_sec += deadline.tv_nsec / 1000000000L;
  deadline.tv_nsec %= 1000000000L;
  return deadline;
}

static int sync_parent_directory(const char *path) {
  const char *slash = strrchr(path, '/');
  char *directory = NULL;
  if (slash == NULL) {
    directory = strdup(".");
  } else if (slash == path) {
    directory = strdup("/");
  } else {
    size_t length = (size_t)(slash - path);
    directory = malloc(length + 1);
    if (directory != NULL) {
      memcpy(directory, path, length);
      directory[length] = '\0';
    }
  }
  if (directory == NULL) return -1;
  int fd = open(directory, O_RDONLY | O_CLOEXEC | O_DIRECTORY);
  free(directory);
  if (fd < 0) return -1;
  int result = fsync(fd);
  int saved_errno = errno;
  close(fd);
  errno = saved_errno;
  return result;
}

static hdl_status validate_segment_header(int fd, uint64_t file_size,
                                          uint64_t *base_position,
                                          uint64_t *generation) {
  if (file_size < HDL_SEGMENT_HEADER_SIZE) return HDL_CORRUPTION;
  unsigned char header[HDL_SEGMENT_HEADER_SIZE];
  if (pread_all(fd, header, sizeof(header), 0) != 0) return HDL_IO;
  if (memcmp(header, HDL_SEGMENT_MAGIC, sizeof(HDL_SEGMENT_MAGIC)) != 0 ||
      get_u32(header + 8) != HDL_SEGMENT_HEADER_SIZE ||
      get_u32(header + 12) != HDL_FORMAT_VERSION ||
      get_u32(header + 60) != crc32_parts(header, 60, NULL, 0)) {
    return HDL_CORRUPTION;
  }
  if (base_position != NULL) *base_position = get_u64(header + 32);
  if (generation != NULL) *generation = get_u64(header + 16);
  return HDL_OK;
}

static void segment_file_name(char out[HDL_SEGMENT_NAME_SIZE],
                              uint64_t index,
                              uint64_t base_position) {
  snprintf(out, HDL_SEGMENT_NAME_SIZE, "%016" PRIx64 "-%016" PRIx64 HDL_SEGMENT_SUFFIX,
           index, base_position);
}

static int parse_hex_field(const char *text, uint64_t *out) {
  uint64_t value = 0;
  for (int position = 0; position < 16; position++) {
    char digit = text[position];
    uint64_t nibble;
    if (digit >= '0' && digit <= '9') nibble = (uint64_t)(digit - '0');
    else if (digit >= 'a' && digit <= 'f') nibble = (uint64_t)(digit - 'a') + 10u;
    else return -1;
    value = (value << 4) | nibble;
  }
  *out = value;
  return 0;
}

/* Only an exactly-formed name is a segment. Everything else in the directory --
   a half-built segment still under its temporary name, an operator's copy, a
   stray file -- is not part of the log and is walked past. */
static int parse_segment_name(const char *name, uint64_t *index, uint64_t *base_position) {
  if (strlen(name) != HDL_SEGMENT_NAME_SIZE - 1) return -1;
  if (name[16] != '-') return -1;
  if (strcmp(name + 33, HDL_SEGMENT_SUFFIX) != 0) return -1;
  if (parse_hex_field(name, index) != 0) return -1;
  if (parse_hex_field(name + 17, base_position) != 0) return -1;
  return 0;
}

static int sync_directory(const char *directory) {
  int fd = open(directory, O_RDONLY | O_CLOEXEC | O_DIRECTORY);
  if (fd < 0) return -1;
  int result = fsync(fd);
  int saved_errno = errno;
  close(fd);
  errno = saved_errno;
  return result;
}

static int segment_path(char *out, size_t size, const char *directory, const char *name) {
  int written = snprintf(out, size, "%s/%s", directory, name);
  return (written < 0 || (size_t)written >= size) ? -1 : 0;
}

/* Publish a segment the way etcd cuts one: build it under a temporary name,
   sync its bytes, rename it into the name recovery looks for, and only then
   sync the directory. A crash before the rename leaves a file recovery cannot
   see; a crash after it leaves a segment whose bytes are already durable. There
   is never a published segment whose contents were not synced first. */
static hdl_status publish_segment(const char *directory,
                                  uint64_t index,
                                  uint64_t base_position,
                                  uint64_t generation,
                                  int *out_fd) {
  char name[HDL_SEGMENT_NAME_SIZE];
  char temporary[HDL_SEGMENT_NAME_SIZE + 8];
  char temporary_path_buffer[4096];
  char final_path_buffer[4096];
  segment_file_name(name, index, base_position);
  snprintf(temporary, sizeof(temporary), "%016" PRIx64 "-%016" PRIx64 HDL_SEGMENT_TEMPORARY_SUFFIX,
           index, base_position);
  if (segment_path(temporary_path_buffer, sizeof(temporary_path_buffer), directory, temporary) != 0 ||
      segment_path(final_path_buffer, sizeof(final_path_buffer), directory, name) != 0) {
    return HDL_INVALID;
  }

  (void)unlink(temporary_path_buffer);
  int fd = open(temporary_path_buffer, O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
  if (fd < 0) return HDL_IO;
  rotation_checkpoint(1);

  unsigned char header[HDL_SEGMENT_HEADER_SIZE];
  memset(header, 0, sizeof(header));
  memcpy(header, HDL_SEGMENT_MAGIC, sizeof(HDL_SEGMENT_MAGIC));
  put_u32(header + 8, HDL_SEGMENT_HEADER_SIZE);
  put_u32(header + 12, HDL_FORMAT_VERSION);
  put_u64(header + 16, generation);
  put_u64(header + 24, unix_nanoseconds());
  put_u64(header + 32, base_position);
  put_u32(header + 60, crc32_parts(header, 60, NULL, 0));
  if (write_all(fd, header, sizeof(header) / 2) != 0) {
    close(fd);
    (void)unlink(temporary_path_buffer);
    return HDL_IO;
  }
  rotation_checkpoint(2);
  if (write_all(fd, header + sizeof(header) / 2, sizeof(header) - sizeof(header) / 2) != 0) {
    close(fd);
    (void)unlink(temporary_path_buffer);
    return HDL_IO;
  }
  rotation_checkpoint(3);
  if (rotation_sync_failed() || sync_data(fd) != 0) {
    close(fd);
    (void)unlink(temporary_path_buffer);
    return HDL_IO;
  }
  close(fd);
  rotation_checkpoint(4);

  if (rename(temporary_path_buffer, final_path_buffer) != 0) {
    (void)unlink(temporary_path_buffer);
    return HDL_IO;
  }
  rotation_checkpoint(5);
  if (sync_directory(directory) != 0) return HDL_IO;
  rotation_checkpoint(6);

  if (out_fd != NULL) {
    int published = open(final_path_buffer, O_RDWR | O_CLOEXEC | O_APPEND);
    if (published < 0) return HDL_IO;
    *out_fd = published;
  }
  return HDL_OK;
}

static int compare_segments(const void *left, const void *right) {
  const hdl_segment *a = left;
  const hdl_segment *b = right;
  if (a->index < b->index) return -1;
  if (a->index > b->index) return 1;
  return 0;
}

static hdl_status list_segments(const char *directory, hdl_segment **out, size_t *count) {
  *out = NULL;
  *count = 0;
  DIR *handle = opendir(directory);
  if (handle == NULL) return errno == ENOENT ? HDL_INVALID : HDL_IO;
  hdl_segment *segments = NULL;
  size_t used = 0;
  size_t capacity = 0;
  hdl_status status = HDL_OK;
  struct dirent *entry;
  while ((entry = readdir(handle)) != NULL) {
    uint64_t index = 0;
    uint64_t base_position = 0;
    if (parse_segment_name(entry->d_name, &index, &base_position) != 0) continue;
    if (used == capacity) {
      size_t next_capacity = capacity == 0 ? 8 : capacity * 2;
      hdl_segment *next = realloc(segments, next_capacity * sizeof(*next));
      if (next == NULL) {
        status = HDL_NOMEM;
        break;
      }
      segments = next;
      capacity = next_capacity;
    }
    segments[used++] = (hdl_segment){index, base_position, 0};
  }
  closedir(handle);
  if (status != HDL_OK) {
    free(segments);
    return status;
  }
  if (used > 1) qsort(segments, used, sizeof(*segments), compare_segments);
  *out = segments;
  *count = used;
  return HDL_OK;
}

static uint32_t batch_crc_add(uint32_t state, uint32_t frame_crc) {
  unsigned char value[4];
  put_u32(value, frame_crc);
  return crc32_continue(state, value, sizeof(value));
}

static void encode_frame_header(unsigned char out[HDL_FRAME_HEADER_SIZE],
                                uint16_t type,
                                uint32_t payload_length,
                                uint64_t sequence,
                                uint64_t batch_id,
                                uint64_t stream_id,
                                uint64_t frame_position,
                                uint32_t previous_frame_crc) {
  memset(out, 0, HDL_FRAME_HEADER_SIZE);
  put_u32(out, HDL_FRAME_MAGIC);
  put_u16(out + 4, HDL_FORMAT_VERSION);
  put_u16(out + 6, type);
  put_u32(out + 8, HDL_FRAME_HEADER_SIZE + payload_length);
  put_u32(out + 12, payload_length);
  put_u64(out + 16, sequence);
  put_u64(out + 24, batch_id);
  put_u64(out + 32, stream_id);
  /* The log-global position this frame was written for. It is inside the frame
     CRC deliberately: it is what binds durable bytes to a place in the log, so
     it must be as hard to forge accidentally as the payload itself. */
  put_u64(out + 40, frame_position);
  put_u32(out + 48, previous_frame_crc);
}

static uint32_t finish_frame_header(unsigned char header[HDL_FRAME_HEADER_SIZE],
                                    const unsigned char *payload,
                                    uint32_t payload_length) {
  put_u32(header + 52, 0);
  uint32_t crc = crc32_parts(header, HDL_FRAME_HEADER_SIZE, payload, payload_length);
  put_u32(header + 52, crc);
  return crc;
}

static hdl_status validate_frame(int fd,
                                 uint64_t offset,
                                 uint64_t expected_position,
                                 uint64_t file_size,
                                 uint32_t max_record_bytes,
                                 unsigned char header[HDL_FRAME_HEADER_SIZE],
                                 unsigned char **payload_out,
                                 int *short_tail) {
  *payload_out = NULL;
  *short_tail = 0;
  if (file_size - offset < HDL_FRAME_HEADER_SIZE) {
    *short_tail = 1;
    return HDL_OK;
  }
  if (pread_all(fd, header, HDL_FRAME_HEADER_SIZE, offset) != 0) return HDL_IO;
  uint16_t type = get_u16(header + 6);
  uint32_t payload_length = get_u32(header + 12);
  uint32_t frame_length = get_u32(header + 8);
  if (get_u32(header) != HDL_FRAME_MAGIC ||
      get_u16(header + 4) != HDL_FORMAT_VERSION ||
      (type != HDL_FRAME_DATA && type != HDL_FRAME_COMMIT) ||
      frame_length != HDL_FRAME_HEADER_SIZE + payload_length ||
      (type == HDL_FRAME_DATA && payload_length > max_record_bytes) ||
      (type == HDL_FRAME_COMMIT && payload_length != HDL_COMMIT_PAYLOAD_SIZE)) {
    return HDL_CORRUPTION;
  }
  if ((uint64_t)frame_length > file_size - offset) {
    *short_tail = 1;
    return HDL_OK;
  }
  unsigned char *payload = NULL;
  if (payload_length > 0) {
    payload = malloc(payload_length);
    if (payload == NULL) return HDL_NOMEM;
    if (pread_all(fd, payload, payload_length, offset + HDL_FRAME_HEADER_SIZE) != 0) {
      free(payload);
      return HDL_IO;
    }
  }
  uint32_t stored_crc = get_u32(header + 52);
  put_u32(header + 52, 0);
  uint32_t actual_crc = crc32_parts(header, HDL_FRAME_HEADER_SIZE, payload, payload_length);
  put_u32(header + 52, stored_crc);
  if (stored_crc != actual_crc) {
    free(payload);
    return HDL_CORRUPTION;
  }
  /* A complete, correctly-checksummed frame that names a DIFFERENT position is
     a frame from somewhere else in the log -- the previous life of a recycled
     segment, or a copy spliced in. It is corruption, not a torn tail: it does
     not truncate back to the last commit, it fails closed. */
  if (get_u64(header + 40) != expected_position) {
    free(payload);
    return HDL_CORRUPTION;
  }
  *payload_out = payload;
  return HDL_OK;
}

/* Scans ONE segment, carrying the chain in and out. The frame chain, the
   sequence and the batch numbering do not restart at a segment boundary -- a
   segment is a file, not a fresh log -- so `chain` arrives holding what the
   previous segment ended with and leaves holding what this one ended with. */
static hdl_status scan_segment(int fd,
                               uint64_t base_position,
                               uint32_t max_record_bytes,
                               uint32_t max_batch_records,
                               hdl_scan_callback callback,
                               void *context,
                               int repair_tail,
                               hdl_recovery *chain) {
  struct stat metadata;
  if (fstat(fd, &metadata) != 0 || metadata.st_size < 0) return HDL_IO;
  uint64_t file_size = (uint64_t)metadata.st_size;
  uint64_t stored_base = 0;
  hdl_status status = validate_segment_header(fd, file_size, &stored_base, NULL);
  if (status != HDL_OK) return status;
  /* The name says where this segment sits and so does its header. They must
     agree: a segment whose header names another position is a file that was
     renamed into a place it was not written for. */
  if (stored_base != base_position) return HDL_CORRUPTION;

  uint64_t offset = HDL_SEGMENT_HEADER_SIZE;
  uint64_t committed_offset = HDL_SEGMENT_HEADER_SIZE;
  uint64_t last_sequence = chain->last_sequence;
  uint64_t last_batch_id = chain->last_batch_id;
  uint32_t previous_crc = chain->previous_frame_crc;
  uint32_t committed_previous_crc = chain->previous_frame_crc;
  hdl_pending_frame *pending = NULL;
  size_t pending_count = 0;
  size_t pending_capacity = 0;
  uint64_t pending_batch_id = 0;
  uint32_t batch_crc_state = 0xffffffffu;
  int tail_incomplete = 0;

  while (offset < file_size) {
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    unsigned char *payload = NULL;
    int short_tail = 0;
    status = validate_frame(fd, offset, base_position + offset, file_size,
                            max_record_bytes, header, &payload, &short_tail);
    if (status != HDL_OK) break;
    if (short_tail) {
      tail_incomplete = 1;
      break;
    }
    uint16_t type = get_u16(header + 6);
    uint32_t frame_length = get_u32(header + 8);
    uint32_t frame_crc = get_u32(header + 52);
    uint64_t sequence = get_u64(header + 16);
    uint64_t batch_id = get_u64(header + 24);
    if (get_u32(header + 48) != previous_crc) {
      free(payload);
      status = HDL_CORRUPTION;
      break;
    }

    if (type == HDL_FRAME_DATA) {
      if (batch_id == 0 || sequence != last_sequence + pending_count + 1 ||
          (pending_count > 0 && batch_id != pending_batch_id)) {
        free(payload);
        status = HDL_CORRUPTION;
        break;
      }
      if (pending_count == 0) pending_batch_id = batch_id;
      if (pending_count == pending_capacity) {
        size_t next_capacity = pending_capacity == 0 ? 16 : pending_capacity * 2;
        if (next_capacity > max_batch_records) next_capacity = max_batch_records;
        if (next_capacity <= pending_capacity) {
          free(payload);
          status = HDL_LIMIT;
          break;
        }
        hdl_pending_frame *next = realloc(pending, next_capacity * sizeof(*next));
        if (next == NULL) {
          free(payload);
          status = HDL_NOMEM;
          break;
        }
        pending = next;
        pending_capacity = next_capacity;
      }
      pending[pending_count++] = (hdl_pending_frame){
        offset, sequence, batch_id, get_u64(header + 32), get_u32(header + 12), frame_crc
      };
      batch_crc_state = batch_crc_add(batch_crc_state, frame_crc);
    } else {
      uint64_t first = get_u64(payload);
      uint64_t last = get_u64(payload + 8);
      uint32_t count = get_u32(payload + 16);
      uint32_t batch_crc = get_u32(payload + 20);
      uint32_t expected_batch_crc = ~batch_crc_state;
      if (pending_count == 0 || batch_id != pending_batch_id ||
          count != pending_count || first != pending[0].sequence ||
          last != pending[pending_count - 1].sequence || sequence != last ||
          batch_crc != expected_batch_crc || batch_id != last_batch_id + 1) {
        free(payload);
        status = HDL_CORRUPTION;
        break;
      }
      if (callback != NULL) {
        for (size_t index = 0; index < pending_count; index++) {
          unsigned char *record_payload = NULL;
          if (pending[index].payload_length > 0) {
            record_payload = malloc(pending[index].payload_length);
            if (record_payload == NULL) {
              free(payload);
              status = HDL_NOMEM;
              goto finished;
            }
            if (pread_all(fd, record_payload, pending[index].payload_length,
                          pending[index].offset + HDL_FRAME_HEADER_SIZE) != 0) {
              free(record_payload);
              free(payload);
              status = HDL_IO;
              goto finished;
            }
          }
          int callback_result = callback(context, pending[index].sequence,
                                         pending[index].batch_id,
                                         pending[index].stream_id,
                                         record_payload,
                                         pending[index].payload_length);
          free(record_payload);
          if (callback_result != 0) {
            free(payload);
            status = HDL_INVALID;
            goto finished;
          }
        }
      }
      last_sequence = last;
      last_batch_id = batch_id;
      committed_offset = offset + frame_length;
      committed_previous_crc = frame_crc;
      pending_count = 0;
      pending_batch_id = 0;
      batch_crc_state = 0xffffffffu;
    }
    previous_crc = frame_crc;
    offset += frame_length;
    free(payload);
  }

finished:
  free(pending);
  if (status != HDL_OK) return status;
  if (repair_tail && (tail_incomplete || pending_count > 0 || offset != committed_offset)) {
    if (ftruncate(fd, (off_t)committed_offset) != 0 || sync_data(fd) != 0) return HDL_IO;
  }
  chain->committed_offset = committed_offset;
  chain->last_sequence = last_sequence;
  chain->last_batch_id = last_batch_id;
  chain->previous_frame_crc = committed_previous_crc;
  return HDL_OK;
}

#define HDL_SNAPSHOT_RECEIPT "snapshot.receipt"
#define HDL_RETIREMENT_RECEIPT "retired.receipt"

static hdl_status write_receipt(const char *directory, const char *name, const char *body) {
  char final_path_buffer[4096];
  char temporary_path_buffer[4096];
  char temporary_name[256];
  snprintf(temporary_name, sizeof(temporary_name), "%s.tmp", name);
  if (segment_path(final_path_buffer, sizeof(final_path_buffer), directory, name) != 0 ||
      segment_path(temporary_path_buffer, sizeof(temporary_path_buffer), directory, temporary_name) != 0) {
    return HDL_INVALID;
  }
  (void)unlink(temporary_path_buffer);
  int fd = open(temporary_path_buffer, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
  if (fd < 0) return HDL_IO;
  size_t length = strlen(body);
  if (write_all(fd, (const unsigned char *)body, length) != 0 || sync_data(fd) != 0) {
    close(fd);
    (void)unlink(temporary_path_buffer);
    return HDL_IO;
  }
  close(fd);
  if (rename(temporary_path_buffer, final_path_buffer) != 0) {
    (void)unlink(temporary_path_buffer);
    return HDL_IO;
  }
  return sync_directory(directory) == 0 ? HDL_OK : HDL_IO;
}

static hdl_status read_receipt(const char *directory, const char *name, char *out, size_t size) {
  char path[4096];
  if (segment_path(path, sizeof(path), directory, name) != 0) return HDL_INVALID;
  int fd = open(path, O_RDONLY | O_CLOEXEC);
  if (fd < 0) return errno == ENOENT ? HDL_INVALID : HDL_IO;
  ssize_t got = read(fd, out, size - 1);
  close(fd);
  if (got < 0) return HDL_IO;
  out[got] = '\0';
  return HDL_OK;
}

/* What a retirement records before it destroys anything.

   Once segment 0 can be absent, "the set starts at 0" stops being the rule that
   proves nothing was lost, so the receipt has to carry the whole recovery state
   at the seam: where the log now begins, and the chain the surviving segments
   continue -- the last sequence, the last batch id, and the previous frame's
   CRC. Without those the first surviving frame chains to a frame nobody has,
   and a perfectly good journal reads as corruption. */
typedef struct {
  uint64_t next_index;
  uint64_t next_position;
  uint64_t last_sequence;
  uint64_t last_batch_id;
  uint32_t previous_frame_crc;
  uint32_t digest;
} hdl_retirement;

static void format_retirement_receipt(const hdl_retirement *retirement, char *out, size_t size) {
  char body[512];
  int length = snprintf(body, sizeof(body),
                        "hey_durable_log retirement 1\n"
                        "next %016" PRIx64 " %016" PRIx64 "\n"
                        "chain %016" PRIx64 " %016" PRIx64 " %08" PRIx32 "\n"
                        "snapshot %08" PRIx32 "\n",
                        retirement->next_index, retirement->next_position,
                        retirement->last_sequence, retirement->last_batch_id,
                        retirement->previous_frame_crc, retirement->digest);
  uint32_t crc = crc32_parts((const unsigned char *)body, (size_t)length, NULL, 0);
  snprintf(out, size, "%scrc %08" PRIx32 "\n", body, crc);
}

static hdl_status parse_retirement_receipt(const char *text, hdl_retirement *out) {
  uint32_t stored_crc = 0;
  const char *crc_line = strstr(text, "\ncrc ");
  if (crc_line == NULL) return HDL_CORRUPTION;
  size_t body_length = (size_t)(crc_line - text) + 1;
  if (sscanf(crc_line + 5, "%8" SCNx32, &stored_crc) != 1) return HDL_CORRUPTION;
  if (crc32_parts((const unsigned char *)text, body_length, NULL, 0) != stored_crc) return HDL_CORRUPTION;
  unsigned int version = 0;
  if (sscanf(text,
             "hey_durable_log retirement %u\n"
             "next %16" SCNx64 " %16" SCNx64 "\n"
             "chain %16" SCNx64 " %16" SCNx64 " %8" SCNx32 "\n"
             "snapshot %8" SCNx32 "\n",
             &version, &out->next_index, &out->next_position,
             &out->last_sequence, &out->last_batch_id,
             &out->previous_frame_crc, &out->digest) != 7 || version != 1) {
    return HDL_CORRUPTION;
  }
  return HDL_OK;
}

static hdl_status read_retirement(const char *directory, hdl_retirement *out, int *present) {
  char text[1024];
  *present = 0;
  memset(out, 0, sizeof(*out));
  hdl_status status = read_receipt(directory, HDL_RETIREMENT_RECEIPT, text, sizeof(text));
  if (status == HDL_INVALID) return HDL_OK; /* no retirement has happened */
  if (status != HDL_OK) return status;
  status = parse_retirement_receipt(text, out);
  if (status != HDL_OK) return status;
  *present = 1;
  return HDL_OK;
}

/* Walks the whole published set, in order, as one log.
 *
 * Three set-level invariants are checked here rather than assumed, because each
 * of them, if violated, would replay something other than the log that was
 * acknowledged:
 *
 * - segment 0 is present and the indices are contiguous. A missing segment must
 *   not be replayed as though the log simply skipped from one position to
 *   another, and the only way to be sure the FIRST one is not missing is to
 *   require it. (Retiring a segment will have to state the log's new origin in
 *   a receipt for exactly this reason; nothing retires anything yet.) The
 *   origin's base position is whatever segment 0 says it is.
 * - each segment begins exactly where the previous one ended. That is what makes
 *   a frame's position unique across the whole log rather than only within its
 *   own file, and it is what format v2 binds every frame to.
 * - only the LAST segment may have a tail to repair. Rotation publishes the next
 *   segment at a batch boundary, so nothing ever writes to a segment again once
 *   a later one exists; an unfinished tail in an earlier segment means something
 *   happened that this design does not permit, and it fails closed. */
static hdl_status scan_log(hdl_log *log,
                           hdl_scan_callback callback,
                           void *context,
                           int repair_tail,
                           hdl_recovery *recovery,
                           uint64_t *committed_position,
                           hdl_segment **out_segments,
                           size_t *out_count) {
  hdl_segment *segments = NULL;
  size_t count = 0;
  hdl_status status = list_segments(log->path, &segments, &count);
  if (status != HDL_OK) return status;
  if (count == 0) {
    free(segments);
    return HDL_CORRUPTION;
  }

  hdl_retirement retirement;
  int retired = 0;
  status = read_retirement(log->path, &retirement, &retired);
  if (status != HDL_OK) {
    free(segments);
    return status;
  }

  memset(recovery, 0, sizeof(*recovery));
  size_t first = 0;
  if (retired) {
    /* Segments the receipt says are retired are not part of the log, even if a
       crash between "record the retirement" and "delete the files" left them on
       disk. The receipt is what says where the log begins now, and the chain it
       carries is what lets the first surviving frame be validated at all. */
    while (first < count && segments[first].index < retirement.next_index) first++;
    if (first == count || segments[first].index != retirement.next_index ||
        segments[first].base_position != retirement.next_position) {
      free(segments);
      return HDL_CORRUPTION;
    }
    recovery->last_sequence = retirement.last_sequence;
    recovery->last_batch_id = retirement.last_batch_id;
    recovery->previous_frame_crc = retirement.previous_frame_crc;
  } else if (segments[0].index != 0) {
    free(segments);
    return HDL_CORRUPTION;
  }
  uint64_t expected_base = segments[first].base_position;
  uint64_t expected_index = segments[first].index;
  for (size_t index = first; index < count && status == HDL_OK; index++) {
    if (segments[index].index != expected_index || segments[index].base_position != expected_base) {
      status = HDL_CORRUPTION;
      break;
    }
    expected_index++;
    int last = index + 1 == count;
    int fd = log->fd;
    if (!last) {
      char name[HDL_SEGMENT_NAME_SIZE];
      char path[4096];
      segment_file_name(name, segments[index].index, segments[index].base_position);
      if (segment_path(path, sizeof(path), log->path, name) != 0) {
        status = HDL_INVALID;
        break;
      }
      fd = open(path, O_RDONLY | O_CLOEXEC);
      if (fd < 0) {
        status = HDL_IO;
        break;
      }
    }
    status = scan_segment(fd, segments[index].base_position, log->max_record_bytes,
                          log->max_batch_records, callback, context,
                          last ? repair_tail : 0, recovery);
    if (status == HDL_OK && !last) {
      struct stat metadata;
      if (fstat(fd, &metadata) != 0 || metadata.st_size < 0) status = HDL_IO;
      else if (recovery->committed_offset != (uint64_t)metadata.st_size) status = HDL_CORRUPTION;
    }
    if (!last) close(fd);
    segments[index].end_offset = recovery->committed_offset;
    expected_base += recovery->committed_offset;
  }

  if (status != HDL_OK) {
    free(segments);
    return status;
  }
  if (committed_position != NULL) {
    *committed_position = segments[count - 1].base_position + recovery->committed_offset;
  }
  if (out_segments != NULL) {
    /* Callers walk the LOG, so a retired prefix left on disk is not theirs to
       see: hand back only the surviving set. */
    if (first > 0) memmove(segments, segments + first, (count - first) * sizeof(*segments));
    *out_segments = segments;
    *out_count = count - first;
  } else {
    free(segments);
  }
  return HDL_OK;
}

/* The cut, in etcd's order: build the next segment under a temporary name, sync
   its bytes, rename it into the log, sync the directory -- and only then write
   anything into it. No acknowledgeable payload exists in a segment that is not
   yet published, so a crash anywhere in the sequence leaves either the old set
   or the new one, and both replay the same committed records.

   The caller holds the log mutex and must be at a batch boundary. */
static hdl_status rotate_segment(hdl_log *log) {
  uint64_t next_index = log->segment_index + 1;
  uint64_t next_base = log->base_position + log->append_offset;
  int fd = -1;
  hdl_status status = publish_segment(log->path, next_index, next_base, log->generation, &fd);
  if (status != HDL_OK) return status;
  if (log->fd >= 0) close(log->fd);
  log->fd = fd;
  log->segment_index = next_index;
  log->base_position = next_base;
  log->append_offset = HDL_SEGMENT_HEADER_SIZE;
  return HDL_OK;
}

hdl_status hdl_open(const char *path, const hdl_options *options, hdl_log **out) {
  if (path == NULL || path[0] == '\0' || out == NULL) return HDL_INVALID;
  *out = NULL;
  hdl_log *log = calloc(1, sizeof(*log));
  if (log == NULL) return HDL_NOMEM;
  log->fd = -1;
  log->lock_fd = -1;
  log->path = strdup(path);
  log->max_record_bytes = options != NULL && options->max_record_bytes != 0
                            ? options->max_record_bytes : HDL_DEFAULT_MAX_RECORD_BYTES;
  log->max_batch_records = options != NULL && options->max_batch_records != 0
                              ? options->max_batch_records : HDL_DEFAULT_MAX_BATCH_RECORDS;
  log->segment_size_bytes = options != NULL && options->segment_size_bytes != 0
                              ? options->segment_size_bytes : HDL_DEFAULT_SEGMENT_SIZE_BYTES;
  log->generation = options == NULL ? 1 : options->generation;
  if (log->path == NULL || pthread_mutex_init(&log->mutex, NULL) != 0) {
    free(log->path);
    free(log);
    return HDL_NOMEM;
  }

  /* A journal is a directory. A path that already holds something else is not
     one, and is refused rather than reinterpreted -- including a single-file
     journal written by an earlier version of this package. */
  struct stat directory_metadata;
  if (stat(path, &directory_metadata) == 0) {
    if (!S_ISDIR(directory_metadata.st_mode)) {
      hdl_close(log);
      return HDL_INVALID;
    }
  } else if (errno != ENOENT) {
    hdl_close(log);
    return HDL_IO;
  } else if (mkdir(path, 0700) != 0 || sync_parent_directory(path) != 0) {
    hdl_close(log);
    return HDL_IO;
  }

  /* Ownership BEFORE recovery, not before the first write: recovery truncates
     an uncommitted tail, so a second opener that got this far would destroy work
     the first owner is still doing before anyone noticed it was not alone. */
  {
    char lock_path[4096];
    if (segment_path(lock_path, sizeof(lock_path), path, HDL_WRITER_LOCK) != 0) {
      hdl_close(log);
      return HDL_INVALID;
    }
    log->lock_fd = open(lock_path, O_RDWR | O_CREAT | O_CLOEXEC, 0600);
    if (log->lock_fd < 0) {
      hdl_close(log);
      return HDL_IO;
    }
    if (flock(log->lock_fd, LOCK_EX | LOCK_NB) != 0) {
      hdl_status refusal = (errno == EWOULDBLOCK || errno == EAGAIN) ? HDL_LOCKED : HDL_IO;
      hdl_close(log);
      return refusal;
    }
  }

  hdl_segment *segments = NULL;
  size_t segment_count = 0;
  hdl_status status = list_segments(path, &segments, &segment_count);
  if (status != HDL_OK) {
    hdl_close(log);
    return status;
  }

  char name[HDL_SEGMENT_NAME_SIZE];
  char active_path[4096];
  if (segment_count == 0) {
    log->segment_index = 0;
    log->base_position = options == NULL ? 0 : options->base_position;
    status = publish_segment(path, log->segment_index, log->base_position,
                             log->generation, &log->fd);
    if (status != HDL_OK) {
      free(segments);
      hdl_close(log);
      return status;
    }
  } else {
    log->segment_index = segments[segment_count - 1].index;
    log->base_position = segments[segment_count - 1].base_position;
    segment_file_name(name, log->segment_index, log->base_position);
    if (segment_path(active_path, sizeof(active_path), path, name) != 0) {
      free(segments);
      hdl_close(log);
      return HDL_INVALID;
    }
    log->fd = open(active_path, O_RDWR | O_CLOEXEC | O_APPEND);
    if (log->fd < 0) {
      free(segments);
      hdl_close(log);
      return HDL_IO;
    }
    uint64_t stored_base = 0;
    uint64_t stored_generation = 0;
    struct stat active_metadata;
    if (fstat(log->fd, &active_metadata) != 0 || active_metadata.st_size < 0) {
      free(segments);
      hdl_close(log);
      return HDL_IO;
    }
    hdl_status header_status = validate_segment_header(log->fd, (uint64_t)active_metadata.st_size,
                                                       &stored_base, &stored_generation);
    if (header_status != HDL_OK) {
      free(segments);
      hdl_close(log);
      return header_status;
    }
    log->generation = stored_generation;
  }
  free(segments);

  hdl_recovery recovery;
  status = scan_log(log, NULL, NULL, 1, &recovery, NULL, NULL, NULL);
  if (status != HDL_OK) {
    hdl_close(log);
    return status;
  }
  log->append_offset = recovery.committed_offset;
  log->next_sequence = recovery.last_sequence + 1;
  log->next_batch_id = recovery.last_batch_id + 1;
  log->previous_frame_crc = recovery.previous_frame_crc;
  if (lseek(log->fd, (off_t)log->append_offset, SEEK_SET) < 0) {
    hdl_close(log);
    return HDL_IO;
  }
  *out = log;
  return HDL_OK;
}

hdl_status hdl_append_batch(hdl_log *log,
                            const hdl_record *records,
                            size_t count,
                            hdl_receipt *receipt) {
  if (log == NULL || records == NULL || count == 0 || count > log->max_batch_records) return HDL_INVALID;
  for (size_t index = 0; index < count; index++) {
    if ((records[index].payload_length > 0 && records[index].payload == NULL) ||
        records[index].payload_length > log->max_record_bytes) return HDL_INVALID;
  }
  pthread_mutex_lock(&log->mutex);
  if (log->poisoned) {
    pthread_mutex_unlock(&log->mutex);
    return HDL_POISONED;
  }
  /* Cut before the batch, never inside one. A segment that has reached its
     size is closed and the next one published while nothing is half-written, so
     the boundary always falls between two batches. A batch bigger than the
     segment size therefore produces an oversized segment rather than a split
     one -- etcd makes the same trade for the same reason. */
  if (log->append_offset > HDL_SEGMENT_HEADER_SIZE &&
      log->append_offset >= log->segment_size_bytes) {
    hdl_status rotation = rotate_segment(log);
    if (rotation != HDL_OK) {
      pthread_mutex_unlock(&log->mutex);
      return rotation;
    }
  }

  uint64_t batch_id = log->next_batch_id;
  uint64_t first_sequence = log->next_sequence;
  uint64_t sequence = first_sequence;
  uint64_t start_offset = log->append_offset;
  uint64_t offset = start_offset;
  uint32_t previous_crc = log->previous_frame_crc;
  uint32_t batch_crc_state = 0xffffffffu;
  hdl_status status = HDL_OK;
  int barrier_failed = 0;

  for (size_t index = 0; index < count; index++, sequence++) {
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    const unsigned char *payload = records[index].payload;
    encode_frame_header(header, HDL_FRAME_DATA, records[index].payload_length,
                        sequence, batch_id, records[index].stream_id,
                        log->base_position + offset, previous_crc);
    uint32_t frame_crc = finish_frame_header(header, payload, records[index].payload_length);
    if (write_all(log->fd, header, sizeof(header)) != 0 ||
        write_all(log->fd, payload, records[index].payload_length) != 0) {
      status = HDL_IO;
      break;
    }
    batch_crc_state = batch_crc_add(batch_crc_state, frame_crc);
    previous_crc = frame_crc;
    offset += sizeof(header) + records[index].payload_length;
  }

  uint64_t last_sequence = first_sequence + count - 1;
  if (status == HDL_OK) {
    unsigned char payload[HDL_COMMIT_PAYLOAD_SIZE];
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    put_u64(payload, first_sequence);
    put_u64(payload + 8, last_sequence);
    put_u32(payload + 16, (uint32_t)count);
    put_u32(payload + 20, ~batch_crc_state);
    encode_frame_header(header, HDL_FRAME_COMMIT, sizeof(payload), last_sequence,
                        batch_id, 0, log->base_position + offset, previous_crc);
    uint32_t frame_crc = finish_frame_header(header, payload, sizeof(payload));
    if (write_all(log->fd, header, sizeof(header)) != 0 ||
        write_all(log->fd, payload, sizeof(payload)) != 0) {
      status = HDL_IO;
    } else if (sync_data(log->fd) != 0) {
      /* The barrier itself failed. From here this descriptor cannot be trusted
         to report durability, so the handle stops acknowledging entirely. A
         failed WRITE is different and deliberately does not land here: the
         bytes did not all reach the file, and the rollback below returns it to
         a state we still know. */
      status = HDL_IO;
      barrier_failed = 1;
    } else {
      previous_crc = frame_crc;
      offset += sizeof(header) + sizeof(payload);
    }
  }

  if (status == HDL_OK) {
    log->append_offset = offset;
    log->next_sequence = last_sequence + 1;
    log->next_batch_id = batch_id + 1;
    log->previous_frame_crc = previous_crc;
    if (receipt != NULL) {
      receipt->batch_id = batch_id;
      receipt->first_sequence = first_sequence;
      receipt->last_sequence = last_sequence;
      /* Log-global, so it is a position a reader can resume from rather than
         an offset that means something different in every segment. */
      receipt->durable_offset = log->base_position + offset;
    }
  } else {
    /* Roll the failed batch back. If the rollback's own barrier fails we cannot
       even prove the file is back where it started, which poisons the handle
       for the same reason. */
    if (ftruncate(log->fd, (off_t)start_offset) != 0) {
      status = HDL_IO;
      barrier_failed = 1;
    } else if (sync_data(log->fd) != 0) {
      status = HDL_IO;
      barrier_failed = 1;
    }
    (void)lseek(log->fd, (off_t)start_offset, SEEK_SET);
    if (barrier_failed) log->poisoned = 1;
  }
  pthread_mutex_unlock(&log->mutex);
  return status;
}

/* The last sequence this log has committed. A follower in a replicated set has
   to know this to answer "is the record you are sending me the one that comes
   next", and it must be O(1): asking by replaying would make every accepted
   record cost a scan of the log. */
hdl_status hdl_last_sequence(hdl_log *log, uint64_t *out) {
  if (log == NULL || out == NULL) return HDL_INVALID;
  pthread_mutex_lock(&log->mutex);
  *out = log->next_sequence - 1;
  pthread_mutex_unlock(&log->mutex);
  return HDL_OK;
}

hdl_status hdl_scan(hdl_log *log, hdl_scan_callback callback, void *context) {
  if (log == NULL) return HDL_INVALID;
  pthread_mutex_lock(&log->mutex);
  hdl_recovery recovery;
  hdl_status status = scan_log(log, callback, context, 0, &recovery, NULL, NULL, NULL);
  pthread_mutex_unlock(&log->mutex);
  return status;
}

static hdl_status cursor_open_current_segment(hdl_cursor *cursor);

/* The committed boundary and the surviving segment set, taken from the open
   handle rather than re-derived from the bytes. Costs one readdir and one stat
   per segment; the previous full scan cost the whole log. */
static hdl_status cursor_take_boundary(hdl_log *log, hdl_cursor *cursor) {
  hdl_retirement retirement;
  int retired = 0;
  hdl_status status = read_retirement(log->path, &retirement, &retired);
  if (status != HDL_OK) return status;

  hdl_segment *segments = NULL;
  size_t count = 0;
  status = list_segments(log->path, &segments, &count);
  if (status != HDL_OK) return status;
  if (count == 0) {
    free(segments);
    return HDL_CORRUPTION;
  }

  size_t first = 0;
  if (retired) {
    while (first < count && segments[first].index < retirement.next_index) first++;
    if (first == count) {
      free(segments);
      return HDL_CORRUPTION;
    }
  }
  for (size_t index = first; index < count; index++) {
    if (segments[index].index == log->segment_index) {
      /* The active segment ends where this handle's committed tail is. */
      segments[index].end_offset = log->append_offset;
      continue;
    }
    char name[HDL_SEGMENT_NAME_SIZE];
    char path[4096];
    struct stat metadata;
    segment_file_name(name, segments[index].index, segments[index].base_position);
    if (segment_path(path, sizeof(path), log->path, name) != 0 ||
        stat(path, &metadata) != 0 || metadata.st_size < 0) {
      free(segments);
      return HDL_IO;
    }
    /* A complete segment ends exactly on a commit boundary; scan_log checks
       that on every open, so a cursor may rely on it. */
    segments[index].end_offset = (uint64_t)metadata.st_size;
  }
  if (first > 0) memmove(segments, segments + first, (count - first) * sizeof(*segments));
  cursor->segments = segments;
  cursor->segment_count = count - first;
  cursor->committed_position = log->base_position + log->append_offset;
  return HDL_OK;
}


/* Place a cursor at `position`, or refuse. Nothing here scans forward looking
   for a plausible frame: a position that is not a boundary is a caller error or
   a corrupted bookmark, and resynchronising would hand back a record that was
   never written at that place. */
static hdl_status position_a_cursor(hdl_cursor *cursor, uint64_t position) {
  if (cursor->segment_count == 0) return HDL_CORRUPTION;
  if (position < cursor->segments[0].base_position) return HDL_RETIRED;
  if (position > cursor->committed_position) return HDL_INVALID;
  if (position == cursor->committed_position) {
    /* Caught up. An empty cursor, not an error. */
    cursor->current = cursor->segment_count;
    return HDL_OK;
  }
  for (size_t index = 0; index < cursor->segment_count; index++) {
    const hdl_segment *segment = &cursor->segments[index];
    if (position < segment->base_position + segment->end_offset) {
      uint64_t offset = position - segment->base_position;
      if (offset < HDL_SEGMENT_HEADER_SIZE) return HDL_INVALID;
      cursor->current = index;
      cursor->offset = offset;
      /* It must name a frame boundary, and the frame there must be the one that
         belongs at that position -- which format v2 makes checkable. */
      hdl_status opened = cursor_open_current_segment(cursor);
      if (opened != HDL_OK) return opened;
      unsigned char header[HDL_FRAME_HEADER_SIZE];
      unsigned char *payload = NULL;
      int short_tail = 0;
      hdl_status status = validate_frame(cursor->fd, offset, position, segment->end_offset,
                                         cursor->max_record_bytes, header, &payload, &short_tail);
      free(payload);
      if (status != HDL_OK || short_tail) return HDL_INVALID;
      return HDL_OK;
    }
  }
  return HDL_INVALID;
}

hdl_status hdl_cursor_open(hdl_log *log, hdl_cursor **out) {
  return hdl_cursor_open_at(log, 0, out);
}

/* Resume at a log-global position.
 *
 * The position is resolved by arithmetic rather than by scanning: format v2
 * stamps every frame with the position it was written for, and a segment's base
 * position is in its name, so the segment holding a position and the offset
 * within it are both computed directly. A reader that has applied a million
 * records pays the same to resume as one that has applied none, which is the
 * whole point -- see docs/BENCHMARK-2026-09-04-replay-lag.md for what it costs
 * when it is not true. */
hdl_status hdl_cursor_open_at(hdl_log *log, uint64_t position, hdl_cursor **out) {
  if (log == NULL || out == NULL) return HDL_INVALID;
  *out = NULL;
  hdl_cursor *cursor = calloc(1, sizeof(*cursor));
  if (cursor == NULL) return HDL_NOMEM;
  cursor->fd = -1;

  pthread_mutex_lock(&log->mutex);
  /* The boundary comes from the handle that WROTE it, not from re-reading the
     whole log.
     
     Opening a cursor used to run a full validating scan, which made every open
     cost O(log length) -- so a materializer that drains, closes and opens
     another cursor paid to re-validate everything on every pass, and resuming
     did not help because the cost was in the open. This handle holds an
     exclusive writer lock, so nothing else can have moved the committed tail
     since it last wrote; and every frame is still validated when the cursor
     READS it, so a corrupt frame is caught exactly as before. What is dropped
     is re-deriving a boundary we already know. */
  hdl_status status = cursor_take_boundary(log, cursor);
  if (status == HDL_OK) {
    cursor->directory = strdup(log->path);
    if (cursor->directory == NULL) status = HDL_NOMEM;
  }
  if (status == HDL_OK) {
    cursor->current = 0;
    cursor->offset = HDL_SEGMENT_HEADER_SIZE;
    cursor->max_record_bytes = log->max_record_bytes;
    if (position != 0) {
      status = position_a_cursor(cursor, position);
    }
  }
  pthread_mutex_unlock(&log->mutex);

  if (status != HDL_OK) {
    free(cursor->segments);
    free(cursor->directory);
    free(cursor);
    return status;
  }
  *out = cursor;
  return HDL_OK;
}

static hdl_status cursor_open_current_segment(hdl_cursor *cursor) {
  char name[HDL_SEGMENT_NAME_SIZE];
  char path[4096];
  segment_file_name(name, cursor->segments[cursor->current].index,
                    cursor->segments[cursor->current].base_position);
  if (segment_path(path, sizeof(path), cursor->directory, name) != 0) return HDL_INVALID;
  cursor->fd = open(path, O_RDONLY | O_CLOEXEC);
  return cursor->fd < 0 ? HDL_IO : HDL_OK;
}

hdl_status hdl_cursor_next(hdl_cursor *cursor, hdl_cursor_record *out) {
  if (cursor == NULL || out == NULL) return HDL_INVALID;
  free(cursor->payload);
  cursor->payload = NULL;
  memset(out, 0, sizeof(*out));

  while (cursor->current < cursor->segment_count) {
    const hdl_segment *segment = &cursor->segments[cursor->current];
    if (cursor->offset >= segment->end_offset ||
        segment->base_position + cursor->offset >= cursor->committed_position) {
      /* A segment boundary is invisible to the record stream: step over it and
         keep reading the same log. */
      if (cursor->fd >= 0) {
        close(cursor->fd);
        cursor->fd = -1;
      }
      cursor->current++;
      cursor->offset = HDL_SEGMENT_HEADER_SIZE;
      continue;
    }
    if (cursor->fd < 0) {
      hdl_status opened = cursor_open_current_segment(cursor);
      if (opened != HDL_OK) return opened;
    }

    unsigned char header[HDL_FRAME_HEADER_SIZE];
    unsigned char *payload = NULL;
    int short_tail = 0;
    hdl_status status = validate_frame(cursor->fd, cursor->offset,
                                       segment->base_position + cursor->offset,
                                       segment->end_offset,
                                       cursor->max_record_bytes,
                                       header, &payload, &short_tail);
    if (status != HDL_OK) return status;
    if (short_tail) return HDL_CORRUPTION;
    cursor->offset += get_u32(header + 8);
    if (get_u16(header + 6) == HDL_FRAME_COMMIT) {
      free(payload);
      continue;
    }
    cursor->payload = payload;
    out->sequence = get_u64(header + 16);
    out->batch_id = get_u64(header + 24);
    out->stream_id = get_u64(header + 32);
    out->payload = cursor->payload;
    out->payload_length = get_u32(header + 12);
    out->position = get_u64(header + 40);
    out->next_position = segment->base_position + cursor->offset;
    return HDL_OK;
  }
  return HDL_DONE;
}

hdl_status hdl_cursor_close(hdl_cursor *cursor) {
  if (cursor == NULL) return HDL_INVALID;
  hdl_status status = HDL_OK;
  if (cursor->fd >= 0 && close(cursor->fd) != 0) status = HDL_IO;
  free(cursor->payload);
  free(cursor->segments);
  free(cursor->directory);
  free(cursor);
  return status;
}

hdl_status hdl_close(hdl_log *log) {
  if (log == NULL) return HDL_INVALID;
  hdl_status status = HDL_OK;
  if (log->fd >= 0 && close(log->fd) != 0) status = HDL_IO;
  /* Closing the descriptor releases the flock; the journal is available again
     the moment its owner lets go, and the kernel does the same on a crash. */
  if (log->lock_fd >= 0 && close(log->lock_fd) != 0) status = HDL_IO;
  pthread_mutex_destroy(&log->mutex);
  free(log->path);
  free(log);
  return status;
}

/* ---------------------------------------------------------------------------
   Snapshots, restores, and the one operation that destroys data.

   A snapshot is just a journal: the same segment files under the same names,
   in a directory of their own, plus a receipt. That is deliberate. It means a
   snapshot is validated by exactly the code that validates a journal -- every
   frame CRC, the chain, the positions, the set rules -- rather than by a second
   reader written for the occasion, which is where a divergence would hide.
   --------------------------------------------------------------------------- */

typedef struct {
  uint32_t crc;
  uint64_t records;
  uint64_t first_sequence;
  uint64_t last_sequence;
} hdl_digest_state;

/* The digest is a statement about the RECORD STREAM a consumer replays --
   sequence, stream and payload -- not about how those records were batched.
   Two journals with the same digest hand a materializer the same work. */
static int digest_record(void *context,
                         uint64_t sequence,
                         uint64_t batch_id,
                         uint64_t stream_id,
                         const void *payload,
                         uint32_t payload_length) {
  hdl_digest_state *state = context;
  unsigned char scalars[16];
  (void)batch_id;
  put_u64(scalars, sequence);
  put_u64(scalars + 8, stream_id);
  state->crc = crc32_continue(state->crc, scalars, sizeof(scalars));
  if (payload_length > 0) {
    state->crc = crc32_continue(state->crc, payload, payload_length);
  }
  if (state->records == 0) state->first_sequence = sequence;
  state->last_sequence = sequence;
  state->records++;
  return 0;
}

/* Read a directory back AS A JOURNAL and describe what it replays. */
static hdl_status describe_journal(const char *directory, hdl_snapshot *out) {
  hdl_log *log = NULL;
  hdl_status status = hdl_open(directory, NULL, &log);
  if (status != HDL_OK) return status;
  hdl_digest_state state = {0xffffffffu, 0, 0, 0};
  status = hdl_scan(log, digest_record, &state);
  if (status == HDL_OK) {
    hdl_segment *segments = NULL;
    size_t count = 0;
    hdl_recovery recovery;
    uint64_t committed_position = 0;
    status = scan_log(log, NULL, NULL, 0, &recovery, &committed_position, &segments, &count);
    if (status == HDL_OK) {
      out->first_index = segments[0].index;
      out->last_index = segments[count - 1].index;
      out->first_position = segments[0].base_position;
      out->end_position = committed_position;
      out->first_sequence = state.first_sequence;
      out->last_sequence = state.last_sequence;
      out->records = state.records;
      out->digest = ~state.crc;
      free(segments);
    }
  }
  hdl_status closed = hdl_close(log);
  return status != HDL_OK ? status : closed;
}

/* Fixed-width hex and no timestamp, so the same committed prefix produces the
   same bytes every time: two operators can compare receipts instead of
   journals, and a receipt that changed means the prefix changed. */
static void format_snapshot_receipt(const hdl_snapshot *snapshot, char *out, size_t size) {
  char body[512];
  int length = snprintf(body, sizeof(body),
                        "hey_durable_log snapshot 1\n"
                        "segments %016" PRIx64 " %016" PRIx64 "\n"
                        "positions %016" PRIx64 " %016" PRIx64 "\n"
                        "sequences %016" PRIx64 " %016" PRIx64 "\n"
                        "records %016" PRIx64 "\n"
                        "digest %08" PRIx32 "\n",
                        snapshot->first_index, snapshot->last_index,
                        snapshot->first_position, snapshot->end_position,
                        snapshot->first_sequence, snapshot->last_sequence,
                        snapshot->records, snapshot->digest);
  uint32_t crc = crc32_parts((const unsigned char *)body, (size_t)length, NULL, 0);
  snprintf(out, size, "%scrc %08" PRIx32 "\n", body, crc);
}

static hdl_status parse_snapshot_receipt(const char *text, hdl_snapshot *out) {
  uint32_t stored_crc = 0;
  const char *crc_line = strstr(text, "\ncrc ");
  if (crc_line == NULL) return HDL_CORRUPTION;
  size_t body_length = (size_t)(crc_line - text) + 1;
  if (sscanf(crc_line + 5, "%8" SCNx32, &stored_crc) != 1) return HDL_CORRUPTION;
  if (crc32_parts((const unsigned char *)text, body_length, NULL, 0) != stored_crc) return HDL_CORRUPTION;
  unsigned int version = 0;
  if (sscanf(text,
             "hey_durable_log snapshot %u\n"
             "segments %16" SCNx64 " %16" SCNx64 "\n"
             "positions %16" SCNx64 " %16" SCNx64 "\n"
             "sequences %16" SCNx64 " %16" SCNx64 "\n"
             "records %16" SCNx64 "\n"
             "digest %8" SCNx32 "\n",
             &version, &out->first_index, &out->last_index,
             &out->first_position, &out->end_position,
             &out->first_sequence, &out->last_sequence,
             &out->records, &out->digest) != 9 || version != 1) {
    return HDL_CORRUPTION;
  }
  return HDL_OK;
}

static int snapshots_agree(const hdl_snapshot *left, const hdl_snapshot *right) {
  return left->first_index == right->first_index && left->last_index == right->last_index &&
         left->first_position == right->first_position && left->end_position == right->end_position &&
         left->first_sequence == right->first_sequence && left->last_sequence == right->last_sequence &&
         left->records == right->records && left->digest == right->digest;
}

static hdl_status copy_segment(const char *from_directory,
                               const char *to_directory,
                               uint64_t index,
                               uint64_t base_position) {
  char name[HDL_SEGMENT_NAME_SIZE];
  char temporary_name[HDL_SEGMENT_NAME_SIZE + 8];
  char source[4096];
  char target[4096];
  char temporary[4096];
  segment_file_name(name, index, base_position);
  snprintf(temporary_name, sizeof(temporary_name), "%s.tmp", name);
  if (segment_path(source, sizeof(source), from_directory, name) != 0 ||
      segment_path(target, sizeof(target), to_directory, name) != 0 ||
      segment_path(temporary, sizeof(temporary), to_directory, temporary_name) != 0) {
    return HDL_INVALID;
  }

  int input = open(source, O_RDONLY | O_CLOEXEC);
  if (input < 0) return HDL_IO;
  (void)unlink(temporary);
  int output = open(temporary, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
  if (output < 0) {
    close(input);
    return HDL_IO;
  }
  unsigned char buffer[65536];
  hdl_status status = HDL_OK;
  for (;;) {
    ssize_t got = read(input, buffer, sizeof(buffer));
    if (got == 0) break;
    if (got < 0) {
      if (errno == EINTR) continue;
      status = HDL_IO;
      break;
    }
    if (write_all(output, buffer, (size_t)got) != 0) {
      status = HDL_IO;
      break;
    }
  }
  if (status == HDL_OK && sync_data(output) != 0) status = HDL_IO;
  close(input);
  close(output);
  if (status != HDL_OK) {
    (void)unlink(temporary);
    return status;
  }
  /* Same publication rule as a segment cut: it exists when it is renamed, and
     not before. A crash mid-copy leaves a .tmp that no reader can see. */
  if (rename(temporary, target) != 0) {
    (void)unlink(temporary);
    return HDL_IO;
  }
  if (sync_directory(to_directory) != 0) return HDL_IO;
  snapshot_checkpoint();
  return HDL_OK;
}

hdl_status hdl_snapshot_create(hdl_log *log, const char *snapshot_directory, hdl_snapshot *out) {
  if (log == NULL || snapshot_directory == NULL || out == NULL) return HDL_INVALID;
  memset(out, 0, sizeof(*out));

  /* Only COMPLETE segments are snapshotted. The active segment is still being
     appended to, so copying it would capture a prefix that is already stale by
     the time the copy finishes -- and a snapshot exists to be retired against,
     which the active segment can never be. Earlier segments are immutable, so
     no lock is needed to copy them. */
  hdl_segment *segments = NULL;
  size_t count = 0;
  hdl_status status = list_segments(log->path, &segments, &count);
  if (status != HDL_OK) return status;
  if (count < 2) {
    free(segments);
    return HDL_INVALID;
  }

  if (mkdir(snapshot_directory, 0700) != 0) {
    free(segments);
    return errno == EEXIST ? HDL_INVALID : HDL_IO;
  }
  if (sync_parent_directory(snapshot_directory) != 0) {
    free(segments);
    return HDL_IO;
  }

  for (size_t index = 0; index + 1 < count && status == HDL_OK; index++) {
    status = copy_segment(log->path, snapshot_directory, segments[index].index,
                          segments[index].base_position);
  }
  free(segments);
  if (status != HDL_OK) return status;

  /* Verify by reading the copy back as a journal -- every frame, every chain
     link, every position -- rather than trusting the bytes we just wrote. */
  status = describe_journal(snapshot_directory, out);
  if (status != HDL_OK) return status;

  char receipt[1024];
  format_snapshot_receipt(out, receipt, sizeof(receipt));
  return write_receipt(snapshot_directory, HDL_SNAPSHOT_RECEIPT, receipt);
}

hdl_status hdl_snapshot_verify(const char *snapshot_directory, hdl_snapshot *out) {
  if (snapshot_directory == NULL) return HDL_INVALID;
  char text[1024];
  hdl_status status = read_receipt(snapshot_directory, HDL_SNAPSHOT_RECEIPT, text, sizeof(text));
  if (status != HDL_OK) return status;
  hdl_snapshot claimed;
  memset(&claimed, 0, sizeof(claimed));
  status = parse_snapshot_receipt(text, &claimed);
  if (status != HDL_OK) return status;

  hdl_snapshot actual;
  memset(&actual, 0, sizeof(actual));
  status = describe_journal(snapshot_directory, &actual);
  if (status != HDL_OK) return status;
  /* Restored and compared. A receipt that describes a different record stream
     than the snapshot actually replays is a snapshot that must not satisfy a
     retirement. */
  if (!snapshots_agree(&claimed, &actual)) return HDL_CORRUPTION;
  if (out != NULL) *out = actual;
  return HDL_OK;
}

hdl_status hdl_snapshot_restore(const char *snapshot_directory, const char *journal_directory) {
  if (snapshot_directory == NULL || journal_directory == NULL) return HDL_INVALID;
  hdl_snapshot verified;
  hdl_status status = hdl_snapshot_verify(snapshot_directory, &verified);
  if (status != HDL_OK) return status;

  if (mkdir(journal_directory, 0700) != 0) return errno == EEXIST ? HDL_INVALID : HDL_IO;
  if (sync_parent_directory(journal_directory) != 0) return HDL_IO;

  hdl_segment *segments = NULL;
  size_t count = 0;
  status = list_segments(snapshot_directory, &segments, &count);
  if (status != HDL_OK) return status;
  for (size_t index = 0; index < count && status == HDL_OK; index++) {
    status = copy_segment(snapshot_directory, journal_directory, segments[index].index,
                          segments[index].base_position);
  }
  free(segments);
  if (status != HDL_OK) return status;

  /* A restore that does not replay what the snapshot promised is not a restore. */
  hdl_snapshot restored;
  memset(&restored, 0, sizeof(restored));
  status = describe_journal(journal_directory, &restored);
  if (status != HDL_OK) return status;
  return snapshots_agree(&verified, &restored) ? HDL_OK : HDL_CORRUPTION;
}

/* Retire the segments a verified snapshot covers.
 *
 * The order is the whole safety argument. Verify the snapshot by reading it
 * back; prove it is a prefix of THIS log, ending exactly where the surviving
 * segments begin and chaining into their first frame; record the retirement,
 * durably, BEFORE anything is deleted; only then delete. A crash between the
 * receipt and the deletion leaves segments recovery has been told to ignore --
 * harmless. A crash the other way round would leave a log whose beginning
 * nothing describes, which is exactly the state this receipt exists to prevent. */
hdl_status hdl_retire_snapshotted(hdl_log *log, const char *snapshot_directory) {
  if (log == NULL || snapshot_directory == NULL) return HDL_INVALID;

  hdl_snapshot verified;
  memset(&verified, 0, sizeof(verified));
  hdl_status status = hdl_snapshot_verify(snapshot_directory, &verified);
  if (status != HDL_OK) return status;

  /* The chain the surviving segments will have to continue, taken from the
     snapshot itself rather than from the journal we are about to cut. */
  hdl_log *snapshot_log = NULL;
  status = hdl_open(snapshot_directory, NULL, &snapshot_log);
  if (status != HDL_OK) return status;
  hdl_recovery boundary;
  uint64_t snapshot_end = 0;
  status = scan_log(snapshot_log, NULL, NULL, 0, &boundary, &snapshot_end, NULL, NULL);
  hdl_status closed = hdl_close(snapshot_log);
  if (status != HDL_OK) return status;
  if (closed != HDL_OK) return closed;

  pthread_mutex_lock(&log->mutex);

  hdl_retirement previous;
  int already_retired = 0;
  status = read_retirement(log->path, &previous, &already_retired);
  if (status != HDL_OK) {
    pthread_mutex_unlock(&log->mutex);
    return status;
  }
  uint64_t origin_index = already_retired ? previous.next_index : 0;

  hdl_segment *segments = NULL;
  size_t count = 0;
  status = list_segments(log->path, &segments, &count);
  if (status != HDL_OK) {
    pthread_mutex_unlock(&log->mutex);
    return status;
  }

  /* It must be a snapshot of THIS log's current beginning, and it must stop
     before the segment still being appended to. */
  if (verified.first_index != origin_index || verified.last_index >= log->segment_index) {
    free(segments);
    pthread_mutex_unlock(&log->mutex);
    return HDL_INVALID;
  }

  /* The segment that will become the first surviving one must begin exactly
     where the snapshot ends, and its first frame must chain to the snapshot's
     last. A snapshot of some other log that happens to cover the right indices
     fails here, before anything is destroyed, rather than turning the journal
     into corruption on its next open. */
  uint64_t next_index = verified.last_index + 1;
  size_t next = 0;
  while (next < count && segments[next].index != next_index) next++;
  if (next == count || segments[next].base_position != verified.end_position ||
      verified.end_position != snapshot_end) {
    free(segments);
    pthread_mutex_unlock(&log->mutex);
    return HDL_INVALID;
  }
  {
    char name[HDL_SEGMENT_NAME_SIZE];
    char path[4096];
    unsigned char header[HDL_FRAME_HEADER_SIZE];
    segment_file_name(name, segments[next].index, segments[next].base_position);
    if (segment_path(path, sizeof(path), log->path, name) != 0) {
      free(segments);
      pthread_mutex_unlock(&log->mutex);
      return HDL_INVALID;
    }
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) {
      free(segments);
      pthread_mutex_unlock(&log->mutex);
      return HDL_IO;
    }
    int read_ok = pread_all(fd, header, sizeof(header), HDL_SEGMENT_HEADER_SIZE) == 0;
    close(fd);
    if (read_ok &&
        (get_u32(header + 48) != boundary.previous_frame_crc ||
         get_u64(header + 16) != boundary.last_sequence + 1)) {
      free(segments);
      pthread_mutex_unlock(&log->mutex);
      return HDL_INVALID;
    }
  }

  hdl_retirement retirement = {next_index, verified.end_position, boundary.last_sequence,
                               boundary.last_batch_id, boundary.previous_frame_crc,
                               verified.digest};
  char receipt[1024];
  format_retirement_receipt(&retirement, receipt, sizeof(receipt));
  status = write_receipt(log->path, HDL_RETIREMENT_RECEIPT, receipt);
  if (status != HDL_OK) {
    free(segments);
    pthread_mutex_unlock(&log->mutex);
    return status;
  }

  for (size_t index = 0; index < count; index++) {
    if (segments[index].index >= next_index) continue;
    char name[HDL_SEGMENT_NAME_SIZE];
    char path[4096];
    segment_file_name(name, segments[index].index, segments[index].base_position);
    if (segment_path(path, sizeof(path), log->path, name) != 0) continue;
    if (unlink(path) != 0 && errno != ENOENT) status = HDL_IO;
  }
  free(segments);
  if (status == HDL_OK && sync_directory(log->path) != 0) status = HDL_IO;
  pthread_mutex_unlock(&log->mutex);
  return status;
}

static void *broker_writer(void *opaque) {
  hdl_broker *broker = opaque;
  hdl_request **requests = calloc(broker->max_batch_records, sizeof(*requests));
  hdl_record *records = calloc(broker->max_batch_records, sizeof(*records));
  if (requests == NULL || records == NULL) {
    free(requests);
    free(records);
    pthread_mutex_lock(&broker->mutex);
    broker->stopping = 1;
    for (hdl_request *request = broker->head; request != NULL; request = request->next) {
      request->status = HDL_NOMEM;
      request->done = 1;
      pthread_cond_signal(&request->completed);
    }
    pthread_cond_broadcast(&broker->not_full);
    pthread_mutex_unlock(&broker->mutex);
    return NULL;
  }

  for (;;) {
    pthread_mutex_lock(&broker->mutex);
    while (broker->head == NULL && !broker->stopping) {
      pthread_cond_wait(&broker->not_empty, &broker->mutex);
    }
    if (broker->head == NULL && broker->stopping) {
      pthread_mutex_unlock(&broker->mutex);
      break;
    }
    struct timespec deadline = realtime_after_microseconds(broker->batch_window_microseconds);
    while (broker->queued < broker->max_batch_records && !broker->stopping) {
      int wait_status = pthread_cond_timedwait(&broker->not_empty, &broker->mutex, &deadline);
      if (wait_status == ETIMEDOUT) break;
    }
    uint32_t count = 0;
    while (count < broker->max_batch_records && broker->head != NULL) {
      requests[count] = broker->head;
      broker->head = broker->head->next;
      requests[count]->next = NULL;
      records[count] = requests[count]->record;
      broker->queued--;
      count++;
    }
    if (broker->head == NULL) broker->tail = NULL;
    pthread_cond_broadcast(&broker->not_full);
    pthread_mutex_unlock(&broker->mutex);

    hdl_receipt batch_receipt;
    hdl_status status = hdl_append_batch(broker->log, records, count, &batch_receipt);

    pthread_mutex_lock(&broker->mutex);
    if (status == HDL_OK) {
      broker->stats.records += count;
      broker->stats.durable_batches++;
      if (count > broker->stats.largest_batch) broker->stats.largest_batch = count;
    }
    for (uint32_t index = 0; index < count; index++) {
      requests[index]->status = status;
      if (status == HDL_OK) {
        requests[index]->receipt = batch_receipt;
        requests[index]->receipt.first_sequence = batch_receipt.first_sequence + index;
        requests[index]->receipt.last_sequence = batch_receipt.first_sequence + index;
      }
      requests[index]->done = 1;
      pthread_cond_signal(&requests[index]->completed);
    }
    pthread_mutex_unlock(&broker->mutex);
  }

  free(requests);
  free(records);
  return NULL;
}

hdl_status hdl_broker_open(hdl_log *log,
                           const hdl_broker_options *options,
                           hdl_broker **out) {
  if (log == NULL || out == NULL) return HDL_INVALID;
  *out = NULL;
  hdl_broker *broker = calloc(1, sizeof(*broker));
  if (broker == NULL) return HDL_NOMEM;
  broker->log = log;
  broker->queue_capacity = options != NULL && options->queue_capacity != 0
                             ? options->queue_capacity : HDL_DEFAULT_QUEUE_CAPACITY;
  broker->max_batch_records = options != NULL && options->max_batch_records != 0
                                ? options->max_batch_records : HDL_DEFAULT_BROKER_BATCH_RECORDS;
  broker->batch_window_microseconds = options != NULL && options->batch_window_microseconds != 0
                                        ? options->batch_window_microseconds : HDL_DEFAULT_BATCH_WINDOW_US;
  if (broker->max_batch_records > broker->queue_capacity) {
    broker->max_batch_records = broker->queue_capacity;
  }
  if (pthread_mutex_init(&broker->mutex, NULL) != 0) {
    free(broker);
    return HDL_NOMEM;
  }
  if (pthread_cond_init(&broker->not_empty, NULL) != 0) {
    pthread_mutex_destroy(&broker->mutex);
    free(broker);
    return HDL_NOMEM;
  }
  if (pthread_cond_init(&broker->not_full, NULL) != 0) {
    pthread_cond_destroy(&broker->not_empty);
    pthread_mutex_destroy(&broker->mutex);
    free(broker);
    return HDL_NOMEM;
  }
  if (pthread_create(&broker->writer, NULL, broker_writer, broker) != 0) {
    pthread_cond_destroy(&broker->not_full);
    pthread_cond_destroy(&broker->not_empty);
    pthread_mutex_destroy(&broker->mutex);
    free(broker);
    return HDL_IO;
  }
  *out = broker;
  return HDL_OK;
}

hdl_status hdl_broker_submit(hdl_broker *broker,
                             const hdl_record *record,
                             hdl_receipt *receipt) {
  return hdl_broker_submit_within(broker, record, 0, receipt);
}

hdl_status hdl_broker_submit_within(hdl_broker *broker,
                                    const hdl_record *record,
                                    uint32_t admission_timeout_microseconds,
                                    hdl_receipt *receipt) {
  if (broker == NULL || record == NULL ||
      (record->payload_length > 0 && record->payload == NULL)) return HDL_INVALID;
  hdl_request request;
  memset(&request, 0, sizeof(request));
  request.record = *record;
  if (pthread_cond_init(&request.completed, NULL) != 0) return HDL_NOMEM;

  pthread_mutex_lock(&broker->mutex);
  /* Waiting to be LET IN is the only part a caller may abandon. Nothing has
     been accepted yet, so a refusal here is the truth and stays the truth. */
  if (admission_timeout_microseconds == 0) {
    while (broker->queued >= broker->queue_capacity && !broker->stopping) {
      pthread_cond_wait(&broker->not_full, &broker->mutex);
    }
  } else {
    struct timespec deadline = realtime_after_microseconds(admission_timeout_microseconds);
    while (broker->queued >= broker->queue_capacity && !broker->stopping) {
      if (pthread_cond_timedwait(&broker->not_full, &broker->mutex, &deadline) == ETIMEDOUT) {
        if (broker->queued < broker->queue_capacity || broker->stopping) break;
        pthread_mutex_unlock(&broker->mutex);
        pthread_cond_destroy(&request.completed);
        return HDL_BUSY;
      }
    }
  }
  if (broker->stopping) {
    pthread_mutex_unlock(&broker->mutex);
    pthread_cond_destroy(&request.completed);
    return HDL_CLOSED;
  }
  if (broker->tail == NULL) broker->head = &request;
  else broker->tail->next = &request;
  broker->tail = &request;
  broker->queued++;
  if (broker->queued > broker->stats.max_queue_depth) broker->stats.max_queue_depth = broker->queued;
  pthread_cond_signal(&broker->not_empty);
  while (!request.done) pthread_cond_wait(&request.completed, &broker->mutex);
  pthread_mutex_unlock(&broker->mutex);

  pthread_cond_destroy(&request.completed);
  if (receipt != NULL && request.status == HDL_OK) *receipt = request.receipt;
  return request.status;
}

hdl_status hdl_broker_get_stats(hdl_broker *broker, hdl_broker_stats *out) {
  if (broker == NULL || out == NULL) return HDL_INVALID;
  pthread_mutex_lock(&broker->mutex);
  *out = broker->stats;
  pthread_mutex_unlock(&broker->mutex);
  return HDL_OK;
}

hdl_status hdl_broker_close(hdl_broker *broker) {
  if (broker == NULL) return HDL_INVALID;
  pthread_mutex_lock(&broker->mutex);
  broker->stopping = 1;
  pthread_cond_broadcast(&broker->not_empty);
  pthread_cond_broadcast(&broker->not_full);
  pthread_mutex_unlock(&broker->mutex);
  if (pthread_join(broker->writer, NULL) != 0) return HDL_IO;
  pthread_cond_destroy(&broker->not_full);
  pthread_cond_destroy(&broker->not_empty);
  pthread_mutex_destroy(&broker->mutex);
  free(broker);
  return HDL_OK;
}

const char *hdl_status_name(hdl_status status) {
  switch (status) {
    case HDL_OK: return "ok";
    case HDL_INVALID: return "invalid";
    case HDL_IO: return "io";
    case HDL_CORRUPTION: return "corruption";
    case HDL_NOMEM: return "nomem";
    case HDL_LIMIT: return "limit";
    case HDL_CLOSED: return "closed";
    case HDL_DONE: return "done";
    case HDL_POISONED: return "poisoned";
    case HDL_LOCKED: return "locked";
    case HDL_BUSY: return "busy";
    case HDL_RETIRED: return "retired";
  }
  return "unknown";
}
