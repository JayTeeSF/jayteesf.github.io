#!/usr/bin/env bash
# The api_screens renderer on the Mac: no emulator, no network.
#
#   1. The pure layer (renderer/java) compiles with no Android class on the class
#      path. Control: the same sources with one android import do not.
#   2. The vendored conformance vectors are hey_mobile's, byte for byte, when
#      HEY_MOBILE_ROOT (default ~/dev/hey_mobile) is present. Control: one byte
#      changed is caught.
#   3. hey_mobile's vectors (values, names, descriptions) pass, and the fixture
#      description is taken by android level 1.
#   4. The renderer's own rules pass (renderer/host ModelMain): unknown kinds
#      hidden and never sent, sign-out, forms, baked keys, prompts, and a
#      search's state (searching, empty, failed, given up).
#   5. MUTATIONS: each deliberately broken copy of the renderer fails the vectors
#      or the rules. A mutation that does not change its file fails the spec, so a
#      control cannot quietly become a no-op.
#   6. renderer/api-renderer.json and the Java constants agree. Control: level 2 is caught.
#   7. The renderer names no product and no route. Control: the same search finds
#      routes in the fixture description.
#   8. tools/hey-android-api-app.sh builds a signed, 16 KB aligned debug APK with
#      one classes.dex, the INTERNET permission, cleartext on, backup off, and the
#      baked description byte for byte. Controls: it refuses a description the
#      renderer refuses, and an http origin to a public host.
#   9. The release lane: with a throwaway key, --release --icon --aab builds an APK
#      and a bundle signed by that key, not debuggable, with the icon, the version
#      code and the baked description; bundletool validates the bundle; the
#      password is in no receipt or log, and no path of this Mac is in the APK or
#      bundle. Controls: a release to http, a bundle
#      without --release, a wrong password, a missing Keychain item and a
#      non-square icon are each refused, and the password search finds a planted copy.
set -uo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ANDROID_ROOT=$ROOT
. "$ROOT/tools/android-env.sh"
failed=0
work=$(mktemp -d "${TMPDIR:-/tmp}/hey_android-api-host-spec.XXXXXX")
trap 'rm -rf "$work"' EXIT
pass() { echo "PASS: $*"; }
control() { echo "PASS (control): $*"; }
bad() { echo "FAIL: $*"; failed=1; }

java_home=$(hey_android_java_home)
[ -n "$java_home" ] || { bad "JDK $HEY_ANDROID_JDK not found"; exit 1; }
javac=$java_home/bin/javac
java=$java_home/bin/java
R=$ROOT/renderer
vectors=$ROOT/specs/conformance/hey_mobile
fixture=$ROOT/specs/support/api_fixture_description.json

compile() { # OUT SRC_DIR...: compile the pure layer and the host mains from the given trees
  local outdir=$1
  shift
  mkdir -p "$outdir"
  find "$@" -name '*.java' | sort > "$outdir.sources"
  "$javac" --release 17 -d "$outdir" @"$outdir.sources" > "$outdir.log" 2>&1
}

# ---- 1. pure --------------------------------------------------------------------------------------
if compile "$work/pure" "$R/java" "$R/host"; then
  pass "renderer/java and renderer/host compile with JDK $HEY_ANDROID_JDK and no android.jar: $(wc -l < "$work/pure.sources" | tr -d ' ') sources"
else
  bad "the pure layer does not compile without Android: $(head -5 "$work/pure.log")"
  exit 1
fi
mkdir -p "$work/impure"
cp -R "$R/java" "$work/impure/java"
sed -i '' 's/^import java.util.Map;$/import java.util.Map;\nimport android.util.Log;/' "$work/impure/java/hey/android/api/Values.java"
if grep -q 'import android.util.Log;' "$work/impure/java/hey/android/api/Values.java" && ! compile "$work/impure-out" "$work/impure/java"; then
  control "Values.java with 'import android.util.Log;' added does not compile on the host: $(grep -m1 'error' "$work/impure-out.log")"
else
  bad "(control) an android import in the pure layer was not caught"
fi

# ---- 2. vendored vectors ----------------------------------------------------------------------------
mobile=${HEY_MOBILE_ROOT:-$HOME/dev/hey_mobile}
if [ -d "$mobile/conformance" ]; then
  differ=''
  for f in values.json names.json descriptions.json; do cmp -s "$vectors/$f" "$mobile/conformance/$f" || differ="$differ $f"; done
  if [ -z "$differ" ]; then
    pass "specs/conformance/hey_mobile holds $mobile/conformance's values, names and descriptions byte for byte (hey_mobile $(tr -d '[:space:]' < "$mobile/VERSION" 2> /dev/null))"
  else
    bad "the vendored vectors differ from $mobile/conformance:$differ"
  fi
  cp "$vectors/values.json" "$work/values-changed.json"
  printf ' ' >> "$work/values-changed.json"
  if ! cmp -s "$work/values-changed.json" "$mobile/conformance/values.json"; then
    control "values.json with one space added is seen to differ"
  else
    bad "(control) a changed vector file compared equal"
  fi
else
  echo "note: no $mobile/conformance here; the vendored vectors are used as they are"
fi

# ---- 3. vectors ---------------------------------------------------------------------------------------
if "$java" -cp "$work/pure" hey.android.api.ConformanceMain "$vectors" "$fixture" > "$work/conformance.txt" 2>&1; then
  cat "$work/conformance.txt"
else
  cat "$work/conformance.txt"
  bad "hey_mobile's conformance vectors fail on this renderer"
fi

# ---- 4. rules -----------------------------------------------------------------------------------------
if "$java" -cp "$work/pure" hey.android.api.ModelMain > "$work/model.txt" 2>&1; then
  cat "$work/model.txt"
else
  cat "$work/model.txt"
  bad "the renderer's own rules fail"
fi

# ---- 5. mutations -------------------------------------------------------------------------------------
mutate() { # NAME FILE MAIN PERL_EXPRESSION: the broken copy must make MAIN fail
  local name=$1 file=$2 main=$3 expr=$4
  local tree=$work/mutant-$name
  rm -rf "$tree"
  mkdir -p "$tree"
  cp -R "$R/java" "$tree/java"
  cp -R "$R/host" "$tree/host"
  perl -0pi -e "$expr" "$tree/java/hey/android/api/$file"
  if cmp -s "$tree/java/hey/android/api/$file" "$R/java/hey/android/api/$file"; then
    bad "(control) mutation '$name' did not change $file: the pattern no longer matches"
    return
  fi
  if ! compile "$tree/out" "$tree/java" "$tree/host"; then
    bad "(control) mutation '$name' does not compile: $(head -3 "$tree/out.log")"
    return
  fi
  if "$java" -cp "$tree/out" "hey.android.api.$main" "$vectors" "$fixture" > "$tree/run.txt" 2>&1; then
    bad "(control) mutation '$name' passed $main: the check cannot tell it from the renderer"
  else
    control "mutation '$name' ($file) fails $main: $(grep -m1 '^FAIL' "$tree/run.txt" | cut -c1-170)"
  fi
}
mutate empty-placeholder-kept Values.java ConformanceMain 's/if \(value\.isEmpty\(\)\) return "";\n//'
mutate unknown-action-known Values.java ConformanceMain 's/if \(!ACTION_KINDS\.contains\(actionKind\(action\)\)\) return false;\n//'
mutate slash-not-encoded Values.java ConformanceMain 's/_~";/_~\/";/'
mutate etag-not-checked Descriptions.java ConformanceMain 's/if \(claimed != null && !claimed\.equals\(sha256Hex\(body\)\)\) return "etag";\n//'
mutate level-not-checked Descriptions.java ConformanceMain 's/ \|\| ld > level\) return "level";/) return "level";/'
mutate icon-dropped Names.java ConformanceMain 's/\s*\{"library", "books\.vertical", "local_library"\},\n/\n/'
mutate undrawn-kind-drawn Screens.java ModelMain 's/if \(!DRAWN_ACTION_KINDS\.contains\(Values\.actionKind\(d\)\)\) return false;\n//'
mutate run-without-refusing Actions.java ModelMain 's/if \(!Screens\.drawsAction\(action\)\) return false;\n//'
mutate unknown-section-asked Screens.java ModelMain 's/if \(!drawsSection\(section\) \|\| !Values\.sectionKind\(section\)\.equals\("route"\)\) return null;/if (Values.sectionKind(section).equals("fields")) return null;/'
mutate served-origin-kept Descriptions.java ModelMain 's/out\.remove\("origin"\);\n//'
mutate required-hidden-sent Screens.java ModelMain 's/f\.primaryDrawn = routes && !requiredHidden;/f.primaryDrawn = routes;/'
mutate prompt-not-asked Actions.java ModelMain 's/if \(!Json\.dict\(action\.get\("prompt"\)\)\.isEmpty\(\)\) host\.prompt\(action, row, vars, ready -> send\(action, ready, row, host, transport\)\);\n\s*else //'
mutate prompt-required-unchecked Actions.java ModelMain 's/\n\s*if \(Values\.truthy\(field\.get\("required"\)\) && text\.isEmpty\(\)\) return new Prompted\([^;]*;//'
mutate odd-prompt-field-drawn Screens.java ModelMain 's/\n\s*if \(!DRAWN_FIELD_KINDS\.contains\(kind\) \|\| !Values\.known\("field", field, level\(\)\)\) return false;//'
mutate unanswered-search-empty Screens.java ModelMain 's/if \(answered == null \|\| answered\.pending\) return SearchState\.SEARCHING;/if (answered == null) continue;/'
mutate gave-up-still-pending Screens.java ModelMain 's/Values\.string\(section\.get\("gave_up_note"\)\), false\);/Values.string(section.get("pending_note")), true);/'
mutate failed-search-empty Screens.java ModelMain 's/return failed \? SearchState\.FAILED : SearchState\.EMPTY;/return SearchState.EMPTY;/'

# ---- 6. declared level ------------------------------------------------------------------------------------
declared() { # FILE: "platform level schema max_bytes" from an api-renderer.json
  /usr/bin/python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(d["platform"], d["level"], d["schema"], d["max_bytes"])' "$1"
}
in_java=$(printf '%s %s %s %s' \
  "$(sed -n 's/.*RENDERER_PLATFORM = "\(.*\)";/\1/p' "$R/java/hey/android/api/Values.java")" \
  "$(sed -n 's/.*RENDERER_LEVEL = \([0-9]*\);/\1/p' "$R/java/hey/android/api/Values.java")" \
  "$(sed -n 's/.*String SCHEMA = "\(.*\)";/\1/p' "$R/java/hey/android/api/Descriptions.java")" \
  "$(sed -n 's/.*MAX_BYTES = \([0-9_]*\);/\1/p' "$R/java/hey/android/api/Descriptions.java" | tr -d _)")
if [ "$(declared "$R/api-renderer.json")" = "$in_java" ]; then
  pass "renderer/api-renderer.json declares what the Java says: $in_java"
else
  bad "renderer/api-renderer.json says '$(declared "$R/api-renderer.json")', the Java says '$in_java'"
fi
sed 's/"level": 1/"level": 2/' "$R/api-renderer.json" > "$work/level2.json"
if [ "$(declared "$work/level2.json")" != "$in_java" ]; then
  control "an api-renderer.json declaring level 2 does not match the Java"
else
  bad "(control) a level-2 declaration matched"
fi

# ---- 7. no product ----------------------------------------------------------------------------------------
product='my ?queue|myqueue|jayteesf|/v1/|netflix|youtube|apple tv'
found=$(grep -rniE "$product" "$R/java" "$R/android" 2> /dev/null || true)
if [ -z "$found" ]; then
  pass "renderer/java and renderer/android name no product, service or route ($product)"
else
  bad "the renderer names a product or route: $(printf '%s\n' "$found" | head -3)"
fi
if grep -qiE "$product" "$fixture"; then
  control "the same search finds routes in the fixture description ($(grep -oiE "$product" "$fixture" | head -1))"
else
  bad "(control) the product search found nothing in the fixture"
fi

# ---- 8. the APK ---------------------------------------------------------------------------------------------
apk_out=$work/apk
if "$ROOT/tools/hey-android-api-app.sh" --description "$fixture" --origin http://10.0.2.2:3581 --package-id com.jayteesf.hey.api.fixture \
  --label 'Hey api fixture' --out "$apk_out" > "$work/apk.log" 2>&1; then
  apk=$apk_out/app.apk
  bt=$HEY_ANDROID_BUILD_TOOLS_DIR
  dexes=$(unzip -l "$apk" | awk '{print $4}' | grep -c '^classes[0-9]*\.dex$')
  "$bt/aapt2" dump xmltree --file AndroidManifest.xml "$apk" > "$work/manifest.txt" 2>&1
  baked_same=false
  unzip -p "$apk" assets/hey-api/description.json | cmp -s - "$fixture" && baked_same=true
  origin=$(unzip -p "$apk" assets/hey-api/origin.txt)
  if [ "$dexes" = 1 ] && grep -q 'android.permission.INTERNET' "$work/manifest.txt" \
    && grep -q 'usesCleartextTraffic.*=true' "$work/manifest.txt" && grep -q 'allowBackup.*=false' "$work/manifest.txt" \
    && grep -q 'hey.android.api.HeyAndroidApiActivity' "$work/manifest.txt" \
    && "$bt/zipalign" -c -P 16 -v 4 "$apk" > /dev/null 2>&1 && [ "$baked_same" = true ] && [ "$origin" = http://10.0.2.2:3581 ] \
    && grep -q "targetSdkVersion:'36'" "$apk_out/logs/badging.txt"; then
    pass "the fixture APK ($(wc -c < "$apk" | tr -d ' ') bytes) has one classes.dex, targets API 36, asks for INTERNET, allows cleartext to 10.0.2.2, keeps backup off, is 16 KB aligned and signed, and bakes the description byte for byte"
  else
    bad "the fixture APK: $dexes dex, baked same $baked_same, origin '$origin'; manifest: $(grep -cE 'INTERNET|usesCleartextTraffic|allowBackup' "$work/manifest.txt") of 3 attributes"
  fi
else
  bad "tools/hey-android-api-app.sh failed: $(tail -5 "$work/apk.log")"
fi
/usr/bin/python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); d["platform"]="ios"; open(sys.argv[2],"w").write(json.dumps(d))' "$fixture" "$work/ios.json"
if ! "$ROOT/tools/hey-android-api-app.sh" --description "$work/ios.json" --origin http://10.0.2.2:3581 --package-id com.jayteesf.hey.api.bad \
  --label bad --out "$work/apk-ios" > "$work/apk-ios.log" 2>&1 && grep -q 'refuses this description: refused platform' "$work/apk-ios.log"; then
  control "the tool refuses to bake a description whose platform is ios: $(grep -m1 refuses "$work/apk-ios.log")"
else
  bad "(control) the tool baked a description the renderer refuses"
fi
if ! "$ROOT/tools/hey-android-api-app.sh" --description "$fixture" --origin http://example.com --package-id com.jayteesf.hey.api.bad \
  --label bad --out "$work/apk-http" > "$work/apk-http.log" 2>&1 && grep -q 'http is allowed only' "$work/apk-http.log"; then
  control "the tool refuses an http origin to a public host: $(head -1 "$work/apk-http.log")"
else
  bad "(control) the tool accepted http://example.com"
fi

# ---- 9. the release lane ------------------------------------------------------------------------------------
keytool=$java_home/bin/keytool
HEY_ANDROID_SPEC_KS_PASS="spec-$$-$(date +%s)-$RANDOM"
export HEY_ANDROID_SPEC_KS_PASS
export HEY_ANDROID_SPEC_WRONG_PASS=not-the-password
"$keytool" -genkeypair -keystore "$work/upload.p12" -storetype PKCS12 -alias upload -keyalg RSA -keysize 2048 -validity 400 \
  -dname 'CN=hey_android spec' -storepass:env HEY_ANDROID_SPEC_KS_PASS -keypass:env HEY_ANDROID_SPEC_KS_PASS > "$work/keytool.log" 2>&1
spec_cert=$("$keytool" -list -v -keystore "$work/upload.p12" -alias upload -storepass:env HEY_ANDROID_SPEC_KS_PASS 2> /dev/null \
  | sed -n 's/^[[:space:]]*SHA256: //p' | head -1 | tr -d ':' | tr 'A-F' 'a-f')
png() { # FILE WIDTH HEIGHT: a solid PNG
  /usr/bin/python3 - "$@" <<'PNG'
import struct, sys, zlib
path, w, h = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
def chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)
raw = b"".join(b"\x00" + b"\x0b\x12\x20" * w for _ in range(h))
open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
                       + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))
PNG
}
png "$work/icon.png" 512 512
png "$work/wide.png" 600 400
rel=$work/release
common=(--description "$fixture" --package-id com.jayteesf.hey.api.release --label 'Hey api release')
if [ -n "$spec_cert" ] && "$ROOT/tools/hey-android-api-app.sh" "${common[@]}" --origin https://api.example.test --version-code 7 --version-name 1.2 \
     --icon "$work/icon.png" --release --keystore "$work/upload.p12" --keystore-password-env HEY_ANDROID_SPEC_KS_PASS --aab --out "$rel" > "$work/release.log" 2>&1; then
  rfield() { /usr/bin/python3 -c 'import json,sys
v = json.load(open(sys.argv[1]))
for k in sys.argv[2].split("."): v = v.get(k) if isinstance(v, dict) else None
print(v if isinstance(v, str) else json.dumps(v))' "$rel/receipt.json" "$1"; }
  bt=$HEY_ANDROID_BUILD_TOOLS_DIR
  apk_cert=$(env JAVA_HOME="$java_home" PATH="$java_home/bin:/usr/bin:/bin" "$bt/apksigner" verify --print-certs "$rel/app.apk" 2> /dev/null \
    | sed -n 's/^Signer #1 certificate SHA-256 digest: //p' | head -1)
  aab_cert=$("$keytool" -printcert -jarfile "$rel/app.aab" 2> /dev/null | sed -n 's/^[[:space:]]*SHA256: //p' | head -1 | tr -d ':' | tr 'A-F' 'a-f')
  "$bt/aapt2" dump badging "$rel/app.apk" > "$work/release-badging.txt" 2>&1
  unzip -l "$rel/app.aab" > "$work/aab-list.txt"
  if [ "$apk_cert" = "$spec_cert" ] && [ "$aab_cert" = "$spec_cert" ] && ! grep -q application-debuggable "$work/release-badging.txt" \
    && grep -q "versionCode='7'" "$work/release-badging.txt" && grep -q '^application-icon-' "$work/release-badging.txt" \
    && [ "$(rfield apk.signing)" = release ] && [ "$(rfield apk.debuggable)" = false ] && [ "$(rfield bundle.validated)" = true ] \
    && grep -q 'base/dex/classes.dex' "$work/aab-list.txt" && grep -q 'base/assets/hey-api/description.json' "$work/aab-list.txt" \
    && grep -q 'base/res/mipmap-xxxhdpi' "$work/aab-list.txt" && grep -q 'base/manifest/AndroidManifest.xml' "$work/aab-list.txt"; then
    pass "a release build: the APK and the bundle ($(wc -c < "$rel/app.aab" | tr -d ' ') bytes, validated by bundletool $HEY_ANDROID_BUNDLETOOL) are signed by the given key ($(printf '%s' "$spec_cert" | cut -c1-16)...), not debuggable, version code 7, with the launcher icon, the dex and the baked description"
  else
    bad "the release build: apk cert '$apk_cert', bundle cert '$aab_cert', key '$spec_cert', signing '$(rfield apk.signing)', validated '$(rfield bundle.validated)'"
  fi
  if unzip -p "$rel/app.aab" | LC_ALL=C grep -aqF -e "$rel" -e "$HOME/" -e '/Users/' || unzip -p "$rel/app.apk" | LC_ALL=C grep -aqF -e "$rel" -e "$HOME/" -e '/Users/'; then
    bad "the release APK or bundle holds a path of this Mac: $(unzip -p "$rel/app.aab" | LC_ALL=C grep -aoE '/(Users|private|var)/[[:print:]]{0,60}' | head -1)"
  else
    pass "no file in the release APK or bundle holds the build directory, the home directory or a /Users/ path"
  fi
  (cd "$work" && mkdir -p abs && "$HEY_ANDROID_BUILD_TOOLS_DIR/aapt2" compile --dir "$rel/res" -o abs/res.zip \
    && "$HEY_ANDROID_BUILD_TOOLS_DIR/aapt2" link --proto-format --manifest "$rel/apk/AndroidManifest.xml" -I "$HEY_ANDROID_PLATFORM_JAR" -R abs/res.zip -o abs/proto.apk) > "$work/abs.log" 2>&1
  if unzip -p "$work/abs/proto.apk" resources.pb 2> /dev/null | LC_ALL=C grep -aqF -e "$rel"; then
    control "resources compiled from the absolute path carry it into resources.pb, and the same search finds it"
  else
    bad "(control) an absolute-path compile left no path the search could find: $(tail -2 "$work/abs.log")"
  fi
  if grep -rqF -e "$HEY_ANDROID_SPEC_KS_PASS" "$rel/receipt.json" "$rel/logs"; then
    bad "the keystore password is written into the receipt or a log"
  else
    pass "the keystore password appears in no receipt or log ($(ls "$rel/logs" | wc -l | tr -d ' ') logs)"
  fi
  cp -R "$rel/logs" "$work/planted-logs"
  printf 'password=%s\n' "$HEY_ANDROID_SPEC_KS_PASS" >> "$work/planted-logs/apksigner.log"
  if grep -rqF -e "$HEY_ANDROID_SPEC_KS_PASS" "$work/planted-logs"; then
    control "the same search finds a password planted in a copy of the logs"
  else
    bad "(control) the password search did not find a planted copy"
  fi
else
  bad "the release build failed (key '$spec_cert'): $(tail -5 "$work/release.log")"
fi
refuses() { # LABEL PATTERN ARGS...: the tool must fail and say PATTERN
  local label=$1 pattern=$2
  shift 2
  if ! "$ROOT/tools/hey-android-api-app.sh" "$@" > "$work/refuse.log" 2>&1 && grep -q -e "$pattern" "$work/refuse.log"; then
    control "$label: $(grep -m1 -e "$pattern" "$work/refuse.log" | cut -c1-170)"
  else
    bad "(control) $label: not refused for that reason: $(head -3 "$work/refuse.log")"
  fi
}
refuses 'a release to an http origin is refused' 'talks only to https' "${common[@]}" --origin http://10.0.2.2:3581 \
  --release --keystore "$work/upload.p12" --keystore-password-env HEY_ANDROID_SPEC_KS_PASS --out "$work/refuse-http"
refuses 'a bundle without --release is refused' 'needs --release' "${common[@]}" --origin https://api.example.test --aab --out "$work/refuse-aab"
refuses 'a wrong keystore password is refused before anything is built' 'does not open with that password' "${common[@]}" --origin https://api.example.test \
  --release --keystore "$work/upload.p12" --keystore-password-env HEY_ANDROID_SPEC_WRONG_PASS --out "$work/refuse-pass"
refuses 'a Keychain item that does not exist is refused' 'no Keychain password' "${common[@]}" --origin https://api.example.test \
  --release --keystore "$work/upload.p12" --keychain-service "hey-android-spec-absent-$$" --out "$work/refuse-keychain"
refuses 'a launcher icon that is not square is refused' 'must be a square PNG' "${common[@]}" --origin http://10.0.2.2:3581 --icon "$work/wide.png" --out "$work/refuse-icon"
if [ ! -e "$work/refuse-pass/app.apk" ] && [ ! -e "$work/refuse-pass/app.aab" ] && [ -d "$work/refuse-pass/logs" ]; then
  control "the wrong-password run stopped before signing: its directory has logs and no app.apk or app.aab"
else
  bad "(control) the wrong-password run: $(ls -A "$work/refuse-pass" 2>&1)"
fi

exit "$failed"
