# hey_toml

TOML 1.1 decoding for compiled applications. Supports comments, dotted keys, arrays of tables, UTF-8 strings, signed 64-bit integers, floats and date/time values. Input, native allocations and encoded output have explicit limits.

The package uses the standard Hey native interface with a pinned MIT-licensed `tomlc17` parser. Its source revision and checksums are in `vendor/tomlc17/UPSTREAM.json`. Native code is built locally; no Ruby or Go runtime is required by the package.

See [getting started](docs/GETTING_STARTED.md), [API and value mapping](docs/README.md), and [testing](docs/TESTING.md).

Choosing a format? Read [TOML vs. JSON](docs/CHOOSING_A_FORMAT.md) for measured speed, RAM and practical selection guidance.
