package hey.android.api;

import java.util.Map;

/** Opt-in form share retries retain the successful response, never replay its write. */
public final class FormShareState {
  private Map<String, Object> submitted;
  private Object response;
  private String path = "", title = "";

  public static Map<String, Object> snapshot(Map<String, Object> values) {
    return Json.dict(Json.parseOrNull(Json.encodeBytes(values)));
  }

  public void saved(Map<String, Object> success, Map<String, Object> values, Object json) {
    clear();
    String offered = Values.string(success.get("share"));
    String label = Values.string(success.get("share_retry_title"));
    if (offered.isEmpty() || label.isEmpty()) return;
    submitted = snapshot(values);
    response = Json.parseOrNull(Json.encodeBytes(json));
    path = offered;
    title = label;
  }

  public boolean matches(Map<String, Object> values) { return submitted != null && Json.same(submitted, values); }
  public Object response() { return response; }
  public String path() { return path; }
  public String title() { return title; }
  public void clear() { submitted = null; response = null; path = ""; title = ""; }
}
