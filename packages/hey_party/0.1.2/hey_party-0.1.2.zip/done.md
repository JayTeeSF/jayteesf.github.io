# Done

- 0.1.0: extracted room, lobby, controller, and five game reducers from Hey core.
- 0.1.2: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes.
