package hey.android.api;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Spannable;
import android.text.Selection;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.util.ArrayList;
import java.util.Locale;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The host: draws the screens a hey_mobile description names, with platform
 * Views. It names no product, route or service: everything it shows and every
 * request it sends comes from the description (Screens, Actions), and the
 * origin and session keys come from the baked copy only.
 *
 * Logcat, tag hey.api, says what happened without a token or a body:
 * "description: drawing the baked copy ...", "screen ready: <id> ...",
 * "signed in", "signed out", "request: GET /path -> 200".
 */
public final class HeyAndroidApiActivity extends Activity implements HeyAndroidHttp.Session {
  static final String TAG = "hey.api";

  private HeyAndroidDescription description;
  private HeyAndroidHttp http;
  private HeyAndroidSecureStore store;
  private final HeyAndroidPictures pictures = new HeyAndroidPictures();
  /**
   * THE PROCESS'S ONE PLAYER, not this screen's. A car browsing this app's
   * media service plays through the same object, so the two can never run at
   * once and can never disagree about where the listener stopped.
   */
  private HeyAndroidPlayback playback;
  private HeyAndroidPlayer player;
  private final Runnable onPlaybackChanged = this::onPlayerChanged;
  private String token;

  private final List<Page> stack = new ArrayList<>();
  private boolean signedIn;
  private String tab;

  private LinearLayout root;
  private TextView backButton;
  private TextView titleView;
  private TextView navButton;
  /**
   * A search screen's box, pinned under the title and OUTSIDE the scrolling
   * body. render() rebuilds the body on every answer -- a search with a pending
   * section answers every second or so -- and a box rebuilt with it lost its
   * focus, its keyboard and whatever had been typed since the last search.
   */
  private FrameLayout searchSlot;
  // Android owns the microphone UI and result; the app still owns the routes.
  // The system recognizer records only after this screen's mic is tapped.
  private static final int SPEECH_REQUEST_CODE = 4182;
  private int speechRequestCode = SPEECH_REQUEST_CODE;
  private Page speechTarget;
  private EditText speechEditor;
  private AlertDialog speechDialog;
  private AlertDialog activePrompt;
  private String speechDraft;
  private int speechStart, speechEnd;
  private int speechGeneration;
  /** The page render() last drew: a different one means the screen changed. */
  private Page shown;
  /** Whether the keyboard was on screen at the last insets pass. */
  private boolean imeShown;
  private ScrollView scroll;
  private LinearLayout body;
  private LinearLayout tabBar;
  private LinearLayout playerBar;
  /**
   * The running time in the player bar, kept as its own view so it can be
   * refreshed every second WITHOUT redrawing the screen: a full render once a
   * second would rebuild every row under the listener's finger and fight the
   * scroll.
   */
  private TextView playerClock;
  private boolean clockRunning;
  private boolean backRegistered;
  private final OnBackInvokedCallback back = this::goBack;

  /** One screen on the stack, with what it has loaded. */
  final class Page implements Actions.Host {
    final Map<String, Object> screen;
    final Map<String, Object> vars = new LinkedHashMap<>();
    final Map<String, Object> values = new LinkedHashMap<>();
    final Map<Integer, Screens.RouteRows> routes = new LinkedHashMap<>();
    Object json;
    String message;
    String sourceError;
    String title;
    int generation;
    boolean busy;
    int typed;
    final java.util.Set<String> touched = new java.util.HashSet<>();
    boolean formNeedsRender;
    final FormShareState savedShare = new FormShareState();
    Button formPrimary;
    Screens.Form formModel;
    boolean sharing;
    int shareRun;
    AlertDialog choiceDialog;
    final Map<String, String> choiceTitles = new LinkedHashMap<>();
    final Map<String, String> choiceLabels = new LinkedHashMap<>();
    /** field id -> the newest form-time choices read; only that one may write labels. */
    final Map<String, Integer> choiceReads = new LinkedHashMap<>();

    void refreshPrimary() {
      if (formPrimary == null || formModel == null) return;
      formPrimary.setEnabled(!busy && !sharing);
      formPrimary.setText(sharing ? "Preparing share…" : busy && !formModel.busyTitle.isEmpty()
          ? formModel.busyTitle : savedShare.matches(values) ? savedShare.title() : formModel.primaryTitle);
    }

    void edited(String id) {
      touched.add(id);
      typed++;
      savedShare.clear();
      refreshPrimary();
    }

    void leave() {
      generation++;
      if (choiceDialog != null) choiceDialog.dismiss();
      savedShare.clear();
      shareRun++;
      sharing = false;
      busy = false;
    }

    /** A search screen's current query, and how many times each section has been re-asked. */
    String query = "";
    final Map<Integer, Integer> polls = new LinkedHashMap<>();
    /** A search screen's box, made once per page so a redraw leaves it as it is. */
    LinearLayout searchBox;
    EditText field;
    TextView cancel;

    Page(Map<String, Object> screen, Map<String, Object> params) {
      this.screen = screen;
      if (params != null) vars.putAll(params);
      values.putAll(vars);
      title = Values.string(screen.get("title"));
    }

    String id() { return Values.string(screen.get("id")); }
    String type() { return Values.string(screen.get("type")); }

    @Override public Map<String, Object> vars() { return vars; }
    @Override public java.util.function.BooleanSupplier actionScope() {
      int started = generation;
      String session = token;
      return () -> !isFinishing() && !isDestroyed() && top() == this
          && generation == started && java.util.Objects.equals(session, token);
    }
    @Override public Object screenJson() { return json; }
    @Override public Map<String, Object> labels() { return description.labels(); }

    @Override public void confirm(String title, String message, String button, boolean destructive, Runnable then) {
      new AlertDialog.Builder(HeyAndroidApiActivity.this)
          .setTitle(title)
          .setMessage(message.isEmpty() ? null : message)
          .setPositiveButton(button.isEmpty() ? "OK" : button, (d, w) -> then.run())
          .setNegativeButton("Cancel", null)
          .show();
    }

    @Override public void openScreen(String id, Map<String, Object> params) { push(id, params); }

    @Override public void openUrl(String address) {
      String full = fullAddress(address);
      try {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(full)));
      } catch (ActivityNotFoundException e) {
        toast("Nothing on this phone opens that address.");
      }
    }

    @Override public void share(String address) {
      share(address, "", "", "");
    }

    @Override public void share(String address, String title, String text, String imageUrl) {
      if (!actionScope().getAsBoolean() || sharing || !Actions.webAddress(address)) return;
      sharing = true;
      int thisShare = ++shareRun;
      refreshPrimary();
      if (HeyAndroidPictures.fetchable(imageUrl)) toast("Preparing image for sharing…");

      String sharingSession = token;
      String body = text == null || text.isEmpty() ? address : text + "\n\n" + address;
      java.util.function.Consumer<Uri> present = artwork -> {
        // The successful action may reload this page while its image finishes.
        // Leaving the page or signing out must still cancel a delayed sheet.
        if (thisShare != shareRun) return;
        sharing = false;
        refreshPrimary();
        if (isFinishing() || isDestroyed() || top() != this || !java.util.Objects.equals(sharingSession, token)) return;
        if (artwork == null && HeyAndroidPictures.fetchable(imageUrl)) toast("Image is unavailable. Sharing the message and link; you can share again.");

        Intent send = new Intent(Intent.ACTION_SEND).setType(artwork == null ? "text/plain" : "image/png")
            .putExtra(Intent.EXTRA_TEXT, body)
            .putExtra(Intent.EXTRA_TITLE, title == null ? "" : title);
        if (artwork != null) {
          send.putExtra(Intent.EXTRA_STREAM, artwork);
          send.setClipData(android.content.ClipData.newRawUri("artwork", artwork));
          send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        try { startActivity(Intent.createChooser(send, null)); }
        catch (ActivityNotFoundException missing) { toast("Nothing on this phone can share that item."); }
      };
      if (HeyAndroidPictures.fetchable(imageUrl)) pictures.shareImage(getApplicationContext(), imageUrl, present);
      else present.accept(null);
    }

    @Override public void choose(Map<String, Object> action, List<Map<String, Object>> options,
        java.util.function.Consumer<Map<String, Object>> then) {
      if (!actionScope().getAsBoolean()) return;
      String[] titles = new String[options.size()];
      for (int i = 0; i < options.size(); i++) titles[i] = Values.string(options.get(i).get("title"));
      LinearLayout box = new LinearLayout(HeyAndroidApiActivity.this);
      box.setOrientation(LinearLayout.VERTICAL);
      String message = Values.string(action.get("prompt_text"));
      if (!message.isEmpty()) box.addView(text(message, 15, MUTED, false));
      android.widget.ListView list = new android.widget.ListView(HeyAndroidApiActivity.this);
      list.setAdapter(new android.widget.ArrayAdapter<String>(HeyAndroidApiActivity.this, android.R.layout.simple_list_item_1, titles));
      box.addView(list);
      AlertDialog dialog = new AlertDialog.Builder(HeyAndroidApiActivity.this)
          .setTitle(Values.string(action.get("title"))).setView(box).setNegativeButton("Cancel", null).create();
      list.setOnItemClickListener((parent, view, index, id) -> { dialog.dismiss(); then.accept(options.get(index)); });
      dialog.show();
    }

    @Override public void playVideo(String address) { HeyAndroidApiActivity.this.playVideo(address); }

    @Override public void toast(String text) { Toast.makeText(HeyAndroidApiActivity.this, text, Toast.LENGTH_SHORT).show(); }

    @Override public void alert(String title, String message) {
      new AlertDialog.Builder(HeyAndroidApiActivity.this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }

    @Override public void prompt(Map<String, Object> action, Object row, Map<String, Object> vars, java.util.function.Consumer<Map<String, Object>> then) {
      Map<String, Object> prompt = Json.dict(action.get("prompt"));
      LinearLayout box = new LinearLayout(HeyAndroidApiActivity.this);
      box.setOrientation(LinearLayout.VERTICAL);
      box.setPadding(dp(20), dp(8), dp(20), 0);
      Map<String, EditText> edits = new LinkedHashMap<>();
      Page promptPage = this;
      for (Object f : Json.list(prompt.get("fields"))) {
        Map<String, Object> field = Json.dict(f);
        String kind = Values.string(field.get("kind"));
        String label = Values.string(field.get("label"));
        String hint = Values.string(field.get("placeholder"));
        EditText edit = new EditText(HeyAndroidApiActivity.this);
        edit.setInputType(inputTypeFor(kind, field));
        edit.setHint(hint.isEmpty() ? label : hint);
        edit.setContentDescription(label);
        edit.setText(Actions.prefill(field, row, json));
        if (kind.equals("secure")) edit.setAutofillHints(View.AUTOFILL_HINT_PASSWORD);
        if (kind.equals("multiline")) edit.setMinLines(3);
        box.addView(dictationEntry(promptPage, field, edit, true));
        edits.put(Values.string(field.get("id")), edit);
      }
      String title = Values.string(prompt.get("title"));
      String message = Values.string(prompt.get("message"));
      String button = Values.string(prompt.get("button"));
      if (activePrompt != null) activePrompt.dismiss();
      activePrompt = new AlertDialog.Builder(HeyAndroidApiActivity.this)
          .setTitle(title.isEmpty() ? Values.string(action.get("title")) : title)
          .setMessage(message.isEmpty() ? null : message)
          .setView(box)
          .setPositiveButton(button.isEmpty() ? "Save" : button, (d, w) -> {
            Map<String, Object> typed = new LinkedHashMap<>();
            for (Map.Entry<String, EditText> e : edits.entrySet()) typed.put(e.getKey(), e.getValue().getText().toString());
            Actions.Prompted asked = Actions.prompted(action, vars, typed);
            if (asked.problem != null) alert(Values.string(action.get("title")), asked.problem);
            else then.accept(asked.vars);
          })
          .setNegativeButton("Cancel", null)
          .create();
      AlertDialog opened = activePrompt;
      opened.setOnDismissListener(d -> {
        if (speechDialog == opened) { speechTarget = null; speechEditor = null; speechDialog = null; }
        if (activePrompt == opened) activePrompt = null;
      });
      opened.show();
      Log.i(TAG, "prompt: " + edits.size() + " fields");
    }

    @Override public void signOut() { HeyAndroidApiActivity.this.signedOut(); }

    // keep_token stored the session and stayed on the signed-out screens for
    // one more page (a recovery code); this is the step into the app.
    @Override public void signedIn() { if (token != null && !token.isEmpty()) HeyAndroidApiActivity.this.signedInWith(token); }

    @Override public void pop() { goBack(); }

    @Override public void reload() { if (top() == this) load(this); }
  }

  // ---- the Activity ------------------------------------------------------------------------

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    buildChrome();
    try {
      description = new HeyAndroidDescription(this);
    } catch (Exception e) {
      Log.e(TAG, "description: this build has no readable description (" + e.getMessage() + ")");
      showProblem("This build has no readable app description. Rebuild it.");
      return;
    }
    http = new HeyAndroidHttp(description.origin, this);
    store = new HeyAndroidSecureStore(this, description.storeName());
    token = store.read();
    HeyAndroidPlayback existingPlayback = HeyAndroidPlayback.existing();
    if (existingPlayback != null) existingPlayback.changeSession(token);
    Log.i(TAG, "renderer: android level " + Values.RENDERER_LEVEL + ", origin " + description.origin + ", kept session " + (token != null));
    if (token == null) {
      showSignIn();
    } else {
      Map<String, Object> check = Json.dict(Json.dict(description.current.get("session")).get("check"));
      if (check.isEmpty()) {
        showTabs();
      } else {
        showMessageOnly("Opening");
        http.request(Values.string(check.get("method")).isEmpty() ? "GET" : Values.string(check.get("method")), Values.string(check.get("path")), null, (status, json, error) -> {
          if (status == 401) {
            keepSession(null);
            showSignIn();
          } else {
            showTabs();
          }
        });
      }
    }
  }

  @Override
  protected void onResume() {
    super.onResume();
    // CAR MODE IS DRIVING (0.4.16). Android's in-vehicle activity needs Google
    // Play services, which this renderer does not carry; car mode (Android
    // Auto on the phone or a car's screen) needs no permission at all.
    android.app.UiModeManager modes = getSystemService(android.app.UiModeManager.class);
    boolean car = modes != null && modes.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_CAR;
    if (car != HeyAndroidHttp.driving) {
      HeyAndroidHttp.driving = car;
      Page shown = top();
      if (shown != null && Boolean.TRUE.equals(shown.screen.get("driving_aware"))) load(shown);
    }
    if (store != null && !java.util.Objects.equals(token, store.read())) {
      keepSession(store.read());
      if (token == null) showSignIn(); else showTabs();
    }
  }

  @Override protected void onDestroy() {
    if (playback != null) playback.unwatch(onPlaybackChanged);
    if (http != null) http.close();
    pictures.close();
    clearPages();
    super.onDestroy();
  }

  // ---- chrome ------------------------------------------------------------------------------

  private int dp(float v) { return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics())); }

  private static final int ACCENT = Color.rgb(0x1a, 0x5f, 0xb4);
  private static final int DANGER = Color.rgb(0xc6, 0x28, 0x28);
  private static final int MUTED = Color.rgb(0x5f, 0x63, 0x68);
  private static final int GROUND = Color.rgb(0xf2, 0xf2, 0xf7);

  private TextView text(String s, float sp, int color, boolean bold) {
    TextView t = new TextView(this);
    t.setText(s);
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
    t.setTextColor(color);
    if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
    t.setTextIsSelectable(true);
    // Android's long press selects one word; a title copied for search must
    // be whole. Let the platform start its selection and toolbar, then widen
    // it to the full value. The handles still narrow it.
    t.setOnLongClickListener(v -> {
      t.post(() -> {
        CharSequence c = t.getText();
        if (c instanceof Spannable && t.hasSelection()) Selection.setSelection((Spannable) c, 0, c.length());
      });
      return false;
    });
    return t;
  }

  // Interactive labels are controls, not content. Keep their normal short-tap
  // handling instead of letting TextView's selection gesture own the touch.
  private TextView controlText(String s, float sp, int color, boolean bold) {
    TextView t = text(s, sp, color, bold);
    t.setTextIsSelectable(false);
    return t;
  }

  private void buildChrome() {
    root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackgroundColor(GROUND);
    root.setOnApplyWindowInsetsListener((v, insets) -> {
      Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
      v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
      // THE KEYBOARD WENT AWAY ON ITS OWN -- system Back, or its own hide key.
      // The box would otherwise keep its focus, and a focused box is one
      // redraw away from the keyboard the person has just put away.
      boolean ime = insets.isVisible(WindowInsets.Type.ime());
      if (imeShown && !ime && shown != null && shown.field != null && shown.field.hasFocus()) {
        shown.field.clearFocus();
        Log.i(TAG, "keyboard: put away by the system");
      }
      imeShown = ime;
      return WindowInsets.CONSUMED;
    });

    LinearLayout bar = new LinearLayout(this);
    bar.setOrientation(LinearLayout.HORIZONTAL);
    bar.setGravity(Gravity.CENTER_VERTICAL);
    bar.setBackgroundColor(Color.WHITE);
    bar.setPadding(dp(8), dp(10), dp(8), dp(10));
    backButton = controlText("‹ Back", 17, ACCENT, false);
    backButton.setPadding(dp(8), dp(4), dp(12), dp(4));
    backButton.setOnClickListener(v -> goBack());
    titleView = text("", 19, Color.BLACK, true);
    titleView.setPadding(dp(8), 0, dp(8), 0);
    navButton = controlText("", 17, ACCENT, false);
    navButton.setPadding(dp(12), dp(4), dp(8), dp(4));
    bar.addView(backButton);
    bar.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    bar.addView(navButton);
    root.addView(bar);

    searchSlot = new FrameLayout(this);
    searchSlot.setVisibility(View.GONE);
    root.addView(searchSlot);

    scroll = new ScrollView(this);
    body = new LinearLayout(this);
    body.setOrientation(LinearLayout.VERTICAL);
    body.setPadding(dp(16), dp(8), dp(16), dp(24));
    scroll.addView(body);
    root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

    // PINNED, AND ABOVE THE TABS. It was drawn at the end of the list, which
    // put it below every row -- so the one control for the thing you are
    // listening to sat several screens down. It is also deliberately OUTSIDE
    // the Listen tab: audio carries on while you look at something else, and a
    // pause button you have to go and find is not a pause button.
    playerBar = new LinearLayout(this);
    playerBar.setOrientation(LinearLayout.VERTICAL);
    playerBar.setBackgroundColor(Color.WHITE);
    playerBar.setPadding(dp(16), dp(8), dp(16), dp(8));
    playerBar.setVisibility(View.GONE);
    root.addView(playerBar);

    tabBar = new LinearLayout(this);
    tabBar.setOrientation(LinearLayout.HORIZONTAL);
    tabBar.setBackgroundColor(Color.WHITE);
    root.addView(tabBar);
    setContentView(root);
  }

  private void showProblem(String message) {
    clearPages();
    body.removeAllViews();
    titleView.setText("");
    backButton.setVisibility(View.GONE);
    navButton.setVisibility(View.GONE);
    tabBar.setVisibility(View.GONE);
    searchSlot.removeAllViews();
    searchSlot.setVisibility(View.GONE);
    putKeyboardAway(null);
    shown = null;
    body.addView(text(message, 17, DANGER, false));
  }

  private void showMessageOnly(String message) {
    body.removeAllViews();
    backButton.setVisibility(View.GONE);
    navButton.setVisibility(View.GONE);
    tabBar.setVisibility(View.GONE);
    body.addView(text(message, 15, MUTED, false));
  }

  // ---- session -----------------------------------------------------------------------------

  @Override public String token() { return token; }

  @Override public Map<String, Object> description() {
    // All UI and session vocabulary comes from this build's bundled definition.
    return description.current;
  }

  @Override public void signedOut() {
    if (!signedIn && token == null) return;
    keepSession(null);
    Log.i(TAG, "signed out");
    showSignIn();
  }

  private void signedInWith(String newToken) {
    if (!keepSession(newToken)) return;
    Log.i(TAG, "signed in");
    showTabs();
  }

  /** Persist the identity, then synchronously clear every old-account consumer. */
  private boolean keepSession(String next) {
    if (java.util.Objects.equals(token, next)) return true;
    if (next == null) store.clear();
    else if (!store.write(next)) return false;
    http.invalidate();
    pictures.sessionChanged();
    for (Page page : stack) page.leave();
    token = next;
    HeyAndroidPlayback held = HeyAndroidPlayback.existing();
    if (held != null) held.changeSession(next);
    return true;
  }

  private void showSignIn() {
    signedIn = false;
    clearPages();
    tab = null;
    String id = Values.string(Json.dict(description.current.get("session")).get("sign_in_screen"));
    Map<String, Object> screen = description.screenNamed(id);
    if (screen == null || !Screens.drawsScreen(screen)) {
      showProblem("This app cannot draw its sign-in screen. Update it.");
      return;
    }
    stack.add(new Page(screen, null));
    render();
    load(top());
  }

  private List<String> drawnTabs() {
    List<String> out = new ArrayList<>();
    for (Object t : Json.list(description.current.get("tabs"))) {
      Map<String, Object> screen = description.screenNamed(Values.string(t));
      if (screen != null && Screens.drawsScreen(screen)) out.add(Values.string(t));
    }
    return out;
  }

  private void showTabs() {
    signedIn = true;
    List<String> tabs = drawnTabs();
    if (tabs.isEmpty()) {
      showProblem("This app cannot draw any of this server's tabs. Update it.");
      return;
    }
    if (tab == null || !tabs.contains(tab)) tab = tabs.get(0);
    selectTab(tab);
  }

  private void selectTab(String id) {
    tab = id;
    clearPages();
    stack.add(new Page(description.screenNamed(id), null));
    render();
    load(top());
    trackScreen(top());
  }

  // OPTIONAL PRODUCT TELEMETRY comes entirely from the description. The host
  // knows only that a signed-in screen became visible; it does not know a
  // product event name or endpoint. A measurement failure changes no UI.
  private void trackScreen(Page page) {
    if (!signedIn || token == null || token.isEmpty() || page == null) return;
    Map<String, Object> route = Json.dict(Json.dict(description.current.get("telemetry")).get("screen_view"));
    if (route.isEmpty()) return;
    Map<String, Object> vars = new LinkedHashMap<>();
    vars.put("screen", page.id());
    http.send(route, vars, null, (status, json, error) -> {
      if (error != null) Log.i(TAG, "telemetry: screen " + page.id() + " was not recorded");
    });
  }

  // ---- navigation --------------------------------------------------------------------------

  private void clearPages() {
    if (activePrompt != null) activePrompt.dismiss();
    speechTarget = null;
    speechEditor = null; speechDialog = null; speechDraft = null;
    for (Page page : stack) page.leave();
    stack.clear();
  }

  private Page top() { return stack.isEmpty() ? null : stack.get(stack.size() - 1); }

  private void push(String id, Map<String, Object> params) {
    Map<String, Object> screen = description.screenNamed(id);
    if (screen == null || !Screens.drawsScreen(screen)) {
      Log.i(TAG, "screen not drawn by this build: " + id);
      return;
    }
    if (top() != null) top().leave();
    stack.add(new Page(screen, params));
    Log.i(TAG, "opened: " + id);
    render();
    load(top());
    trackScreen(top());
  }

  private void goBack() {
    if (stack.size() <= 1) return;
    top().leave();
    stack.remove(stack.size() - 1);
    Page page = top();
    Log.i(TAG, "back to: " + page.id());
    render();
    if (page.type().equals("list")) load(page);
    trackScreen(page);
  }

  private void syncBack() {
    OnBackInvokedDispatcher dispatcher = getOnBackInvokedDispatcher();
    boolean want = stack.size() > 1;
    if (want && !backRegistered) {
      dispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, back);
      backRegistered = true;
    } else if (!want && backRegistered) {
      dispatcher.unregisterOnBackInvokedCallback(back);
      backRegistered = false;
    }
  }

  // ---- drawing -----------------------------------------------------------------------------

  private void render() {
    Page page = top();
    if (page == null) return;
    // LEAVING A SCREEN PUTS THE KEYBOARD AWAY: a tab, a push, Back, sign-out.
    // Nothing on the next screen asked for it, and a search screen returned to
    // shows its box without focus, so the keyboard does not rise by itself.
    if (page != shown) {
      putKeyboardAway(shown == null ? null : "left " + shown.id());
      shown = page;
    }
    titleView.setText(page.title);
    backButton.setVisibility(stack.size() > 1 ? View.VISIBLE : View.GONE);
    syncBack();
    drawNav(page);
    drawTabBar();
    body.removeAllViews();
    drawPlayerBar();
    drawSearchBox(page);
    if (page.type().equals("form")) drawForm(page);
    else if (page.type().equals("search")) drawSearch(page);
    else if (page.type().equals("audio")) drawAudio(page);
    else drawList(page);
  }

  private void drawNav(Page page) {
    Map<String, Object> nav = Json.dict(page.screen.get("nav_left"));
    if (nav.isEmpty()) nav = Json.dict(page.screen.get("nav_right"));
    Map<String, Object> navScreen = description.screenNamed(Values.string(nav.get("screen")));
    if (!nav.isEmpty() && navScreen != null && Screens.drawsScreen(navScreen) && signedIn) {
      navButton.setText(Values.string(nav.get("title")));
      navButton.setVisibility(View.VISIBLE);
      final Map<String, Object> spec = nav;
      navButton.setOnClickListener(v -> push(Values.string(spec.get("screen")), Screens.params(spec.get("params"), page.vars, null, page.json)));
    } else {
      navButton.setVisibility(View.GONE);
    }
  }

  private void drawTabBar() {
    tabBar.removeAllViews();
    if (!signedIn) {
      tabBar.setVisibility(View.GONE);
      return;
    }
    tabBar.setVisibility(View.VISIBLE);
    for (String id : drawnTabs()) {
      Map<String, Object> screen = description.screenNamed(id);
      String title = Values.string(Json.dict(screen.get("tab")).get("title"));
      if (title.isEmpty()) title = Values.string(screen.get("title"));
      TextView t = controlText(title, 14, id.equals(tab) ? ACCENT : MUTED, id.equals(tab));
      t.setGravity(Gravity.CENTER);
      t.setPadding(0, dp(14), 0, dp(14));
      t.setOnClickListener(v -> selectTab(id));
      tabBar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    }
  }

  private LinearLayout card() {
    LinearLayout c = new LinearLayout(this);
    c.setOrientation(LinearLayout.VERTICAL);
    c.setBackgroundColor(Color.WHITE);
    c.setPadding(dp(16), dp(12), dp(16), dp(12));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    lp.topMargin = dp(1);
    c.setLayoutParams(lp);
    return c;
  }

  /**
   * A row's picture: the space is taken immediately and filled when the bytes
   * arrive, so a list does not jump about as pictures land under the finger.
   *
   * <p>16:9 because that is the shape the descriptions this renderer draws use
   * for a thumbnail, and a fixed shape is what lets the space be reserved
   * before anything at all is known about the file.
   */
  private ImageView picture(String address) {
    ImageView view = new ImageView(this);
    view.setScaleType(ImageView.ScaleType.CENTER_CROP);
    view.setBackgroundColor(GROUND);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(88), dp(50));
    lp.setMargins(0, 0, dp(10), 0);
    view.setLayoutParams(lp);
    Bitmap already = pictures.held(address, false);
    if (already != null) {
      view.setImageBitmap(already);
      return view;
    }
    // The address is checked again on arrival: this view is drawn fresh per
    // render, but a reload can land while an older fetch is still in flight.
    view.setTag(address);
    pictures.want(address, false, drawn -> {
      if (address.equals(view.getTag())) view.setImageBitmap(drawn);
    });
    return view;
  }

  /**
   * The picture at the top of a thing's own screen: as large as it comes and
   * whole.
   *
   * <p>FIT, NOT CROP, and a height rather than a shape. What arrives here is a
   * portrait poster as often as a wide frame, and one fixed shape has to cut
   * one of them: cropping a poster to a letterbox takes the face off it. Given
   * a width and a ceiling on height, both kinds are shown entire.
   */
  private ImageView headerPicture(String address) {
    ImageView view = new ImageView(this);
    view.setScaleType(ImageView.ScaleType.FIT_CENTER);
    view.setAdjustViewBounds(true);
    view.setMaxHeight(dp(280));
    view.setMinimumHeight(dp(160));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    lp.setMargins(0, dp(4), 0, dp(10));
    view.setLayoutParams(lp);
    Bitmap already = pictures.held(address, true);
    if (already != null) {
      view.setImageBitmap(already);
      return view;
    }
    view.setTag(address);
    pictures.want(address, true, drawn -> {
      if (address.equals(view.getTag())) view.setImageBitmap(drawn);
    });
    return view;
  }

  private void tappable(View v, Runnable r) {
    TypedValue ripple = new TypedValue();
    getTheme().resolveAttribute(android.R.attr.selectableItemBackground, ripple, true);
    v.setForeground(getDrawable(ripple.resourceId));
    v.setClickable(true);
    v.setOnClickListener(x -> r.run());
    forwardTextClicks(v, r);
  }

  // Selectable TextViews can report that they are clickable even though they
  // have no app click handler. Always install the row handler for these
  // labels; Android still owns long-press selection and its copy toolbar.
  private void forwardTextClicks(View root, Runnable action) {
    if (!(root instanceof ViewGroup)) return;
    ViewGroup group = (ViewGroup) root;
    for (int i = 0; i < group.getChildCount(); i++) {
      View child = group.getChildAt(i);
      if (child instanceof TextView) {
        child.setOnClickListener(view -> action.run());
        long[] downAt = {0};
        float[] downX = {0};
        float[] downY = {0};
        boolean[] moved = {false};
        int touchSlop = ViewConfiguration.get(child.getContext()).getScaledTouchSlop();
        child.setOnTouchListener((view, event) -> {
          switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
              downAt[0] = event.getEventTime();
              downX[0] = event.getX();
              downY[0] = event.getY();
              moved[0] = false;
              return false;
            case MotionEvent.ACTION_MOVE:
              float dx = event.getX() - downX[0];
              float dy = event.getY() - downY[0];
              if (dx * dx + dy * dy > touchSlop * touchSlop) moved[0] = true;
              return false;
            case MotionEvent.ACTION_UP:
              long held = event.getEventTime() - downAt[0];
              downAt[0] = 0;
              if (!moved[0] && held < ViewConfiguration.getLongPressTimeout()) {
                action.run();
                return true;
              }
              return false;
            case MotionEvent.ACTION_CANCEL:
              downAt[0] = 0;
              moved[0] = true;
              return false;
            default:
              return false;
          }
        });
      } else if (child instanceof ViewGroup) {
        forwardTextClicks(child, action);
      }
    }
  }

  /**
   * A search screen: a box to type in, then exactly the list machinery.
   *
   * <p>Its sections are ordinary route sections -- {@code list}, {@code row},
   * {@code select} and a {@code request} -- so everything below the box is
   * already built. What it adds is the one thing that makes them a SEARCH: the
   * request bodies say {@code $query}, and nothing is asked until there is one.
   *
   * <p>NOTHING IS ASKED WHILE SOMEBODY IS STILL TYPING. The request goes when
   * they press search on the keyboard, not per keystroke: these routes reach
   * other people's services, and a fetch per letter is a good way to have an
   * address blocked.
   *
   * <p>The box itself is not drawn here but by drawSearchBox, above the body.
   */
  private void drawSearch(Page page) {
    // A SEARCH WITH NOTHING TYPED CAN SHOW SOMETHING (0.4.16, idle_sections):
    // what the screen is for before a search, drawn as a list from idle_source.
    Map<String, Object> idle = Screens.idleView(page.screen);
    if (idle != null && page.query.isEmpty()) {
      drawList(page, idle);
      return;
    }
    String hint = Values.string(page.screen.get("hint"));
    if (!hint.isEmpty() && page.query.isEmpty()) {
      TextView t = text(hint, 13, MUTED, false);
      t.setPadding(dp(4), dp(8), dp(4), dp(4));
      body.addView(t);
    }
    if (page.query.isEmpty()) return;
    drawSearchState(page);
    drawList(page);
  }

  /**
   * Above the results: whether the search is still running, found nothing, or
   * failed. A section that has not answered draws as its bare title, and
   * without this line "still asking" and "found nothing" looked the same.
   */
  private void drawSearchState(Page page) {
    Screens.SearchState state = Screens.searchState(page.screen, page.json, page.query, page.routes);
    LinearLayout line = new LinearLayout(this);
    line.setOrientation(LinearLayout.HORIZONTAL);
    line.setGravity(Gravity.CENTER_VERTICAL);
    line.setPadding(dp(4), dp(10), dp(4), dp(2));
    switch (state) {
      case SEARCHING: {
        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        line.addView(spinner, new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView t = text("Searching for “" + page.query + "”…", 15, MUTED, false);
        t.setPadding(dp(10), 0, 0, 0);
        line.addView(t);
        break;
      }
      case EMPTY: {
        String said = Screens.noResults(page.screen, page.json, page.query);
        if (said.isEmpty()) { Log.i(TAG, "search state: " + page.id() + " empty"); return; }
        line.addView(text(said, 17, Color.BLACK, true));
        break;
      }
      case FAILED: {
        line.addView(text("The search did not finish.", 15, DANGER, false),
            new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView again = text("Try again", 15, ACCENT, false);
        again.setPadding(dp(12), dp(6), dp(4), dp(6));
        tappable(again, () -> ask(page, page.query));
        line.addView(again);
        break;
      }
      default:
        return;
    }
    body.addView(line);
    Log.i(TAG, "search state: " + page.id() + " " + state.name().toLowerCase());
  }

  /** Show the page's search box in the slot above the body, or empty the slot. */
  private void drawSearchBox(Page page) {
    if (!page.type().equals("search")) {
      searchSlot.removeAllViews();
      searchSlot.setVisibility(View.GONE);
      return;
    }
    if (page.searchBox == null) buildSearchBox(page);
    if (page.searchBox.getParent() != searchSlot) {
      searchSlot.removeAllViews();
      searchSlot.addView(page.searchBox);
    }
    searchSlot.setVisibility(View.VISIBLE);
  }

  /**
   * The box and its Cancel, made once per page.
   *
   * <p>THE KEYBOARD CAN ALWAYS BE PUT AWAY, with the box empty or not. Cleared,
   * the search key had nothing to do and the screen offered no other way down,
   * so the tabs sat behind the keyboard until a new search was typed. Now:
   * Cancel, the search key, a touch anywhere below the box (a tap, or the start
   * of a drag through the results), system Back, and leaving the screen.
   */
  private void buildSearchBox(Page page) {
    LinearLayout box = card();
    box.setOrientation(LinearLayout.HORIZONTAL);
    box.setGravity(Gravity.CENTER_VERTICAL);
    EditText field = new EditText(this);
    field.setHint(Values.string(page.screen.get("placeholder")));
    field.setText(page.query);
    // ORDER MATTERS: setInputType RESETS the IME options, so setting the action
    // first leaves the keyboard showing Return and the search never runs.
    field.setInputType(InputType.TYPE_CLASS_TEXT);
    field.setSingleLine(true);
    field.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
    field.setContentDescription(page.title);
    field.setOnEditorActionListener((v, actionId, event) -> {
      // A keyboard may send its own idea of "go": the search key, Done, Go, or
      // a plain Enter with no action id at all. All of them mean search here.
      boolean go = actionId == EditorInfo.IME_ACTION_SEARCH
          || actionId == EditorInfo.IME_ACTION_DONE
          || actionId == EditorInfo.IME_ACTION_GO
          || (actionId == EditorInfo.IME_ACTION_UNSPECIFIED && event != null
              && event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
      if (!go) return false;
      // Searching is done typing: the results are what is wanted on screen now.
      putKeyboardAway("search");
      ask(page, field.getText().toString());
      return true;
    });
    TextView cancel = controlText("Cancel", 17, ACCENT, false);
    cancel.setPadding(dp(12), dp(8), dp(4), dp(8));
    cancel.setVisibility(page.query.isEmpty() ? View.GONE : View.VISIBLE);
    cancel.setOnClickListener(v -> {
      putKeyboardAway("cancel");
      field.setText("");
      showCancel(page);
    });
    field.setOnFocusChangeListener((v, focused) -> showCancel(page));
    field.addTextChangedListener(new TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
      @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
      @Override public void afterTextChanged(Editable s) {
        if (page.cancel != null) showCancel(page);
        // EMPTIED IS CLEARED: results under an empty box answer a search that
        // is no longer there. Nothing is asked for an empty query.
        if (s.length() == 0 && !page.query.isEmpty()) ask(page, "");
      }
    });
    box.addView(field, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    if (Boolean.TRUE.equals(page.screen.get("speech_input"))) {
      // No RECORD_AUDIO permission: the OS speech recognizer is a separate
      // activity and owns the recording/consent. The app receives text only.
      ImageButton microphone = new ImageButton(this);
      microphone.setImageResource(android.R.drawable.ic_btn_speak_now);
      microphone.setContentDescription("Search by voice");
      microphone.setMinimumWidth(dp(48));
      microphone.setMinimumHeight(dp(48));
      microphone.setOnClickListener(v -> startSpeechSearch(page));
      box.addView(microphone, new LinearLayout.LayoutParams(dp(48), dp(48)));
    }
    box.addView(cancel);
    page.searchBox = box;
    page.field = field;
    page.cancel = cancel;
  }

  /** Record by intent rather than shipping a product-specific microphone stack.
   * The device's speech activity handles permission and gives back transcripts.
   */
  private void startSpeechSearch(Page page) {
    if (page != top() || !page.type().equals("search")) return;
    startSystemSpeech(page, null, null);
  }

  /** Shared field wrapper for editable prose in forms and action prompts. */
  private View dictationEntry(Page page, Map<String, Object> field, EditText edit, boolean prompt) {
    String kind = Values.string(field.get("kind"));
    if (!Boolean.TRUE.equals(field.get("speech_input"))
        || !(kind.equals("multiline") || kind.equals("prose"))) return edit;
    LinearLayout entry = new LinearLayout(this);
    entry.setOrientation(LinearLayout.HORIZONTAL);
    entry.setGravity(Gravity.BOTTOM);
    entry.addView(edit, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    ImageButton microphone = new ImageButton(this);
    microphone.setImageResource(android.R.drawable.ic_btn_speak_now);
    microphone.setContentDescription("Dictate " + Values.string(field.get("label")));
    microphone.setMinimumWidth(dp(48));
    microphone.setMinimumHeight(dp(48));
    microphone.setOnClickListener(v -> {
      if (page != top()) return;
      if (prompt && (activePrompt == null || !activePrompt.isShowing())) return;
      startSystemSpeech(page, edit, prompt ? activePrompt : null);
    });
    entry.addView(microphone, new LinearLayout.LayoutParams(dp(48), dp(48)));
    return entry;
  }

  private void startSystemSpeech(Page page, EditText editor, AlertDialog dialog) {
    // Capture selection before removing focus: some keyboards move it on blur.
    speechTarget = page;
    speechEditor = editor;
    speechDialog = dialog;
    speechGeneration = page.generation;
    speechDraft = editor == null ? null : editor.getText().toString();
    speechStart = editor == null ? 0 : Math.max(0, editor.getSelectionStart());
    speechEnd = editor == null ? 0 : Math.max(0, editor.getSelectionEnd());
    putKeyboardAway(editor == null ? "voice search" : "dictation");
    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, editor == null ? "Speak a title or link" : "Dictate text");
    // Distinct request codes prevent an old activity result from consuming a
    // newer session, including one begun after navigation or account change.
    speechRequestCode = speechRequestCode == 65535 ? SPEECH_REQUEST_CODE : speechRequestCode + 1;
    try {
      startActivityForResult(intent, speechRequestCode);
    } catch (ActivityNotFoundException | SecurityException failure) {
      speechTarget = null;
      speechEditor = null; speechDialog = null; speechDraft = null;
      Toast.makeText(this, "Voice input is unavailable. You can still type.", Toast.LENGTH_LONG).show();
    }
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode != speechRequestCode) return;
    Page page = speechTarget;
    EditText editor = speechEditor;
    AlertDialog dialog = speechDialog;
    String draft = speechDraft;
    int begin = speechStart, end = speechEnd;
    int started = speechGeneration;
    speechTarget = null;
    speechEditor = null; speechDialog = null; speechDraft = null;
    // A canceled, empty, or stale result cannot overwrite a reply or search.
    if (page == null || page != top() || page.generation != started
        || resultCode != RESULT_OK || data == null) return;
    ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
    if (results == null || results.isEmpty()) return;
    String words = results.get(0) == null ? "" : results.get(0).trim();
    if (words.isEmpty()) return;
    if (editor != null) {
      if (!editor.isAttachedToWindow() || (dialog != null && !dialog.isShowing())
          || !editor.getText().toString().equals(draft)) return;
      // Edit the real widget; form watchers preserve draft and retry state.
      // Never render, submit, save or share from a speech callback.
      int lo = Math.min(begin, end), hi = Math.max(begin, end);
      if (hi > editor.length()) return;
      editor.getText().replace(lo, hi, words);
      editor.setSelection(lo + words.length());
    } else if (page.type().equals("search")) {
      if (page.field != null) page.field.setText(words);
      putKeyboardAway("voice search result");
      ask(page, words);
    }
  }

  /** Cancel is offered while there is a keyboard to put away or text to clear. */
  private void showCancel(Page page) {
    boolean want = page.field.hasFocus() || page.field.length() > 0;
    page.cancel.setVisibility(want ? View.VISIBLE : View.GONE);
  }

  /**
   * Hide the keyboard and take the focus off whatever had it, so nothing raises
   * it again until somebody taps a box. {@code why} is logged when given.
   */
  private void putKeyboardAway(String why) {
    if (root == null) return;
    InputMethodManager ime = getSystemService(InputMethodManager.class);
    if (ime != null) ime.hideSoftInputFromWindow(root.getWindowToken(), 0);
    View focused = getCurrentFocus();
    if (focused != null) focused.clearFocus();
    if (why != null) Log.i(TAG, "keyboard: put away (" + why + ")");
  }

  /**
   * A touch below a search screen's box puts the keyboard away: a tap on the
   * hint or the empty space, or the start of a drag through the results. The
   * touch is not taken -- a row still opens and a drag still scrolls.
   */
  @Override
  public boolean dispatchTouchEvent(MotionEvent event) {
    Page page = top();
    if (event.getActionMasked() == MotionEvent.ACTION_DOWN && page != null && page.field != null
        && page.field.hasFocus() && !inside(searchSlot, event)) {
      putKeyboardAway("touch outside");
    }
    return super.dispatchTouchEvent(event);
  }

  private static boolean inside(View view, MotionEvent event) {
    int[] at = new int[2];
    view.getLocationOnScreen(at);
    float x = event.getRawX();
    float y = event.getRawY();
    return x >= at[0] && x < at[0] + view.getWidth() && y >= at[1] && y < at[1] + view.getHeight();
  }

  /** Take a query and ask every section again from the beginning. */
  private void ask(Page page, String typed) {
    String query = typed == null ? "" : typed.trim();
    page.query = query;
    page.vars.put("query", query);
    page.values.put("query", query);
    page.routes.clear();
    page.polls.clear();
    page.message = null;
    // A NEW GENERATION EVEN FOR NOTHING. Answers and polls still on their way
    // for the last query check it and are dropped; clearing the box used to
    // leave them free to land, and the polls to keep asking.
    int generation = ++page.generation;
    if (query.isEmpty()) {
      render();
      loadIdle(page);
      return;
    }
    loadRoutes(page, generation);
  }

  /**
   * The Listen tab: what is playable, in the server's own groupings, with a bar
   * along the bottom for whatever is playing.
   *
   * <p>A row this build cannot play is DRAWN AND NOT OFFERED rather than
   * dropped. It is in the listener's queue either way, and the reason it will
   * not play here belongs on screen next to it -- a row that simply vanished
   * from one phone is a bug report waiting to happen.
   */
  private void drawAudio(Page page) {
    Map<String, Object> feed = Json.dict(description().get("audio"));
    usePlayback();
    List<Screens.AudioSection> sections = Screens.audio(feed, page.json, description.labels());

    if (page.message != null) body.addView(text(page.message, 15, DANGER, false));
    if (page.json != null && Screens.audioEmpty(sections)) {
      LinearLayout empty = new LinearLayout(this);
      empty.setOrientation(LinearLayout.VERTICAL);
      empty.setPadding(dp(4), dp(24), dp(4), dp(12));
      empty.addView(text(Values.string(feed.get("empty_title")), 22, Color.BLACK, true));
      empty.addView(text(Values.string(feed.get("empty")), 15, MUTED, false));
      body.addView(empty);
      return;
    }

    for (Screens.AudioSection section : sections) {
      if (!section.title.isEmpty()) {
        TextView t = text(section.title.toUpperCase(), 13, MUTED, false);
        t.setPadding(dp(4), dp(18), dp(4), dp(6));
        body.addView(t);
      }
      for (Screens.Track track : section.tracks) {
        body.addView(audioRow(track));
      }
      if (!section.note.isEmpty()) {
        TextView n = text(section.note, 13, MUTED, false);
        n.setPadding(dp(4), dp(6), dp(4), dp(4));
        body.addView(n);
      }
    }
  }

  private View audioRow(Screens.Track track) {
    LinearLayout c = card();
    LinearLayout line = new LinearLayout(this);
    line.setOrientation(LinearLayout.HORIZONTAL);
    line.setGravity(Gravity.CENTER_VERTICAL);
    if (HeyAndroidPictures.fetchable(track.image)) line.addView(picture(track.image));
    LinearLayout words = new LinearLayout(this);
    words.setOrientation(LinearLayout.VERTICAL);
    boolean holding = player != null && player.holding(track);
    TextView title = text(track.title, 17, holding ? ACCENT : Color.BLACK, holding);
    title.setMaxLines(2);
    words.addView(title);
    if (!track.subtitle.isEmpty()) words.addView(text(track.subtitle, 14, MUTED, false));
    if (!track.waiting && !track.playable) {
      // The honest reason, in the listener's words rather than a field name.
      String why = track.requires.equals("apple_music_subscription")
          ? "Plays on your iPhone, not here"
          : "Nothing to play here yet";
      words.addView(text(why, 13, MUTED, false));
    }
    line.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    c.addView(line);
    if (track.playable) tappable(c, () -> startTrack(track));
    return c;
  }

  /** The pinned bar: what is playing, and the one control it needs. */
  private void drawPlayerBar() {
    if (playerBar == null) return;
    playerBar.removeAllViews();
    if (player == null || player.state() == HeyAndroidPlayer.State.IDLE) {
      playerBar.setVisibility(View.GONE);
      playerClock = null;
      return;
    }
    playerBar.setVisibility(View.VISIBLE);
    startClock();
    Map<String, Object> feed = Json.dict(description().get("audio"));
    HeyAndroidPlayer.State state = player.state();
    Screens.Track track = player.track();
    LinearLayout c = playerBar;
    String said;
    switch (state) {
      case LOADING: said = Screens.says(feed, "loading"); break;
      case PLAYING: said = Screens.says(feed, "playing"); break;
      case PAUSED: said = Screens.says(feed, "paused"); break;
      default: said = Screens.says(feed, "failed"); break;
    }
    LinearLayout top = new LinearLayout(this);
    top.setOrientation(LinearLayout.HORIZONTAL);
    top.setGravity(Gravity.CENTER_VERTICAL);
    top.addView(text(said, 13, state == HeyAndroidPlayer.State.FAILED ? DANGER : MUTED, false),
        new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    playerClock = text(Screens.elapsed(player.seconds(), player.duration()), 13, MUTED, false);
    top.addView(playerClock);
    c.addView(top);
    if (track != null) c.addView(text(track.title, 16, Color.BLACK, false));
    if (state == HeyAndroidPlayer.State.PLAYING || state == HeyAndroidPlayer.State.PAUSED) {
      boolean playing = state == HeyAndroidPlayer.State.PLAYING;
      LinearLayout controls = new LinearLayout(this);
      controls.setOrientation(LinearLayout.HORIZONTAL);
      controls.setGravity(Gravity.CENTER_VERTICAL);
      controls.setPadding(0, dp(8), 0, 0);
      controls.addView(skipButton(Screens.skipBack()));
      TextView button = text(Screens.says(feed, playing ? "pause" : "play"), 17, ACCENT, false);
      button.setPadding(dp(24), 0, dp(24), 0);
      tappable(button, () -> {
        if (playing) player.pause();
        else player.resume();
      });
      controls.addView(button);
      controls.addView(skipButton(Screens.skipOn()));
      c.addView(controls);
    }
  }

  /**
   * A jump back or on. Labelled with its own number of seconds, because a
   * listener pressing one wants to know how far it goes, and two unlabelled
   * arrows do not say.
   */
  private TextView skipButton(int delta) {
    String said = delta < 0 ? ("\u21ba " + (-delta)) : (delta + " \u21bb");
    TextView button = text(said, 17, ACCENT, false);
    button.setPadding(dp(4), 0, dp(4), 0);
    tappable(button, () -> player.skip(delta));
    return button;
  }

  /**
   * Count the running time once a second while something is playing.
   *
   * <p>One loop, ever: it stops when nothing is playing and is started again by
   * the next draw. It touches one view, so it costs nothing next to a render.
   */
  private void startClock() {
    if (clockRunning) return;
    clockRunning = true;
    body.postDelayed(new Runnable() {
      @Override public void run() {
        if (player == null || player.state() == HeyAndroidPlayer.State.IDLE || playerClock == null) {
          clockRunning = false;
          return;
        }
        playerClock.setText(Screens.elapsed(player.seconds(), player.duration()));
        body.postDelayed(this, 1000);
      }
    }, 1000);
  }

  /**
   * A rating as five tappable stars.
   *
   * <p>The value is HALVES, 0 to 10, which is what the server keeps and what
   * every list already shows through {stars:...}. A tap lands on the left or
   * right half of a star depending on where the finger is, and tapping the
   * value it already holds clears it -- otherwise a rating given by accident
   * can never be taken off from a screen made only of stars.
   */
  private View starRow(Page page, String id) {
    LinearLayout row = new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.setPadding(0, dp(4), 0, dp(4));
    long halves = Values.integer(page.values.get(id));
    for (int i = 1; i <= 5; i++) {
      final int index = i;
      int state = Screens.starState(i, halves);
      TextView star = text(state == 0 ? "\u2606" : "\u2605", 30, ACCENT, false);
      // A HALF IS A WHOLE STAR DRAWN FAINTLY. No font is needed for it, which
      // matters: the half-star character is missing on this very device.
      star.setAlpha(state == 1 ? 0.45f : 1f);
      star.setPadding(dp(2), 0, dp(2), 0);
      star.setOnTouchListener((v, event) -> {
        if (event.getAction() != android.view.MotionEvent.ACTION_UP) return true;
        boolean leftHalf = event.getX() < v.getWidth() / 2.0f;
        long now = Values.integer(page.values.get(id));
        page.values.put(id, String.valueOf(Screens.ratingFromTap(index, leftHalf, now)));
        page.edited(id);
        render();
        return true;
      });
      row.addView(star);
    }
    TextView said = text(halves > 0 ? Values.stars(halves) : "Not rated", 13, MUTED, false);
    said.setPadding(dp(10), dp(10), 0, 0);
    row.addView(said);
    row.setContentDescription("Rating, " + (halves / 2.0) + " of 5");
    return row;
  }

  /**
   * Play a film without leaving the app.
   *
   * <p>VideoView, because this build has only the framework: no ExoPlayer and
   * no media3. It is enough for what this description points at -- short files
   * on this app's own server -- and it carries no credential, exactly as the
   * iPhone's player does not.
   */
  /**
   * An address as the description writes it, made whole.
   *
   * <p>A description names this app's own files by PATH -- "/faq/video/x.mp4" --
   * and anything elsewhere by its full address. One rule for both, in one
   * place: playVideo learned this the hard way, handing "/faq/video/signup.mp4"
   * to a player that had no idea which host it belonged to.
   */
  private String fullAddress(String address) {
    if (address == null) return "";
    return address.startsWith("/") ? http.origin + address : address;
  }

  private void playVideo(String raw) {
    String address = fullAddress(raw);
    if (address.isEmpty()) return;
    android.app.Dialog dialog = new android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
    FrameLayout frame = new FrameLayout(this);
    frame.setBackgroundColor(Color.BLACK);
    android.widget.VideoView video = new android.widget.VideoView(this);
    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    lp.gravity = Gravity.CENTER;
    video.setLayoutParams(lp);
    android.widget.MediaController controls = new android.widget.MediaController(this);
    controls.setAnchorView(video);
    video.setMediaController(controls);
    video.setVideoURI(Uri.parse(address));
    // A FILM THAT WILL NOT PLAY CLOSES RATHER THAN SITTING BLACK: a still,
    // silent, full-screen nothing is indistinguishable from a frozen app.
    video.setOnErrorListener((mp, what, extra) -> {
      Log.i(TAG, "video failed: " + address + " (what=" + what + " extra=" + extra + ")");
      dialog.dismiss();
      Toast.makeText(this, "That video would not play.", Toast.LENGTH_SHORT).show();
      return true;
    });
    video.setOnCompletionListener(mp -> dialog.dismiss());
    video.setOnPreparedListener(mp -> video.start());
    frame.addView(video);
    frame.setOnClickListener(v -> dialog.dismiss());
    dialog.setContentView(frame);
    dialog.setOnDismissListener(d -> video.stopPlayback());
    dialog.show();
  }

  private void startTrack(Screens.Track track) {
    usePlayback();
    player.play(track, playback.headers(), this, http.origin);
  }

  /**
   * Take hold of the process's player and start the service that carries it.
   *
   * <p>STARTING THE SERVICE IS WHAT LETS IT PLAY ON. A player owned by an
   * Activity alone stops when the Activity does; the media service is the
   * component allowed to keep going, and it is also the thing a car talks to.
   */
  private void usePlayback() {
    if (playback != null) return;
    playback = HeyAndroidPlayback.of(this);
    player = playback.player;
    playback.watch(onPlaybackChanged);
    // ASKED FOR ONLY WHEN SOMETHING IS ABOUT TO PLAY. Since Android 13 a
    // notification needs permission, and the media notification is what keeps
    // audio alive off screen -- but asking on first launch, before anyone has
    // pressed play, is a prompt with no visible reason for being there.
    if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
      try {
        requestPermissions(new String[] {android.Manifest.permission.POST_NOTIFICATIONS}, 1);
      } catch (Exception e) {
        Log.i(TAG, "could not ask about notifications: " + e);
      }
    }
    try {
      startService(new Intent(this, HeyAndroidAudioService.class));
    } catch (Exception e) {
      // A refused start costs background playing and the car, not this screen.
      Log.i(TAG, "audio service did not start: " + e);
    }
  }

  private void onPlayerChanged() {
    if (token != null && playback.token() == null) { signedOut(); return; }
    Page page = top();
    if (page != null && page.type().equals("audio")) render();
    else drawPlayerBar();
  }

  private void drawList(Page page) {
    drawList(page, page.screen);
  }

  private void drawList(Page page, Map<String, Object> screen) {
    List<Screens.Element> elements = Screens.list(screen, page.json, page.message, page.routes, page.vars, description.labels());
    for (Screens.Element e : elements) {
      switch (e.kind) {
        case HEADER: {
          LinearLayout h = new LinearLayout(this);
          h.setOrientation(LinearLayout.VERTICAL);
          h.setPadding(dp(4), dp(8), dp(4), dp(12));
          if (HeyAndroidPictures.fetchable(e.image)) {
            View picture = headerPicture(e.image);
            if (e.url != null) {
              picture.setContentDescription(e.title.isEmpty() ? "Open content" : "Open " + e.title);
              picture.setFocusable(true);
              picture.setOnClickListener(v -> page.openUrl(e.url));
            }
            h.addView(picture);
          }
          if (!e.title.isEmpty()) h.addView(text(e.title, 24, Color.BLACK, true));
          if (!e.subtitle.isEmpty()) h.addView(text(e.subtitle, 15, MUTED, false));
          if (!e.body.isEmpty()) h.addView(text(e.body, 16, Color.DKGRAY, false));
          body.addView(h);
          break;
        }
        case MESSAGE:
          body.addView(text(e.title, 15, DANGER, false));
          break;
        case SECTION_TITLE: {
          TextView t = text(e.title.toUpperCase(), 13, MUTED, false);
          t.setPadding(dp(4), dp(18), dp(4), dp(6));
          body.addView(t);
          break;
        }
        case NOTE: {
          TextView t = text(e.title, 13, e.destructive ? DANGER : MUTED, false);
          t.setPadding(dp(4), dp(6), dp(4), dp(4));
          body.addView(t);
          break;
        }
        case FIELD: {
          LinearLayout c = card();
          c.addView(text(e.title, 13, MUTED, false));
          c.addView(text(e.subtitle, 16, e.url != null ? ACCENT : Color.BLACK, false));
          if (e.url != null) tappable(c, () -> page.openUrl(e.url));
          body.addView(c);
          break;
        }
        case BUTTON: {
          LinearLayout c = card();
          c.addView(text(e.title, 17, e.destructive ? DANGER : ACCENT, false));
          if (!e.subtitle.isEmpty()) c.addView(text(e.subtitle, 14, MUTED, false));
          tappable(c, () -> Actions.run(e.action, e.row, page, http));
          body.addView(c);
          break;
        }
        case ROW: {
          LinearLayout c = card();
          LinearLayout line = new LinearLayout(this);
          line.setOrientation(LinearLayout.HORIZONTAL);
          line.setGravity(Gravity.CENTER_VERTICAL);
          if (HeyAndroidPictures.fetchable(e.image)) line.addView(picture(e.image));
          LinearLayout words = new LinearLayout(this);
          words.setOrientation(LinearLayout.VERTICAL);
          TextView title = text(e.title, 17, Color.BLACK, false);
          title.setMaxLines(2);
          words.addView(title);
          if (!e.subtitle.isEmpty()) words.addView(text(e.subtitle, 14, MUTED, false));
          if (!e.body.isEmpty()) {
            TextView detail = text(e.body, 14, MUTED, false);
            if (!e.detailMultiline) detail.setMaxLines(3);
            words.addView(detail);
          }
          line.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
          if (e.tappable()) line.addView(text("›", 22, MUTED, false));
          c.addView(line);
          if (e.action != null) tappable(c, () -> Actions.run(e.action, e.row, page, http));
          else if (e.screen != null) tappable(c, () -> push(e.screen, e.params));
          else if (!e.video.isEmpty()) tappable(c, () -> playVideo(e.video));
          else if (e.url != null) tappable(c, () -> page.openUrl(e.url));
          body.addView(c);
          break;
        }
        default:
          break;
      }
    }
  }

  private int inputTypeFor(String kind, Map<String, Object> field) { return TextInputTraits.forField(kind, Values.string(field.get("id"))); }

  /** A separate dialog owns disclosure/loading; the form's EditTexts stay intact. */
  private void openChoice(Page page, Map<String,Object> field, TextView shown) {
    // Opening the picker is not a choice. Only a selection marks the field as
    // touched, so Cancel keeps whatever value the server supplied.
    if (page.choiceDialog != null) page.choiceDialog.dismiss();
    java.util.function.BooleanSupplier current = page.actionScope();
    LinearLayout rows = new LinearLayout(this);
    rows.setOrientation(LinearLayout.VERTICAL);
    rows.setPadding(dp(12), dp(8), dp(12), dp(8));
    ScrollView choicesScroll = new ScrollView(this);
    choicesScroll.addView(rows);
    AlertDialog dialog = new AlertDialog.Builder(this)
        .setTitle(Values.string(field.get("label"))).setView(choicesScroll)
        .setNegativeButton("Cancel", null).create();
    page.choiceDialog = dialog;
    dialog.setOnDismissListener(d -> {
      if (page.choiceDialog == dialog) page.choiceDialog = null;
      if (page.formNeedsRender && current.getAsBoolean()) { page.formNeedsRender = false; renderKeepingFocus(); }
    });
    java.util.function.BooleanSupplier active = () -> current.getAsBoolean()
        && page.choiceDialog == dialog && dialog.isShowing();
    java.util.function.Consumer<ChoiceTree> display = tree -> drawChoiceRows(page, field, shown, dialog, rows, tree, active);
    Map<String,Object> choices = Json.dict(field.get("choices"));
    Runnable[] load = new Runnable[1];
    // Each read is numbered and only the newest may write, as a form's own
    // source is. Retry starts nothing while a read is out, so a double tap
    // sends one request and an older failure cannot land beneath a tree.
    int[] request = {0};
    boolean[] reading = {false};
    load[0] = () -> {
      int mine = ++request[0];
      reading[0] = false;
      rows.removeAllViews();
      // Static choices remain available even if the remote source is unavailable.
      Map<String,Object> staticField = new LinkedHashMap<>(field);
      staticField.remove("choices");
      try { drawChoiceRows(page, field, shown, dialog, rows, ChoiceTree.parse(staticField, null), active); }
      catch (IllegalArgumentException invalid) {
        rows.addView(text("These choices could not be loaded.", 15, DANGER, false));
        return;
      }
      if (choices.isEmpty()) return;
      TextView loading = text("Loading choices…", 15, MUTED, false);
      rows.addView(loading);
      reading[0] = true;
      Actions.Reply reply = (status, json, error) -> {
        if (mine != request[0]) return;
        reading[0] = false;
        if (!active.getAsBoolean()) return;
        ChoiceTree tree = null;
        if (error == null) {
          try { tree = ChoiceTree.parse(field, json, description.labels()); }
          catch (IllegalArgumentException invalid) { error = "These choices could not be loaded."; }
        }
        if (tree != null) {
          String fieldId = Values.string(field.get("id"));
          for (Map.Entry<String, String> named : tree.labels().entrySet())
            page.choiceLabels.put(fieldId + "\u0000" + named.getKey(), named.getValue());
          String named = page.choiceLabels.get(fieldId + "\u0000" + Values.string(page.values.get(fieldId)));
          if (named != null && !page.touched.contains(fieldId)) shown.setText(named);
          display.accept(tree);
          return;
        }
        rows.removeView(loading);
        String said = error == null || error.isEmpty() || error.length() > 160 ? "Could not load choices." : error;
        TextView problem = text(said, 15, DANGER, false);
        rows.addView(problem);
        Button retry = new Button(this); retry.setText("Retry"); retry.setAllCaps(false);
        retry.setOnClickListener(v -> {
          if (!active.getAsBoolean() || reading[0] || mine != request[0]) return;
          v.setEnabled(false);
          load[0].run();
        });
        rows.addView(retry);
      };
      try { http.send(ChoiceTree.readRoute(field), page.vars, null, reply); }
      catch (IllegalArgumentException invalid) { reply.done(0, null, invalid.getMessage()); }
    };
    dialog.show();
    load[0].run();
  }

  private void drawChoiceRows(Page page, Map<String,Object> field, TextView shown,
      AlertDialog dialog, LinearLayout rows, ChoiceTree tree, java.util.function.BooleanSupplier active) {
    rows.removeAllViews();
    for (ChoiceTree.Row item : tree.rows()) {
      LinearLayout row = new LinearLayout(this);
      row.setGravity(Gravity.CENTER_VERTICAL);
      row.setPadding(dp(12 * item.depth), 0, 0, 0);
      if (item.children) {
        Button disclosure = new Button(this);
        disclosure.setText(tree.expanded(item.key) ? "▾" : "▸");
        disclosure.setContentDescription((tree.expanded(item.key) ? "Collapse " : "Expand ") + item.label);
        disclosure.setOnClickListener(v -> {
          if (!active.getAsBoolean()) return;
          tree.toggle(item.key); drawChoiceRows(page, field, shown, dialog, rows, tree, active);
        });
        row.addView(disclosure, new LinearLayout.LayoutParams(dp(56), dp(48)));
      } else if (item.key.startsWith("remote:")) {
        row.addView(new android.widget.Space(this), new LinearLayout.LayoutParams(dp(56), 1));
      }
      // The current value is marked: a check beside it, bold, and Selected for
      // TalkBack, so the picker says which choice is already made.
      boolean chosen = item.selectable
          && Values.string(page.values.get(Values.string(field.get("id")))).equals(item.value);
      TextView label = controlText(item.label, 16, item.selectable ? ACCENT : MUTED, chosen);
      label.setPadding(dp(8), dp(12), dp(8), dp(12));
      if (item.selectable) {
        label.setContentDescription("Select " + item.label);
        label.setSelected(chosen);
        if (chosen) label.setStateDescription("Selected");
        label.setOnClickListener(v -> {
          if (!active.getAsBoolean()) return;
          String id = Values.string(field.get("id"));
          page.values.put(id, item.value); page.choiceTitles.put(id, item.label);
          page.edited(id); shown.setText(item.label); dialog.dismiss();
        });
      }
      row.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
      if (chosen) {
        TextView check = controlText("✓", 18, ACCENT, true);
        check.setPadding(dp(8), 0, dp(8), 0);
        // The row's label already says Selected; the mark is for the eye.
        check.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        row.addView(check);
      }
      rows.addView(row);
    }
  }

  /**
   * A form loads its choices with it, as iOS does, so a stored id such as a
   * folder slug is shown by its label before the picker is ever opened. Only
   * the newest read per field, in the same page and account, may write. A
   * failure stays quiet here: opening the picker reads again and offers Retry.
   */
  private void loadChoiceLabels(Page page) {
    for (Map<String, Object> field : Screens.form(page.screen, page.vars).fields) {
      if (!"choice".equals(Values.string(field.get("kind"))) || Json.dict(field.get("choices")).isEmpty()) continue;
      String fieldId = Values.string(field.get("id"));
      int mine = page.choiceReads.merge(fieldId, 1, Integer::sum);
      java.util.function.BooleanSupplier current = page.actionScope();
      Actions.Reply reply = (status, json, error) -> {
        if (!current.getAsBoolean() || mine != page.choiceReads.get(fieldId) || error != null) return;
        ChoiceTree tree;
        try { tree = ChoiceTree.parse(field, json, description.labels()); }
        catch (IllegalArgumentException invalid) { return; }
        String key = fieldId + "\u0000" + Values.string(page.values.get(fieldId));
        String before = page.choiceLabels.get(key);
        for (Map.Entry<String, String> named : tree.labels().entrySet())
          page.choiceLabels.put(fieldId + "\u0000" + named.getKey(), named.getValue());
        String after = page.choiceLabels.get(key);
        if (after == null || after.equals(before)) return;
        if (page.choiceDialog != null) page.formNeedsRender = true;
        else if (top() == page) renderKeepingFocus();
      };
      try { http.send(ChoiceTree.readRoute(field), page.vars, null, reply); }
      catch (IllegalArgumentException invalid) { /* the picker reports it when opened */ }
    }
  }

  private void drawForm(Page page) {
    Screens.Form form = Screens.form(page.screen, page.vars);
    if (!form.header.isEmpty()) {
      TextView h = text(form.header, 15, MUTED, false);
      h.setPadding(dp(4), dp(12), dp(4), dp(8));
      body.addView(h);
    }
    for (Map<String, Object> field : form.fields) {
      String id = Values.string(field.get("id"));
      String kind = Values.string(field.get("kind"));
      LinearLayout c = card();
      c.addView(text(Values.string(field.get("label")), 13, MUTED, false));
      // A CHOICE IS PICKED, NOT TYPED. Drawn as a row that opens the options,
      // because a text box for "Kind" invites somebody to type a word the
      // server will refuse -- and because this field is REQUIRED, so leaving it
      // undrawn took the Save button with it.
      if (kind.equals("choice")) {
        String currentChoice = Values.string(page.values.get(id));
        TextView shown = controlText(page.choiceLabels.getOrDefault(id + "\u0000" + currentChoice,
            page.choiceTitles.getOrDefault(id, Screens.optionTitle(field, currentChoice))), 16, Color.BLACK, false);
        shown.setPadding(0, dp(6), 0, dp(6));
        shown.setContentDescription(Values.string(field.get("label")));
        if (!Screens.options(field).isEmpty() || !Json.dict(field.get("choices")).isEmpty()) {
          shown.setOnClickListener(v -> openChoice(page, field, shown));
          TypedValue tap = new TypedValue();
          getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tap, true);
          shown.setForeground(getDrawable(tap.resourceId));
        }
        c.addView(shown);
        body.addView(c);
        continue;
      }
      // FIVE STARS, AND THE LEFT HALF OF ONE IS WORTH A HALF. The form already
      // carries the sentence saying so; until now it said it beside nothing,
      // because this kind was not drawn.
      if (kind.equals("rating")) {
        c.addView(starRow(page, id));
        body.addView(c);
        continue;
      }
      EditText edit = new EditText(this);
      edit.setInputType(inputTypeFor(kind, field));
      edit.setHint(Values.string(field.get("placeholder")));
      edit.setText(Values.string(page.values.get(id)));
      edit.setContentDescription(Values.string(field.get("label")));
      if (kind.equals("multiline")) edit.setMinLines(3);
      if (id.equals("username")) edit.setAutofillHints(View.AUTOFILL_HINT_USERNAME);
      if (kind.equals("secure")) edit.setAutofillHints(View.AUTOFILL_HINT_PASSWORD);
      edit.addTextChangedListener(new TextWatcher() {
        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c2) {}
        @Override public void onTextChanged(CharSequence s, int a, int b, int c2) {}
        @Override public void afterTextChanged(Editable s) {
          page.values.put(id, s.toString());
          page.edited(id);
        }
      });
      c.addView(dictationEntry(page, field, edit, false));
      body.addView(c);
    }
    if (!form.footer.isEmpty()) {
      TextView f = text(form.footer, 13, MUTED, false);
      f.setPadding(dp(4), dp(8), dp(4), dp(4));
      body.addView(f);
    }
    TextView message = text(page.message == null ? "" : page.message, 15, DANGER, false);
    message.setPadding(dp(4), dp(8), dp(4), dp(8));
    message.setVisibility(page.message == null ? View.GONE : View.VISIBLE);
    if (form.primaryDrawn) {
      Button primary = new Button(this);
      page.formPrimary = primary;
      page.formModel = form;
      page.refreshPrimary();
      primary.setEnabled(!page.busy && !page.sharing);
      primary.setAllCaps(false);
      primary.setOnClickListener(v -> submit(page, form, primary, message));
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
      lp.topMargin = dp(12);
      body.addView(primary, lp);
    }
    body.addView(message);
    for (Screens.Element link : form.links) {
      LinearLayout c = card();
      c.addView(text(link.title, 17, ACCENT, false));
      if (link.action != null) tappable(c, () -> Actions.run(link.action, null, page, http));
      else tappable(c, () -> push(link.screen, link.params));
      body.addView(c);
    }
    if (!form.linksFooter.isEmpty()) {
      TextView f = text(form.linksFooter, 13, MUTED, false);
      f.setPadding(dp(4), dp(8), dp(4), dp(4));
      body.addView(f);
    }
    Log.i(TAG, "screen ready: " + page.id() + " (form, " + form.fields.size() + " fields, button " + form.primaryDrawn + ")");
  }

  private void submit(Page page, Screens.Form form, Button primary, TextView message) {
    if (page.busy || page.sharing) return;
    if (page.savedShare.matches(page.values)) {
      if (!Actions.shareResponse(page.savedShare.response(), page.savedShare.path(), page)) {
        page.alert("Sharing unavailable", "Your changes are saved, but the server returned no usable share link.");
      }
      return;
    }
    String problem = Screens.problem(page.screen, form, page.values);
    if (problem != null) {
      showFormMessage(page, message, problem);
      return;
    }
    java.util.function.BooleanSupplier current = page.actionScope();
    Map<String, Object> submitted = FormShareState.snapshot(page.values);
    int submittedEdits = page.typed;
    String submittedSession = token;
    List<Map<String, Object>> queue = Screens.requests(page.screen, submitted);

    page.busy = true;
    primary.setEnabled(false);
    if (!form.busyTitle.isEmpty()) primary.setText(form.busyTitle);
    showFormMessage(page, message, null);
    sendInOrder(page, submitted, current, queue, 0, null, (status, json, error) -> {
      if (!current.getAsBoolean()) return;

      page.busy = false;
      primary.setEnabled(true);
      primary.setText(form.primaryTitle);
      if (error != null) {
        showFormMessage(page, message, error);
        return;
      }
      Map<String, Object> success = Json.dict(Json.dict(page.screen.get("primary")).get("on_success"));
      String tokenPath = Values.string(success.get("store_token"));
      if (!tokenPath.isEmpty()) {
        String newToken = Values.string(Values.at(json, tokenPath));
        if (newToken.isEmpty()) {
          showFormMessage(page, message, Values.string(success.get("no_token")));
          return;
        }
        if (!keepSession(newToken)) {
          showFormMessage(page, message, "Signed in, but this phone would not keep the session.");
          return;
        }
        signedInWith(newToken);
        return;
      }
      if (page.typed == submittedEdits) page.savedShare.saved(success, submitted, json);
      page.refreshPrimary();
      showFormMessage(page, message, Values.line(success.get("message"), json, description.labels()));

      if (!Values.string(success.get("go")).isEmpty()) push(Values.string(success.get("go")), Screens.params(success.get("params"), page.values, json, null));
      if (success.get("then") != null) {
        // Some account-making flows must show one more screen before the app
        // switches to its signed-in root. Keep that session now, without
        // calling signedInWith(), so the next screen can make authenticated
        // requests; account-creation flows can use this for a one-time
        // intermediate screen before entering the signed-in application.
        String keepTokenPath = Values.string(success.get("keep_token"));
        if (!keepTokenPath.isEmpty()) {
          String newToken = Values.string(Values.at(json, keepTokenPath));
          if (newToken.isEmpty()) {
            showFormMessage(page, message, Values.string(success.get("no_token")));
            return;
          }
          if (!keepSession(newToken)) {
            showFormMessage(page, message, "Signed in, but this phone would not keep the session.");
            return;
          }
        }
        Map<String, Object> after = new LinkedHashMap<>();
        after.put("then", success.get("then"));
        Actions.after(after, page.values, json, page);
      }
      // The declared success navigation runs before choosing its presenter.
      // A later user navigation/session change still cancels image completion.
      String sharePath = Values.string(success.get("share"));
      if (!sharePath.isEmpty() && java.util.Objects.equals(submittedSession, token) && top() != null) {
        if (!Actions.shareResponse(json, sharePath, top())) top().toast("Saved, but no usable share link was returned.");
      }
    });
  }


  private void showFormMessage(Page page, TextView view, String text) {
    page.sourceError = null;
    page.message = text == null || text.isEmpty() ? null : text;
    view.setText(page.message == null ? "" : page.message);
    view.setVisibility(page.message == null ? View.GONE : View.VISIBLE);
    if (page.message != null) Log.i(TAG, "form message on " + page.id() + ": " + page.message);
  }

  private void sendInOrder(Page page, Map<String, Object> submitted, java.util.function.BooleanSupplier current,
      List<Map<String, Object>> queue, int index, Object last, Actions.Reply done) {
    if (!current.getAsBoolean()) return;

    if (index >= queue.size()) {
      done.done(200, last, null);
      return;
    }
    http.send(queue.get(index), submitted, null, (status, json, error) -> {
      if (!current.getAsBoolean()) return;
      if (error != null) done.done(status, json, error);
      else sendInOrder(page, submitted, current, queue, index + 1, json, done);
    });
  }

  // ---- loading -----------------------------------------------------------------------------

  private void load(Page page) {
    if (page == null) return;
    // A FORM LOADS TOO. This read `!page.type().equals("list")` and returned,
    // so a form screen never fetched its source -- and an EDIT form that does
    // not fetch is an edit form that opens blank and offers to replace what is
    // there with nothing. Reported from a phone: the item edit screen "shows a
    // blank screen (forgetting what already exists)".
    if (page.type().equals("form")) {
      // After loadForm: it starts a new generation, which would orphan these reads.
      loadForm(page);
      loadChoiceLabels(page);
      return;
    }
    // A SEARCH SCREEN ASKS NOTHING UNTIL IT IS ASKED. Its sections' requests all
    // want $query; sending them empty would fetch the whole of everything the
    // moment the tab is opened.
    if (page.type().equals("search")) {
      if (!page.query.isEmpty()) loadRoutes(page, ++page.generation);
      else loadIdle(page);
      return;
    }
    // AN AUDIO SCREEN'S SOURCE IS NOT ITS OWN. The screen in the description
    // carries no source at all; the whole feed comes from the description's
    // top-level audio block, which is shared with whatever a car is handed.
    if (page.type().equals("audio")) {
      Map<String, Object> feed = Json.dict(description().get("audio"));
      Map<String, Object> source = Json.dict(feed.get("source"));
      if (source.isEmpty()) return;
      int generation = ++page.generation;
      http.send(source, page.vars, null, (status, json, error) -> {
        if (generation != page.generation) return;
        page.json = error == null ? json : null;
        page.message = error;
        if (top() == page) render();
      });
      return;
    }
    if (!page.type().equals("list")) return;
    int generation = ++page.generation;
    Map<String, Object> source = Json.dict(page.screen.get("source"));
    if (source.isEmpty()) {
      loadRoutes(page, generation);
      return;
    }
    http.send(source, page.vars, null, (status, json, error) -> {
      if (generation != page.generation) return;
      page.json = error == null ? json : null;
      page.message = error;
      String titled = Values.line(page.screen.get("title_from"), json, description.labels());
      if (!titled.isEmpty()) page.title = titled;
      if (top() == page) render();
      loadRoutes(page, generation);
    });
  }

  /**
   * A form's starting values, fetched once and written into the fields.
   *
   * <p>Touched fields win independently; explicitly mapped metadata and other
   * untouched defaults can still arrive after somebody starts writing.
   */
  private void loadForm(Page page) {
    Map<String, Object> source = Screens.prefillSource(page.screen);
    if (source.isEmpty()) return;
    int generation = ++page.generation;
    java.util.function.BooleanSupplier current = page.actionScope();
    http.send(source, page.vars, null, (status, json, error) -> {
      if (!current.getAsBoolean()) return;
      if (error != null) {
        page.sourceError = error;
        page.message = error;
        // A failed source keeps the field being typed in and its cursor too.
        if (page.choiceDialog != null) page.formNeedsRender = true;
        else if (top() == page) renderKeepingFocus();
        return;
      }
      if (page.sourceError != null && java.util.Objects.equals(page.message, page.sourceError)) page.message = null;
      page.sourceError = null;
      page.json = json;
      for (Map.Entry<String, String> e : Screens.prefilled(page.screen, json).entrySet()) {
        if (!page.touched.contains(e.getKey())) page.values.put(e.getKey(), e.getValue());
      }
      String titled = Values.line(page.screen.get("title_from"), json, description.labels());
      if (!titled.isEmpty()) page.title = titled;
      if (page.choiceDialog != null) page.formNeedsRender = true;
      else if (top() == page) renderKeepingFocus();
    });
  }

  /**
   * Redraw after a late answer without taking the person out of the field they
   * are typing in: the same field gets focus back with its cursor where it was.
   */
  private void renderKeepingFocus() {
    View focused = getCurrentFocus();
    int index = -1, start = 0, end = 0;
    if (focused instanceof EditText) {
      List<EditText> before = new ArrayList<>();
      collectEdits(body, before);
      index = before.indexOf(focused);
      start = ((EditText) focused).getSelectionStart();
      end = ((EditText) focused).getSelectionEnd();
    }
    render();
    if (index < 0) return;
    List<EditText> after = new ArrayList<>();
    collectEdits(body, after);
    if (index >= after.size()) return;
    EditText again = after.get(index);
    int length = again.length();
    again.requestFocus();
    again.setSelection(Math.max(0, Math.min(start, length)), Math.max(0, Math.min(end, length)));
  }

  private static void collectEdits(View view, List<EditText> out) {
    if (view instanceof EditText) { out.add((EditText) view); return; }
    if (view instanceof ViewGroup) {
      ViewGroup group = (ViewGroup) view;
      for (int i = 0; i < group.getChildCount(); i++) collectEdits(group.getChildAt(i), out);
    }
  }

  /**
   * Ask a section again because its answer said it was still looking.
   *
   * <p>A find asks several services at once and answers straight away with
   * whatever it already has, marking itself pending. Without this the screen
   * kept that first answer -- usually empty -- and said "No service this app
   * knows has that title" about a search that had not finished.
   *
   * <p>BOUNDED BY THE DESCRIPTION, not by this build: poll.every_ms and
   * poll.max come from the screen, and the count is per section per query, so
   * a search that never settles stops asking instead of polling for ever.
   */
  private void pollAgain(Page page, int generation, int index, Map<String, Object> section, Map<String, Object> route) {
    int already = page.polls.containsKey(index) ? page.polls.get(index) : 0;
    if (already >= Screens.pollMax(section)) {
      // Out of polls: say so in the section's own words, and stop showing it as running.
      page.routes.put(index, Screens.gaveUp(section, page.routes.get(index)));
      if (top() == page) render();
      return;
    }
    page.polls.put(index, already + 1);
    body.postDelayed(() -> {
      if (generation != page.generation) return;
      http.send(route, page.vars, null, (status, json, error) -> {
        if (generation != page.generation) return;
        Screens.RouteRows answered = Screens.routeRows(section, json, error);
        page.routes.put(index, answered);
        if (top() == page) render();
        if (answered.pending) pollAgain(page, generation, index, section, route);
      });
    }, Screens.pollEvery(section));
  }

  /** An empty search screen with idle_sections reads idle_source, as a list screen reads its source. */
  private void loadIdle(Page page) {
    Map<String, Object> idle = Screens.idleView(page.screen);
    if (idle == null) return;
    Map<String, Object> source = Json.dict(idle.get("source"));
    if (source.isEmpty()) return;
    int generation = ++page.generation;
    http.send(source, page.vars, null, (status, json, error) -> {
      if (generation != page.generation || !page.query.isEmpty()) return;
      page.json = error == null ? json : null;
      page.message = error;
      if (top() == page) render();
    });
  }

  private void loadRoutes(Page page, int generation) {
    List<Map<String, Object>> sections = Screens.sections(page.screen);
    int asked = 0;
    for (int i = 0; i < sections.size(); i++) {
      Map<String, Object> section = sections.get(i);
      Map<String, Object> route = Screens.routeFor(section, page.json);
      if (route == null) continue;
      asked++;
      final int index = i;
      http.send(route, page.vars, null, (status, json, error) -> {
        if (generation != page.generation) return;
        Screens.RouteRows answered = Screens.routeRows(section, json, error);
        page.routes.put(index, answered);
        if (top() == page) render();
        if (answered.pending) pollAgain(page, generation, index, section, route);
      });
    }
    if (top() == page) render();
    int rows = 0;
    for (Screens.Element e : Screens.list(page.screen, page.json, page.message, page.routes, page.vars, description.labels())) {
      if (e.kind == Screens.Kind.ROW) rows++;
    }
    Log.i(TAG, "screen ready: " + page.id() + " (list, " + rows + " rows, " + asked + " route sections asked" + (page.message == null ? "" : ", message: " + page.message) + ")");
  }
}
