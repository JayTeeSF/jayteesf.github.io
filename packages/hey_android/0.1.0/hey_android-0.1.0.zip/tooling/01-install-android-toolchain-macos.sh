#!/usr/bin/env bash
set -euo pipefail

ANDROID_HOME="${ANDROID_HOME:-$HOME/Library/Android/sdk}"
ANDROID_API="${HEY_ANDROID_API:-34}"
ANDROID_BUILD_TOOLS="${HEY_ANDROID_BUILD_TOOLS:-34.0.0}"
ANDROID_NDK_VERSION="${HEY_ANDROID_NDK_VERSION:-26.1.10909125}"
ANDROID_CMAKE_VERSION="${HEY_ANDROID_CMAKE_VERSION:-3.22.1}"
GRADLE_VERSION="${HEY_ANDROID_GRADLE_VERSION:-8.7}"
ANDROID_AVD_NAME="${HEY_ANDROID_AVD_NAME:-Hey_API_34}"
ENV_FILE="${HEY_ANDROID_ENV_FILE:-$HOME/.config/hey/android.env}"
GRADLE_HOME="$HOME/.cache/hey/gradle-$GRADLE_VERSION"

fail() { printf 'error: %s\n' "$*" >&2; exit 1; }
step() { printf '\n== %s ==\n' "$*"; }

[ "$(uname -s)" = Darwin ] || fail "this installer currently supports macOS"
command -v brew >/dev/null 2>&1 || fail "Homebrew is required: https://brew.sh"

step "Install Android Studio, JDK 17, and Android command-line tools"
brew list --cask android-studio >/dev/null 2>&1 || brew install --cask android-studio
brew list --cask temurin@17 >/dev/null 2>&1 || brew install --cask temurin@17
brew list --cask android-commandlinetools >/dev/null 2>&1 || brew install --cask android-commandlinetools

JAVA_HOME="$(/usr/libexec/java_home -v 17 2>/dev/null || true)"
[ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/java" ] || fail "JDK 17 was not found after installation"

SDKMANAGER="$(command -v sdkmanager || true)"
AVDMANAGER="$(command -v avdmanager || true)"
[ -x "$SDKMANAGER" ] || fail "sdkmanager was not installed by android-commandlinetools"
[ -x "$AVDMANAGER" ] || fail "avdmanager was not installed by android-commandlinetools"

mkdir -p "$ANDROID_HOME"

case "$(uname -m)" in
  arm64) SYSTEM_IMAGE_ABI=arm64-v8a ;;
  x86_64) SYSTEM_IMAGE_ABI=x86_64 ;;
  *) fail "unsupported Mac architecture: $(uname -m)" ;;
esac

SYSTEM_IMAGE="system-images;android-$ANDROID_API;google_apis;$SYSTEM_IMAGE_ABI"

step "Accept Android SDK licenses"
yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null || true

step "Install the pinned Android SDK, NDK, CMake, emulator, and system image"
"$SDKMANAGER" --sdk_root="$ANDROID_HOME" \
  "platform-tools" \
  "platforms;android-$ANDROID_API" \
  "build-tools;$ANDROID_BUILD_TOOLS" \
  "emulator" \
  "ndk;$ANDROID_NDK_VERSION" \
  "cmake;$ANDROID_CMAKE_VERSION" \
  "$SYSTEM_IMAGE"

yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null || true

step "Install the pinned Gradle runner"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  tmp_dir="$(mktemp -d)"
  cleanup() { rm -rf "$tmp_dir"; }
  trap cleanup EXIT HUP INT TERM
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$tmp_dir/gradle.zip"
  unzip -q "$tmp_dir/gradle.zip" -d "$tmp_dir"
  mkdir -p "$(dirname "$GRADLE_HOME")"
  rm -rf "$GRADLE_HOME"
  mv "$tmp_dir/gradle-$GRADLE_VERSION" "$GRADLE_HOME"
  trap - EXIT HUP INT TERM
  cleanup
fi

step "Create the Android virtual device"
EMULATOR="$ANDROID_HOME/emulator/emulator"
if [ ! -x "$EMULATOR" ]; then
  fail "Android emulator missing after installation: $EMULATOR"
fi
if ! "$EMULATOR" -list-avds | grep -Fx "$ANDROID_AVD_NAME" >/dev/null 2>&1; then
  echo no | "$AVDMANAGER" create avd \
    --force \
    --name "$ANDROID_AVD_NAME" \
    --package "$SYSTEM_IMAGE"
fi

step "Write reusable Hey Android environment"
mkdir -p "$(dirname "$ENV_FILE")"
cat > "$ENV_FILE" <<EOF_ENV
export ANDROID_HOME="$ANDROID_HOME"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/$ANDROID_NDK_VERSION"
export JAVA_HOME="$JAVA_HOME"
export HEY_ANDROID_API="$ANDROID_API"
export HEY_ANDROID_BUILD_TOOLS="$ANDROID_BUILD_TOOLS"
export HEY_ANDROID_NDK_VERSION="$ANDROID_NDK_VERSION"
export HEY_ANDROID_CMAKE_VERSION="$ANDROID_CMAKE_VERSION"
export HEY_ANDROID_GRADLE_VERSION="$GRADLE_VERSION"
export HEY_ANDROID_AVD_NAME="$ANDROID_AVD_NAME"
export PATH="$GRADLE_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/emulator:$ANDROID_HOME/cmdline-tools/latest/bin:\$PATH"
EOF_ENV
chmod 600 "$ENV_FILE"

printf '\nAndroid toolchain installed.\n'
printf 'environment=%s\n' "$ENV_FILE"
printf 'avd=%s\n' "$ANDROID_AVD_NAME"
printf 'next: ./02-build-and-launch-hey-android.sh\n'
