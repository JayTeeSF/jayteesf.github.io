# Done

- Replaced the pre-`stdlib:web` 0.1.1 design with stdlib-first 0.1.2 modules.
- Added application/config/server/router/controller/view/jobs/client/command layers.
- Added resource routing, pure dispatch specs, curl-style argv planning, JSON bodies, status checking, and atomic download delegation.
- Added package, verification, roadmap, prompt, and continuation scripts.
- Verified the packed release through clean package install, lockfile pinning, installed-content verification, and compiled `pkg:` import.
- Kept public modules at package-root paths to match Hey 0.99.259a's current package resolver behavior.
- Added and passed `bin/check-live-http`, covering a real one-request localhost server/client exchange.
- Fixed `bin/hey-web` argument forwarding and avoided stale imported-module script caches by preferring `heyc --run --`.
- Added a regression spec for ERB-style EHY `<%= ... %>` interpolation and updated the executable package example to render an actual `.ehy` file.
