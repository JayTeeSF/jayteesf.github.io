# Done

- v0.1.0 package boundary, modules, tests, toolchain installer, emulator/device launcher, docs, packaging, and LLM handoff.
- Fixed the macOS installer so `sdkmanager` and `avdmanager` share the same exported Android SDK root before AVD creation.
- Fixed AVD creation by installing Android command-line tools inside the selected SDK and invoking those SDK-local binaries; Homebrew's avdmanager no longer resolves packages from its separate root.

## 0.2.0 (2026-09-13): a Hey program with the runtime, on Android 16, with no Java or Kotlin

- `tools/hey-android-app.sh` builds a Hey program into a signed APK:
  - heyc's LLVM IR, compiled by NDK r28 clang for `aarch64-linux-android35`;
  - the unmodified Hey runtime from HEY_ROOT with the package's Android profile;
  - one 16 KB-aligned library;
  - aapt2, zipalign `-P 16` and apksigner.
  - The manifest has `hasCode="false"` and uses `android.app.NativeActivity`.
  - It installs and launches with adb, then writes a receipt.
- `native/glue`, the entry point:
  - the program runs on an 8 MiB thread, and so do the runtime's own threads;
  - stdout and stderr go to logcat;
  - `exit()` finishes the activity;
  - one program per process.
- `native/runtime_profile` gives the runtime real secure random, constant-time
  compare and SHA-256 (vendored from Brad Conte, public domain) through its
  platform-crypto seam. TLS, AEAD, scrypt and Argon2id report named
  unavailable errors.
- Build isolation:
  - every compiler-search variable is cleared, and `PATH` is reduced;
  - the include search path goes into the receipt, and any host directory
    fails the build.
- `bin/android-doctor` checks and prints the new pins and the Hey checkout's
  identity: platform 36, build-tools 36.0.0, NDK 28.2.13676358, the API 36
  Play image, JDK 17. It fails with the exact sdkmanager line for anything
  missing.
- `tools/hey-android-emulator.sh` owns the dedicated AVD `hey_android_API_36`:
  - it boots headless;
  - it shuts down and waits until no emulator process remains.
- `bin/check` runs the Hey specs and five shell specs: pins, SHA-256 on the
  host, the doctor, the build lane and the emulator. Every check has a
  negative control:
  - a Mac target triple is refused;
  - a Homebrew-contaminated runtime is caught;
  - a 4 KB library is refused;
  - a dex in the APK is refused;
  - `hasCode="true"` is refused;
  - a wrong digest fails;
  - an API 34 SDK is refused;
  - a build linked without `--wrap=exit` fails.
- On the emulator:
  - `hello_runtime`'s logcat output equals the Mac run byte for byte;
  - the NIST vectors pass through the runtime;
  - a runtime error ends the activity with no crash.
- Removed the Gradle lane: `tooling/01-*`, `tooling/02-*` and their spec, with
  the API 34, AGP 8.5.2 and NDK 26.1 pins.
