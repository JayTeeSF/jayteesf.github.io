// Runs the shipped header renderer. Only the external browser launch is replaced.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wnullability-completeness"
#import "HeyIOSApiHost.m"
#pragma clang diagnostic pop
#import <objc/runtime.h>

const char *HeyIOSBakedOrigin(void) { return NULL; }
static NSMutableArray<NSURL *> *opened;
static NSInteger failures;
@interface HeaderBrowser : NSObject
- (void)openURL:(NSURL *)url options:(NSDictionary *)options completionHandler:(void (^)(BOOL))done;
@end
@implementation HeaderBrowser
- (void)openURL:(NSURL *)url options:(NSDictionary *)options completionHandler:(void (^)(BOOL))done {
  [opened addObject:url];
  if (done) done(YES);
}
@end
static void check(BOOL ok, NSString *message) {
  if (!ok) { fprintf(stderr, "header-link: %s\n", message.UTF8String); failures++; }
}
static NSArray<UIView *> *descendants(UIView *view) {
  NSMutableArray *all = [NSMutableArray array];
  for (UIView *child in view.subviews) { [all addObject:child]; [all addObjectsFromArray:descendants(child)]; }
  return all;
}
static void run(id binding, id destination, BOOL hasImage, NSString *expected) {
  NSMutableDictionary *header = [@{@"title": @"item.title", @"body": @"item.body"} mutableCopy];
  if (hasImage) header[@"image"] = @"item.image";
  if (binding) header[@"image_open_url"] = binding;
  NSMutableDictionary *item = [@{@"title": @"A title", @"body": @"A body", @"image": @"https://images.example.test/cover.jpg"} mutableCopy];
  if (destination) item[@"canonical_url"] = destination;
  UIView *view = HeyIOSHeaderView(header, @{@"item": item}, nil, 390);
  [view layoutIfNeeded];
  NSMutableArray<UIControl *> *links = [NSMutableArray array];
  for (UIView *child in descendants(view)) {
    if ([child isKindOfClass:UIControl.class]) [links addObject:(UIControl *)child];
    if ([child isKindOfClass:UILabel.class]) check(!child.userInteractionEnabled, @"header text became tappable");
  }
  check(links.count == (expected ? 1 : 0), [NSString stringWithFormat:@"wrong link count for binding=%@ destination=%@", binding, destination]);
  NSUInteger before = opened.count;
  for (UIControl *link in links) {
    check(link.isAccessibilityElement && link.accessibilityLabel.length > 0, @"link has no accessible name");
    check((link.accessibilityTraits & UIAccessibilityTraitLink) != 0, @"artwork is not announced as a link");
    check(fabs(link.bounds.size.height - 200) < 0.5 && link.bounds.size.width > 0, @"artwork link lost its visible tap area");
    for (UIView *child in descendants(link)) {
      if ([child isKindOfClass:UILabel.class]) {
        NSString *text = ((UILabel *)child).text;
        check(![text isEqualToString:@"A title"] && ![text isEqualToString:@"A body"], @"link includes header text");
      }
    }
    check([descendants(link) filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id child, NSDictionary *_) { return [child isKindOfClass:UIImageView.class]; }]].count == 1, @"link does not contain only the artwork");
    // A spawned command has no UIApplicationMain. Intercept only the browser
    // singleton during dispatch and execute the real control's registered action.
    Method shared = class_getClassMethod(UIApplication.class, @selector(sharedApplication));
    HeaderBrowser *browser = [[HeaderBrowser alloc] init];
    IMP replacement = imp_implementationWithBlock(^id(id cls) { return browser; });
    IMP original = method_setImplementation(shared, replacement);
    [link enumerateEventHandlers:^(UIAction *action, id target, SEL selector, UIControlEvents events, BOOL *stop) {
      if (events & UIControlEventTouchUpInside) [link sendAction:action];
    }];
    method_setImplementation(shared, original);
    imp_removeBlock(replacement);
  }
  check(opened.count - before == (expected ? 1 : 0), @"wrong number of browser launches");
  if (expected && opened.count > before) check([opened.lastObject.absoluteString isEqualToString:expected], @"browser opened a value other than canonical content URL");
}
int main(void) {
  @autoreleasepool {
    opened = [NSMutableArray array];
    // A cache hit keeps the real renderer from starting an image download.
    [HeyIOSImageCache() setObject:[[UIImage alloc] init] forKey:@"https://images.example.test/cover.jpg"];
    run(@"item.canonical_url", @"https://example.test/article?id=7#read", YES, @"https://example.test/article?id=7#read");
    run(@"item.canonical_url", @"http://example.test/book", YES, @"http://example.test/book");
    run(nil, @"https://example.test/article", YES, nil);
    run(@"", @"https://example.test/article", YES, nil);
    run(@"item.canonical_url", nil, YES, nil);
    run(@"item.canonical_url", NSNull.null, YES, nil);
    run(@"item.canonical_url", @"", YES, nil);
    run(@"item.canonical_url", @42, YES, nil);
    run(@"item.canonical_url", @{}, YES, nil);
    for (NSString *bad in @[@"javascript:alert(1)", @"file:///tmp/a", @"data:text/html,hi", @"myapp://item/1", @"/relative", @"//example.test/a", @"https://", @"https:article", @"not a url", @"https://example.test/with space", @" https://example.test/a", @"https://bad host/a"]) run(@"item.canonical_url", bad, YES, nil);
    run(@"item.canonical_url", @"https://example.test/article", NO, nil);
    if (failures) return 1;
    puts("hey_ios_header_image_link=true");
    return 0;
  }
}
