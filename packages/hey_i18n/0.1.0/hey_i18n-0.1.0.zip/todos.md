# Todo

1. First consuming application (RecallCoach string extraction) locked
   against 0.1.0.
2. CLDR plural rules for the next real locale a consumer ships.
3. RFC 4647 q-value ranking, only if header order proves insufficient.
