package android.net;
public class Uri {
  public final String address;
  private Uri(String address) { this.address = address; }
  public static Uri parse(String address) { return new Uri(address); }
}
