# hey_ios

Apple-specific capability contracts layered under `hey_mobile`. This first slice declares UIKit lifecycle hosting, Keychain, LocalAuthentication, protected files, AVFoundation QR scanning, URLSession, Apple frameworks, and entitlement metadata. Native adapters remain opaque; no Keychain item, LAContext, key, or UIKit object crosses into ordinary Hey values.

Compiler/SDK/sign/install/launch porcelain for ordinary Hey iOS apps remains in the Hey language repository under `hey mobile ios ...`.

## Searchable multi-select sheets (0.4.3)

A level-3 `choose_many` can now consume `choices.search` from `hey_mobile 0.3.4`. The sheet keeps its current ticked values while remote results arrive, merges unseen results by value, and computes Done from the post-search option set. The search route and option mapping stay in the description; the native host remains product-neutral.

`HeyIOSMergeOptions` is Foundation-only and runs against the same new level-3 conformance vectors as `hey_mobile`. `bin/check-searchable-choose-many` additionally syntax-checks the actual UIKit host for the iOS Simulator and proves the search bridge calls that helper.

## The running time and the skip controls, on the 0.4.x line (0.4.2)

The now playing bar's elapsed and total time, and the jump-back and
jump-on controls, were released as 0.3.4 and 0.3.5 from a branch. `main`
went to 0.4.0 and 0.4.1 without them, so the two newest releases did not
have what the two before them did: an app taking 0.4.1 lost the timer and
the skip buttons, and an app keeping 0.3.5 had no `--distribution` and no
level-3 audio. Nothing said so.

This rebases that work onto `main`, so 0.4.2 is the first release with
both. The native merge was clean; only the version declarations
conflicted.

- **The running time.** `currentSeconds` and `currentDuration`, reported
  while a thing plays.
- **The skips.** `skipBy:` with `HeyIOSAudioSkipBack` (15s) and
  `HeyIOSAudioSkipOn` (30s), and the remote commands that carry those
  preferred intervals to the lock screen and the car.
- **Two rows.** `buildNowPlaying` lays the bar out in two rows with
  `sizeNowPlaying`. On one row the clock truncated to "12:3…" and the
  play and forward buttons were pushed off screen on a 6.1-inch phone.

## A profile that grants Associated Domains is read as one (0.4.1)

0.4.0 read a profile's Associated Domains grant in a format that refuses a bare string, and profiles grant it as the string `*`, so `--associated-domain` stopped every device and distribution build, granted or not. The grant is read as XML now; `bin/package-check` runs the tool's own function on a string grant, a list grant and a profile without it.

## Level 3, audio with no credential, App Store packs and universal links (0.4.0)

- **Renderer level 3** (`hey_mobile` 0.3.2). `choose_many` lists the options with a tick beside each and a Done button; what follows sends `$values`, a list, and can say `{value_titles}`. A form lookup's `offers` draws what the lookup found as one button under a field the viewer typed something else in; a tap puts it in. `bin/conformance` runs `level3.json` as well as the level-2 vectors, with a second negative control (level 3 without `choose_many`). A level-2 description draws as before.
- **No credential rides on an audio fetch.** `HeyIOSAudio` plays every page from a plain `AVURLAsset` with no options. `headersForURL` is gone (that is why this is 0.4.0): an app sets `resolveAddress` instead, and the host does so from the description's `audio.sign` route, which exchanges an address on the app's own server for a short-lived one that needs no header. Each page is resolved just before it plays, and once more if it fails while playing. `bin/package-check` fails if the request-header asset option appears in the native code, with a control. An app whose server protects audio with the session header must add a sign route.
- **App Store packs.** `tools/hey-ios-api-app.sh --distribution` builds for iphoneos, signs with App Store profiles (get-task-allow false), stamps the Xcode provenance keys and writes `<Name>.ipa`; nothing is installed.
- **Universal links.** `--associated-domain HOST` signs a device or distribution build with `applinks:HOST`. A profile that does not grant Associated Domains stops the build with the portal step. A simulator build claims no domain.

## Signing in no longer crashes on a phone (0.3.1)

In 0.3.0 the Sign in button could close the app on an iPhone. The form's requests run as a chain of blocks, and the last step freed the running block before it read what it needed to finish. The simulator happened not to reuse that memory, so it always looked fine there. Dragging a row to reorder a list had the same fault. Both are fixed. `bin/block-lifetimes` (run by `bin/package-check`) builds the host for the iOS Simulator with AddressSanitizer, runs both chains against a stubbed request, and checks that each one fails with a heap-use-after-free when its fix is reverted.

Gotcha: a block kept alive only by a `__block` reference to itself (`hold = run`) must copy every capture it still needs into locals before it sets that reference to nil.

## A level-2 renderer with served descriptions (0.3.0)

`hey_mobile` 0.3.0 lets a server send an app its screens. This host is a renderer at level 2 of that contract (`api-renderer.json`; `docs/RENDERERS.md` in hey_mobile):

- **Served, stored, baked.** On launch it draws the last good served copy this build stored, else the baked copy, at once. On launch and on every return to the foreground it asks the description's `served` route (`?platform=ios&level=2`, `If-None-Match` the copy in hand, no credentials) and draws a new copy it takes when nothing is in progress. A network failure, an error status or a refused body changes nothing. The origin, the session header and checks, the Keychain service and the url scheme always come from the baked copy.
- **Hide what you do not know.** An unknown screen type, section, action, field or row kind is not drawn, and no action it does not recognise sends a request.
- **One evaluator.** `native/HeyIOSValues.{h,m}` (Foundation only) holds the value language, the kinds, icon and file-kind names and the rules for taking a served body. `bin/conformance` compiles it for this Mac and runs hey_mobile's `conformance/` vectors against it, with a negative control; `bin/package-check` runs it.
- The Hey shell may export `fn ios_app_origin()`: the origin, baked beside a description whose bytes are the server's.

## The native host for api_screens apps (0.2.0)

An app described with `hey_mobile` 0.2.0 `api_screens` runs on iPhone through this package. Nothing here names a product, a route or a service: the description decides every screen and request.

| file | what it is |
|---|---|
| `native/HeyIOSApiHost.{h,m}` | the renderer: tabs, lists, forms, search with polling, sign-in, deep links, document upload, video, web links, badges, the Listen tab, and the served description |
| `native/HeyIOSValues.{h,m}` | the value language, kinds, names and served-description rules, Foundation only |
| `native/HeyIOSKeychain.{h,m}` | the session token, readable after first unlock |
| `native/HeyIOSAudio.{h,m}` | playback through AVQueuePlayer (pages in order, resume, position reports) or Apple Music, Now Playing and remote commands, the running time (`currentSeconds`, `currentDuration`) and jumps back and on (`skipBy:`) |
| `native/HeyIOSShareController.{h,m}` | a share extension that saves a link through the description's share route |
| `audio.hey` | the audio capability contract (background mode, session category, Info.plist keys) |
| `tools/hey-ios-api-app.sh` | compiles the Hey shell through the LLVM lane (no Hey runtime linked), links the host, builds the share extension and icon, signs, installs on a simulator or a paired iPhone |

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" \
  "$HEY_IOS/tools/hey-ios-api-app.sh" --source ios/app.hey --out build/ios \
  --bundle-id com.example.app --display-name 'Example' --share-extension \
  --url-scheme example --icon-png build/AppIcon-1024.png [--sim-udid UDID]
# a paired iPhone: --device-udid ID --sign-identity "Apple Development: ..." --profile P --extension-profile P
```

The Hey shell exports `fn ios_app_manifest()` (the description as a literal string) and `fn ios_action_code(0)` (its byte length).

### Extensions (`--extension DIR`)

Another package adds native code to the app through `DIR/ios-extension.json`: sources compiled beside the host, frameworks, entitlements (linked into a simulator build, carried on a device only when the profile grants them) and scene declarations for Info.plist. The host configures any scene role other than the phone's window from that declaration, and a scene reads the audio feed with `HeyIOSApiHostLoadAudioFeed`, re-reading on `HeyIOSApiHostAudioFeedDidChange`. `hey_carplay` (the CarPlay audio scene) is the first extension. `--with carplay` from the unpublished working copy is gone.

## Standard package controls

This package uses `hey_packager` 0.1.3 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_ios`.
