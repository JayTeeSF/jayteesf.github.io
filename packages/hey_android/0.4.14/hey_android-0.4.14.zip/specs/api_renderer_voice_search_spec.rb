# frozen_string_literal: true
# encoding: UTF-8
require 'minitest/autorun'

class ApiRendererVoiceSearchSpec < Minitest::Test
  ROOT = File.expand_path('..', __dir__)
  ACTIVITY = File.read(File.join(ROOT, 'renderer/android/hey/android/api/HeyAndroidApiActivity.java'))

  def test_microphone_only_appears_for_opted_in_search_screens
    assert_includes ACTIVITY, 'Boolean.TRUE.equals(page.screen.get("speech_input"))'
    assert_includes ACTIVITY, 'setContentDescription("Search by voice")'
    assert_includes ACTIVITY, 'RecognizerIntent.ACTION_RECOGNIZE_SPEECH'
    assert_includes ACTIVITY, 'RecognizerIntent.EXTRA_LANGUAGE_MODEL'
    assert_includes ACTIVITY, 'RecognizerIntent.LANGUAGE_MODEL_FREE_FORM'
  end

  def test_search_result_reuses_normal_search_and_ignores_stale_or_empty_transcripts
    assert_includes ACTIVITY, 'onActivityResult(int requestCode, int resultCode, Intent data)'
    assert_includes ACTIVITY, 'RecognizerIntent.EXTRA_RESULTS'
    assert_includes ACTIVITY, 'page.generation != started'
    assert_includes ACTIVITY, 'page.field.setText(words)'
    assert_includes ACTIVITY, 'ask(page, words)'
    assert_includes ACTIVITY, 'ActivityNotFoundException'
  end

  def test_opted_in_editors_only_update_selection_without_submitting
    assert_includes ACTIVITY, 'Boolean.TRUE.equals(field.get("speech_input"))'
    assert_includes ACTIVITY, 'setContentDescription("Dictate " + Values.string(field.get("label")))'
    assert_includes ACTIVITY, 'editor.getText().replace(lo, hi, words)'
    assert_includes ACTIVITY, 'editor.setSelection(lo + words.length())'
    assert_includes ACTIVITY, 'dialog != null && !dialog.isShowing()'
    assert_includes ACTIVITY, 'page.generation != started'
    assert_includes ACTIVITY, 'editor.getText().toString().equals(draft)'
    insertion = ACTIVITY.split('if (editor != null) {', 2)[1].split('} else if (page.type().equals("search"))', 2)[0]
    %w[ask( submit( share( render(].each { |call| refute_includes insertion, call }
  end
end
