# hey_stripe

Stripe Checkout, Billing Portal, subscription, and webhook primitives for Hey
over stdlib:Http. Public info in `main.hey` (`HeyStripeInfo`). Build/verify with
`bin/check`. MMeoww owns entitlement truth; Stripe is a provider.
