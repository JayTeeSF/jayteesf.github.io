package hey.android.api;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pictures for rows, fetched once and remembered.
 *
 * <p>A picture is the one thing on these screens that comes from somewhere
 * OTHER than this app's own server: i.ytimg.com, a publisher, a store. So this
 * is deliberately not part of {@link HeyAndroidHttp}, which carries the
 * session token -- nothing here sends a header, a cookie or a token anywhere,
 * because the address came out of a row and an address out of a row is not a
 * place to present credentials.
 *
 * <p>HTTPS ONLY, for the same reason. A row can name any address at all, and a
 * plaintext fetch would tell whatever is on the path exactly what somebody is
 * reading. Anything else is simply not fetched and the row draws without a
 * picture, which is what it did before this file existed.
 *
 * <p>MISSING IS NORMAL, not an error worth showing: the sweep that fills these
 * addresses in runs behind the app, links rot, and a title that is not out yet
 * has no picture by definition. A failure leaves the space empty and is logged,
 * never raised -- a shelf of red error boxes would be worse than a plain list.
 */
final class HeyAndroidPictures {
  static final String TAG = "hey.api";

  /** What a caller wants when one arrives. Called on the main thread. */
  interface Ready {
    void drew(Bitmap picture);
  }

  /** How many addresses that answered with nothing are remembered, so each is asked once. */
  private static final int BARREN_LIMIT = 480;
  private static final int MAX_BYTES = 4 * 1024 * 1024;
  static final int SHARE_PIXELS = 1024 * 1024;
  interface ShareConnections { HttpURLConnection open(String address) throws Exception; }
  private final ShareConnections shareConnections;
  private final Object sessionLock = new Object();
  private volatile int sessionGeneration;
  private final java.util.Set<ShareFetch> activeShares = Collections.synchronizedSet(new java.util.HashSet<>());
  HeyAndroidPictures() { this(address -> (HttpURLConnection) new URL(address).openConnection()); }
  HeyAndroidPictures(ShareConnections connections) { shareConnections = connections; }
  private final java.util.concurrent.ScheduledExecutorService shareDeadlines = Executors.newSingleThreadScheduledExecutor();
  private final Map<String, Bitmap> shareHeld = Collections.synchronizedMap(new LinkedHashMap<String, Bitmap>(4, 0.75f, true) {
    @Override protected boolean removeEldestEntry(Map.Entry<String, Bitmap> eldest) { return size() > 4; }
  });

  private final class ShareFetch {
    final int generation = sessionGeneration;
    final long end = System.nanoTime() + java.util.concurrent.TimeUnit.SECONDS.toNanos(2);
    volatile boolean cancelled;
    volatile HttpURLConnection connection;
    void check() throws java.io.IOException {
      if (generation != sessionGeneration || cancelled || System.nanoTime() >= end) throw new java.io.IOException("share image ended");
    }
    void cancel() { cancelled = true; HttpURLConnection c = connection; if (c != null) c.disconnect(); }
  }

  private final ExecutorService pool = Executors.newFixedThreadPool(2);
  // A user's share must not wait behind unrelated row/header downloads.
  private final ExecutorService shares = Executors.newSingleThreadExecutor();
  private final Handler main = new Handler(Looper.getMainLooper());

  /**
   * The ones already fetched, oldest dropped first, bounded by DECODED BYTES
   * (HeyAndroidPictureBudget): a count said nothing about memory, since one
   * picture can be a hundred times another. Guarded by sessionLock.
   */
  private final HeyAndroidPictureBudget.Held<Bitmap> held = new HeyAndroidPictureBudget.Held<>(
      HeyAndroidPictureBudget.heldBudget(Runtime.getRuntime().maxMemory()), Bitmap::getAllocationByteCount);

  /** Rows waiting on a fetch already under way, one fetch per picture. Guarded by sessionLock. */
  private final HeyAndroidPictureBudget.Waiting<Ready> waiting =
      new HeyAndroidPictureBudget.Waiting<>(HeyAndroidPictureBudget.MAX_WAITING);

  /** Addresses already asked for and answered with nothing, so a broken one is asked for once. */
  private final Map<String, Boolean> barren = Collections.synchronizedMap(new LinkedHashMap<String, Boolean>() {
    @Override protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
      return size() > BARREN_LIMIT;
    }
  });

  /** True when this is an address this will even try. */
  static boolean fetchable(String address) {
    return address != null && address.startsWith("https://");
  }

  /**
   * Cached under its SIZE as well as its address. The same poster is wanted
   * small beside a row and whole at the top of its own screen, and one key for
   * both would hand whichever was asked for first to the other -- a header
   * built from a half-size thumbnail is exactly the blur this was asked to fix.
   */
  private static String key(String address, boolean full) {
    return (full ? "full|" : "thumb|") + address;
  }

  /** The one already held, or null. Lets a row draw without a flash when it is scrolled back to. */
  Bitmap held(String address, boolean full) {
    if (address == null) return null;
    synchronized (sessionLock) { return held.get(key(address, full)); }
  }

  /** Put a picture straight into the held set, as a fetch would. For the device checks. */
  void hold(String address, boolean full, Bitmap picture) {
    synchronized (sessionLock) { held.put(key(address, full), picture); }
  }

  /** Decoded bytes held now, and the most that may be. For the device checks. */
  long[] heldBytes() {
    synchronized (sessionLock) { return new long[] {held.total(), held.limit(), held.size(), waiting.size()}; }
  }

  /** Reuse the image cache, encode off the UI thread, and always finish even without artwork. */
  void shareImage(android.content.Context context, String address, java.util.function.Consumer<android.net.Uri> then) {
    java.util.concurrent.atomic.AtomicBoolean delivered = new java.util.concurrent.atomic.AtomicBoolean();
    // Bound visible preparation and the whole network transfer, including a
    // queued fetch. A slow-drip peer cannot keep the share worker indefinitely.
    ShareFetch fetch = new ShareFetch();
    Runnable timeout = () -> { if (fetch.generation == sessionGeneration && delivered.compareAndSet(false, true)) then.accept(null); };
    activeShares.add(fetch);
    java.util.concurrent.ScheduledFuture<?> deadline = shareDeadlines.schedule(() -> {
      main.post(timeout);
      fetch.cancel();
    }, 2, java.util.concurrent.TimeUnit.SECONDS);
    shares.execute(() -> {
      android.net.Uri attachment = null;
      try {
        if (fetchable(address)) {
          fetch.check();
          Bitmap picture = shareHeld.get(address);
          if (picture == null) picture = held(address, true);
          if (picture == null) picture = readShared(address, fetch);
          if (picture != null) {
            picture = boundedShare(picture);
            fetch.check();
            synchronized (sessionLock) { fetch.check(); shareHeld.put(address, picture); }
            attachment = HeyAndroidShareProvider.keep(context, picture);
            fetch.check();
          }
        }
      } catch (Exception failure) {
        Log.i(TAG, "share artwork unavailable: " + failure.getClass().getSimpleName());
      } finally {
        activeShares.remove(fetch);
      }
      final android.net.Uri ready = attachment;
      main.post(() -> {
        if (fetch.generation != sessionGeneration) return;
        if (!delivered.compareAndSet(false, true)) return;
        deadline.cancel(false);
        then.accept(ready);
      });
    });
  }

  void sessionChanged() {
    synchronized (sessionLock) {
      sessionGeneration++;
      shareHeld.clear();
      held.clear();
      waiting.clear();
      barren.clear();
    }
    java.util.List<ShareFetch> old;
    synchronized (activeShares) { old = new java.util.ArrayList<>(activeShares); }
    for (ShareFetch fetch : old) if (fetch.generation != sessionGeneration) fetch.cancel();
  }

  void close() {
    sessionChanged();
    shareDeadlines.shutdownNow();
    shares.shutdownNow();
    pool.shutdownNow();
    main.removeCallbacksAndMessages(null);
  }

  /**
   * Fetch it, unless it is already held or already known to be missing.
   *
   * <p>The caller passes the address it wants back so it can check the row it
   * is about to draw into is still showing the same one: these are list rows,
   * and a slow fetch landing after the view was reused is how the wrong picture
   * ends up against the wrong title.
   */
  void want(String address, boolean full, Ready then) {
    if (!fetchable(address)) return;
    String at = key(address, full);
    int generation;
    synchronized (sessionLock) {
      Bitmap already = held.get(at);
      if (already != null) {
        then.drew(already);
        return;
      }
      if (barren.containsKey(address)) return;
      // One fetch however many rows want this picture; past the cap, the row
      // keeps its glyph and asks again the next time it is bound.
      if (waiting.join(at, then) != HeyAndroidPictureBudget.Waiting.Joined.FETCH) return;
      generation = sessionGeneration;
    }
    pool.execute(() -> {
      Bitmap picture = read(address, full);
      java.util.List<Ready> callers;
      synchronized (sessionLock) {
        if (generation != sessionGeneration) return;
        callers = waiting.finish(at);
        if (picture == null) {
          barren.put(address, Boolean.TRUE);
          return;
        }
        held.put(at, picture);
      }
      main.post(() -> {
        if (generation != sessionGeneration) return;
        for (Ready caller : callers) caller.drew(picture);
      });
    });
  }

  private Bitmap readShared(String address, ShareFetch fetch) throws Exception {
    fetch.check();
    HttpURLConnection conn = shareConnections.open(address);
    fetch.connection = conn;
    try {
      fetch.check();
      conn.setConnectTimeout(1500);
      conn.setReadTimeout(1500);
      conn.setInstanceFollowRedirects(false);
      conn.setRequestProperty("accept", "image/*");
      int status = conn.getResponseCode();
      if (status < 200 || status > 299 || conn.getContentLengthLong() > MAX_BYTES) return null;
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      try (InputStream input = conn.getInputStream()) {
        byte[] chunk = new byte[16384];
        int n;
        while ((n = input.read(chunk)) != -1) {
          fetch.check();
          if (n > MAX_BYTES - out.size()) return null;
          out.write(chunk, 0, n);
        }
      }
      fetch.check();
      byte[] bytes = out.toByteArray();
      BitmapFactory.Options bounds = new BitmapFactory.Options();
      bounds.inJustDecodeBounds = true;
      BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
      if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
      // Even a sampled decoder must scan source pixels; refuse decompression
      // bombs before that work, then bound the actual decoded allocation.
      if ((long) bounds.outWidth * bounds.outHeight > 64L * 1024 * 1024) return null;
      BitmapFactory.Options options = new BitmapFactory.Options();
      options.inPreferredConfig = Bitmap.Config.ARGB_8888;
      int sample = 1;
      while (((bounds.outWidth + sample - 1L) / sample) * ((bounds.outHeight + sample - 1L) / sample) > SHARE_PIXELS
          || (bounds.outWidth + sample - 1L) / sample > 2048 || (bounds.outHeight + sample - 1L) / sample > 2048) sample *= 2;
      options.inSampleSize = sample;
      fetch.check();
      Bitmap decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
      fetch.check();
      return decoded == null ? null : boundedShare(decoded);
    } finally {
      fetch.connection = null;
      conn.disconnect();
    }
  }

  private static Bitmap boundedShare(Bitmap picture) {
    int width = picture.getWidth(), height = picture.getHeight();
    double scale = Math.min(1, Math.min(Math.sqrt(SHARE_PIXELS / ((double) width * height)), 2048.0 / Math.max(width, height)));
    if (scale < 1) picture = Bitmap.createScaledBitmap(picture, Math.max(1, (int) (width * scale)), Math.max(1, (int) (height * scale)), true);
    return picture;
  }

  /**
   * Bounds first, from the header alone: a picture that declares too many
   * pixels is refused before any decode. The rest is sampled down until its
   * longest side fits where it is drawn -- a row, or the top of a screen --
   * so a 6000-pixel poster costs a row about a megabyte, not a hundred.
   */
  static Bitmap decodeBounded(byte[] bytes, int maxSide) {
    BitmapFactory.Options bounds = new BitmapFactory.Options();
    bounds.inJustDecodeBounds = true;
    BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
    if (!HeyAndroidPictureBudget.acceptable(bounds.outWidth, bounds.outHeight)) return null;
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inSampleSize = HeyAndroidPictureBudget.sampleSize(bounds.outWidth, bounds.outHeight, maxSide);
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
  }

  private Bitmap read(String address, boolean full) {
    HttpURLConnection conn = null;
    try {
      conn = shareConnections.open(address);
      conn.setInstanceFollowRedirects(true);
      conn.setConnectTimeout(10000);
      conn.setReadTimeout(15000);
      conn.setRequestProperty("Accept", "image/*");
      int status = conn.getResponseCode();
      if (status < 200 || status > 299) return null;
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      try (InputStream in = conn.getInputStream()) {
        byte[] chunk = new byte[16384];
        int n;
        while ((n = in.read(chunk)) > 0) {
          out.write(chunk, 0, n);
          if (out.size() > MAX_BYTES) return null;
        }
      }
      byte[] bytes = out.toByteArray();
      return decodeBounded(bytes, full ? HeyAndroidPictureBudget.FULL_SIDE : HeyAndroidPictureBudget.ROW_SIDE);
    } catch (Exception e) {
      Log.i(TAG, "no picture from " + address + ": " + e);
      return null;
    } finally {
      if (conn != null) conn.disconnect();
    }
  }
}
