/* hey_android_glue.c: the NativeActivity entry for a Hey program.
 *
 * This file is the only non-Hey code in a hey_android app. The APK declares
 * android.app.NativeActivity with hasCode="false"; the framework loads
 * libhey_app.so and calls ANativeActivity_onCreate below. It does five things.
 *
 * 1. THE PROGRAM RUNS ON ITS OWN THREAD WITH AN 8 MiB STACK. onCreate runs on
 *    the UI thread, which must return promptly. bionic's default thread stack
 *    is about 1 MiB; musl's is 128 KiB, and my_queue's server died with no
 *    message when a Hey job-pool thread overflowed it (my_queue Dockerfile,
 *    "THE THREAD STACK"). So the program thread asks for 8 MiB explicitly,
 *    and every thread the runtime starts with no attributes (job pool, I/O
 *    reactor, actors, web workers) gets 8 MiB too, through the linker's
 *    --wrap=pthread_create. It is address space; pages are touched only as
 *    deep as a thread goes.
 *
 * 2. `says` REACHES LOGCAT. Android discards stdout and stderr. Both are
 *    replaced by pipes, and a pump thread writes each line as one logcat entry:
 *    stdout under tag hey.out at INFO, stderr under hey.err at ERROR. The
 *    glue's own messages use tag hey.app. A line longer than 4000 bytes is
 *    split into several entries (logcat's entry limit).
 *
 * 3. exit() ENDS THE ACTIVITY, NOT THE PROCESS. The Hey runtime calls exit(70)
 *    after printing "hey error: ..." on any runtime error, and a program may
 *    call exit itself. The link uses --wrap=exit, so on a Hey thread exit
 *    comes here: output is flushed and drained into logcat, the status is
 *    logged, ANativeActivity_finish is called, and that thread ends.
 *
 * 4. RELATIVE PATHS WORK. The working directory, HOME and TMPDIR are the app's
 *    private files directory.
 *
 * 5. ONE PROGRAM PER PROCESS. The runtime has no re-entrant entry point, and a
 *    program that ended through exit may have left runtime locks held. So once
 *    the program has ended and its activity is destroyed, the glue logs that
 *    and ends the process, and the next launch starts a fresh runtime. A
 *    library entry point in the toolchain would remove this (docs/ROADMAP.md).
 */
#include <android/log.h>
#include <android/native_activity.h>

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define HEY_TAG_APP "hey.app"
#define HEY_TAG_OUT "hey.out"
#define HEY_TAG_ERR "hey.err"
#define HEY_THREAD_STACK_BYTES ((size_t)8 * 1024 * 1024)
#define HEY_LINE_MAX 4000

#ifndef HEY_ANDROID_VERSION
#define HEY_ANDROID_VERSION "unknown"
#endif

extern int hey_program_main(int argc, char **argv);
extern int __real_pthread_create(pthread_t *thread, const pthread_attr_t *attr, void *(*start)(void *), void *arg);
extern void __real_exit(int status) __attribute__((noreturn));

static pthread_mutex_t hey_lock = PTHREAD_MUTEX_INITIALIZER;
static ANativeActivity *hey_activity;
static int hey_started;
static int hey_ended;
static pthread_t hey_main_thread;
static pthread_t hey_pump_thread;
static int hey_pump_running;
static int hey_out_read = -1;
static int hey_err_read = -1;

/* ---- 2. stdout and stderr to logcat ------------------------------------ */

typedef struct {
  int fd;
  int priority;
  const char *tag;
  size_t length;
  char line[HEY_LINE_MAX + 1];
} HeyStream;

static void hey_stream_emit(HeyStream *stream) {
  stream->line[stream->length] = '\0';
  __android_log_write(stream->priority, stream->tag, stream->line);
  stream->length = 0;
}

/* Returns 0 at end of file. */
static int hey_stream_read(HeyStream *stream) {
  char chunk[1024];
  ssize_t got = read(stream->fd, chunk, sizeof chunk);
  if (got < 0 && errno == EINTR) return 1;
  if (got <= 0) {
    if (stream->length > 0) hey_stream_emit(stream);
    return 0;
  }
  for (ssize_t i = 0; i < got; i++) {
    if (chunk[i] == '\n') {
      hey_stream_emit(stream);
    } else {
      stream->line[stream->length++] = chunk[i];
      if (stream->length == HEY_LINE_MAX) hey_stream_emit(stream);
    }
  }
  return 1;
}

static void *hey_pump_main(void *unused) {
  (void)unused;
  HeyStream out = {hey_out_read, ANDROID_LOG_INFO, HEY_TAG_OUT, 0, {0}};
  HeyStream err = {hey_err_read, ANDROID_LOG_ERROR, HEY_TAG_ERR, 0, {0}};
  struct pollfd fds[2] = {{out.fd, POLLIN, 0}, {err.fd, POLLIN, 0}};
  int open_streams = 2;
  while (open_streams > 0) {
    if (poll(fds, 2, -1) < 0) {
      if (errno == EINTR) continue;
      break;
    }
    for (int i = 0; i < 2; i++) {
      if (fds[i].fd < 0 || !(fds[i].revents & (POLLIN | POLLHUP | POLLERR))) continue;
      if (!hey_stream_read(i == 0 ? &out : &err)) {
        close(fds[i].fd);
        fds[i].fd = -1;
        open_streams--;
      }
    }
  }
  return NULL;
}

static int hey_redirect(int target, int *read_end) {
  int ends[2];
  if (pipe2(ends, O_CLOEXEC) != 0) return -1;
  if (dup2(ends[1], target) < 0) {
    close(ends[0]);
    close(ends[1]);
    return -1;
  }
  close(ends[1]);
  *read_end = ends[0];
  return 0;
}

/* ---- 3. the end of the program ----------------------------------------- */

/* Returns 0 if another thread already ended the program. */
static int hey_program_ended(int status, const char *how) {
  fflush(stdout);
  fflush(stderr);
  pthread_mutex_lock(&hey_lock);
  if (hey_ended) {
    pthread_mutex_unlock(&hey_lock);
    return 0;
  }
  hey_ended = 1;
  pthread_mutex_unlock(&hey_lock);

  /* Point stdout and stderr at /dev/null: the pipes' last write ends close, the
   * pump reaches end of file, and joining it puts every line the program wrote
   * into logcat before the status line. /dev/null rather than close() keeps
   * descriptors 1 and 2 from being reused by an unrelated open(). */
  if (hey_pump_running) {
    int sink = open("/dev/null", O_WRONLY | O_CLOEXEC);
    if (sink >= 0) {
      dup2(sink, STDOUT_FILENO);
      dup2(sink, STDERR_FILENO);
      close(sink);
    }
    pthread_join(hey_pump_thread, NULL);
  }
  __android_log_print(status == 0 ? ANDROID_LOG_INFO : ANDROID_LOG_ERROR, HEY_TAG_APP,
                      "hey program %s with status %d", how, status);

  pthread_mutex_lock(&hey_lock);
  if (hey_activity) {
    __android_log_write(ANDROID_LOG_INFO, HEY_TAG_APP, "finishing the activity");
    ANativeActivity_finish(hey_activity); /* posts to the UI thread; safe from any thread */
  } else {
    __android_log_write(ANDROID_LOG_INFO, HEY_TAG_APP, "no activity is attached; nothing to finish");
  }
  pthread_mutex_unlock(&hey_lock);
  return 1;
}

void __wrap_exit(int status) __attribute__((noreturn));
void __wrap_exit(int status) {
  pthread_mutex_lock(&hey_lock);
  int on_hey_thread = hey_started && !pthread_equal(pthread_self(), hey_main_thread);
  pthread_mutex_unlock(&hey_lock);
  if (!on_hey_thread) __real_exit(status);
  hey_program_ended(status, "exited");
  pthread_exit(NULL);
}

/* ---- 1. thread stacks -------------------------------------------------- */

int __wrap_pthread_create(pthread_t *thread, const pthread_attr_t *attr, void *(*start)(void *), void *arg) {
  if (attr) return __real_pthread_create(thread, attr, start, arg);
  pthread_attr_t sized;
  pthread_attr_init(&sized);
  pthread_attr_setstacksize(&sized, HEY_THREAD_STACK_BYTES);
  int rc = __real_pthread_create(thread, &sized, start, arg);
  pthread_attr_destroy(&sized);
  return rc;
}

static void *hey_program_thread(void *unused) {
  (void)unused;
  pthread_attr_t attr;
  if (pthread_getattr_np(pthread_self(), &attr) == 0) {
    size_t stack = 0;
    pthread_attr_getstacksize(&attr, &stack);
    pthread_attr_destroy(&attr);
    __android_log_print(ANDROID_LOG_INFO, HEY_TAG_APP, "hey program thread stack is %zu bytes", stack);
  }
  char name[] = "hey_android_app";
  char *argv[] = {name, NULL};
  int status = hey_program_main(1, argv);
  hey_program_ended(status, "returned");
  return NULL;
}

/* ---- the activity ------------------------------------------------------ */

static void hey_on_destroy(ANativeActivity *activity) {
  pthread_mutex_lock(&hey_lock);
  if (hey_activity == activity) hey_activity = NULL;
  int ended = hey_ended;
  pthread_mutex_unlock(&hey_lock);
  __android_log_write(ANDROID_LOG_INFO, HEY_TAG_APP, "activity destroyed");
  if (ended) {
    __android_log_write(ANDROID_LOG_INFO, HEY_TAG_APP,
                        "the Hey program has ended; the process exits so the next launch starts a fresh runtime");
    _exit(0);
  }
}

void ANativeActivity_onCreate(ANativeActivity *activity, void *saved_state, size_t saved_state_size) {
  (void)saved_state;
  (void)saved_state_size;
  activity->callbacks->onDestroy = hey_on_destroy;

  pthread_mutex_lock(&hey_lock);
  hey_activity = activity;
  if (hey_started) {
    int ended = hey_ended;
    pthread_mutex_unlock(&hey_lock);
    __android_log_write(ANDROID_LOG_INFO, HEY_TAG_APP,
                        ended ? "the Hey program already ended in this process; finishing"
                              : "attached to the running Hey program");
    if (ended) ANativeActivity_finish(activity);
    return;
  }
  hey_started = 1;
  hey_main_thread = pthread_self();
  pthread_mutex_unlock(&hey_lock);

  __android_log_print(ANDROID_LOG_INFO, HEY_TAG_APP, "hey_android %s: starting the Hey program (pid %d)",
                      HEY_ANDROID_VERSION, (int)getpid());

  const char *files = activity->internalDataPath;
  if (files && *files) {
    mkdir(files, 0700);
    if (chdir(files) != 0) {
      __android_log_print(ANDROID_LOG_WARN, HEY_TAG_APP, "could not enter %s: %s", files, strerror(errno));
    }
    setenv("HOME", files, 1);
    setenv("TMPDIR", files, 1);
  }

  if (hey_redirect(STDOUT_FILENO, &hey_out_read) == 0 && hey_redirect(STDERR_FILENO, &hey_err_read) == 0) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    hey_pump_running = __real_pthread_create(&hey_pump_thread, NULL, hey_pump_main, NULL) == 0;
  }
  if (!hey_pump_running) {
    __android_log_print(ANDROID_LOG_ERROR, HEY_TAG_APP, "could not route stdout to logcat: %s", strerror(errno));
  }

  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, HEY_THREAD_STACK_BYTES);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  pthread_t program;
  int rc = __real_pthread_create(&program, &attr, hey_program_thread, NULL);
  pthread_attr_destroy(&attr);
  if (rc != 0) {
    __android_log_print(ANDROID_LOG_ERROR, HEY_TAG_APP, "could not start the Hey program thread: %s", strerror(rc));
    hey_program_ended(71, "could not start");
  }
}
