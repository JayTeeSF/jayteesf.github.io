#!/usr/bin/env sh
# HEY-ROOT PROVENANCE.
#
# THE INVARIANT THIS SPEC PINS:
#
#   the Hey checkout compiled into a tvOS app is NAMED, VERIFIED and PRINTED -- never guessed.
#
# WHY IT EXISTS. tools/hey-ios-tv-app.sh compiles $HEY_ROOT/runtime/hey_runtime.c straight into the
# shipped app binary, so whichever checkout it selects IS the product. It used to select one
# silently:
#
#     tools/hey-ios-tv-app.sh   HEY_ROOT=${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}
#     hey-tv-device-env.sh      HEY_ROOT=${HEY_ROOT:-$HOME/dev/claude_01}
#
# The device environment's default pointed at a checkout months out of date. A developer running the
# device lane to test "current Hey" was shipping an unrelated runtime, and nothing in the output said
# so. That was found while proving the tvOS OpenSSL elimination: without an explicit override the
# device binary would have been built from a compiler that never had the fix -- a GREEN receipt for
# code that was not in the binary.
#
# This is evidence corruption, and it is the same class as the ambient-HEY_ROOT problem hardened in
# Hey core's bin/hey-hermetic-run. The fix is not "point the default at a newer checkout" -- that
# default goes stale again. The fix is that there is no default.
#
# DO NOT "FIX" A FAILURE HERE BY REINTRODUCING A $HOME/dev/... FALLBACK.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
TOOL="$ROOT/tools/hey-ios-tv-app.sh"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

say() { printf 'hey_root provenance spec: %s\n' "$*"; }
fail() { printf 'hey_root provenance spec: FAIL: %s\n' "$*" >&2; exit 1; }

# A real Hey checkout to point at. Named explicitly so this spec never inherits the ambient default
# it exists to forbid.
GOOD="${HEY_SPEC_ROOT:-$HOME/dev/hey-lang-tgz}"
if [ ! -e "$GOOD/runtime/hey_runtime.c" ]; then
  say "NOT-MEASURED (no Hey checkout at $GOOD; set HEY_SPEC_ROOT)"
  exit 0
fi

say '== 1. no root named at all: the tool FAILS instead of guessing =='
if out=$(env -u HEY_ROOT sh "$TOOL" --out "$WORK/a" --plan-only 2>&1); then
  fail "the tool built with no Hey checkout named; it must refuse. Output: $out"
fi
printf '%s' "$out" | grep -q 'will not guess' \
  || fail "refusing is right but the message does not say the tool will not guess: $out"
printf '%s' "$out" | grep -q -- '--hey-root' \
  || fail 'the refusal must tell the caller how to name a checkout (--hey-root)'
say '1=PASS refuses, and says how to name one'

say '== 2. no $HOME/dev/... fallback survives anywhere in the tool =='
# The precise shape that caused this: a parameter-expansion default naming a personal path. Comment
# lines are stripped first -- this file and the tool both DESCRIBE the removed pattern on purpose,
# and a guard that cannot survive its own documentation is a guard nobody keeps.
CODE="$WORK/tool-code.sh"
sed 's/[[:space:]]*#.*$//' "$TOOL" > "$CODE"
if grep -nE 'HEY_ROOT=\$\{HEY_ROOT:[-=]' "$CODE" >/dev/null 2>&1; then
  fail "tools/hey-ios-tv-app.sh still defaults HEY_ROOT via parameter expansion: $(grep -nE 'HEY_ROOT=\$\{HEY_ROOT:[-=]' "$CODE")"
fi
if grep -nE 'HEY_ROOT.*\$HOME/dev/' "$CODE" >/dev/null 2>&1; then
  fail "a \$HOME/dev/... HEY_ROOT default has come back: $(grep -nE 'HEY_ROOT.*\$HOME/dev/' "$CODE")"
fi
say '2=PASS no personal-path default'

say '== 3. a named root that is not a Hey checkout FAILS, and says what is missing =='
mkdir -p "$WORK/empty"
if out=$(HEY_ROOT="$WORK/empty" sh "$TOOL" --out "$WORK/b" --plan-only 2>&1); then
  fail 'the tool accepted a directory that is not a Hey checkout'
fi
printf '%s' "$out" | grep -q 'is not a Hey checkout' \
  || fail "the refusal must name the problem: $out"
printf '%s' "$out" | grep -q 'runtime/hey_runtime.c' \
  || fail "the refusal must name the missing file: $out"
say '3=PASS verifies the checkout instead of assuming it'

say '== 4. NEGATIVE CONTROL: a stale foreign HEY_ROOT cannot win over an explicit --hey-root =='
# The exact live configuration: hey-tv-device-env.sh exports a stale checkout, and the caller names
# the intended one. The intended one must win, and the receipt must SAY which was used.
STALE="$WORK/stale_checkout"
mkdir -p "$STALE/runtime" "$STALE/bin"
: > "$STALE/runtime/hey_runtime.c"
: > "$STALE/runtime/hey_compiler_nodes_bundle.c"
: > "$STALE/bin/heyc"
out=$(HEY_ROOT="$STALE" sh "$TOOL" --out "$WORK/c" --plan-only --hey-root "$GOOD" 2>&1) \
  || fail "the explicit --hey-root run failed: $out"
printf '%s' "$out" | grep -q "^hey_root=$GOOD$" \
  || fail "the receipt does not report the explicitly named root. Output: $out"
printf '%s' "$out" | grep -q '^hey_root_source=--hey-root$' \
  || fail 'the receipt does not record that --hey-root won over the environment'
if printf '%s' "$out" | grep -q "$STALE"; then
  fail "the STALE checkout appears in the receipt; it must not influence the build. Output: $out"
fi
# And the runtime digest must be the GOOD checkout's, not the empty stale stub's.
good_sha=$(shasum -a 256 "$GOOD/runtime/hey_runtime.c" | cut -c1-16)
printf '%s' "$out" | grep -q "^runtime_source_sha256=$good_sha$" \
  || fail "the runtime compiled is not the named checkout's. Output: $out"
say '4=PASS explicit root wins; stale root cannot reach the build'

say '== 5. the receipt carries the full provenance set =='
for field in hey_root hey_root_source hey_head compiler_identity runtime_source_sha256 hey_ios_tv_version; do
  printf '%s' "$out" | grep -q "^$field=" \
    || fail "the provenance receipt is missing $field"
done
# Printed BEFORE the build, so provenance survives a failed build.
printf '%s' "$out" | head -1 | grep -q '^hey_root=' \
  || fail 'provenance must be printed before anything is compiled'
say '5=PASS receipt complete and printed first'

printf 'hey_root provenance spec passed: no_default=true verified=true explicit_wins=true stale_excluded=true receipt=complete\n'
