#include "hey_mysql.h"
#include <mysql.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct HeyMysqlResult {
  MYSQL_RES *result;
  MYSQL_ROW current;
  unsigned long *lengths;
} HeyMysqlResult;

static MYSQL *hey_mysql_connection(HeyNativeHandle value) {
  return (MYSQL *)(uintptr_t)value;
}

static HeyMysqlResult *hey_mysql_result(HeyNativeHandle value) {
  return (HeyMysqlResult *)(uintptr_t)value;
}

static char *hey_mysql_c_string(HeyNativeUtf8View value, int nullable) {
  if (nullable && value.data == NULL && value.length == 0) return NULL;
  char *out = (char *)malloc(value.length + 1);
  if (!out) return NULL;
  if (value.length && value.data) memcpy(out, value.data, value.length);
  out[value.length] = '\0';
  return out;
}

static void hey_mysql_release_bytes(void *context, uint8_t *data, size_t length) {
  (void)context;
  (void)length;
  free(data);
}

HeyNativeUtf8View hey_mysql_client_info(void) {
  const char *value = mysql_get_client_info();
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeHandle hey_mysql_init(void) {
  return (HeyNativeHandle)(uintptr_t)mysql_init(NULL);
}

int32_t hey_mysql_close(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  mysql_close(mysql);
  return 0;
}

int32_t hey_mysql_set_connect_timeout(HeyNativeHandle connection, uint32_t seconds) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_options(mysql, MYSQL_OPT_CONNECT_TIMEOUT, &seconds) : 1;
}

int32_t hey_mysql_set_read_timeout(HeyNativeHandle connection, uint32_t seconds) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_options(mysql, MYSQL_OPT_READ_TIMEOUT, &seconds) : 1;
}

int32_t hey_mysql_set_write_timeout(HeyNativeHandle connection, uint32_t seconds) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_options(mysql, MYSQL_OPT_WRITE_TIMEOUT, &seconds) : 1;
}

int32_t hey_mysql_set_ssl(HeyNativeHandle connection, HeyNativeUtf8View key, HeyNativeUtf8View certificate, HeyNativeUtf8View ca, HeyNativeUtf8View ca_path, HeyNativeUtf8View cipher) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *key_c = hey_mysql_c_string(key, 1);
  char *cert_c = hey_mysql_c_string(certificate, 1);
  char *ca_c = hey_mysql_c_string(ca, 1);
  char *path_c = hey_mysql_c_string(ca_path, 1);
  char *cipher_c = hey_mysql_c_string(cipher, 1);
  int rc = mysql_ssl_set(mysql, key_c, cert_c, ca_c, path_c, cipher_c);
  free(key_c);
  free(cert_c);
  free(ca_c);
  free(path_c);
  free(cipher_c);
  return rc;
}

int32_t hey_mysql_set_ssl_verify(HeyNativeHandle connection, HeyNativeBool verify) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
#ifdef MYSQL_OPT_SSL_VERIFY_SERVER_CERT
  unsigned char enabled = verify ? 1 : 0;
  return mysql_options(mysql, MYSQL_OPT_SSL_VERIFY_SERVER_CERT, &enabled);
#else
  (void)verify;
  return 2;
#endif
}

int32_t hey_mysql_connect(HeyNativeHandle connection, HeyNativeUtf8View host, HeyNativeUtf8View username, HeyNativeUtf8View password, HeyNativeUtf8View database, uint32_t port, HeyNativeUtf8View socket, uint64_t flags) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *host_c = hey_mysql_c_string(host, 0);
  char *user_c = hey_mysql_c_string(username, 0);
  char *password_c = hey_mysql_c_string(password, 0);
  char *database_c = hey_mysql_c_string(database, 1);
  char *socket_c = hey_mysql_c_string(socket, 1);
  if (!host_c || !user_c || !password_c) {
    free(host_c);
    free(user_c);
    free(password_c);
    free(database_c);
    free(socket_c);
    return 1;
  }
  MYSQL *connected = mysql_real_connect(mysql, host_c, user_c, password_c, database_c, port, socket_c, (unsigned long)flags);
  free(host_c);
  free(user_c);
  free(password_c);
  free(database_c);
  free(socket_c);
  return connected ? 0 : (int32_t)mysql_errno(mysql);
}

int32_t hey_mysql_set_charset(HeyNativeHandle connection, HeyNativeUtf8View charset) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *charset_c = hey_mysql_c_string(charset, 0);
  if (!charset_c) return 1;
  int rc = mysql_set_character_set(mysql, charset_c);
  free(charset_c);
  return rc;
}

int32_t hey_mysql_select_db(HeyNativeHandle connection, HeyNativeUtf8View database) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  char *database_c = hey_mysql_c_string(database, 0);
  if (!database_c) return 1;
  int rc = mysql_select_db(mysql, database_c);
  free(database_c);
  return rc;
}

uint32_t hey_mysql_errcode(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint32_t)mysql_errno(mysql) : 0;
}

HeyNativeUtf8View hey_mysql_errmsg(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  const char *value = mysql ? mysql_error(mysql) : "invalid MySQL connection handle";
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeUtf8View hey_mysql_sqlstate(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  const char *value = mysql ? mysql_sqlstate(mysql) : "HY000";
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeUtf8View hey_mysql_server_info(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  const char *value = mysql ? mysql_get_server_info(mysql) : "";
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

uint64_t hey_mysql_thread_id(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint64_t)mysql_thread_id(mysql) : 0;
}

int32_t hey_mysql_query(HeyNativeHandle connection, HeyNativeUtf8View sql) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return 1;
  return mysql_real_query(mysql, sql.data, (unsigned long)sql.length);
}

uint32_t hey_mysql_field_count(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint32_t)mysql_field_count(mysql) : 0;
}

HeyNativeHandle hey_mysql_store_result(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return (HeyNativeHandle)0;
  MYSQL_RES *stored = mysql_store_result(mysql);
  if (!stored) return (HeyNativeHandle)0;
  HeyMysqlResult *out = (HeyMysqlResult *)calloc(1, sizeof(HeyMysqlResult));
  if (!out) {
    mysql_free_result(stored);
    return (HeyNativeHandle)0;
  }
  out->result = stored;
  return (HeyNativeHandle)(uintptr_t)out;
}

int32_t hey_mysql_free_result(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped) return 1;
  if (wrapped->result) mysql_free_result(wrapped->result);
  free(wrapped);
  return 0;
}

uint64_t hey_mysql_num_rows(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  return wrapped && wrapped->result ? (uint64_t)mysql_num_rows(wrapped->result) : 0;
}

uint32_t hey_mysql_num_fields(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  return wrapped && wrapped->result ? (uint32_t)mysql_num_fields(wrapped->result) : 0;
}

HeyNativeUtf8View hey_mysql_field_name(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || index >= mysql_num_fields(wrapped->result)) return (HeyNativeUtf8View){"", 0};
  MYSQL_FIELD *fields = mysql_fetch_fields(wrapped->result);
  const char *value = fields[index].name ? fields[index].name : "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeBool hey_mysql_fetch_row(HeyNativeHandle result_set) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result) return 0;
  wrapped->current = mysql_fetch_row(wrapped->result);
  wrapped->lengths = wrapped->current ? mysql_fetch_lengths(wrapped->result) : NULL;
  return wrapped->current ? 1 : 0;
}

HeyNativeBool hey_mysql_column_is_null(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || index >= mysql_num_fields(wrapped->result)) return 1;
  return wrapped->current[index] == NULL ? 1 : 0;
}

HeyNativeUtf8View hey_mysql_column_text(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || !wrapped->lengths || index >= mysql_num_fields(wrapped->result) || wrapped->current[index] == NULL) return (HeyNativeUtf8View){"", 0};
  return (HeyNativeUtf8View){wrapped->current[index], (size_t)wrapped->lengths[index]};
}

HeyNativeBytesView hey_mysql_column_bytes(HeyNativeHandle result_set, uint32_t index) {
  static const uint8_t empty = 0;
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || !wrapped->lengths || index >= mysql_num_fields(wrapped->result) || wrapped->current[index] == NULL) return (HeyNativeBytesView){&empty, 0};
  return (HeyNativeBytesView){(const uint8_t *)wrapped->current[index], (size_t)wrapped->lengths[index]};
}

uint64_t hey_mysql_column_length(HeyNativeHandle result_set, uint32_t index) {
  HeyMysqlResult *wrapped = hey_mysql_result(result_set);
  if (!wrapped || !wrapped->result || !wrapped->current || !wrapped->lengths || index >= mysql_num_fields(wrapped->result)) return 0;
  return (uint64_t)wrapped->lengths[index];
}

uint64_t hey_mysql_affected_rows(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint64_t)mysql_affected_rows(mysql) : 0;
}

uint64_t hey_mysql_insert_id(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? (uint64_t)mysql_insert_id(mysql) : 0;
}

int32_t hey_mysql_autocommit(HeyNativeHandle connection, HeyNativeBool enabled) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_autocommit(mysql, enabled ? 1 : 0) : 1;
}

int32_t hey_mysql_commit(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_commit(mysql) : 1;
}

int32_t hey_mysql_rollback(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_rollback(mysql) : 1;
}

int32_t hey_mysql_ping(HeyNativeHandle connection) {
  MYSQL *mysql = hey_mysql_connection(connection);
  return mysql ? mysql_ping(mysql) : 1;
}

HeyNativeOwnedBytes hey_mysql_escape(HeyNativeHandle connection, HeyNativeUtf8View value) {
  MYSQL *mysql = hey_mysql_connection(connection);
  if (!mysql) return (HeyNativeOwnedBytes){0, 0, 0, 0};
  if (value.length > (SIZE_MAX - 1) / 2) return (HeyNativeOwnedBytes){0, 0, 0, 0};
  size_t capacity = value.length * 2 + 1;
  uint8_t *buffer = (uint8_t *)malloc(capacity);
  if (!buffer) return (HeyNativeOwnedBytes){0, 0, 0, 0};
  unsigned long length = mysql_real_escape_string(mysql, (char *)buffer, value.data, (unsigned long)value.length);
  return (HeyNativeOwnedBytes){buffer, (size_t)length, hey_mysql_release_bytes, NULL};
}
