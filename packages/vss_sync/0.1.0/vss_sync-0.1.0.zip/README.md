# vss_sync

`vss_sync` is an independently versioned Hey package for the pure, shared parts
of the VSS v3 ciphertext protocol:

- protocol/format identities;
- route construction;
- revision and recovery-envelope validation;
- deterministic causal winner/alternate selection.

It deliberately does **not** own HTTP hosting, persistence, bearer registries,
Keychain/Keystore, cryptographic key storage, native UI, or product policy.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
./bin/verify
./bin/package
./bin/source-zip
```

Consumers install a verified archive and import:

```hey
import 'pkg:vss_sync@0.1.0/main'
```

The package is specialized VSS domain code, not a standard-library candidate.
General facilities exposed while using it are tracked in
`docs/humans/hey-extraction.md`.
