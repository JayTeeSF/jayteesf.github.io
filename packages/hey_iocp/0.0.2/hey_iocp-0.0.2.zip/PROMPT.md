# Continue hey_iocp

Read README.md, docs/README.md, todos.md, done.md, hey.native.json, the
native source and the specs before editing.

hey_iocp is an independent package: the Windows I/O completion port backend (EXPERIMENTAL, never run)
behind the same API as hey_epoll's Epoll. Hey owns the generic native ABI,
loader and package plumbing; this package owns the event loop. Keep handles
opaque, blocking calls honest (`wait` is the only blocking function), one loop
per thread, and the API name-for-name equal to Epoll so hey_poller can swap it. Never claim it works on Windows until a Windows run says so.

Verify with:

```sh
HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan" ./bin/check
bin/build-native       # cross-build the windows-x64 DLL
```

Published versions are immutable. Change the version whenever released bytes change.
