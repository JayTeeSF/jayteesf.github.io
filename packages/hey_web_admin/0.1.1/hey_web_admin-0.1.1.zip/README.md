# hey_web_admin

Scaffolded CRUD screens over your records, for [`hey_web`](../hey_web)
applications. Point it at a collection and you get list, show, create,
edit and delete pages you did not write.

Django's admin and Rails' ActiveAdmin are the reference points. The
resemblance stops at the idea: this is a **0.1.0**, it is deliberately
quick and dirty, and it is not a design system. Read
[Limits](#limits) before you decide it fits.

Two things it is **not** casual about, because "quick and dirty" does
not extend to them: [escaping](#escaping) and
[the authorization guard](#authorization-is-not-optional).

---

## Where the metadata comes from, and why

This is the load-bearing design question for any admin, so here is the
measurement rather than the conclusion.

### `hey_record` 0.3.0 has no model reflection

`HeyRecordModel.define(connection, table, options)` returns, in full:

```hey
{kind, connection, table, primary_key, timestamps, options}
```

Table name, primary-key name, timestamps flag. **No column list, no
types, no nullability, no associations.** `HeyRecord.from` seeds
`columns: []`, but that is the SELECT *projection*, not the column set.
`HeyRecordInfo.capabilities()` declares `associations`, `validations`
and `callbacks` all `false`, and the package README lists *schema
dumping* under deliberate limits.

Type information is typed by a developer — into
`HeyRecordMigration.column(name, sql_type, options)` — and that
function concatenates it straight into a DDL **string**. The metadata is
destroyed at the moment it is used. Nothing retains it.

So **runtime reflection of a model is not available.** That is a finding
about `hey_record`, not a gap this package worked around quietly.

### Reflecting the database instead would have been worse

`HeyRecord.query(connection, 'PRAGMA table_info(t)')` is available, and
that was this package's first design. It is wrong here.

The app this package is proved against, `generic_cagents`, persists
through `HeyRecordStore` — the JSON document store — whose SQL table is
fixed by `hey_record` itself as
`(collection_name, record_id, payload LONGTEXT, ...)`. Reflecting it
yields those same five meaningless columns for **every collection in the
application**, and renders a blob. It would have passed every spec
written against it.

### So: declaration first, inference for free

- **Declare** fields with `HeyAdminField` and you get labels, ordering,
  types and required-ness. Always works, in both lanes, over any
  backend.
- **Declare nothing** and `HeyAdminReflect` infers the field list from
  the rows the source actually returned — the sorted union of their
  keys, primary key first. That is what keeps the "point it at your
  models" promise: it reflects the **data**, which is the only thing in
  this stack that carries a shape.
- Where both exist, **declaration wins**; inference only contributes
  keys nobody declared.

Every inferred column is marked, and the list screen says so. *"Columns
the developer declared"* and *"columns we guessed from the rows on this
page"* are different claims, and an admin that blurs them is lying about
the record.

**What inference honestly costs**, stated on the screen and here:

1. A field that is empty or absent in every sampled row does not exist
   as far as inference is concerned. Declare it.
2. Types are guessed from the first non-nil value.
3. **Nothing is inferred as required.** Required-ness is a claim about
   all possible rows and cannot be read off some of them.
4. An empty collection with no declaration infers nothing — so it cannot
   render a create form, and both the form and the POST refuse and say
   why rather than silently storing an empty record.

There is a pleasing confirmation of this choice in the test subject:
`generic_cagents` **already declares its own field metadata**, in
`Project.required_fields()` — a list of `{key, label}`, which is the
shape `HeyAdminField` takes. The application had the metadata all
along. It just was not in `hey_record`.

---

## Mounting it

Hey has no closures, so a route handler cannot capture the admin
configuration. The application supplies one three-line handler that
reaches its own config through an ordinary module function:

```hey
import 'stdlib:Web'
import 'pkg:hey_web@0.3.5/main'
import 'pkg:hey_web@0.3.5/config'
import 'pkg:hey_web_admin@0.1.1/main'

module MyAdmin
  fn config()
    let store = HeyRecordStore.file('db/data')
    let source = HeyAdminSource.record_store(store, 'projects')
    let fields = [
      HeyAdminField.required_text('name', 'Name'),
      HeyAdminField.long_text('notes', 'Notes')
    ]
    let projects = HeyAdmin.resource('projects', source, {fields: fields, singular: 'project'})
    return HeyAdmin.config('/admin', [projects], {authorize: MyAuth.check})
  end

  fn handle(request)
    return HeyAdmin.handle(MyAdmin.config(), request)
  end
end
```

Then, at your application's **own top level**:

```hey
let allowed = HeyAdmin.mount_check(MyAdmin.config())
if allowed.ok == false
  fail allowed.error          # the guard refused; see below
end

let routes = [
  ...App.routes(),
  Web.get('/admin', MyAdmin.handle),
  Web.get('/admin/:resource', MyAdmin.handle),
  Web.get('/admin/:resource/new', MyAdmin.handle),
  Web.get('/admin/:resource/:id', MyAdmin.handle),
  Web.get('/admin/:resource/:id/edit', MyAdmin.handle),
  Web.get('/admin/:resource/:id/delete', MyAdmin.handle),
  Web.post('/admin/:resource', MyAdmin.handle),
  Web.post('/admin/:resource/:id', MyAdmin.handle),
  Web.post('/admin/:resource/:id/delete', MyAdmin.handle)
]

let served = Web.serve(routes, {host: '127.0.0.1', port: 9292, workers: 2})
```

`/new` **must** be registered before `/:id`. The first matching pattern
wins, so the other order makes `/admin/projects/new` a "show" for a
record called `new` and there is no create screen at all.
`HeyAdmin.paths(prefix)` returns the nine in the required order if you
would rather generate them.

### The one-liner, and why it is not the default

`HeyAdmin.mount(config, handler)` builds that whole table in one call
and returns it as a `Result`. **It does not survive the compiled lane
today.** A callable that arrives as a *parameter* and is stored into a
route record makes `Web.dispatch` answer `nil` for that route (the
shared `bind()` degradation; reduced to 25 lines in
`tools/probe20.hey`). The same callable written directly into
`Web.get(path, handler)` at your own call site works in both lanes.

Use `mount` if you only ever run interpreted. Use the explicit form
above otherwise. When the trunk fix lands, `mount` becomes the
recommended form and nothing else changes — `HeyAdmin.handle` is the
actual engine and is already compiled-lane clean.

`Web.serve` is the only serving lane. `Web.service` and `Web.start`
were deleted in `hey_web` 0.3.0; nothing here may reintroduce them.

---

## Authorization is not optional

**There is no auth package in the Hey ecosystem yet, and this package
does not try to be one.** An admin that shipped its own hand-rolled
session handling would be two bad ideas welded together.

What it does do is refuse to be the reason an unauthenticated CRUD
interface over every record in your database appears on a public port.

- `HeyAdmin.mount_check` / `HeyAdmin.mount` **refuse** — a `Result`
  error with code `admin_unguarded`, and **zero routes** — unless you
  pass an `authorize` callable. Not a warning next to a working admin. A
  refusal that still returned a route table would be a comment, not a
  guard.
- `authorize(request) -> bool` is called on **every request**, not only
  at mount. Anything that is not exactly `true` denies: `nil`, `0`, a
  string, a `Result`. An authorization predicate whose contract is
  misunderstood must fail closed.
- The escape hatch is `HEY_ADMIN_INSECURE=1` — an environment variable,
  never an option, because it must be a deployment decision rather than
  something set once while developing and then carried to production
  inside a commit. It logs a warning on every mount and puts a red
  banner on **every screen**, because a log line scrolls away.

It exists at all because without one the first thing anybody does at
11pm is fork the package and delete the check, and then it is gone
forever and invisible.

---

## Escaping

`hey_web` has no escaper; `HeyWebResponses.html(body)` takes a finished
string. So escaping is this package's obligation, and it is
escape-by-default: every record value reaches a page through
`HeyAdminEscape.text` or `.cell`. `raw` exists, is named `raw`, and is
never given a record value.

It matters more in an admin than anywhere else: the page renders
attacker-supplied data to the one person who can edit every record and
delete every row.

Proved with a real `<script>` payload on **every** screen that renders a
value — list, show, edit, delete-confirm — and posted the way a browser
actually sends it (`%3Cimg+src%3Dx+onerror%3D...`), so that a missing
decoder cannot make the gate pass for the wrong reason. The edit form
gets its own assertion because the value sits in an **attribute**, where
escaping `<` is not enough: `" onfocus=alert(1) autofocus="` needs no
angle bracket.

It is also proved against real data. `generic_cagents`' own record
carries `seat_branch_pattern: "seat/<name>/<slice>"` — not a planted
payload — and an admin that did not escape would emit `<name>` into the
document, where a browser parses it as an unknown element and silently
drops it. The operator would read a branch pattern of `seat//` and never
know.

---

## Other things it gets right

- **Delete is POST-only.** A GET renders a confirmation and touches
  nothing. A GET that deletes is reachable from an `<img>` tag, a
  prefetching browser, or a link in an email — and the operator's
  browser is where all of those meet. The spec asserts the record still
  exists after the GET, not merely that a confirmation rendered.
- **Pagination**, over the id list, before any payload is read: page 900
  costs what page 1 costs. The first time a table has 100k rows an
  unpaged admin stops being an admin.
- **Update merges, it does not replace.** A form renders the fields it
  knows about; storing only those would drop every key the form never
  showed. Against `generic_cagents`' real record that is 16 of 24 keys.
- **A write allow-list.** A POST cannot invent a column. In a schemaless
  store an injected key is not a stray value — it becomes a permanent
  phantom column on every list screen from the next inference pass
  onward.
- **A row that fails to load is skipped, not fatal**, and the count is
  reported on the page. One corrupt record should not make a collection
  unreachable — the admin is where an operator would go to find the
  damage.

## Labels

Chrome strings come from a `labels` record you can pass to
`HeyAdmin.config`, defaulting to English. That is a seam, not i18n, and
it is deliberately not a dependency: `hey_i18n` 0.1.1 exists and is
usable (`I18n.format`, `I18n.render_body`), so build your catalog there
and hand the resolved strings in. This package stays dependency-light
and you keep one place where locale is decided.

```hey
HeyAdmin.config('/admin', resources, {authorize: MyAuth.check, labels: {new: 'Nuevo', delete: 'Eliminar'}})
```

---

## Limits

Say what you did not build.

- **One source: `HeyRecordStore`.** `HeyAdminSource.record_store(store,
  collection)`, file- or SQL-backed. A `HeyRecordModel` source is the
  same four operations and is **not shipped**, because `model.hey` is
  interpreter-lane only on the current trunk (`HeyRecordModel.find` does
  not lower — `HeyRecord.first` is mis-resolved as the `first` builtin,
  per `hey_record`'s own README) and it could not pass the compiled
  gate. Adding a backend means editing `source.hey`; sources are inert
  descriptors dispatched on `kind` rather than records of callables,
  because callables in records do not survive the compiled lane.
- **No associations.** `hey_record` does not have them
  (`capabilities()` says `associations: false`), so there is nothing to
  render.
- **Validation is required-ness only.** No types, no formats, no
  uniqueness. `hey_record` claims no validations either.
- **No CSRF protection.** A logged-in operator's browser can be made to
  POST from another origin. Put the admin behind something that handles
  this, or do not expose it to a browser that visits other sites.
- **No file uploads, no search, no filtering, no sorting by column, no
  bulk actions, no audit log, no soft delete.**
- **Percent-decoding is ASCII-only** (0x09/0x0A/0x0D and 0x20–0x7E).
  Hey has no `chr`/`ord` and no ints→bytes anywhere, so a multi-byte
  escape cannot be reassembled; `%C3%A9` is passed through **literally**
  rather than corrupted. Every character an injection needs is ASCII, so
  this does not weaken the escaping guarantee. It resolves when
  `Text.from_code_point` lands on the trunk.
- **`HeyAdmin.mount` is interpreter-lane only.** See above.
- It is **not the app's real UI**. If you are styling it, you have
  outgrown it.

## Gates

```sh
bin/check            # interpreter lane, plus the version and tautology guards
bin/check-compiled   # compiled lane, plus a byte-identical lane-agreement receipt
tools/red-check      # mutation testing: breaks the code, demands each gate go RED
```

`bin/check` runs the guard spec **twice**, with and without
`HEY_ADMIN_INSECURE=1`; running it in one environment would leave either
the refusal or the escape hatch untested.

An interpreted green is not a green. On this package alone the two lanes
were measured disagreeing three times, every one invisible to an
interpreted run — a body rendered as its own address, a pager linking to
page 11 of 3, and a route dispatching to `nil`. `bin/check-compiled`
therefore asserts **byte-identical** output between lanes, not merely
that both exit 0.

`tools/red-check` applies 25 targeted mutations — escaping off, the
guard defaulted open, GET deleting, update replacing, the allow-list
removed — and fails if any gate stays green. Two real gate holes were
found this way and closed.

## Standard package controls

This package follows the `hey_packager` conventions. It is published to
the jayteesf registry from 0.1.1.
