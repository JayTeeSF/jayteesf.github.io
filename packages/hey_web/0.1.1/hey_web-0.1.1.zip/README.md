# hey_web

`hey_web` is a third-party HTTP client/server convenience package for Hey.
It layers a small reusable API over `stdlib:web`, `stdlib:net`, and `stdlib:http`.

This release uses the package layout required by Hey v0.99.198a and later:
public modules live at the installed package root, the manifest maps module names
to those files, and installation is performed by `hey package install` so the
compiler receives both `.hey-package-install.json` and a pinned app lockfile.

## Modules

```hey
import 'pkg:hey_web@0.1.1/server'
import 'pkg:hey_web@0.1.1/client'
import 'pkg:hey_web@0.1.1/client_cli'
import 'pkg:hey_web@0.1.1/main'
```

- `HeyWebServer`: server options, worker-pool plans, and blocking `web.serve`.
- `HeyHttpClient`: HTTP/1.1 request rendering, socket requests, and response parsing.
- `HeyHttpClientCli`: reusable command-line option and response rendering helpers.
- `HeyWeb`: small facade over the client/server modules.

Workers default to `0`, which lets the active Hey runtime select `HEY_WORKERS`
or the online CPU count. Slow or retryable work should be submitted to Jobs
instead of blocking request workers.

## Install into an application

Run from the consuming application root:

```sh
./vendor/hey/darwin-arm64/bin/hey package install \
  --release /path/to/hey_web-0.1.1.release.json \
  --archive /path/to/hey_web-0.1.1.zip \
  --root .hey/packages \
  --lock hey.lock.json
```

Do not manually unzip or copy the package into `.hey/packages`. A verified
`pkg:` import requires the install receipt and the generated lock entry.

Audit the installed package:

```sh
./vendor/hey/darwin-arm64/bin/hey package verify-install \
  .hey/packages/hey_web/0.1.1
```

## Develop and verify

Set `HEY_BIN` to the Hey v0.99.198a+ launcher and run:

```sh
HEY_BIN=/path/to/hey-lang/bin/hey ./bin/check
```

The check runs direct source specs, verifies and packs the manifest, installs the
actual release archive into an isolated consumer app, verifies the install
receipt, and runs imports through `pkg:hey_web@0.1.1/...`.

## Release assets

`hey package pack . --out dist` creates:

- `dist/hey_web-0.1.1.zip`
- `dist/hey_web-0.1.1.release.json`

Both files are required for installation.
