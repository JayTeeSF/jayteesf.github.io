# Done

- Replaced the sqlite3 CLI subprocess adapter with Hey native ABI v2.
- Added explicit extension/database/statement ownership.
- Added prepared statements, typed scalar/blob bindings, typed rows, busy timeout, transactions, changes, insert IDs, and interruption.
- Added adapter callbacks compatible with `hey_record@0.2.0`.
- Promoted interpreter and ordinary self-hosted LLVM receipts to the mandatory package gate; private Stage-0 compilation is rejected rather than used as package evidence.
- Kept hey_sqlite3 independent of journal packages and added a fail-closed guard against a `hey_durable_log` manifest/runtime dependency.
- Made loadable-extension capability resolution portable to Apple's SQLite headers by resolving the two optional symbols at runtime and refusing cleanly when absent.
- Made connection close fail while statements remain open, preventing extension unload before deterministic statement finalization.
- Updated native generation to the stable `hey native` command and removed `hey_packager` from runtime dependencies.
- 0.4.0: per-connection prepared-statement cache under query/execute (opt out with `statement_cache: false`), with a spec and a no-reset negative control; `Sqlite3.checkpoint(connection, mode)`; validated `cache_size`, `mmap_size`, `wal_autocheckpoint` connect options. Learned from hey_fast_web.
- 0.5.0: JSON built by SQLite as a first-class adapter call: `Sqlite3.query_json`, `query_rows_json`, `query_row_json` (and `_with` variants taking `json_columns`) return SQLite's own JSON text with no Hey row objects, through the statement cache, with typed refusals (multi-column, non-text, duplicate names, BLOBs). 20-row feed: 245 us (query_params + Json.encode) -> 46 us (`query_rows_json`) / 35 us (`query_json`). `specs/json_spec.hey` with three negative-control builds. Learned from hey_fast_web.
- 0.5.1: hey.lock.json refreshed (it still named the project 0.2.5); hey_packager 0.1.11 controls (no Python); the README and docs version lines are declared in hey-version-files so bin/bump moves them; `.native-build/`, `.hey/` and `build/` are ignored.
