# In progress

The 0.1.4 compatibility release updates `hey_web` to the current `files.exists?` API and external `hey_packager` controls. Package specs include ERB-style EHY rendering and a real localhost socket receipt. External HTTPS receipts on target macOS/Linux hosts remain.
