/* Per-connection prepared-statement cache.
 *
 * Sqlite3.query_params / execute_params used to prepare, run and finalize a
 * statement on every call. Parsing and planning the SQL is often the larger
 * part of a small query, so the adapter now asks this cache for an idle
 * statement with the same SQL text on the same connection, and hands it back
 * reset and unbound when it is done. Statements are prepared with
 * SQLITE_PREPARE_PERSISTENT; SQLite re-prepares one by itself after a schema
 * change (sqlite3_prepare_v3 semantics), so a cached statement never runs a
 * stale plan.
 *
 * Ownership is explicit:
 *   - a statement taken with hey_sqlite3_prepare_cached is "in use" until it
 *     is given back with hey_sqlite3_release_cached; while in use it is never
 *     handed out again (a second request for the same SQL prepares another);
 *   - hey_sqlite3_cache_clear finalizes every idle cached statement of one
 *     connection (the adapter calls it before closing); a statement still in
 *     use is left alone, so sqlite3_close keeps refusing a connection with an
 *     open statement exactly as before;
 *   - at most HEY_SQLITE3_CACHE_PER_CONNECTION idle statements are kept per
 *     connection; past that the least recently used idle one is finalized.
 *
 * One registry for all connections, guarded by one mutex: entries are found
 * by (connection, SQL) and a connection is owned by one thread, so the lock
 * is uncontended in practice.
 */
#include "hey_sqlite3.h"
#include <pthread.h>
#include <sqlite3.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define HEY_SQLITE3_CACHE_PER_CONNECTION 64

typedef struct HeySqlite3CacheEntry {
  sqlite3 *db;
  sqlite3_stmt *statement;
  char *sql;
  size_t sql_length;
  int in_use;
  uint64_t last_used;
} HeySqlite3CacheEntry;

static pthread_mutex_t hey_sqlite3_cache_mutex = PTHREAD_MUTEX_INITIALIZER;
static HeySqlite3CacheEntry *hey_sqlite3_cache = NULL;
static size_t hey_sqlite3_cache_count = 0;
static size_t hey_sqlite3_cache_capacity = 0;
static uint64_t hey_sqlite3_cache_clock = 0;

static void hey_sqlite3_cache_remove_at(size_t index) {
  free(hey_sqlite3_cache[index].sql);
  hey_sqlite3_cache[index] = hey_sqlite3_cache[hey_sqlite3_cache_count - 1];
  hey_sqlite3_cache_count--;
}

/* Finalizes the least recently used idle statement of db when db is at its limit. */
static void hey_sqlite3_cache_evict(sqlite3 *db) {
  size_t idle = 0, oldest = (size_t)-1;
  for (size_t i = 0; i < hey_sqlite3_cache_count; i++) {
    if (hey_sqlite3_cache[i].db != db || hey_sqlite3_cache[i].in_use) continue;
    idle++;
    if (oldest == (size_t)-1 || hey_sqlite3_cache[i].last_used < hey_sqlite3_cache[oldest].last_used) oldest = i;
  }
  if (idle >= HEY_SQLITE3_CACHE_PER_CONNECTION && oldest != (size_t)-1) {
    sqlite3_finalize(hey_sqlite3_cache[oldest].statement);
    hey_sqlite3_cache_remove_at(oldest);
  }
}

HeyNativeHandle hey_sqlite3_prepare_cached(HeyNativeHandle database, HeyNativeUtf8View sql) {
  sqlite3 *db = (sqlite3 *)(uintptr_t)database;
  if (!db) return (HeyNativeHandle)0;
  pthread_mutex_lock(&hey_sqlite3_cache_mutex);
  for (size_t i = 0; i < hey_sqlite3_cache_count; i++) {
    HeySqlite3CacheEntry *e = &hey_sqlite3_cache[i];
    if (e->db == db && !e->in_use && e->sql_length == sql.length && memcmp(e->sql, sql.data, sql.length) == 0) {
      e->in_use = 1;
      e->last_used = ++hey_sqlite3_cache_clock;
      sqlite3_stmt *found = e->statement;
      pthread_mutex_unlock(&hey_sqlite3_cache_mutex);
      return (HeyNativeHandle)(uintptr_t)found;
    }
  }
  pthread_mutex_unlock(&hey_sqlite3_cache_mutex);

  char *sql_c = (char *)malloc(sql.length + 1);
  if (!sql_c) return (HeyNativeHandle)0;
  if (sql.length) memcpy(sql_c, sql.data, sql.length);
  sql_c[sql.length] = '\0';
  sqlite3_stmt *statement = NULL;
  int rc = sqlite3_prepare_v3(db, sql_c, (int)sql.length, SQLITE_PREPARE_PERSISTENT, &statement, NULL);
  if (rc != SQLITE_OK || !statement) {
    if (statement) sqlite3_finalize(statement);
    free(sql_c);
    return (HeyNativeHandle)0;
  }

  pthread_mutex_lock(&hey_sqlite3_cache_mutex);
  hey_sqlite3_cache_evict(db);
  if (hey_sqlite3_cache_count == hey_sqlite3_cache_capacity) {
    size_t capacity = hey_sqlite3_cache_capacity ? hey_sqlite3_cache_capacity * 2 : 32;
    HeySqlite3CacheEntry *grown = (HeySqlite3CacheEntry *)realloc(hey_sqlite3_cache, capacity * sizeof(*grown));
    if (!grown) {
      /* No room to remember it: hand it out uncached; release_cached finalizes it. */
      pthread_mutex_unlock(&hey_sqlite3_cache_mutex);
      free(sql_c);
      return (HeyNativeHandle)(uintptr_t)statement;
    }
    hey_sqlite3_cache = grown;
    hey_sqlite3_cache_capacity = capacity;
  }
  HeySqlite3CacheEntry *e = &hey_sqlite3_cache[hey_sqlite3_cache_count++];
  e->db = db;
  e->statement = statement;
  e->sql = sql_c;
  e->sql_length = sql.length;
  e->in_use = 1;
  e->last_used = ++hey_sqlite3_cache_clock;
  pthread_mutex_unlock(&hey_sqlite3_cache_mutex);
  return (HeyNativeHandle)(uintptr_t)statement;
}

int32_t hey_sqlite3_release_cached(HeyNativeHandle statement_handle) {
  sqlite3_stmt *statement = (sqlite3_stmt *)(uintptr_t)statement_handle;
  if (!statement) return (int32_t)SQLITE_MISUSE;
#ifndef HEY_SQLITE3_NEGATIVE_CONTROL_NO_RESET
  /* The reset's return code repeats the last step's error; the statement is
     reusable either way, so the release itself succeeds. */
  (void)sqlite3_reset(statement);
  (void)sqlite3_clear_bindings(statement);
#endif
  pthread_mutex_lock(&hey_sqlite3_cache_mutex);
  for (size_t i = 0; i < hey_sqlite3_cache_count; i++) {
    if (hey_sqlite3_cache[i].statement == statement) {
      hey_sqlite3_cache[i].in_use = 0;
      pthread_mutex_unlock(&hey_sqlite3_cache_mutex);
      return SQLITE_OK;
    }
  }
  pthread_mutex_unlock(&hey_sqlite3_cache_mutex);
  /* Not remembered (allocation failure above): it was never shared, so finalize it. */
  return (int32_t)sqlite3_finalize(statement);
}

int32_t hey_sqlite3_cache_clear(HeyNativeHandle database) {
  sqlite3 *db = (sqlite3 *)(uintptr_t)database;
  if (!db) return (int32_t)SQLITE_MISUSE;
  int32_t in_use = 0;
  pthread_mutex_lock(&hey_sqlite3_cache_mutex);
  size_t i = 0;
  while (i < hey_sqlite3_cache_count) {
    if (hey_sqlite3_cache[i].db != db) { i++; continue; }
    if (hey_sqlite3_cache[i].in_use) { in_use++; i++; continue; }
    sqlite3_finalize(hey_sqlite3_cache[i].statement);
    hey_sqlite3_cache_remove_at(i);
  }
  pthread_mutex_unlock(&hey_sqlite3_cache_mutex);
  return in_use;
}

int32_t hey_sqlite3_cache_count_for(HeyNativeHandle database) {
  sqlite3 *db = (sqlite3 *)(uintptr_t)database;
  int32_t count = 0;
  pthread_mutex_lock(&hey_sqlite3_cache_mutex);
  for (size_t i = 0; i < hey_sqlite3_cache_count; i++) if (hey_sqlite3_cache[i].db == db) count++;
  pthread_mutex_unlock(&hey_sqlite3_cache_mutex);
  return count;
}
