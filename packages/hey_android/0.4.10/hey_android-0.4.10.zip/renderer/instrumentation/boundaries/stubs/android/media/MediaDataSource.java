package android.media;
import java.io.*;
public abstract class MediaDataSource implements Closeable {
  public abstract int readAt(long position, byte[] buffer, int offset, int size) throws IOException;
  public abstract long getSize() throws IOException;
}
