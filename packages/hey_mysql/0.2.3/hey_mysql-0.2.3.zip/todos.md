# Todo

1. Run configured MySQL 8/9 and MariaDB live matrices, including required and verified TLS plus representative authentication plugins.
2. Implement `MYSQL_STMT` prepared statements and typed/binary parameter/result bindings.
3. Add connection-pool and partitioned-Job ownership helpers.
4. Add Darwin receipts and native Windows receipts after Hey's generic Windows native-loader milestone.
5. Close the generic direct-LLVM dynamic live-SQL supported-subset gap.
6. Evaluate a future pure-Hey asynchronous wire-protocol adapter behind the same public contract.
