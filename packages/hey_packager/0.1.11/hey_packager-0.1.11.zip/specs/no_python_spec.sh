#!/usr/bin/env sh
# Exercise release decisions with neither Python nor pip available on PATH.
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
helper=$("$root/bin/hey-packager" helper-path)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
mkdir -p "$tmp/bin"
for tool in sh env awk basename cat chmod cmp cp cut date diff dirname find git grep head ln ls mkdir mktemp mv od pwd readlink rg rm sed shasum sha256sum sort tail tar touch tr uname unzip wc xargs zip; do
  executable=$(command -v "$tool" || true)
  if [ -n "$executable" ]; then ln -s "$executable" "$tmp/bin/$tool"; fi
done
PATH="$tmp/bin"
export PATH
if command -v python >/dev/null 2>&1 || command -v python3 >/dev/null 2>&1 || command -v pip >/dev/null 2>&1; then
  echo 'isolated PATH unexpectedly contains Python' >&2
  exit 1
fi
HEY_PACKAGER_HELPER="$helper" sh "$root/specs/commands_spec.sh"
echo 'PASS: release decisions with Python absent from PATH'
