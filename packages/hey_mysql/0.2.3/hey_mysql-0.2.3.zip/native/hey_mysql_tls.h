#ifndef HEY_MYSQL_TLS_H
#define HEY_MYSQL_TLS_H

#include <mysql.h>
#include <string.h>

#if defined(HEY_MYSQL_TLS_API_MYSQL) && defined(HEY_MYSQL_TLS_API_MARIADB)
#error "select exactly one MySQL TLS API"
#endif

#if !defined(HEY_MYSQL_TLS_API_MYSQL) && !defined(HEY_MYSQL_TLS_API_MARIADB)
#error "build must define HEY_MYSQL_TLS_API_MYSQL or HEY_MYSQL_TLS_API_MARIADB"
#endif

static const char *hey_mysql_tls_api_name(void) {
#if defined(HEY_MYSQL_TLS_API_MYSQL)
  return "mysql_ssl_mode";
#else
  return "mariadb_legacy_options";
#endif
}

static int hey_mysql_apply_tls_mode(MYSQL *mysql, const char *mode) {
  if (!mysql || !mode) return 1;

#if defined(HEY_MYSQL_TLS_API_MYSQL)
  enum mysql_ssl_mode ssl_mode;
  if (strcmp(mode, "disabled") == 0) {
    ssl_mode = SSL_MODE_DISABLED;
  } else if (strcmp(mode, "preferred") == 0) {
    ssl_mode = SSL_MODE_PREFERRED;
  } else if (strcmp(mode, "required") == 0) {
    ssl_mode = SSL_MODE_REQUIRED;
  } else if (strcmp(mode, "verify_server_cert") == 0) {
    ssl_mode = SSL_MODE_VERIFY_IDENTITY;
  } else {
    return 2;
  }
  return mysql_options(mysql, MYSQL_OPT_SSL_MODE, &ssl_mode);
#else
  my_bool enforce = 0;
  my_bool verify = 0;
  if (strcmp(mode, "disabled") == 0 || strcmp(mode, "preferred") == 0) {
    enforce = 0;
    verify = 0;
  } else if (strcmp(mode, "required") == 0) {
    enforce = 1;
    verify = 0;
  } else if (strcmp(mode, "verify_server_cert") == 0) {
    enforce = 1;
    verify = 1;
  } else {
    return 2;
  }
  int rc = mysql_options(mysql, MYSQL_OPT_SSL_ENFORCE, &enforce);
  if (rc != 0) return rc;
  return mysql_options(mysql, MYSQL_OPT_SSL_VERIFY_SERVER_CERT, &verify);
#endif
}

#endif
