# Continue hey_web

Continue the reusable Hey packages in this workspace against the newest supplied compatible Hey release.

The original goal is to make `hey_web` replace curl/wget-style shell commands and Puma-style Ruby serving while providing Rails-familiar routes, controllers, EHY views/layouts, JSON endpoints, model modules, and Jobs. Database work is split into `hey_record`, `hey_sqlite3`, and `hey_mysql`.

Read in this order:

1. `goals.md`
2. `in-progress.md`
3. `todos.md`
4. `done.md`
5. `README.md`
6. `docs/*.md`
7. `*.hey` package modules
8. `specs/*.hey`

Rules:

- Do not duplicate `stdlib:Web`, `stdlib:Http`, `stdlib:Net`, TLS, EHY, Jobs, or package-manager responsibilities.
- Keep route handlers as first-class source callables; config files carry only the serve options (host, port, workers, request_timeout_ms, max_body_bytes, max_requests). There is no middleware surface: the one serving lane is Web.serve over a flat route table (maintainer ruling 2026-07-30).
- Preserve pure controller dispatch tests and add live receipts separately.
- Slow/retryable work belongs in Jobs.
- Existing specs stay unless explicitly obsolete and replaced by stricter coverage.
- Update `PROMPT.md`, `goals.md`, `todos.md`, `done.md`, and `in-progress.md` with every slice.
- Run `HEY_ROOT=/path/to/hey ./bin/check`, then pack immutable release assets.
- Keep exported module files at the package root until a package-resolver migration is explicitly verified; do not move public module paths casually.
