/* Android implementation of Hey's target-neutral runtime crypto seam. */
#include "hey_android_platform_crypto.h"

#include <errno.h>
#include <stdlib.h>
#include <sys/random.h>

/* Kernel randomness. getrandom blocks only until the pool is first seeded,
 * which has happened long before an app can run. A short read is continued;
 * ENOSYS falls back to bionic's arc4random_buf. */
int hey_runtime_platform_random_bytes(unsigned char *out, size_t length) {
  unsigned char *next = out;
  if (!next && length) return 0;
  while (length > 0) {
    ssize_t got = getrandom(next, length, 0);
    if (got < 0) {
      if (errno == EINTR) continue;
      if (errno == ENOSYS) {
        arc4random_buf(next, length);
        return 1;
      }
      return 0;
    }
    next += got;
    length -= (size_t)got;
  }
  return 1;
}

/* 0 when equal, 1 otherwise; the loop always visits every byte. */
int hey_runtime_platform_constant_time_bcmp(const void *left, const void *right, size_t length) {
  const unsigned char *a = (const unsigned char *)left;
  const unsigned char *b = (const unsigned char *)right;
  unsigned char difference = 0;
  for (size_t i = 0; i < length; i++) difference |= (unsigned char)(a[i] ^ b[i]);
  return difference != 0;
}
