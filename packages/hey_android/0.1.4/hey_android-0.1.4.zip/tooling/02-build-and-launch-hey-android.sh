#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${HEY_ANDROID_ENV_FILE:-$HOME/.config/hey/android.env}"
[ -f "$ENV_FILE" ] || {
  echo "Android environment not found: $ENV_FILE" >&2
  echo "Run 01-install-android-toolchain-macos.sh first." >&2
  exit 1
}
# shellcheck disable=SC1090
source "$ENV_FILE"

HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
SOURCE="${HEY_ANDROID_SOURCE:-$HEY_ROOT/examples/mobile/native_android_app.hey}"
VERSION="$($HEY_ROOT/bin/hey --version)"
OUT="${HEY_ANDROID_OUT:-$HOME/Desktop/hey-android-native-v$VERSION}"
ADB="$ANDROID_HOME/platform-tools/adb"
EMULATOR="$ANDROID_HOME/emulator/emulator"
AVD_NAME="${HEY_ANDROID_AVD_NAME:-Hey_API_34}"

fail() { printf 'error: %s\n' "$*" >&2; exit 1; }
step() { printf '\n== %s ==\n' "$*"; }

[ -x "$HEY_ROOT/bin/hey" ] || fail "Hey executable not found: $HEY_ROOT/bin/hey"
[ -f "$SOURCE" ] || fail "Hey Android source not found: $SOURCE"
[ -x "$ADB" ] || fail "adb not found: $ADB"
command -v gradle >/dev/null 2>&1 || fail "pinned Gradle is not on PATH; rerun the installer"

serial="${ANDROID_SERIAL:-}"
if [ -z "$serial" ]; then
  serial="$($ADB devices | awk 'NR > 1 && $2 == "device" { print $1; exit }')"
fi

if [ -z "$serial" ]; then
  step "Start Android emulator $AVD_NAME"
  [ -x "$EMULATOR" ] || fail "Android emulator not found: $EMULATOR"
  emulator_log="$HOME/Desktop/hey-android-emulator.log"
  nohup "$EMULATOR" -avd "$AVD_NAME" >"$emulator_log" 2>&1 &
  printf 'emulator_log=%s\n' "$emulator_log"
  "$ADB" wait-for-device
  until [ "$("$ADB" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ]; do
    sleep 2
  done
  serial="$($ADB devices | awk 'NR > 1 && $2 == "device" { print $1; exit }')"
fi
[ -n "$serial" ] || fail "no authorized Android device or booted emulator was found"
printf 'android_device=%s\n' "$serial"

step "Run Hey Android doctor"
cd "$HEY_ROOT"
./bin/hey mobile android doctor

step "Build, install, and launch the ordinary-Hey Android app"
rm -rf "$OUT"
./bin/hey mobile android app \
  --source "$SOURCE" \
  --out "$OUT" \
  --target-sdk "${HEY_ANDROID_API:-34}" \
  --build \
  --launch \
  --device "$serial"

step "Generate a Gradle Wrapper inside the project"
gradle -p "$OUT" --no-daemon wrapper \
  --gradle-version "${HEY_ANDROID_GRADLE_VERSION:-8.7}" \
  --distribution-type bin

step "Capture target evidence"
"$ADB" -s "$serial" logcat -d > "$OUT/adb-logcat.txt" || true
"$ADB" -s "$serial" exec-out screencap -p > "$OUT/android-screenshot.png" || true
"$ADB" -s "$serial" shell dumpsys activity activities > "$OUT/adb-activity.txt" || true

cat "$OUT/STATUS.md"
cat "$OUT/receipt.json"
file "$OUT/app/build/outputs/apk/debug/app-debug.apk"
printf 'project=%s\n' "$OUT"
printf 'screenshot=%s\n' "$OUT/android-screenshot.png"
printf '\nAndroid native app launched successfully.\n'
