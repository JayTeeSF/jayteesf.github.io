#ifndef HEY_DURABLE_LOG_TEST_HOOKS_H
#define HEY_DURABLE_LOG_TEST_HOOKS_H

#ifdef HDL_ENABLE_TEST_HOOKS
void hdl_test_fail_next_sync(void);
void hdl_test_fail_write_after_bytes(long long bytes);
void hdl_test_kill_during_write_after_bytes(long long bytes);
void hdl_test_kill_before_next_sync(void);
void hdl_test_kill_after_next_sync(void);
void hdl_test_clear_failures(void);
#endif

#endif
