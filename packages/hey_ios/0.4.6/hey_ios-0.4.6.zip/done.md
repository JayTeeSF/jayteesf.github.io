# Done

- v0.1.0 capability and framework contracts.
- Development entitlement metadata without manufacturing unsupported profile entitlements.
- Updated package controls for external `hey_packager` tooling and the repaired `hey_mobile` dependency.
- v0.2.0 native host for `hey_mobile` 0.2.0 `api_screens` apps: the renderer (tabs, lists, detail, forms, inline half-star rating, sign-in sheet, search with polling and a note when incomplete, document upload, video, web links, tab badges, rows still being looked up), the Keychain session, audio (pages in order with resume and one position report per item in flight, Apple Music, Now Playing, remote commands), a share extension, and `tools/hey-ios-api-app.sh` for simulator and paired-iPhone builds with development profiles and an app icon from one 1024 square. CarPlay moved out to `hey_carplay` behind `--extension DIR` and three audio-feed hooks, so the host names no extension. First consumer: My Queue.
- v0.3.0 renderer level 2: served, stored and baked descriptions with ETag revalidation on launch and foreground; unknown kinds hidden and never sent; `HeyIOSValues` passing hey_mobile's 117 value vectors, 21 served descriptions and the icon table (`bin/conformance`, with a control); the origin baked beside the description; the detail screen removed. First app: My Queue on iPhone.
- v0.3.1 signing in no longer crashes on a phone. In 0.3.0 the form's request chain freed its own running block (clearing `hold`, the last reference to it) and then read `finish` from the freed memory: EXC_BAD_ACCESS at 0x10 on the main thread in `-[HeyIOSFormController submit]`, on an iPhone only, because the simulator had not reused the memory. The list's reorder chain did the same before reloading. Both now copy what they use into locals first. `bin/block-lifetimes` runs both chains under AddressSanitizer on the iOS Simulator, with a control per chain that reverts the fix and must stop with a heap-use-after-free.
- v0.3.2: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes.
- v0.3.3: depends on `hey_mobile` ^0.3.0 instead of exactly 0.3.0, so an app can take a newer hey_mobile 0.3.x. The renderer is unchanged.
# 0.4.5 — arm64 on the share extension in distribution builds

- `--distribution` now stamps `UIRequiredDeviceCapabilities` `arm64` on the share extension as well as the app. App Store Connect validates it on every arm64 bundle in an upload and refused a share extension without it (my_queue_2, 2026-09-15). Measured on MyQueue 1.0.3: `check-ios-pack` 68/70 before, 69/70 after; the remaining failure is the CarPlay entitlement Apple has not granted yet.

# 0.4.4 — runtime-free manifest-length ABI

- Current Hey rejects typed parameter syntax and lowers untyped `ios_action_code(action_id)` through a pointer value plus `hey_llvm_*` calls, which cannot link into this package's deliberately runtime-free manifest shell.
- Shells now export zero-argument `ios_manifest_length()`. The app and share extension call it through one generated no-argument bridge.
- The builder keeps compatibility with legacy shells only when their compiler emits the original runtime-free `i64 -> i64` action ABI; pointer-shaped legacy exports remain refused.
- `specs/manifest_contract_spec.sh` builds the current shell and share extension with the real toolchain, asserts the stripped IR has no Hey runtime calls, and proves the unsafe legacy shape is rejected.
# 0.4.6 — the keyboard on a search list can always be put away

- `HeyIOSListController` (search screens such as My Queue's Add) had none of the form renderer's keyboard handling, so a focused search field left no way out and covered the tab bar. Now: a Cancel button beside the field while it is focused (clears the text and dismisses); dragging the results dismisses interactively; a tap on empty space or a section header dismisses (rows and the field still take their own taps, and the first tap on a row opens it); the Search key is enabled with an empty field and always dismisses; the keyboard is put away when a row opens and when the screen is left, so Back no longer raises it again. Verified on the iOS Simulator (iPhone 17 Pro, iOS 26.5) on My Queue's Add screen, all six behaviours before and after (my_queue_2, 2026-10-06).
