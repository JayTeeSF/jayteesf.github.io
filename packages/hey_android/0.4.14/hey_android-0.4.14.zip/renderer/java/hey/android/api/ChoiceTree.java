package hey.android.api;

import java.util.*;

/** Bounded, validated choice data. Disclosure never changes a form value. */
public final class ChoiceTree {
  /** Static options and remote rows are bounded separately; iOS allows the same 4096 remote rows. */
  private static final int MAX_STATIC = 1000, MAX_REMOTE = 4096, MAX_DEPTH = 64, MAX_TEXT = 4096;
  public static final class Row {
    public final String key, label, value;
    public final boolean selectable, children;
    public final int depth;
    Row(Node node, int depth) {
      key=node.key; label=node.label; value=node.value; selectable=node.selectable;
      children=!node.children.isEmpty(); this.depth=depth;
    }
  }
  private static final class Node {
    String key,label,value,parent;
    boolean selectable;
    final List<Node> children=new ArrayList<>();
  }
  private final List<Node> roots=new ArrayList<>();
  private final Set<String> expanded=new HashSet<>();
  private final Map<String,String> labels=new LinkedHashMap<>();

  private static String text(Object value) {
    String s=Values.string(value);
    if(s.length()>MAX_TEXT) throw new IllegalArgumentException("Choice text too long");
    return s;
  }

  /**
   * Choice loading is always a bodyless read. The method may be absent or GET
   * in any case; `body` may be absent or an empty object, and anything else is
   * refused (as on iOS) rather than silently dropped.
   */
  public static Map<String,Object> readRoute(Map<String,Object> field) {
    Map<String,Object> choices=Json.dict(field.get("choices"));
    String method=Values.string(choices.get("method"));
    if(!method.isEmpty() && !method.equalsIgnoreCase("GET"))
      throw new IllegalArgumentException("Choices require a read request.");
    if(choices.containsKey("body") && !(choices.get("body") instanceof Map && ((Map<?,?>)choices.get("body")).isEmpty()))
      throw new IllegalArgumentException("Choices are a read and take no body.");
    String path=Values.string(choices.get("path"));
    if(path.isEmpty()) throw new IllegalArgumentException("Choices need a path.");
    Map<String,Object> route=new LinkedHashMap<>();
    route.put("method","GET");route.put("path",path);return route;
  }

  public static ChoiceTree parse(Map<String,Object> field,Object response) {
    return parse(field,response,Collections.emptyMap());
  }

  /** LABELS are the description's value labels, for a `{label:path}` template in `choices.label`. */
  public static ChoiceTree parse(Map<String,Object> field,Object response,Map<String,Object> labels) {
    ChoiceTree result=new ChoiceTree();
    int index=0;
    // A static choice such as "Only this item" owns its value; a selectable
    // remote row with that value, or none, would silently mean the same.
    Set<String> staticValues=new HashSet<>();
    for(Map<String,Object> option:Screens.options(field)) {
      if(++index>MAX_STATIC) throw new IllegalArgumentException("Too many choices");
      Node node=new Node(); node.key="static:"+index; node.label=text(option.get("title"));
      node.value=text(option.get("value")); node.selectable=true; result.roots.add(node);
      staticValues.add(node.value); result.labels.putIfAbsent(node.value,node.label);
    }
    Map<String,Object> choices=Json.dict(field.get("choices"));
    if(choices.isEmpty()) return result;
    Object raw=Values.at(response,Values.string(choices.get("list")));
    if(!(raw instanceof List)) throw new IllegalArgumentException("Choices must be a list");
    List<?> data=(List<?>)raw;
    if(data.size()>MAX_REMOTE) throw new IllegalArgumentException("Too many choices");
    Map<String,Object> tree=Json.dict(choices.get("tree"));
    LinkedHashMap<String,Node> nodes=new LinkedHashMap<>();
    for(Object item:data) {
      if(!(item instanceof Map)) throw new IllegalArgumentException("Invalid choice");
      // Flat choices honour `where` as iOS and action choices do. A tree is not
      // filtered: dropping a parent would orphan its children.
      if(tree.isEmpty() && !Values.when(choices.get("where"),item)) continue;
      String id=tree.isEmpty()?Integer.toString(++index):text(Values.at(item,Values.string(tree.get("id"))));
      if(id.isEmpty() || nodes.containsKey(id)) throw new IllegalArgumentException("Duplicate or empty choice ID");
      Node node=new Node(); node.key="remote:"+id;
      node.value=text(Values.at(item,Values.string(choices.get("value"))));
      // A label is a line (a path, template or list of parts) as for action
      // choices. Without one a row is named by its value, a tree row by the
      // value's last path component, as iOS names it.
      String label=Values.line(choices.get("label"),item,labels);
      node.label=text(label.isEmpty()?(tree.isEmpty()?node.value:lastComponent(node.value)):label);
      node.parent=tree.isEmpty()?"":text(Values.at(item,Values.string(tree.get("parent"))));
      Object selectable=tree.isEmpty()?Boolean.TRUE:Values.at(item,Values.string(tree.get("selectable")));
      if(!(selectable instanceof Boolean)) throw new IllegalArgumentException("Invalid choice selection flag");
      node.selectable=Boolean.TRUE.equals(selectable);
      if(!tree.isEmpty() && node.selectable && (node.value.isEmpty() || staticValues.contains(node.value)))
        throw new IllegalArgumentException("A selectable choice needs its own value");
      if(node.selectable) result.labels.putIfAbsent(node.value,node.label);
      nodes.put(id,node);
    }
    for(Node node:nodes.values()) {
      Set<String> visited=new HashSet<>(); Node cursor=node;
      for(int depth=0;cursor!=null;depth++) {
        if(depth>MAX_DEPTH || !visited.add(cursor.key)) throw new IllegalArgumentException("Cyclic or deep choice tree");
        if(cursor.parent.isEmpty()) break;
        cursor=nodes.get(cursor.parent);
        if(cursor==null) throw new IllegalArgumentException("Unknown choice parent");
      }
      if(node.parent.isEmpty()) result.roots.add(node);
      else nodes.get(node.parent).children.add(node);
    }
    return result;
  }
  /** NSString.lastPathComponent: trailing slashes ignored; "/" stays "/". */
  static String lastComponent(String value) {
    String trimmed=value;
    while(trimmed.length()>1 && trimmed.endsWith("/")) trimmed=trimmed.substring(0,trimmed.length()-1);
    int slash=trimmed.lastIndexOf('/');
    String last=slash<0||trimmed.length()==1?trimmed:trimmed.substring(slash+1);
    return last.isEmpty()?value:last;
  }
  /** The label for each selectable value, so a stored value is shown by name. */
  public Map<String,String> labels() { return java.util.Collections.unmodifiableMap(labels); }
  public List<Row> rows() {
    List<Row> rows=new ArrayList<>(); append(roots,0,rows); return rows;
  }
  private void append(List<Node> nodes,int depth,List<Row> rows) {
    for(Node node:nodes) {
      rows.add(new Row(node,depth));
      if(expanded.contains(node.key)) append(node.children,depth+1,rows);
    }
  }
  public boolean expanded(String key) { return expanded.contains(key); }
  public void toggle(String key) { if(!expanded.remove(key)) expanded.add(key); }
}
