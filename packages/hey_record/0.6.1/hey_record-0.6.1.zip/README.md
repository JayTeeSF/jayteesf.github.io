# hey_record

`hey_record` is database-independent porcelain for Hey. It combines Sequel-style immutable datasets and explicit connections with a small Active Record-style model/migration vocabulary, plus a JSON record store and a migration ledger extracted from a production application.

It contains no C code and no database driver. Applications choose `hey_sqlite3`, `hey_mysql`, or another adapter implementing the connection callback contract.

The repository is at package version 0.3.0, which ships the record store, migration ledger, and dialect refusal described below (new since 0.2.5).

## Plumbing and porcelain

- Driver packages own native handles, sockets, blocking policy, parameter binding, and rows.
- `hey_record` owns SQL plans, dialect quoting, datasets, transactions, model descriptors, migration DDL, the record store, and the migration ledger.
- Applications own domain models, validations, authorization, Jobs, and deployment configuration.

## The record store (`store.hey`)

`HeyRecordStore` is a JSON record/document store keyed by collection + id, extracted from RecallCoach's proven `RecallStorage` module: one API over two backends.

```hey
import 'pkg:hey_record@<version>/store'

# File backend: <root>/<collection>/<id>.json, atomic writes.
let store = HeyRecordStore.file('build/data')
let booted = HeyRecordStore.boot(store, ['cards', 'decks'])

# SQL backend: one table over an injected open connection.
# let opened = Mysql.connect(options)            (hey_mysql)
# let store = HeyRecordStore.sql(opened.value, 'app_records')
# let booted = HeyRecordStore.boot(store, [])

let saved = HeyRecordStore.store(store, 'cards', 'ada', {name: 'Ada', score: 42})
let fetched = HeyRecordStore.fetch(store, 'cards', 'ada')   # Result of decoded JSON
let ids = HeyRecordStore.list(store, 'cards')               # Result of sorted ids
```

Surface:

- `HeyRecordStore.file(root)` / `HeyRecordStore.sql(connection, table)` -- backend descriptors.
- `boot(store, collections)` -- file: ensure root plus one directory per collection (the collection list is the application's, a parameter); sql: apply the store DDL through the connection.
- `store(store, collection, id, value)` -- canonical-JSON upsert.
- `fetch(store, collection, id)` -- point fetch; a missing record is the typed error `not_found`, never nil.
- `delete(store, collection, id)` -- remove one record; deleting an absent record is the typed error `not_found` so callers can distinguish a real removal from a no-op. On the SQL backend that contract rides on the adapter's affected-rows count (`changes`); an adapter that does not report it cannot detect absence and the delete is then reported ok (the honest limit).
- `list(store, collection)` -- sorted record ids; a never-written collection lists empty.
- `ddl(dialect, table)` / `upsert_sql(dialect, table)` -- the SQL the sql backend runs, exposed for conformance receipts.
- `prepare(connection, table)` -- apply the store DDL through an injected connection.

The SQL backend's table shape is the one RecallCoach proved in production: `collection_name VARCHAR(64)`, `record_id VARCHAR(191)`, `payload LONGTEXT`, timestamps, composite primary key. The upsert is parameterized; dialect divergence is exactly the clause suffix (`ON DUPLICATE KEY UPDATE` for mysql, `ON CONFLICT ... DO UPDATE` for sqlite3).

Deliberate store limits:

- **Delete is for domains that genuinely remove records.** RecallCoach, the application this store was extracted from, deliberately never calls it: its pattern is expiry-at-read (a fetched payload carrying its own staleness marker is overwritten or ignored by the consumer). Do not cargo-cult deletion into an import-back.
- **The store never dials.** It takes an open connection (or a file root); connection lifetime, pooling, and per-operation dialing are the caller's policy. `hey_record` keeps zero driver dependencies.
- **No nil across the API.** Every operation returns a Result record with typed error codes (`not_found`, `storage_read_failed`, `storage_write_failed`, `invalid_collection`, `invalid_record_id`).

## Three backends behind one interface (the ActiveRecord shape)

`HeyRecordStore.sql(connection, table)` takes any record implementing the
connection callback contract (`dialect` + `query`/`query_params`/`execute`/
`execute_params`, optionally `begin`/`commit`/`rollback`/`close`). Every adapter
plugs in there, so one harness swaps backends without touching the store calls
(see `bench/scaling_bench.hey`, one workload, `BACKEND=` selects the adapter).

- **durable_log + sqlite3** (`durable.hey`, `HeyRecordDurable`) — a SINGLE
  durable-log-fronted sqlite3 backend. A write appends to hey_durable_log FIRST
  and is acknowledged only once the append receipt crosses the durability
  boundary (the receipt IS the ACK); sqlite3 is the queryable projection of that
  same mutation stream. If durability is refused the projection is never
  touched. Reads go straight to the sqlite projection.
- **postgres** (`pg.hey`, `HeyRecordPg`) — bridges hey_postgres (which returns a
  bare rows array / `{affected}` and binds `$1..$n`) into the same contract,
  dependency-injecting the driver functions so hey_record still imports no
  driver. hey_record's portable `?` placeholders are renumbered to `$1..$n`.
- **mysql** (`hey_mysql`) — already returns a `hey_record_connection` directly.

```hey
import 'pkg:hey_record@<v>/durable'
let sql = Sqlite3.connect('app.sqlite3', {}).value
let journal = DurableLog.open('app.hdl', {}).value
let conn = HeyRecordDurable.connection(sql, journal, 1)   # one integer stream
let store = HeyRecordStore.sql(conn, 'app_records')       # identical from here

import 'pkg:hey_record@<v>/pg'
let pg = Postgres.open({host: '...', dbname: '...', user: '...'}).value
let pconn = HeyRecordPg.connection(pg, {query: Postgres.query, execute: Postgres.execute, close: Postgres.close})
let pstore = HeyRecordStore.sql(pconn, 'app_records')
```

The stub-connection gate (`specs/pg_durable_spec.hey`) proves the bridges with
no server or native library; the live end-to-end proofs against real
sqlite3/durable_log/postgres/mysql are in `specs_live/` and run by hand with the
adapters' native libraries.

## The migration ledger (`migrate.hey`)

`HeyRecordMigrate` records applied migration ids -- the `schema_migrations` bookkeeping the DDL builders in `migration.hey` never had.

```hey
import 'pkg:hey_record@<version>/migrate'

let migrations = [
  HeyRecordMigrate.migration('001_create_records', 'CREATE TABLE ...'),
  HeyRecordMigrate.migration('002_add_index', 'CREATE INDEX ...')
]

# SQL target: ledger table schema_migrations(version PRIMARY KEY, applied_at).
let outcome = HeyRecordMigrate.ensure(connection, migrations)

# File target: ledger directory <root>/schema_migrations/<id>.json; the
# migration sql is a deliberate no-op (a file tree has no DDL), so file-mode
# apps stay in step with their SQL-mode twins.
let outcome = HeyRecordMigrate.ensure(HeyRecordMigrate.file('build/data'), migrations)
```

Surface:

- `migration(id, sql)` -- one step; ids are the ledger keys (zero-padded sortable prefixes by convention).
- `ensure(target, migrations)` -- ensure the ledger, apply every not-yet-applied migration in the order given, record each id. Idempotent: a second run applies nothing. Returns `{applied, skipped}`. Accepts a bare connection record as the target.
- `ensure_ledger(target)`, `applied(target)`, `is_applied(target, id)` -- the ledger primitives. (`is_applied` is deliberately not `applied?`: module-level `?`-named functions returning Result records mislower on the current trunk; `?` names stay reserved for plain-boolean returns.)

## Lineage

The store and ledger generalize RecallCoach (`recall_coach_app`): `domain/storage.hey` (the file/mysql `RecallStorage` shape), `db/prepare.hey` plus `db/001_create_recall_coach_records.sql` (absorbed by `HeyRecordStore.prepare` and the ledger), and `bin/db-prepare` (now a thin wrapper an application scaffolds around `HeyRecordMigrate.ensure`).

## Dialects

`HeyRecordDialect.named` refuses unknown dialect names. Through 0.2.5 it silently defaulted to sqlite3, which let a typo'd dialect emit wrong SQL against a real server.

## Datasets and models

```hey
import 'pkg:hey_record@<version>/main'
import 'pkg:hey_sqlite3@<version>/main'

let opened = Sqlite3.connect('app.sqlite3', {})
let database = opened.value
let Cards = HeyRecordModel.define(database, 'cards', {timestamps: true})

HeyRecordModel.create(Cards, {name: 'Ada'})
let cards = HeyRecordModel.where(Cards, {name: 'Ada'})
let rows = HeyRecord.all(cards)

HeyRecord.close(database)
```

## Parameterized plans

Dataset reads/writes create `{sql, parameters}` plans. SQLite binds them with native prepared statements. The MySQL 0.2.5 adapter uses Connector/C escaping and declares that limitation; its planned 0.3.0 release will provide server-side statements.

## Deliberate limits

Associations, validations, callbacks, identity maps, schema dumping, down-migrations, and connection pools are not yet claimed. They should be added as independent, testable porcelain rather than hidden inside the language or native drivers.

Compiled-lane honesty: `bin/check` builds a compiled receipt (`tools/compiled_receipt.hey`) and demands byte-identical interpreter/binary output for the store, ledger, dialect, SQL-plan, and dataset modules. `model.hey` is interpreter-lane only for now: `HeyRecordModel.find` does not lower on the current trunk (the `HeyRecord.first` call is mis-resolved as the collections builtin `first`).

## Long-lived readers (`reader.hey`)

Open a database once per serving worker instead of once per query. Opening
costs more than a typical query, and concurrent opens and closes contend on the
database file. A kept connection also keeps the adapter's prepared statements
(hey_sqlite3 caches them per connection). Measured on Elders Prayer
(`/api/schedule`, 64 clients, the same machine and data): 8,516 req/s at
22.8 ms p95 and 251 MB opening per query, against 56,328 req/s at 1.25 ms p95
and 60 MB with readers on Hey 0.99.611a.

```hey
import 'pkg:hey_record@0.6.1/reader'
import 'pkg:hey_sqlite3@0.5.3/adapter'

module Readers
  fn open()
    return HeyRecordReader.open({
      connect: Sqlite3.connect, path: Db.path(), connect_options: {},
      setup: HeyRecordReader.sqlite_setup(),   # PRAGMA query_only = ON
      warm: [HOT_SQL]                          # prepared before the first request
    })
  end
  fn close(reader)
    return HeyRecordReader.release(reader)
  end
end
Web.serve(routes, {workers: 4, max_connections: 64,
  worker_resource: {open: Readers.open, close: Readers.close}})

fn schedule(request)
  let db = HeyRecordReader.connection(request)   # nil without a reader
  ...
end
```

Give Web.serve plain module functions like these, which build the spec on
each call. `HeyRecordReader.hooks(spec)` returns the same pair over
`bind(open, spec)`, but Web.serve calls `open` from many worker threads, and
on the Hey 0.99.611a candidate the bound spec was corrupted after a few
worker retirements. In War Room's soak, every open failed from the fourth
30-second round on (1,655,088 failures); with plain functions the same app
served 9.17M requests with none. Use `hooks` only from one thread (a single
HeyWebPoller loop, a CLI) until Hey shares bound values safely.

Each serving worker opens one reader the first time it serves and closes it
when it retires. The worker bound is therefore the connection bound:
`max_connections` on the default poll backend, `handler_workers` on a
readiness backend.

`connection(request)` returns nil when the request carries no reader. Hey
0.99.610a ignores `worker_resource`, and tests and command-line tools call
handlers directly. Code that opens a connection when it gets nil runs
unchanged on both runtimes. Elders measured identically on 610a with and
without the change.

A failed `setup` or `warm` statement closes the connection and fails the
open, so Web.serve answers 503 instead of serving from a half-made reader.
Writes stay on their own connection per call, since SQLite serializes writers.

## Standard package controls

This package uses `hey_packager` 0.1.2 or newer as external validation and release tooling. It is not an application runtime dependency.

```sh
export HEY_ROOT="$HOME/dev/hey-lang-bootstrap-plan"
export HEY_PACKAGER_ROOT="$HOME/dev/hey_packager"

bin/check
bin/release
bin/source-zip
bin/publish --no-commit
```

`bin/source-zip` creates an unverified source-handoff archive; run `bin/check` before relying on it. `bin/package-zip` remains a compatibility alias for `bin/release`. Use `bin/publish` only when the version does not already exist under `$HOME/dev/jayteesf.github.io/packages/hey_record`.

## Bounded stream capability

Import the stream module to call HeyRecordStream.open, read, close and load_file. The connection supplies optional stream_open and bulk_load_file callbacks; stream values supply read_batch and close. Adapters without the capability fail explicitly. The layer contains no engine handles or native FFI. Limits bound rows, frame bytes and record bytes before dispatch.
