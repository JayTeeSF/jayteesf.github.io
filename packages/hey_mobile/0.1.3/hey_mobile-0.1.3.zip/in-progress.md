# In progress

The 0.1.3 package compatibility release is ready for validation and immutable publication.

- VSS as first iOS consumer.
- API stabilization before Android implementation.
