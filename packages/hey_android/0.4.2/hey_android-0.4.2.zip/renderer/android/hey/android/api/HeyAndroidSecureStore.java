package hey.android.api;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * The session token, sealed with an AES-256-GCM key that lives in the Android
 * Keystore and never leaves it. The sealed bytes are in the app's no-backup
 * directory, so neither Auto Backup nor a device transfer carries them: the
 * Android side of iOS's AfterFirstUnlockThisDeviceOnly. The key needs no user
 * authentication, so a locked phone can still send the token.
 *
 * File: one version byte (1), one IV length byte, the IV, the ciphertext.
 */
final class HeyAndroidSecureStore {
  private static final String TAG = "hey.api";
  private final String alias;
  private final File file;

  HeyAndroidSecureStore(Context context, String storeName) {
    String name = storeName == null || storeName.isEmpty() ? "session" : storeName;
    this.alias = "hey.android.api.session." + name;
    this.file = new File(context.getNoBackupFilesDir(), "hey-session-" + Descriptions.sha256Hex(name.getBytes(StandardCharsets.UTF_8)).substring(0, 16) + ".bin");
  }

  File file() { return file; }

  private SecretKey key() throws Exception {
    KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
    ks.load(null);
    if (ks.containsAlias(alias)) {
      return ((KeyStore.SecretKeyEntry) ks.getEntry(alias, null)).getSecretKey();
    }
    KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
    generator.init(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .build());
    return generator.generateKey();
  }

  /** The token, or null when none is kept or it cannot be opened (then it is removed). */
  String read() {
    if (!file.exists()) return null;
    try {
      byte[] sealed = Files.readAllBytes(file.toPath());
      if (sealed.length < 3 || sealed[0] != 1) throw new IllegalStateException("unknown format");
      int ivLength = sealed[1] & 0xff;
      byte[] iv = Arrays.copyOfRange(sealed, 2, 2 + ivLength);
      byte[] ciphertext = Arrays.copyOfRange(sealed, 2 + ivLength, sealed.length);
      Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
      return new String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8);
    } catch (Exception e) {
      Log.w(TAG, "secure store: the kept session could not be opened (" + e.getClass().getSimpleName() + "); it is removed");
      clear();
      return null;
    }
  }

  boolean write(String token) {
    try {
      Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.ENCRYPT_MODE, key());
      byte[] iv = cipher.getIV();
      byte[] ciphertext = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
      byte[] sealed = new byte[2 + iv.length + ciphertext.length];
      sealed[0] = 1;
      sealed[1] = (byte) iv.length;
      System.arraycopy(iv, 0, sealed, 2, iv.length);
      System.arraycopy(ciphertext, 0, sealed, 2 + iv.length, ciphertext.length);
      File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
      try (FileOutputStream out = new FileOutputStream(tmp)) {
        out.write(sealed);
        out.getFD().sync();
      }
      if (!tmp.renameTo(file)) throw new IllegalStateException("rename failed");
      Log.i(TAG, "secure store: session sealed with Keystore key " + alias + " (" + sealed.length + " bytes)");
      return true;
    } catch (Exception e) {
      Log.w(TAG, "secure store: could not seal the session (" + e.getClass().getSimpleName() + ")");
      return false;
    }
  }

  void clear() {
    if (file.exists() && !file.delete()) Log.w(TAG, "secure store: could not remove the session file");
  }
}
