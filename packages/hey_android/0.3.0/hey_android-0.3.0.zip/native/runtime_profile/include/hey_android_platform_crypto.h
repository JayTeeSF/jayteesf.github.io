/* hey_android runtime profile: the platform-crypto primitives for bionic.
 *
 * WHY THIS EXISTS. The Hey runtime (hey_runtime.c, compiled unmodified) needs
 * three primitives on every target: secure random bytes, SHA-256 of a file,
 * and a constant-time compare. When HEY_RUNTIME_APPLE_CRYPTO is defined it
 * takes them from the platform through <CommonCrypto/CommonDigest.h>,
 * <CommonCrypto/CommonRandom.h> and timingsafe_bcmp. Otherwise it takes them
 * from OpenSSL, and the Android NDK has no OpenSSL.
 *
 * So tools/hey-android-app.sh defines HEY_RUNTIME_APPLE_CRYPTO together with
 * HEY_RUNTIME_NO_TLS_CLIENT, _NO_TLS_SERVER, _NO_AEAD and _NO_PASSWORD_KDF, and
 * puts native/runtime_profile/include first on the include path. The two
 * CommonCrypto headers in this directory forward here. With every OpenSSL
 * consumer excluded or served by the platform seam, the runtime derives
 * HEY_RUNTIME_NO_OPENSSL itself and never includes an OpenSSL header.
 *
 * Every platform name is renamed to a hey_android_ function below, so the
 * shared library carries no Apple or OpenSSL symbol names (the tool's .so
 * check fails the build if one appears).
 *
 *   SHA-256        native/vendor/sha256 (Brad Conte, public domain)
 *   secure random  getrandom(2); arc4random_buf only if the kernel lacks it
 *   compare        a byte loop with no data-dependent branch
 *
 * TLS, AES-256-GCM, scrypt and Argon2id are not provided: the runtime reports
 * them as unavailable with named errors (crypto_aead_unavailable,
 * crypto_kdf_unavailable). The seam is named for Apple in the runtime; the
 * request for a platform-neutral name is in docs/ROADMAP.md. */
#ifndef HEY_ANDROID_PLATFORM_CRYPTO_H
#define HEY_ANDROID_PLATFORM_CRYPTO_H

#if !defined(__ANDROID__)
#error "hey_android's platform crypto profile is for Android targets only"
#endif

#include <stddef.h>
#include <stdint.h>

typedef uint32_t CC_LONG;
#define CC_SHA256_DIGEST_LENGTH 32
#define kCCSuccess 0

/* Same size as the vendored SHA256_CTX; hey_android_platform_crypto.c checks
 * that at compile time and copies in and out, so no pointer is type-punned. */
typedef struct {
  unsigned char data[64];
  uint32_t datalen;
  unsigned long long bitlen;
  uint32_t state[8];
} CC_SHA256_CTX;

#define CC_SHA256_Init hey_android_sha256_init
#define CC_SHA256_Update hey_android_sha256_update
#define CC_SHA256_Final hey_android_sha256_final
#define CCRandomGenerateBytes hey_android_random_bytes
#define timingsafe_bcmp hey_android_timingsafe_bcmp

int hey_android_sha256_init(CC_SHA256_CTX *ctx);
int hey_android_sha256_update(CC_SHA256_CTX *ctx, const void *data, CC_LONG length);
int hey_android_sha256_final(unsigned char *digest, CC_SHA256_CTX *ctx);
int hey_android_random_bytes(void *bytes, size_t count);
int hey_android_timingsafe_bcmp(const void *left, const void *right, size_t length);

#endif
