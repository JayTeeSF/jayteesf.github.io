#ifndef HEY_DURABLE_LOG_NATIVE_H
#define HEY_DURABLE_LOG_NATIVE_H

#include "hey_native_abi.h"

HeyNativeHandle hey_durable_log_native_open(HeyNativeUtf8View path,
                                             int32_t queue_capacity,
                                             int32_t max_batch_records,
                                             int32_t batch_window_microseconds);
int32_t hey_durable_log_native_close(HeyNativeHandle connection);
/* Classify a failed open. `open` can only answer "a handle or nothing", which
   collapses corruption, a bad path and ENOMEM into one indistinguishable
   failure -- and an operator's response to a CORRUPT journal (stop, restore
   from a verified snapshot) is nothing like the response to a typo. This
   re-runs the open and reports the hdl_status it reached, closing anything it
   managed to open. It is called only on the failure path. */
int32_t hey_durable_log_native_open_status(HeyNativeUtf8View path,
                                            int32_t queue_capacity,
                                            int32_t max_batch_records,
                                            int32_t batch_window_microseconds);
HeyNativeHandle hey_durable_log_native_submit(HeyNativeHandle connection,
                                               int64_t stream_id,
                                               HeyNativeBytesView payload);
int32_t hey_durable_log_native_receipt_status(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_sequence(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_batch_id(HeyNativeHandle receipt);
int64_t hey_durable_log_native_receipt_durable_offset(HeyNativeHandle receipt);
void hey_durable_log_native_receipt_close(HeyNativeHandle receipt);
HeyNativeHandle hey_durable_log_native_cursor_open(HeyNativeHandle connection);
HeyNativeHandle hey_durable_log_native_cursor_next(HeyNativeHandle cursor);
int32_t hey_durable_log_native_cursor_close(HeyNativeHandle cursor);
int32_t hey_durable_log_native_record_status(HeyNativeHandle record);
int64_t hey_durable_log_native_record_sequence(HeyNativeHandle record);
int64_t hey_durable_log_native_record_batch_id(HeyNativeHandle record);
int64_t hey_durable_log_native_record_stream_id(HeyNativeHandle record);
HeyNativeBytesView hey_durable_log_native_record_payload(HeyNativeHandle record);
void hey_durable_log_native_record_close(HeyNativeHandle record);

#endif
