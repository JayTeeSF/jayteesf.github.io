#!/usr/bin/env sh
set -eu
PACKAGE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"

usage() {
  cat <<'HELP'
Hey party application scaffolding

  hey party init --out DIRECTORY [--name NAME] [--base-url URL]

Generates an authoritative-room starter with a native-TV public-state contract,
mobile-web private controllers, signed QR join payloads, reconnect tokens, and
current immutable package requirements.
HELP
}

case "${1:-}" in
  init)
    shift
    out=''; name='hey_party_app'; base_url='http://127.0.0.1:3072'
    while [ "$#" -gt 0 ]; do
      case "$1" in
        --out) shift; out=${1:?missing --out value} ;;
        --name) shift; name=${1:?missing --name value} ;;
        --base-url) shift; base_url=${1:?missing --base-url value} ;;
        --help|-h) usage; exit 0 ;;
        *) echo "unknown party init option: $1" >&2; usage >&2; exit 2 ;;
      esac
      shift
    done
    [ -n "$out" ] || { echo '--out is required' >&2; exit 2; }
    [ ! -e "$out" ] || { echo "refusing to overwrite: $out" >&2; exit 73; }
    mkdir -p "$out/src" "$out/specs" "$out/server" "$out/public/tv" "$out/public/phone" "$out/bin" "$out/data"

    cat > "$out/hey-package.json" <<EOF_MANIFEST
{
  "manifest_version": 1,
  "name": "$name",
  "version": "0.1.0",
  "registry": "https://www.jayteesf.com/packages/registry-v1.json",
  "dependencies": {
    "hey_party": "^0.1.0",
    "hey_tv": "^0.1.0",
    "hey_web": "^0.1.6",
    "hey_mobile": "^0.1.3"
  },
  "modules": {"room_protocol": "src/RoomProtocol.hey", "room_transport": "src/RoomTransport.hey", "lobby": "src/Lobby.hey", "game_kernel": "src/GameKernel.hey", "dictionary_bluff": "src/DictionaryBluff.hey", "categories_clash": "src/CategoriesClash.hey", "ghost": "src/Ghost.hey", "card_kernel": "src/CardKernel.hey", "spades": "src/Spades.hey", "bid_whist": "src/BidWhist.hey"}
}
EOF_MANIFEST

    cat > "$out/src/RoomProtocol.hey" <<'EOF_ROOM'
import 'stdlib:Collections'
import 'stdlib:Crypto'

module RoomProtocol
  fn signature(code, nonce, secret)
    return Crypto.sha256_text(code + ':' + nonce + ':' + secret)
  end

  fn join_url(base_url, code, nonce, secret)
    let signature = RoomProtocol.signature(code, nonce, secret)
    return base_url + '/join/' + code + '?nonce=' + nonce + '&sig=' + signature
  end

  fn new(code, base_url, secret)
    let nonce = 'room-1'
    return {
      code: code,
      phase: 'lobby',
      sequence: 0,
      next_player_id: 1,
      players: [],
      join_url: RoomProtocol.join_url(base_url, code, nonce, secret)
    }
  end

  fn public_player(player)
    return {id: player.id, nickname: player.nickname, connected: player.connected}
  end

  fn public_view(state)
    return {
      code: state.code,
      phase: state.phase,
      sequence: state.sequence,
      join_url: state.join_url,
      players: Collections.map(state.players, RoomProtocol.public_player)
    }
  end

  fn player_by_id(players, player_id)
    for player in players
      if player.id == player_id
        return player
      end
    end
    return nil
  end

  fn player_view(state, player_id)
    return {
      public: RoomProtocol.public_view(state),
      self: RoomProtocol.player_by_id(state.players, player_id)
    }
  end

  fn apply(state, action, secret)
    if action.sequence <= state.sequence
      return {accepted: false, reason: 'duplicate_or_stale', state: state, events: []}
    end
    if action.kind == 'join'
      let player_id = 'p' + state.next_player_id
      let reconnect_token = Crypto.sha256_text(state.code + ':' + player_id + ':' + action.nonce + ':' + secret)
      let player = {
        id: player_id,
        nickname: action.nickname,
        connected: true,
        reconnect_token: reconnect_token
      }
      let next = {
        ...state,
        sequence: action.sequence,
        next_player_id: state.next_player_id + 1,
        players: [...state.players, player]
      }
      return {accepted: true, state: next, events: [{kind: 'player_joined', player_id: player_id}]}
    end
    if action.kind == 'start'
      return {accepted: true, state: {...state, phase: 'playing', sequence: action.sequence}, events: [{kind: 'game_started'}]}
    end
    return {accepted: false, reason: 'unknown_action', state: state, events: []}
  end
end
EOF_ROOM

    cat > "$out/src/RoomTransport.hey" <<'EOF_TRANSPORT'
import 'stdlib:Crypto'

module RoomTransport
  fn new(code, now_ms, ttl_ms, capacity)
    return {
      code: code,
      expires_at_ms: now_ms + ttl_ms,
      capacity: capacity,
      pending: 0,
      last_sequences: {},
      last_seen_ms: {},
      connected: {}
    }
  end

  fn reconnect_token(code, client_id, secret)
    return Crypto.sha256_text(code + ':' + client_id + ':' + secret)
  end

  fn envelope(client_id, sequence, kind, payload, sent_at_ms)
    return {client_id: client_id, sequence: sequence, kind: kind, payload: payload, sent_at_ms: sent_at_ms}
  end

  fn reject(state, reason)
    return {accepted: false, reason: reason, state: state, events: []}
  end

  fn apply(state, envelope, now_ms, secret)
    if now_ms >= state.expires_at_ms
      return RoomTransport.reject(state, 'room_expired')
    end
    let previous = state.last_sequences[envelope.client_id]
    if previous != nil and envelope.sequence <= previous
      return RoomTransport.reject(state, 'duplicate_or_stale')
    end
    if envelope.kind == 'enqueue' and state.pending >= state.capacity
      return RoomTransport.reject(state, 'backpressure')
    end
    if envelope.kind == 'reconnect'
      let expected = RoomTransport.reconnect_token(state.code, envelope.client_id, secret)
      if envelope.payload.token != expected
        return RoomTransport.reject(state, 'invalid_reconnect_token')
      end
    end
    let pending = state.pending
    if envelope.kind == 'enqueue'
      set pending = pending + 1
    end
    if envelope.kind == 'ack' and pending > 0
      set pending = pending - 1
    end
    let next = {
      ...state,
      pending: pending,
      last_sequences: put(state.last_sequences, envelope.client_id, envelope.sequence),
      last_seen_ms: put(state.last_seen_ms, envelope.client_id, now_ms),
      connected: put(state.connected, envelope.client_id, true)
    }
    return {accepted: true, state: next, events: [{kind: envelope.kind, client_id: envelope.client_id}]}
  end

  fn disconnected_clients(state, now_ms, timeout_ms)
    let result = []
    for client_id in keys(state.last_seen_ms)
      if now_ms - state.last_seen_ms[client_id] > timeout_ms
        set result = push(result, client_id)
      end
    end
    return result
  end
end
EOF_TRANSPORT

    cat > "$out/src/Lobby.hey" <<'EOF_LOBBY'
module Lobby
  fn new(code, join_url, now_ms, ttl_ms, allow_late_join)
    return {
      code: code,
      join_url: join_url,
      qr: {kind: 'qr_payload', text: join_url, encoding: 'utf-8', error_correction: 'M'},
      phase: 'lobby',
      round: 1,
      sequence: 0,
      next_client_id: 1,
      host_id: nil,
      players: [],
      spectators: [],
      allow_late_join: allow_late_join,
      expires_at_ms: now_ms + ttl_ms
    }
  end

  fn public_member(member)
    return {id: member.id, nickname: member.nickname, connected: member.connected}
  end

  fn public_members(members)
    let result = []
    for member in members
      set result = push(result, Lobby.public_member(member))
    end
    return result
  end

  fn remove_member(members, member_id)
    let result = []
    for member in members
      if member.id != member_id
        set result = push(result, member)
      end
    end
    return result
  end

  fn public_view(state)
    return {
      code: state.code,
      join_url: state.join_url,
      qr: state.qr,
      phase: state.phase,
      round: state.round,
      host_id: state.host_id,
      players: Lobby.public_members(state.players),
      spectator_count: len(state.spectators),
      expires_at_ms: state.expires_at_ms
    }
  end

  fn reject(state, reason)
    return {accepted: false, reason: reason, state: state, events: []}
  end

  fn apply(state, action, now_ms)
    if now_ms >= state.expires_at_ms
      return Lobby.reject({...state, phase: 'expired'}, 'room_expired')
    end
    if action.sequence <= state.sequence
      return Lobby.reject(state, 'duplicate_or_stale')
    end
    if action.kind == 'join'
      if state.phase != 'lobby' and !state.allow_late_join
        return Lobby.reject(state, 'late_join_closed')
      end
      let id = 'c' + state.next_client_id
      let member = {id: id, nickname: action.nickname, connected: true}
      if action.role == 'spectator'
        let next = {...state, sequence: action.sequence, next_client_id: state.next_client_id + 1, spectators: [...state.spectators, member]}
        return {accepted: true, state: next, events: [{kind: 'spectator_joined', client_id: id}]}
      end
      let host_id = state.host_id
      if host_id == nil
        set host_id = id
      end
      let next = {...state, sequence: action.sequence, next_client_id: state.next_client_id + 1, host_id: host_id, players: [...state.players, member]}
      return {accepted: true, state: next, events: [{kind: 'player_joined', client_id: id}]}
    end
    if action.kind == 'start'
      if action.client_id != state.host_id
        return Lobby.reject(state, 'host_required')
      end
      if len(state.players) < 2
        return Lobby.reject(state, 'not_enough_players')
      end
      return {accepted: true, state: {...state, sequence: action.sequence, phase: 'playing'}, events: [{kind: 'game_started'}]}
    end
    if action.kind == 'kick'
      if action.client_id != state.host_id
        return Lobby.reject(state, 'host_required')
      end
      if action.target_id == state.host_id
        return Lobby.reject(state, 'cannot_kick_host')
      end
      let next = {...state, sequence: action.sequence, players: Lobby.remove_member(state.players, action.target_id), spectators: Lobby.remove_member(state.spectators, action.target_id)}
      return {accepted: true, state: next, events: [{kind: 'client_kicked', client_id: action.target_id}]}
    end
    if action.kind == 'finish'
      return {accepted: true, state: {...state, sequence: action.sequence, phase: 'results'}, events: [{kind: 'game_finished'}]}
    end
    if action.kind == 'rematch'
      if action.client_id != state.host_id
        return Lobby.reject(state, 'host_required')
      end
      if state.phase != 'results'
        return Lobby.reject(state, 'results_required')
      end
      return {accepted: true, state: {...state, sequence: action.sequence, phase: 'lobby', round: state.round + 1}, events: [{kind: 'rematch_opened', round: state.round + 1}]}
    end
    return Lobby.reject(state, 'unknown_action')
  end
end
EOF_LOBBY

    cat > "$out/src/GameKernel.hey" <<'EOF_GAME_KERNEL'
import 'stdlib:Collections'

module GameKernel
  fn guard_sequence(state, action)
    if action.sequence <= state.sequence
      return {accepted: false, reason: 'duplicate_or_stale', state: state, events: []}
    end
    return {accepted: true, state: {...state, sequence: action.sequence}, events: []}
  end

  fn seeded_index(seed, round_index, count)
    if count <= 0
      return 0
    end
    return ((seed * 1103515245) + (round_index * 12345) + 67890) % count
  end

  fn insert_at(items, index, value)
    let out = []
    let cursor = 0
    let inserted = false
    for item in items
      if !inserted and cursor == index
        set out = [...out, value]
        set inserted = true
      end
      set out = [...out, item]
      set cursor = cursor + 1
    end
    if !inserted
      set out = [...out, value]
    end
    return out
  end

  fn replay(initial, actions, reducer)
    let state = initial
    let events = []
    for action in actions
      let result = reducer(state, action)
      if result.accepted
        set state = result.state
        set events = [...events, ...result.events]
      end
    end
    return {state: state, events: events}
  end
end
EOF_GAME_KERNEL

    cat > "$out/src/DictionaryBluff.hey" <<'EOF_DICTIONARY_BLUFF'
import 'stdlib:Collections'
import 'GameKernel.hey'

module DictionaryBluff
  fn prompts()
    return [
      {word: 'agelast', definition: 'a person who never laughs'},
      {word: 'brontide', definition: 'a low rumbling sound like distant thunder'},
      {word: 'quomodocunquize', definition: 'to make money by any possible means'}
    ]
  end

  fn initial_scores(players)
    let scores = {}
    for player in players
      set scores = put(scores, player.id, 0)
    end
    return scores
  end

  fn new(players, seed)
    let prompts = DictionaryBluff.prompts()
    let prompt_index = GameKernel.seeded_index(seed, 0, len(prompts))
    return {
      game: 'dictionary_bluff',
      phase: 'submitting',
      sequence: 0,
      round: 1,
      seed: seed,
      players: players,
      prompt: prompts[prompt_index],
      submissions: [],
      choices: [],
      votes: [],
      scores: DictionaryBluff.initial_scores(players)
    }
  end

  fn submission_for(submissions, player_id)
    for submission in submissions
      if submission.player_id == player_id
        return submission
      end
    end
    return nil
  end

  fn vote_for(votes, player_id)
    for vote in votes
      if vote.player_id == player_id
        return vote
      end
    end
    return nil
  end

  fn choice_for(choices, choice_id)
    for choice in choices
      if choice.id == choice_id
        return choice
      end
    end
    return nil
  end

  fn anonymous_choice(choice)
    return {id: choice.id, text: choice.text}
  end

  fn scored_choice(choice)
    return {
      id: choice.id,
      text: choice.text,
      author_id: choice.author_id,
      correct: choice.id == 'truth'
    }
  end

  fn make_choices(state)
    let fakes = []
    for submission in state.submissions
      set fakes = [...fakes, {id: 'fake-' + submission.player_id, text: submission.text, author_id: submission.player_id}]
    end
    let truth = {id: 'truth', text: state.prompt.definition, author_id: 'dictionary'}
    let truth_index = GameKernel.seeded_index(state.seed, state.round, len(fakes) + 1)
    return GameKernel.insert_at(fakes, truth_index, truth)
  end

  fn score(state, votes)
    let scores = state.scores
    for vote in votes
      let choice = DictionaryBluff.choice_for(state.choices, vote.choice_id)
      if choice != nil
        if choice.id == 'truth'
          let current = scores[vote.player_id]
          if current == nil
            set current = 0
          end
          set scores = put(scores, vote.player_id, current + 2)
        else
          if choice.author_id != vote.player_id
            let fooled = scores[choice.author_id]
            if fooled == nil
              set fooled = 0
            end
            set scores = put(scores, choice.author_id, fooled + 1)
          end
        end
      end
    end
    return scores
  end

  fn public_view(state)
    let base = {
      game: state.game,
      phase: state.phase,
      sequence: state.sequence,
      round: state.round,
      word: state.prompt.word,
      players: state.players,
      scores: state.scores
    }
    if state.phase == 'submitting'
      return {...base, submitted_count: len(state.submissions)}
    end
    if state.phase == 'voting'
      return {...base, choices: Collections.map(state.choices, DictionaryBluff.anonymous_choice), vote_count: len(state.votes)}
    end
    return {
      ...base,
      definition: state.prompt.definition,
      choices: Collections.map(state.choices, DictionaryBluff.scored_choice),
      votes: state.votes
    }
  end

  fn player_view(state, player_id)
    return {
      public: DictionaryBluff.public_view(state),
      self: {
        player_id: player_id,
        submission: DictionaryBluff.submission_for(state.submissions, player_id),
        vote: DictionaryBluff.vote_for(state.votes, player_id)
      }
    }
  end

  fn apply(state, action)
    let guarded = GameKernel.guard_sequence(state, action)
    if !guarded.accepted
      return guarded
    end
    let current = guarded.state

    if action.kind == 'submit' and current.phase == 'submitting'
      if DictionaryBluff.submission_for(current.submissions, action.player_id) != nil
        return {accepted: false, reason: 'already_submitted', state: state, events: []}
      end
      let submissions = [...current.submissions, {player_id: action.player_id, text: action.text}]
      let next = {...current, submissions: submissions}
      let events = [{kind: 'definition_submitted', player_id: action.player_id}]
      if len(submissions) == len(current.players)
        set next = {...next, phase: 'voting', choices: DictionaryBluff.make_choices(next)}
        set events = [...events, {kind: 'voting_started'}]
      end
      return {accepted: true, state: next, events: events}
    end

    if action.kind == 'vote' and current.phase == 'voting'
      if DictionaryBluff.vote_for(current.votes, action.player_id) != nil
        return {accepted: false, reason: 'already_voted', state: state, events: []}
      end
      let choice = DictionaryBluff.choice_for(current.choices, action.choice_id)
      if choice == nil or choice.author_id == action.player_id
        return {accepted: false, reason: 'invalid_choice', state: state, events: []}
      end
      let votes = [...current.votes, {player_id: action.player_id, choice_id: action.choice_id}]
      let next = {...current, votes: votes}
      let events = [{kind: 'vote_cast', player_id: action.player_id}]
      if len(votes) == len(current.players)
        set next = {...next, phase: 'scored', scores: DictionaryBluff.score(next, votes)}
        set events = [...events, {kind: 'round_scored'}]
      end
      return {accepted: true, state: next, events: events}
    end

    return {accepted: false, reason: 'action_not_allowed', state: state, events: []}
  end
end
EOF_DICTIONARY_BLUFF

    cat > "$out/src/CategoriesClash.hey" <<'EOF_CATEGORIES'
import 'stdlib:Text'

module CategoriesClash
  fn new(players, categories, letter, host_id)
    let scores = {}
    for player in players
      set scores = put(scores, player.id, 0)
    end
    return {
      game: 'categories_clash',
      phase: 'submitting',
      sequence: 0,
      round: 1,
      players: players,
      categories: categories,
      letter: Text.lower(letter),
      host_id: host_id,
      submissions: [],
      invalid_answers: {},
      scores: scores
    }
  end

  fn normalize(answer)
    return Text.lower(Text.trim(answer))
  end

  fn player_submitted?(submissions, player_id)
    for submission in submissions
      if submission.player_id == player_id
        return true
      end
    end
    return false
  end

  fn answer_entries(player_id, answers)
    let result = []
    for answer in answers
      let normalized = CategoriesClash.normalize(answer.answer)
      set result = push(result, {
        id: player_id + ':' + answer.category,
        player_id: player_id,
        category: answer.category,
        answer: answer.answer,
        normalized: normalized
      })
    end
    return result
  end

  fn flattened(submissions)
    let result = []
    for submission in submissions
      for answer in submission.answers
        set result = push(result, answer)
      end
    end
    return result
  end

  fn occurrence_count(entries, category, normalized)
    let count = 0
    for entry in entries
      if entry.category == category and entry.normalized == normalized
        set count = count + 1
      end
    end
    return count
  end

  fn score(state)
    let entries = CategoriesClash.flattened(state.submissions)
    let scores = state.scores
    for entry in entries
      let current = scores[entry.player_id]
      if current == nil
        set current = 0
      end
      let invalid = state.invalid_answers[entry.id]
      let starts = Text.starts_with?(entry.normalized, state.letter)
      let unique = CategoriesClash.occurrence_count(entries, entry.category, entry.normalized) == 1
      if entry.normalized != '' and invalid != true and starts and unique
        set scores = put(scores, entry.player_id, current + 1)
      end
    end
    return scores
  end

  fn public_view(state)
    let base = {game: state.game, phase: state.phase, round: state.round, categories: state.categories, letter: state.letter, players: state.players, scores: state.scores}
    if state.phase == 'submitting'
      return {...base, submitted_count: len(state.submissions)}
    end
    return {...base, submissions: state.submissions, invalid_answers: state.invalid_answers}
  end

  fn player_view(state, player_id)
    let own = nil
    for submission in state.submissions
      if submission.player_id == player_id
        set own = submission
      end
    end
    return {public: CategoriesClash.public_view(state), self_submission: own}
  end

  fn reject(state, reason)
    return {accepted: false, reason: reason, state: state, events: []}
  end

  fn apply(state, action)
    if action.sequence <= state.sequence
      return CategoriesClash.reject(state, 'duplicate_or_stale')
    end
    if action.kind == 'submit'
      if state.phase != 'submitting'
        return CategoriesClash.reject(state, 'submissions_closed')
      end
      if CategoriesClash.player_submitted?(state.submissions, action.player_id)
        return CategoriesClash.reject(state, 'already_submitted')
      end
      let entries = CategoriesClash.answer_entries(action.player_id, action.answers)
      let submissions = [...state.submissions, {player_id: action.player_id, answers: entries}]
      let phase = state.phase
      if len(submissions) == len(state.players)
        set phase = 'review'
      end
      return {accepted: true, state: {...state, sequence: action.sequence, submissions: submissions, phase: phase}, events: [{kind: 'answers_submitted', player_id: action.player_id}]}
    end
    if action.kind == 'moderate'
      if action.player_id != state.host_id
        return CategoriesClash.reject(state, 'host_required')
      end
      if state.phase != 'review'
        return CategoriesClash.reject(state, 'review_required')
      end
      return {accepted: true, state: {...state, sequence: action.sequence, invalid_answers: put(state.invalid_answers, action.answer_id, !action.valid)}, events: [{kind: 'answer_moderated', answer_id: action.answer_id}]}
    end
    if action.kind == 'reveal'
      if action.player_id != state.host_id
        return CategoriesClash.reject(state, 'host_required')
      end
      if state.phase != 'review'
        return CategoriesClash.reject(state, 'review_required')
      end
      let scored = {...state, sequence: action.sequence, phase: 'results'}
      return {accepted: true, state: {...scored, scores: CategoriesClash.score(scored)}, events: [{kind: 'round_scored'}]}
    end
    return CategoriesClash.reject(state, 'unknown_action')
  end
end
EOF_CATEGORIES

    cat > "$out/data/ghost_words.txt" <<'EOF_GHOST_WORDS'
game
garden
gather
ghost
giant
gift
globe
grace
grain
grape
green
group
house
human
music
party
phone
prayer
spade
stone
television
word
EOF_GHOST_WORDS
    if command -v shasum >/dev/null 2>&1; then
      shasum -a 256 "$out/data/ghost_words.txt" | awk '{print $1}' > "$out/data/ghost_words.sha256"
    else
      sha256sum "$out/data/ghost_words.txt" | awk '{print $1}' > "$out/data/ghost_words.sha256"
    fi

    cat > "$out/src/Ghost.hey" <<'EOF_GHOST'
import 'stdlib:Text'

module Ghost
  fn new(players, dictionary_id, min_length)
    let penalties = {}
    let active_player_ids = []
    for player in players
      set penalties = put(penalties, player.id, 0)
      set active_player_ids = push(active_player_ids, player.id)
    end
    return {
      game: 'ghost',
      phase: 'playing',
      sequence: 0,
      round: 1,
      players: players,
      active_player_ids: active_player_ids,
      current_index: 0,
      last_player_id: nil,
      challenger_id: nil,
      challenged_id: nil,
      fragment: '',
      penalties: penalties,
      dictionary_id: dictionary_id,
      min_length: min_length,
      winner_id: nil
    }
  end

  fn penalty_label(count)
    if count <= 0
      return ''
    end
    if count >= 5
      return 'GHOST'
    end
    return Text.slice('GHOST', 0, count)
  end

  fn current_player_id(state)
    if len(state.active_player_ids) == 0
      return nil
    end
    return state.active_player_ids[state.current_index]
  end

  fn contains_word(words, candidate)
    let normalized = Text.lower(Text.trim(candidate))
    for word in words
      if Text.lower(Text.trim(word)) == normalized
        return true
      end
    end
    return false
  end

  fn has_prefix(words, fragment)
    let normalized = Text.lower(Text.trim(fragment))
    for word in words
      if Text.starts_with?(Text.lower(Text.trim(word)), normalized)
        return true
      end
    end
    return false
  end

  fn remove_player(player_ids, player_id)
    let remaining = []
    for candidate in player_ids
      if candidate != player_id
        set remaining = push(remaining, candidate)
      end
    end
    return remaining
  end

  fn next_index(state)
    let next = state.current_index + 1
    if next >= len(state.active_player_ids)
      return 0
    end
    return next
  end

  fn public_penalties(state)
    let values = []
    for player in state.players
      let count = state.penalties[player.id]
      set values = push(values, {player_id: player.id, count: count, label: Ghost.penalty_label(count), eliminated: count >= 5})
    end
    return values
  end

  fn public_view(state)
    return {
      game: state.game,
      phase: state.phase,
      round: state.round,
      fragment: state.fragment,
      current_player_id: Ghost.current_player_id(state),
      last_player_id: state.last_player_id,
      challenger_id: state.challenger_id,
      challenged_id: state.challenged_id,
      penalties: Ghost.public_penalties(state),
      dictionary_id: state.dictionary_id,
      min_length: state.min_length,
      winner_id: state.winner_id
    }
  end

  fn player_view(state, player_id)
    return {public: Ghost.public_view(state), self: {player_id: player_id, penalty: state.penalties[player_id]}}
  end

  fn reject(state, reason)
    return {accepted: false, reason: reason, state: state, events: []}
  end

  fn penalize(state, player_id, reason)
    let next_count = state.penalties[player_id] + 1
    let penalties = put(state.penalties, player_id, next_count)
    let active = state.active_player_ids
    let events = [{kind: 'ghost_letter_awarded', player_id: player_id, letter: Ghost.penalty_label(next_count), reason: reason}]
    if next_count >= 5
      set active = Ghost.remove_player(active, player_id)
      set events = [...events, {kind: 'player_eliminated', player_id: player_id}]
    end
    if len(active) <= 1
      let winner = nil
      if len(active) == 1
        set winner = active[0]
      end
      return {accepted: true, state: {...state, phase: 'results', penalties: penalties, active_player_ids: active, current_index: 0, fragment: '', last_player_id: nil, challenger_id: nil, challenged_id: nil, winner_id: winner}, events: [...events, {kind: 'match_finished', winner_id: winner}]}
    end
    return {accepted: true, state: {...state, phase: 'playing', penalties: penalties, active_player_ids: active, current_index: 0, fragment: '', last_player_id: nil, challenger_id: nil, challenged_id: nil, round: state.round + 1}, events: events}
  end

  fn apply(state, action, words)
    if action.sequence <= state.sequence
      return Ghost.reject(state, 'duplicate_or_stale')
    end
    if state.phase == 'results'
      return Ghost.reject(state, 'match_finished')
    end
    let current = {...state, sequence: action.sequence}

    if action.kind == 'add_letter'
      if current.phase != 'playing'
        return Ghost.reject(state, 'proof_required')
      end
      if action.player_id != Ghost.current_player_id(current)
        return Ghost.reject(state, 'not_your_turn')
      end
      let letter = Text.lower(Text.trim(action.letter))
      if len(letter) != 1
        return Ghost.reject(state, 'one_letter_required')
      end
      let fragment = current.fragment + letter
      if len(fragment) >= current.min_length and Ghost.contains_word(words, fragment)
        return Ghost.penalize({...current, fragment: fragment}, action.player_id, 'completed_word')
      end
      return {accepted: true, state: {...current, fragment: fragment, last_player_id: action.player_id, current_index: Ghost.next_index(current)}, events: [{kind: 'letter_added', player_id: action.player_id, letter: letter, fragment: fragment}]}
    end

    if action.kind == 'challenge'
      if current.phase != 'playing'
        return Ghost.reject(state, 'challenge_not_allowed')
      end
      if action.player_id != Ghost.current_player_id(current)
        return Ghost.reject(state, 'not_your_turn')
      end
      if current.last_player_id == nil or current.fragment == ''
        return Ghost.reject(state, 'nothing_to_challenge')
      end
      return {accepted: true, state: {...current, phase: 'proof', challenger_id: action.player_id, challenged_id: current.last_player_id}, events: [{kind: 'challenge_opened', challenger_id: action.player_id, challenged_id: current.last_player_id}]}
    end

    if action.kind == 'prove'
      if current.phase != 'proof'
        return Ghost.reject(state, 'no_open_challenge')
      end
      if action.player_id != current.challenged_id
        return Ghost.reject(state, 'challenged_player_required')
      end
      let proposed = Text.lower(Text.trim(action.word))
      let valid = len(proposed) >= current.min_length and Text.starts_with?(proposed, current.fragment) and Ghost.contains_word(words, proposed)
      if valid
        return Ghost.penalize(current, current.challenger_id, 'valid_completion_proved')
      end
      return Ghost.penalize(current, current.challenged_id, 'invalid_completion')
    end

    return Ghost.reject(state, 'unknown_action')
  end
end
EOF_GHOST

    cat > "$out/src/CardKernel.hey" <<'EOF_CARD_KERNEL'
import 'stdlib:Collections'

module CardKernel
  fn deck()
    let cards = []
    for suit in ['clubs', 'diamonds', 'hearts', 'spades']
      let rank = 2
      while rank <= 14
        set cards = [...cards, {id: suit + '-' + rank, suit: suit, rank: rank}]
        set rank = rank + 1
      end
    end
    return cards
  end

  fn remove_at(items, index)
    let out = []
    let cursor = 0
    for item in items
      if cursor != index
        set out = [...out, item]
      end
      set cursor = cursor + 1
    end
    return out
  end

  fn deck_with_jokers()
    return [
      ...CardKernel.deck(),
      {id: 'little-joker', suit: 'joker', rank: 15},
      {id: 'big-joker', suit: 'joker', rank: 16}
    ]
  end

  fn shuffle_cards(cards, seed)
    let remaining = cards
    let out = []
    let state = seed
    while len(remaining) > 0
      set state = (state * 1103515245 + 12345) % 2147483647
      let index = state % len(remaining)
      set out = [...out, remaining[index]]
      set remaining = CardKernel.remove_at(remaining, index)
    end
    return out
  end

  fn shuffled(seed)
    return CardKernel.shuffle_cards(CardKernel.deck(), seed)
  end

  fn deal(players, seed)
    let hands = {}
    for player in players
      set hands = put(hands, player.id, [])
    end
    let index = 0
    for card in CardKernel.shuffled(seed)
      let player = players[index % len(players)]
      set hands = put(hands, player.id, [...hands[player.id], card])
      set index = index + 1
    end
    return hands
  end

  fn has_suit(hand, suit)
    for card in hand
      if card.suit == suit
        return true
      end
    end
    return false
  end

  fn non_spades(hand)
    let out = []
    for card in hand
      if card.suit != 'spades'
        set out = [...out, card]
      end
    end
    return out
  end

  fn legal_cards(hand, lead_suit, spades_broken)
    if lead_suit != nil and CardKernel.has_suit(hand, lead_suit)
      let matching = []
      for card in hand
        if card.suit == lead_suit
          set matching = [...matching, card]
        end
      end
      return matching
    end
    if lead_suit == nil and !spades_broken
      let plain = CardKernel.non_spades(hand)
      if len(plain) > 0
        return plain
      end
    end
    return hand
  end

  fn includes_card(cards, card_id)
    for card in cards
      if card.id == card_id
        return true
      end
    end
    return false
  end

  fn card_by_id(cards, card_id)
    for card in cards
      if card.id == card_id
        return card
      end
    end
    return nil
  end

  fn remove_card(cards, card_id)
    let out = []
    for card in cards
      if card.id != card_id
        set out = [...out, card]
      end
    end
    return out
  end

  fn beats?(candidate, winner, lead_suit)
    if candidate.card.suit == winner.card.suit
      return candidate.card.rank > winner.card.rank
    end
    if candidate.card.suit == 'spades'
      return true
    end
    if winner.card.suit == 'spades'
      return false
    end
    return candidate.card.suit == lead_suit
  end

  fn trick_winner(plays, lead_suit)
    let winner = plays[0]
    for play in Collections.drop(plays, 1)
      if CardKernel.beats?(play, winner, lead_suit)
        set winner = play
      end
    end
    return winner.player_id
  end
end
EOF_CARD_KERNEL

    cat > "$out/src/Spades.hey" <<'EOF_SPADES'
import 'stdlib:Collections'
import 'GameKernel.hey'
import 'CardKernel.hey'

module Spades
  fn team_for(player_id)
    if player_id == 'p1' or player_id == 'p3'
      return 'north_south'
    end
    return 'east_west'
  end

  fn empty_counts(players)
    let counts = {}
    for player in players
      set counts = put(counts, player.id, 0)
    end
    return counts
  end

  fn new(players, seed)
    return {
      game: 'spades',
      phase: 'bidding',
      sequence: 0,
      seed: seed,
      players: players,
      dealer_index: 3,
      current_player: players[0].id,
      hands: CardKernel.deal(players, seed),
      bids: {},
      tricks: Spades.empty_counts(players),
      trick: [],
      lead_suit: nil,
      spades_broken: false,
      team_scores: {
        north_south: {score: 0, bags: 0},
        east_west: {score: 0, bags: 0}
      }
    }
  end

  fn player_index(players, player_id)
    let index = 0
    for player in players
      if player.id == player_id
        return index
      end
      set index = index + 1
    end
    return -1
  end

  fn next_player(players, player_id)
    let index = Spades.player_index(players, player_id)
    return players[(index + 1) % len(players)].id
  end

  fn public_player(state, player)
    return {
      id: player.id,
      nickname: player.nickname,
      hand_count: len(state.hands[player.id]),
      bid: state.bids[player.id],
      tricks: state.tricks[player.id]
    }
  end

  fn public_players(state)
    let out = []
    for player in state.players
      set out = [...out, Spades.public_player(state, player)]
    end
    return out
  end

  fn public_view(state)
    return {
      game: state.game,
      phase: state.phase,
      sequence: state.sequence,
      players: Spades.public_players(state),
      current_player: state.current_player,
      trick: state.trick,
      lead_suit: state.lead_suit,
      spades_broken: state.spades_broken,
      team_scores: state.team_scores
    }
  end

  fn player_view(state, player_id)
    return {
      public: Spades.public_view(state),
      self: {
        player_id: player_id,
        hand: state.hands[player_id],
        legal_cards: CardKernel.legal_cards(state.hands[player_id], state.lead_suit, state.spades_broken)
      }
    }
  end

  fn team_bid(state, team)
    let total = 0
    for player in state.players
      if Spades.team_for(player.id) == team
        let bid = state.bids[player.id]
        if bid != nil
          set total = total + bid
        end
      end
    end
    return total
  end

  fn team_tricks(state, team)
    let total = 0
    for player in state.players
      if Spades.team_for(player.id) == team
        set total = total + state.tricks[player.id]
      end
    end
    return total
  end

  fn nil_adjustment(state, team)
    let score = 0
    for player in state.players
      if Spades.team_for(player.id) == team and state.bids[player.id] == 0
        if state.tricks[player.id] == 0
          set score = score + 100
        else
          set score = score - 100
        end
      end
    end
    return score
  end

  fn score_team(state, team)
    let previous = state.team_scores[team]
    let bid = Spades.team_bid(state, team)
    let tricks = Spades.team_tricks(state, team)
    let score = previous.score + Spades.nil_adjustment(state, team)
    let bags = previous.bags
    if tricks >= bid
      let over = tricks - bid
      set score = score + (bid * 10) + over
      set bags = bags + over
    else
      set score = score - (bid * 10)
    end
    if bags >= 10
      set score = score - 100
      set bags = bags - 10
    end
    return {score: score, bags: bags}
  end

  fn score_hand(state)
    return {
      north_south: Spades.score_team(state, 'north_south'),
      east_west: Spades.score_team(state, 'east_west')
    }
  end

  fn all_hands_empty?(state)
    for player in state.players
      if len(state.hands[player.id]) > 0
        return false
      end
    end
    return true
  end

  fn apply(state, action)
    let guarded = GameKernel.guard_sequence(state, action)
    if !guarded.accepted
      return guarded
    end
    let current = guarded.state

    if action.kind == 'bid' and current.phase == 'bidding'
      if current.bids[action.player_id] != nil or action.bid < 0 or action.bid > 13
        return {accepted: false, reason: 'invalid_bid', state: state, events: []}
      end
      let bids = put(current.bids, action.player_id, action.bid)
      let next = {...current, bids: bids}
      let events = [{kind: 'bid_placed', player_id: action.player_id, bid: action.bid}]
      if len(keys(bids)) == len(current.players)
        set next = {...next, phase: 'playing', current_player: current.players[0].id}
        set events = [...events, {kind: 'play_started'}]
      end
      return {accepted: true, state: next, events: events}
    end

    if action.kind == 'play' and current.phase == 'playing'
      if action.player_id != current.current_player
        return {accepted: false, reason: 'not_your_turn', state: state, events: []}
      end
      let hand = current.hands[action.player_id]
      let legal = CardKernel.legal_cards(hand, current.lead_suit, current.spades_broken)
      if !CardKernel.includes_card(legal, action.card_id)
        return {accepted: false, reason: 'illegal_card', state: state, events: []}
      end
      let card = CardKernel.card_by_id(hand, action.card_id)
      let hands = put(current.hands, action.player_id, CardKernel.remove_card(hand, action.card_id))
      let trick = [...current.trick, {player_id: action.player_id, card: card}]
      let lead_suit = current.lead_suit
      if lead_suit == nil
        set lead_suit = card.suit
      end
      let broken = current.spades_broken or card.suit == 'spades'
      let next = {
        ...current,
        hands: hands,
        trick: trick,
        lead_suit: lead_suit,
        spades_broken: broken,
        current_player: Spades.next_player(current.players, action.player_id)
      }
      let events = [{kind: 'card_played', player_id: action.player_id, card_id: action.card_id}]
      if len(trick) == len(current.players)
        let winner = CardKernel.trick_winner(trick, lead_suit)
        let tricks = put(current.tricks, winner, current.tricks[winner] + 1)
        set next = {...next, tricks: tricks, trick: [], lead_suit: nil, current_player: winner}
        set events = [...events, {kind: 'trick_won', player_id: winner}]
        if Spades.all_hands_empty?(next)
          set next = {...next, phase: 'scored', team_scores: Spades.score_hand(next)}
          set events = [...events, {kind: 'hand_scored'}]
        end
      end
      return {accepted: true, state: next, events: events}
    end

    return {accepted: false, reason: 'action_not_allowed', state: state, events: []}
  end
end
EOF_SPADES

    cat > "$out/src/BidWhist.hey" <<'EOF_BID_WHIST'
import 'stdlib:Collections'
import 'GameKernel.hey'
import 'CardKernel.hey'

module BidWhist
  fn team_for(player_id)
    if player_id == 'p1' or player_id == 'p3'
      return 'north_south'
    end
    return 'east_west'
  end

  fn deal(players, seed)
    let shuffled = CardKernel.shuffle_cards(CardKernel.deck_with_jokers(), seed)
    let hands = {}
    for player in players
      set hands = put(hands, player.id, [])
    end
    let index = 0
    while index < 48
      let player = players[index % 4]
      set hands = put(hands, player.id, [...hands[player.id], shuffled[index]])
      set index = index + 1
    end
    return {hands: hands, kitty: Collections.drop(shuffled, 48)}
  end

  fn empty_counts(players)
    let counts = {}
    for player in players
      set counts = put(counts, player.id, 0)
    end
    return counts
  end

  fn new(players, seed)
    let dealt = BidWhist.deal(players, seed)
    return {
      game: 'bid_whist',
      phase: 'auction',
      sequence: 0,
      players: players,
      current_player: players[0].id,
      auction_count: 0,
      highest_bid: nil,
      bids: [],
      declarer: nil,
      contract: nil,
      hands: dealt.hands,
      kitty: dealt.kitty,
      trick: [],
      lead_suit: nil,
      tricks: BidWhist.empty_counts(players),
      team_scores: {north_south: 0, east_west: 0}
    }
  end

  fn player_index(players, player_id)
    let index = 0
    for player in players
      if player.id == player_id
        return index
      end
      set index = index + 1
    end
    return -1
  end

  fn next_player(players, player_id)
    return players[(BidWhist.player_index(players, player_id) + 1) % len(players)].id
  end

  fn public_players(state)
    let out = []
    for player in state.players
      set out = [...out, {
        id: player.id,
        nickname: player.nickname,
        hand_count: len(state.hands[player.id]),
        tricks: state.tricks[player.id]
      }]
    end
    return out
  end

  fn public_view(state)
    return {
      game: state.game,
      phase: state.phase,
      sequence: state.sequence,
      players: BidWhist.public_players(state),
      current_player: state.current_player,
      highest_bid: state.highest_bid,
      declarer: state.declarer,
      contract: state.contract,
      trick: state.trick,
      lead_suit: state.lead_suit,
      team_scores: state.team_scores
    }
  end

  fn player_view(state, player_id)
    let private_kitty = []
    if state.phase == 'contract' and player_id == state.declarer
      set private_kitty = state.kitty
    end
    return {
      public: BidWhist.public_view(state),
      self: {player_id: player_id, hand: state.hands[player_id], kitty: private_kitty}
    }
  end

  fn effective_suit(card, contract)
    if card.suit == 'joker' and contract.trump != 'no_trump'
      return contract.trump
    end
    return card.suit
  end

  fn has_suit(hand, suit, contract)
    for card in hand
      if BidWhist.effective_suit(card, contract) == suit
        return true
      end
    end
    return false
  end

  fn legal_cards(hand, lead_suit, contract)
    if lead_suit == nil or !BidWhist.has_suit(hand, lead_suit, contract)
      return hand
    end
    let out = []
    for card in hand
      if BidWhist.effective_suit(card, contract) == lead_suit
        set out = [...out, card]
      end
    end
    return out
  end

  fn remove_cards(hand, discards)
    let out = hand
    for card_id in discards
      set out = CardKernel.remove_card(out, card_id)
    end
    return out
  end

  fn joker_weight(card)
    if card.id == 'big-joker'
      return 100
    end
    if card.id == 'little-joker'
      return 99
    end
    return 0
  end

  fn beats?(candidate, winner, lead_suit, contract)
    let candidate_suit = BidWhist.effective_suit(candidate.card, contract)
    let winner_suit = BidWhist.effective_suit(winner.card, contract)
    let trump = contract.trump
    let candidate_joker = BidWhist.joker_weight(candidate.card)
    let winner_joker = BidWhist.joker_weight(winner.card)
    if candidate_joker > 0 or winner_joker > 0
      return candidate_joker > winner_joker
    end
    if candidate_suit == winner_suit
      if contract.direction == 'downtown'
        return candidate.card.rank < winner.card.rank
      end
      return candidate.card.rank > winner.card.rank
    end
    if trump != 'no_trump' and candidate_suit == trump
      return true
    end
    if trump != 'no_trump' and winner_suit == trump
      return false
    end
    return candidate_suit == lead_suit
  end

  fn trick_winner(plays, lead_suit, contract)
    let winner = plays[0]
    for play in Collections.drop(plays, 1)
      if BidWhist.beats?(play, winner, lead_suit, contract)
        set winner = play
      end
    end
    return winner.player_id
  end

  fn team_tricks(state, team)
    let total = 0
    for player in state.players
      if BidWhist.team_for(player.id) == team
        set total = total + state.tricks[player.id]
      end
    end
    return total
  end

  fn score_hand(state)
    let bidder_team = BidWhist.team_for(state.declarer)
    let required = 6 + state.highest_bid.amount
    let won = BidWhist.team_tricks(state, bidder_team)
    let delta = state.highest_bid.amount
    if won < required
      set delta = 0 - delta
    end
    return put(state.team_scores, bidder_team, state.team_scores[bidder_team] + delta)
  end

  fn all_hands_empty?(state)
    for player in state.players
      if len(state.hands[player.id]) > 0
        return false
      end
    end
    return true
  end

  fn apply(state, action)
    let guarded = GameKernel.guard_sequence(state, action)
    if !guarded.accepted
      return guarded
    end
    let current = guarded.state

    if current.phase == 'auction' and (action.kind == 'bid' or action.kind == 'pass')
      if action.player_id != current.current_player
        return {accepted: false, reason: 'not_your_turn', state: state, events: []}
      end
      let highest = current.highest_bid
      if action.kind == 'bid'
        if action.amount < 3 or action.amount > 7 or (highest != nil and action.amount <= highest.amount)
          return {accepted: false, reason: 'invalid_bid', state: state, events: []}
        end
        set highest = {player_id: action.player_id, amount: action.amount}
      end
      let bids = [...current.bids, {player_id: action.player_id, kind: action.kind, amount: action.amount}]
      let count = current.auction_count + 1
      let next = {...current, highest_bid: highest, bids: bids, auction_count: count, current_player: BidWhist.next_player(current.players, action.player_id)}
      let events = [{kind: 'auction_action', player_id: action.player_id}]
      if count == len(current.players)
        if highest == nil
          return {accepted: false, reason: 'all_passed', state: state, events: []}
        end
        set next = {...next, phase: 'contract', declarer: highest.player_id, current_player: highest.player_id, hands: put(next.hands, highest.player_id, [...next.hands[highest.player_id], ...next.kitty])}
        set events = [...events, {kind: 'auction_won', player_id: highest.player_id}]
      end
      return {accepted: true, state: next, events: events}
    end

    if current.phase == 'contract' and action.kind == 'contract'
      if action.player_id != current.declarer or len(action.discards) != 6
        return {accepted: false, reason: 'invalid_contract', state: state, events: []}
      end
      if action.direction != 'uptown' and action.direction != 'downtown'
        return {accepted: false, reason: 'invalid_direction', state: state, events: []}
      end
      if action.trump != 'clubs' and action.trump != 'diamonds' and action.trump != 'hearts' and action.trump != 'spades' and action.trump != 'no_trump'
        return {accepted: false, reason: 'invalid_trump', state: state, events: []}
      end
      let hand = current.hands[current.declarer]
      for card_id in action.discards
        if !CardKernel.includes_card(hand, card_id)
          return {accepted: false, reason: 'invalid_discard', state: state, events: []}
        end
      end
      let contract = {direction: action.direction, trump: action.trump, amount: current.highest_bid.amount}
      let hands = put(current.hands, current.declarer, BidWhist.remove_cards(hand, action.discards))
      return {accepted: true, state: {...current, phase: 'playing', contract: contract, hands: hands, kitty: [], current_player: current.declarer}, events: [{kind: 'contract_declared'}]}
    end

    if current.phase == 'playing' and action.kind == 'play'
      if action.player_id != current.current_player
        return {accepted: false, reason: 'not_your_turn', state: state, events: []}
      end
      let hand = current.hands[action.player_id]
      let legal = BidWhist.legal_cards(hand, current.lead_suit, current.contract)
      if !CardKernel.includes_card(legal, action.card_id)
        return {accepted: false, reason: 'illegal_card', state: state, events: []}
      end
      let card = CardKernel.card_by_id(hand, action.card_id)
      let hands = put(current.hands, action.player_id, CardKernel.remove_card(hand, action.card_id))
      let trick = [...current.trick, {player_id: action.player_id, card: card}]
      let lead_suit = current.lead_suit
      if lead_suit == nil
        set lead_suit = BidWhist.effective_suit(card, current.contract)
      end
      let next = {...current, hands: hands, trick: trick, lead_suit: lead_suit, current_player: BidWhist.next_player(current.players, action.player_id)}
      let events = [{kind: 'card_played', player_id: action.player_id}]
      if len(trick) == 4
        let winner = BidWhist.trick_winner(trick, lead_suit, current.contract)
        let tricks = put(current.tricks, winner, current.tricks[winner] + 1)
        set next = {...next, tricks: tricks, trick: [], lead_suit: nil, current_player: winner}
        set events = [...events, {kind: 'trick_won', player_id: winner}]
        if BidWhist.all_hands_empty?(next)
          set next = {...next, phase: 'scored', team_scores: BidWhist.score_hand(next)}
          set events = [...events, {kind: 'hand_scored'}]
        end
      end
      return {accepted: true, state: next, events: events}
    end

    return {accepted: false, reason: 'action_not_allowed', state: state, events: []}
  end
end
EOF_BID_WHIST

    cat > "$out/specs/room_protocol_spec.hey" <<'EOF_SPEC'
spec 'party room keeps public and private views separate'
  expect stdout "true\ntrue\ntrue\ntrue\n"
end

import 'stdlib:Json'
import 'stdlib:Text'
import '../src/RoomProtocol.hey'
import '../src/DictionaryBluff.hey'
import '../src/CategoriesClash.hey'
import '../src/Ghost.hey'
import '../src/Spades.hey'
import '../src/BidWhist.hey'

program
  let initial = RoomProtocol.new('ABCD', 'https://party.example', 'secret')
  let joined = RoomProtocol.apply(initial, {kind: 'join', sequence: 1, nickname: 'Ada', nonce: 'n1'}, 'secret')
  let duplicate = RoomProtocol.apply(joined.state, {kind: 'join', sequence: 1, nickname: 'Grace', nonce: 'n2'}, 'secret')
  let public_json = Json.encode(RoomProtocol.public_view(joined.state))
  let private_json = Json.encode(RoomProtocol.player_view(joined.state, 'p1'))
  says joined.accepted
  says !duplicate.accepted
  says !Text.contains?(public_json, 'reconnect_token')
  says Text.contains?(private_json, 'reconnect_token')
end
EOF_SPEC

    cat > "$out/specs/room_transport_spec.hey" <<'EOF_TRANSPORT_SPEC'
spec 'room transport enforces ordering heartbeat reconnect expiration and backpressure'
  expect stdout "true\nduplicate_or_stale\nbackpressure\ntrue\nroom_expired\n2\n"
end

import '../src/RoomTransport.hey'
import '../src/Lobby.hey'

program
  let secret = 'test-secret'
  let state = RoomTransport.new('ABCD', 1000, 10000, 1)
  let heartbeat = RoomTransport.apply(state, RoomTransport.envelope('tv-1', 1, 'heartbeat', {}, 1001), 1001, secret)
  says heartbeat.accepted
  let duplicate = RoomTransport.apply(heartbeat.state, RoomTransport.envelope('tv-1', 1, 'heartbeat', {}, 1002), 1002, secret)
  says duplicate.reason
  let queued = RoomTransport.apply(heartbeat.state, RoomTransport.envelope('phone-1', 1, 'enqueue', {action: 'join'}, 1003), 1003, secret)
  let blocked = RoomTransport.apply(queued.state, RoomTransport.envelope('phone-2', 1, 'enqueue', {action: 'join'}, 1004), 1004, secret)
  says blocked.reason
  let token = RoomTransport.reconnect_token('ABCD', 'phone-1', secret)
  let reconnect = RoomTransport.apply(queued.state, RoomTransport.envelope('phone-1', 2, 'reconnect', {token: token}, 1005), 1005, secret)
  says reconnect.accepted
  let expired = RoomTransport.apply(reconnect.state, RoomTransport.envelope('phone-1', 3, 'heartbeat', {}, 12000), 12000, secret)
  says expired.reason
  says len(RoomTransport.disconnected_clients(reconnect.state, 7000, 5000))
end
EOF_TRANSPORT_SPEC

    cat > "$out/specs/lobby_spec.hey" <<'EOF_LOBBY_SPEC'
spec 'lobby controls host late join spectators kick expiration and rematch'
  expect stdout "c1\n1\nhost_required\nplaying\nlate_join_closed\n2\nexpired\n"
end

import '../src/Lobby.hey'

program
  let state = Lobby.new('ABCD', 'https://party.test/join/ABCD', 1000, 10000, false)
  let host = Lobby.apply(state, {kind: 'join', role: 'player', nickname: 'Ada', sequence: 1}, 1001)
  says host.state.host_id
  let guest = Lobby.apply(host.state, {kind: 'join', role: 'player', nickname: 'Grace', sequence: 2}, 1002)
  let watcher = Lobby.apply(guest.state, {kind: 'join', role: 'spectator', nickname: 'Linus', sequence: 3}, 1003)
  says Lobby.public_view(watcher.state).spectator_count
  let denied = Lobby.apply(watcher.state, {kind: 'start', client_id: 'c2', sequence: 4}, 1004)
  says denied.reason
  let started = Lobby.apply(watcher.state, {kind: 'start', client_id: 'c1', sequence: 4}, 1004)
  says started.state.phase
  let late = Lobby.apply(started.state, {kind: 'join', role: 'player', nickname: 'Late', sequence: 5}, 1005)
  says late.reason
  let finished = Lobby.apply(started.state, {kind: 'finish', client_id: 'c1', sequence: 5}, 1005)
  let rematch = Lobby.apply(finished.state, {kind: 'rematch', client_id: 'c1', sequence: 6}, 1006)
  says rematch.state.round
  let expired = Lobby.apply(rematch.state, {kind: 'finish', client_id: 'c1', sequence: 7}, 12000)
  says expired.state.phase
end
EOF_LOBBY_SPEC

    cat > "$out/specs/dictionary_bluff_spec.hey" <<'EOF_DICTIONARY_SPEC'
spec 'dictionary bluff replays deterministically and protects private state'
  expect stdout "true\ntrue\ntrue\ntrue\n4\nscored\n"
end

import 'stdlib:Json'
import 'stdlib:Text'
import '../src/GameKernel.hey'
import '../src/DictionaryBluff.hey'

program
  let players = [
    {id: 'p1', nickname: 'Ada'},
    {id: 'p2', nickname: 'Grace'},
    {id: 'p3', nickname: 'Linus'}
  ]
  let initial = DictionaryBluff.new(players, 7)
  let actions = [
    {kind: 'submit', sequence: 1, player_id: 'p1', text: 'a silver umbrella'},
    {kind: 'submit', sequence: 2, player_id: 'p2', text: 'a tiny sea bird'},
    {kind: 'submit', sequence: 3, player_id: 'p3', text: 'a winter lantern'},
    {kind: 'vote', sequence: 4, player_id: 'p1', choice_id: 'truth'},
    {kind: 'vote', sequence: 5, player_id: 'p2', choice_id: 'fake-p1'},
    {kind: 'vote', sequence: 6, player_id: 'p3', choice_id: 'fake-p1'}
  ]
  let after_one = GameKernel.replay(initial, actions, DictionaryBluff.apply)
  let after_two = GameKernel.replay(initial, actions, DictionaryBluff.apply)
  let submitting_json = Json.encode(DictionaryBluff.public_view(initial))
  let voting = GameKernel.replay(initial, Collections.take(actions, 3), DictionaryBluff.apply).state
  let voting_json = Json.encode(DictionaryBluff.public_view(voting))
  let private_json = Json.encode(DictionaryBluff.player_view(voting, 'p1'))
  says Json.encode_canonical(after_one.state) == Json.encode_canonical(after_two.state)
  says !Text.contains?(submitting_json, 'silver umbrella')
  says !Text.contains?(voting_json, 'author_id')
  says Text.contains?(private_json, 'silver umbrella')
  says after_one.state.scores['p1']
  says after_one.state.phase
end
EOF_DICTIONARY_SPEC

    cat > "$out/specs/categories_clash_spec.hey" <<'EOF_CATEGORIES_SPEC'
spec 'Categories Clash protects answers until reveal and cancels duplicates'
  expect stdout "0\nreview\nhost_required\nresults\n0\n0\n1\n"
end

import '../src/CategoriesClash.hey'

program
  let players = [{id: 'p1', nickname: 'Ada'}, {id: 'p2', nickname: 'Grace'}, {id: 'p3', nickname: 'Linus'}]
  let state = CategoriesClash.new(players, ['Animal', 'Food'], 'B', 'p1')
  says CategoriesClash.public_view(state).submitted_count
  let one = CategoriesClash.apply(state, {kind: 'submit', sequence: 1, player_id: 'p1', answers: [{category: 'Animal', answer: 'Bear'}, {category: 'Food', answer: 'Bread'}]})
  let two = CategoriesClash.apply(one.state, {kind: 'submit', sequence: 2, player_id: 'p2', answers: [{category: 'Animal', answer: 'Bear'}, {category: 'Food', answer: 'Banana'}]})
  let three = CategoriesClash.apply(two.state, {kind: 'submit', sequence: 3, player_id: 'p3', answers: [{category: 'Animal', answer: 'Badger'}, {category: 'Food', answer: 'Bread'}]})
  says three.state.phase
  let denied = CategoriesClash.apply(three.state, {kind: 'moderate', sequence: 4, player_id: 'p2', answer_id: 'p2:Food', valid: false})
  says denied.reason
  let moderated = CategoriesClash.apply(three.state, {kind: 'moderate', sequence: 4, player_id: 'p1', answer_id: 'p2:Food', valid: false})
  let revealed = CategoriesClash.apply(moderated.state, {kind: 'reveal', sequence: 5, player_id: 'p1'})
  says revealed.state.phase
  says revealed.state.scores['p1']
  says revealed.state.scores['p2']
  says revealed.state.scores['p3']
end
EOF_CATEGORIES_SPEC

    cat > "$out/specs/ghost_spec.hey" <<'EOF_GHOST_SPEC'
spec 'Ghost uses a locked dictionary challenge proof and elimination letters'
  expect stdout "1\nG\ntrue\n1\nplaying\n1\nduplicate_or_stale\ntrue\n"
end

import 'stdlib:Json'
import 'stdlib:Text'
import '../src/Ghost.hey'

program
  let players = [{id: 'p1', nickname: 'Ada'}, {id: 'p2', nickname: 'Grace'}, {id: 'p3', nickname: 'Linus'}]
  let words = ['game', 'garden', 'gather', 'ghost']
  let state = Ghost.new(players, 'sha256:test-dictionary', 4)
  let one = Ghost.apply(state, {kind: 'add_letter', sequence: 1, player_id: 'p1', letter: 'g'}, words)
  let two = Ghost.apply(one.state, {kind: 'add_letter', sequence: 2, player_id: 'p2', letter: 'a'}, words)
  let three = Ghost.apply(two.state, {kind: 'add_letter', sequence: 3, player_id: 'p3', letter: 'm'}, words)
  let completed = Ghost.apply(three.state, {kind: 'add_letter', sequence: 4, player_id: 'p1', letter: 'e'}, words)
  says completed.state.penalties['p1']
  says Ghost.penalty_label(completed.state.penalties['p1'])
  says completed.state.fragment == ''

  let challenge_state = Ghost.new(players, 'sha256:test-dictionary', 4)
  let cg = Ghost.apply(challenge_state, {kind: 'add_letter', sequence: 1, player_id: 'p1', letter: 'g'}, words)
  let ch = Ghost.apply(cg.state, {kind: 'add_letter', sequence: 2, player_id: 'p2', letter: 'h'}, words)
  let challenge = Ghost.apply(ch.state, {kind: 'challenge', sequence: 3, player_id: 'p3'}, words)
  let proved = Ghost.apply(challenge.state, {kind: 'prove', sequence: 4, player_id: 'p2', word: 'ghost'}, words)
  says proved.state.penalties['p3']
  says proved.state.phase

  let invalid_state = Ghost.new(players, 'sha256:test-dictionary', 4)
  let ix = Ghost.apply(invalid_state, {kind: 'add_letter', sequence: 1, player_id: 'p1', letter: 'x'}, words)
  let challenged = Ghost.apply(ix.state, {kind: 'challenge', sequence: 2, player_id: 'p2'}, words)
  let invalid = Ghost.apply(challenged.state, {kind: 'prove', sequence: 3, player_id: 'p1', word: 'xylophone'}, words)
  says invalid.state.penalties['p1']
  let stale = Ghost.apply(invalid.state, {kind: 'add_letter', sequence: 3, player_id: 'p1', letter: 'g'}, words)
  says stale.reason
  let public_json = Json.encode(Ghost.public_view(state))
  says Text.contains?(public_json, 'sha256:test-dictionary') and !Text.contains?(public_json, 'garden')
end
EOF_GHOST_SPEC

    cat > "$out/specs/spades_spec.hey" <<'EOF_SPADES_SPEC'
spec 'Spades keeps hands private and completes a deterministic hand'
  expect stdout "true\ntrue\ntrue\n13\nscored\n140\n81\n"
end

import 'stdlib:Json'
import 'stdlib:Text'
import '../src/CardKernel.hey'
import '../src/Spades.hey'

program
  let players = [
    {id: 'p1', nickname: 'North'},
    {id: 'p2', nickname: 'East'},
    {id: 'p3', nickname: 'South'},
    {id: 'p4', nickname: 'West'}
  ]
  let state = Spades.new(players, 17)
  let public_json = Json.encode(Spades.public_view(state))
  let private_json = Json.encode(Spades.player_view(state, 'p1'))
  says !Text.contains?(public_json, 'clubs-')
  says Text.contains?(private_json, 'hand')

  let sequence = 0
  for player in players
    set sequence = sequence + 1
    let result = Spades.apply(state, {kind: 'bid', sequence: sequence, player_id: player.id, bid: 3})
    set state = result.state
  end
  while state.phase == 'playing'
    let player_id = state.current_player
    let legal = CardKernel.legal_cards(state.hands[player_id], state.lead_suit, state.spades_broken)
    set sequence = sequence + 1
    let result = Spades.apply(state, {kind: 'play', sequence: sequence, player_id: player_id, card_id: legal[0].id})
    if !result.accepted
      fail result.reason
    end
    set state = result.state
  end
  let total_tricks = state.tricks['p1'] + state.tricks['p2'] + state.tricks['p3'] + state.tricks['p4']
  says total_tricks == 13
  says total_tricks
  says state.phase

  let nil_state = {
    ...state,
    bids: {p1: 0, p2: 4, p3: 4, p4: 4},
    tricks: {p1: 0, p2: 5, p3: 4, p4: 4},
    team_scores: {north_south: {score: 0, bags: 0}, east_west: {score: 0, bags: 0}}
  }
  let scored = Spades.score_hand(nil_state)
  says scored.north_south.score
  says scored.east_west.score
end
EOF_SPADES_SPEC

    cat > "$out/specs/bid_whist_spec.hey" <<'EOF_BID_WHIST_SPEC'
spec 'Bid Whist keeps kitty private and completes a deterministic hand'
  expect stdout "true\ntrue\n6\n12\nscored\n3\n"
end

import 'stdlib:Json'
import 'stdlib:Text'
import '../src/CardKernel.hey'
import '../src/BidWhist.hey'

program
  let players = [
    {id: 'p1', nickname: 'North'},
    {id: 'p2', nickname: 'East'},
    {id: 'p3', nickname: 'South'},
    {id: 'p4', nickname: 'West'}
  ]
  let state = BidWhist.new(players, 29)
  let public_json = Json.encode(BidWhist.public_view(state))
  says !Text.contains?(public_json, 'kitty')
  let sequence = 1
  set state = BidWhist.apply(state, {kind: 'bid', sequence: sequence, player_id: 'p1', amount: 3}).state
  set sequence = sequence + 1
  set state = BidWhist.apply(state, {kind: 'pass', sequence: sequence, player_id: 'p2', amount: 0}).state
  set sequence = sequence + 1
  set state = BidWhist.apply(state, {kind: 'pass', sequence: sequence, player_id: 'p3', amount: 0}).state
  set sequence = sequence + 1
  set state = BidWhist.apply(state, {kind: 'pass', sequence: sequence, player_id: 'p4', amount: 0}).state
  let private_json = Json.encode(BidWhist.player_view(state, 'p1'))
  says Text.contains?(private_json, 'kitty')
  says len(state.kitty)
  let discards = []
  let i = 0
  while i < 6
    set discards = [...discards, state.hands['p1'][i].id]
    set i = i + 1
  end
  set sequence = sequence + 1
  let contract_result = BidWhist.apply(state, {kind: 'contract', sequence: sequence, player_id: 'p1', direction: 'uptown', trump: 'spades', discards: discards})
  if !contract_result.accepted
    fail contract_result.reason
  end
  set state = contract_result.state
  while state.phase == 'playing'
    let player_id = state.current_player
    let legal = BidWhist.legal_cards(state.hands[player_id], state.lead_suit, state.contract)
    set sequence = sequence + 1
    let result = BidWhist.apply(state, {kind: 'play', sequence: sequence, player_id: player_id, card_id: legal[0].id})
    if !result.accepted
      fail result.reason
    end
    set state = result.state
  end
  let total_tricks = state.tricks['p1'] + state.tricks['p2'] + state.tricks['p3'] + state.tricks['p4']
  says total_tricks
  says state.phase
  let made = {...state, tricks: {p1: 5, p2: 2, p3: 4, p4: 1}, team_scores: {north_south: 0, east_west: 0}}
  says BidWhist.score_hand(made).north_south
end
EOF_BID_WHIST_SPEC

    cat > "$out/server/app.hey" <<EOF_SERVER
import 'stdlib:Env'
import 'stdlib:Jobs'
import 'stdlib:Web'
import '../src/RoomProtocol.hey'
import '../src/RoomTransport.hey'
import '../src/Lobby.hey'
import '../src/DictionaryBluff.hey'
import '../src/CategoriesClash.hey'
import '../src/Ghost.hey'
import '../src/Spades.hey'
import '../src/BidWhist.hey'

worker ProviderWork(message)
  return {ok: true, kind: message.kind}
end

module PartyServer
  fn route_list(request)
  return Web.json({routes: ['GET /routes', 'GET /health', 'GET /api/transport/template', 'GET /api/lobby/template', 'GET /api/room/template', 'GET /api/game/template', 'GET /api/categories/template', 'GET /api/ghost/template', 'GET /api/spades/template', 'GET /api/bid-whist/template', 'GET /tv', 'GET /join/:code']})
end

  fn health(request)
  return Web.json({ok: true, service: '$name'})
end

  fn transport_template(request)
  let state = RoomTransport.new('ABCD', 1000, 3600000, 128)
  let applied = RoomTransport.apply(state, RoomTransport.envelope('tv-1', 1, 'heartbeat', {}, 1001), 1001, 'development-secret')
  return Web.json({accepted: applied.accepted, code: applied.state.code, pending: applied.state.pending, expires_at_ms: applied.state.expires_at_ms})
end


  fn lobby_template(request)
    let room = RoomProtocol.new('ABCD', '$base_url', 'development-secret')
    return Web.json(Lobby.public_view(Lobby.new('ABCD', room.join_url, 1000, 3600000, false)))
  end

  fn room_template(request)
  return Web.json(RoomProtocol.public_view(RoomProtocol.new('ABCD', '$base_url', 'development-secret')))
end

  fn game_template(request)
  let players = [{id: 'p1', nickname: 'Ada'}, {id: 'p2', nickname: 'Grace'}, {id: 'p3', nickname: 'Linus'}]
  return Web.json(DictionaryBluff.public_view(DictionaryBluff.new(players, 7)))
end


  fn categories_template(request)
    let players = [{id: 'p1', nickname: 'Ada'}, {id: 'p2', nickname: 'Grace'}, {id: 'p3', nickname: 'Linus'}]
    return Web.json(CategoriesClash.public_view(CategoriesClash.new(players, ['Animal', 'Food', 'Place'], 'B', 'p1')))
  end

  fn ghost_template(request)
    let players = [{id: 'p1', nickname: 'Ada'}, {id: 'p2', nickname: 'Grace'}, {id: 'p3', nickname: 'Linus'}]
    return Web.json(Ghost.public_view(Ghost.new(players, 'sha256:locked-ghost-words', 4)))
  end

  fn spades_template(request)
  let players = [{id: 'p1', nickname: 'North'}, {id: 'p2', nickname: 'East'}, {id: 'p3', nickname: 'South'}, {id: 'p4', nickname: 'West'}]
  return Web.json(Spades.public_view(Spades.new(players, 17)))
end

  fn bid_whist_template(request)
  let players = [{id: 'p1', nickname: 'North'}, {id: 'p2', nickname: 'East'}, {id: 'p3', nickname: 'South'}, {id: 'p4', nickname: 'West'}]
  return Web.json(BidWhist.public_view(BidWhist.new(players, 29)))
end

  fn tv(request)
  return Web.file('public/tv', '/index.html')
end

  fn phone(request)
  return Web.file('public/phone', '/index.html')
end

  fn party_js(request)
  return Web.file('public', '/party.js')
end

end

program
  let ProviderJobs = Jobs.define('PartyProviderJobs', ProviderWork, count: 2, capacity: 128)
  let host = Env.default('HEY_PARTY_HOST', '127.0.0.1')
  let port = parse_int(Env.default('HEY_PARTY_PORT', '3072'))
  let routes = Web.routes([
    Web.get('/routes', PartyServer.route_list),
    Web.get('/health', PartyServer.health),
    Web.get('/api/transport/template', PartyServer.transport_template),
    Web.get('/api/lobby/template', PartyServer.lobby_template),
    Web.get('/api/room/template', PartyServer.room_template),
    Web.get('/api/game/template', PartyServer.game_template),
    Web.get('/api/categories/template', PartyServer.categories_template),
    Web.get('/api/ghost/template', PartyServer.ghost_template),
    Web.get('/api/spades/template', PartyServer.spades_template),
    Web.get('/api/bid-whist/template', PartyServer.bid_whist_template),
    Web.get('/tv', PartyServer.tv),
    Web.get('/join/:code', PartyServer.phone),
    Web.get('/party.js', PartyServer.party_js)
  ])
  let options = {host: host, port: port, workers: 0, request_timeout_ms: 15000, max_body_bytes: 1048576}
  let served = Web.serve(routes, options)
  if !served.ok
    fail served.error
  end
end
EOF_SERVER

    mkdir -p "$out/client"
    cat > "$out/client/app.hey" <<'EOF_CLIENT'
import 'stdlib:Cli'
import 'stdlib:Env'
import 'stdlib:Http'
import 'stdlib:Result'

program
  let args = Cli.args()
  let path = '/routes'
  if len(args) > 0
    set path = args[0]
  end
  let host = Env.default('HEY_PARTY_HOST', '127.0.0.1')
  let port = Env.default('HEY_PARTY_PORT', '3072')
  let response = Http.request('GET', 'http://' + host + ':' + port + path, {headers: {'accept': 'application/json'}, timeout_ms: 5000, max_response_bytes: 1048576, max_redirects: 0})
  if Result.error?(response)
    fail Result.code(response) + ': ' + Result.message(response)
  end
  let value = Result.value(response)
  says value.status
  print value.body
end
EOF_CLIENT

    cat > "$out/bin/server" <<'EOF_BIN_SERVER'
#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
HEYC="$HEY_ROOT/bin/heyc"
[ -x "$HEYC" ] || HEYC="$HEY_ROOT/build/heyc"
[ -x "$HEYC" ] || { echo "Hey compiler not found: $HEY_ROOT" >&2; exit 69; }
mkdir -p "$ROOT/build"
BINARY="$ROOT/build/party-server"
rebuild=false
[ -x "$BINARY" ] || rebuild=true
if [ "$rebuild" = false ] && find "$ROOT/server" "$ROOT/src" -type f -name '*.hey' -newer "$BINARY" -print -quit | grep . >/dev/null; then rebuild=true; fi
if [ "$rebuild" = true ]; then
  HEY_ROOT="$HEY_ROOT" HEY_STDLIB_PATH="$HEY_ROOT/stdlib" HEY_COMPILER_BUILD_DIR="$HEY_ROOT/build" \
    "$HEYC" build --backend native-c "$ROOT/server/app.hey" -o "$BINARY"
fi
exec "$BINARY"
EOF_BIN_SERVER

    cat > "$out/bin/client" <<'EOF_BIN_CLIENT'
#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
exec "$HEY_ROOT/bin/hey" "$ROOT/client/app.hey" "$@"
EOF_BIN_CLIENT

    cat > "$out/bin/check-live" <<'EOF_CHECK_LIVE'
#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
HEY_ROOT="${HEY_ROOT:-$HOME/dev/hey-lang-bootstrap-plan}"
PORT="${HEY_PARTY_TEST_PORT:-$((32000 + ($$ % 1000)))}"
mkdir -p "$ROOT/tmp"
LOG="$ROOT/tmp/party-server-$PORT.log"
HEY_PARTY_HOST=127.0.0.1 HEY_PARTY_PORT="$PORT" HEY_ROOT="$HEY_ROOT" "$ROOT/bin/server" >"$LOG" 2>&1 &
pid=$!
cleanup() { kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true; }
trap cleanup EXIT HUP INT TERM
ready=false
for attempt in $(seq 1 600); do
  if HEY_PARTY_HOST=127.0.0.1 HEY_PARTY_PORT="$PORT" HEY_ROOT="$HEY_ROOT" "$ROOT/bin/client" /health >"$ROOT/tmp/health.out" 2>/dev/null; then ready=true; break; fi
  if ! kill -0 "$pid" 2>/dev/null; then cat "$LOG" >&2; exit 70; fi
  sleep 0.1
done
[ "$ready" = true ] || { cat "$LOG" >&2; exit 70; }
pids=''; i=1
while [ "$i" -le 8 ]; do
  path='/api/transport/template'
  [ $((i % 2)) -eq 0 ] && path='/routes'
  HEY_PARTY_HOST=127.0.0.1 HEY_PARTY_PORT="$PORT" HEY_ROOT="$HEY_ROOT" "$ROOT/bin/client" "$path" >"$ROOT/tmp/client-$i.out" 2>&1 &
  pids="$pids $!"; i=$((i + 1))
done
for child in $pids; do wait "$child"; done
for output in "$ROOT/tmp"/client-*.out; do grep -F '200' "$output" >/dev/null; done
grep -F '"accepted":true' "$ROOT/tmp/client-1.out" >/dev/null
grep -F 'GET /routes' "$ROOT/tmp/client-2.out" >/dev/null
kill -0 "$pid"
echo 'party transport live loopback ok clients=8 workers=auto heartbeat=true server_alive=true'
EOF_CHECK_LIVE
    chmod 0755 "$out/bin/server" "$out/bin/client" "$out/bin/check-live"

    cat > "$out/public/tv/index.html" <<'EOF_TV'
<!doctype html><meta charset="utf-8"><title>Hey Party TV</title>
<main id="tv" data-view="public"><h1>Dictionary Bluff</h1><p id="room-code">ABCD</p><div id="qr" aria-label="join QR payload"></div><ol id="players"></ol></main>
<script src="/party.js"></script>
EOF_TV
    cat > "$out/public/phone/index.html" <<'EOF_PHONE'
<!doctype html><meta charset="utf-8"><title>Join Hey Party</title>
<main id="phone" data-view="private"><h1>Join room</h1><form id="join"><input name="nickname" autocomplete="nickname" required><button>Join</button></form><section id="private-player-state"></section></main>
<script src="/party.js"></script>
EOF_PHONE
    cat > "$out/public/party.js" <<'EOF_JS'
const role = document.querySelector('[data-view]')?.dataset.view;
const state = { role, sequence: 0, reconnectToken: localStorage.getItem('hey-party-reconnect') };
window.HeyParty = {
  nextAction(kind, payload = {}) { state.sequence += 1; return { kind, sequence: state.sequence, ...payload }; },
  remember(token) { state.reconnectToken = token; localStorage.setItem('hey-party-reconnect', token); },
  publicOnly(snapshot) { const copy = structuredClone(snapshot); delete copy.self; return copy; },
  state
};
EOF_JS

    cat > "$out/bin/check" <<EOF_CHECK
#!/usr/bin/env sh
set -eu
ROOT="\$(CDPATH= cd -- "\$(dirname -- "\$0")/.." && pwd)"
HEY_ROOT="\${HEY_ROOT:-\$HOME/dev/hey-lang-bootstrap-plan}"
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/room_protocol_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/room_transport_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/lobby_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/dictionary_bluff_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/categories_clash_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/ghost_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/spades_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/specs/bid_whist_spec.hey" --test
env HEY_ROOT="\$HEY_ROOT" HEY_STDLIB_PATH="\$HEY_ROOT/stdlib" "\$HEY_ROOT/bin/heyc" "\$ROOT/server/app.hey" --check
grep -F '"hey_web": "^0.1.6"' "\$ROOT/hey-package.json" >/dev/null
grep -F 'data-view="public"' "\$ROOT/public/tv/index.html" >/dev/null
grep -F 'data-view="private"' "\$ROOT/public/phone/index.html" >/dev/null
grep -F 'module RoomTransport' "\$ROOT/src/RoomTransport.hey" >/dev/null
grep -F 'module Lobby' "\$ROOT/src/Lobby.hey" >/dev/null
grep -F 'module DictionaryBluff' "\$ROOT/src/DictionaryBluff.hey" >/dev/null
grep -F 'module CategoriesClash' "\$ROOT/src/CategoriesClash.hey" >/dev/null
grep -F 'module Ghost' "\$ROOT/src/Ghost.hey" >/dev/null
grep -F 'module Spades' "\$ROOT/src/Spades.hey" >/dev/null
grep -F 'module BidWhist' "\$ROOT/src/BidWhist.hey" >/dev/null
expected_dictionary=\$(cat "\$ROOT/data/ghost_words.sha256")
if command -v shasum >/dev/null 2>&1; then actual_dictionary=\$(shasum -a 256 "\$ROOT/data/ghost_words.txt" | awk '{print \$1}'); else actual_dictionary=\$(sha256sum "\$ROOT/data/ghost_words.txt" | awk '{print \$1}'); fi
[ "\$expected_dictionary" = "\$actual_dictionary" ]
echo 'party project checks passed public_private_split=true sequence_safe=true signed_join=true heartbeat=true reconnect=true backpressure=true expiration=true lobby=true spectators=true rematch=true deterministic_game_kernel=true dictionary_bluff=true categories_clash=true ghost=true locked_dictionary=true spades=true bid_whist=true'
EOF_CHECK
    chmod 0755 "$out/bin/check"

    cat > "$out/README.md" <<EOF_README
# $name

Generated Hey party-room starter.

- The TV renders only RoomProtocol.public_view.
- A phone receives RoomProtocol.player_view for its authenticated player.
- Join URLs bind room code and nonce to a SHA-256 signature.
- Every action carries a monotonically increasing sequence number.
- RoomTransport adds heartbeat, reconnect proof, bounded pending work, expiration, and disconnect detection.
- Lobby adds host authority, late-join policy, spectators, kick, expiration presentation, rematch, and a native QR payload descriptor.
- Reconnect tokens stay in the private player projection.
- GameKernel replays immutable actions deterministically.
- DictionaryBluff ships as the first complete public/private party-game reducer.
- CategoriesClash adds simultaneous private answers, normalization, duplicate cancellation, host moderation, and scored reveal.
- Ghost adds a SHA-256-locked dictionary, turn-owned fragments, challenge proof, completion loss, GHOST penalties, and elimination.
- Spades ships a deterministic 52-card deal, bidding, legal play, tricks, nil, bags, and partnership scoring.
- Bid Whist extends the trick kernel with jokers, kitty, auction, uptown/downtown/no-trump contracts, and contract scoring.

Current package requirements were selected from https://www.jayteesf.com/packages/.

\`\`\`sh
export HEY_ROOT="\$HOME/dev/hey-lang-bootstrap-plan"
bin/check
\$HEY_ROOT/bin/hey server/app.hey
\`\`\`

The generated Dictionary Bluff reducer includes private submissions, anonymous voting, deterministic truth placement, scoring, and replay receipts.

The generated Ghost reducer never ships the dictionary through public state; it exposes only the locked dictionary identity while the authoritative server resolves completion and challenge proofs.

The generated Spades reducer deals a deterministic 52-card deck, keeps hands private, enforces follow-suit and unbroken-spade leads, scores nil/contracts/bags, and includes a complete scripted hand.

The generated Bid Whist reducer deals 54 cards including jokers, keeps the six-card kitty private, runs a server-owned auction and contract declaration, and plays all twelve tricks.

The starter uses HTTP endpoints and browser polling/application code. Add a
WebSocket package only after it has an immutable release and lock receipt; the
room reducer and public/private projections remain transport independent.
EOF_README

    printf 'party project created name=%s path=%s hey_party=0.1.0 hey_tv=0.1.0 hey_web=0.1.6 hey_mobile=0.1.3 platform_adapters=consumer_selected public_private_split=true dictionary_bluff=true categories_clash=true ghost=true locked_dictionary=true spades=true bid_whist=true\n' "$name" "$out"
    ;;
  help|--help|-h|'') usage ;;
  *) echo "unknown Hey party command: ${1:-}" >&2; usage >&2; exit 2 ;;
esac
