# Continuation prompt

Maintain `hey_i18n` as an independently versioned third-party Hey package.
Keep every public function pure (catalog in, chain in, string out) and
keep the package stdlib-only. Enforce the apostrophe rule from
`docs/DESIGN.md` in every string value. Every source change must bump
VERSION, update manifest/docs/specs/status, run `bin/check`, and generate
immutable release and source archives through `hey_packager`.
