#define _POSIX_C_SOURCE 200809L
#include "hey_toml.h"
#include "tomlc17.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <locale.h>
#include <limits.h>
typedef union {max_align_t alignment;size_t size;} allocation;
static _Thread_local size_t used,peak,budget;
static _Thread_local int exhausted,active;
static void *bounded_realloc(void *p,size_t n){
 allocation *old=p?(allocation*)p-1:NULL;size_t before=old?old->size:0;
 if(n>SIZE_MAX-sizeof(allocation)||n+sizeof(allocation)>budget-(used-before)){exhausted=1;return NULL;}
 size_t total=n+sizeof(allocation);allocation *next=realloc(old,total);if(!next)return NULL;next->size=total;used=used-before+total;if(used>peak)peak=used;return next+1;
}
static void bounded_free(void *p){if(!p)return;allocation *header=(allocation*)p-1;used-=header->size;free(header);}
/* Reject raw NUL and Unicode outside strings/comments per the published TOML
 * grammar; keep the pinned parser sources unchanged. */
static int lexical_guard(HeyNativeBytesView input){
 size_t i=0;int quote_char=0,triple=0,comment=0;
 if(input.length>=3&&input.data[0]==239&&input.data[1]==187&&input.data[2]==191)i=3;
 for(;i<input.length;i++){
  unsigned char ch=input.data[i];if(ch==0)return 0;
  if(comment){if(ch==10)comment=0;continue;}
  if(quote_char){
   if(quote_char==34&&ch==92){if(i+1<input.length)i++;continue;}
   if(ch==(unsigned)quote_char){size_t count=1;while(i+count<input.length&&input.data[i+count]==ch)count++;
    if(!triple){quote_char=0;continue;}
    if(count>=3){quote_char=0;triple=0;i+=count-1;}else i+=count-1;
   }
   continue;
  }
  if(ch==35){comment=1;continue;}
  if(ch==34||ch==39){quote_char=ch;triple=i+2<input.length&&input.data[i+1]==ch&&input.data[i+2]==ch;if(triple)i+=2;continue;}
  if(ch>=128)return 0;
 }
 return 1;
}
static pthread_once_t initialized=PTHREAD_ONCE_INIT;
static locale_t numeric_locale;
static void initialize(void){toml_option_t opt=toml_default_option();opt.check_utf8=true;opt.mem_realloc=bounded_realloc;opt.mem_free=bounded_free;toml_set_option(opt);numeric_locale=newlocale(LC_NUMERIC_MASK,"C",NULL);}
struct output {uint8_t *p;size_t n,cap,limit;int failed;int invalid_key;};
static void append(struct output *o,const void *p,size_t n){
 if(o->failed)return;if(n>o->limit-o->n){o->failed=1;return;}
 if(o->n+n>o->cap){size_t cap=o->cap?o->cap:256;while(cap<o->n+n){if(cap>o->limit/2){cap=o->limit;break;}cap*=2;}if(cap>budget-used){exhausted=1;o->failed=1;return;}uint8_t *next=realloc(o->p,cap);if(!next){o->failed=1;return;}o->p=next;o->cap=cap;}
 if(n)memcpy(o->p+o->n,p,n);o->n+=n;
}
static void text(struct output *o,const char *s){append(o,s,strlen(s));}
static void quote(struct output *o,const char *p,size_t n){
 text(o,"\"");for(size_t i=0;i<n;i++){uint8_t c=(uint8_t)p[i];if(c=='"'||c=='\\'){uint8_t pair[2]={'\\',c};append(o,pair,2);}else if(c<32){char escaped[7];snprintf(escaped,sizeof(escaped),"\\u%04x",c);text(o,escaped);}else append(o,&c,1);}text(o,"\"");
}
static void scalar(struct output *o,const char *type,const char *value,int typed,int special){
 if(typed){text(o,"{\"type\":");quote(o,type,strlen(type));text(o,",\"value\":");quote(o,value,strlen(value));text(o,"}");}
 else if(special){text(o,"{\"toml_type\":");quote(o,type,strlen(type));text(o,",\"value\":");quote(o,value,strlen(value));text(o,"}");}
 else text(o,value);
}
static void serialize(struct output *o,toml_datum_t d,unsigned depth,int typed){
 if(o->failed)return;if(depth>128){o->failed=1;return;}
 char value[160];const char *kind=NULL;
 switch(d.type){
 case TOML_TABLE:
  text(o,"{");for(int i=0;i<d.u.tab.size;i++){if(typed!=2&&memchr(d.u.tab.key[i],0,(size_t)d.u.tab.len[i])){o->failed=1;o->invalid_key=1;return;}if(i)text(o,",");quote(o,d.u.tab.key[i],(size_t)d.u.tab.len[i]);text(o,":");serialize(o,d.u.tab.value[i],depth+1,typed);}text(o,"}");return;
 case TOML_ARRAY:
  text(o,"[");for(int i=0;i<d.u.arr.size;i++){if(i)text(o,",");serialize(o,d.u.arr.elem[i],depth+1,typed);}text(o,"]");return;
 case TOML_STRING:
  if(typed)text(o,"{\"type\":\"string\",\"value\":");quote(o,d.u.str.ptr,(size_t)d.u.str.len);if(typed)text(o,"}");return;
 case TOML_INT64:
  snprintf(value,sizeof(value),"%lld",(long long)d.u.int64);scalar(o,"integer",value,typed,0);return;
 case TOML_BOOLEAN:
  scalar(o,"bool",d.u.boolean?"true":"false",typed,0);return;
 case TOML_FP64:
  if(isnan(d.u.fp64))strcpy(value,"nan");else if(isinf(d.u.fp64))strcpy(value,signbit(d.u.fp64)?"-inf":"inf");else {snprintf(value,sizeof(value),"%.17g",d.u.fp64);if(!strpbrk(value,".eE"))strcat(value,".0");}scalar(o,"float",value,typed,!isfinite(d.u.fp64));return;
 case TOML_DATE:kind="date-local";snprintf(value,sizeof(value),"%04d-%02d-%02d",d.u.ts.year,d.u.ts.month,d.u.ts.day);break;
 case TOML_TIME:kind="time-local";snprintf(value,sizeof(value),"%02d:%02d:%02d.%06d",d.u.ts.hour,d.u.ts.minute,d.u.ts.second,d.u.ts.usec);break;
 case TOML_DATETIME:case TOML_DATETIMETZ:
  kind=d.type==TOML_DATETIME?"datetime-local":"datetime";snprintf(value,sizeof(value),"%04d-%02d-%02dT%02d:%02d:%02d.%06d",d.u.ts.year,d.u.ts.month,d.u.ts.day,d.u.ts.hour,d.u.ts.minute,d.u.ts.second,d.u.ts.usec);
  if(d.type==TOML_DATETIMETZ){size_t n=strlen(value);if(d.u.ts.tz==0)strcpy(value+n,"Z");else {int tz=d.u.ts.tz;snprintf(value+n,sizeof(value)-n,"%c%02d:%02d",tz<0?'-':'+',abs(tz)/60,abs(tz)%60);}}break;
 default:o->failed=1;return;
 }
 scalar(o,kind,value,typed,1);
}
static void release(void *ctx,uint8_t *p,size_t n){(void)ctx;(void)n;free(p);}
static HeyNativeOwnedBytes failure(const char *code,unsigned line){char json[160];int n=snprintf(json,sizeof(json),"{\"ok\":false,\"code\":\"%s\",\"line\":%u}",code,line);if(n<0||(size_t)n>=sizeof(json))return(HeyNativeOwnedBytes){0};uint8_t *p=malloc((size_t)n);if(!p)return(HeyNativeOwnedBytes){0};memcpy(p,json,(size_t)n);return(HeyNativeOwnedBytes){p,(size_t)n,release,NULL};}
HeyNativeOwnedBytes toml_document(HeyNativeBytesView input,uint32_t input_limit,uint32_t memory_limit,uint32_t output_limit,uint32_t typed){
 if(active||used)return failure("native_state_busy",0);
 if(input_limit<1||input_limit>1048576||input.length>input_limit||(!input.data&&input.length)||memory_limit<4096||memory_limit>67108864||output_limit<256||output_limit>16777216||typed>2)return failure("toml_limits_invalid",0);
 if(!lexical_guard(input))return failure("invalid_toml",0);
 pthread_once(&initialized,initialize);if(!numeric_locale)return failure("toml_native_unavailable",0);
 active=1;budget=memory_limit;peak=0;exhausted=0;locale_t before=uselocale(numeric_locale);
 toml_result_t parsed=toml_parse(input.data?(const char*)input.data:"",(int)input.length);
 if(!parsed.ok){unsigned line=0;(void)sscanf(parsed.errmsg,"(line %u)",&line);toml_free(parsed);uselocale(before);active=0;return failure(exhausted?"toml_memory_limit":"invalid_toml",line);}
 struct output out={.limit=output_limit};text(&out,"{\"ok\":true,\"value\":");serialize(&out,parsed.toptab,0,(int)typed);text(&out,"}");toml_free(parsed);uselocale(before);active=0;
 if(out.failed||used){free(out.p);return failure(out.invalid_key?"toml_key_not_representable":(exhausted?"toml_memory_limit":"toml_output_limit"),0);}
 return(HeyNativeOwnedBytes){out.p,out.n,release,NULL};
}
