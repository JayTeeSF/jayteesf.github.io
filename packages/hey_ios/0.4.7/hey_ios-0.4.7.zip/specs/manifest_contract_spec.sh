#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
HEY_ROOT=${HEY_ROOT:-"$HOME/dev/hey-lang-bootstrap-plan"}
work=$(mktemp -d "${TMPDIR:-/tmp}/hey-ios-manifest-contract.XXXXXX")
cleanup() { rm -rf "$work"; }
trap cleanup EXIT HUP INT TERM

HEY_ROOT="$HEY_ROOT" "$ROOT/tools/hey-ios-api-app.sh" \
  --source "$ROOT/specs/fixtures/manifest_length_current.hey" \
  --out "$work/current" \
  --bundle-id com.example.manifest-contract \
  --display-name 'Manifest Contract' \
  --share-extension

grep -F 'define i64 @hey_fn_ios_manifest_length()' "$work/current/src/app-ios.ll" >/dev/null
[ -x "$work/current/ManifestContract.app/PlugIns/ManifestContractShare.appex/ManifestContractShare" ] || {
  echo 'manifest contract spec: share extension did not link the manifest-length bridge' >&2
  exit 1
}
if grep -E 'call .*@hey_(runtime_(init|set_argv|shutdown|error)|llvm_)' "$work/current/src/app-ios.ll" >/dev/null; then
  echo 'manifest contract spec: current zero-argument shell retained Hey runtime calls' >&2
  exit 1
fi

if HEY_ROOT="$HEY_ROOT" "$ROOT/tools/hey-ios-api-app.sh" \
  --source "$ROOT/specs/fixtures/manifest_length_unsafe_legacy.hey" \
  --out "$work/unsafe" \
  --bundle-id com.example.manifest-contract-unsafe \
  --display-name 'Unsafe Manifest Contract' >"$work/unsafe.log" 2>&1; then
  echo 'manifest contract spec: pointer-shaped legacy action export was accepted' >&2
  exit 1
fi
grep -E 'manifest length|runtime-free|scalar ABI' "$work/unsafe.log" >/dev/null || {
  cat "$work/unsafe.log" >&2
  echo 'manifest contract spec: unsafe legacy refusal did not name the contract defect' >&2
  exit 1
}

echo 'hey_ios_manifest_length_contract=true'
