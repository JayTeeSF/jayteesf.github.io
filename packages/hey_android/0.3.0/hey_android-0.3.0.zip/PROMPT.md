# Continuation prompt

Continue `hey_android` as an independently versioned package. Preserve the
plumbing/porcelain boundary: do not add Android syntax to Hey, do not edit or
copy the Hey runtime (compile it from HEY_ROOT), do not move application policy
into this package, and do not duplicate cross-platform vocabulary that belongs
in `hey_mobile`. No Java or Kotlin source, ever; the only non-Hey code is the
documented glue, manifest template and runtime profile under `native/`.

For every slice:

1. bump with `bin/bump`;
2. add executable specs, each with a negative control;
3. update README, docs (design, testing, roadmap), the extraction ledger, and in-progress/todos/done;
4. wrap every heyc build in the build lock (`HEY_HEYC_LOCK`);
5. run `bin/check`, which boots the emulator and always shuts it down;
6. `bin/release`, then `bin/publish` to `$HOME/dev/jayteesf.github.io/packages/hey_android/VERSION/`.
