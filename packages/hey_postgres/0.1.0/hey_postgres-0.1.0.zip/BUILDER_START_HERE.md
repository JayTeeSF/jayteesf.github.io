# hey_postgres Builder Start Here

## Goal

Turn this repository into the verified immutable `hey_postgres` package described by `PACKAGE_SPEC.md` using the current Hey toolchain and the canonical `hey_packager` workflow.

## Non-negotiable package rule

Every package created for MMeoww must depend on `hey_packager` and use it for the standard package structure/check/release/publish/source-handoff workflow. Do not copy packaging policy into this repository and allow it to drift.

At the time this handoff was written the accessible canonical `hey_packager` manifest is version `0.1.6`. When you initialize the package, declare an **exact immutable `hey_packager` dependency** to the current approved release; do not use a moving branch or `latest`.

## First implementation actions

1. Use the exact Hey checkout/toolchain intended for the release.
2. Run the current `hey package init hey_postgres --path <this-repo>` workflow, or generate the scaffold in a temporary directory and merge it if the current command refuses a non-empty repository. Preserve `README.md`, `PACKAGE_SPEC.md`, this handoff, and Git history.
3. Use the current Hey native-package generator to produce the native manifest/build scaffold. Do **not** write `hey.native.json` from memory or from an old example.
4. Make the package manifest depend exactly on the approved immutable `hey_packager` release.
5. Use the standard package surfaces expected by `hey_packager`: package-specific `bin/package-check`, shared `bin/check`, `bin/release`, `bin/publish`, `bin/source-zip`, `bin/bump`, required docs, and at least one executable docs example.
6. Implement the Hey API and libpq native boundary in `PACKAGE_SPEC.md`.
7. Add all required tests, including blocking/native-resource/leak/concurrency/TLS/COPY/LISTEN-NOTIFY coverage.
8. Run package-specific checks, `hey_packager check`, target builds, and native leak/resource tests.
9. Bump to the intended release version through the canonical packager bump workflow.
10. Publish an immutable release through `hey_packager`; record archive, release, manifest and content hashes.

## MMeoww gate

Do not add a guessed dependency or local path to MMeoww. Only after this package has an immutable verified registry release should MMeoww add that exact version to `hey-package.json` and regenerate/commit `hey.lock.json` with the Hey package resolver.

## Stop conditions

Do not claim completion if any of these are missing: generated native descriptor, successful compile on claimed targets, package tests, resource/leak checks, docs, immutable release metadata/hashes, or exact registry version.
