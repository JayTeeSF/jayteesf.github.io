# hey_zstd

Bounded zstd file streams with checksums, exclusive private outputs and strict complete-frame decoding.

Version 0.1.0, implementation in progress. Hey module over a native ABI-v2 kernel; no compiler/runtime source modifications. Build with `bin/build-native`. Supported build targets are Linux x86-64 and Darwin arm64.

Native codec receipt passes exact null/empty/escaping/Unicode and bounded/truncated-input cases. Complete package and LLVM composition gates are still being assembled; do not claim production readiness.
