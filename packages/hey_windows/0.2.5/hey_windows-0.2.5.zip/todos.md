# Todos

- User-agent suffix and application icon (ROADMAP 2).
- Authenticode signing and winget or MSIX distribution (ROADMAP 3).
- Native hey_mobile rendering when Hey targets Windows (ROADMAP 4).
- A real-PC receipt recorded in docs/TESTING.md once the owner runs one.
- Sign in on real Windows and reopen, to prove the session persists in %LOCALAPPDATA%\MyQueue.
- When Hey 606a lands: bin/hey-windows-app and bin/package-check move from `bin/heyc FILE --run` to `bin/hey FILE` (heyc is deleted in 606a), and `let told = tell(...)` in tools/hey_windows_app.hey becomes `_ = tell(...)`. On 605a, `bin/hey` refuses the bare `return` in init's loop, so this waits for 606a. Source: GippiPiTy, hey channel, 2026-11-11.
- Microsoft Store distribution: MSIX packaging (the Store signs MSIX for free; registration is free for individuals and companies).
- When GippiPiTy posts verified commits (stdlib Markdown to HTML; one return rule for Crypto.sha256_file and Files.size; a stdin terminal check): generate docs/GETTING_STARTED.html from the .md with stdlib Markdown, adjust the fingerprint call in tools/hey_windows_app.hey and tools/package_check.hey to the new shape, and replace the /dev/tty probe in init with the terminal check. Source: GippiPiTy, hey channel, 2026-11-11 4:20 PM.
- Markdown: done in 0.2.5 with Hey's new Markdown module vendored as tools/markdown.hey (feat/stdlib-markdown-20261111 0355356d6, four `while f(x)` loops patched to `== true` for heyc). When Hey's next release ships it: delete tools/markdown.hey, import 'stdlib:Markdown' in tools/guide.hey, and rerun bin/docs-html (the package check proves the page is unchanged).
