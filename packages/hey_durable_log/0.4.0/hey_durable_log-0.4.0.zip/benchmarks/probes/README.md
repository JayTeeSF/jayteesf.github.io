# Platform probes

Small standalone programs that establish what the *platform* costs, so the
journal's own numbers can be read against a known floor. They are probes, not
gates: nothing here asserts, it only measures.

| Probe | Question it answers |
|---|---|
| `darwin_barrier_tiers.c` | What do `fsync`, `F_BARRIERFSYNC` and `F_FULLFSYNC` actually cost on this Mac? |
| `preallocation_effect.c` | Does writing in place instead of extending the file make the barrier cheaper? |
| `sqlite_durability_matrix.c` | Which `journal_mode` × `synchronous` × `fullfsync` combinations issue a real barrier? |

Build one directly, e.g.:

```sh
cc -O2 benchmarks/probes/darwin_barrier_tiers.c -o /tmp/tiers && /tmp/tiers
docker run --rm -v "$PWD":/src hey-durable-log-linux \
  sh -c 'cd /src && cc -O2 -D_GNU_SOURCE benchmarks/probes/preallocation_effect.c -o /tmp/pa && /tmp/pa'
```

The results these produced on 2026-09-04 are recorded in
`docs/BENCHMARK-2026-09-04-linux-vs-sqlite.md`, which is the document to read
first — the probes exist so those numbers can be re-derived rather than trusted.
