#include "hey_sqlite3.h"
#include "hey_sqlite3_functions.h"
#include <sqlite3.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static char *hey_sqlite3_c_string(HeyNativeUtf8View value) {
  char *out = (char *)malloc(value.length + 1);
  if (!out) return NULL;
  if (value.length && value.data) memcpy(out, value.data, value.length);
  out[value.length] = '\0';
  return out;
}

static sqlite3 *hey_sqlite3_database(HeyNativeHandle value) {
  return (sqlite3 *)(uintptr_t)value;
}

static sqlite3_stmt *hey_sqlite3_statement(HeyNativeHandle value) {
  return (sqlite3_stmt *)(uintptr_t)value;
}

HeyNativeHandle hey_sqlite3_open(HeyNativeUtf8View path, int32_t flags) {
  char *path_c = hey_sqlite3_c_string(path);
  if (!path_c) return (HeyNativeHandle)0;
  sqlite3 *database = NULL;
  int rc = sqlite3_open_v2(path_c, &database, flags, NULL);
  free(path_c);
  if (database) {
    sqlite3_extended_result_codes(database, 1);
    /* Every connection this package hands out carries PostgreSQL-compatible
       greatest()/least() (see native/hey_sqlite3_functions.c), so caller SQL
       written for PostgreSQL keeps its null-ignoring semantics instead of
       silently changing answers through SQLite's max()/min(). A failed open
       is left alone: the handle exists only so the caller can read errmsg. */
    if (rc == SQLITE_OK) (void)hey_sqlite3_register_functions(database);
  }
  return (HeyNativeHandle)(uintptr_t)database;
}

int32_t hey_sqlite3_close(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  return db ? (int32_t)sqlite3_close(db) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_errcode(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  return db ? (int32_t)sqlite3_errcode(db) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_extended_errcode(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  return db ? (int32_t)sqlite3_extended_errcode(db) : (int32_t)SQLITE_MISUSE;
}

HeyNativeUtf8View hey_sqlite3_errmsg(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  const char *message = db ? sqlite3_errmsg(db) : "invalid SQLite database handle";
  return (HeyNativeUtf8View){message, strlen(message)};
}

int32_t hey_sqlite3_busy_timeout(HeyNativeHandle database, int32_t milliseconds) {
  sqlite3 *db = hey_sqlite3_database(database);
  return db ? (int32_t)sqlite3_busy_timeout(db, milliseconds) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_exec(HeyNativeHandle database, HeyNativeUtf8View sql) {
  sqlite3 *db = hey_sqlite3_database(database);
  if (!db) return (int32_t)SQLITE_MISUSE;
  char *sql_c = hey_sqlite3_c_string(sql);
  if (!sql_c) return (int32_t)SQLITE_NOMEM;
  int rc = sqlite3_exec(db, sql_c, NULL, NULL, NULL);
  free(sql_c);
  return (int32_t)rc;
}

int64_t hey_sqlite3_changes(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  return db ? (int64_t)sqlite3_changes64(db) : 0;
}

int64_t hey_sqlite3_total_changes(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  return db ? (int64_t)sqlite3_total_changes64(db) : 0;
}

int64_t hey_sqlite3_last_insert_rowid(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  return db ? (int64_t)sqlite3_last_insert_rowid(db) : 0;
}

void hey_sqlite3_interrupt(HeyNativeHandle database) {
  sqlite3 *db = hey_sqlite3_database(database);
  if (db) sqlite3_interrupt(db);
}

HeyNativeHandle hey_sqlite3_prepare(HeyNativeHandle database, HeyNativeUtf8View sql) {
  sqlite3 *db = hey_sqlite3_database(database);
  if (!db) return (HeyNativeHandle)0;
  char *sql_c = hey_sqlite3_c_string(sql);
  if (!sql_c) return (HeyNativeHandle)0;
  sqlite3_stmt *statement = NULL;
  int rc = sqlite3_prepare_v3(db, sql_c, -1, SQLITE_PREPARE_PERSISTENT, &statement, NULL);
  free(sql_c);
  if (rc != SQLITE_OK) {
    if (statement) sqlite3_finalize(statement);
    return (HeyNativeHandle)0;
  }
  return (HeyNativeHandle)(uintptr_t)statement;
}

int32_t hey_sqlite3_bind_parameter_count(HeyNativeHandle statement) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_bind_parameter_count(stmt) : 0;
}

int32_t hey_sqlite3_bind_i64(HeyNativeHandle statement, int32_t index, int64_t value) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_bind_int64(stmt, index, value) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_bind_f64(HeyNativeHandle statement, int32_t index, double value) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_bind_double(stmt, index, value) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_bind_text(HeyNativeHandle statement, int32_t index, HeyNativeUtf8View value) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  if (!stmt) return (int32_t)SQLITE_MISUSE;
  return (int32_t)sqlite3_bind_text64(stmt, index, value.data, (sqlite3_uint64)value.length, SQLITE_TRANSIENT, SQLITE_UTF8);
}

int32_t hey_sqlite3_bind_bytes(HeyNativeHandle statement, int32_t index, HeyNativeBytesView value) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  if (!stmt) return (int32_t)SQLITE_MISUSE;
  return (int32_t)sqlite3_bind_blob64(stmt, index, value.data, (sqlite3_uint64)value.length, SQLITE_TRANSIENT);
}

int32_t hey_sqlite3_bind_null(HeyNativeHandle statement, int32_t index) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_bind_null(stmt, index) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_step(HeyNativeHandle statement) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_step(stmt) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_reset(HeyNativeHandle statement) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_reset(stmt) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_clear_bindings(HeyNativeHandle statement) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_clear_bindings(stmt) : (int32_t)SQLITE_MISUSE;
}

int32_t hey_sqlite3_finalize(HeyNativeHandle statement) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_finalize(stmt) : (int32_t)SQLITE_MISUSE;
}

HeyNativeBool hey_sqlite3_readonly(HeyNativeHandle statement) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return (HeyNativeBool)(stmt && sqlite3_stmt_readonly(stmt));
}

int32_t hey_sqlite3_column_count(HeyNativeHandle statement) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_column_count(stmt) : 0;
}

int32_t hey_sqlite3_column_type(HeyNativeHandle statement, int32_t index) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int32_t)sqlite3_column_type(stmt, index) : (int32_t)SQLITE_NULL;
}

HeyNativeUtf8View hey_sqlite3_column_name(HeyNativeHandle statement, int32_t index) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  const char *value = stmt ? sqlite3_column_name(stmt, index) : NULL;
  if (!value) value = "";
  return (HeyNativeUtf8View){value, strlen(value)};
}

HeyNativeUtf8View hey_sqlite3_column_text(HeyNativeHandle statement, int32_t index) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  const unsigned char *value = stmt ? sqlite3_column_text(stmt, index) : NULL;
  int length = stmt ? sqlite3_column_bytes(stmt, index) : 0;
  if (!value) return (HeyNativeUtf8View){"", 0};
  return (HeyNativeUtf8View){(const char *)value, (size_t)length};
}

HeyNativeBytesView hey_sqlite3_column_bytes(HeyNativeHandle statement, int32_t index) {
  static const uint8_t empty = 0;
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  const void *value = stmt ? sqlite3_column_blob(stmt, index) : NULL;
  int length = stmt ? sqlite3_column_bytes(stmt, index) : 0;
  return (HeyNativeBytesView){value ? (const uint8_t *)value : &empty, (size_t)(length < 0 ? 0 : length)};
}

int64_t hey_sqlite3_column_i64(HeyNativeHandle statement, int32_t index) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? (int64_t)sqlite3_column_int64(stmt, index) : 0;
}

double hey_sqlite3_column_f64(HeyNativeHandle statement, int32_t index) {
  sqlite3_stmt *stmt = hey_sqlite3_statement(statement);
  return stmt ? sqlite3_column_double(stmt, index) : 0.0;
}
