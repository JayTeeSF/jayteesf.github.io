# Done

- v0.1.0 capability and framework contracts.
- Development entitlement metadata without manufacturing unsupported profile entitlements.
- Updated package controls for external `hey_packager` tooling and the repaired `hey_mobile` dependency.
