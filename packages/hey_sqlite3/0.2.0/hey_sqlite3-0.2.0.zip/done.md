# Done

- Replaced the sqlite3 CLI subprocess adapter with Hey native ABI v2.
- Added explicit extension/database/statement ownership.
- Added prepared statements, typed scalar/blob bindings, typed rows, busy timeout, transactions, changes, insert IDs, and interruption.
- Added adapter callbacks compatible with `hey_record@0.2.0`.
- Added interpreter and native-C receipts on Linux; retained an opt-in LLVM probe that currently exposes a v0.99.268a self-hosted lowering gap for the richer adapter surface.
- Made connection close fail while statements remain open, preventing extension unload before deterministic statement finalization.
