#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wnullability-completeness"
#import "HeyIOSApiHost.m"
#pragma clang diagnostic pop
#import <objc/runtime.h>
const char *HeyIOSBakedOrigin(void) { return "https://tree.example.test"; }
static int failures, posts;
static NSDictionary *sentValues;
static NSInteger bodyRequests;
static NSDictionary *lastRoute;
static NSString *session = @"alice";
static NSMutableArray *pending;
static UIWindow *window;
static void check(BOOL ok, NSString *why) {
  if (!ok) {
    fprintf(stderr, "tree-choice FAIL: %s\n", why.UTF8String);
    failures++;
  }
}
static void after(double t, void (^b)(void)) {
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, t * NSEC_PER_SEC), dispatch_get_main_queue(), b);
}
static NSArray *descendants(UIView *v) {
  NSMutableArray *a = [NSMutableArray array];
  for (UIView *c in v.subviews) {
    [a addObject:c];
    [a addObjectsFromArray:descendants(c)];
  }
  return a;
}
static UIButton *button(UITableViewCell *c) {
  for (UIView *v in descendants(c))
    if ([v isKindOfClass:UIButton.class])
      return (id)v;
  return nil;
}
static NSDictionary *node(NSString *path, NSString *parent, BOOL selectable) {
  return @{
    @"path" : path,
    @"parent" : parent,
    @"label" : path.lastPathComponent,
    @"slug" : path,
    @"selectable" : @(selectable)
  };
}
static NSArray *nodes(void) {
  return @[
    node(@"work", @"", YES), node(@"work/science", @"work", YES), node(@"work/art", @"work", YES),
    node(@"private", @"", NO), node(@"private/public", @"private", YES)
  ];
}
static NSDictionary *treeField(void) {
  return @{
    @"kind" : @"choice",
    @"id" : @"folder",
    @"label" : @"Set",
    @"options" : @[ @{@"title" : @"Only this item", @"value" : @""} ],
    @"choices" : @{
      @"method" : @"GET",
      @"path" : @"/nodes",
      @"list" : @"nodes",
      @"value" : @"slug",
      @"label" : @"label",
      @"tree" : @{@"id" : @"path", @"parent" : @"parent", @"selectable" : @"selectable"}
    }
  };
}
static void answer(NSArray *data, NSString *error) {
  void (^done)(NSInteger, id, NSString *) = pending.firstObject;
  [pending removeObjectAtIndex:0];
  done(error ? 500 : 200, @{@"nodes" : data}, error);
}
// A link gated on the form's source appears only when that source arrives, so
// the table gains a section at the same moment a field value changes.
static void sourceShapeFlow(UINavigationController *nav, void (^done)(void)) {
  HeyIOSFormController *form = [[HeyIOSFormController alloc]
      initWithScreen:@{
        @"fields" : @[ @{@"id" : @"title", @"label" : @"Title", @"kind" : @"text"} ],
        @"source" : @{@"method" : @"GET", @"path" : @"/source"},
        @"values" : @{@"title" : @"item.title"},
        @"links" : @[ @{@"title" : @"Open later", @"screen" : @"later", @"when" : @"item.ready"} ]
      }
                vars:@{@"title" : @"Before"}];
  [pending removeAllObjects];
  [nav pushViewController:form animated:NO];
  after(.5, ^{
    NSInteger before = [form numberOfSectionsInTableView:form.tableView];
    check(pending.count == 1, @"form source was not requested");
    // An interactive Back swipe starts with willMove(nil); cancelling it
    // leaves the form in place, and its load must still land.
    [form willMoveToParentViewController:nil];
    if (pending.count == 1) {
      void (^reply)(NSInteger, id, NSString *) = pending.firstObject;
      [pending removeObjectAtIndex:0];
      reply(200, @{@"item" : @{@"title" : @"After", @"ready" : @YES}}, nil);
    }
    [form.tableView layoutIfNeeded];
    check(before == 2 && [form numberOfSectionsInTableView:form.tableView] == 3 &&
              form.tableView.numberOfSections == 3 && [form.values[@"title"] isEqual:@"After"],
          @"source-gated link or changed value did not redraw the form");
    [nav popViewControllerAnimated:NO];
    done();
  });
}

static UITextField *textField(UITableViewCell *c) {
  for (UIView *v in descendants(c))
    if ([v isKindOfClass:UITextField.class])
      return (id)v;
  return nil;
}
static NSInteger cursor(UITextField *f) {
  return [f offsetFromPosition:f.beginningOfDocument toPosition:f.selectedTextRange.start];
}
// A source that lands, or fails, while someone types must leave the keyboard
// and the cursor where they are, even when it adds a source-gated link.
static void focusFlow(UINavigationController *nav, void (^done)(void)) {
  HeyIOSFormController *form = [[HeyIOSFormController alloc]
      initWithScreen:@{
        @"fields" : @[
          @{@"id" : @"title", @"label" : @"Title", @"kind" : @"text"},
          @{@"id" : @"note", @"label" : @"Note", @"kind" : @"text"}
        ],
        @"source" : @{@"method" : @"GET", @"path" : @"/source"},
        @"values" : @{@"title" : @"item.title", @"note" : @"item.note"},
        @"links" : @[ @{@"title" : @"Open later", @"screen" : @"later", @"when" : @"item.ready"} ]
      }
                vars:@{}];
  [pending removeAllObjects];
  [nav pushViewController:form animated:NO];
  after(.5, ^{
    UITextField *field =
        textField([form.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]]);
    [field becomeFirstResponder];
    field.text = @"Typing";
    [field sendActionsForControlEvents:UIControlEventEditingChanged];
    UITextPosition *at = [field positionFromPosition:field.beginningOfDocument offset:2];
    field.selectedTextRange = [field textRangeFromPosition:at toPosition:at];
    check(field.isFirstResponder && cursor(field) == 2, @"focus test could not place the cursor");
    check(pending.count == 1, @"focus form source was not requested");
    if (pending.count == 1) {
      void (^reply)(NSInteger, id, NSString *) = pending.firstObject;
      [pending removeObjectAtIndex:0];
      reply(200, @{@"item" : @{@"title" : @"Late", @"note" : @"Filled", @"ready" : @YES}}, nil);
    }
    [form.tableView layoutIfNeeded];
    check(form.tableView.numberOfSections == 3 && [form.values[@"note"] isEqual:@"Filled"] &&
              [form.values[@"title"] isEqual:@"Typing"],
          @"late source did not add its link and fill the other field");
    check(field.isFirstResponder && field.window != nil && cursor(field) == 2 &&
              [field.text isEqual:@"Typing"],
          @"late shape-changing source took focus or the cursor from the edited field");
    [form reloadContent];
    if (pending.count == 1) {
      void (^reply)(NSInteger, id, NSString *) = pending.firstObject;
      [pending removeObjectAtIndex:0];
      reply(500, nil, @"Offline");
    }
    [form.tableView layoutIfNeeded];
    check([form.message isEqual:@"Offline"] && field.isFirstResponder && field.window != nil && cursor(field) == 2,
          @"late source failure took focus or the cursor from the edited field");
    [field resignFirstResponder];
    after(.3, ^{
      [nav popViewControllerAnimated:NO];
      done();
    });
  });
}
// A field that is only focused, never typed in, is not the person's yet: a late
// source fills it in place, keeping the keyboard and the cursor (at the end),
// whether or not the source also changes the table's shape.
static void untypedFocusFlow(UINavigationController *nav, BOOL reshape, void (^done)(void)) {
  NSMutableDictionary *screen = [@{
    @"fields" : @[
      @{@"id" : @"title", @"label" : @"Title", @"kind" : @"text"},
      @{@"id" : @"note", @"label" : @"Note", @"kind" : @"text"}
    ],
    @"source" : @{@"method" : @"GET", @"path" : @"/source"},
    @"values" : @{@"title" : @"item.title", @"note" : @"item.note"}
  } mutableCopy];
  if (reshape)
    screen[@"links"] = @[ @{@"title" : @"Open later", @"screen" : @"later", @"when" : @"item.ready"} ];
  HeyIOSFormController *form = [[HeyIOSFormController alloc] initWithScreen:screen vars:@{}];
  [pending removeAllObjects];
  [nav pushViewController:form animated:NO];
  after(.5, ^{
    UITextField *field =
        textField([form.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]]);
    [field becomeFirstResponder];
    NSInteger sections = form.tableView.numberOfSections;
    check(field.isFirstResponder && field.text.length == 0 && cursor(field) == 0,
          @"untyped focus test could not focus the empty field");
    check(pending.count == 1, @"untyped focus form source was not requested");
    if (pending.count == 1) {
      void (^reply)(NSInteger, id, NSString *) = pending.firstObject;
      [pending removeObjectAtIndex:0];
      reply(200, @{@"item" : @{@"title" : @"Stored title", @"note" : @"Filled", @"ready" : @YES}}, nil);
    }
    [form.tableView layoutIfNeeded];
    check(form.tableView.numberOfSections == sections + (reshape ? 1 : 0) &&
              [form.values[@"note"] isEqual:@"Filled"] && [form.values[@"title"] isEqual:@"Stored title"],
          reshape ? @"late shape-changing source did not fill the focused but untyped field"
                  : @"late source did not fill the focused but untyped field");
    check(field.isFirstResponder && field.window != nil && [field.text isEqual:@"Stored title"] &&
              cursor(field) == (NSInteger)@"Stored title".length,
          reshape ? @"late shape-changing source did not fill the focused field in place with focus and cursor"
                  : @"late source did not fill the focused field in place with focus and cursor");
    [field resignFirstResponder];
    after(.3, ^{
      [nav popViewControllerAnimated:NO];
      done();
    });
  });
}
// Swiping the picker sheet down finishes like Cancel: Send is redrawn with its
// enabled tint even if it was last drawn under the dimmed sheet.
static void sheetFlow(UINavigationController *nav, void (^done)(void)) {
  HeyIOSFormController *form = [[HeyIOSFormController alloc]
      initWithScreen:@{
        @"fields" : @[ treeField() ],
        @"primary" : @{@"title" : @"Send", @"request" : @{@"method" : @"POST", @"path" : @"/send"}}
      }
                vars:@{@"folder" : @"work"}];
  [pending removeAllObjects];
  [nav pushViewController:form animated:NO];
  after(.5, ^{
    if (pending.count)
      answer(nodes(), nil);
    [form openTree:treeField()];
    after(.7, ^{
      UINavigationController *sheet = (id)form.presentedViewController;
      check(sheet != nil, @"picker sheet did not open for the swipe test");
      [form refreshPrimaryTitle];
      UIPresentationController *presentation = sheet.presentationController;
      id<UIAdaptivePresentationControllerDelegate> delegate = presentation.delegate;
      [form dismissViewControllerAnimated:YES
                               completion:^{
                                 // What UIKit calls once an interactive swipe-down completes.
                                 if ([delegate respondsToSelector:@selector(presentationControllerDidDismiss:)])
                                   [delegate presentationControllerDidDismiss:presentation];
                               }];
      after(.8, ^{
        UITableViewCell *sendCell =
            [form.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
        UIListContentConfiguration *content = (id)sendCell.contentConfiguration;
        UIColor *actual = [content.textProperties.color resolvedColorWithTraitCollection:form.traitCollection];
        UIColor *expected = [form.view.tintColor resolvedColorWithTraitCollection:form.traitCollection];
        check(sendCell != nil && [actual isEqual:expected], @"swiping the picker away left Send looking disabled");
        [nav popViewControllerAnimated:NO];
        done();
      });
    });
  });
}
static void staticChoiceFlow(UINavigationController *nav, NSString *prose, void (^done)(void)) {
  HeyIOSFormController *form =
      [[HeyIOSFormController alloc] initWithScreen:@{
        @"fields" : @[ @{@"id" : @"message", @"kind" : @"multiline"}, treeField() ]
      }
                                              vars:@{@"folder" : @"work", @"message" : prose}];
  [nav pushViewController:form animated:NO];
  [form openTree:treeField()];
  after(.5, ^{
    UITableViewController *picker =
        (id)((UINavigationController *)form.presentedViewController).topViewController;
    check([(id<UITableViewDataSource>)picker tableView:picker.tableView numberOfRowsInSection:0] >= 2,
          @"initial loading did not retain static option beside status");
    [(id<UITableViewDelegate>)picker tableView:picker.tableView
                       didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    BOOL staticKept = [form.values[@"folder"] isEqual:@""] && [form.values[@"message"] isEqual:prose] && posts == 1;
    if (!staticKept)
      fprintf(stderr, "tree-choice static loading state folder=%s posts=%d prose=%d presented=%s\n",
              [form.values[@"folder"] description].UTF8String, posts, [form.values[@"message"] isEqual:prose],
              NSStringFromClass([form.presentedViewController class]).UTF8String);
    check(staticKept, @"static selection during loading changed prose or sent");
    if (![form.values[@"folder"] isEqual:@""]) {
      [nav popViewControllerAnimated:NO];
      [pending removeAllObjects];
      done();
      return;
    }
    answer(@[], @"Offline");
    after(.5, ^{
      [form openTree:treeField()];
      after(.5, ^{
        UITableViewController *retryPicker =
            (id)((UINavigationController *)form.presentedViewController).topViewController;
        check([(id<UITableViewDataSource>)retryPicker tableView:retryPicker.tableView
                                          numberOfRowsInSection:0] >= 2,
              @"metadata error hid static option");
        [(id<UITableViewDelegate>)retryPicker tableView:retryPicker.tableView
                                didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        check([form.values[@"folder"] isEqual:@""] && [form.values[@"message"] isEqual:prose] && posts == 1,
              @"static selection during error changed prose or sent");
        after(.5, ^{
          [nav popViewControllerAnimated:NO];
          done();
        });
      });
    });
  });
}
@interface TreeDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic, strong) UIWindow *window;
@end
@implementation TreeDelegate
- (BOOL)application:(UIApplication *)a didFinishLaunchingWithOptions:(NSDictionary *)o {
  pending = [NSMutableArray array];
  method_setImplementation(class_getInstanceMethod(HeyIOSApi.class, @selector(token)),
                           imp_implementationWithBlock(^NSString *(id s) {
                             return session;
                           }));
  method_setImplementation(class_getInstanceMethod(HeyIOSApi.class, @selector(send:vars:row:completion:)),
                           imp_implementationWithBlock(^(id s, NSDictionary *route, NSDictionary *vars,
                                                         id row, void (^done)(NSInteger, id, NSString *)) {
                             lastRoute = route;
                             if (route[@"body"] != nil)
                               bodyRequests++;
                             if ([route[@"method"] isEqual:@"POST"]) {
                               posts++;
                               sentValues = [vars copy];
                               done(200, @{}, nil);
                             } else
                               [pending addObject:[done copy]];
                           }));
  NSMutableArray *fields = [NSMutableArray
      arrayWithArray:@[ @{@"id" : @"message", @"label" : @"Message", @"kind" : @"multiline"}, treeField() ]];
  for (NSString *kind in @[ @"text", @"prose", @"url", @"secure", @"new_secure", @"code" ])
    [fields
        addObject:@{@"id" : [kind isEqual:@"text"] ? @"title" : kind, @"label" : kind, @"kind" : kind}];
  // A username is typed exactly: no capital forced on it and no correction.
  [fields addObject:@{@"id" : @"username", @"label" : @"Name", @"kind" : @"text"}];
  HeyIOSFormController *form = [[HeyIOSFormController alloc]
      initWithScreen:@{
        @"id" : @"draft",
        @"title" : @"Share draft",
        @"fields" : fields,
        @"primary" : @{@"title" : @"Send", @"request" : @{@"method" : @"POST", @"path" : @"/send"}}
      }
                vars:@{@"folder" : @"work", @"message" : @"MiXeD typed\nDictated words. 🎬"}];
  self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  window = self.window;
  UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:form];
  window.rootViewController = nav;
  [window makeKeyAndVisible];
  after(.5, ^{
    NSString *prose = [form.values[@"message"] copy];
    for (NSInteger i = 0; i < fields.count; i++) {
      UITableViewCell *cell = [form.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i
                                                                                       inSection:0]]
                                  ?: [form tableView:form.tableView
                                         cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
      for (UIView *v in descendants(cell))
        if ([v isKindOfClass:UITextField.class] || [v isKindOfClass:UITextView.class]) {
          NSString *kind = fields[i][@"kind"];
          BOOL ordinary = [@[ @"text", @"prose", @"multiline" ] containsObject:kind];
          if ([fields[i][@"id"] isEqual:@"username"]) {
            check([(id)v autocapitalizationType] == UITextAutocapitalizationTypeNone &&
                      [(id)v autocorrectionType] == UITextAutocorrectionTypeNo,
                  @"username field capitalizes or corrects what was typed");
          } else if (ordinary) {
            check([(id)v autocapitalizationType] == UITextAutocapitalizationTypeSentences,
                  @"ordinary text lacks sentence capitalization");
            check([(id)v autocorrectionType] == UITextAutocorrectionTypeDefault,
                  @"ordinary text lacks default correction");
          } else {
            check([(id)v autocorrectionType] == UITextAutocorrectionTypeNo,
                  @"structured input correction enabled");
          }
          if ([fields[i][@"id"] isEqual:@"username"]) {
            [(UITextField *)v setText:@"MiXeDUser"];
            [(UITextField *)v sendActionsForControlEvents:UIControlEventEditingChanged];
            check([form.values[@"username"] isEqual:@"MiXeDUser"], @"username case transformed");
          }
        }
    }
    // Whatever kind names it, a username takes no capitals and no correction.
    for (NSString *kind in @[ @"multiline", @"code", @"prose", @"text", @"url", @"secure", @"number" ]) {
      HeyIOSFormController *exact = [[HeyIOSFormController alloc]
          initWithScreen:@{@"fields" : @[ @{@"id" : @"username", @"label" : @"Name", @"kind" : kind} ]}
                    vars:@{}];
      [exact loadViewIfNeeded];
      UITableViewCell *exactCell = [exact tableView:exact.tableView
                              cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
      BOOL seen = NO;
      for (UIView *v in descendants(exactCell))
        if ([v isKindOfClass:UITextField.class] || [v isKindOfClass:UITextView.class]) {
          seen = YES;
          check([(id)v autocapitalizationType] == UITextAutocapitalizationTypeNone &&
                    [(id)v autocorrectionType] == UITextAutocorrectionTypeNo,
                [@"username capitalizes or corrects as kind " stringByAppendingString:kind]);
        }
      check(seen, [@"username input missing for kind " stringByAppendingString:kind]);
    }
    check(NSClassFromString(@"HeyIOSTreeChoiceController") != nil, @"hierarchical choice controller missing");
    if (NSClassFromString(@"HeyIOSTreeChoiceController") == nil) {
      fprintf(stdout, "hey_ios_tree_choice=false failures=%d\n", failures);
      exit(1);
    }
    NSInteger readsBefore = pending.count, postsBefore = posts, bodiesBefore = bodyRequests;
    for (NSDictionary *routeChange in @[ @{@"method" : @"POST"}, @{@"body" : @{@"q" : @"x"}}, @{@"body" : @[]} ]) {
      NSMutableDictionary *unsafeField = [treeField() mutableCopy],
                          *unsafeRoute = [unsafeField[@"choices"] mutableCopy];
      [unsafeRoute addEntriesFromDictionary:routeChange];
      unsafeField[@"choices"] = unsafeRoute;
      HeyIOSFormController *unsafe = [[HeyIOSFormController alloc] initWithScreen:@{
        @"fields" : @[ unsafeField ]
      }
                                                                             vars:@{}];
      [unsafe loadViewIfNeeded];
    }
    check(posts == postsBefore && pending.count == readsBefore && bodyRequests == bodiesBefore,
          @"tree metadata dispatched a write method or request body");
    // Discard unsafe test completions after recording the failing behavior.
    while (pending.count > readsBefore)
      [pending removeLastObject];
    posts = postsBefore;
    {
      // Lower-case get and an empty body object still describe a plain read.
      NSMutableDictionary *readField = [treeField() mutableCopy], *readRoute = [readField[@"choices"] mutableCopy];
      readRoute[@"method"] = @"get";
      readRoute[@"body"] = @{};
      readField[@"choices"] = readRoute;
      HeyIOSFormController *reader = [[HeyIOSFormController alloc] initWithScreen:@{@"fields" : @[ readField ]}
                                                                              vars:@{}];
      [reader loadViewIfNeeded];
      check(pending.count == readsBefore + 1 && [lastRoute[@"method"] isEqual:@"GET"] && lastRoute[@"body"] == nil &&
                bodyRequests == bodiesBefore && posts == postsBefore,
            @"get with an empty body was not sent as one bodyless GET");
      while (pending.count > readsBefore)
        [pending removeLastObject];
    }
    Class mapper = NSClassFromString(@"HeyIOSTreeChoiceController");
    NSArray *mapped =
        ((id (*)(id, SEL, id, id))[mapper methodForSelector:NSSelectorFromString(@"mapped:json:")])(
            mapper, NSSelectorFromString(@"mapped:json:"), treeField(), @{@"nodes" : nodes()});
    check(mapped.count == 6, @"mapping lost static or remote choices");
    for (NSArray *bad in @[
           @[ node(@"duplicate", @"", YES), node(@"duplicate", @"", YES) ],
           @[ node(@"a", @"b", YES), node(@"b", @"a", YES) ], @[ node(@"orphan", @"absent", YES) ],
           @[ node(@"self", @"self", YES) ], @[ @{@"path" : @"bad", @"parent" : @""} ],
           // Selectable with no value would silently mean the static "Only this item".
           @[ @{@"path" : @"blank", @"parent" : @"", @"label" : @"blank", @"slug" : @"", @"selectable" : @YES} ]
         ]) {
      id invalid =
          ((id (*)(id, SEL, id, id))[mapper methodForSelector:NSSelectorFromString(@"mapped:json:")])(
              mapper, NSSelectorFromString(@"mapped:json:"), treeField(), @{@"nodes" : bad});
      check(invalid == nil, @"malformed forest accepted");
    }
    // The server names a private structural folder with an empty value.
    id structural =
        ((id (*)(id, SEL, id, id))[mapper methodForSelector:NSSelectorFromString(@"mapped:json:")])(
            mapper, NSSelectorFromString(@"mapped:json:"), treeField(), @{
              @"nodes" : @[ @{@"path" : @"folder", @"parent" : @"", @"label" : @"folder", @"slug" : @"", @"selectable" : @NO},
                             node(@"folder/x", @"folder", YES) ]
            });
    check(structural != nil, @"an unselectable folder with no value was refused");
    // Numeric identities and parents are their decimal text.
    NSArray *numeric =
        ((id (*)(id, SEL, id, id))[mapper methodForSelector:NSSelectorFromString(@"mapped:json:")])(
            mapper, NSSelectorFromString(@"mapped:json:"), treeField(), @{
              @"nodes" : @[
                @{@"path" : @7, @"parent" : NSNull.null, @"label" : @"seven", @"slug" : @"s7", @"selectable" : @YES},
                @{@"path" : @8, @"parent" : @7, @"label" : @"eight", @"slug" : @"s8", @"selectable" : @YES},
                @{@"path" : @"9", @"parent" : @8, @"label" : @"nine", @"slug" : @"s9", @"selectable" : @YES}
              ]
            });
    check(numeric.count == 4 && [numeric[2][@"id"] isEqual:@"remote:8"] &&
              [numeric[2][@"parent"] isEqual:@"remote:7"] && [numeric[3][@"parent"] isEqual:@"remote:8"],
          @"numeric tree id or parent was refused or not read as decimal text");
    for (NSDictionary *bad in @[ @{@"path" : @YES, @"parent" : @""}, @{@"path" : @"x", @"parent" : @NO},
                                @{@"path" : @{}, @"parent" : @""} ]) {
      NSMutableDictionary *row = [bad mutableCopy];
      [row addEntriesFromDictionary:@{@"label" : @"bad", @"slug" : @"bad", @"selectable" : @YES}];
      id refused = ((id (*)(id, SEL, id, id))[mapper methodForSelector:NSSelectorFromString(@"mapped:json:")])(
          mapper, NSSelectorFromString(@"mapped:json:"), treeField(), @{@"nodes" : @[ row ]});
      check(refused == nil, @"boolean or object tree identity accepted");
    }
    check([form.options[@"folder"] count] >= 1 && [form.options[@"folder"][0][@"selectable"] boolValue],
          @"loading hid static empty choice");
    answer(nodes(), nil);
    NSMutableDictionary *flatField = [treeField() mutableCopy],
                        *flatChoices = [flatField[@"choices"] mutableCopy];
    [flatChoices removeObjectForKey:@"tree"];
    flatField[@"choices"] = flatChoices;
    HeyIOSFormController *flat = [[HeyIOSFormController alloc] initWithScreen:@{
      @"fields" : @[ flatField ]
    }
                                                                         vars:@{}];
    [flat loadViewIfNeeded];
    answer(@[ @{@"slug" : @"", @"label" : @"Empty remote value"} ], nil);
    check([flat.options[@"folder"] count] == 2, @"flat choices dropped an existing empty remote value");
    [flat loadChoices];
    answer(@[], @"Offline");
    check([flat.options[@"folder"] count] == 1, @"flat choices changed legacy error fallback");

    UITableViewCell *cell = [form tableView:form.tableView
                      cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
    // Keep Send on screen while the picker is up. Scrolling to it after
    // dismissal would redraw the cell and hide a stale disabled tint.
    [form.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]
                          atScrollPosition:UITableViewScrollPositionBottom
                                  animated:NO];
    [form.tableView layoutIfNeeded];
    [form loadChoices];
    [button(cell) sendActionsForControlEvents:UIControlEventTouchUpInside];
    after(.5, ^{
      UINavigationController *sheet = (id)form.presentedViewController;
      UITableViewController *picker = (id)sheet.topViewController;
      check([picker isKindOfClass:NSClassFromString(@"HeyIOSTreeChoiceController")],
            @"choice button did not open hierarchy");
      id<UITableViewDataSource> ds = picker;
      id<UITableViewDelegate> delegate = picker;
      answer(@[], @"Offline");
      check([ds tableView:picker.tableView numberOfRowsInSection:0] >= 2 &&
                [form.values[@"message"] isEqual:prose],
            @"active picker load failure lost draft or retry row");
      [delegate tableView:picker.tableView
          didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:[ds tableView:picker.tableView
                                                                   numberOfRowsInSection:0] -
                                                               1
                                                     inSection:0]];
      check(pending.count == 1, @"Try again did not request choices");
      [delegate tableView:picker.tableView
          didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:[ds tableView:picker.tableView
                                                                   numberOfRowsInSection:0] -
                                                               1
                                                     inSection:0]];
      check(pending.count == 1, @"Try again started a second load while one was in flight");
      while (pending.count > 1)
        [pending removeLastObject];
      answer(nodes(), nil);
      check([[picker valueForKey:@"loadError"] length] == 0, @"active picker retry kept old error");

      check([ds tableView:picker.tableView numberOfRowsInSection:0] == 3,
            @"collapsed root hierarchy flattened");
      UITableViewCell *parent = [ds tableView:picker.tableView
                        cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
      check(parent.accessoryView != nil, @"parent has no independent disclosure");
      [(UIControl *)parent.accessoryView sendActionsForControlEvents:UIControlEventTouchUpInside];
      [(UIControl *)parent.accessoryView sendActionsForControlEvents:UIControlEventTouchUpInside];
      check([ds tableView:picker.tableView numberOfRowsInSection:0] == 3 &&
                [form.values[@"folder"] isEqual:@"work"],
            @"collapse changed selection or kept children visible");
      [(UIControl *)parent.accessoryView sendActionsForControlEvents:UIControlEventTouchUpInside];
      [picker.tableView layoutIfNeeded];

      UITableViewCell *renderedParent =
          [picker.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
      UITableViewCell *renderedChild =
          [picker.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
      CGFloat parentX = [renderedParent.textLabel convertPoint:CGPointZero toView:picker.tableView].x;
      CGFloat childX = [renderedChild.textLabel convertPoint:CGPointZero toView:picker.tableView].x;
      check(childX > parentX, @"selection marker made child labels appear above their hierarchy level");
      check([ds tableView:picker.tableView numberOfRowsInSection:0] == 5,
            @"expansion did not reveal two children");
      check([form.values[@"folder"] isEqual:@"work"] && posts == 0, @"disclosure selected or sent");
      NSString *mode = [[NSUserDefaults standardUserDefaults] stringForKey:@"Mode"];

      [delegate tableView:picker.tableView
          didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:4 inSection:0]];
      check([form.values[@"folder"] isEqual:@"work"], @"private structural ancestor selected");
      UITableViewCell *privateFolder = [ds tableView:picker.tableView
                               cellForRowAtIndexPath:[NSIndexPath indexPathForRow:4 inSection:0]];
      [(UIControl *)privateFolder.accessoryView sendActionsForControlEvents:UIControlEventTouchUpInside];
      check([ds tableView:picker.tableView numberOfRowsInSection:0] == 6,
            @"private ancestor cannot expand to its public child");
      if ([mode isEqual:@"frame-tree"])
        return;

      [delegate tableView:picker.tableView
          didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
      after(.5, ^{
        NSIndexPath *sendPath = [NSIndexPath indexPathForRow:0 inSection:1];
        UITableViewCell *sendCell = [form.tableView cellForRowAtIndexPath:sendPath];
        check(sendCell != nil, @"Send row could not be rendered for its tint check");
        UIListContentConfiguration *sendContent = (id)sendCell.contentConfiguration;
        UIColor *actualColor =
            [sendContent.textProperties.color resolvedColorWithTraitCollection:form.traitCollection];
        UIColor *expectedColor = [form.view.tintColor resolvedColorWithTraitCollection:form.traitCollection];
        check([actualColor isEqual:expectedColor], @"picker dismissal left Send looking disabled");
        if ([[[NSUserDefaults standardUserDefaults] stringForKey:@"Mode"] isEqual:@"frame-selected"])
          return;
        check([form.values[@"folder"] isEqual:@"work/science"] && [form.touched containsObject:@"folder"],
              @"leaf selection not stored as touched local state");
        check([form.values[@"message"] isEqual:prose] && posts == 0,
              @"tree interaction changed prose or sent");
        [button([form tableView:form.tableView
            cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]])
            sendActionsForControlEvents:UIControlEventTouchUpInside];
        after(.5, ^{
          UITableViewController *again =
              (id)((UINavigationController *)form.presentedViewController).topViewController;
          UIBarButtonItem *cancel = again.navigationItem.leftBarButtonItem;
          [UIApplication.sharedApplication sendAction:cancel.action
                                                   to:cancel.target
                                                 from:cancel
                                             forEvent:nil];
          after(.5, ^{
            check([form.values[@"folder"] isEqual:@"work/science"] && [form.values[@"message"] isEqual:prose],
                  @"cancel changed draft");
            if ([[[NSUserDefaults standardUserDefaults] stringForKey:@"Mode"] isEqual:@"frame-cancel"])
              return;
            NSArray *before = form.options[@"folder"];
            [form loadChoices];
            session = @"bob";
            answer(@[ node(@"bob-only", @"", YES) ], nil);
            check([form.options[@"folder"] isEqual:before], @"account switch accepted old choices callback");
            session = @"alice";
            [form loadChoices];
            [[NSNotificationCenter defaultCenter] postNotificationName:HeyIOSSignedOutNotification
                                                                object:nil];
            answer(@[ node(@"late", @"", YES) ], nil);
            check([form.options[@"folder"] isEqual:before],
                  @"signout and same-token reuse accepted old callback");
            [form loadChoices];
            answer(@[], @"Offline");
            check([form.treeErrors[@"folder"] isEqual:@"Offline"] && [form.values[@"message"] isEqual:prose],
                  @"load failure lost draft or retry error");
            [form loadChoices];
            answer(nodes(), nil);
            check(form.treeErrors[@"folder"] == nil, @"retry did not clear error");
            // Only the newest choices request may update the rows.
            NSArray *settled = form.options[@"folder"];
            [form loadChoices];
            [form loadChoices];
            if (pending.count == 2) {
              void (^older)(NSInteger, id, NSString *) = pending[0], (^newer)(NSInteger, id, NSString *) = pending[1];
              [pending removeAllObjects];
              newer(200, @{@"nodes" : nodes()}, nil);
              older(200, @{@"nodes" : @[ node(@"stale", @"", YES) ]}, nil);
            } else
              check(NO, @"two choices loads were not both requested");
            check([form.options[@"folder"] isEqual:settled] && form.treeErrors[@"folder"] == nil,
                  @"an older choices response replaced the newest rows");
            // Source callbacks cannot replace typed or selected values, including an empty draft.
            NSMutableDictionary *sourceScreen = [form.screen mutableCopy];
            sourceScreen[@"source"] = @{@"method" : @"GET", @"path" : @"/draft"};
            sourceScreen[@"values"] =
                @{@"message" : @"message", @"folder" : @"folder", @"request_key" : @"request_key"};
            form.screen = sourceScreen;
            form.values[@"message"] = @"";
            [form.touched addObject:@"message"];
            [form loadSource];
            void (^sourceDone)(NSInteger, id, NSString *) = pending.firstObject;
            [pending removeObjectAtIndex:0];
            sourceDone(200,
                       @{@"message" : @"overwrite", @"folder" : @"overwrite", @"request_key" : @"event-17"},
                       nil);
            check([form.values[@"message"] isEqual:@""] && [form.values[@"folder"] isEqual:@"work/science"],
                  @"source replaced touched prose or selection");
            check([form.values[@"request_key"] isEqual:@"event-17"],
                  @"source metadata without a visual field was lost");
            form.values[@"message"] = prose;
            [form loadSource];
            sourceDone = pending.firstObject;
            [pending removeObjectAtIndex:0];
            [form invalidateFormLoads];
            sourceDone(200, @{@"message" : @"late"}, nil);
            check([form.values[@"message"] isEqual:prose], @"late source replaced draft");
            // A reload supersedes the source request already in flight.
            [form reloadContent];
            [form reloadContent];
            if (pending.count == 2) {
              void (^older)(NSInteger, id, NSString *) = pending[0], (^newer)(NSInteger, id, NSString *) = pending[1];
              [pending removeAllObjects];
              newer(200, @{@"request_key" : @"newer"}, nil);
              older(200, @{@"request_key" : @"older"}, nil);
            } else
              check(NO, @"two source reloads were not both requested");
            check([form.values[@"request_key"] isEqual:@"newer"], @"an older source response overwrote a newer one");
            // Exercise selecting a public parent itself independently of disclosure.
            [form openTree:treeField()];
            after(.5, ^{
              UITableViewController *parentPicker =
                  (id)((UINavigationController *)form.presentedViewController).topViewController;
              [(id<UITableViewDelegate>)parentPicker tableView:parentPicker.tableView
                                       didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
              check([form.values[@"folder"] isEqual:@"work"] && posts == 0,
                    @"public parent cannot be selected locally");
              if ([[[NSUserDefaults standardUserDefaults] stringForKey:@"Mode"] isEqual:@"frame-parent"])
                return;
              [form submit];
              check(posts == 1 && [sentValues[@"message"] isEqual:prose] &&
                        [sentValues[@"folder"] isEqual:@"work"] &&
                        [sentValues[@"username"] isEqual:@"MiXeDUser"],
                    @"Send did not write the exact authored draft once");

              after(.5, ^{
                staticChoiceFlow(nav, prose, ^{
                  sourceShapeFlow(nav, ^{
                    focusFlow(nav, ^{
                      untypedFocusFlow(nav, YES, ^{
                        untypedFocusFlow(nav, NO, ^{
                          sheetFlow(nav, ^{
                            fprintf(stdout, "hey_ios_tree_choice=%s failures=%d posts=%d\n",
                                    failures ? "false" : "true", failures, posts);
                            fflush(stdout);
                            exit(failures ? 1 : 0);
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
  return YES;
}
@end
int main(int argc, char **argv) {
  @autoreleasepool {
    return UIApplicationMain(argc, argv, nil, NSStringFromClass(TreeDelegate.class));
  }
}
