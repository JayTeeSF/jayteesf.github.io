package hey.android.api;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Runs against the real Activity, chooser Intent and app-owned ContentProvider. */
public final class ShareInstrumentation extends Instrumentation {
  private volatile Intent sent;
  private volatile CountDownLatch shared;
  private volatile long began, chooserMillis;
  private final java.util.concurrent.atomic.AtomicInteger chooserCount = new java.util.concurrent.atomic.AtomicInteger();
  private Bundle arguments;

  private static void require(boolean ok, String why) {
    if (!ok) throw new AssertionError(why);
  }

  @Override public void onCreate(Bundle arguments) { this.arguments = arguments; super.onCreate(arguments); start(); }

  @Override public void onStart() {
    Bundle result = new Bundle();
    Activity activity = null;
    CountDownLatch release = new CountDownLatch(1);
    try {
      addMonitor(new ActivityMonitor() {
        @Override public ActivityResult onStartActivity(Intent intent) {
          if (!Intent.ACTION_CHOOSER.equals(intent.getAction())) return null;
          sent = intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class);
          chooserMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - began);
          chooserCount.incrementAndGet();
          shared.countDown();
          return new ActivityResult(Activity.RESULT_OK, null);
        }
      });
      String app = getTargetContext().getPackageName();
      activity = startActivitySync(new Intent().setClassName(app, "hey.android.api.HeyAndroidApiActivity")
          .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
      waitForIdleSync();
      final Activity running = activity;
      Method top = activity.getClass().getDeclaredMethod("top");
      top.setAccessible(true);
      Actions.Host page = (Actions.Host) top.invoke(activity);
      require(page != null, "fixture did not draw its baked screen");
      Field pictures = activity.getClass().getDeclaredField("pictures");
      pictures.setAccessible(true);
      Object cache = pictures.get(activity);
      Method hold = cache.getClass().getDeclaredMethod("hold", String.class, boolean.class, Bitmap.class);
      hold.setAccessible(true);
      Bitmap image = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888);
      image.eraseColor(0xff336699);
      hold.invoke(cache, "https://example.invalid/art.png", true, image);
      Field workers = cache.getClass().getDeclaredField("shares"); workers.setAccessible(true);
      java.util.concurrent.ExecutorService executor = (java.util.concurrent.ExecutorService) workers.get(cache);
      boolean deadline = "deadline".equals(arguments.getString("scenario", "normal"));
      if (deadline) {
        CountDownLatch occupied = new CountDownLatch(1);
        executor.execute(() -> {
          occupied.countDown();
          try { release.await(15, TimeUnit.SECONDS); }
          catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
        });
        require(occupied.await(2, TimeUnit.SECONDS), "fixture did not occupy the share worker");
      }

      shared = new CountDownLatch(1);
      runOnMainSync(() -> {
        began = System.nanoTime();
        page.share("https://example.invalid/thread", "Shared item", "  Exact\nreply  ", "https://example.invalid/art.png");
      });
      require(shared.await(15, TimeUnit.SECONDS), "native share did not reach the chooser");
      require("  Exact\nreply  \n\nhttps://example.invalid/thread".equals(sent.getStringExtra(Intent.EXTRA_TEXT)), "typed text or canonical URL changed");
      Uri stream = sent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
      boolean fallback = stream == null;
      if (deadline) require(fallback, "an occupied share worker must finish with the bounded text fallback");
      if (fallback) {
        // A cold or contended emulator may legitimately exhaust the production
        // two-second budget. Validate that behavior, then test an explicit retry
        // with the worker available; never relax the actual attachment checks.
        require("text/plain".equals(sent.getType()) && chooserMillis >= 2000,
            "artwork disappeared before the two-second deadline: " + chooserMillis + "ms");
        release.countDown();
        executor.submit(() -> {}).get(5, TimeUnit.SECONDS);
        waitForIdleSync();
        shared = new CountDownLatch(1);
        runOnMainSync(() -> {
          began = System.nanoTime();
          page.share("https://example.invalid/thread", "Shared item", "  Exact\nreply  ", "https://example.invalid/art.png");
        });
        require(shared.await(15, TimeUnit.SECONDS), "explicit share retry did not reach the chooser");
        require("  Exact\nreply  \n\nhttps://example.invalid/thread".equals(sent.getStringExtra(Intent.EXTRA_TEXT)), "explicit retry changed authored text or URL");
        stream = sent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
      }
      require(stream != null, "artwork is not a real EXTRA_STREAM attachment");
      require("content".equals(stream.getScheme()), "attachment must use a content URI");
      require("image/png".equals(sent.getType()), "artwork MIME type missing");
      require((sent.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0, "attachment has no temporary read grant");
      require(sent.getClipData() != null && stream.equals(sent.getClipData().getItemAt(0).getUri()), "grant URI is missing from ClipData");
      try (java.io.InputStream input = activity.getContentResolver().openInputStream(stream)) {
        byte[] bytes = input.readAllBytes();
        require(bytes.length > 8 && bytes[0] == (byte) 137 && bytes[1] == 80 && bytes[2] == 78 && bytes[3] == 71, "shared URI does not open PNG artwork");
      }
      android.content.pm.ProviderInfo provider = activity.getPackageManager().resolveContentProvider(stream.getAuthority(), 0);
      require(provider != null && !provider.exported && provider.grantUriPermissions, "provider must be private with temporary URI grants");
      try {
        activity.getContentResolver().openFileDescriptor(stream, "w");
        throw new AssertionError("shared artwork allowed writes");
      } catch (java.io.FileNotFoundException | SecurityException expected) { }
      try {
        activity.getContentResolver().openInputStream(Uri.parse("content://" + stream.getAuthority() + "/../outside.png"));
        throw new AssertionError("provider accepted a path traversal");
      } catch (java.io.FileNotFoundException | SecurityException expected) { }

      shared = new CountDownLatch(1);
      runOnMainSync(() -> page.share("https://example.invalid/thread", "Shared item", "  Exact\nreply  ", ""));
      require(shared.await(5, TimeUnit.SECONDS), "missing artwork suppressed text sharing");
      require("text/plain".equals(sent.getType()) && !sent.hasExtra(Intent.EXTRA_STREAM), "missing artwork must retain plain message and URL");
      require(chooserCount.get() == (fallback ? 3 : 2), "late artwork opened an extra chooser");
      result.putString("stream", "share_instrumentation=true deadline=" + deadline + " fallback=" + fallback + " real_attachment=true explicit_retry=" + fallback);
      finish(Activity.RESULT_OK, result);
    } catch (Throwable error) {
      result.putString("stream", "FAIL: " + error);
      finish(Activity.RESULT_CANCELED, result);
    } finally {
      release.countDown();
      if (activity != null) {
        final Activity done = activity;
        runOnMainSync(done::finish);
      }
    }
  }
}
