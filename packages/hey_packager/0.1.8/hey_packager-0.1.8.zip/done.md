# Done

- v0.1.0: release, checksums, documentation, immutable website publication, version bump, and source handoff porcelain.
- v0.1.2: validation ordering, safe output cleanup, explicit source-handoff status, and HEY_ROOT-correct documentation-example execution.
- v0.1.7: Adopts hey_packager (canonical bin/check, bin/bump, bin/release, bin/publish); release no longer publishes. Bump fixed for BSD sed.
- v0.1.8: declared version copies (`hey-version-files`) and a `bin/package-bump` hook; bump verifies, restores, dry-runs and normalizes; release/publish run the full check with explicit overrides; `update-packages` replaces the v3 updater.
