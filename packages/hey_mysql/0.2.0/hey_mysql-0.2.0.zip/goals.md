# Goals

- Keep MySQL/MariaDB integration outside the Hey runtime and standard library.
- Provide an honest Connector/C adapter with explicit ownership, bounded timeouts, TLS policy, transactions, and row results.
- Converge on server-side prepared statements and a shared `hey_record` contract without leaking Connector/C types.
